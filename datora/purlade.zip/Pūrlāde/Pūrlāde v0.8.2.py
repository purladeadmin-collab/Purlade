#!/usr/bin/env python3
"""
Pūrlāde — tautas deju kolektīva pārvaldības programma
(Folk dance group management program)

Moduļi (folderī moduli/):
    Tērpu pūrs      – tērpu uzskaite, izsniegšana un atgriešana
    Deju pūrs       – deju (repertuāra) uzskaite
    Kopas pūrs      – dejotāju uzskaite un statistika
    Notikumu pūrs   – koncertu un citu pasākumu plānošana un uzskaite
    Cītības pūrs    – apmeklējuma uzskaite
    Zelta pūrs      – finanšu pārvaldība

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3; the online database is
              reached with moduli/pgwire.py, also standard library only).
Run:          python "Pūrlāde v0.8.2.py"

All data is kept in ONE database: purlade.db next to this file, or the shared online PostgreSQL
database (Supabase) when this computer is connected to it (Administrēšana → Datubāze…).
On the first start the data of the stand-alone Tērpu pūrs (costume_inventory.db) is copied into purlade.db.
"""

import importlib
import os
import sys
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from moduli import kopeja  # noqa: E402
from moduli import administresana  # noqa: E402
from moduli import izmainas  # noqa: E402
from moduli import kolektiva_vesture  # noqa: E402
from moduli import izstrades_darbi  # noqa: E402
from moduli import aizversana  # noqa: E402
from moduli import atjauninasana  # noqa: E402
from moduli import piekluve  # noqa: E402
from moduli import izskats  # noqa: E402
from moduli import sakums as home  # noqa: E402
from moduli.kopeja import CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREY  # noqa: E402

PROGRAM_NAME = "Pūrlāde"
APP_VERSION = "0.8.2"
TAGLINE = "Viss amatiermākslas kolektīvam vienuviet"

# Pūrlāde logo, only the chest with the module cards (PNG as base64 text): header and window icon
PURLADE_LOGO_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAMMAAACCCAYAAAD7e3xjAADivUlEQVR42uy9d3xc1bX3/d37nOnqXbLk3nuvuIJNN1Wmd0KH9IRA"
    "ghCQBEIghIQSSgodi96LAcsV27j33otkq2vKaXu/f5yRbHJzc+/z3Pd533vvc8cffeQZzZw5c2avvdb6rd/6LcH/3P7RTVRVVYlB"
    "mzaJjfX1AoDaWlUN6h89+au/VIWXLl7Uta2huZuy7YGBcGhAKCPUPxyNlriW0+Q5+vWq15Y85jqO8A+G/tfeWGvE/HurjPnMZxqw"
    "7XA/0be0VB/dtElvHDhQ31tdrcU/ef3/3P4DX/r/7RdAay3uvfdewfz5EoBptaq6+h8tesFHv78ttHjFsjLToY9QopfWulsoI9Qv"
    "nBXtF83K65KdVZKVX1BCQVkp2UUFZOUW4KZsvv7kbVZ/s/i3972y/MdV9yj5j4/vG4IQHQtd/DObEXMrK2WHoQ4qKtIAGwcO1Pfe"
    "W62PH+N/bv9jDP9k162Z4y+iTUW1uqYG7x9dkq/0l+b8i+8st5JWb9fxegTCZp9odmxwKBbpnZld0KWkpHu0pLSc/OJisgrziGRm"
    "EY5mEQxlKsyQQmiNZwvXsYUZCCmUEH9+8Cfmtk2rRz705rrVVVVVsrq6+lsGoUEI0Evmzo189c7Dl7taD9FaWwq1z3Hsg2YgfDCo"
    "xSE3u6Sh+tmPEmj9z4yFykqMgfVTO42lBhj4P8byP8bgL45Ko6am5luLX0iD33x/RlHTnmNdlWUMkCEx2AzpvuFopHd2Xln3osKK"
    "jOKycgq6FJNTVEAsO49QJIdQJNNFGBrtaeVZQnm28BwltNJCIECAFv7VVa5HNKfIXfPVu8FXn3nk3t+8taG6aupUs7q21u04j7Rx"
    "6L9V3VDRWL+3ZuSkKWNLu/fFc2zaWhtobjxG49EGEi3tralE4piVStQn4o0Hk8n4fuV5h0wjfEBg7icQONS9T6/Ga+9/sVmrf24s"
    "VVVI5k9Ne8Np6u+N8//Gm/l/w4esAlldU+P9vur2rPrV88cGQpkjzAhDIlmh/pmx/J6lYwbkFxWUU9qjgtySfKIZ2URieYQj2R6G"
    "ocHRyrOFdh08RwmrrVlqpUECwt9QhJDpH5HeYvzFKA1D41qioLiUaCRjaEcoRu2JZ1iN1pqHvzPrqdlXXDe235QzkiQTBmiBv1yF"
    "67rSs90sL2VnOan2nslEM60tDbQ1NdLa0EJzYwutzceS8UR980M3TDloxZN7nJS3T3hmnQiIww72fjMYORSJhOvuev6rlupqpaBW"
    "pfMh/xr9KznR/xjDfxdDqEJWVwv10M0zL3LqNj807pSzu5V370NucQ6ZhflEs4sJBrOUEQx54IFnCc918SxXWu0tUqNB+AtfaBBI"
    "LYREGIDQAgFap22iMzvWJzheLXAdEcvOI5yR2V1rLYQQ6u+8ggodOLV3YXHpKb1HTPRSx44E0Tp9NIXvbwRSmF4oHNLhaJjsohJd"
    "EjQ1QoISAldJ205FHLs1YidbSxOtraPjTe20NTTT1FTHsaaDtDY3JpNtiYZfXz3rqGfrQ0rG99mqbWcwkvnVz59ZvArUP01U/scY"
    "/oslwieiLR0L7Te3zB4ei5ovVd78Y7OworeD0hrl4LmW9DxPuKl24STbDY0WSE166SGkRKJRQoEAIYT214vwLaNjyYuOd/TXUseK"
    "8o+jcVxXhqJZRKOZXR+58ex84FjaKPSgTZsEQHtDfZ+Bw4YHDTPgOsmElNJIG5c8blga4XmO0K4GJ4VOghbaN1ItEYb0gsEwkWhM"
    "5xZ11YiQb8VS46mUdOxU2Es55W48VZ5si49ojx+lseUgaxYt0PddMqmq6vUl99/zC+/vE3xRVVUlNm3aJObOrVH/nfMN+V89IZ5b"
    "WWlUgRRC6OrqaiVAV1ZiAHQgRK0Nh74z+dTZZmHP/ql4Y52RamkyU+3tpms7EoUUUgpDSmEYBlIYJ4Q6Hduk0J0bvvAz3X+cb+lv"
    "J2Pav6+URyASVdFYdl6itaECYM6cORKgAxEKBIwBBUUlYJiq81j6Hx1fIIRACIk0JIbsOGcJGqGVErblSCuRMFLtzabV1mSmWhtN"
    "JxGXQikVDIW8zPxCt6RnL6f3iPH22FMutK/68a9Ur34D7/v5ORPPrK5Gza2sNDo2E0BXV1ermpoaTwj/2mr93zPX/C/nGTSImspK"
    "WUMNQuBBjQeSqsrJJZ5qzh86fdLeObc92V4FktpaBYJQOFqeX1KuSbQZhhFAItHpEId/GBf4Cy6962ulPPyE1PcYhkwnydqPlP7l"
    "0tAdOzkg0NojEAp7+UVFge3rl5cDawbW1PguptZPHkKBQO+ComLQ3glblPi2kZ1wV6Pp/ABC+uGYQKMlIu2dhBT49yXggdZCKw/H"
    "Swn/CAoPh1hOoTv13Evkri33XA58uHFgvejwqlIa3HXWoBHxVFug/4yZW2+889kWITRzKyuNjQMH6v9Oifd/GWOoqqqSgzZtEqKm"
    "xqOmxgPB8z+7uvDIwfWnBoIZc3ILKyaEswZmHt66+/DD3znlnh8/+8WLN4waGWDlKqUcpznZ1iIwAxoSfvzfGcycsKj+gVEopQhn"
    "ZoKh/fTSCOG0tqOU43sIfXzt/4vfJ65kQ+q8wiIikVhXpKEfEMIVWnO/wDWNAJGMzD5Z+YXgOR0puW9tGt8VCf+gWmkCoRAYEieV"
    "7PBSaehKiw4D9k82/Tot0kGA9h+SPtwlBAgZQNm2iOXkiMzszDKAaUxjenW1eva7Fw1obW16tqxPvwkyJOWB3ZsO3HXegL9Go/lP"
    "znm55nAnhDuw6r+FUZj/FbzAnJqazouttY48fOOZU5PxhgvbE3VnjZl2evGAERPI79KLUDTTazl6sPvbz/zuhYeunrznp39dsAjA"
    "teytDYcP0ssw0Z0L7MTd99ur11+H/s4eysgQG79aoJe89gZ2PEm/CRM46fKLMYKmVspJVweOv9J3BsfXM4BWWuC5RmZ+oSZp/fjR"
    "CydWWl4qpFDakFJ6SgSUq/pHc/KV49gGWtDpcIRvkGiF1gIjFOLInv14tkNJ3x4ox0Z8K6QSaXcltX8MeTzk6rBeoU/4nCANk3hz"
    "I7adTCINjm6q1l/NnZux8tPn3jj3mpsG9ho1yVXaobXhcPmmFV/9fMX8BTfcd+nk1wtKuz1zyyOvbIBqqkBuqqwUfw9f/48x/Adr"
    "H3MrKyVApxeQJg/ePmuA1Xis8pGbzri0a48+/QaPvZSK/kPJyi9ycF1sKyWteIvI7dLDmnXRdaG/PXLfL6Q0ZinlEQwFdx49cgg8"
    "z1+mJ0Lw8kTbO76ilPKIZGaz7M0PeOLa29HawzBNFr/xCVuWrOKmvzzi77g6vWO7Ci3QSCE6yshC+JGLlBI8T+QWFGvtqm5NTUe7"
    "ucJDCRe0JJ5I0mfUSKKZ2Up7Xnq31yAkWmvCmRkQDICrwIAXf3g3qbYUd897UygvhdDHP4wQApSPdnmui5QSwzDQntcBe3079NKA"
    "YepEyzFc264TCObU4P0y/Pgl4yafMrDXxBlW4tjhgBSIjMw8b+LZV6ihk84q2rFqxe3fLPriO/dfOuYVERRP/PyFb1ZRU0MVyEGV"
    "lWLOf0Gj+E9jDB1h0JyaGm9OOgx6709V0Q3LvjwvEAxelZ2Zc9KgKTMjvQeNpai8l4tpaCfZLpOtzQYIpBAY0iDV1BAo7d7X69qn"
    "37RfX2+M/OkzX67OyMjZ03i0XjnJlOEvNAU+bHTC+j8xxkFLaYhUPMkHjz6tjYBJOCsHlCaWHWTJOx8z/uKzxejZs0g2t+hQNAMZ"
    "jYBW2O3tWnluh2/wAxMhUMojIyubYCzmWYkWFTBM7aGxPE9qAXklZTIQiJBKtXeGPlpDKBpj45dL2LhgEVnFhQw9ZTJNR+oo690L"
    "M2hoISIY4ZB/7p4QeBrXcpBhQ/z1hluRZkBf84ffYbe1Ik15PPvvAAm0ACFpb2nEttt3aOWye/fu8OtVV94yaPx0TbLdMKT0cyfP"
    "FcmWZiMUCnrDZ5zp9R19UmjP5mXXLvnigyvvucj5yHDFo1VvrKqlpgaAuZWVxpyaGvVfBa41/zN4gRpqqK6u9tJhkPmbG0+ebLUk"
    "zt27bs0ZI8ZN7t1/1HiKegzU0cxsW6VS0kq0SQ2dBqA7N7p0eB6OeMMmTAnufXHDdSBuLSot39nSfOywFW/tEo5EPeV6oiNU6EhE"
    "hRAopVHaBQGBUJTGA0dpPdpAIBxCOQ5CC7ShkVJwYMsORp93BoFIRDTuP8SaT77UoViIEbNPJxyLaM+2O0IogdB4rkskI4twRqbY"
    "vf2QgSnRwiFpO0gtKCipAMNIxy1+aBTJyGTdpwv57ZzrcJWNci1ufPYx4q1xygcN4O3qR9m8aCndhg2koKKM/IpynVVYKnJLigjl"
    "xthQu5iK/n2FEc3QkWAAZaewkwmQsiN98C+ZQjQ3HkV51h4N4pe/uHxm/0HDhpf07OOmkm1SdiYmwvcySolUa6MZMAJq4LiTvV7D"
    "x5u7138ze8W8z2bfVxn6UEv11D2vLvlICOH9VzIK8z+HF5D8qer6ro17tl70m5unXV7SrdfQEaOn0m3gKLIKihy0g5VKymRToymF"
    "RErhf5c6HaaLNNanBVIKnGTc6D5guM4rKqp889HvPuCVT6yPf/zUtmRLQ5eMzGxluZ5xolPosKNQLAMiBtgWqbhNJCeHUCxKorUR"
    "IxQApTENidCanJIiMEyO7NrNo+ffwLHd+4XSth765nvc9uJTmIEAeAqED1sp5RKOxojl5bNq3zE8IZHSxfYUPQszKCwp+zZopBUE"
    "TFa8+ymu65JVlE8oEiS7qID6ffvJ79aNJa+8y5rahWz6+hvQCikNgoEwwUiEyx69F9ty6Tp8KGveepdDW7Yy/PSZlPTvhZVIfBsy"
    "cD3Z3NRIW3PdVgH6waB506hpp4HkhARLdCYZ2g/9hFaeSLU1CyT0H3OS03fEZHlg08YzVyz48Mzf3DB5+a+uPemPP3t+4etCCNv/"
    "3qea995b6/1nrVX8f1Zn6KgJAKK6ulrNqanxtP4mUDVn1BnVF016UbW3r50w6/TfXHr7XUMvueMeb8i0M+xoRpabams2Uu1xQygt"
    "pOHDQB0FX//s/+V19RxLZOUXun2HDC/ctn7Z2XPmzPFsO7k+3tIApqn1v0iYBcFojO1LVvLJb//AhtqFGKZJZn4Oky4+j9bmJtxU"
    "Cu0qWg4focfgvgyfNRU8h4Uvvkndrn1kdykmp0sZa79cwJqP5xHMyEQr1ZmfaK0xzACFZSVkRkyCAYNQ0CBoSnIzY+TmF4DnnXBK"
    "BlgOrYfrCQYDCKFpb2qicf9hfvb+W2Tm53Nw6zZyCorJyM0hIy+PaE42wjR1KBzGTaQ4cuQYBd27Me/JP/Pnu+/nV6dfyv61WwhG"
    "QmitOsMlx7FE87EG3X/YSbEXfn3NsLKu3WeW9xumUvF2Q4hvAwudoV/6vvT9hki2tRp2sl10HTTUueDmn7qX3v6LsYNHjX7hkRtP"
    "/uahK6bepPfti1RX17pCoOdWVhq6s8L+f5dnEJWVyM6agGHyy8tn9LesI+c9cvsPLx48bsLQoaNn0KXvYGJ5Obayk9KyktJNWKYh"
    "DD/57CA4CH/haq3RHiDFcVd/wg4mBeC6ov+ok/SqxbXXPXPzbLlv7/YZRw4e0N2HpwtyHWQHpYhkZzH/+bn89bs/R4kkDg6XP1DF"
    "mbffwhm3XQ/CY8ELr4CWDJ56EhdU/UBEMiLgOaTaEhiGoVEKKQFpkEym/JDnRIPTfkKcW1BKJGgQT3hpmBOyszPIysvHU57P4dYg"
    "DQMrHqfh0GGElniWg2EYvHX/w/QcNYZD23dj2xZGQKI9rxMskhI85ZJTXMS5t95Aaa9ufHzgAPkFJTTV1bP203l0Gz8Uqz2BlBop"
    "TRzbormuTtft3flBJDer/ZzrvmeaoZB240n/fER699Har3iLtCtO/0EIgfTDLax4q6G1oqznALe87xB9ZNeOIRsXfvXUb35x7e0/"
    "O3foH2dddc2r08/7fjNCUDV1qnnv/PmeDwX/32EMuqYG7/PP/5S95rXXzpc6fGlmUcHkIeNPD/UaMobCkh4uwtROMiGTzY2mkAJD"
    "SDAkQguU9lBKIQyfCIcS2gwGMUyJ0gjlecK1UvpbOxgCK5WQJV1766LS7mP3r1gx1k04HN6/R3VyfvyKGdI0aW9q58M//BkZNIjl"
    "5BOPt/Hpn17Uk+dcRCQjg3N+8X3O/P7VHN13iFhmLlk5uWCA53iMu+BMFr74Ni2HjuBik9+zQgyZORk30e6vTPHtzTQzr4BAwEBr"
    "F9BINPkFOSKanYNSXifEIwyT5rp6mo7Uk1WQhxExiTcfE3ZbKys++lAHRBQzFEAaYJgSGTAQhoEZMkm2xfUHjz7BpEsu5KPfP8+x"
    "g4eJZGYSCJhkFRRA+m20BsMwSMVbSba00NbUHC3o2T3ad8QYZaeSCGmAUOl6i8YMBpGGxE4l0DpNWdEaLSEQjYICN24hpMRJJaSn"
    "tCgq7+6VXHWLGjrl1IHfLPjwyZVffPLT+y4f99TgcdOfO//2BxuqhfiHjOL/bsaQZiTo0ANXj79z3Xs1Vw8ZO7HbgBFTKerZV4cz"
    "w45rJUUy3i6FBikNPznrZD0IMCShUAjCIdxkAtdyMIMhGg8dpubuX2Ilk1TefyelfXviJFPIEwxCa4UZCDBw7Ene1sVfK4QUrfX1"
    "0nWcdHXZXxBSCFzbwbNsggED5TmEggGUbWMlU2QVFdC67yAf/eFJ1s9bQrIxQX5JMVOvrWTcZRfQb/J4fvLuX1nxzocEYyFOueky"
    "8svLiTe3YprBdILekah65BYUkZkRRTSl0AoMoSgsLtKhaEx4SqXPXWMEDFqONtBQf4QrH7yHadddwsHNG2ipr6P5cAONe+s4tv8w"
    "jYcO0Vx/hERLC1ZbG7blIjDYULuYVbULCJshotlZaE9hBAwKu5aD6yGlX5AzDIN48zFSiTiBSMgbffKpRDNyRLKtDcPwa9laa4Kx"
    "GM1HjpFsa6NL/x7gaTzXNyalHfat34xpBinv199P0hHCMCSOlZQ6mZSFZRXu6Vffrscc2tNtw9J5D66qXXhrVeXE5wZNnfnMnNuq"
    "j/xnYM3+HzOGKhD3aq3vu3zacxNOOe2yUTNnk1dY7uCCnYrLZHOTIaRASoMO7F+fEMNrLfBsxdF9e9m2bBmDpk8mt6QYMxxm3tMv"
    "8PWbHwOaQEaU2158SjiJZGdKjdAIAVYqSZ+hY0RhRbmxa/M2jh2rx04mCQSCPmqEwHMdcorzGXPWqbz/+KOEImFakylOvfJU8rt3"
    "o63hKL+/9GY2Ll5CLDeXACHijdv1c7f+TGxZsZqrf/cAPYYPINXexuGdu9i2aIUeMDVATmkpqdY4acoQAoFyXbLyCsjNyUHsP4bW"
    "EJCQV1SMEQppNx4HKcDzPVbToTo8PIp7dRPR3Az6jB0OoRwgBDiQTGDZKRKtLbQePUrrkXoa9x2ibuc+ju0/ROOReprrjtB+rBHP"
    "tgnHouSUFYPj+hTCdAEy1dzA7rpGyrqXiOHjp+JYVufGopUiEIuxY9kqnrjqe8TbmukzfiTn/vg2svMLUAq99vN5vPXAb9EiwKW/"
    "uocZ111CsrUJafjfpWEYOHZKeql2cvML3WkXXquHTTy9YtPShdWrFs+7+ZdXT/nh3X9d+EpVlf5XuwD/yxpDZWWlUV1T46nzJ47p"
    "ObD/ZTMvuclx3ZRItjQbEj/cMQzz23ybE4g32vMIxzJ5/Z4HWfi312g6Vkf/yeP5Uc1fMMNRYYZDCBQeCoVGKe0nq9IHiTqyB891"
    "yM3Lp/+4MXxYuwRxIAOrvYVgQYnQjocQQgspcRLtnPeLO4jlR9m9fi3dR/bjtBu/gwxIPnzkKTYvWUFueSnKVeBJAoEQgcyo/uL5"
    "FynuWUGvESN59PzLMY0QSE1hz65c/fsHGTB9CqmWJp86JEB5LrGMLAoLcpFoPC0IB02yC4s6C2yioyAoDep37cU0QuQWl4CCtZ9/"
    "xfbl6yjt25/ew0eSXZKP69lkFeaRW1EGliUwTDDD4FnY8YSONzXjpJI8f+udHNqyk+ziQlwnXTlXGjyXY3VHiCcTjDppMjmFZSTb"
    "En6oigaFMMwAHz/+Z+r27dXdB/dnzcfzGHnqDJa98SE7120hEW/hlicfpuFgHe8/9icx49qLO+oYmvRHEgIhDQPXtgwrmSQrJ8+b"
    "dMEV3qDxk0ve/fMjLz944yn2ndXz3phbeaHx/1fB7v8ImlSZ/p2KN/fs2W+gRkisRFzKjrg/HTwowFPKpxt0hBMdrFDtMerMWdjJ"
    "JNl5uRzYtJm2o8eEsh1O+c6VTLziQkadczoX/uJHyHCISE6OH4loT3QcXwqJ5ykGj51G1y7FNDU009pQh2madDRaCgSepzBDJrPv"
    "+Qmn3nIdWfmF7Fu7gbb9B1nx9kdk5uegXDfNFdL+ObseWUVFvPnrx4nlZzH5okoC4QhZpSU0Hq7jD1fewv61GwjGYr6hCvC0RyAS"
    "o6C4ECk1SkNGJEBuYXHnRtAJkylF3fZdZGXnkFNYAAGTb977nJfvf5Q/XnGb2Ld2I+HcbF740d386vQ5/PW2n9J8pJH2+ka2L6il"
    "btsO3ERCxDIyRFHP7iTbk2SXFIlodiae63VuPbaT4vCBvVSU5jNu2mkoVyF80p9QSotgJELd9r2s+2oRg04aL6q+fFv8fvPXIqdL"
    "GWsXLUJrRSQjxuqP57Hxq0WEwyFaD9djBExcx0Wn3U/ndi8khhHAcxyZajhq5pRV2NMvuFK7qeQdWiuRrkf894NWw7FoY0N9ncBT"
    "Qoh0QekEpr8RCBLJziKcnYUwAniewnNdPKWw4nF6jhrCiLNm0tTYyNDpk0ROl1KcRJKswgJufP4xBkwey5v3PsSzV9zMqnc/JxCJ"
    "YkbCKOV1ehvXSlHWsy9jxo7Bs22OHj4IhtHBUPLjc8PAtV3+eOE1/OrUS3j8xp+y5JV3OLBpO80Hj2AGgumeAZ02VIVO4/p2IsXC"
    "F+Yy/eZrUUrh2DbhzAwSre28/cCjdHJItR9yGKEQxV0rCAUkSmkyY2HyC4tBecerw1KA61C/ex85xQXE8rI1qYRua2ohQxhkZEQp"
    "69dL2I1NbPvqa9bPX8KK9z4nkp2rWxqa9WNzvqPvnXaOfu/hP+pgRoyGg0fE0V17RUmv7shgQKiO91IKJ5WksW4/Q0aNpqLPQKxk"
    "UkghfexIay1jUVZ++BmNzUeZekUlkdws8itK6T16KGffdqPIKciFRJKV737CvjUbaT5wWP/qzEt0e3ObjhXkE87IRHegRR31oPRd"
    "wzRRyaTMyM4jEApm/mOi2H91zzB3rgIYOfvyFbu2bjx47NA+IxAMaa09QKGVIhiOsnflah6YeR6LX3sTK5UikpNNND+XaF42odws"
    "rGSKMeeezq0v/Ykb//o4MmCilNKGafDKD+/hxR/dw5oPv2Dp3A956qo7ePKyW3TjoXodyclBKbcz5jWDIUacNI3MiEndgX3f4uYo"
    "pQnEYrx936MsfvNtsgrzyDIM+pw0gQObt+E5brp5R3Ji805HQhzNyWTlR1+SW1ZKxaABWO1JXNcjmpXJpkXL2LN6A6FI2jvgV6/z"
    "i0uJhUOgICsri6z8AjzP7ahsIaRBsrWNo/v2U1jRhVAsih1P8Z0/PcxDG+fzvTf/TG55CYm2dtFz/EjK+/ai/4SRhHLy2b9xKw11"
    "ddTXH/U/YShGa/0x2hubKOnVAwzpQxRa49o2VipOvL2V4VNnIoUhhOqszAvDMITTHmfJ629TUlzG8DNOATOAFY8TzcoUV/7hYe75"
    "8l1x1e8eYMiMSQgJLU11GIEAG75YyBOX3sSmhUsxQ2E/D/Rp8B1UYe0pDxmO6sN7tou2psb1Qpoq3Yui/9vkDEIIPbey0jjvmh80"
    "P3jtyXO3r1z8/QnnXuK5dsrsKGQ6VoqCbuUU9+zKc7f8lMLy7gyYOJqKoX0wAoIDG3eyY8k69qxbzxk/uYHPDu1n3OyzyenSQ+z8"
    "eqX+6m9zyS4u9OsKMgQOfP3u++zdtInrnnqQ/tMmYTW1IqTAsVL0HjqKrl3LaTh0CM91/KKW0oQiEQ5t2saiV94gO78Qz1NoBJlF"
    "+exbtQWk7z06GKQdCb5Ic/SCoRCNh45Qv2cP/SdPYPuqNYQywkjDINWeZMfy1XQfMwLd3gKGQGlFTl4B0UgY0ZQiNz+faGa2UMpN"
    "H1MLIxjUDXV1NNfVM/zU6RAJ03bkAAteeZ2CLuX0HDacYDiMNOC2l58USrnaak1gtzTQbWh/rn3sAfZv3srAaZMArRsPHRa2Z1Pc"
    "szugtRACrRTKdTh68ACBSJT+oyZgJZMI6e+PylOEs7PYVLuU7StXc+bN3yGanc28R59iyjVzCMaibJ+/kPKB/Zh+3RVi4mUX6F0r"
    "17HwpTcYM/t0Dm7dwoLX32Fpzfuc9f1buPj+u7TV1trRMZj22xJsW36z4DO0cv6M9qikkhpq/msn0FprUVMzR258ol5sKirSlQMH"
    "atDklZU9v2nNqltGnnxmwDADWrtKCCF94lphId/585Mc2TGbHV9voGHvIdRLNhoXLQyiGdlIwyTZ3MzK9z/RVkuS8x74rVj7eS2O"
    "bRHIDIAHVlucETOmkVt2Fh//6Wl+N+cabnzm9wyfNRMnmcCzLQqLy+g3ciz7t27GSiYJBAJpQluIHUuWEW9pIZKfjfYU0gxgmgHa"
    "mpsRUqZL3nQ26wjR0fJmIKS/0+5ZuZbeo4djpotTrp3CSrSye/kKuOWazlwJ5ZKdl08sFkYKTX5BAeFoDOX56JbWYAYDNNcdw4q3"
    "U9y7K8gg9XuP8OY9D2sHmHL+eeLWN19j6Qt/Zt4Tz1DWpwdTrrqMPpMmo7Vi1LlnMuM7V6JSDngWjfsOAVDYrULjeQgpsJMphJSs"
    "X7mUnoOGk5GTR7K5CUOesCRMk+Vvf6gVgrEXnEWqLS5e+mk18ZZj7F2/jY21y/n10k+J5GYRCoUYMGksAyaNxXM9Bs2YRMXgAeLx"
    "y27TC2ve5Zwf3EIgEsRTDgIfLAjFcrwDO9YF9mxZv/iBNzYsMO+9VzJoE3OpNGqoYWD9VHHv/P/v6Bv/r4RJVVVVUgih58yp8apr"
    "a92amhrvXqqpmjrVvPGXL208Wn/k/f3bN8tgOKZ0mm4skMJNWsJqa6NsYG+U8ohmZ5JZVEhGQQGxvByE0GTmZVM+sDdN+w6iPEX9"
    "lk3s+no1KA/PtjGkgWe7NNfVc8lj9/G9N59HuS4v/fQBXNv18XR8WsTgiSfT3tZMa2MDhhGg41zqd+093ueQ5jhppUGpNAziQ8CG"
    "aWAEDIyA6R/X83BScWwrwcavFlDQrbwThckuzmfAlHGUDOwNloWQfmum9jyycnPJyc4kaAhy8wuQgRAo3VnlxTTF0T37UCiKupUD"
    "ipb6eiLZWQgERT17AEF2Ll/N+uWr+fLlt0TD/oPCjGaIV39UzQ8HTebuiWfQcOAIGAGO7Nijw8GYzikrBtcDpVCOTUvTUXFo324x"
    "cspM4SZTQgrZWYwLBEO0HjzCqvc/E/1HDqPr4L5kFOcx9fpL+et9v8PTgrs/fRuk4LkbvqdXfPgJifY2kCZO0sUwA6KwewUpz6X7"
    "iCFEcrLxXLezxqM1IKVYveAznJT1eyGEYtMmc84cn69WU4NXXevTN9Ltp//5PUNlZaVRXV3tvfzrm3MP7d5+rucm8zGCS+68r3ZJ"
    "1YVFptaKlBX/3coFn57be/AImc5A07GxRDsOVz1aTddBQ3jtrodxrCRCukSyM7Fa40y74kJ2LVpJNBpFuPDQSWfoxsZGxs85jYbD"
    "B9iwYCVl3fvRpX9fUk0NjJx9Kufd/V2yC7tghgI4cRspJZaVoHv/wUSz8jmyezsl3XuiEx2oV8qnMgiBMPy6h1KKWHYm2nXxbAcn"
    "lUR5TtqQg5jBCJHcDPJLsugzYQR9x40mt2uZuP2tv5BTXkBWcY6OZWdjGiGsuOUbgtA+vJqVRW5eLpGgQW5RMYZhaodUZ36JEBzZ"
    "vA1DSgq7VeC2NTF85kk8vHE+9bv3kxnL1V6yUZT268WQ8SNpb2qhy4B+OM3H2L95q2iNt+vosUYiWVngOBzeuYfs4nwyC3NwXQ/P"
    "cTGkZMuaFRR0qaCoa09Sza1I6TNVlPYwMiKsf/N96g7u58w7riNaXCrctkZm3Xol4y4+l4EnTQQl2bVsJSs+mCc+/usruqJ/L06+"
    "/DIxsfJ88gu7s/DFN2iLt4pJF5+rCZhopRGG7/2CkZg6um+nuWHl8s39Js76aK7Z35hTU2M/+ePL+jUe2X9jJCvWJZVq3Txgypl/"
    "OP+quxqqpmJW1+L+pzQGrRFz5iBrat7wfnntKSfHG5ueObXyyp6Zubks+/JjHrxe3nXn82/9+k83jArc8KclS3959cSlh/ZsnVzW"
    "Y4CTSiRMH7EQWmuNk7KYce0lotfosWz/ernOKMhk86KFrHj7c/qcNJ6/fv9nzP7B9WTld+FIwwGGT5/B1U//hi2LFzPw5C0UlPXg"
    "8OYdbF28jAGnTuLU267HECGstoSPzCBQnkskO48+w0eza+Nqhk8/nY62yHAsCK6Dl0ziOR7NdpzmujqyuhSiDE1WSRG5Rbnkdyum"
    "sEdXirr1I7+iGzldCojlRwlnRDBkELvNZtgpU/C0hetYuCkHT3sYwkyvcYlSCiMQIjsvh4xYkMLSCo43VKexZc+jbtc+MnJzySoo"
    "xDQMFr75Pq0N9XQdMpiK3gNw461MvbKSU2++DKs9iXbRViIpZv/sdvZt3kg0mkk0O5tUPEXD3gMUVZQQzojiJCxcO4VrWezYtJbp"
    "F1yO6tyxfS8qpMCzbRa98iYZsSxGnXum2Ln0a6JZYboMHklJop2Wg3WEQmHK+/fm4ZXzWPX5F3z551d49uf3UT6gD9ldilg29116"
    "du/G0CkTcdraO0NKpRUyHFZrFn+Bk7IWXPnj38VB8cit5wyxWpu+PO/q2wryy7uyd9tyvnz3jYse/s5ZV/742Q9XVE3V/0cNwvzf"
    "D4uqFUjvrguG3VTRvdcfZl9+o5ldWmahPbr0Gmi89sSDv6q+TO+48Zkva254BpGoTPx59aIvJpf1GdJZbNbozk5EOxGn++De9Bwx"
    "QBAO0H14X7oPHa5judmcfMNljDrnVEoHjyCrpAt9xg0hEA7RbdgwPnnkBT5f8wpNTfUMWT2BYWefTLyxCUO4SGn6IZLUSC1Qts3g"
    "cVP46vW/Yre1pUMoTWZRDsFQgKLuXcntUkxmWTGF3SvoP2Ui/WdMoaCsjGhWlGDEAEOCZ4ALnmPhqJRvdDqFIYPaam8DqXyqg5QI"
    "bXyr10J5ikAgQH5RIUW5WeQWlZwABaOlkAI7ReO+QyK/vJRwdpZWnseiP9ewbtnXZGRl8OuF88guLuCRi64BNIOmTtRn3nYzgYDS"
    "M665GAzA9nAtaG9uo/VwHb1GTsUImsSbWhBKc2DnVjIyM3WvwcOEnUwi0xRgpRXhWJg9G7aKjYuWMnzWKRT0HcpT02eSU1rASZdf"
    "wrM3fo9Z11/DuVV3Q6IJM2ww7Yo5YuIFs9m9fpvuPXIYaz75XOzes0df/OPbyCguInW0EWkKlAbDDNBWf9hc/tXnXqKu4cqHLh53"
    "bOBpZz61et5HL112690FPcdOTnnxJqO49yVeSXm//u/9+cmvfnXV1BvvemHhy1V48l5fZ0f//54zzPXDIrVv377IvZeNfmrirLOe"
    "uujWO2VGbr6bbG4MJFuaAgLBOVff5uXlZz/35O2zRwiEnn7WRe9vWrPicNORg2YgENZo1dmDgOjoQ0iQONaIl2jnwIZt+u37H+HZ"
    "m37Il8+9zOOX3c7Wzxcx/Pzz/DK/8tixbA3rv1qKEQhQUFzK/o2b2LL4a2IlxccXYAfELcC2knTrMxAjEmX/9g2EwmGs1jZGn382"
    "v1j6ET/55FXueP1Zrn/6YXqPGUZmfhY9BvUlmhFB2Tbx5jYSDc2kmpqx2trxbBuhfH6ONKTvLmW6sCjkCRDuCdC5Vmg0OTn5FOdn"
    "kZGT6xtDR3uyYdDe3EbDgcOU9O6JGQ6J1mPHhEITDoTIKS4iv7yE+t179I75X7Puy0Vsnv+1D18ql2RTE4mjTSSbE5hmkNa6Otqa"
    "Gijt1xOExE0lAcHWtd8wYMwkTNNE++/vt4goIBxh1fufYts2ky89H5THKddcTO2rb/H4Zdcx6tSZesqVV7B87ut8/NTztDa2+LQL"
    "M0DvwQOFETDF4tfe1dFQmHEXngUpy/fQaRQrGI6x5usFHNm9WziOE2k+Vn/3ordeWjn9vEuG9hw2xkvWHww6VsJIHKsLdu03xLns"
    "B/dFS7t0fenn5w362f1mQAkh/o/kEf9LB6yaOtWcU1PjPf7Dy3vM/eW1X5x92fU3nXnFTY5WLq6dktIwMcwArpOSWTl5uvI7389y"
    "tZr70e9/Vjjz6rsbPNt6e+faZcKMRjzVKb5zvHVeCIE0TAwEi199h9aGJjwPhBmmYf9RHr/oRj594EGCkShGKEqiqZlgKORHGZ6H"
    "nUjyx6tuYcsXiwjnF6A8Ly2IkqaAa4UZDtN90DA2rlyMlALPccjMz6W0d3cCwQBOIkXyaCNOIgWOh5NMguchpcQ0TaRpYobCCEN2"
    "0sq1PnGT0vyLBoAT/qSVB55HLDOXUChMZlYOyvN8JAmFEQjoloZG2hqbyCrMR0ZyyCku4kfv/UXct/R9rn/yYYQ0UFoz4txT6TVy"
    "CH3GjxJSCqG0EtKQGKbpc4sCBg3792NpRXGvXuDYCKU4dvgQTY0N9B05DiuRQAqpO0I1Mxgg2dTE12+8Q89+Axhy8mTttdfrgSef"
    "pC+4+w79849r9HVPPkxeeYH+5t2PeepHv+DOMSfz7M0/Ydc3a9GGwdGtO9jw6Xwx9KTxovvgQViJeDpcBSlNUvE4qz7/iCAaM2B6"
    "8VTKHTL2pOKTTjvXs9tbhGGaCCExzQDJ9hYjKydPXfaj+90xU2f+qmrOyFe0PppZXV3dqe/0/6kxaBCVYFTXLnB/cclJU532xgUX"
    "XP+9CSNPPsdOtLcaWnsCITsb4aWUpBJtsrhHf+esy27uvX7dir9JISgsrfjL2mWLXbutxZQd7ZocVxjSoIORkK7fs1/vXr2BWE6m"
    "X59R2sfVgwHm3vcwf/rOD0i2Jijp0xvtOn5TjBAU9+pKsrWdxy+9ma3zlxEuKO4MQTroGW4yycCREziyfy/tTQ0Yhol2XLxkCqE0"
    "hiExAmZ6dxfH9VPTMX8gEKatvQVDBgiFM1DqhE9xoiTG3xmCX0NQeMrDdWxiGVlEMzIJh2Mo73ijjec4ZOXnkd+liMWvvsnb997P"
    "snc+pW7nPnKLi0X/iWOFDIXoMWEc333zdX698jMu+MX3QTkEwsFOjpPjeiA0dbv2ooG8ilLseBzTMNmy7hu69OlHZm6uUK7jd4Do"
    "dAiXEWH9FwvYuWW7HnPe6YSzc0RbU4uIZkXFJQ/cT6/xI0g1HiN57ChXPHgP97z5AoOmT+az51/izQcfx8wqYvkHn9LU1siYyjMg"
    "GBBa+6GqUh6hSIwd61ewcuUa6uIehkR0HzBAnn3tbZ5rO0Kj0ki2EBohDGkK10lJtBKzb/ihPeuCOZc8eF3lZ688dGvZnJoar2rq"
    "1P/XygPGvyc/mF5byyZpql9dNeWWLhXdXrzo1p/mlfUZ4MSbG03TMAhHY0JrUMoTviaP35zipJKysFtfV7mpfmXmsYwfPTP/b6O6"
    "x8Z269G7X2FFL9e1k7JDsVog0B4EsrJY/emXLJn7FsFo5Hheqf3ur1BGhN1r1rHuk8/pd9JE2usaObhtB7ldiuk6qj97120mEIix"
    "/M1P6DFsIGVD+uEk4v6iRuK5LjkFhWxdtwzTMOnSvTeu6yJkWgyys7DWQaWRnaJd4PJSzW95ee4fWbNuCXk5RZQWlWM7CXxAwEB2"
    "gOJpw+gwCaUUnuvguEmE8ki0ttJ07CjDp83Ecx0fyUKi09Xrgr4VYnPtYla+9ynL3nyf+c+/yhfPvsCCv77Oqnc/YdNXtexetUw0"
    "7tlPorEV13K1MA0C0RChWAbBjCwIxpj35HPU79zFWd+7EUNokm0JVsz/lMnnVBKJxYT2FAKTDoVjMyyZe9/DHN6xhxv+8IjYvWId"
    "z99wB2MvnMknf/wTnz/xZyadey6BzAxhmpLyfj0Zd/4ZjD//HEacOp1gOMBrP7kXA80lv7wb0zBBaSGkT0sRwuCjF55i4dK1HI07"
    "dCnL4vIf3E1xRS/h91Ck+bInEDh9tUAPx0rJ7sPGOYWFBd2Wff7x2TOG91p2z7vzD0ydirl373+c7Wr+W/nBnOpqT2ttPHD1SY8P"
    "HTvhlpMrr1PhUMRNtjQbsaxMlFbsXb+RvPJuZOblkmxrQZod3VqCVGujMfnMSudo/f4f3Sm82szM3Kq1Sxee1WvIBF/hRKuOKlZH"
    "HyHbFi9Ld1V9O9xQngvSIJaTyYZV6xj85UIGTp7Iys+/QgQMRpw5i+3L1tC4p55gKIPfX3Yjd7z8OIOmjSfVHv/Wft1vxAS2rl7K"
    "kHFTfYQnDSuKjvftEI9I91oEw1G+Xv4+H38xl6xIAVu2reXB7T/gB7fey+CBI7CdFIYAhAlSo9NNMVoLtKcIBUJoUwiJg+fY2rIs"
    "ojk5mFLg+P7Uf39DkkokGDlzuu618H0aDhwTrUcaadh3gKP793J0zwEa9h0QG2sX0d7QqK1ECo3AlEGiuVGRWZJLTkmZLqrohdCK"
    "Ba+8zqBTJpGZn4nTmmTHurVk5hdS3rMPiXgLhjA621JD0TAHt2xl7byvGDJlPMW9umuBIRoOHuFHw05GBMKc/7Of0NrcKlZ/8jmD"
    "p08iv1sZnuNR3L0bocwMNnw+nx1r1jPrO5eRV1FBsrEJwzS1VopgJIN9W9axbOFi4q6ga57k1MpL6DVkjL9ufNbx8Y2oM+PSflOg"
    "lDrV3Gj2GzPVuTyrqO+bz/1+/oM3nHrLnc9+/rfKSs+YO5f/kBas+W/kB+4fq64quf+KCX87efacWePPuMjxLEsmE+0yEA5xaPsu"
    "XvhRFQEjwNAZU+kxeoTuPXksVktTOujxdYNcy5Knzbnaqz+098WMvMJZuzZv/Oro3h3T8yu6uZbtN/eghd9F1dTMnlVrMUNBH5dO"
    "r0wNGAGDeHMj0bwYNz56L1Muv4zfnHY5QSNINCPC+HNPp++40bx+18Os/Xg+ru3wl+/fzb1fvk0oFEZ5Cin9Tq0+Q0ez+quPOXZo"
    "P9lFJd8SDu74n9IQNIMcPXoQgaK1tQnDCKORhMMxUlZCv/r20+Ku7r8mYGYQCcdQjoflxtEm6Z1eEzTDrFw9n6Wr5lFR1pWTJ51J"
    "oq2VQDAMWqGUhzSM44tASJLtScLRDLoNLtDG8KDfRioR4OHZFom2duKNrbQcaaTpYD0N+/eJ+n27OLZvvz669wh7V23HsVMMO3kq"
    "l//mLjwriWPZbFq9jIlnnd/Z6de50SgFoQArP/iU9pYkM666CGJRkd+zglnf/w6Nhw9y3p3fFzkVfVn/3gf84ebvk5Odw8gzZzD1"
    "sovoNmwooYwYS9/4AFd7jLlwNigvrd7nyyNLKVn66bts2V1HVkgya9Z0pp17KVaiXaS1Yk8INTtbvE5QNfc3plRLs9GlVz/3ih/c"
    "F3nn+cf+eu/F48rvfX35L4VwxT8aBPMfMoaOYRoPXDV1vF135IWLbv5Jn76jJ1nJ5oaAaQYxDBNpmCx57S2a9h8mHIky8YqLWfri"
    "q9Tv3MbEyy/AtV2f7iAlrmOJcCRDXXjdbTkv/+E3zyqt3lnz9cKpM3v2QVvKXzRKE4qE2LdhC/W7D/jGoJUfevjNxbTUH2XkGVOY"
    "86s76TKwP6ljzb6gtvIo6VmBchXRSAY3v/gkf7n2u8x7+XX69hxOOBbFsx0/nk73OWTl5lPSoxfb1y1nwmnnk7IsX/kC4S9QFEEz"
    "zI5d63n86btxvCS5eYUEA2FSKQtcSSAQFnsO7Gb7rg307T6MuR89waC+Y+nbdxApxw/NAiLM4UO7efalh2hNNmtvhceWnRsol0V0"
    "7d4fx7HAc3yP0hmi6U50yk0mcFUSrUFp7UvhGz7jM7+shJKefcA0QVka0wPXxUm4JJtSWIkEOWV5uE47icZGDu7dgxaCPsNGk0r6"
    "oV06Y+uE3A5s3Y4BbJy3kJ7DxuriXl3FOT//EZAi1dBK4tBu+o4fxX2ffkDtK6/xzVvvMf+Vt3h46acYpmTVOx/Re/gw+owegd2e"
    "QEo/hwmEItTt28HCefNJOjBpdG/OueEHSCOA6yTTTV7pxq7jnS1pddu0XpufVmlpGKQSbTIrN1dd+v179KcvP/XAPV6qpPr1ld8X"
    "QrhpaRrvP5RAdyhYVNcucH9+/thzS0orPr/yB/f26Ttqkp1sbQxEMjNIJW2COTmsee9jNn72FWPPO52dq1frVe9+rE/58Y+QAZP3"
    "H3saK5EiHMvA8/xdz0omZEFpT/eUcy4ZFggGLj64a2tbW0OdaZoB/2MrBeEIO1ZtINHqC14JwAyYuLZLvLGZ8+/+nhhx7izRduyo"
    "cOJJ4bpeGgRxKe7VFRkM4dkOqq2NZFMzrmszoXI2ZjSC53md+42UAuU69Bk+nq3r12Ank2jPRSuvExnSnkIaBqvW1tLYUIfnavbt"
    "3432fGqH8jSep7Ash8071/PGR8/zwhtP8cfn7+fAoZ1IrbGtBMq1OVK/H8ezyMzMIjOWzeZtm6ldt4ii8i44qXZcx0IrjfI8lPLQ"
    "WnFcJE+ihS8BGY3EtBRoz7V0QAgtHMWhHZup37EJp7mFRN0xUk2tKNshmhkhr7QQJxkn3tSIEJLNq5YxYPQEApEIWnkIIU9sLkQ5"
    "FhMqZ5NTksunL7zOz8edyR8vu0Uv/tvLunHPPsKZmURzckDAwInDufn5R3nomy/4wSvPUTF8MCvf/4SGxnpOuuw8HcjK1Mp109QL"
    "hREMsmr+J2zZfZieZTmcf+3NFHfrg5XqMMp/icH5bHn/OivPQ3sarbXQaCGlgetYQgohZt/wA+e0i6647dfXT/nszT89UDqnpsar"
    "qvpfT6yN44kycvp0dM2Wrfq+i8fcPXjMpKcvuOGHwaz8AjcVbzcjGTG+fPYVPn7yL3z55PM0bNlGa8NReo4exr5Vm9m7ZhNjz5lB"
    "r6lTMAzB/BdeJ7u4mPyKcpxUCmmAnUqJLr0GenYiWbRi3odmaY++dOnVF8dOIoSBGY7xxdMvcmDTRgLRIK5l097QRk5BIVc/ej9S"
    "eOLVX1Qz45rLySkqxrNdFr3yNq31dcy44VK69OuH9iDe2sZ7v32SrJxcLrrvJ3SIJPlJtH+RXc8lt6iE1Yu/orColKy8vHTTi78j"
    "K+0SMAwOHNzDhs3fEAyGUB27MxKlwHN90LY91cqBg3sJGhm0trcQDZsM6jcM20oSC2cSCUZZsnIe8WQc19UEjBAJxyKWGWVgn8F+"
    "+6ntEQxGfYPASzeJaTzPw5QGTirF9h2riUQjRKMZ7DuwjedeeIh3PnyReQveJS8vl17dB+C6HlL4cpLKtfHsJI6doqXhGJu+WcaM"
    "C6/ClKKz0d9X6fb5V65tU9q/J6PPOYPCsh4km9tZ8+V8Fr7zPivf/UTU79lHJDOD/IoKZDiE095OIBqh68D+oOHVu36J1dzC5Q/d"
    "QzgURnuu38puBok3HRMv/PExcfhIA1defTEnz7mqA9btyJLTA1+OJwxaa4LRCIGMGGYkjBkMoJXf84IUQkohtFa4liV7DBvr5Gbn"
    "9F768Vtnnzlh1Fd3/fbjuqqpU83avXvV/5IxaBDTa9Fz5z4SGZ2T/NvkWed+d9YlN3pCaOxUUkaysvjsqT/z/PfvZvDY8WSUFbN5"
    "zTrOvOMGGvcfZseyNSRa22k5cJghp06msFs5pb16seC1dzECJgUVpSjP58M4tiV6DhypD+/eKXZuXMWo6TP9mFkGsBMW7//qdzQe"
    "OYDSiqyifKZfcTEzrr2SMeedzp9v+b4o7dONs354B1Z7EiEFi158k1RbK2d893oy8nKRZoCDO/by2iO/Z8bF5zHmkvOw2tvTvJsT"
    "BAOEJpyRTUvDUer2bafngKH4aIZGaX83c1yXvOx8VqxeRCIZxwwYWI7nyxspP7RTEhJWC5blIDyfih8IGIwaOh7P9Vi8fB77D+2m"
    "Pd7C4aOHAAPX8d3/3sO7OWnsZL5Zu5g/PPcgiXgrA/oOxXUtv+8jrY+aaG/hD8/ezwtv/JHc3Bwys3L45SPfY+/eXQgRIJ5op6Wt"
    "iUnjTkF5yudWafA8ByvZihSSdcsWEMstZNjkWdjJdj8M+xbe5asKurZFRl4uA6dNZmLlOQw5ZQqxzAj7Nm9j2byFLH2hRmxdvAK7"
    "PUlOSRGZ+bnIjCiH12/ktarfMPa8M5hy9SXYbe2+B9aeCGVmseSTd3n/rXeZNHEUV/7w50jD9M813dgnThiKodO0hGA4zN71W9j4"
    "5SL2rd1IvKmBWE42sdJitOuh0lqyArCTcdml7yC3onuvos0rl1ROGVyx5p535++oBGPTv7M/wqiqQk6rhbKqHxTUrfvqvTMvvvrs"
    "0bPm2HayXaKVkIaJlUywZ/0G+o0bzcd/eJqB40cx4tSTObxhA6ve/xTP0ZgBk0RLC6ahySopJL9Xb/qOHs77D/yOPhNHE4yEjne6"
    "aUH/0RNZWfsxeSWlFJd3w7FshDCoGNqfATMmMvWaizj99u+wY+laFrz4FtOuvoT2xmMsf+t9MfLMmWQXl+E5NgtfeBNhCk6743pM"
    "0/B5+JEoVmucSRefT05pgS/Ae/yqHxeHU4pwRiaraz+n94Ah6SYenf7xcBybrGgGXYq7sHztYhKphI8KKbBthYHA9jxkwJe10Z7f"
    "zRcOR5g28VRWrlvC0y/9ls3b19EabwMpcD0PZYMQJkk7QXZuBp98+Q6NTc3s3LOFwf2Gkpedh+OkfKUOM8ibH/yVr77+lHA4SjAc"
    "YMmKr9h3YA+RUDYdTZVdu3ZjwshpOO7xpibXSWEnk6QScZZ99RmTz7qEzMxstHI5viF3TGPsYKULtOvhxOOgNSU9uzL8rJOZeOGZ"
    "9B46CByPrQtXiCUffciKV97j4NZtoDS1f3mFfRs3cUHVjynt3cuvdEuBNANYiThv/On3CNflpp9VUVzREzuVwJDyhD7ftHZ5R5U6"
    "I8YXz7zAk1fewdr3v2D1B5+z/I0PWfHeRzTuO0C3wYOJZuf4LAABUkjhJOOyoKy712fwiMx92zZePL5fUfMf1+7/uuoeJWtr/22D"
    "MKZNm2pMr92rRnXlgXOuvP7iwVNnpxINxwLS8G1VaYEZDLJ7zVpOveM6GvYc4ss/v8jur1dTv3032fk5xFsTBEJh2ltaGTBjCscO"
    "HiFx7BibPvqCgm5d6TN5LK6V7CxiKc8jkplLKBpi/fJaBo+fimvZCCEp6t2NrsMHUdq7B7iKP91wF6V9ezH5ykryygvRQVN0GzSQ"
    "zLx8lKvEJ48/Rywvm1k3X43nOqA0gVCYseedQU5xPo6V9HcPLf+uSKyxHYusnFw2r1lBKGBSUNoFx0kBHq7roLXCdizKSrrSp3sf"
    "9uzfwdHGBr8moSUpyyVgSm25HlIaQng+2zUrO4cp42ZwtKGOleu+JiuWg2U7OJ7rw7jawLYU0oSjzQdobW0nHIhiuzZdy7rTs2sv"
    "LCuJISStLc28/M6fsV2fBt4ab+Zw/RGEDuDYHoYhSdhtXDT7KroUd8NxLD/W9jwcKwlas239Ktra2ph8+nm+tKT4O6rKcXlCvzwp"
    "tK+ZBLi2hZNMEo5F6TV6OOMvPIuRZ59KfmEpx/YfYOVXX4mva95h3/pNdB88gAvu/oFWjttZZAxlZLNq0Vcs/+htzrnqBkadfAbJ"
    "eCuGIU8oVHZgSLKTTRDIyeGjx55m79r15JSUIQOmJhCgvamVdV8uYu3nCxk8bbLIKswTnusKIYSv12QlZUZOnho0epJoOrTnzP5F"
    "qv6+PxxcUVlZaWzatOmfGoRRW7tXIQQXzBj16xnnXVGsbcefYeGzSn0l6FhU7Fm9hoy8PIafcRqr3voUz7ZQAqxUilg0Qkt9A9ld"
    "SugzbhimGcJOeYRjUSZcfh52In4CZCaQUuLZNvll5Syb9z5lFb3IyivCc5002zOBZ7sYMsCCF96g65D+jDp3FtJAjDhzFtGMDNyU"
    "RTAW04d37KR8UD+GnDIZ17L8eFkr3EQSrVxfekUfl6HXyu9fVsrF82xMwxCpeBv7tm+i14ChpJJxTMMgHIr62kCeg20lKC/txtiR"
    "U5Cm5sDhvWhP43g+kCMMjW0h0BJXuWRn5TJu2HhKCkpoi7eyZvN6nzQoIGUpUCZCgydcUnbC5wMpSSplM6DvIHp17U0qlSRoBtm1"
    "ZyefLvwYjQ892o6N9sCxNEJIbNfl/DMuZsaEM0im2o4LKHsediqFRLL0y48ZMm4SJeXdsK2Ur0iYFmLQWqd7OY5XN3WHkK3wvysp"
    "JVopnFQK5bjklpYwaOZUJl00m/7jxxEMBkR+eSmV9/1MF3ar8De2dA+I57q8+6dHyC8q4fybf+R3GaZhUyMtE+QpV2it0+8DgWiM"
    "DZ/No6RXD3YtW0fTgUMEIhGEIZDBABl5OTTsPSiO7d3LhIvOxbOdTrqHEBLPcQgEI7rX0JHsWLd8XN+Mtueff//rhNaI6up/Aq36"
    "0zC1chznqJNMilBOhvY8ixNLXghBTmkRR3ftZejskcy45Urm3nkf2UV52KkUiWPNDJ05nREXnM3KN9/i2K49RAtKOLf6TmQggDSN"
    "dKON2WkQCo9wZg69ho7mm4VfMPvqQdipBMIQ6YoomJEIfccOJ5afBcpDux7JhkakDCAMiWNbXPW7+/DQpBIJhDiuyO33u/t0Yb88"
    "fpwbpNG+MSiXhNVMr36D2bJ6OfGWZnJy8zhSf5DNOxfSq1tfyoor8DyXtZtW8+r7f8HVbpqiAaGgpC1lk5NliFTSQ6OQQpBIpnBd"
    "C60kladdQWFWFz6qfZ+mRCOGESARd8gMBrBcjaEkruMhTA+lNNFIFM+1/bxBxTh45ADxZIpwIIrCxQwIv04pJULCtPHTmDx6Ko6V"
    "8vMM7aJRaTUPqDu8n1QqRZ+Bw4i3NfsqhWlBAGH6CbRE+g1NvlWmG/el38mX7uYTxvFeDzeVxIknMU2TUWfOZNQZ0zUoPKWw4ymk"
    "YaCURyQrg3VLv+LIgT3c8sATBIMhkok2IhkxkCZWSzsyYBDJzdFoLazWOJ7rEcrIYsnLb+i2lhZx+4tP8Mkf/sLqT78g2dieHjds"
    "4LkOGYWFoNTx6UW6Q2FfYltJGcnJUf2HjyrctmbZcODLmjmV0h979q+FSUw1avfuVYOLA15GLHRh72HjlGMlDZGGuyQCYZgkk0ka"
    "9x+g64jBBAIBtONQt30XueVlnHLTNRT368P6Dz9n27JvGHvhbKzmOC9XP4DV1Eb/yeMJxqI4lnW8jVIItOeQW1TKsnkfMWDoaAJh"
    "XxC3Y8ySVpqRZ5xM30lj8Fz/tVKaQqRjTaE1nuv4sKjWaKU7dzp/13PRnoPyHB9ZcR2U5/o/roP2PFzXIhrN4Ejdft7+9DW2Hd7C"
    "wpVf8c7nb7B87RKU8hg9eDzvf/E2tSvmoVyPVNJGeQLP8xtUk5ar87KCtMc9TNMQjuswYfhoIuEIWkF+dhHlXcpJWs0ca2xAKaGV"
    "Qpim8BNy1w+7DCPI6dNOJzMaxXEdwoEIXy75gq27tgIBkFobUmBZmmDQEKGAQUNTA+99+RaRYIABvYf5NRClhG1ZGEKyesmXFHXp"
    "Qu9Bw7GS7f5UK6XT8K2fpCvH8Xsc7JR/ndMIv1a+eEMH1VGkyZX+6F+/cu2kkv7rbBvlOEhhdG54ZsDk7eceYcjE6YyaMZtEWwvB"
    "WJQ96zby/K138dlTL7B07ttsWbIEPI+y3n0IZWbQcviwwDR5/eE/ir2r1jHz1uuZdMlsug8fQHm/nvSdNFpMvqySCReeTSwnMw0a"
    "yBMoYv4/MxRi1YJPZP3hQ08s2nL00MDKSlFbW6v/9TBp715VBTK09ZaN+37z4cSevfr0KSjv6Tl2UnbydTQYoSD712+k25DBuJYN"
    "GoadNZPiXj04tGk7tX97lUgoyNg5s3nv0ScZc+459Bo8lPee/hN7l35Dn4ljySuvwE4k0zwgjatcsvKK2Ld9M63NzfQYPALHitO5"
    "2FUH1C5OFJ3sLIr4ki2e7/K1h9YuyvW/XOXZJ/y4vjivUr5nUC5oH9NXnt8amrQs3v7iTfYc2kNzWyNZsSw8V7Fi3Qo85TJhxEl8"
    "vWYxjucQNIK4nsbz/JAiaXtCaEQ0YIpkCizHYlDffvTu3ocFyxfw6PMPsXnXZmzPwrYsBBLXRQSDBrbr+bVPJcnKzOW0KacipOeH"
    "80ry9mfv0tDUgmEYRCOGaGlxME0DqaVQniZlJUlZ7YwcNIpeXftiOxZKaTzXI5WIs2ZpLRNOOdOX7kxfKzz/OijPxnMsXMdGu54v"
    "7hYMpL25iRCm35Cj/Co52h/0qDsGPuq09pSfwXYKJaA04YxMtq//ht2bVnPhzXfiWRZaKUJ5Obzww7tZ9u5HuJZH45E6dq/bwLK3"
    "PmbbghX0nXISO5YtFzuXLhMX/vzH1P7tdT578WW9f+UGAhGTaF6W0Eqw4t3PKKgoo/uoobjJVOfwlXSYKMJZud7utV+bX3zw2vxz"
    "fvTsw6XPPEN1ba36N6HVaVVVonp6tTp5TL/lh/Zsv2bQqIkBIxDQWvvjuLWCaFaMfWvWU9i9gryyEo7t2s3e9ZtY884H7N+wjckX"
    "X8C6z+eR16WMnmPG8MYfn2T4tGkMmTCWBa+/ybpP51PSsyvlw4fiJpNomU7gtCYcjrL04/cYOWm6LzeVpgmIjgGWgDZk2kgMQHZi"
    "/kprPK1Q6R+tVfoL0yjt4Wl/d0Od6DlUJ2iEBld5ZGXls3HrBo42HcVTmrZ4knjSxvVg0aql5GRnc+7JZ7H38F4aWltwHD8hTlgp"
    "LNuhvimOUApDwqFjDTjaYer4Kew7uJ+la5eRtJIcqj9KPGmTshyRsFwStoXnWrTGbRxHk7QcJo+fRDQWwQwEWbVhPa99+LYfzwYd"
    "jhxtIWW7QmstXM9DGZIupWVcPPsKpoyZheVYIAxs20UaBmtXLEZIyfDx00ilh5RoJUhfDn9BC400ApiBEDLQwXpNXzMEwgggjZAf"
    "+qRnMyjVAboJXzrZSCe+yktLB/rjfj96+U+cfOEV5BeX4aRSmMEgddu243iw8dNawhmZmOEgwUiQUDjC4W17+ebNDzjlpivE4r++"
    "TKqlmYvuv5vufQdy7MAB1i9awpaFK8ShbXvoP240s268Mj3PTncOpdeAGQzrRFureO2JXyetlHX+Jbf+4si0qqp/6hW+xQ3sKGHf"
    "fdHY66aedsZzMy+9wUm0tJimMMGDYF6mXvxqDZk5uXQdOpQVr77B9nUbSTQ2k2xpJ7+8nPzcDD557m/MeaCaHYtWUvvJe1R+/1ZC"
    "4RBv/fr3hGOZXHz/z5hx+3WkWhvRykF7ikAwyou/fYBJp82m36ixpBKtfqyqfNdnBARevA43mUAQ8L8wodGeDZ6fF/hfhAJh+IPu"
    "lULhh09I6RPSlO9RFOkkWvvfqud5hAIRNm9dxzcbl6KFxlMeSkmU9rVCE6k2Tp96Gj27dGfd1vVs2rGVRDwOhkZLidISz1YUZEVo"
    "TdoYhubsU84mP7uYz2s/ZO+hvciAxN9gDbQwUThETJekYxKSESzbYsakCXTvXoH2JLVLFrFzz15ycmO0peK4niIg/WMU5+fTr3c/"
    "enbpQSQUJWmlEIYf+zuOg5CSjSsX07V7H4rLu+O6ji/U52lQ6VBGKoT0E1eZ3mQ62RnC87ll0kRKE2kGEZK0p/U6H+8UeQ4HMLKK"
    "sJI2mRk5fPrGi6SsOOdc/10SzY1IDMI5eTx24RUMPX0mtqV4+Yf3+ENcsiKYwRChUIT6g/u44CffFf2njucXZ15Cl/wCpl9zte4x"
    "biiBqIlQWjQeOEpOXg7Dzj5Fp9rjSCn9qR3ap+qHMnPdN5/4ZWDFgs+ve+idjX+urLzw36XyLb7NUsWY84b07r1i7NuX3fKDc3sP"
    "m+SmWtoMQ5qIoKGbj9Xx2R+eJxCMMey0U9i1Zg0f//4ZRp82i0WvvcVlv/oZ79z7azACXHhfNR8+/Dj7dmzinJ9+F5B88NATSDPI"
    "OT+4kXMe+DFWewtuKkkkls2ahfPZuWktlbf/lGR7E1KaCM8gGDTZt+JjPn71JRLtNlIE/cGBhka7ru8pOgQMhU5nOX6YpbSHxkML"
    "iRAGUndqV+Ip31A6eqTREA3FCARMXM9CCYUQAkME0smkpj3ZCloSDcR81AoXbXgIwx8qKPENzgxItPSIJ+IITxI2IyihUdLzK+3S"
    "xJASJRxcZWPKEKbnV7gTTguO9hGmsJFJyIjhaA9t2ijhIZREKhOBwHEsEqkEyrMRhoHE6NQ9QkAoGMJ1PFzHQRr+NXI8hdBGuvKb"
    "Di/xkSmJP2BdSvC0k0bdAOWHQoaUfl9CWk3QEGY6VPSQAY/pleczeNp5HNi5m/dffp5r7qzGDBjpmN7AjGTwxi8f4d0HH+Gmp35H"
    "XtceLHj5VbYuW0L8aDPaM4jGolz6yD2i19hR7Px6BZ8//RKbln6tFYqMQEgYAZNAKMp1TzykR50zi2RbmzAM6Y/+8hThnAJv3Zcf"
    "mG8+/4ea+95YPWfuhcqYU4P3v0zU2zgQrbUSd9nRm9596fmxN1b0KYlE85Rn21I7NlkF+Vx4351ITMysPFLxFpoP1ZNdXIC2bbZ/"
    "s5rBp0xj4WtvseC5Fzjjhzcz98d38+lDf+CMu77P6Xd8h48ff453Hnma1uZGLrz/RxjBIMl4G/2Gj2bNklrq9+0ir7QM17IwzBDJ"
    "Y/t5+9nn2Ln/KJFwBOUoAoZAGsrPIrTp1xCkQgk3PTPAgI7ZDrh42ocZTOH3GyAFnkpj/tIfiyWEpFk3pUOBdG9cOhQQWvrGZvjw"
    "o/QkBoYvMCZdhFZoLTsHkPs+ya+4Gzpd4xCgpQJkWptI42oHpVwkBqYO+6GL4YDpq3AYXgLlBvC0hytTaNHx3CBo8LSLFqozqfUR"
    "Ib+67jcSKaSW6Tja82nlUuCbjZH2AL54s2/4hv8jBR4KjYenNKg0FV1rtPA6xc49DxxPYhgS20tx7OlnKes1mNpPPmT67DlEMzJJ"
    "xFuQShLKyuL1ql+LXuNGM/XKi/Rvb/4+E6ZOY9LVFzH5mvNx2hIoR+BZDr3GD+cPl15DdpdyzvnZ9zlfGBzdt5e2piM6Iyefoh49"
    "xICTxgo7mUjXK/yQLxjJUEd3bzc/fvUve3uPHXNbVc1KuXHgv5/SLf5hD0NNjffT84deMO6kKW+cd8MvHCveZghDo3DTwaYgEIxy"
    "9NBhfjbqFKZcfB4New6wZfVKLr3nR3z666doPtbExMsvILdrCR/95g9I02Tmbd+hramdz5//Gzm52Xz3zacpGzwIISAgg8x//w0s"
    "O8WZV99CovEo0VgOC157nnee/ROxvBxQEBQmmw4fozGZ8CflqAAmJlp4aOGrPAhtopXPv9HCX9haCz/s6hRx1J3kYAknkMVEJ1lP"
    "dDboCD/3QCGkxMTfWf3irQ+pkjYaX2pF42kPH+NI5z4dBfA0D1NphcL3XFIbvlGnIWdP2iDAUAGECqBReMJOL3yJoU3f2EkvcH1c"
    "v1aItHxkWndGIFBeOu9CdTZSSaTPhMVLn5f2YVZt+LC0UOnPlb4G2pcMENK/psqDgswo3fKzsRwHMyjwPIeCLmX0n3gyZ19xA8m2"
    "Jj9q9SBaWCqeuvxm1s//iu+98We9Y/EqPnj4aQ4fO0RGMExeeQnSEWRmZYrvvvUcH/z+Cd578m8IoHf/oXQZ0kNHskIc3LSL0n4D"
    "ufbxXwkvlUi3wmiNNDDMsPrbgz9j27rVMx/6cOP8/1X2qvhXKdwLFrk/rxz22sXXfu+iQVPPclKt9YYwdRqGNtDSQEmD6slnYwjJ"
    "2LNn8vKvf8vp11yOkXJZ/vYnoD1O/8lNHNi8mbUffIkhDDHzjpvYtXaDPumKc6j/egWH1m7mklefwgzHaD58iDeff4yrfnIvZjBC"
    "KBTlq9df4N2nHycjJwfPU2QEw6w/eIwvthzESEOwUTPoE8+E1/nFCS38kUvp9l6hRdpbkK4HpBd+5zxk8XdXQ6eZG/7OqkkXqACJ"
    "7EzYOgoYnQsxfXz/ubJjYkt6gR7nIh9nTqdfq9OcSaFAplmr6cWJ0HjCTcObJ3iAjteLE5E2ieqYSiSOo4EdlGi/luDPzxL6uEJJ"
    "J1rXMdgobVAd/VcaiJqSlOviaoXSMHNQBd3yMknZDmYQHM8hu6iEOx5+kkg0w0fxtMLMyGD1u19gBMP85Sd30bB7D5X33km/cRNo"
    "OXyYfRvX0dLQRFZWPhMuPl/sXLsSz0tS3LUb6z9dzq5V62k6egAjLHXv4aM490d3UNCjQrhWCmGglfIIZ+W5i974a/Cjmpcf+vU7"
    "6++smjrFrK6tdf+3WKsn3qZdfTW1878S1199Tu3GFV9fNmDwqOxoVrbyvJRf9hYS5WkiuZnsW7WR1V98xdizZ9G0dRf7Nm1mwsXn"
    "cWD1RpCCfavXcNKVlRzetpNUS7vYMP8rbn7xT5C0mPvDKoTtIaMhIrm5lPbqzd5tG0kk4vQYOAw7kSArN4e1tfOwLDtdrdTkRIPs"
    "b2rDURrTMAia/rBAwxCYUmIa/v8DpsQwBIYUfm+zlJiGwDT93wFTEDANAgFJKGAQDBgEA5JgwCBgSgJm+jHTIGAIAgGJaUgChv/b"
    "NIT/noZMV2p9lQ/TkBjp36YhCaaPZRqSgCkJpo/rv79/P2D672kaEjP9eCD9XoYh/XOWovOxjvc3zY7PLDFNA0OCYUgCZvo8TJm+"
    "DhJDCm0YQpiGH//75+5/BsNI35f+eUqD9GP+40HTIGRKX7RICHJjIcZ0y8N1/bqQBvBczrr2RroPGIyVTGKkRY6DmVm8d99j7Fiy"
    "jGuefpgj27fz0V9fY8Nbn+LYSTJL84kV5nN4x16GzjhJ1D77AjWPPUv7oSP0GDZEDz91uhhx5sn0HjdShKJh+o0fhyENgfBQWhHO"
    "yFb7NqwOfPjqX9Zd+/AbVxw48Dv9xId7VPU/Kzf/e42htrZWV1ZWyl8+9kL7xH4lW1rrj1w6aNxJynFt6VeIffjMjIZJNjez+J33"
    "6dKrFwUlRWz8egX5JWV0HzKEncu+QUtN84EjjL7gLNZ8MV9c+eiviIUifHFXNUnHYtLNV1O35BsOr99A95MmkJmTwze1nzB0zCQ8"
    "2yIjL5+D2zazd8cOguEIjusRC5o0JVMcaUv6SZ3WGLKDmqg7CWjiBJmYjsZ+kW411537akeRzq9Yn7izqzSO7leydRq+1cdhWX/c"
    "wPFwSh7vF5WdQ8eP78p0vlYfP9eO/u+0PnXH+XSEdv4IOt2p8uGf4wkerWNPF98iDCCE9kfKyXThVPpkUOlLN6RzBH8YpJSi01PS"
    "cT3QeLrjc0PYlHha4yiN43n0Kc6kW24mtuejUVYqzoARw5h1+TVYiVS6c0+kYeEgQgSoefgRjmzdyflV32Ps9OmgFNvXrGF97SKx"
    "bdkaUda3r+g3dhjF/brTrU9PNny5mIXvfMCSt97l69ffEyve+4CKvr3FiDNOE65t+58xENCOlRJzn3g4pWxn9ulX3rG/srJKTJ8+"
    "Xf9v9TNUVlYagwZtkps2IaZOnWrs2bNXz5mzSVVNnWre+96CrX1zdSQ3O2NKxZBhrp1MSpHmLUkEZiTMN6+9R1tDIwOmjWfP12uo"
    "332AsZXncmDTZrR2ObhtO6YhufFvT4jMzAxevfIO6vbvZ9LN1xE0BEfWbaLfGbMoHdKfjMxMNn6zmFA0g5Iu3dFKISSsXbQAIxDC"
    "83z3Lw3N3mPxtDF0yv6kF6tvrB0LWp8QEYrOGRF/30niL2YhdSexVUrSybWgg2DZGfWngal03nrCKC6thdBCiuOtWZ2SSemi0Ali"
    "3n7UpNPHlCI9sbPDmEVnbiKMjvMSx8MfcVwiX3e2gqVrAB0jjLRGK3+s9HE9+A7pHN35vOOz9NI/km9VdCOGQcrxfLEHCSO65RE0"
    "Ax1ytHiOxbQLzqesd39cy+qkbggp8WyHrkMGY4oIn7z0EoteeoNgRoYYdtpMMWnO2WLcRRcweMoEpl86h/nPv8Rbv3qE4bNnMf3a"
    "Sxh39myGTpvKyLNniomXzGbSRecSDEc7ZYBCWdneF68+a36zeOH3qucue79q6lSz+m9/87RGzJ8/1bz66r0UFSEHDaqU/xZRzwTE"
    "iRhsbW2tEsJv9rm3utbbVIkxrPKi6i8/ePPcLn369yvq1sNJxuOGFCZ2yqKwRzd6jBzMhq8WoQ2DLv17s2P1ejZ/uYAx551BzSOP"
    "MWjCcM685weolmb9yffvIWhbnHTLd+g+ajgffO9ORl5zEUMvPBM7FSdgmgwaOY4NyxcwaMR4Eq3t9Bg4kNKuZdQdrMcwQ1iuS2FG"
    "mOxIkJaki4lAIQjKNHUF6VevpUh7geMLQ/nySZ2Pi7+XdulAjtLpQGcTovZ3Sn9Cpzzen5tOXjtGz/qshbRXSY8qUR0GmDYQrX1Z"
    "S532FHR6Bd8rqQ7voAWy04fo40/qOGtB5yAU0hI9nbmQ1scXtEKn1WDS3CzRicl3DA/Rf6/Z0+FtNJhS4J7gkQozQ+RGgtieIiAk"
    "tmOTmZ9Ht0HDSCWT6VTKQwmN8CRSGljtrZx7162UD+3O+7/7I7Uvvq6/ePF1IjJAIBIQAVPw84/epu+E8Sx+7U2euOVO8jOy6DZ4"
    "KLmlhaK1+SiNR4/Q/ZXnycz1axvh7Gxv5zeLAstrP5v36CdbnpxbiTGnptatqkIKgYJat7a2Y2XXfLvJ/V/zDLffPnH6iMH5948e"
    "Xn7dpPFd+1xw5oStP6/e1EYVctq0SjFnzu/sScMqNtft33nFkHFTFGlRG6U0oexMmvbuZ938BWTm59NtcH92L1vL/i1b6TtuFGMu"
    "Optz77yNbW9/xNybfkrA8phy1w+IxEIsf/5Fek4dw4SbLseIBHFSFo5tkV9cxOolX1FS3oNoLINAOEhz/WF2rttAMBzG9TwiIZPW"
    "lE19m40ppQ8jijSnJi2g3Zk0qn+p0CROkHLx9T/pXJx+X3V6EWs/gfTSj6E0Snd6gc4worMNIh1y6Q7WmBadodXxQVXfTtYFHd5H"
    "fmuUV0c4I9KasKS9QacBp3lYEv/8rJRDMuWQTDokbZd43CWVcvFQImU5WHEnPUTVF0QTIt2g1Clnc2Jl+fgtZEicjqo1mn5lWRTG"
    "wijPN8B4op1hk8YxfOoM7ORx5rBGpXugfejTtSy6jRjIxIvOYeTMGfQZOpwuA/vSZ9wILrr3J3QbMUR0GdCHsXPOorCsCO14NO6v"
    "E/X79oGE8396O30njsNOpAiEwjrR2sRbzz6SCOUXn/fxwnUNAyurmDatVlRXo373u6tyevWS148YXnzXmFFl500c3zexbMXe7f9s"
    "KpD47ncnXdne3vA3POUXjgyBkBwoLCi65JcP1S6aOxejad4oeeOzq5wfz+l/79mVV1dNPudqO9nUZEokoWiU3Ws28sjpl+Aph1m3"
    "XcOSl95h0IxpnHzrVYh4Ix//9AGaN+1A5OYw9e4f4SVSrHr6L+QN68fMB35IND8H05WgDaxUHG14LJ33AcqTzDj3UlKpNg5s3cTz"
    "1VVo4fdMh4IGDQmLTzcc8pEjrQkG/ISwI0zy4UzdOdlSn6CA4c/1Fp2D1jsaSzqxFH2iAQmOTx7Uae8hOpGk4/GOQHXSYzuwJH9A"
    "Sed4Kt3hLzQ6LSUkO3KcdHGvcwKsFmmIWHfmEqTRLInEVR6W1ljKIxIO072snH5du1FcWkhWlxLyuhTi7N/P3k27aEnYtISC7Nyw"
    "lvqGRuJJB+lpwkETM2j4HqkjxExfA5U2ibBhkLB9mksgKJgxoISMQACUP5fPFB5X3vVTyvsNwkk5CBkgEokhA5LW9hZi4UxCwQws"
    "1wKpMQIm4WgmBMJpLR4PrBRWwkJ7mkA4iBENCddytd2W8hmw2TGMgCDVnkBok1BGtvfes78OrF299MZ7/vL1M1VVU0yoVdXVqOpf"
    "nDXhcP3eFxwv1RsFKJNAIEA4kn31Y48v/Nu/NnfaGDI05xXPtQu1J1MglefieNrKiyfjZ51/5viarxZubw33PKxq56OXbGyY3yuz"
    "ZUavPgN65hV19VwnJTzXI7O4iN1ff0MkL4MxF5/JKTdcRVlZBcsfe55lf3yWlrp6ep0xg2m/+BH7Fyxj77JV5PbtybSf3kZOeQlt"
    "Tcf4ZP47LFlRizQkXYq6cKThKN8sms+wURNQyiOWncmONStpONrgj65VimgowL6GBEnbI506YAg/Kuj0++JfIsnHd9oTqL8dYYrq"
    "SFLTUbTihIRZf1tBsiNfTldn/fygIyklLWzckbQLP9k+IdnV4gQpPnWCR1L6OH/oBG/VAda6Ctpcf6mWhQKcXpDPuUVlTAln06ch"
    "Tv6+OrL2HyS7uZWyfr0Yfc75DIvmMCgZZ85N13HyzBkUIQhkZ9KUStHS1oJ2PYKmmaZf05lAB9MVbcfzZ6kXZUfoUxRLj6CT2JZF"
    "j369mTT7HBzbAS2IhDM4dHQ/f379d7z90SssXVlLeWl3CvNLcJUvmOZZDm4ihZtK4MQTfjeiTBctPQ8nkUS7HmYgQMAM4Nk2ru0A"
    "gnBWnrdu/nuBrz5+e27VC8t/Bpra2r2qqKhSXl05pnjf4e3zHSfZ1VUqhRIKZdhaKdNRVpeVK+uenzNnDv8oXDKGDc+7Rykvlk7L"
    "JCjDcZXtaie7NZ4sfOWVo29eOu2GyKDR0cmnzBrpJA40v1N/YNf1Q0ZPDhqGiVJKBENhckvz6XfSaFq2bmftUy+y6qlXOLRhPQXD"
    "BzDhjmtFKDND7PzwSw5+s44B557J1B/dSCQ/Aydl8cxLD/PupzXs3b+HRStqEcJj3vL57N61g/7d+lNU1gUpIZFoZdvqdQSCYRzX"
    "I2AIEo5LXUsK0/DRDtPwURI6ZCE7h+Hy97xXTtjr027E37lVJ5pzPFQ53iCnj7+mIxL61oFOTFDFcQTLSF/hDlSrI1kWIg1XC79W"
    "LHxDFUaHgIHQhpQYUgpXa+KeRyhoMik3n3Oycplhhsltt9l46Bhf1x1ldbKdbU6c3UfqaVi9mfYvlrBn9SpyJo2ndMxItr/7NtbC"
    "pUwYNYaxBYVUuIpBUyfRZtkcbGwiFbcImUECpl+niQYlKccPDT2tGVCWQW40iKdI90w7TDjzNMr79sNOpgiHMjhUf4iHnvo5W/ds"
    "RCtN3dFD7N67jUljp/sM5HQjjw8O+PBtB22/Y/PwDcMfz9tJ65cQjGSoun07zDee//2Bcf1POqNkRDh/ysQe486bObr5d0/WJHr2"
    "Dj/ouO3THU+lhCQASLQ/eUOh2levXvFcbe1a5x+FS8aIUfk3aqXy/fBXCOVqPO0ZrqeU0u6A006d+MHeI9seiydaHmxta7gqe3Cf"
    "N9o271wv3eQ5vUdPdd1kUgbMAMlkkr+cfhmbP/kSq6GdHhPGMPyqS8gb1JdDa9aw7/MFuLbNjOqfMnD2TIT0qcS792/j9ff/QkY0"
    "B9MIIpCs37GWlkQrjlZkeDBg6Ehc1yYjO5O1i5diW47PpdceIUOwvymJp3RHnpjure0QgEjjJ3/nITpjdGEc730+ISL6FhzbEeIc"
    "r5Z1Fux0OonuQGy8NATbmTukd3iljyfM+rgXEB3eQCtEx3NUmlXrF+OESDpKxD2PoliQMyqKuTi7iB6tiqONcTZLxZbiLBpKszBL"
    "c5HRIJYp2ac9jhZnksiOYew9ivfRPGxP0e+Ht9C2aztH4zaDrriKLc/8lZED+3Fe5dn0zM6AjCz27jtAWyJF0IRwOEjK1igPYiGD"
    "EeVZneCA6yoys7OYOecipOlX/U0jyJ9e+T27DmwnMzMLjSYajtHa3sLQ/iMozC/0W2qVn2uR9uQa1elBv+3IO6A97c/hk4Z665nf"
    "Go2Hj5yzNZQK1tfvWdwab7q5sb1t4uwzpuw81rD/EdexpdJaKuVnWFIbWkhhSGkcnDDxO0/V1NT8w4mixujRZRPR9mClcFG+I1fp"
    "ucUaLyjQY5Kp9smO7SoPNyPe3HjSU2/suL5HLDGxvKyib1H3vm4q3i4ziwpobTpGcb/eDDx7Fvl9+1G/cg27Fi5i/8bNjL/9Gk6+"
    "54fk9+2JslM4lkUgGGL7rg0sW70QIQ0c29ctkoaBVhobUO1xBvUeQiQ7i2hmBvu2bubQnv0EwxFszyUSlLQkPVpTbjpfgKBp+JQJ"
    "w/QHz3ZUY4XAEBIpDJRSJBIpkgkH5bqYhoFpHlfQ0Ohv6fnIb8kepnf7E6HQNOTJCbh9mvOk0w6hExKVIv3cjmOL438TAr+yjiDh"
    "KCyt6ZadxbnlZVycnU9xg8WaI82sy4nS2LeIQPdCzESK3LxMZCSCqSWthxtxbIuKXqV6e0Mja+NJ0SyClG7YwvavFzPol3fTtmsv"
    "ez7+jPz8PJocm67jhhB/8wMuve1Wpp48HdXaTLtyOFjfiJ3wWao9i2JU5IVJuS6mESCVTDF49EiGTZmKZaWIhGJs2rGFd+e9STAc"
    "xHEctBJIDFzlMW7ERAryCvBch1gkk0Ag5HciSkkkHMWU/vPEcc5M501pTSg721vy7suBFYu+evy+1755uk9vMdf1UoMsx7OUoqd2"
    "3VMSidY8Dcr1SWVp4onhBU1pGkboozt/9vg7lZUYmzb9S21WY8rkvi2Om7pSeVqhpejg+3taCV9L2C33NzotlPJchCydMWvkR4GU"
    "8+KBHTuuHzJiYsgMhgiGTUFYU79xHUeWr+fgii3IaJjeM8dx+q/voufJkwDttwsaQTzX5/Q0NdVRu+wLTMNEuaA8gULjegrb09hO"
    "ivLMXLr3HeQnda7LuiVfo7TASibxnBSplMuuhiS2rUg6CsdxSSYcEimbpOti2R6O7eGkPNoTLu1Jh0AkRK/+/eg/sB/RWITW9jjt"
    "7SmNEgSDAZ8J2cHvOWGh+gYgtC+dieAEiPY4bvd31Ivj/0l/sScUuDo3wXSvMYK44+CgGZifw+XdK7ggIx+ONLPg0FG2lWZjDOtO"
    "WZdCAoU5WHWNhIMGRw434TgOLW0J2qwU5f0r2LBpDw2Hm4iEgiJREKNeQN+GVta89R6TH7yfoJBse/V1Rn3nSoqGDWHnyg3Mf/lt"
    "yktKuea7NzPANKjo34dkPMWxw3UMKc8mIyuE43hoz78eZ1x6OdnFRbS1t5Cblc8ntR+yeedGn/2rlQ82uIJQKMTMKaeRn52P4zks"
    "X7OUDz5/g4+/eJPapZ+yZedqCguKycsp9oWgTxAoUEoTzszy9m9eG3jvpWdXX/iz5y7Ky9vTs6Gx/gHbdoSQPiHLtpM5ytOepz3R"
    "ETJLYWi0EIYMiEg4/6Zl3+w+9K/VHMzHHls878YbB/9FhKxrUnFSWhNQWgilwHY9pFCugRSeoxEmWuHoZFP98Ef+vGrFTy8de/eX"
    "b/7tj2dddYfrWCmRUZSPlYjTdeIYyoaOpsuY4WR1z8d1EljNrb6NSoN9e3eSnZ1LlDDdy3pQXtaVPfv3EDEy8DyfhWnZvv5PuxSs"
    "2vgNQ0ZPIBiL0qVnL0oruoIZJKs4D2lIerc5dGtKYnmaXCtOXnEu4cIKLEvTenQ/zS3HaEpaOMqkz4gRDBo2hCFlXSjMz4CMMEfr"
    "DrFz4wY2r97C/GVr2bb7IFpBJCKIRiPfgmP1iQrzfBvz72hF1enqd7qyLLQ+Dul3ZOrqhERDSInraZKuQyhoMLS4gNOKiujnGuzc"
    "cYQ3UincwV0p6jMIt72NiCOwdx+gqEcJRV1L2bR9D14yxdYte7CAbr274DkepSV5ZGZFfBRIClamkjixEBe02Xx2ygXM/uwdBt/9"
    "E76870HOf+4Rup88hWFXXY2WAqNXOW3rNjIsK4tTfnQHq1aspnH/Zvbs2AjZmbjKo0tFV8r79OGZFx5n7bZ1/PiGn3G4/jCeB5ar"
    "O0Ex17MpKy2le1l3tu3ZzF9rnmfrji0YCIKhIIaETdtWsW7jcqp+9DhFeeW4rpuW2ATDMHUq0Wa898pzbkInbxo8eLD9g+9OHqmV"
    "iqCwFUpK00N7wrVtT0hTIKVCa4GrtBsLG2HTjPzu8ae+WOH3/P9j8p4JWpaU9L/jwIEtfQKmfZJty5Tj2QGNJmCYwrJcEQqYOmV7"
    "GAqMgBSeErn+QVc8YcTVoO69B908ePpMJ69rV+O8Jx8hEsnDJIRnpUg1N6HTjSIawTMv/ZYlyxdSWFjMdRfdyIDeQ7jy/Ot45pUn"
    "aG1qx3E0ISkxDIP2RIr2tjZ2EKTh8H66j5pEpKgLP/7by6h4O/axBo4uXoHIjNC85BtKJo+D5iZ0KESi2SKSm0+kywyMwgyM7Fzy"
    "e/RDxhPs++srtGxaT2pwb/Z/soLW7XsonzqJip4DxIWXXMbm+ga++WYV3yxdyo4t2wmbQUxT4jkdancGpvS9hxIKz/PSA0V1B4E0"
    "rcqhj6O0Pnu7E5nqCNts1yNu22SGQ0wt78KpuXmUJhy2b6vjFdtGDe5Bcb+uZKUc9q3aSKysFFlSxIZl64nE49o61iBaHIfssiLC"
    "mVHGjhuKshwWfb2egqJMEcuNkbI9bNujJCvCLitFjaO51FK8feoFnDnvHbq3HOWj628gJXLINDPILS9ja1hSt20PBA16XncVvZXC"
    "GtKboUfHsui9D9m8ewfnX3cjW/fv4Isl8xBmgHc+e5vm1jZ/ETo+2hUyJYlUkpPHz2LT9o388qkqbMsmFs5IV/kFhgEZmTGONdWx"
    "a+9Wyop6YNsphGGi0YQzcnTt68/KA9t33v7gO6uXaxC3p5xCKcBTKNfThpRgWZ4ISEO4ytE+a1444aAII4Kfzuhy2p3FVctkdfU/"
    "KbpVVSGqqzdZs2dPfbe9rXW0KVRfx3VVPGWLoGmKdAIolAdKKWUYhmmYkYWPPXa49md3nDbUyjRHHdywccSAISOMSHYG4KFTCi/l"
    "N+LrNBU4FAyzbdcW/vr6k4TDERpbmtm1fxujBo2lvKScaDDM5m1bsG1oS6awrVays/O46LzLufa6n9J7+Hii+Xm4LQ0cXrKcPa+9"
    "T3zvIXYtXAzCJX/seJpb4+zavhOyopSfOou8EUPROTFC2Xnkd+tJ/TdrWPDjX+D17Ea0ooTtT79EXiyHwRfPoefpsyifOoWyAYMY"
    "1K8nwwd3Z9y4IZSXlbF9624cTxPLySQYjWIYJlbCoqklQSLhEDA0gUDgBF7Qt/TU0TpdKdDHGbIJR9HmuhRkRDi9RwXXl3VlVNJg"
    "+7aDfNncwNHBFRRNHkYEibX7MGs/X0TPwf2pGDWUg5s2k1tWSO+JI0RKgRIaNxYmlbQQzW2EMyOYmREQmlRDG7qhHdGUQLUlEEmH"
    "Q8qlIWgwzjFY/O4HnP7UY7R7FolNGxlz7724QtO8ZRt2QwNaC+z2JMpTJPbtgHgr4y++kpzsLphHm9l4dBvbju0nEgjT3NZCe3vc"
    "jygkeAoc16FraVcmjzyJB5/5FfFkklAgjE4r/2kBRlAST8YpyM/n/DOuxDQDaDxQLpGMLLatXS5fe+mpRKIo2jR5Yr/G05bt2jdi"
    "ZPmklBU/1XG162kMEEjtkxlTnkcwKEVGLBAIBDLeH1E+8aJrqn+bnD8f/pkxiI6BJNXV1UprLW++fvSjza1NN8ct23BdRU4sIuJJ"
    "F8/TWgjtBsMyFApF737lleqHrr36/k1BI9C3+WirM23YWOP6n1ZhpRIYXghc6TeHCBulXZ57+RG27dpKW3s7rq0wpElLvJmf3fxz"
    "PNfhkeceJBrIpb6umXA0wkUXX8rZZ19EXn5XSCnsRBN7a+dxaMVKotEcnPpmjh08SPeZkymqKGHrF0s45MHEG66g25CBuG3+fDgj"
    "aBLrUszBT77k41t/wNiqn5Bd0ZO9b7+HjMYYce0VxPr2wI23kWptZcGH77FtzUpC0SD9hg5i4NDR2DqGrQSxnAhIgWMpUgmb3bt2"
    "sWD+l3zx0Wcc3HuQ7KxMv2moQ01CifTEIB/VcjxF0vGFmCsyM5leUsjU3Gzcw62s3FPH5ogkc0gPynuWYtcdQ8Ztivv2ZtvuQ+zd"
    "votTZk3k7bkfEW+NM/akURSUFrF57VYK+5ShwgGa6o6iXcXBQ02kjjUTTlgoNHHDIC4FlgBX+kXBJIJZsXzOcCTxvmVc9NkbfHLX"
    "3QRWbWbmi3/FKMjmi+/+kGA8wYjb72DLmx8RCmma16zmwL6DDLvtdqJde/LBo9Usbt6G07OYqBDYKc9H7gyN5XoILbhg5jksX/cN"
    "uw/tIDMWRSmNgSQUNAkGTVJugpLiUq6/5HYG9BlNKpXCNExkwMRzbB5+4Ht63eHtXiwzEkSHd7/00oa+l18y+DbbSfzOdjzL9pRp"
    "GJLscIS2dkuHYkIEw2YiKyv710898c2vO0S1/63ZDUYHS9W/u7/UTqQ2ZmRElcIe47hKeK4Q4YBBW8JFCqFMU5oB01y2cNHmtpa2"
    "hp/aCZ2QwXBg74EtIiskGTBiEk48RSSQge1YmCYcOXaQV955nmQi7k/Pcfx2wkQySa9uPehSUsLnSz4n2W5z8klnUXXPbzlpxqlC"
    "ai2Src0isX8fO9/+kG1vvEPXcWOIb9uP9lx6VV5IcXkhC+9/lPyTT+a0u35AVmYUq60N5biYwSih3Dxad+3ki5vuYMKD9xKTIZbc"
    "8EPc9iRjf/5jsnp3x2ltIdXWxGtPP86eLZsZMW4c0846i74jxhLNKSYvv4C8wgIyY1EyMzLIzs0leewwiYYD9OlVyqzTpqKUYOWK"
    "DUSjwfQoBY0pfCzd1Yp21yUUMJhQWsCVFV05I5pNtL6dhdv3sdB0cId1p2BoH0gkOLRiI6HsGGZGjCSarUtXM+vS2eisGKFYhMKS"
    "AqKxKKs/XEROYTaEJcf2H6Z1fwNtO+soaEtRkhEiWBTBygliZAbIyQpTkB0iFjYIBySZAZNdVpJINEKf/Uc4tnYt57zwDEve+Yj6"
    "l+aS36uC5b/+AxVTxtNl8kQOfT6fnGH96XLqyfQ/fzZbXnoF7SY4vbqa7O31bJ/3NcmSHJRShEMG7ZaNVope5d05VFfPgcN7iUWj"
    "pCx/NEvAMLVhCBGLZXD5uVdx2bnXUlLUFduyiEWysBybSCTKW399Qn+9abEW4RBOyrOUcou+/OqNj5Wn+tl2aobjas9yPZmXHaS9"
    "3UMIRCwz4ubmFf8plXAXT5vUK+/r5fsP/nvY3EZVFbK2Fn3rrZNuPXZkzxstLQ3fjVttg5X2AiCE7YAhEcGAJJ7ydCggDTB2mwER"
    "t6zkbNdGKcczInk5mJ4r5n/9MW9+WENbaxv9+wxBaxfLirN4+Zd4ni/aq5TffZW0LHp378n08dPJzcxj8knncM13fkJmNEp70xFh"
    "p5pJ7jvElmdeo2VvHYOuvYS6BYto3rObiQ88QMv2bXxw7/2c9LvfMvjcs0gdO4KnOiqZBsIMYgYN5n3nZiJDB9J/+nSOrtlAfo+u"
    "9Lj0XPJHDfWV9zybV578Ha2NDZw6+1z6DBpKJDsXEYj46I+r8TwXD9DKZd4bL/Ple28SDocpKSunW4+enHPRRURiYdb8P829d5wc"
    "xZn//3mquifP7GzOQTmsckYCJIHIIooFTDLBBnwmOEfOQs7nbOMzBmxMDhIZiShQQBIKSEJpFXa1q805TZ7urqrfH90zK3zJX5/v"
    "7je89iXR2p3tmamn6onvz0c7EPDYO55iDC5dw4SQD+cW5uPakhLMlx50NvVjc1sXjuS4oS2agLKKEiQHo1BuD5RpIr+qGPXHW9DW"
    "0onDuw9D011IRmJoP3AMyVgUWsCHRDyJnOpCCLeOrhPtiJ7qRTplICfsQTLA0ecBkhqgc4KHc3g0LTu7ALI7NF0g1KcS8AV88Nc3"
    "oO/kKVz81GPYt/l9dL+4FhQI4Mw138RQYzN2/+i3OPHGBsCjo+bc5Yg0daB3yw4ceGEdLvjLbzHFW4Cjf3kbqcowDJeAkUjD5dZg"
    "GAZSsQhMUyEST8DtsU8EjWnQuU79QwOYNH4KZtXORSQehVf3Yt3rT+HJdX/Evr2bYJiW6jeiSCWSpKRSXCPucrv3G2lromWl50Xj"
    "QuYEdUZSIpkUcLs1SFhIpmJzhUzeYpipzy+YV+Xdt79rY2at/yd4SahvrF5a0dfZ/ZqRSocYYJnS9FiQpATAQYglBeWG3JQ2BYRU"
    "zKXxFHehKZlMXiAMCCmJKaag/G7atW8rErE0du3bgbKSMoyrGQeNMxw++glaOlqhcxdMwyHPpVPIzcnB3OmLMG3OMkyatgBWMo5U"
    "dADJaB+4tFD/68fBLY7Jl1+IA4/8GWQkceGrr+P4E0/j2V//Flc+/zjGzZ+DZFcHlLTAXZ6MwizcwRBOvrEB9etexcUPPYj9X1+N"
    "nve2omjpYoy/+VqYsRg8Hg82vvQsThw5gLPPvwBllWPhC+ZA9/ptdpCjQ2ZLRSl8tHE99m7bjCXnnIc5CxajqLwE3pwCkO7D4vMv"
    "QnlVNV55aQPcEpjsC2GpO4gF3AvfiImDp3qxKRJBS2UY+uQyBPJzEDnZCdk3jIaTHRjsHoKVSCOeSKG1qQN5RXngLjemnz0PyWQM"
    "3Z09SEHBl+tHIpZE5/F2DDS0I51OYcTHMeAldAkLfWkTsZSJSNLAUMLCYNxEXySF3mgaw0kDsaSJhCGQFhKWVDiUTiDs98P38VEw"
    "08TZv/sxtr+4FmVBP8Z/7mZogRyMufwi5Ewbh7L5M+HNzcMH9zwASTqql83Db+9/gJb88Ns0f0It6h9+CYMBDSpICHo0JJJJJJIK"
    "4UAuykrzwV0KQppQEqQEkJ+bj6WLliE/twA+jx+bt7+HPz33ICwrpdr7W+AKB9XQ0ABZhoQCU8SY5nZ7jxqmMS+eSFcCkLkhjXqG"
    "UvC63PZMOxcklaWRorQQgiml5p935oKnf/KLhuH/zCA0ANAt5raLrGQoBXIwnOSMABJnhJ7BJIrzvaxnIKHSljUlxDznGMaQgiSu"
    "hIJKmXTixEEEA7ngUocUClt3bsTZi5ZAKYG6S65He3cHhkdGYJgSHpcLkWgUhmQIV42HaQikYyMQiTiS6SiirR04+p0fIG/WPOSf"
    "uwINL7+OiglVmPmzH+HEg7/DW7/9PT731suonjoB6b4+mIko9GDOaRVkBgiB+g0bMP7KiwFFmHT3bdj3/V8jPGs6jGgcHrcbp44e"
    "xK4PP0DtrBkIhfPh9nghhAkrnYRGysbSmAaUMNDW1oQdH7yDKVOno6ikEmnDAKUAF9ehMw+SA/247DM3odDvwfrbvwQes9CcHMQ2"
    "Mw0RciMwuQDBgjCMvgiSQzFE0gbcEAjOnYix44rR19QNqTPsONyIgqIcNLV3Y+7iGRjq64PUdVTNnYzkUBQd+xoQHYojzjlSfg1p"
    "rqBIgQmCBmbja5xaB3PmS8kmsUGRApiCkIClMh0QHK8lowiE8uD+zZ/hKs3FTS88iefOXYktt90NM+lCtKsPM2+7AuHycpj9ffDq"
    "HDll+Tjvtz+F+kM13r3xdtz+2su4Pb0Gj3ztWxg5pwLk1nDm5MVYWHsGODOhNANjxo4DIw3xaBI686CstAJcZ4gbMWiaCzv3b4HX"
    "41GarkFjfjSdOsJIuiAlKSjGDAil6Z4V8cTweGFBFed7WUfvCOm6ZvcCSAUhCNBIaaQ4Iy4ZkaE8+n+p06ABYD/84QdNt902fbdE"
    "epmZlgkAuhSSSBEpYVdtTSkQiRkoyfOozv5EIBqJXkhgwpKKhFTEFaDrNppEOo2b8UQMppFGykhgTOUYXLfyejyx9gkIM42+/gEs"
    "mHsWvvXNnzudnApGZBDx4RGIeAyppg4ULFiI2d/5Ljbf88+I9HVi7q/+jJ7X1+ONH/8LVjz9F1RPnYDU0BDMeARCCHhcNp4SEuAe"
    "N2INDUgerMfMG+rw0Z33QAqOknOXIn/mNChSsMwUdm7ZiLyCAlSMGQ+31wMJAY27YZkpWCLtQIEljFQKH324Gd5AEAXFJSCNQ3Pr"
    "sIQAJeOAIHDdi3jvKZxx2cXo/F4rvvvtHyAc9iMnNwdc4+jtj0J0DqOwLBcDbX1Ipg1UzqjCrm2HMNgfRWVNMcAIeaX5KCwLo0Mp"
    "HD3WjHAwCBE3kOgfRNIwEQXDCGMwlICWtsCzE3zOoBDhU42IzOEhZVtO4PQaSZuvykjBVApPmUO4O1iC4e/8AlZZHi569s/YcMWt"
    "CEQI+YsXYdePfgWPm8MfyIcYiaFg4njEu7sw8v52VXayG69ediMufGstPtPThT/9/Le4+Hf3Ije3AG9vW4/W3jakRAzXXHo1PJob"
    "rS1tYEJHaWkxzl60FF6/H+l0ColkXEERTEOQYEJpuhumpWBZRMSISJHs6++fFU+mVE1JWPX1x4mIQ+c2tDhTAGX2GJfp0rmPkfu9"
    "X/3q9Ta7HPAfq4Jqq1cDRKTuu2/pl6NDA+8wt1EkLEsoyQRMe2bBFJJxThiKpEljCnlBl+ofHEHA58o2NgsBCDMzcslhWin43D6p"
    "pCKP20Nbdm7Go88+jJAvD+l0FJMnzcS//OBfEfIHkE6nkIoMItbbj2BxKQ4/9gz6D32C+d/7BrZ8+VtI9vTh/GceATo78caXvok5"
    "P/4BZp+3HMbwAJRIIREdhieQ4/TnC1IK4C6XGjh2AgNMQ/60qai58mI0PPkyguNq4AoFIJIJtDWdxHsb3oVSwKnmLoQCXgAcHrcH"
    "QkmkLdMZBOJIJVPo7+uCP+BFV0s3GGlwuXVISDBi4KRDKQVLCTBmY+nnTB+DoaFhRIdGIKQFjRGCYT8MMw1LB4IBL+JDwxCpJMIB"
    "F8hKIx6Jo9DvRrJvACVhHcQ0RAdGgJQBLaiDcRe8Cgg6tApb1Mluv2Zg0Ijb46GwAWF28ZtRhp5nK9ECwlI2F9UhfJCUGE5JPJce"
    "xG3uPLx953fx+U3PYOEffoE3brgDS1ZdiBk/+BIie7eha9N+qMpylFx0LvRwEbQcH6LTxiHk8uDRVTfhG++sQ3fzSez63iM4PicE"
    "xgkhrx9uzY0XNjwPI5UCly7o5EbSSqB7qB23XvMFSKmUzj3KsCS5GJQlASElpGX3fJEQ4IwwODQiyosCNBJNIpo04fEyCKngcZHU"
    "GSQ4ONNIc7m4xsj9SUXV5HuBTwhYDeA/jqS1NWtsZSaiLZ989Z4Ll0ej3T9yMbGCKxGAxiA1AtKmUpaSHg9XPUNpqir2IzfgRiRu"
    "gjPNEeEGOKns7IphClVdUa1xYiptpqTf5ydTWOge6EJF2Tj85Ae/RyjgRyqdhBEdRmJwEKGKCnS8+CYSTc2ovfsOxLt70Lv3IM5/"
    "4Qm4jSTevOFOeFZeguWfvxXGQC8UKUqODCthWZ9W5XG00Orf3YL8GdOQaDiJSMNJ+MuKUThzCoxUAi5G2L35A/Q1NWJSTRlmhMPw"
    "uE1oXMHtNiGVgGmZYEyzu2DhAq8Za0/LCWHjV0iO1hWUPRIpIcA1BdPsw5Rlk6BrLkBXIM3WaoOloARB03RIZdkyVV4NjDFIk6Ar"
    "DVJa0HUFCxKmqaAzF6BxCBjgZC96ZZLdOcosSJgw0gJMcOhMgyQJS5m2S6QYlMUgpQKRyMoSW4aERhosUlDMZiGNjBj4uHkQJzuG"
    "ML0FeOiaL+C7O95CYs39eOXuL2Pu6q9i/qoLgRTDksuvQKytA20fbsPiNffDnRcmNzQkr7wJb33pftQ98VsVmXsxUp+0ontJCYQp"
    "7O4CrsPvcUEnHR7NBxGxkEylACjFGUdVWbW29+B+wbnLxvMwBstQgCWJGFOphIXCPC8pKdE/mITPZ5NRGFfQNOgelw5DWOCctXg8"
    "vnVjqmt//O1vPzsEgP4rFVAtI7BoHyFv1wO48lvfOnfswHDf7FTUKHZ7vLXE4zfIZCKoLEivV0d7TwLVJX5KGxLxpK19ZpoSTGNg"
    "pJRpCuV2ubhUeBMkFhlGKjxt8gz1zbu+Q29vegc3Xn8vCgpLkEpGYMYjiA/2gymGnm370Prquxh38yoMNzeh6Y2NGHvFJSiYMgEf"
    "fe4+7BcCX/3+d2CNDAOMwUpEVTpuY8zhTFaBoLimwRqJwmprxZSrLkK6rRVdW3aj7OIL4QrnggOIjQxjx5aPYJKOspISMJcfCanA"
    "FCGpnFhBaeCKO/Q8QBiWM+zPHUarle1fykzTaTpHR0c/Zs2tRU1VBbo7e6G5OSSZEMLGzhM4CNwG+ZJNtQMRmCB43F68v/MIYpE4"
    "Zo4rhbAA5gwaCzIdzpIGkvY0mSQTiix7CMiS4MoCaQqSHPFHSZAWs6HDyoSAspvnFIcQBiST4LozMio1zCjJw7bhYezzK1Sf6sWv"
    "PnMXvrX+RZz8+DA6n12Lho5W7H38RUy47HIMHD6Grfd+B56CIHLn1GLi9dfh3J/+UL156Y1oOGsO6l59BPG5VyJxLIqBcT5ohgTp"
    "gMkkUlYSMZFCZUUVVl10LSzLJN2tKbc70E3Eiixhk36FAJmmgk4M6bSkvLALHp3Q2hmHz+u2s0AaVCDgJ58efJcUez0Q0A9Uj5t0"
    "4JvffCwKHPibagyfIuqtWQO5ejUY1gBrfvp+E4CmH337uuLGtqNLlCU4Y6SUUsSgwDlHW08cYytz0N2fRCIl7IYqh0ptmpJygwH1"
    "4d4Pv335+ZdcFwj6vj0SiZpTx9TyxQsuhub1Ix2PQZpJxAf7wDQN4cpqbLnr+5i86iK4K8oR+XgXOPdg0S8eRMcff4NX1r6Cq99+"
    "GqG8PKSGo2AaIR2PwLJMSOUAvaTdckIaR2I4gpGRKDx5YTBGKL3gPCRb2wCPG5wzNNYfwSf7DkHnhFOtXWht7bKZSA41IjsbLO1r"
    "ihxcZUbg0AGFgZRNrVOOxKsLONbZh5KqYvS1N6OltRvcBaStNIRQ4FyDEI4fryRMKezpQgKUsNuUN9f3wIpYSPX2QkjKMmclSRt7"
    "qTg47I5ci+xTjMDBlGZ3xDIFxaRDymYQEhBSACQgM02BsKfoBOzrdhs7g6YYmCmxVyVQlJcD472dePF7P8aNv/8ZHrzkCtCTazHl"
    "tmtAOSFq37FHaZIjv3YK2g8eVYdf/SwKp82AL1yAnff/Cks3Po4Vv7kfg5//BuI5OkQhh0YK4ZwwJlVPxpjKCTh7/lJ4/R7JdGiD"
    "w72H9h3e/0ufL/jnZCppJwIkOSItEkG/C+GgjpNtI3C7NRDZYjGaTkpIQ0lKVef584/88l+3bAO2o64OfO26v10o/VN4SSe4oLq6"
    "Oj51qk8/3rTvDWkm5hvCtKS00SNQgNsFpA2G9p44asqCaO6IIZ40oev2dJCS0IhY+2WXreof5jUPBGj4nNwgLUxbLktqOjPMNAgC"
    "icE+u5ErFqPm199VvlwfKlacja1f/za8RbmYfNO1sE7sxls//BUm/tPNWLBiGVK9w+AuD6xUBJZh49eZHSvYxsBs7YBkJIrBZBL+"
    "/EIcf/Bh9B1vwfR7bgfXOWCZ2LVpM2KRCGoqCuF1a1k3K9NenaGsZ3rrbF9IGx3+UbBHPE8DlCml4HIx5AT9dltAysgqFWmaDqYp"
    "pFIGPC4fokkLHIDf67Y5rEI4Gsg2u8jt1eD1umAfepnJOOncZoZ8p6DbyAH7tMmAyLgCI5tzQ3KUnGcDl535asWcwVUFAWG/JgFI"
    "E/AxUpW5fnq7P4LrivKx5V8ewrQlC7Dqz7/Hw+dehKn+HGg+N6I9fZQyE6rmxitwzvnn4virr6Nvz1HUv7UFIQm8fu8DuGf905i1"
    "YTMib76LjhUl0HQgkYrj4mUXYtr4eSoSjyqNa5AwRUNL04/MaPR9nbkGYjJRpGtkCaWQSgnKD3lRWuhBU3sEukuHxrON3kopRsIS"
    "Mm0kJg1YeHb1fZdPRfi1yJo1kIS/HS/J/r2L69atE+l0v9c0UlVpU5ggUkLaCEZ74J7g1rkyDKjOviSqy73QuIJhCHBGSkgFKVTX"
    "Zz7zQN/6df+y4P6ff698487tIq+0kiAFGBGSQwMwkkl4wmFoiqvjD/4Z8+64AWpoAL68HJTMnYmpt96Nvd/9MY4qgVWrvwXAA5AG"
    "JQTSyRiEEHaAC1vXWUrL6XLkaD9yHJruRqiiBPk1FSicORXS64bmdmGwrw8fbdsJTXch5HXDxXU7CGbchpJxDhfXoHGbzaocUrdl"
    "2TlneyxTQkgBy7JgCdsfFlJk0fcgwLQEpkybDEtzo3MwhpF4EpXja/GZz1yHMWV56B6OYyiWQijoQ+3UcWjrj8MUEkLa2g+j8w4Z"
    "PIwtDm+j+uGADySEUBCWhGUJWFI49yOghFRKKiVk5kRzxk7/CmCQUXTTGIPLxeFya1Sa44Xu49gkY5iak4sn7/gGikJ+LP7S7fjw"
    "l7/HiYcfUWZvv2J+H/JrytH1yX5YjNOi1V+ja577A5b//odw7a/HoYefwjm//i7yyAv/0RiYWwcnIJKIIJ6KIZ5M0EtvP4efPfpD"
    "2rjlrdTDz348IpXqMg0JjTNlGAJeN1PVFT60d8WhQODcThwpIkUOGZAYI8tSpmGkAwkr7nM8Hfq7RdFPiz/ZT36yfsTt8h53uZhO"
    "DKbbRRbnsBgnS0JZhiUtImX1D6fM1q6YGFPplxkco5IKhmnFAVht/a3fPt58qCK3qEwwXScwQjo2jHhkGNzjRf+Behx44FfInzwJ"
    "3urx2PiFryI8tRaFZ56J4Q3P4u23NyHEOZrv+So61m+AHgrBFQrCSifsk8Ae2LVFSiwzO+CfbmpGRXkJTMNEwhRQXb0oqLZz2o2H"
    "DqLpRBP8fg+8bj1L1FAODsaSCpaj/QYAuqbB63LB73HD7/Ui6PUi4PUg4PHA5/bAq7vh1nVojNuz0CAIS0DjGlrb2rF5/0kMJy2Y"
    "gjBzxiScbDymoum4SkmJpu4IlLCw45MGNHRFIBxEhXSYSxlCoP1lk/oYy0x/ZecrsgPVGdiZEBKWJWHZIi1K2DMqtgFLZRuNFM7/"
    "C/t1C/v7TWG7f8VeF9ph4qhbItwXwSN3fg2X/tPn4F2+GDu/8RN4kml4qkqQM24cmt//CBtu/zr+dOYlOPzOe6hefhYWf+te7Pne"
    "rxAgwooH7kOwuR8ra8/DL//5QUwaMx0jsSgeevZXeH3jWtHQfIR19ndc79LdpiVkTCmClFBuF6mxNQFx7OSwGYmbFmNKKEjJuRIa"
    "g+AMQuMQCkp63Fx36b5tvoIl3f9VGvVvPhlWr14NIpLFBeV3u3X/Ea9X83m9zO1zc7fPw90+H3f7vNzt9+vugjyP2xCkdw0ktbJi"
    "r/C6mVRCQYHcAHj/YFfexeddqZadcxmlkgkokUZieBDKlAiUlIClLEgpMPG+O2ASIc41hCdPQNmCuXj3uz+G59LzcOfaRzEyEsXu"
    "e7+BLdfdiqPPvACpLHhyc2x0i5kJToW9W6YT6OvvQ7q6DDAF+j6pR96iufAUFwCJOD7esQNmOom8kA9hv9tuWXBp8Lo1+N06fB4X"
    "3LrmjIXC0WpwaNcZsoaTReLMnkzTGcGt21hHxgiWsAAG9PYNo7IgiIllYaRNhU2bNmPXvr3o7ougqz+FeFoimUwjHk+jtjIMj2Zn"
    "yJW0h5QyclPS4SZxAjgRNEbwaAw+twa/2zFUtwt+t4aQR1dBvxvBgBcBnwfBgBchrwcBrxshrxc+lwteTYNH17I/79V1uDUOl4PD"
    "dOkcXhdDVdCDj8woWH4Qra9swpZnX8MFP12NprwgcgpDqDx/CSxDonXbLvg1r6KuYXX8pQ0QSqG3qxuRgUFs+/4vcOaXbsOUSTNx"
    "8PF3YFkMusuFV957nupPHEbQF2aMXJAKJYaZpkTKYIwzhPwuWVLoZqfaYi4Cdxfke1x+v0sP+F26z6u5fF7N5XYzl64zl0tjuq4H"
    "N5YX1dy5Zs0aif83suS/jRlGY4c1EgD9y6/fOvTzn391YXPzjssSseEZhhJer9uT9krEhJAJoZBm0EK6lhw7MBI7o3/YmDq+IohU"
    "Usm0KaoA8HHVtUduuu6Li0QiBVISicggjFQKus+D1vXvou3FDRh7wVK0vfE2DjzyDFY8/DOUrliCIw/8BDsPNaLui7egZNE8lGx4"
    "Bb3btuH4I09g6z3fgn9CJSZefxkK5s6GtzAPRAJWKgEQh0t4MNzTh+CMKWCJNCqXnYm2dz/EuNs+g8GBPmzavAsjaQUMRDEST0Mp"
    "lu0sVXJ0Bs1Syl78TrXWDk5HKd0Z4pBycv62bgFhIJrAUmW7NiG/B3lhNxJGGn6vjvc+akTQoyOetNA/bGLuxBwIEKqLgiABGEJC"
    "gjAQN7G7aSALUs4OdTsTdKRGYwjpwKDtAEZAMUVKkSLFTiOBOJ20WRjyqDg8kTOvLWz0i6UkpA05Uy7FKCUE3pHDuDyUg3e/90vc"
    "v3sD1d5zOz765k/UtXd8Br5wAHljyoHuAfQ0NmDBOavAOYdx5CSqzpuP7R9tw9idH+PKf/0JvrPiYnzw+Dqs+Pw1+Gjvdui6B8mk"
    "IeGC4ppr7+Z1/+pPpq1xhWGXzAlyz9GmWJqT5+2SwpxtnLEGX8CdUFz5zVTaxZgWgpScNIoFQv6jv/nN9n3AfnsN4//tVPgPjSHj"
    "Lq1eDfb1r/8yDuA55+vTJ8jX6kq6BjvG5AZz3pw9reSXh4431nZ2D95VXhg6ty9qlF999Ywzn/nTi153MAwjGoeZiFEiMgwopULV"
    "lTj5l2eROtmEkh//EB0P/Ayh4hKAuyA7OvHR4y/AXVmGU9/9LaLPvYrJX7kLFRech6Izz0T1Oxtw5MVXcOjRtcCjr2PKtZdhzEWL"
    "4aopskUPDYlgVzfGX3YhRo4fQ8NvHkblP90Ol8+LPds+QlNDM1wuF6SQSKftTBjn5LgnKnsKOAMiWUaqUKdFYw5aMvPvQo0ag2FJ"
    "eL1euLhAR1c/lBN3BNwckSRQfyoGCYXJFUFMrSpA0jRgSptOJ2CzTEkBpiUhFIHk6LC8JJuyR458lz1VlCFNOAU4y0YjkLJTxcTs"
    "TFQG42HHRyzLUs3yVQVhJG3ZaWQoFfJyuFwc+cTRa5g46gYm9CXw3A9/jdt+9XN8f+0bdPyZl9TwSATL13yDNE1Te/70DDz5RUj0"
    "9CG6vx6sKhelCYX6n/wrrnznZZx72eXY/vgrkONzEE+lwaQOyQTzuV1UVlT07K+fePyc/JC3KCdEaOk0nh9XOemR/DzvSE/3QAVc"
    "VrlkOPXoI7tf/Y9GEpwEgcLf8fhbAgyqq6tjvb3rCABmzBjPu7sbla7POttIx9+UUupJw4BUasDn83+U4yt6x6+zKUPRtpvKqyb1"
    "/GzNH8vSKcMLYalIXxclYlG4dbcSfSNof+t9VF16HrgWwsc/+R1m3HcXKi48FztvvAFv7P0EX9rwLCJb96H5Ly+g8+O9CM6agdp7"
    "bkPp8rmwmIXB+iYc/cvr6P9wLwIeoPjcBZh46w3IqRyDuy66Arfe/w1MM9M4+f425M2ahaorL8YDX/kq3n39HfiCflTkepDn9zgz"
    "B/RX8LAMYlE5kDI7WD39X21MjF1EI2eXZQzoGo6DPD5csHACXLpE30A/iAOmsPDGnm4MDtnTcYumlWH5zEJ0DgxB1ziShsDHx/vR"
    "2ZNGntuFSaVeSMXsIN4hfWRodwQbt5/VVYBdC1FkOUAJR8FIZpCV0i7CSZad57b12ZzrChAW0DSQgqUUTAiUBHSUBtyIpRQGkwKR"
    "ZBp1Wgj9sThuevNpMk2oD1Z9FmFDIVoWwsQLVmDuF+9CsKQM7du34f2b74a7ohiTrjwfW379Jyz4y+9RO3kyHpizFF0lHsSnhKDS"
    "0nQFmDs/nP/G008fvOyaVdP2+r2iKm3qD6Ys00okI9dLIWozJHGPzwWXx/+ZJx7b/0Jd3SJPb6/bBIBly2yAGP4bD+1v+B51Gn2M"
    "tmxptADg1s+5qi0jqpvCSsJGy+TG49GVqVhypc+T2+ALFiTPW37ReBBTSkqVjkWQTiQVI6JQeRk2feunkJEoJtxwFd688rMwDI6p"
    "0kR860Z88Oq7OPOPP0bh2NnIKx+LiitWonPzR2j842P46J++DSoNo+bai1Bz8XmYf/99MCMxtDz/Avp27cL7V3+ACeechzP9AYyZ"
    "PBHpvR9j6MABaHkFaDx8GPt3HoCu62CkEPRof7UbqKzs62h8MDrjzMgu+2fAFs5SREYdy9aCs1Aa9uFI8yAauhK46Kwx6OzucjJW"
    "TluBAnRnEs4S9smkMcJQPI2uPhNB3YWaAi845+DOk5+mwJWFpBFzWK9OWjfLTD0NPamUgpB2AtW2J5l9ddKZR1WOQqctSaVGRQPJ"
    "5qxqDAjqDHGLYYdIYKnS8fzXf6BWb3od+1deAN+Wj1B5+fnY9fNH0PTye6g8dxkKZkxCOp5CMD+MGf/0OXQ1tuClH/0MZ+18H0s+"
    "ew02PPwEIvkeiULuzvEGmq5f8ZPPuNS3fwAu50Qj7vqhWO8q4taMtCnAGTM0TkoIKNMQWjioT3z44dXeO+9ck8gU1EaZqn//g/8/"
    "niLqpz+9I6esTPwxER+6VwrBAGiWAIFIWaayLBNiYGiwKBwu9N/7hW9Y0hSkTAPxYRtfonFCpLkTomcYU+64CTzkx0BLN8745n2o"
    "XrkcG2//Mk7k+VF312dx5Pd/QeuLG1B1/lmUM3kcVV12EcIzpmDoZDOaXnkX7Ru2ItU7jNCYSky4+XLUXHUBXHlFGNp3HHpTHyK7"
    "9iI4bxpKV67ApJvqsGHti9j09hZoHjdCfg3FOX4o5dDwGIFnSBhOz06m2AYnnWyrxipYEhDIsEcdnKUjaCIdbhMjwB8OYUxFCF1d"
    "veCaDqUkDrdFYKRscEBhrg9jyvyIJ23N5mjaQltnEvleDWW5Xnt+IsM+VaNVbuVIbUnl9IQ5MryZIDuL0XR+DtmA307POlCyrGQt"
    "d4iAjDEMJQQyEUbAzZHrczvAMEAnhlPpBIrcXuBEJ1RhGGffeSvtXrsOno4ulFx8Poy+KE5tfB8Dew6DFFC2/AyMu/QiBAoK0fir"
    "x8AKc7Do9utw+MlXVCySZPnTq0+dX73kgnf2P35LWiS+39g8kI7GYqVgojhlCQMg6dI4gyTOGOMEhVQ6dm5n5/Grl5855eBFK1tb"
    "/qs5hf8JY2CrV6/mx+rfW2tZiWvShsGFkMwu+jLijEhjjHl0F7PMlPz8rXeq2to5zEylYMSiSEajIKaQU1WO7V+4Hx7uBsIBbLjt"
    "iygoK8T0u++gyFvv05O/ehgX/X4Ntf7mMRz/4wsY6u3FmJXnkub3QgpB4fGVGHvdpcg/cxaSje04tf5DNDz/OuINjQhPqMH4y65A"
    "5RUrkTurFtH9+3HyhbXo3nMYw9EkXnlvM7raO6F7dRSGPPC5eQbVbkPIlHKqtcpOS0qVzfkL5+9ZxL1TzcnqGihlq2k6O2o0YSCU"
    "G8bYyjA6u3rtVhVG6BhMoLM3BTNt4ayFE5HjlYjFk9A4w0jKRGtXHH5NQ37QDUVZbQUwxpxFe5r4SuaLbEEVzm1WLmfM4UPZf9Jp"
    "KVhGo8Y/ir2nrEbEYNzKoiX9bo6wR4eQdh+UUhKmVOhMp7HAHcL+nftx3t230LBO1Pz4Olzw6C9RsfIilM6ejaHDR5COxjB4tAkn"
    "XnsbpYvnw2Na2P/Ci1jwpVuBhCn7Nu7UgkWVv21E84K0iD3Q0T+S0knT/F5Nco1JnTOmc2ZLYJB9ZgspiUiZSprFqbRx/srl5zz1"
    "w5/VJ5QCrVnzv2AMdXV1vL6+Xs6cpC8eiQ781LSshFJgUioSVkaHmSAVo0gkgbKyKrrvC1+39bGtNBJDg5BCgXNg5EgDEr1DmPOd"
    "L8GVF8JAUxMmXHwhSubOpXfu+BaGx5bRLT9ZjWjzKerZsgu+cWXIXziHcseMQaK9TYlUGv279sJVnIeqi85B7sJZAGfofOd9tDy7"
    "Fr17PoE/rwhlZy1C1Y2fQd6CaZBcYf0P/hW7untAbhd0rlCc48ouAHUa7U5mMfP2jsqYU+Ri9rA549zm8XA7s8SZ09zAMgZid7HG"
    "EgZy8sKYOCYfbR1dWRWb0lwPptQU48Jz5mBMqQ9tnZ32IiZgKGWhszuFgEtDyMNhSgnhwIClso8iu9hnG6rlDOcIAeeagGEJp74g"
    "YVlwvsf+N1PYBUMhAcuSWeOWyhZqsSQwlDSdVhPbGHI8ur1BKOmwaCV6DAMBlxtFfQn0GnFa/rU7sOn9jZR+50MkC3Ix94arUP/8"
    "yxCkMPnKC3Dijfep+b0tNNLVSwFpoddjYdktt7DDT76seoZ7lwyV0NLeoahiikEIGwBmQTLhULwdg5VEIDsuIyKwNCOWB0Xvf/xJ"
    "a2N9fR3/r/QX/q46w18/pk6dqgDAVCoNBSmF7WVyDkFMWZwTd+uMuThXlmXg4gtWIphXAGFZMJMJGxgrFXzFRdj/4wcxdKoLgx9/"
    "gu233YPy2smY8oX70Pb0Ouz6+CDcLV1ItbSi6qIVWPKnf8FVbzxN1Uvmg9waOrfvwjs33outX/8pkq1dMKIRhMsLsehbd+LKzS9h"
    "+ve/jv76E9h49R14d+XNOPHkUyicOwvT7rweyWW1iFsGOCf4XBo0xmBK6ciyZlR3TgcKn17EUtmCnBDCXlyWhGXaCBbDsmCYAobp"
    "VKMtC26No72jH27dBc5ZNkvl1TRU5evQjT40NjTaDXjSTnsORdOABDw6s8HFROBOW4hdbGNg3P6yXR1u1xy4LWrCnPqDxuzdX2P2"
    "2KfOGFyaBreuw6VrtkyWnpH4ciS3GIHR6SQoclpJbIN3cw6XRvC4GEJuHQesBML5IXz8p+dhtHdh8TfuU7t37EGF7kL73r1o37cf"
    "pfOmYPnvfohr3nkaEy46G1ACIhJD5+OvweIci+64CdQxoA80RAekcnfqzK38Prfb7ea618uFz6sJl86UW9eZrjFd0yDdLmYRKVMI"
    "4VGSpb2+8El7ja7733GTHGAA27O3qWv9y3+ewZg1Q0hLA6Sma0zzefxDuqYnE4mkKxzOY/fc+XXyefwQZhKpkWEIQ0JzcTQ+9yoG"
    "Dh3DWd//BtweN7r2HkDh2YuRV5KD97/yIzrFgUtvuwZ5UyfAX1GFwlkzSRFDx/tbcfTpl9C+cQeGD5+A4hraPtwJd0EIOWOroZOG"
    "3AljUTR/OsZfU4f8WXPQv+8gjjz2FJo3vIWmU014beseCFNA1zhKc1zweewdR+McpmVBSgVd51nEC3NgwYCje5ZZjI6rksFDcofx"
    "xNhpOm+MIeB141hLH6oqSzF5QjFa2rugczvjk0oLxBJpWyOBKegaoS9p4FhrDDIFFIVccHPupE4zuJnRgFg6QoXKkd3K6JjAqRmQ"
    "c1pxYjAM024W0/+qvvApAaOMESj0J8wsGzbk1ZDnc9ktEA5C3J6RAIYswMU4iqMGmod6cNmX78KOt99HqKETQz0DaN9/GHPvvQXe"
    "vFz0HTtJM26uw9hLliNn+jgM7DyA5mgE5959pzz4+AtcxazWc+69a2mOiac0TTukSISJW2OIg0OCBTy+Xp/Hd0wxUUlMaUTQXZpb"
    "+Hw533noz5s3/D3V5v9uzIA1a9aoG2+5ccNIb1ecSLo1rp1yu/zrplRP/2I0GpmpyJg0c/LM9CXnX6UpxpAc6odIpUEghCrL0L5x"
    "K4JjaxAqKMTHP3oQuWcuxML716DpkYdp00tv4eb1T2DmzXcpxUxiChg4fBjv3vlNHH/qVfS8vwvxxlboxQVIDkcRnFCJCddcBMYY"
    "XNyNjg+24cAfHkPlsqUonjsbNZeej/zFczFw/BjeevltnEgn4dF1eDRCWdiTFUNMGwJTxlegoiQPrR199m7L7CLC6eo1WS02OarL"
    "hizGnrKSTdI5TaAU3JqGHQdPYUxVKYryfBiJR+2dndnCg2AKaWGhYziBI6ciiAwI5PtcKAq6HTCyw2WVmQHcUY3QjCptBpCcvU6j"
    "clfJpIWZtWMQ8LvR0TsI4twWXFHIZovIkcnijCAVoS9mKjsuIgq6OXJ9dsxAZOM27bhKKaGIeiwT010BHD18DLMuXIqC2dOx/9Fn"
    "IY42w19TjDn33IqefUex8eav4uSmHZhy3WVUtHAm9b63A8e278LMuz5LFIuJk+9/WNTb27vlN69s+/DjA60fHz02+NiZi8YegJTF"
    "GtcK3S7vS1//zjNX7//k3e2cs0Mel+/Nwvyy7zz0px2v2BnO/37w/LemVj+1fThFuB8D9OPRy/W4/6aFX45XTJlbezJ1zaM33LGy"
    "7rFfC4/bxYyIhO714sRfnsdw/XFM//zNGGntRefB4/DOnwk52IQ9jz6Nkmsuxvipk3H84d+hYe0rau79X0a4dgqJ4SGIeBI5U8dg"
    "+heuJ+H3qU13fBdmLIXEcATFk8uw818eQcerm2BJE5Vnn4WJV9fBSCdRPHsyrG/ejkcbDoPa+mBKiQK3CwTAsOyJ9EnjynHR+fPh"
    "cWsAKez65CR0TbeFDaFs1+E0FSB7PcqsDJbMyBCDwUwL6G4bamwKibBPhyEVHn5+GwoL/UjLJEIBHR5dB4ghEjeRSJqIJUyIlEKu"
    "x4WykH1/QikoYbtxXu6BsC1u9KPIpFmVUws5zcdTACxLYM70MVh5yRIk03GYr27FqfZ+m2mbEaOQCkIK2IrVCpZQToziyHZJm31k"
    "WZkajN0U6GIMfl2pAWHRAZVGddrC2p/8Dl9/7hEcPutFsK37UbRgKoqm1eLwk6+C+zxQ8QS8BWH10b88iKatezGhMB9HXnkDCz//"
    "GbX5j49juHXwy0qpDdfU1vJ19fXmI4/tfZXAXv3a11eWXXzxl3unTZtmAXjH+TrdzZf4Bz343/Ez5FCMs39/oLaO3fPcu7379rQd"
    "XNQZ+553xbzCyIsbZNPBYzRm2RnwBIJoeWcTzIEBkGFiqLEV5cvOwJIff5M6nluHF596Cef/9keUxzi23vZlDDe0wEgnMemmm0km"
    "RtDy9haEpk/Ekl/ej5yaEmrdvo96d3wCqSmMO+9sKNJx6rWNAEzoJXmoOX8FEt3diJ44ifdefB1vbdsFr0sHI0JlbgAuR7nS5daw"
    "8vx5CIdDUMRQUpKLEw3tSKUlOIPji9u9QBnpXJ4VJslAVylLzisvzcNwNAbORzM0Yb8HeSEf+gejYIpjfEkBgroHId0PXbnQ0RFB"
    "SOcoz/OgIsdtu1KKYAoLHo+OksIwhobi0HXdHrGlbMltVFzFQeJLJ/5ImxIBrxfXXHG27Qq6OMJ5QRw72g5TnK4LNxoTZOKOwYSV"
    "sRMK+3QU53hsWV6nTsIZ4CKWEU2hzlQKtb4AThw9iWnnnYWi6bXY9vhzOOv2ayB9OsrmzcOU61YhPLaKAtXFtOenDwFJgdxwiI4c"
    "O4FFd9zARhqaZOOeA9Vbd2976887drbWAby2ro4dqT+CHTuOR5944onsaEFhYT2vqQG75RZgy5Z/nCH8vcaA+vrRY6m+HqqutpZN"
    "raunr1lnXxQtz7tvypI51smf/4V1l5chP5aCUMDk669GxcUrYA4Oof2tzQhOHIfqM+fhg7u/C3PRLFx59x3E/UF07t1P0dY25Eys"
    "RsVZ8+HNzUHbe9sQaemg4LhSdO+vR/9HB4BYErGOblSfvwz5k8cjEYnSwq/eSVNvuhqecA56du7Dpju/hXV7PkZMB3RGCHlcKPC7"
    "bJ9aIyRSBto6BjBhXDmkVHj21Q/R2TMEjRF8bhfiyaRd0clkXD6l/aayO7TGGZYunobLLzkD0Vgcp9q74dI1RxLKpnSMr8zFF29e"
    "irPnTcD0SRWYOakSZ8+ZgAnlIQwP9CPg5Y7LwqEUwJnCyvNnY+mSaRgcTNDgUDSLrWTMXoxZhSDYLp9UtryXxiQisQT6+0cwbVIl"
    "hiJxvPjGDkSiCQS9LpAjtaVzzdGvthc5gdAfNzJ1CvK5NQTdDAnDGXOFPcNhCVskMW1KDBomuThDWcxE8+AgVn3jbry/dRsi72xB"
    "y4YP0HfgBPTcMGbccQe17tuFfQ8/hbxpk3DGj79FWx98DIG5tZixaL448OTLepJk+uPBobdqAbauvl5kSHhr1tjnYH19vWppgWxp"
    "gfxHuUb/bWP4N6nX2lp290NH5YU+/33lV1+wIPXaB1afodjCu27A/ru/hz43x/jFC+DNLUSqtxeJrh4s/Pka9K9/D+v+8GeUzp+F"
    "hVdcDvLnQMvxUM2V52PWPbcBUkLz+zGw7wgijaeoZ8d+tDz3top39MFTnAd/aS6KZtcid9wYjL/kPCqaNxPRxpPo2rodp9Zvwt5j"
    "J3AQSejc7ukpC3nh1xjOXz4HM6ZV42hDK4ZHEujpGsKhY2042dQJQGHZ4lqct2w2Wlq6EU+msum9rAQVjeoypNMmpk6uwsUXLEIq"
    "aWDihDLE4nE0t/bC4/YgmTRRVBRG3WVnID8/CIDwxrv7wcBQU1mMwqJchEJe1J9ot8dLJUFJhSsuXoBxE0qgAFRUlOLQkRYkDcOZ"
    "6FNQjksjlNOp69RCrli5AJPHleLw0TZ09kUxMBDBwfoWtLb3waNruO7KJQjl+HGypScrPphJsVpSYTBpZRniIQ9Hnk+HUnDE0jkY"
    "t0cqSNrp3ljawqCyaKYniP7jrZh+2QUomDQWPS9vAA3EqK/+FLW9tQUDJ+spPjyE1ve2omLJAiz40l0UP1KPI/v24Jwv3o4jL77J"
    "Brp7i297+xd/+sUTb6YzrUL/3drB/7Yx0Lr6erkJ8AzPnvmTcFlxYcuzL8mqL99K1rZPqK9nALO+dge2ffYuRMjC9M/ejvKlZwDp"
    "JHZ//fvozM9BYWcv+v7yAoTmxthVK5E7aQyMoUEwpiHVO4z29z9ErKMT5mAEueOrUXHlcpStXIqF370HuRPHQEmFoeNN+OjbP8PR"
    "h5/GybUb0HOgHh8hhSFmp049Ho5CnxtnzJuCRQsnIRh0ITfsR9OpHvQPxDAciUMKC8uWTMHZZ06Hx+tGKODH0cZOKGW7H9JpbZDC"
    "XjgpwwLXONo6+yElYXx1MZKpFMZPKMfQcAwnmjpRU1GIqy9dgqDfC8MUeP2tPdh3qBnNbX0Ieb0oLsxDfmEQoRwfjjZ0QFjApect"
    "wpQpFTCFgVRa4pXXdqJ/IAquM6SFsEVUHBXRzBhnPGlg8aJaLD1rOnILQgi4dTQ29aJvKIHhkQQ0F+HKSxZi4oRKVFWVob9/BF09"
    "w+AaP62IqDCcFE62ieD3aAh6uR1HSLILj7BrGkIAhlCIpUwkIRF2uak4ZqLFSODSez+PLc8+i3HjJ9CCX/4AnTs+xtChI+j9cDdI"
    "0zHrCzdRTlUZ2vd/gpFtOzHtljqKdQ+Iwx/uyIsc69m8p6OrqQ7g9fjH7/7/o8awtq6Or6uvVxdWTVmqTR5za/rAIbPHNDyV5y1D"
    "22+fRu5nV1H+wAB2vvIWylddgcFnX4Z7TCV0KGz9zYO49I8/xxmfvw1d+w7jyO//jKb16+EuCFHu+PEEEPylpfAWhnHipVdRedEZ"
    "CE6pxsS7bkKoshRWKonjT7+EYG4BAmUlOPiLPyHR1oVgRTGGqwvxYW8PiOzKb45HQ27Ajf6+CMI5QeTl+VCUH0BOOIQTjR2QlsLy"
    "s6Zj2dkzoUAYGIzi9Xd2I5WynC5WBcuyoHEGJQDGOfLyghiJxOHSOU40dsKjaxhTUwLTMjFxXCmkNHHe2bORHw7DFBIb3tuLvYeb"
    "4XLrUGBoaO5BfsiPkqIgiosCcLtdGFdVjnmzJsC0DJhKYN2rO9DSMgCXbtM0CvICGBlOgjFuD+YIC0JJcNIx0B9BUVEA4Vw/ykry"
    "oCuGY41d0DTCqpWLMGN6NaAUdn18ArsPNEIpBmnZAz/23IbCUNKyrytC0Kshx28X3UgRpCRYzoCQlHaXa9SwY4yIEjTblYOjxxsw"
    "/4bLkBImNb++EWM/c4Wad+/nYVpJ9B4+Ar26BPPv/QLt/dM6vP7r3yNf98GcUIZpi5eIj594iceU6jsQi7xbCPAW/GNjgv9xY6ir"
    "r2XrUK9uGD/lBjPPtyj+0R4ttnCWltsXpc5jzai+dRVO/e5h0Pln0fSx47Hxuw8gNaYGoZJSjLvyPBRPGQ9XUSnGXXYB8ufNRvfH"
    "H+P4H/+Mtvc2k+byIjxlMrzl+ag6bxGqL1sB5IUBciHW1o4tX/wu2l/9AL68XIy9pg7Jnk50bNqO4jNmYXeOjmNHT8Lv82L+xEJa"
    "PKOaTrX3QwmgobkLxUVh5Of5UFKUC4/Xg9L8HKxYNhuSCCORBF569UMMDschhURxfhBXXjgXA8NRDA3Zo4dnL6rFpRfMR3tHL/oG"
    "I/B53Tja0A2vx4WaqnxYwsSkCRW2MqmCYwgnQQRMHl8GxjhGogYaT/WgKORFfp4LBfkhlJcWQlgKAgovrd+BpuYe+L1eRONJnLlo"
    "Ei6/ZCG6uwYxNJxAyjRx1hkTMH1yBY6f6IYlgBONbaiqDCMU9GBMeSnSaQvTplZhwZzxUKRw4NApvPrOHihF0IhwzaVLQIyhs6cP"
    "LreGwbiV7bfK9el2pZ5RdtqOM7sGozlz35G0CaUU4lAoZG54+iNIFgfp3Fuuw+bfPwYeiWHsxcvReuAAFv7zF6EX5aP2/IvR8OYH"
    "GGxtAx8ZQr+LsPTWW3DspXdYX3ef/l0z9dgv/gusy/8/TwbU44HVq1l9W9sViUQ8HOvpr8679CwpN2xTxuSJyAkH0brhXZpw7y3o"
    "feR5ShaUYMyyRdh43edQcMHZKBk/AVwCZjyB0PgxmHrLtcitnYzBg0fR9Oyr6H1vM7TcEIqWLIBpJJCKJUGKkFdZgcFtexBpboch"
    "TIy5aDm8xfmI7DuMg58cwjunmuH1eDG5Kg9nzKii5WdOg2kKtLT2QwE4eqIdpWX5CIcDKMoLorKiGFISovEE1r28Cb39ESgQCvIC"
    "qLt8CcoqCjF1SgWOHGtDTWUZLr9kEQwzhYnjS9Ha2Y+BwQT8Xi8OHmtBbo4X5eV5SKVs7tJb732C/YebwEhizowxuPrS+RhbWYST"
    "LYMYiRo40dqNwoIACgtCMNISxDx45uWtOH6yHUG/F/F4GovnTcKK5bPAOcekseXYvb8Js2orcMmFs1FeUYyQL4CTp3qQFgLHTrZi"
    "4thS5ARDGF9TjtKSMJgG1B9rwwuv74RQBE1JXH3xItROrcH4sSXo6B5AV98IooZNSJcS8LsZAm4Ow5JQAtm2DFMKKBAJIRFJC6dn"
    "CEhzzibDzU60tMkVX7yZGg8fhe9kF8jtxtb7f4baGy5D+ay5qN/wARbe9hkExpciNdiOtvpG1NatQrKrD0d27sjv2LXxpb2NrX2r"
    "Abblf9FV+u8aA60BVG06navlF41LNjRWDbqpLL8sv7V30/6w//IL4N61jxI+XRXPqUXHk69RwT/dhKF3toJbFvLm1eKdz94LOb4S"
    "1VNrwYgjFRlCuHYSxl93NfJmTMfQwWOo/+NfcOzlNxAfGoa3tBBcc6Fg/BhwFyFQWYbF3/8OuXNyYMWjGDp4HO8eO44uD4ErQAgL"
    "l587HR6/G2NrCiEl4eSpHigQGhraUVWZj9zcEJQE4ok0nn1xC3r7hgAAeblBXL9qKXJzgiAwOnS0GYePtyMaTcLn9VBxUQ6IKUyZ"
    "WImOjgF090VRUZaPhXPGw+tzg3GON9/eh/2HmgACpteOwVWXLABjCiG/FzXlRWhq6UM0EUdDSzeK84MoL86HUhriiSQaT7XDMC0s"
    "mTsJK8+bD0tYYIywcethnGzpBTGJ8eNL4NZ0VJeXkabr1NDUhqRpoelUD6ZMqILP4wFxQmNTB555ZTvSpgKUwFXnz8ecGWMhhcSp"
    "9l7s+qQBaVNgJGUB0j4Zcjwa8gO60/rNnF51ZFtFlAV7GIigSEiufO6uKYHcru7G5vzqs+fLnPFjaefDz2Pk3W0oOns2am9ehW2/"
    "eAj7f/YYtLwQpl68HFXLFmLrrx5F1ZlnUkVNjbVn7SvuFGP1BweG9+B/2VX6x2STzjjDGLp48VH9w31fiXnRqnUNHFHKPaN66SJj"
    "+KUNNLK4loKn2tTwcIxyzzuXhh99DtW31yF1pBHHtu9HeMYENH3vlxjKD6J67kwoy4IViVLuxAkYU3c5ihbPx2BzMw488xq63t4B"
    "YziGnJIClJ97JsZddRlpbheklcLBx5/Fh0++jN1egJxX5gYg0ybGjC2CrmsYN64UGmdoa++DKSRONLajsqIYBI61L29Dd+8guMZQ"
    "mB/ENZcuQTgcghASH39yAus37oUCgxASJxo7qSA/gKLCEHRNp/Fjy5CMp3H5hfNRVBiClApvvbsPu/edBGOEmbVjcdVlZ8DFgTc3"
    "fgIpgQljy1FSFEZzSwcisRhOnOpGSUEeivJyMKa6EFwTCATcuOLCRTANE0wjbN5+BFt3HofP40J/JIbWzl5MGFMGjdxUVVEEy0qh"
    "s7sfsYSB4w19mDimFNFYDM++8iFSNr0EFy+fiTMX1yJtSvQNRPHcqzswPGLXRwYTljPrYFO0gx5uj6IKB0upJKSUSkqQKUAjKQvK"
    "nnvgFtSJKl/oPfdAZHGEWWLZZ69h9Zu2gfcMYMzn6lC1cDb2/+4JpFoH0fjuFgy2t2DcRWdCNHei7WQrFt9QJw89+TIfsFLmoVT6"
    "hQVKUR1ARXV17IH6WlZXV8vqau2vqXX19I+YYfiHG8Pa+nrMfePd5LXTp+5NBr3HeVfvBSIntzCsWH9PY1OONaV8ILj7gEufP09T"
    "ibQyjzei8OqLceoPTyLn/DMoTwB7X3oNZu0EDLz4JmKJKCpmzwCRCyKZRKC6FGXnLkTujAkgcLS+twPdT76C2IkmWEoiOLYSVnIE"
    "oYpivHXsAI61d8DtsHWK/W7Hb66Bz++BruswUiYOH+sA4wzxZAo15YUgELZsPwK3xwXDMjBpXAXmzpiAVFpAKsLbm/diKBKH1+0G"
    "MQ6lFB081oKJ40vg83lI0zjmTBtrpytJ4rW392DHxw3QXDrm1I7FqpWLoROwfuMerN+0Hx2dA6gqKURpcR7G1eSisaUL0YSJI8c6"
    "UVqQh7y8AGrGFqJ2ShWScRM61/HR3hN4c9MnCPk9UArwuHW0dvUDQmLSuGqyTKGqqvNw6PgpmJZCV3cEPt2FxlPdONbUDk1nKC8v"
    "RN1lZyGVMkHE8MqG3Wht7YHP54IhBKIpaWeqYOs+h9wEU0h7NlwSmLS7o0BESgIjKQuKAZwYc3EeKy2r+qU+GKnrbetwLfnsFWjr"
    "7IboHMDSH3wdnXv3Yt8fnkfBhHHIqa7Asfc3ItrWAbOrH/G+Ycy+7nI6+s5mauvsyr/9e1945tcf7IxsceoL61Cv1tWPfmXqDGsB"
    "XldXx9Y5VeD/c2NY45Sfpre2tr3T1nno6oriC2QoCNYyNNRjpTz5+Z7X0dw5z3/heZax6wCskgL4wgHq3rgJhddfioGXPoA+djxV"
    "L5yBYz/4hRoO+ijd1Y+WbXtQOHMy3P4AhlpOQgt6ULFsCcauPB+F4yehZ9OHOP7np9C6eTuEInQOD+GZV9+BsExwnSHg4igOenD1"
    "ZWeirDQPnDMca+jAi6/vgGFKmJbApefPwdxZNQj5/SjMDaH+RAs0jaOtewCplKCJNRWkpKJp06rR2z+IvqEYOHEYpqCzz5iCKZPK"
    "AEZ2YH6yGwX5OQBTiESiaGrvg5KAzhmNqSwmv8+FaDKJhpYuVJUW0oxJ48jl0nH8ZDuOnOyAYQoUF+RiwYyJCIcDiMSjONnUgcL8"
    "XAgTCOf60NM3hP7+CLxuF2LJJCZPKMX5S2eBk814euO93Wjp7INpWpg8vgaXnrcAZWW5aDjVgWg8iXgsiWQijakTyyEtiaryQjS1"
    "9mJoJAJd1zGcsuzWdkUI+2w3CUTgxEGSlFIKkkuCg9cZTtonAyNibsbNqu/d822xaffCdFffBN/0cda4RQvYrj8+g9rzzsDRj/ej"
    "6YNtOGf1N1BxzmKYfQM4/s4WqME4JGOovOgsEsMRsX/7zpAv4Nt/W0lVQ8WgOfb8nLJJZ+neeefkBpZdmheas9LrLrqqdpL+r+27"
    "44t/9Dtj3eHDtmHUga+r//tjDP6POmLWOGnWqYeP0Jd6Bl7q+WTXx/0Hm+6IulhHiZU+FTeshZ5Fc62R1zdTcPkZUCcakDBSFJg1"
    "A+mX30PgyotgNbcj1dBM5bevQsevn8KuXfsRZ0DbulehjS1DMCcEzl3wh3NRcd7ZKL1kGfIXzsDAsQZ0vvY+3ti4DcdiEfh0DRoj"
    "FPlduO6KxZg8oQpKASeaOvD8a9sgLLtoddE5s7Fo/gRY0m5nKCnKQ0FBCEcbW6ExolPtvbAkMKGmDFwHpk0uR0NjF/oHk1h+Ri2d"
    "u7QWUkm4dA1vvXsQr761D4X5QZSV5qK8JIycoBeNzd0YHoxSe2c/xowpxKSaUioqCtPcaeNQVliAPZ804vX39yKRTqO0OAc3X7kM"
    "RXm5SKRTWPvGNmzZXo/i3DDKi3PBuMLECSXo7R3GwGAMM2qrceVFC5TP7SKX7saG9z7G3vomKEhUVxTixiuXwau74HVrNK6miI6f"
    "7EAqZaKlrR+MCONrSuFxaZg6uQIt7T0YjiYRN6UdM0gg5OHI9euwsu0bNrjPbv3mIDAMJ23AMSdiOtMif3p03b+sf/Rh6YnGV40I"
    "S5554zXs2Ib34OrpQduBo7AsiXErlqL2kgtRMG8qSKWQGhhBpL0b3jPmYtyYGmx/8Q2VIMylkOuOQGn4a77S8F05Y0uvK5k+YWXV"
    "jMmXBkqLbkj0Dd127Pt/uO5i5plz/fSJ8qWOzqZp16wRqwG2DKC/J/Dm/0ifa119vdoCqDVr1uC53fs7rpkxvTNQUdJltLeeHXG5"
    "qnKKi4aS+4/7fGfOVtaOXRATx4KDKHXoGMJ1l2Hg9fegCkIITB5LIy9uRPF1l0I2tePkk89jZOYktL7wBozeQQRrqpGTmwfd70Vo"
    "fAXKVyyCWZqHlzZ9iLSS4IyQ69OQ6+UYGoxjbE0ZOnuG8Pwb220GkSVxwdK5WDhnAsAVGps60dE5gOKifBQV56Egz4+jJ1rANTed"
    "autTnCmMG1uED3cdx76DpzBzUg1WXbIA8WQaupvjrfcP4MNdx+H3unHkRCsKc4MI5wZRXpKPcDBIDc3dGBiMqKa2XowZU0I1pQVw"
    "u7zY/UmTemvTPpjCRHlZDm5cdRbCfj+EYHju1e04eLQJAb8b9cc7EQp4UVacA03XMGF8BQ4dbkVO0KumTqiAS9fx7uYDtHP/STAG"
    "lJXl4IZVSxHw+DASTSBlGFRQkIOx1cXUcLKTDEuh8VQfmCKMH1MMyzJx+HgbhqJJxAy7MVEoIODhCHrtmEHJLK/NBh843bojSdPG"
    "DBC4DjbQ8MGHj0QqXCfcnUM3J1q7w/NWXaJODkeo9YU34evrh5pQg/O++SW8+LUfIFSag8VfuQMNh49h+Ggj9JoKTDzrDNr79Msq"
    "7tfyQ8X5+ZHhmG6EPCJUVWBxIyWGpRLe2nFq/JWX6mNWrCgsnjBh9vCRw9dv/953VtYtmjH45Y7eI1uEVGtRx9fh/23Yh/8PBea0"
    "GmBfam0+9FpT47ZLigvnDUGanp7hg5ritdqsCemhzdvhOnsRXC0dsISAXjsJQy+/Be2MGeSSglIHjiFw+TlIbdwFd3kpojWFwONv"
    "4L2dB2AU5KHj6XUQATe4zw0PI7y/bQfe2/wRXLoOFyeU5LjAGUPvQByNzb04WN+CZCoNQOC8s2djyfypUFBoau3G2te34+ixDhTm"
    "56GoIISCohBKinJx7EQHCByn2vvQ1tmPvQebAQlEIgm4vT6MG1uCNzfuxeYd9Qh4PUikDUwYW4qFc8dD0wlCKNSUl5DP51PHm9ox"
    "OBRBe3cvpkysoEPHe9Sr7+xB2jJRVOTHjauWIC8YQNqwdRN8Ph3HWzpgmTb2//jJbuTmBFCUH8KG9w+is2tAtXUMIiUtdHYP03tb"
    "jwCKkJfnxXVXLUE4J4BUUuC5V7ajpa2bJk8sR27YjzFVJag/0QHLlGhq70XA48aWXfU4frITPo+O4ZSAtEUfKOjV4PdwZ+TTJiXa"
    "Qie24LgQQCRtKUVKOaMdA5X5nkd/8fqO6Pzi3Ip4V//ivMoyKzB5PDv45iZUhL2YcFsdgvlF2Pqbx3DwpdehBdyYce2VCASDaNyy"
    "E3NuuhrN722ihoZmoSwhwy4Pxo8rpwnV5QwHG1jTzoOMK4ta1r6MwVOtMmdGrZj9tS/IYK6vov3drdesDBdO/+o3v7lj5cbfjawF"
    "+Lr/hxPif8oYsAVQa1HHp6oj9PXBkfXXX3/WBtY4uFhzeeYpv2eX1dBcNlJdEg8daaJYaQkP+oOI79pN4uwFJI81A5ZJfP4spN/Y"
    "DGveJFhKwHfoJAamTcSkCRNx4jf/iuHCEuxe+zZ63tyCp7ZuQ3QkBjCOfL+O/IALAoBH1xGLp51xSQtLFk3GirNnQlpAV/8Inn1l"
    "K1IpE5xxNJ7sRHl5AXJz/cjLD6A0PwfHGroAIvT0DUPjBJ0T0kkTnT2DGIrEsH3PUfg8OpIJA5PGleP6K8+Cx83AOJA2TRAYjaks"
    "gsfjRUNzG0YiMZxsHcDRE12IxVOoKA/jhlVLkJ8bQCxhgIiDc46SoiDKy3Nw+HgHpLANpKmtF/39w9h/pAU653DrHO1dg2hq7yeN"
    "6ygtCeO6KxYhP9eHlCGx/p1P0NDYgcHBYUoJA+PHFqscvxs1FQVobumDaZo43tyJ4ZEYvF4NSgGRlC1XqwAKeTnyAjoIzO5NYvZ0"
    "HOOw+5RAGElatjoWEdc4G5o9Zs5Db9bXmzNnT+kW3YOfi/ePsMXXXUyNuz5Gsq8Xs790J4Ya27H32VeRA8LeN96Fp7IUMxbPx44n"
    "XsTUVRfD6uzG0f0HKTSmlIYSaWr56Ch1N7XRwm/eRZMuOpfmXruKisaPp7HzF1Lnno/ZsRfXseLLzhdz7/uiGNqxd1rjug11nz3/"
    "4k+uPX6kyTGIf9zY59/7uAbrxAOAekFK/vnfvdFTNG/K94zivHt5c8cnWsDn5dLqp2gins7NUbynXypdJ29+HhOdPbAK8lSssw9I"
    "JqAV54P6hhEx06CCHLj6hpDrDsFbkof4vsPYu2Ez2tp64XK7oJSExkdflpDKQT4qMM7QdKoX/f0jiCZSeOmNHUgk0gjn+JET8iNl"
    "WHjhle04ebIL0rJwvLELUkpwUg6p294VvR4NZjqNXXuOwuvmSCRSmDC2DDdctdRGTWr2afKHJzfixMkOpaTAGXPH4ZLzFhHTdfT2"
    "jSART6KqIh83rDoTuTl+GIai197eS8+/8hGEEEil0xhbUUo3rjobbl2DUvZc88ETnfB53SBOBFLQNQa3rkFIC2Wl+SgtCsM0Bd58"
    "dx8OHDkFn8cNza2rjz4+rt7fcgBKWCgKBxAOeWEJy1nclJ2Ntom+kjLgNHv0QToacaOK7zJLIx9lSXHGkaxyKwDq4a0fH9BLCzZ0"
    "Hmrg3Q2NonTOJKCyHPnlJTj4wivQLANEhLKyUkxbPBfb39+Mvp4etB85hjFL5kOTCoKRqpgzSUXjCZUcisCyBA5u3Ipnz6nDxz/9"
    "VxTOmo1zvvst5Lr82H79P7H3nlnHz3/9GWPyjVdVNr33/rtPLjv33muIxGpH5u//7GQ4PbBeB6jVALvzQH309VPNuz87c8aRrmTM"
    "F9K1Q0ZXz/JERanM6xlODowMseC8yZa+5xBPja0i5vbAVd8A7ZwzMHz0JNDRDcydjtxYCslTp+BaMhuRnfsh3BqOw3RIEoSgiyPg"
    "5lAOSCuDmOcaQ/9gBJ1dQzja0IG2zn74fDquuWIxZk6txqHDrYjH0+jo7kNfXwQfHzgFl8YdYFem2ASbPMEILheHYZqYOK4MN1+7"
    "AgCDrjM0t3Xjude2Ix4zUN/YibygD/m5XlRV5SMQCuLY8VZUlBbixqvPQjDkRipt4KUNH+NwfTuGh2LoHRjB1NpKmJaBovwwxlYV"
    "4+iJdhimAGO2+yXs4RuylCKpFDgjNJzqhpAKzS09+HBPA0gxXHLufJQUBNHU0oXWjgF4NBf2HmjFweNt8Hhs6S27hZuDAETSIjsg"
    "5Hdx+NzcHvoRzswEbICxTeCzU6vSBi1xjbGhmfNnPrR+y14TSuGS88883FHffItuKW3qyrNR//pGqp44DpVnLsBAewdamhpRNns6"
    "Jl64DIfe2QR/Qye0XC8mrliCw2vfQs9wlMjtgs/lpmjfAKqnTwT5vWh9bwfk0AhypkxA89tbcPjxF1FYXored7eoyP7D/Kxf/EDw"
    "3AA1PfvSxZ+bP0v/YlfX+5CKLVv9n0/FMfwvPdY4Q1lrUccvW7++9StHjt01qbzs18gPvxLr7XsqNTiY1r1eI9bY8qYyDGbmhCRP"
    "p2FxgvC5oSUTEGCQuguUtiCZLa6hE0FJmSVacLK7OU2hYDi4F1Nk/l/A7dbR3tGnmk91w+9z4epLF6OyrAAF+SFce8US5IX9GI4k"
    "sPfQKbhd3O5QFXYa1qZUw34+aT+fAqF/IIrOrgHkhH1oauvB0y9ts6fenF3b43JB1zRYIo0FMyqx6uJFuOKCBZSbE4BUCi5dQ27Q"
    "a0MTvC4ca2jDute2g3EOznS0tQ/BtKQ9ZKPZYGA359B1Dp077gsxhPxubN99DDv3NyHg9WDposmYM6saZ51Zi8ULJoFzhne3Hcbh"
    "E20IeN2AY0SZmW7KoAAy80oZVSKo7KQfAGcc1RGIoeyYBUbxasBSQFuz7s3Dgcrin9Vv/VizlBK5MyZg45d/gNhwBOf95JuYuOoi"
    "eCdUQSSTOLl1HzSmoWXHfiQ1jqlL5iM1FEE0niJLWAjoOkhamHbhubj2tUdR9/YzGLtwFpiZhAr5EFq+AKXzZxD6h/DEohWsctVF"
    "mP/r1ebw4ePffXHRvId+4NLlmjWQavVq9o8Y+/zvR9WAAtYJBdA6gJ352POdILrmnSd+5h/4zbqISwaXmcl0VClFBteUTxIiBJiG"
    "CU3Y2HS37oJOpo1GMU24OQc5Mo82Q9QW/tY1guZo1NjtziIzkAZd16E4KU3n9niCg1n0+d1we3RE0wSPmwMWHGoGwSK7hVmJDIzY"
    "VscBEXoGYnhy3VasOHsGNn90GOm0CeKEgEvDqgvnY9qUGhw5cQq9gwOYN2s8pk2qhEf3o3cwgm17jmDFWVNx2YrZ8OoebN1ZD49H"
    "w6EjzdA5Q0lBId7bfACai4MxZ892wMPOqJ0tOuIIGGqaPeTj83swe+ZYWIYBzcMwZ9YY7Dt8CoZhG4AlhK14KqWzuDMuUlYUFASb"
    "mgFoIMZsSh8pSLJxOCrrV5BtEMR4LkoZABQBqk4p/mjzyZ9c68tbtuvJ15dNunaFseOjI9qmr/wAC+67FefcdgMi0WE07dgJPjKC"
    "gqsvQOvOfdi39SNMvORMuN7eCCYtlC2fiVyD4a3fP4Ml/XHMXzwTRzesQ+/BNoTH1eC61x6FIdIgRaicMhmbf/UIXrj8BrrnnbXc"
    "nxs0dt317bsenzwl/6YD6z9LVJXctHSptnzLFuv/7GT4a6O4xs7e0Vql+AU3fz1+/b7dXy26/ZJl7uKCp3dLY3g4GuPxRFIxjw6p"
    "CMQ1hF0u6AS4mAswBdKWhMfrRQiAnoEBIzOF6ZAkJGwhkSzyxSFDMEXJRBpPrtuMA4dacLKxGw8/sRF9AxFoHBCWzPb5k6OJYO/K"
    "Glwah0vncOsaXDpHKOCBMC28/vYepFIG3G6bybTijGmYOrESxxvb8cpbu/D6u/uw7aPj8Lg8GIkl1Evrd2DL9oN47e3diCUNrFg2"
    "A+PHlCKdNhHwe3H4aBve//Ag3G7dJmUrpy1CZk4r24ilkKe9NnuxR0ZieP6VbUinBQb6IvjLc1uQTNkt6Az2dJ7LOWV0zuDi9p+Z"
    "QWtyhv9NS8J0OEw2SM35fSIjFk4ZnhoYAV2DgwyOazzVDqyN5TdfeuPRPfVNZnu/q2jVMstTko99v38SOx95Bv78MHqa2xBJxpEz"
    "vhJVs2rxyXMbEJpcjqLyYvQfaMDBZzfC1DjO/OadaP9wO7bcuxpDTV3o6+xBX2sXfHm5OPGnF3DgD88gnjCQU1CI3LYhbL7oRtTU"
    "TtTm/PnnxkhnT90TE5a+9+Y9d4xbvmWLpQBaW1fHT+cNc/wfPjLxBACqA/j3Nu5IvX7gaHMipH+u6VRrfkNnh2xXJvXBwmBPH8xU"
    "Gk1eDXlpgaGWdgxOrkGgtx+xwUEcs1sEwBng1gk+nUE6xSO7gUBilI5CJKR96FtS4siJDhw50QHLkmDMvmbLwzqqODIj4uEMzctM"
    "n47tu9vsJYAxR3bWOamaOoYQiaWxcdsh9A9HwHSOEyd7kEpY+HD3UTS2dCEY9KC5bQBdvTG0tfbj0NFTIM0menPmqIAqmcVKZha9"
    "Mwqdxb4ohwKuHCAYEcPgcAKn2vtw6FgruvtHsrMYyAqzSFhK2q/JlDAFEE1b9kZCgNfF4XfrNvQAp6VVobLTdSMpK4MX4Ezjg6uu"
    "PfvBJ17bYikAy51Y8et7D0TOnzPrzeZPjlw4/7yFRUcamozc2TNZ94f7qffYcQwcP4XkUBRjzp6LwhmTcPKFd5E7cxzyq4pxZMcB"
    "uJiOjr2HMI65serZP+Lg7r2oGlOJkikToelulC2ZjU1f+RE6T7ZhwtUXYu8DvwUJCXCOXX98AhVXX8Tm332r1bb+3Zr+3Qeuv37e"
    "/OEZ7W17M5XrOoA/MKpa9n//WL0a7IE1UP982Rmzdh44vmUgmvJLKZXijPxMkiAoRQQIgptp4EohpTNyK8AyTUQtqbyaDs4JRWEd"
    "FWGvsgQRY3YKUJKNb2eOkJ+UgFQCkqTj/jBojNn6aJpzZEoCA7cRKUw46gYayFl4ghyXCQQmbQykyGReHKp1yhDweuxxSQkFDo5k"
    "3BY11D0EYhKkGNIpe0HqbthSrozAodvdogxQzM7cwNFcoAwhw/ldSo3mSzJUQFIMpiVAzBYClEpBgwaWARVzh84NApO2EGJzXxRC"
    "KRhKoDzXhzEFOTAthxLiEAOVtJ/bEhLHu4eV09PKAl5PZPLEMYt++PqO46ezjOrs9Ka4fvbs6vKinHUTp1bM3/nBHunuiFt+M8WF"
    "sECKgVUUUflZ82AcPIZIOo4Vq+/Es/c/iI76k4h4g5iUjOKKlRdizsM/w1P3fBWB9/eoM75yF0394q3Y/8IrGGzvwOI7b8Pbn70P"
    "5NUw/c6bceKJV3Ci5SRm33cLzrpkhVh/89f05P5j8BWXbRnQtV+5fv75d28957YUlPrfjRn+s8fmzWAEWLd09S4Pe1jQErqRNqVG"
    "IHjcXGVUeaAxKNgMH5+zICTToSsLHheHUgoVhTmYN7kUhgHFSSPOCKSrUTHCzIkB4YgBMkiRiQYVyHlXmOLgxKFIwiJhg8JIBwQg"
    "pQXJHDdBEjgYGFewYMcmDARp2YYiiSCcBU6Sg0kGCQHSbbiXFARlEixTwJRpKCZtfTnmAuc6QBISNuiM5KiYooC0K8HKxj4yblM8"
    "pMOFzcDQQPawEIHZoiYCkFIAXADMxldCEoQlMbKnESnTQtxUKC8OY9GM8UilLBBJR0NawjKclg0lMJhM03A0BQayhGGGO7v6zlbA"
    "iUfWg2cwLusAsXrpUm3N1q0tK0vmLPOGhn4w75z5d3/y+oeulJYL1dFrFJXnomDhFGrcuoeSA8PEBgZo51Prseyuq/D6/Q/BiCTV"
    "fm8I4fXvI/j1NbjxoV/RU6vuoL4jR8G9HoQK8+EiBWZZyK0ohrc4jOpFc1EzZyHynnoWe+/+HsqHh1nJHausR+58QC5vaV+aE/Iv"
    "bb7xO/Wrq8s+Cofzt/5fGgOdroVw553zaPPmj+nGOdVm0lS2/+rgEsN+HUnTxsEbhoSwBAwpwTUbV2G7LQppSwKk0NY7AqQMu2pK"
    "BM4BIluHgBS3A2obXgpBTru8ZCAJm1fHicDsLs2MvoGA7ZdDZCjdCuQE0KRsHQSQzEZh5ATvGVdMOG35Gjg47N1ekq0jrUEDk7Yh"
    "SyYgYM8UQHCQIqWYtNV4nHlnygDAuK3CYAfQEhl/xWaTsmyax9ZgyJD3Ro1JknBcHkdeV0jVO5IkAQlTSpzqGAAlLXu4h4SjKmqf"
    "rMJSkEqgL5JCypTEQXBxIIe7GQFqaeDTKcwHNm8WtevW8Wuvuzaxfp366nuPPfh4aU31Z3c8v+HG4y2pYsUtjJ9ahamFeWqw4ZT0"
    "BLyyf3+96mbA/Nsuxb4n3qbk0BB2am7kPvcGsaJCdfMLj9JTyy5FyeofYe+rWzHYeBKHS/4ApiywgAfNH+5B9bnngwcD8AmFd3/6"
    "ELVUFOG6r97BP3p3V9q3fTfKA3yKBTY1FolW/I+5SSrT1vjv5XMZU6frCJwOhLpuRs098Vj0d4ZUpoDiAV3HpPIcWxjEWW/CAkxp"
    "Adze+QaiaRxrj8Cta7CUREmOjsqwTwnLThkqKCimIEmRUnTaglJZDhEpm1wHSMiMMYCBqYzYhyM6qJwVRgpgdiUjI7CqmMpmCMj5"
    "XvvnVFZESiMGpsjekR3j0SQHt0hJBkiyJWohCZB2SCdIkGLKUR5lWRoeMqQMB/qV1YpQdnYIzCZtkFSjrXbM9rBsp1Fkpa24YhCm"
    "VMcHYpBQZEqBirAfYwpCMEwJwYQTC9knoR2nSDQPxJC2JDiY5WLMVTl2zDce/mDdg7/6yg99c0IViRNdXWJiaWn2Q+6rrVdDG3PZ"
    "nY88YgJA9OTG4q/d8t2LYrHI8ikTxsxqP9JUkYzHw5OWzWUyEkHbpv3wzp6EUHkxho+142RzKwIMxryRuOvC3/1YeKZNpNdWXgsV"
    "zAfzuLDkpmvQsv4tuMIhBKfXwhwYwfirViKdSuBPX/kOjrV1obaqWl129SrV7XOpvo8+FPlIJWRR5cp/iDEopSi7H/4NEkKrsZot"
    "+0uNC/64lhMo8qbTwp9ImzkT5s0TP7/nztsa6w99WXJmWkLxoFvHhJIcWLB3fU1xe8cle7fVOKFvJI36thFonGBIibJcN2ryfRAG"
    "2ZEgc5YzOTJHGefaoeLZrjdzMlGjuztz9l1Fdr3C/pFRzQNn8MuRos1opylHQ9p2V+RpfFTKypHb959JzWqCKS4JimFUVAQEpRhJ"
    "2EZjN8fZhidPEyaRjjFwJ+uVKRKMkvJPMwZFzsskSFsIzjZcYmBgsEyFE31RZUHCFIJq8gOYVJyLlCUc8XR7Q4DI7HMKJ3pGkDQE"
    "dOJSGKZ26fU3bbj+3nvfGurqkrrHHVGkJXVdEySsYSGMEcMwIQHNisXM2EjMACG56IrrogDEW48+GuAwCo7s/jgv1tPjE5xcOQW5"
    "WndLVzTFWfSiuss8PU0txvH08LDvgz1/zm9om3fFW8+aO/bt5id+8iCuePhXqDnzDBz446M4tWsvVv7pD2ApgV1/fhLHTjQgqWvo"
    "evN9DKZNlU4LNa92khy3dDZ19XY+t+TyWz6v/XfcGyJSp//pGAbbvHkzm5yb6za1hFumXG53QPMwFw8pxYt0Tc8lhSLFqBQkg0LJ"
    "HKYozzKkL1xQwGsXLq765ONdyhcKOhpMKivOAQCmdPxkKAiyl5g8XWjNSfFxziA47H2YJBgYpCMOmBEGV6dhGWk0LHWu02kLn0HT"
    "FDLrJ2NB0hFjzparMiTUT+0Izj2x0UqLymg8OEblaA4qRYqk830ZmiQjx/HOajXY9wWyDYw7LRJ20WzUCthpxqAyTRTOnmX/blsN"
    "KGOkShLA5GllM9vQkoaJlGknGrI5VEFgdno6+wqJiCWTKVE1pXZZQVnlfLc/YDKuGZDKIkZKQUWVVFElpZLKspQpohCkpDRVV8Oh"
    "mBSmMXXhzAFpqVNTzzijnymKwqU1UsgzUFo6IQUgTURG5t7Wr3/66r13r9605fYvj7lk8/OWduAYO3jfP2PcB69AD+ep6rMW0UhD"
    "I7o+2IPh+ma8vPYlLF++BGd95S5s+e2f4HUrfNJ0SvQ3HPWOnTV5/7RrrjH+VmMgjHb/KTrtHdu0aZM2syroT0h3yKO5Av2tx3wz"
    "x1eVMK5VeFl+Ptd4CFAhpeBhnE8gYiUKysWI+cGUWwEMirgwBbmDOTyvuASGYSqfUw7LYNE1MNvVcPzhzF6bUZzJ1EgJDtPItPPw"
    "3GGESrsR00lLZv2YrDYUz3rftvsDRx7KSSo57gSyguRZt0hlDpLTQL6wpaokOcUslblvO3C3lTpt1nzmVYIR2QRt59cqlV28GZnn"
    "Uckqpy8oY8wyc6uZuCFj2KedSkTZ58taIsFhxtr/ZjlSRMxRLQIhu9HYH4d9CtmofAJxZLXhADtVyzTdw3TNyzQOXdelrYolQcSU"
    "UoqcfULYdGMCoCxF0oBU0rJMS0kalkIklBCWZaY7ZSLZ1F6/d8BIit6TH33YYqRT3f0drfEzF17Q13HT8dubH/zjy7vvvj90zp9+"
    "Ln997tVs92PPon3bLnLl+lEzdx62rv45XAtmYUmoQH2y6SMy4zGcdc9t2PfYC+pKwT39pfmHuktynlHI5k3+lhDAXvi5huF2F/hz"
    "PMFAsYtrfpfmzifdNS6gsVLOeS5AecRYKQOFFMHLGLkAIqWUphh5oYh4lhqtiGwRb6VsH9xSSjEie4KZRmubjovhaJthVEdAOboH"
    "DKMtBRlsPDRmr1E7VIBwFkRm0SvnZMkYyOkiPKDT3Cln8Ugox04ch8o5IYW0+3kYEZQjOkhZiSv7fhXZAC5bYDCzsO1sFFO2TKV9"
    "2gnbcCSzq9zOCSadGQLmXPvUueO8J+r0f1CjNG6WtTgaLS9nFIGypyGzEZOEbFsGJwafS7eVQZ0AWirb1WPKdvUyb5AigBh3hh4s"
    "CSmUtEwQkSKiLL589ERkmfiRK3CvYpJ0TVMEFrKPMjKhrPEAzhBSGMpUMWla7aaVHsmvKuttbW3su+XuO06+EI//ec+DD91X9vu/"
    "0BXPPYQ3rvocJieAqV+6H5GRARx1SdSUl2DirBnwPfGs2r/3CFE0RguuWCEPbd6drHLxB7+77u2+CQD/L41hbV0dr77jjrAnhxWE"
    "guFSnyc4Rve4pzKNTWaMvMRYkEBBAulEygtOXihwRwyNOV2PpBQIQhEpRdJWJYJUMrPaSAkLEBaZhkFGWoJzzc7zcw3ENSgI2zgk"
    "spkSUgKMA5xzaE7fjiSCy6XB49ZhmE6AafsW4M5ACpQtAqKYyvbb2IqZZO+uLBOU2suCq8y5kDkt7A+SmF2EYo6qJjnGALKp3FKq"
    "UWVNEp/Wa4YEmAQYA0kGprgdLzinHikOpmy9CAkGxaRtsJLbvwcSmZMk485lVYgIo3HDabuZcrJumf4jYqNgb6ls/TpN4zad2/Ht"
    "JDE7k3Zap2rWXIiBGAfjCpxzmGmDhGUqCIuEZZKty+hoaOHTrnXGvZQOwM9OWGQaoEgppVxgXAHKwzQuwZHL3e4yXbpNoYThCYYT"
    "sUQqcs0D/3z8yf6+I++s+e3Mm+ZNt85/8Ifs/ZV3YNzB4+h1meiXAvEXX8Gk2z+P/JUXYeYbr6jjLZ0i54X17klnLXl51XNrH1u9"
    "FNo1W2D9uwE0EfC9761my2bVhPLyKse6Q75xvoCvyh8IT9d1by1nrBxchRScT0uRJHYauF0pe4+Rjpq3ksy5TqfvuDbA105NCCmh"
    "6250tbXigS/cTo1HD0MpjqDbhcnlOZBkv2skGUg5bhIJaBzoGTFxpGUELp1gSIXCHI6SHB9M066S2uLhajSNqGzFGzCBDKCRlD3G"
    "CKZgKQGlpD0AT3Y3ZyYNabtY3Fnk9nNnag22rTjBurI3SaYYGGXSmABBc9wVCXDlxAAcJO1Ks2QWQBIkbCMRKpN1EnZIrzSnzibB"
    "ubJrF3aw7TBTJTIFBo7RgDqj+ikdXXXGMrGGck5fBksAHYMxSACGBCrzvZhYFEbaFJAQEMqEkoAG3daK4wqH2vuRMAASwKRp0/GD"
    "P/0FJRUlyjINMMbs9yrbymcbg+002lGZE77Ym4ICiJhzkgDIeL+jMqbZCBKKuKPdKyRk9yNXXJ1fcPBw4JLN6/DJGx+wV//5Jxi7"
    "8hx4ckPY/Mx6NVELYsHnb0Lb0b0KR46awzkFopTzi287evTDOtTxdVgn6N8LDj5YvVqLTywOlhSPmRYIhGo8If9YXzg4x+3yVjLS"
    "gsRUSDHlJUcjxl5jyi7G2k6tw0yXlKV4qqysvZN9yohuZDpOCVJJuD1exKLDtPnNN9B+shXBgB95Pg4ThqODoAGSQSkBSSaIAfGU"
    "Qt+QCc4Jkiz7FCENJO3pLHLSmPauyJyFD4Cs04LlTJbHTjlKZQ+5MKU5qp9ORuW0BW1TIoS98Qn754mRk7KUIDi7OxQUbOFAUvbv"
    "UqTsFcSQfU3CtKCYAHHl/KwGBeZkmCwncuP2c5CDw1HCOcH4aXp08jQ3j7IyuXBipoz4iv190nlNHETcaWgUMKVAvs+DwmDA6euy"
    "IJTp9PC4wMBBTKE/kUIyZaC0shorLr0KgVAIRirpCChCEXhWFiyTZCDnhrKxJ9mRuN0UydXpnbOnJ2dGDWLUSJQk4XJrsvNUQ3zt"
    "isvzplWUaRN+8R38+Jp/ouRAL6796uew560PVUd9G84Ihymv7rx4dPeOoCeQ98/Xb9r+w7V1dfwaR9qZ/m1bxGqWNzioT1u4sCSv"
    "uHiaPxyqDOQGpnmDwRmca2FGzMcYCyouvQCzq1qOqnbGIEgpkiJTicqkMDIdL6elYp3hkGyZgRSkEGCckzcQsKnUChDSgoTpBLDc"
    "NgaSkCRAsF0SjemO82E5vqzjUjgpT0VOUw64s4uPCoVTZntSmbNajjb/KOYsfGELjtuOEyDZp59XMfs64FyTIOIOfAvOySad+IQ7"
    "KVuRiaYdA5dOalc6cxh23639zjkni8pG2E4UY0fPLKOwmNWqsls3spscY6e1b1D2dFHZji3mBP+nXVcEJe3rCsJOBQMgNXpfTM8k"
    "CQipaALCEiBOoEwSm/inG7xPM1JypLEyaiv2qcts59R+OVmnzHb72GjUYb9vSoGEMNKmy6MPbnvuuegnd32jNnzJuYzlh/HOX56m"
    "8rHlauk1q7Dt4bUIKFjFuW43n1f7gnfX4S+caG0deSD7bvw7xqAAemD1ar5wfJ4vGKiakJubOymYH5wYLMidr+meakbMBUY+4vAA"
    "pBHxjGQmSTiflAKRVKSUc0oQsqeBE0Q5Mab8qzPJCVSlICmk49JkhLtFdgfDaQEwTtM8theidHp4aFTanDKLw/HrnefN/EeZ4DIT"
    "wjixRLYfUxFAmYUHZyFQdtFlCleEjPRVZpHZYT+yv0tmr5FzXwT7dWb7i7ICbU61mZhzVRGdlhaFykyfOS3dpznd+FRi1+meIso+"
    "76fSy5lnPC1RoZwcGjk4DKeS52SeRl+rE+05WSm7dQVEIOYsbmdFU/bjdd4TGk1ony47RE7hgzL1KnJSe0rZqTbnJiSUAkkLAoaU"
    "MiUNczg5NNim+fnWp669c4Xad2hF5bfuMhqefYlvPtGAi2+qQ+6gaSU/3OW2ioK7rbzwqvt2725XowfQfzzP8MCaNWLd2rq47Fre"
    "RIAgTcalpoxgMNdwuX1VDKRJSM6ISdiKpNJODkIjGy5lC6NJyTKxnDMsSFCKlFT2JpBZ1KP1Ubu4xGAH0NkdzLITX5nWB6curMj5"
    "DBVGd8GMMcAeYrfXivxUctje6TMC4pkFyBy7oIyBKKUyOXj7cxo1XnZaykll3Txmpw/tZGy2rZRl1QSdAzSzyJ2fE5/K/WfL7Jni"
    "WSavSmo0x5o9aTN5WvZX+W/1bzaZ0aJgJrS2n1ll09Vw9q3TTI6ddo0ySebRRe4UWUfXNVh2voeyiql/HcZnqzqnFymU3SiQbVpQ"
    "IKaIIImYtDdSm8ehSAlSwhJCjMi0GhRpYyA1MtKeGOhpEmZkX+XKsw801Z9Y3LNll3vaBWfKfQ0NrGX7LjM+ZrKruqq8w5Ofe/uq"
    "Le+1r62r4+S4R3+9HX+6jeK09NzeRx7RkoFAQA/o4VBhSVUgFJ7h9Xqmc482hjQW4lz3M9I9BKWBSRcxcgOkA4xJBU6On2BnEe0E"
    "phSCgRSUFDSaWHDaDJhSKpNlks5BQ8IpCHEw4k5VTGUHW0ajMABKUKY/J9OmYB/RpLL1ZnVazwQyrlo2mU9OkWi0VUTRqPvkfCTI"
    "fvBq1NzVadMUSlLWZyc7ZLZPskzAa5+MTjzpZD2dEyujZ6jo9OGx7AlmJ4RGp8+ICEooKCVGB0bUX99T9t6U41KRAilb0fQ0Oa7T"
    "d/LMws64ZXSaoGLm/WajXoud2soYnyM296mRmex5qbKn9GgZ13mXskcUiCBAMCEVkYIhhOoV0oxaRmpYmMZJI2qcSo0kelJDQ63J"
    "aGtz5569I5f+8uGBP85e8KJq6byq6u661K7Hn4McTnjGL1gUHawef/lXH3to0+lxwn9qDP/VY9Nf/uIJ5ebmuQtyinw+d47bF8jV"
    "dW8BZywETeZwjfsBHiTi+YAKKgY/KeFSRB4oVqDrbq/LFyAFyy2VBQIpKRQRcRAjAgl74yQiErpDuhVEOiAMoaykoYi4yvQVOW8r"
    "kHH9IelTu2Em1Zjx1ymbwMt8P5z2pdE2qWz2T9kfEGXOLDWaUVIZd0CdlrvEaKIg8znbCQaM/jbbzXBovqPGk5mhVJllN5rCzJwo"
    "zBFqzpQKZGboUgGMa+Ty+Oz1l3UAM80nmcUrnOwXBymNlJAqlYgoRQqMuLJrE5T1EB3/nmxf/bT7zaSdGWUTPUopsk9G+quRsdNG"
    "SZXTFqwyPq7td9otXDItJaVJUQykklKKhJRmL4Tqh5AJYcpOaZmNqVh0KJUcGbZGooOJkXQs1dYWa9+507hm3TqxGku1NdhiPXLB"
    "5ReI7XvW5108Ly1SUf+Jj44cP+vqVbed+9BDO/4jQ/i7xj6X33prCkCn8/VvahKYOpVPHDdOD06YEDCQ8jKQlyQ8hmH6C0qK8hrr"
    "m8a+//Aj95vC9Apl2O2UkqRURDan1AJpBEZcMbiYkiDSoVJGEmdde7U897bPW8lITHKdZ9oPyNlGCFCcUfaoJsdfJ6lkxg1ydkFm"
    "f35Sjia47a4ImTGojI/OMnEHFNmLUoHgtJA6S0M6rq2dfXIqv2SXW8mJRez6gz0pmfWWMvMBTt9RJkZRpP56KWWN2k5X2DesEZQQ"
    "kryhEO1782315u/+FT6PD5a0nKyjU9Szg1gSynIqCgzSAopranD9z35AxJzspp12U0SQ9lajmF3IZHBKLU7lTDE7uSGdNLpUUCQd"
    "NoEiBSVJCEhYUqkUSTJBylBMpiFVUlhymEk2rKRIKIiYVCICYEiZok+lVZvifMgw47HUUM9wyhhJ1G8+YlyzZo3xX3dJbJEAYCya"
    "tZ1/cqg7erChOHfFjO9OGIk8cu5DD/X/Z4bwdxnDv9ONSqc5hNKOvJgBqPi/M2Iqv1xTM7P/VOsvDNvl4CJ7mLNM5eE0z9I+UiUU"
    "kgAP5wZ7z7jq6r2x7j7O3bpOOilN1wTATCVIYzr5iVEARB7GuItsMWepyCn7gtxKwC4sgexkK7MdblKkOOPSyWQzxSQHcV1lFZmV"
    "LbiWdT2YBJEEhBNfOM4G46SUZIBwoiJNZtwpBcseUSKuOOfSqTgzQCi7l1UjSMkUKZIQZPfMcrvmzSgbwGdrB1JCmpZgnFHfsQZ9"
    "78b33V77/VKjSVPH2846eXaiRgAoKauUV33vOwMun5YClADTLEgIIYWSDBon0hWYmW3YlZYSyjII3CBJUpimpRhFlDRTSiq3EkhB"
    "IaZIxCzLGJEKQ8yiqLRUUljWkEUyaRnxlEimh8SwGjEoJeLGgOkbsgwAZlNnp3VkzRprzWg7FqRSVLusDuqBB+xx0nXrqK6uLpsl"
    "yJ70gFrjXKtdhlTL6wVPg9T+Vb9/YW1mo/7PDAEA/j8mJFOvavXmdQAAAABJRU5ErkJggg=="
)

# Module logos: moduli/logo/<file>.png (coloured) and <file>_peleks.png (grey, module not available yet)
LOGO_DIR = os.path.join(HERE, "moduli", "logo")
LOGO_SIZE = 96

# Order of the modules on the start page (file names in the moduli folder)
MODULE_FILES = ["terpu_purs", "deju_purs", "kopas_purs", "notikumu_purs", "citibas_purs", "zelta_purs"]

# Names and descriptions shown on the start page. Used whenever a module file does not give its own
# (e.g. while a module is being rewritten), so a tile is never left without a description.
DEFAULT_INFO = {
    "terpu_purs": {"name": "Tērpu pūrs", "letter": "T", "color": RED,
                   "description": "Tērpu un tērpa detaļu uzskaite, izsniegšana dejotājiem un atgriešana noliktavā"},
    "deju_purs": {"name": "Deju pūrs", "letter": "D", "color": NAVY,
                  "description": "Deju uzskaite: repertuārs, dejas apraksts, horeogrāfs, dejotāju sastāvs"},
    "kopas_purs": {"name": "Kopas pūrs", "letter": "K", "color": "#2E7D6B",
                   "description": "Dejotāju uzskaite un statistika: sastāvs, stāžs, dalība"},
    "notikumu_purs": {"name": "Notikumu pūrs", "letter": "N", "color": "#7A5C99",
                      "description": "Koncertu, skašu un citu pasākumu uzskaite un plānošana"},
    "citibas_purs": {"name": "Cītības pūrs", "letter": "C", "color": "#C4703A",
                     "description": "Mēģinājumu un pasākumu apmeklējuma uzskaite"},
    "zelta_purs": {"name": "Zelta pūrs", "letter": "Z", "color": GOLD,
                   "description": "Finanšu pārvaldība: ienākumi, izdevumi, dalības maksas"},
}


class ModuleInfo:
    def __init__(self, file_name):
        self.file_name = file_name
        self.module = None
        self.error = None
        default = DEFAULT_INFO.get(file_name, {})
        self.info = {"name": file_name, "version": None, "description": "", "letter": "?", "color": GREY}
        self.info.update(default)
        try:
            self.module = importlib.import_module("moduli." + file_name)
            self.info.update(getattr(self.module, "MODULE", {}))
        except Exception:
            self.error = traceback.format_exc()
            kopeja.log_error(self.error)
        for key, value in default.items():  # empty values from the module file -> defaults
            if not self.info.get(key):
                self.info[key] = value

    @property
    def ready(self):
        return self.module is not None and hasattr(self.module, "start")


class Purlade:
    def __init__(self, root):
        self.root = root
        root.geometry("1360x860")
        root.minsize(1180, 700)
        root.configure(bg=CREAM)
        kopeja.prepare_database()
        self.modules = [ModuleInfo(name) for name in MODULE_FILES]
        self.active = None
        self.active_key = None
        self.active_name = ""
        self.logos = {}
        # window close button (X) and "Beigt darbu": ask first when something is not saved yet
        self.guard = aizversana.CloseGuard(root, active_module=lambda: self.active,
                                           module_name=lambda: self.active_name if self.active else "")
        root.protocol("WM_DELETE_WINDOW", self.guard.request_close)
        self.set_window_icon()
        self.setup_style()
        self.access = piekluve.current(refresh=True)   # who uses this computer and what the roles allow
        self.build()
        # every start: ask the server (in the background) whether a newer Pūrlāde exists
        root.after(2000, lambda: atjauninasana.check_in_background(root, APP_VERSION, self.restart_program))

    def restart_program(self):
        """After an update: close (asking about unsaved changes) and open the new version.
        Returns False when the user chose to stay (then the new version starts next time)."""
        self.guard.request_close()
        try:
            alive = self.root.winfo_exists()
        except tk.TclError:
            alive = False
        if alive:
            return False
        atjauninasana.launch_new_version()
        return True

    # ---- look -------------------------------------------------------------
    def set_window_icon(self):
        """Pūrlāde logo (chest with the module cards) in the title bar and on the Windows taskbar."""
        set_app_icon(self.root)

    def setup_style(self):
        administresana.setup_style()  # buttons and tables look the same as in the modules

    # ---- start page ---------------------------------------------------------
    def clear(self):
        for child in self.root.winfo_children():
            child.destroy()

    def build(self):
        """Side bar + start page (again after a user change or Administrēšana)."""
        self.clear()
        self.active = None
        self.active_key = None
        self.root.title(f"{PROGRAM_NAME} v{APP_VERSION}")
        if not self.access.allowed():
            self.build_no_access()
            return
        self.build_shell()
        self.show_home()

    # ---- side bar ---------------------------------------------------------------
    def build_shell(self):
        acc = self.access
        items = [(m.file_name, m.info["name"], m.file_name, m.ready)
                 for m in self.modules if acc.can_open(m.file_name) and (m.ready or m.error)]
        extras = [("history", "Kolektīva vēsture"), ("changes", "Izmaiņu vēsture")]
        if acc.full:
            extras.append(("admin", "Administrēšana"))
            if not administresana.is_locked():
                extras.append(("dev", "Izstrādes darbi"))
        user = acc.user
        roles = ", ".join(r for r in user.roles if r != kopeja.APP_ROLE_DANCER)
        if user.source == "local":
            who = {"name": "Lokālā datubāze", "roles": "visas tiesības"}
        elif user.source == "admin":
            who = {"name": "Datubāzes administrators", "roles": "visas tiesības"}
        else:
            who = {"name": user.name or user.email, "roles": roles or kopeja.APP_ROLE_DANCER}
        self.sidebar = izskats.Sidebar(
            self.root, PURLADE_LOGO_B64, kopeja.read_setting("app.group_name", "Tautas deju kolektīvs"), who,
            items, extras, self.select,
            on_change_user=self.change_user if kopeja.datubaze.online_config() else None,
            on_quit=self.guard.request_close, version=f"Pūrlāde v{APP_VERSION} · {kopeja.database_label()}")
        self.sidebar.pack(side="left", fill="y")
        self.host = izskats.ModuleHost(self.root, bg=CREAM)
        self.host.pack(side="left", fill="both", expand=True)

    def select(self, key):
        """A side bar item was clicked."""
        if key == "home":
            if self.active is None or self.leave_module():
                self.show_home()
        elif key == "history":
            self.open_history()
        elif key == "changes":
            izmainas.show(self.root)
        elif key == "admin":
            self.open_admin()
        elif key == "dev":
            self.open_dev_tasks()
        else:
            mod = next((m for m in self.modules if m.file_name == key), None)
            if mod is not None:
                self.open_module(mod)

    def leave_module(self):
        """True when the open module may be left (nothing unsaved, or saved / discarded)."""
        module = self.active
        if module is None:
            return True
        confirm_view = getattr(module, "confirm_leave_view", None)   # Tērpu pūrs checks its own views
        if callable(confirm_view):
            if not confirm_view():
                return False
            return self.guard.confirm_leave(include_view=False)
        return self.guard.confirm_leave()

    def go_home(self):
        """A module's own “back” (on_exit): the start page."""
        self.show_home()

    # ---- start page ---------------------------------------------------------------
    def show_home(self):
        self.active = None
        self.active_key = None
        self.host.clear()
        self.sidebar.set_active("home")
        self.root.title(f"{PROGRAM_NAME} v{APP_VERSION}")
        try:
            home.build(self.host, self)
        except Exception:
            text = traceback.format_exc()
            kopeja.log_error(text)
            tk.Label(self.host, text="Sākuma lapu neizdevās parādīt — moduļi pieejami sānu joslā.\n"
                                     f"Detaļas: {kopeja.ERROR_LOG}", bg=CREAM, fg=RED,
                     font=("Segoe UI", 11)).pack(pady=40)

    def open_module_key(self, key, then=None):
        """Open a module from the start page; then(app) runs afterwards (e.g. open an event)."""
        mod = next((m for m in self.modules if m.file_name == key), None)
        if mod is None or not self.open_module(mod):
            return
        if then is not None and self.active is not None:
            try:
                then(self.active)
            except Exception:
                kopeja.log_error(traceback.format_exc())

    def build_no_access(self):
        """The person connected to this computer has no role that allows the desktop Pūrlāde."""
        user = self.access.user
        box = tk.Frame(self.root, bg=CREAM)
        box.place(relx=0.5, rely=0.45, anchor="center")
        try:
            self.header_logo = tk.PhotoImage(data=PURLADE_LOGO_B64)
            tk.Label(box, image=self.header_logo, bg=CREAM).pack(pady=(0, 10))
        except Exception:
            pass
        tk.Label(box, text="Nav piekļuves datora Pūrlādei", font=("Georgia", 20, "bold"), bg=CREAM,
                 fg=RED).pack()
        who = user.name or user.email or "nezināms lietotājs"
        if user.problem:
            why = user.problem
        else:
            roles = ", ".join(user.roles) or kopeja.APP_ROLE_DANCER
            why = (f"{who} lomām ({roles}) datora Pūrlāde nav pieejama — tā ir kolektīva vadībai, tērpu pārzinim, "
                   "sociālo tīklu administratoram un kasieriem. Dejotājiem ir Kabatas Pūrlāde telefonā.")
        tk.Label(box, text=why, font=("Segoe UI", 11), bg=CREAM, fg=NAVY, wraplength=560,
                 justify="center").pack(pady=(10, 4))
        tk.Label(box, text="Ja datoru lietos cits cilvēks, pieslēdzieties ar viņa e-pastu.",
                 font=("Segoe UI", 10, "italic"), bg=CREAM, fg=NAVY).pack(pady=(0, 14))
        btns = tk.Frame(box, bg=CREAM)
        btns.pack()
        ttk.Button(btns, text="👤 Pieslēgties ar citu e-pastu…", style="Accent.TButton",
                   command=self.change_user).pack(side="left", padx=6)
        ttk.Button(btns, text="Iziet", command=self.root.destroy).pack(side="left", padx=6)
        tk.Label(self.root, text=kopeja.COPYRIGHT, font=("Segoe UI", 8), bg=CREAM, fg=NAVY).pack(side="bottom",
                                                                                                pady=6)

    def change_user(self):
        """Sign in with another e-mail (code sent to it); the roles of that person apply from now on."""
        from moduli import datubaze_logs
        if datubaze_logs.connect_with_email(self.root):
            self.access = piekluve.current(refresh=True)
            self.build()

    def open_admin(self):
        if not self.access.full:
            return piekluve.deny(self.root, "Administrēšana ir vadītājam, repetitoram un sistēmas administratoram.")
        modules = [(m.info["name"], m.module) for m in self.modules if m.module is not None]
        administresana.open_admin(self.root, modules, on_change=self.build)

    def open_history(self):
        try:
            kolektiva_vesture.show(self.root)
        except Exception:
            text = traceback.format_exc()
            kopeja.log_error(text)
            messagebox.showerror("Kļūda", "Kolektīva vēsturi neizdevās atvērt.\n\n"
                                          f"Detaļas saglabātas failā:\n{kopeja.ERROR_LOG}", parent=self.root)

    def open_dev_tasks(self):
        if not self.access.full or administresana.is_locked():  # locked meanwhile
            self.build()
            return
        izstrades_darbi.show(self.root, [m.info["name"] for m in self.modules])

    # ---- modules --------------------------------------------------------------
    def open_module(self, mod):
        """Opens the module next to the side bar. True when it is open."""
        if not self.access.can_open(mod.file_name):
            piekluve.deny(self.root, f"Jūsu lomai nav piekļuves modulim “{mod.info['name']}”.")
            return False
        if mod.error or not mod.ready:
            messagebox.showerror("Kļūda", f"Moduli “{mod.info['name']}” neizdevās ielādēt.\n\n"
                                          f"Detaļas saglabātas failā:\n{kopeja.ERROR_LOG}", parent=self.root)
            return False
        if self.active is not None and self.active_key == mod.file_name:
            return True
        if not self.leave_module():
            return False
        self.host.clear()
        self.sidebar.set_active(mod.file_name)
        try:
            self.active_name = mod.info["name"]
            self.active_key = mod.file_name
            self.active = mod.module.start(self.host, on_exit=self.go_home,
                                           title_prefix=f"{PROGRAM_NAME} v{APP_VERSION} — ")
            return True
        except Exception:
            text = traceback.format_exc()
            kopeja.log_error(text)
            messagebox.showerror("Kļūda", f"Moduli “{mod.info['name']}” neizdevās atvērt.\n\n"
                                          f"Detaļas saglabātas failā:\n{kopeja.ERROR_LOG}", parent=self.root)
            self.show_home()
            return False

APP_ICON_ICO = os.path.join(LOGO_DIR, "purlade.ico")
APP_ICON_PNG = os.path.join(LOGO_DIR, "purlade.png")


def set_taskbar_identity():
    """Windows shows the icon of python.exe on the taskbar unless the program has its own
    identity; this must be set before the first window is created."""
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AdriansGutsmits.Purlade")
    except Exception:
        pass


def set_app_icon(root):
    # Windows: the .ico file (BMP images in 16-256 px) gives the title bar, taskbar and Alt+Tab
    # their proper sizes. If it cannot be used, the logo picture is set instead.
    if os.name == "nt" and os.path.exists(APP_ICON_ICO):
        try:
            root.iconbitmap(default=APP_ICON_ICO)
            root.iconbitmap(APP_ICON_ICO)
            return
        except Exception as exc:
            kopeja.log_error(f"Ikonu {APP_ICON_ICO} neizdevās ielādēt: {exc}")
    try:
        images = []
        if os.path.exists(APP_ICON_PNG):
            images.append(tk.PhotoImage(file=APP_ICON_PNG))
        images.append(tk.PhotoImage(data=PURLADE_LOGO_B64))
        root._purlade_icons = images  # keep references
        root.iconphoto(True, *images)
    except Exception:
        pass


def main():
    if kopeja.console_is_own():
        kopeja.set_console_visible(False)
    set_taskbar_identity()
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            # with the console hidden errors would vanish: write them to a log and tell the user
            kopeja.log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n"
                                              f"{kopeja.ERROR_LOG}", parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        set_app_icon(root)
        from moduli import datubaze_logs
        if not datubaze_logs.startup_check(root):  # online database not reachable and the user chose "Iziet"
            root.destroy()
            return
        Purlade(root)
        root.mainloop()
    except Exception:
        text = traceback.format_exc()
        kopeja.log_error(text)
        kopeja.set_console_visible(True)
        print(text)
        try:
            messagebox.showerror("Kļūda", f"Programma nevarēja startēt.\n\nDetaļas: {kopeja.ERROR_LOG}")
        except Exception:
            pass


if __name__ == "__main__":
    main()
