"""
Pūrlāde — palaidējs bez konsoles loga

Palaiž jaunāko programmas versiju šajā mapē (failu “Pūrlāde vX.Y.Z.py” ar lielāko versijas numuru).
Fails ar paplašinājumu .pyw tiek atvērts ar pythonw.exe, tāpēc konsoles (termināļa) logs neparādās.
To palaiž arī Pūrlāde.exe.
"""

import os
import re
import runpy
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = re.compile(r"^Pūrlāde v(\d+(?:\.\d+)*)\.py$")


def newest_version():
    best = None
    for name in os.listdir(HERE):
        m = VERSION_FILE.match(name)
        if m:
            key = tuple(int(x) for x in m.group(1).split("."))
            if best is None or key > best[0]:
                best = (key, name)
    return os.path.join(HERE, best[1]) if best else None


def main():
    script = newest_version()
    if script is None:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Pūrlāde", "Mapē nav atrasts neviens fails “Pūrlāde vX.Y.py”.\n\n" + HERE)
        return
    os.chdir(HERE)
    sys.argv = [script]
    try:
        runpy.run_path(script, run_name="__main__")
    except SystemExit:
        pass
    except Exception:
        text = traceback.format_exc()
        try:
            with open(os.path.join(HERE, "kludas.log"), "a", encoding="utf-8") as fh:
                from datetime import datetime
                fh.write(datetime.now().strftime("%d.%m.%Y %H:%M:%S") + "\n" + text + "\n")
        except OSError:
            pass
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Pūrlāde", "Programma nevarēja startēt.\n\nDetaļas saglabātas failā kludas.log.")


if __name__ == "__main__":
    main()
