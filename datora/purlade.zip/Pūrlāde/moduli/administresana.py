"""
Pūrlāde — Administrēšana (opened from the Pūrlāde start page)

Kopīgie iestatījumi visiem moduļiem: kolektīva nosaukums un logotips, moduļu tekstu un
kolonnu nosaukumi, sadaļas bloķēšana ar paroli, konsoles loga rādīšana un datubāze
(lokālā purlade.db vai tiešsaistes datubāze — sk. datubaze_logs.py).
Šī datora nosaukums (pagaidu risinājums, kamēr Pūrlādē nav lietotāju) glabājas tikai šajā
datorā — sk. datubaze.set_computer_name().

A module can offer its texts here by defining
    ADMIN_LABELS = {"logo": (settings key, file name prefix, title)}
(table and column names can no longer be renamed; only the collective name is set here)
"""

import hashlib
import hmac
import os
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:
    from moduli import datubaze
except ImportError:
    import datubaze

try:
    from moduli.kopeja import (DATA_DIR, DB_PATH, connect_db, load_image, console_available, console_visible,
                               set_console_visible, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE)
except ImportError:
    from kopeja import (DATA_DIR, DB_PATH, connect_db, load_image, console_available, console_visible,
                        set_console_visible, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE)

# texts shared by all modules
COMMON_LABELS = {"app.group_name": "Tautas deju kolektīvs"}
GROUP_LOGO = ("logo.file", "logo", "Kolektīva logotips")


# --------------------------------------------------------------------------
# Settings in the shared database
# --------------------------------------------------------------------------
class Settings:
    def __init__(self):
        self.con = connect_db(DB_PATH)
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        self.con.commit()

    def get(self, key, default=None):
        row = self.con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row and row[0] else default

    def set(self, key, value):
        self.con.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                         "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        self.con.commit()

    def delete(self, key):
        self.con.execute("DELETE FROM settings WHERE key=?", (key,))
        self.con.commit()

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass

    # administration lock: the password is only kept while the section is locked
    def lock_record(self):
        return self.get("admin.lock")

    def locked(self):
        return self.lock_record() is not None

    def lock(self, password):
        self.set("admin.lock", make_password_record(password))

    def unlock(self):
        self.delete("admin.lock")


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=vsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def setup_style():
    # same look as in the modules (the start page itself sets only the basic style)
    s = ttk.Style()
    s.theme_use("clam")
    s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
    s.configure("TFrame", background=CREAM)
    s.configure("TLabel", background=CREAM, foreground=NAVY)
    s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
    s.map("TButton", background=[("active", GOLD)])
    s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
    s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
    s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                bordercolor=GOLD)
    s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                padding=6)
    s.map("Treeview.Heading", background=[("active", RED)])
    s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])
    izskats.apply_style()   # kopīgais izskats (v0.8)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def make_password_record(password):
    # salted PBKDF2 hash; the password itself is never stored
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return salt.hex() + "$" + digest.hex()


def check_password(password, record):
    try:
        salt_hex, digest_hex = record.split("$", 1)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 200_000)
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, AttributeError):
        return False


class PasswordDialog(tk.Toplevel):
    """Modal password prompt. With confirm=True it asks for the new password twice."""

    def __init__(self, parent, title, confirm):
        super().__init__(parent)
        self.result = None
        self.confirm = confirm
        self.title(title)
        self.configure(bg=CREAM, padx=18, pady=14)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        tk.Label(self, text=title, font=("Georgia", 14, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        tk.Label(self, text="Parole:", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=4)
        self.pw1 = ttk.Entry(self, show="•", width=30)
        self.pw1.grid(row=1, column=1, padx=(10, 0), pady=4)
        row = 2
        self.pw2 = None
        if confirm:
            tk.Label(self, text="Atkārtojiet paroli:", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
            self.pw2 = ttk.Entry(self, show="•", width=30)
            self.pw2.grid(row=2, column=1, padx=(10, 0), pady=4)
            tk.Label(self, text="Vismaz 4 rakstzīmes. Parole būs jāievada, lai atbloķētu sadaļu.",
                     bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(
                row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
            row = 4
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=row, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Apstiprināt", style="Accent.TButton", command=self.ok).pack(side="right")
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.pw1.focus_set()

    def ok(self):
        password = self.pw1.get()
        if not password:
            messagebox.showwarning("Parole", "Ievadiet paroli.", parent=self)
            return
        if self.confirm:
            if len(password) < 4:
                messagebox.showwarning("Parole", "Parolei jābūt vismaz 4 rakstzīmēm.", parent=self)
                return
            if password != self.pw2.get():
                messagebox.showwarning("Parole", "Paroles nesakrīt.", parent=self)
                return
        self.result = password
        self.destroy()


def ask_password(parent, title, confirm=False):
    dialog = PasswordDialog(parent, title, confirm)
    parent.wait_window(dialog)
    return dialog.result




class EditableTree(ttk.Treeview):
    """Treeview whose chosen columns can be edited in place (double-click).
    Columns listed in `choices` open a small menu of allowed values instead."""

    def __init__(self, master, columns, editable, on_commit, choices=None, **kw):
        super().__init__(master, columns=columns, show="headings", **kw)
        self._cols = list(columns)
        self._editable = set(editable)
        self._on_commit = on_commit
        self._choices = choices or {}
        self._entry = None
        self._editing = None
        self.can_edit = None  # optional callable; editing only starts when it returns True
        self.bind("<Double-1>", self._begin_edit)

    def _begin_edit(self, event):
        if self.identify_region(event.x, event.y) != "cell":
            return
        iid = self.identify_row(event.y)
        col_index = int(self.identify_column(event.x).replace("#", "")) - 1
        col = self._cols[col_index]
        if not iid or col not in self._editable:
            return
        if self.can_edit is not None and not self.can_edit():
            return
        if col in self._choices:
            menu = tk.Menu(self, tearoff=0)
            for value in self._choices[col]:
                menu.add_command(label=value, command=lambda v=value: self._pick(iid, col, v))
            menu.tk_popup(event.x_root, event.y_root)
            return
        x, y, w, h = self.bbox(iid, f"#{col_index + 1}")
        self._close_entry()
        entry = tk.Entry(self, relief="solid", bd=1, font=("Segoe UI", 10))
        entry.insert(0, self.set(iid, col))
        entry.select_range(0, tk.END)
        entry.place(x=x, y=y, width=w, height=h)
        entry.focus_set()
        self._editing = (iid, col)
        entry.bind("<Return>", lambda e: self._commit(iid, col))
        entry.bind("<Escape>", lambda e: self._close_entry())
        entry.bind("<FocusOut>", lambda e: self._commit(iid, col))
        self._entry = entry

    def _pick(self, iid, col, value):
        if self._on_commit(iid, col, value):
            self.set(iid, col, value)

    def _commit(self, iid, col):
        if not self._entry:
            return
        value = self._entry.get()
        self._close_entry()
        if self._on_commit(iid, col, value):
            self.set(iid, col, value)

    def commit_open(self):
        # writes a cell that is still being edited (used by the "Saglabāt" buttons)
        if self._entry is not None and self._editing:
            self._commit(*self._editing)

    def _close_entry(self):
        if self._entry is not None:
            entry, self._entry = self._entry, None
            entry.destroy()


# --------------------------------------------------------------------------
# Administration window
# --------------------------------------------------------------------------
class AdminWindow(tk.Toplevel):
    """Administrēšana: collective name, computer name, logos, lock, console, database."""

    def __init__(self, root, modules, on_change, version=""):
        """modules: list of (module name, python module); on_change(): rebuild the start page."""
        super().__init__(root)
        self.app_version = version
        self.settings = Settings()
        self.on_change = on_change
        self.title("Administrēšana")
        self.geometry("820x370")
        self.configure(bg=CREAM)
        self.transient(root)
        self.protocol("WM_DELETE_WINDOW", self.save_close)
        self.locked_buttons = []
        self.changed = False
        setup_style()

        # logos offered by the modules (column names can no longer be renamed here)
        self.logos = [GROUP_LOGO]
        for name, module in modules:
            offer = getattr(module, "ADMIN_LABELS", None)
            if offer and offer.get("logo"):
                self.logos.append(offer["logo"])

        top = tk.Frame(self, bg=CREAM)
        top.pack(fill="x", padx=12, pady=(12, 0))
        tk.Label(top, text="Administrēšana", font=("Georgia", 16, "bold"), bg=CREAM, fg=RED).pack(side="left")
        self.lock_btn = ttk.Button(top, text="Bloķēt", style="Accent.TButton", command=self.toggle_lock)
        self.lock_btn.pack(side="right")
        self.lock_msg = tk.Label(top, text="", bg=CREAM, fg=RED, font=("Segoe UI", 9, "bold"))
        self.lock_msg.pack(side="right", padx=10)
        tk.Label(self, text="Iestatījumi ir kopīgi visiem moduļiem. Izmaiņas moduļos redzamas, kad tos atver.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), wraplength=820,
                 justify="left").pack(anchor="w", padx=12, pady=(2, 10))

        # collective name (shown in the header of every module)
        name_box = tk.Frame(self, bg=CREAM)
        name_box.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(name_box, text="Kolektīva nosaukums:", bg=CREAM, fg=NAVY, width=30, anchor="w",
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        self.name_lbl = tk.Label(name_box, text="", bg=NAVY, fg=GOLD, font=("Georgia", 11, "italic"),
                                 padx=12, pady=4)
        self.name_lbl.pack(side="left", padx=10)
        name_btn = ttk.Button(name_box, text="Mainīt nosaukumu…", command=self.change_group_name)
        name_btn.pack(side="left", padx=3)
        self.locked_buttons.append(name_btn)
        self.update_group_name()

        # name of this computer (temporary, until Pūrlāde has users); kept only on this computer
        pc_box = tk.Frame(self, bg=CREAM)
        pc_box.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(pc_box, text="Datora nosaukums:", bg=CREAM, fg=NAVY, width=30, anchor="w",
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        self.pc_lbl = tk.Label(pc_box, text="", bg=NAVY, fg=GOLD, font=("Georgia", 11, "italic"),
                               padx=12, pady=4)
        self.pc_lbl.pack(side="left", padx=10)
        pc_btn = ttk.Button(pc_box, text="Iestatīt datora nosaukumu…", command=self.change_computer_name)
        pc_btn.pack(side="left", padx=3)
        self.locked_buttons.append(pc_btn)
        self.pc_note = tk.Label(pc_box, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"))
        self.pc_note.pack(side="left", padx=6)
        self.update_computer_name()

        self.logo_previews = {}
        self._logo_imgs = {}
        for key, prefix, title in self.logos:
            box = tk.Frame(self, bg=CREAM)
            box.pack(fill="x", padx=12, pady=(0, 6))
            tk.Label(box, text=title + ":", bg=CREAM, fg=NAVY, width=30, anchor="w",
                     font=("Segoe UI", 10, "bold")).pack(side="left")
            preview = tk.Label(box, bg=NAVY, fg=GOLD, text="(nav)", padx=10, pady=4)
            preview.pack(side="left", padx=10)
            self.logo_previews[key] = preview
            pick = ttk.Button(box, text="Izvēlēties logotipu…", command=lambda k=key, p=prefix: self.pick_logo(k, p))
            pick.pack(side="left", padx=3)
            remove = ttk.Button(box, text="Noņemt logotipu", command=lambda k=key, p=prefix: self.remove_logo(k, p))
            remove.pack(side="left", padx=3)
            self.locked_buttons += [pick, remove]
        self.update_logo_previews()

        btns = ttk.Frame(self)
        btns.pack(side="bottom", fill="x", padx=10, pady=8)
        self.console_btn = ttk.Button(btns, text="", command=self.toggle_console)
        self.console_btn.pack(side="left", padx=(0, 8))
        db_btn = ttk.Button(btns, text="Datubāze…", command=self.open_database)
        db_btn.pack(side="left")
        self.locked_buttons.append(db_btn)
        backup_btn = ttk.Button(btns, text="Rezerves kopijas…", command=self.open_backups)   # Pūrlāde v0.9.4
        backup_btn.pack(side="left", padx=(8, 0))
        self.locked_buttons.append(backup_btn)
        ttk.Button(btns, text="Saglabāt un aizvērt", style="Accent.TButton",
                   command=self.save_close).pack(side="right")

        self.update_console_btn()
        self.update_lock_state()
        fit_min_size(self)
        self.grab_set()

    # -- closing --------------------------------------------------------------
    def save_close(self):
        # every change is written as it is made
        self.settings.close()
        self.destroy()
        if self.changed:
            self.on_change()

    # -- lock -----------------------------------------------------------------
    def check_unlocked(self):
        if self.settings.locked():
            messagebox.showinfo("Bloķēts", "Administrēšana ir bloķēta. Nospiediet “Atbloķēt”, lai rediģētu.",
                                parent=self)
            return False
        return True

    def update_lock_state(self):
        locked = self.settings.locked()
        self.lock_btn.configure(text="Atbloķēt" if locked else "Bloķēt")
        self.lock_msg.configure(text="Sadaļa ir bloķēta — izmaiņas nav iespējamas." if locked else "")
        for btn in self.locked_buttons:
            btn.configure(state="disabled" if locked else "normal")

    def toggle_lock(self):
        if self.settings.locked():
            password = ask_password(self, "Atbloķēt administrēšanu")
            if password is None:
                return
            if not check_password(password, self.settings.lock_record()):
                messagebox.showerror("Parole", "Nepareiza parole.", parent=self)
                return
            self.settings.unlock()  # the password is forgotten; a new one is asked for next time
        else:
            password = ask_password(self, "Izveidot paroli", confirm=True)
            if password is None:
                return
            self.settings.lock(password)
        self.changed = True
        self.update_lock_state()

    # -- database ---------------------------------------------------------------
    def open_database(self):
        """Online / local database of this computer. After a switch the window closes and the start
        page is rebuilt, because all settings shown here come from the other database."""
        if not self.check_unlocked():
            return
        try:
            from moduli import datubaze_logs
        except ImportError:
            import datubaze_logs
        if datubaze_logs.open_window(self):
            self.settings.close()
            self.destroy()
            self.on_change()

    # -- backups (Pūrlāde v0.9.4) -------------------------------------------------
    def open_backups(self):
        if not self.check_unlocked():
            return
        try:
            from moduli import rezerves_kopijas
        except ImportError:
            import rezerves_kopijas

        def restored():
            self.settings.close()
            self.destroy()
            self.on_change()
        rezerves_kopijas.show(self, version=self.app_version, on_restored=restored)

    # -- console --------------------------------------------------------------
    def update_console_btn(self):
        self.console_btn.configure(text="Paslēpt konsoli" if console_visible() else "Atvērt konsoli")

    def toggle_console(self):
        if not console_available():
            messagebox.showinfo("Konsole", "Konsoles logs šeit nav pieejams (programma nav palaista ar konsoli).",
                                parent=self)
            return
        set_console_visible(not console_visible())
        self.update_console_btn()

    # -- logos ----------------------------------------------------------------
    def logo_path(self, key):
        name = self.settings.get(key)
        path = os.path.join(DATA_DIR, name) if name else None
        return path if path and os.path.exists(path) else None

    def update_logo_previews(self):
        for key, preview in self.logo_previews.items():
            img = None
            path = self.logo_path(key)
            if path:
                try:
                    img = load_image(path, 150, 52)
                except Exception:
                    img = None
            self._logo_imgs[key] = img
            if img is not None:
                preview.configure(image=img, text="")
            else:
                preview.configure(image="", text="(nav)")

    @staticmethod
    def _remove_logo_files(prefix):
        start = prefix + "."
        for name in os.listdir(DATA_DIR):
            full = os.path.join(DATA_DIR, name)
            if name.lower().startswith(start) and os.path.isfile(full):
                os.remove(full)

    def pick_logo(self, key, prefix):
        if not self.check_unlocked():
            return
        src = filedialog.askopenfilename(
            parent=self, title="Izvēlieties logotipu",
            filetypes=[("Attēli", "*.png *.gif *.jpg *.jpeg"), ("Visi faili", "*.*")])
        if not src:
            return
        try:
            load_image(src, 150, 52)
        except Exception as exc:
            messagebox.showerror("Logotips", "Neizdevās ielādēt attēlu.\nIzmantojiet PNG vai GIF failu "
                                             "(JPG nepieciešama bibliotēka Pillow).\n\n" + str(exc), parent=self)
            return
        import shutil
        ext = os.path.splitext(src)[1].lower()
        dest = os.path.join(DATA_DIR, prefix + ext)
        if os.path.abspath(src) != dest:
            self._remove_logo_files(prefix)
            shutil.copy2(src, dest)
        self.settings.set(key, prefix + ext)
        self.changed = True
        self.update_logo_previews()

    def remove_logo(self, key, prefix):
        if not self.check_unlocked():
            return
        self._remove_logo_files(prefix)
        self.settings.delete(key)
        self.changed = True
        self.update_logo_previews()

    # -- collective name --------------------------------------------------------
    def group_name(self):
        return self.settings.get("app.group_name", COMMON_LABELS["app.group_name"])

    def update_group_name(self):
        self.name_lbl.configure(text=self.group_name())

    def change_group_name(self):
        if not self.check_unlocked():
            return
        new = ask_group_name(self, self.group_name())
        if new is None or new == self.group_name():
            return
        self.settings.set("app.group_name", new)
        self.changed = True
        self.update_group_name()

    # -- computer name ----------------------------------------------------------
    def update_computer_name(self):
        custom = datubaze.custom_computer_name()
        self.pc_lbl.configure(text=custom or datubaze.windows_computer_name())
        self.pc_note.configure(text="" if custom else "(Windows nosaukums)")

    def change_computer_name(self):
        if not self.check_unlocked():
            return
        current = datubaze.custom_computer_name()
        new = ask_computer_name(self, current or "")
        if new is None or new == (current or ""):
            return
        try:
            datubaze.set_computer_name(new)
        except OSError as exc:
            messagebox.showerror("Datora nosaukums", "Neizdevās saglabāt nosaukumu.\n\n" + str(exc), parent=self)
            return
        self.changed = True
        self.update_computer_name()


class ComputerNameDialog(tk.Toplevel):
    """Small window for the name of this computer (an empty name returns to the Windows name)."""

    def __init__(self, parent, current):
        super().__init__(parent)
        self.result = None
        self.title("Datora nosaukums")
        self.configure(bg=CREAM, padx=18, pady=14)
        self.resizable(False, False)
        self.transient(parent)
        tk.Label(self, text="Datora nosaukums", font=("Georgia", 14, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        tk.Label(self, text="Nosaukums:", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w")
        self.var = tk.StringVar(value=current)
        entry = ttk.Entry(self, textvariable=self.var, width=40)
        entry.grid(row=1, column=1, padx=(10, 0))
        tk.Label(self, text=("Piem., “Vadītājas klēpjdators”. Nosaukums glabājas tikai šajā datorā un ir redzams\n"
                             "sākuma lapas apakšā un tiešsaistes datubāzes savienojumos (pēc Pūrlādes pārstartēšanas).\n"
                             "Atstājiet tukšu, lai lietotu Windows datora nosaukumu (" +
                             datubaze.windows_computer_name() + ")."),
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), justify="left").grid(
            row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Return>", lambda e: self.save())
        self.bind("<Escape>", lambda e: self.destroy())
        entry.focus_set()
        entry.select_range(0, "end")
        self.grab_set()

    def save(self):
        value = " ".join(self.var.get().split())
        if len(value) > 40:
            messagebox.showwarning("Datora nosaukums", "Nosaukums nedrīkst būt garāks par 40 rakstzīmēm.",
                                   parent=self)
            return
        self.result = value
        self.destroy()


def ask_computer_name(parent, current):
    dialog = ComputerNameDialog(parent, current)
    parent.wait_window(dialog)
    try:
        parent.grab_set()  # the Administrēšana window stays modal
    except tk.TclError:
        pass
    return dialog.result


class GroupNameDialog(tk.Toplevel):
    """Small window for the collective name."""

    def __init__(self, parent, current):
        super().__init__(parent)
        self.result = None
        self.title("Kolektīva nosaukums")
        self.configure(bg=CREAM, padx=18, pady=14)
        self.resizable(False, False)
        self.transient(parent)
        tk.Label(self, text="Kolektīva nosaukums", font=("Georgia", 14, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        tk.Label(self, text="Nosaukums:", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w")
        self.var = tk.StringVar(value=current)
        entry = ttk.Entry(self, textvariable=self.var, width=40)
        entry.grid(row=1, column=1, padx=(10, 0))
        tk.Label(self, text="Nosaukums redzams visu moduļu galvenē.", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Return>", lambda e: self.save())
        self.bind("<Escape>", lambda e: self.destroy())
        entry.focus_set()
        entry.select_range(0, "end")
        self.grab_set()

    def save(self):
        value = " ".join(self.var.get().split())
        if not value:
            messagebox.showwarning("Nosaukums", "Nosaukums nedrīkst būt tukšs.", parent=self)
            return
        self.result = value
        self.destroy()


def ask_group_name(parent, current):
    dialog = GroupNameDialog(parent, current)
    parent.wait_window(dialog)
    try:
        parent.grab_set()  # the Administrēšana window stays modal
    except tk.TclError:
        pass
    return dialog.result

def is_locked():
    """True while Administrēšana is locked with a password."""
    settings = Settings()
    try:
        return settings.locked()
    finally:
        settings.close()


def open_admin(root, modules, on_change, version=""):
    """The "⚙ Administrēšana" button. When the section is locked only the password prompt appears
    (a correct password unlocks it; the window is not opened)."""
    settings = Settings()
    try:
        if not settings.locked():
            return AdminWindow(root, modules, on_change, version)
        password = ask_password(root, "Atbloķēt administrēšanu")
        if password is None:
            return None
        if not check_password(password, settings.lock_record()):
            messagebox.showerror("Parole", "Nepareiza parole.", parent=root)
            return None
        settings.unlock()  # the password is forgotten; a new one is asked for next time
        messagebox.showinfo("Administrēšana", "Administrēšana ir atbloķēta.", parent=root)
        on_change()
        return None
    finally:
        settings.close()
