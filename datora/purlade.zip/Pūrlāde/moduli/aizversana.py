"""
Pūrlāde — programmas aizvēršana ar nesaglabātu izmaiņu pārbaudi

When the window's close button (X) or "Beigt darbu" is pressed, Pūrlāde looks for data that has
been entered but not saved yet:
  * the open view of a module that knows whether it is changed (dirty() — e.g. Tērpu pūrs
    "Izsniegt" / "Atgriezt" / "Noliktavas pārvaldība");
  * every open window (form) that can be saved (has save()): it is changed when its dirty()
    says so, or its `changed` flag is set, or — for forms without either — when any of its input
    fields differs from what it showed when the window opened.
If something is unsaved, a dialog asks: save and close, close without saving, or cancel.
"""

import tkinter as tk
from tkinter import ttk, messagebox

try:
    from moduli.kopeja import CREAM, RED, NAVY, GOLD
except ImportError:
    from kopeja import CREAM, RED, NAVY, GOLD

INPUT_CLASSES = {"Entry", "TEntry", "Spinbox", "TSpinbox", "TCombobox", "Text",
                 "Checkbutton", "TCheckbutton", "Radiobutton", "TRadiobutton"}


# --------------------------------------------------------------------------
# What a window showed when it opened
# --------------------------------------------------------------------------
def _inputs(win):
    """{widget path: value} of the input fields of a window (not of windows opened from it)."""
    values = {}
    stack = list(win.winfo_children())
    while stack:
        w = stack.pop()
        if isinstance(w, tk.Toplevel):
            continue
        stack.extend(w.winfo_children())
        cls = w.winfo_class()
        if cls not in INPUT_CLASSES:
            continue
        try:
            if cls == "Text":
                if str(w.cget("state")) == "disabled":
                    continue
                values[str(w)] = w.get("1.0", "end-1c")
            elif cls in ("Checkbutton", "TCheckbutton", "Radiobutton", "TRadiobutton"):
                var = str(w.cget("variable"))
                if var:
                    values[str(w)] = str(w.getvar(var))
            else:
                if cls != "TCombobox" and str(w.cget("state")) in ("disabled", "readonly"):
                    continue
                values[str(w)] = w.get()
        except tk.TclError:
            pass
    return values


class CloseGuard:
    def __init__(self, root, active_module=None, module_name=None):
        """active_module(): the open module object (or None); module_name(): its name."""
        self.root = root
        self.active_module = active_module or (lambda: None)
        self.module_name = module_name or (lambda: "")
        self.snapshots = {}   # window path -> input values when it opened
        self.order = []       # windows in the order they were opened
        root.bind_class("Toplevel", "<Map>", self._on_map, add="+")
        root.bind_class("Toplevel", "<Destroy>", self._on_destroy, add="+")

    def _on_map(self, event):
        win = event.widget
        key = str(win)
        if key in self.snapshots or not isinstance(win, tk.Toplevel):
            return
        self.snapshots[key] = _inputs(win)
        self.order.append(win)

    def _on_destroy(self, event):
        key = str(event.widget)
        if key in self.snapshots:
            self.snapshots.pop(key, None)
            self.order = [w for w in self.order if str(w) != key]

    # ---- what is unsaved ----------------------------------------------------
    def _window_changed(self, win):
        dirty = getattr(win, "dirty", None)
        if callable(dirty):
            return bool(dirty())
        if hasattr(win, "changed") and isinstance(win.changed, bool):
            return win.changed  # the window tracks its own changes (Cītības pūrs, Notikumu pūrs)
        before = self.snapshots.get(str(win))
        if before is None:
            return False
        now = _inputs(win)
        return any(now[k] != v for k, v in before.items() if k in now)

    def unsaved(self, include_view=True):
        """[(description, save function), ...] — newest window first. include_view=False: only the windows
        (the open view of the module is then checked by the module itself, e.g. Tērpu pūrs)."""
        items = []
        prefix = self.module_name()
        for win in reversed(self.order):
            try:
                if not win.winfo_exists() or not callable(getattr(win, "save", None)):
                    continue
                if self._window_changed(win):
                    title = win.title() or "Logs"
                    items.append((f"{prefix}: {title}" if prefix else title, self._window_saver(win)))
            except tk.TclError:
                continue
        module = self.active_module()
        view = getattr(module, "view_widget", None) if include_view else None
        if view is not None and callable(getattr(view, "dirty", None)):
            try:
                if view.winfo_exists() and view.dirty():
                    saver = getattr(view, "do_return", None) or getattr(view, "save", None)
                    name = getattr(getattr(module, "current_view", None), "__name__", "")
                    title = {"IssueWindow": "Izsniegšana", "ReturnWindow": "Atgriešana",
                             "CatalogWindow": "Noliktavas pārvaldība"}.get(name, "atvērtais skats")
                    items.append((f"{prefix}: {title}" if prefix else title, self._view_saver(view, saver)))
            except tk.TclError:
                pass
        return items

    @staticmethod
    def _window_saver(win):
        def save():
            win.save()
            try:
                if not win.winfo_exists():
                    return True
            except tk.TclError:
                return True
            dirty = getattr(win, "dirty", None)
            return callable(dirty) and not dirty()
        return save

    @staticmethod
    def _view_saver(view, saver):
        def save():
            if saver is None:
                return False
            result = saver()
            try:
                return bool(result) or not view.dirty()
            except tk.TclError:
                return True
        return save

    # ---- leaving the open module (Pūrlāde v0.8 side bar) ------------------------
    def confirm_leave(self, include_view=True):
        """Before another module or the start page is opened: True when nothing is unsaved, or the user saved /
        discarded it; False — stay in the module."""
        items = self.unsaved(include_view)
        if not items:
            return True
        choice = ask_close(self.root, [d for d, _ in items], leaving=True)
        if choice == "cancel":
            return False
        if choice == "save":
            for description, save in items:
                ok = False
                try:
                    ok = save()
                except Exception as exc:
                    messagebox.showerror("Saglabāšana", f"{description}\n\nNeizdevās saglabāt: {exc}",
                                         parent=self.root)
                if not ok:
                    messagebox.showwarning("Modulis netika atstāts",
                                           f"“{description}” neizdevās saglabāt — pārbaudiet ievadītos datus.",
                                           parent=self.root)
                    return False
        return True

    # ---- closing ------------------------------------------------------------
    def request_close(self):
        """Close the program; asks first when something is unsaved."""
        items = self.unsaved()
        if items:
            had_grab = self.root.grab_current()
            choice = ask_close(self.root, [d for d, _ in items])
            if choice == "cancel":
                if had_grab is not None:
                    try:
                        had_grab.grab_set()
                    except tk.TclError:
                        pass
                return
            if choice == "save":
                for description, save in items:
                    ok = False
                    try:
                        ok = save()
                    except Exception as exc:
                        messagebox.showerror("Saglabāšana", f"{description}\n\nNeizdevās saglabāt: {exc}",
                                             parent=self.root)
                    if not ok:
                        messagebox.showwarning(
                            "Programma netika aizvērta",
                            f"“{description}” neizdevās saglabāt — pārbaudiet ievadītos datus un mēģiniet vēlreiz.",
                            parent=self.root)
                        return
        self.root.destroy()


class CloseDialog(tk.Toplevel):
    def __init__(self, root, descriptions, leaving=False):
        super().__init__(root)
        self.result = "cancel"
        self.title("Atstāt moduli" if leaving else "Aizvērt programmu")
        self.configure(bg=CREAM, padx=22, pady=18)
        self.transient(root)
        self.resizable(False, False)
        tk.Label(self, text="Ir nesaglabātas izmaiņas", font=("Georgia", 14, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w")
        tk.Label(self, text="Šajos logos ievadītie dati vēl nav saglabāti:", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(8, 2))
        for d in descriptions:
            tk.Label(self, text="•  " + d, bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold"),
                     justify="left", wraplength=460).pack(anchor="w", padx=(8, 0))
        tk.Label(self, text=("Vai atstāt moduli? Izmaiņas var saglabāt vai atmest." if leaving else
                             "Vai tiešām aizvērt programmu? Izmaiņas var saglabāt vai atmest."), bg=CREAM,
                 fg=NAVY, font=("Segoe UI", 10)).pack(anchor="w", pady=(10, 14))
        tk.Frame(self, bg=GOLD, height=2).pack(fill="x", pady=(0, 12))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x")
        ttk.Button(btns, text="Atcelt", command=lambda: self.finish("cancel")).pack(side="right")
        ttk.Button(btns, text="Atmest" if leaving else "Atmest un aizvērt",
                   command=lambda: self.finish("discard")).pack(side="right", padx=6)
        ttk.Button(btns, text="Saglabāt" if leaving else "Saglabāt un aizvērt", style="Accent.TButton",
                   command=lambda: self.finish("save")).pack(side="right")
        self.protocol("WM_DELETE_WINDOW", lambda: self.finish("cancel"))
        self.bind("<Escape>", lambda e: self.finish("cancel"))
        self.update_idletasks()
        try:
            x = root.winfo_rootx() + (root.winfo_width() - self.winfo_reqwidth()) // 2
            y = root.winfo_rooty() + (root.winfo_height() - self.winfo_reqheight()) // 3
            self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        except tk.TclError:
            pass
        self.lift()
        self.grab_set()
        self.focus_set()

    def finish(self, result):
        self.result = result
        self.destroy()


def ask_close(root, descriptions, leaving=False):
    """'save', 'discard' or 'cancel'."""
    dialog = CloseDialog(root, descriptions, leaving=leaving)
    root.wait_window(dialog)
    return dialog.result
