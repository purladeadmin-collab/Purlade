"""
Pūrlāde — automātiskā atjaunināšana (datora versija)

Katru reizi, kad Pūrlāde tiek atvērta, fonā tiek pajautāts Kabatas Pūrlādes serverim (tam pašam, kas dod
lejupielādi mājaslapā), kāda ir jaunākā datora Pūrlādes versija. Ja tā ir jaunāka par atvērto, parādās logs
ar izvēli “Atjaunināt tagad” / “Vēlāk”.

Atjaunināšana:
  1. lejupielādē zip failu (to sagatavo “Sagatavot lejupielādi.pyw”) — serveris to dod tikai ar atslēgu
     `update.key`, kas glabājas kolektīva kopīgajā tiešsaistes datubāzē (tātad tikai datoriem, kas pieslēgti
     kolektīva datubāzei). Datoram ar lokālo datubāzi atveras mājaslapas lejupielāde pārlūkā;
  2. pārbauda faila kontrolsummu (SHA-256) un to, vai zip ir vesels;
  3. pārraksta programmas failus Pūrlādes mapē (jaunākais “Pūrlāde vX.Y.Z.py”, Pūrlāde.pyw, Pūrlāde.exe,
     plogo.png, mape moduli/). Dati (purlade.db, foto, Excel faili) netiek aiztikti — zip failā to nav;
  4. vecos “Pūrlāde vX.Y.Z.py” failus pārvieto uz mapi “Vecās versijas”;
  5. aizver Pūrlādi (pajautājot par nesaglabātām izmaiņām) un atver jauno versiju.

Servera adrese: iestatījums `update.server` (ja nav — DEFAULT_SERVER). Pārbaudi var izslēgt ar vides mainīgo
PURLADE_BEZ_ATJAUNINASANAS=1.
"""

import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import traceback
import urllib.error
import urllib.request
import webbrowser
import zipfile
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from moduli import kopeja
    from moduli.kopeja import CREAM, RED, NAVY, GOLD
except ImportError:
    import kopeja
    from kopeja import CREAM, RED, NAVY, GOLD

DEFAULT_SERVER = "https://kabatas-purlade.onrender.com"
INFO_PATH = "/api/atjauninajums/info"
DOWNLOAD_PATH = "/api/atjauninajums"
SITE_PATH = "/purlade/#ielogoties"
KEY_SETTING = "update.key"
KEY_HEADER = "X-Purlade-Atslega"
# a sleeping free Render server needs up to a minute to wake up
INFO_TIMEOUT = 90
DOWNLOAD_TIMEOUT = 120

APP_DIR = kopeja.DATA_DIR                      # the Pūrlāde folder (program files + data)
OLD_DIR = os.path.join(APP_DIR, "Vecās versijas")
PROGRAM_RE = re.compile(r"^Pūrlāde v(\d+(?:\.\d+)*)\.py$")
ZIP_ROOT = "Pūrlāde/"
NEVER_OVERWRITE = {"purlade.db", "kludas.log", "logo.png"}     # data that must stay as it is


def version_key(text):
    try:
        return tuple(int(x) for x in str(text).strip().split("."))
    except ValueError:
        return ()


def server_url():
    url = (kopeja.read_setting("update.server") or os.environ.get("PURLADE_SERVER") or DEFAULT_SERVER).strip()
    return url.rstrip("/")


def user_agent(version):
    return f"Purlade-dators/{version}"


def fetch_info(current_version, url=None):
    """{"available", "version", "size", "sha256", "date"} from the server (raises on network errors)."""
    req = urllib.request.Request((url or server_url()) + INFO_PATH, headers={"User-Agent": user_agent(current_version),
                                                                    "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=INFO_TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def update_key():
    """The download key from the shared online database (created here if the collective has none yet).
    Only computers that use the collective's online database have it; a local database gets None."""
    if not kopeja.database_is_online():
        return None
    key = kopeja.read_setting(KEY_SETTING)
    if key:
        return key
    try:
        con = kopeja.connect_db()
        try:
            con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            con.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO NOTHING",
                        (KEY_SETTING, secrets.token_urlsafe(32)))
            con.commit()
        finally:
            con.close()
    except Exception:
        kopeja.log_error("Atjaunināšanas atslēgu neizdevās izveidot:\n" + traceback.format_exc())
        return None
    return kopeja.read_setting(KEY_SETTING)


# --------------------------------------------------------------------------
# Start-up check
# --------------------------------------------------------------------------
def check_in_background(root, current_version, restart):
    """Ask the server in a background thread; when a newer version exists, offer it (in the Tk thread).
    restart(): closes the program (asking about unsaved changes) and returns True when it was closed."""
    if os.environ.get("PURLADE_BEZ_ATJAUNINASANAS") == "1":
        return

    url = server_url()        # read the setting here, in the Tk thread (the database is not shared with threads)
    result = {}

    def work():
        try:
            result["info"] = fetch_info(current_version, url)
        except Exception as exc:   # offline, server asleep too long, ... — try again next time
            result["error"] = exc
        result["done"] = True

    def poll():
        # Tk may only be used from its own thread: the background thread just stores the answer
        if not result.get("done"):
            try:
                root.after(500, poll)
            except tk.TclError:
                pass
            return
        if "error" in result:
            kopeja.log_error(f"Atjauninājumu pārbaude neizdevās ({url}): {result['error']}")
            return
        info = result["info"]
        if info.get("available") and version_key(info.get("version")) > version_key(current_version):
            offer(root, current_version, info, restart)

    threading.Thread(target=work, daemon=True, name="atjauninasana").start()
    root.after(500, poll)


def offer(root, current_version, info, restart):
    try:
        if not root.winfo_exists():
            return
    except tk.TclError:
        return
    dialog = OfferDialog(root, current_version, info)
    root.wait_window(dialog)
    if dialog.result == "update":
        start_update(root, current_version, info, restart)


class OfferDialog(tk.Toplevel):
    def __init__(self, root, current_version, info):
        super().__init__(root)
        self.result = "later"
        self.title("Pieejama jauna Pūrlādes versija")
        self.configure(bg=CREAM, padx=22, pady=18)
        self.transient(root)
        self.resizable(False, False)
        tk.Label(self, text="Pieejama jauna Pūrlādes versija", font=("Georgia", 14, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w")
        size = info.get("size") or 0
        size_text = f", {size / 1048576:.1f} MB".replace(".", ",") if size else ""
        date = f", sagatavota {info['date']}" if info.get("date") else ""
        tk.Label(self, text=f"Jaunā versija: v{info.get('version')}{date}{size_text}\n"
                            f"Šajā datorā: v{current_version}",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 10), justify="left").pack(anchor="w", pady=(8, 6))
        tk.Label(self, text="Atjauninot tiek nomainīti tikai programmas faili — kolektīva dati netiek mainīti.\n"
                            "Pēc atjaunināšanas Pūrlāde tiks atvērta no jauna.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), justify="left").pack(anchor="w", pady=(0, 12))
        tk.Frame(self, bg=GOLD, height=2).pack(fill="x", pady=(0, 12))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x")
        ttk.Button(btns, text="Vēlāk", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="Atjaunināt tagad", style="Accent.TButton",
                   command=self.accept).pack(side="right", padx=(0, 6))
        self.bind("<Escape>", lambda e: self.destroy())
        self.update_idletasks()
        try:
            x = root.winfo_rootx() + (root.winfo_width() - self.winfo_reqwidth()) // 2
            y = root.winfo_rooty() + (root.winfo_height() - self.winfo_reqheight()) // 3
            self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        except tk.TclError:
            pass
        self.lift()
        self.grab_set()

    def accept(self):
        self.result = "update"
        self.destroy()


# --------------------------------------------------------------------------
# Download and install
# --------------------------------------------------------------------------
def start_update(root, current_version, info, restart):
    key = update_key()
    if not key:
        if messagebox.askyesno(
                "Atjaunināšana",
                "Šis dators nav pieslēgts kolektīva tiešsaistes datubāzei, tāpēc jauno versiju nevar lejupielādēt "
                "automātiski.\n\nAtvērt mājaslapu, kur pēc pieteikšanās to var lejupielādēt (Lietotājiem → "
                "Datora Pūrlāde)?", parent=root):
            webbrowser.open(server_url() + SITE_PATH)
        return
    progress = ProgressDialog(root, info.get("version"))
    state = {"done": False, "error": None, "files": 0}
    url = server_url()

    def work():
        try:
            path = download(key, current_version, info, progress.set_fraction, url)
            progress.set_text("Uzstāda jauno versiju…")
            state["files"] = install(path, info.get("version"))
        except Exception as exc:
            state["error"] = exc
            kopeja.log_error("Atjaunināšana neizdevās:\n" + traceback.format_exc())
        state["done"] = True

    threading.Thread(target=work, daemon=True, name="atjauninasana-lejupielade").start()

    def poll():
        if not state["done"]:
            root.after(200, poll)
            return
        progress.destroy()
        if state["error"] is not None:
            messagebox.showerror("Atjaunināšana neizdevās",
                                 f"Jauno versiju neizdevās uzstādīt:\n{state['error']}\n\n"
                                 "Programmas faili netika mainīti — var turpināt strādāt ar pašreizējo versiju. "
                                 f"Detaļas: {kopeja.ERROR_LOG}", parent=root)
            return
        messagebox.showinfo("Atjaunināts",
                            f"Pūrlāde atjaunināta uz v{info.get('version')}.\n\n"
                            "Tagad tā tiks aizvērta un atvērta no jauna.", parent=root)
        if not restart():
            messagebox.showinfo("Atjaunināts",
                                "Jaunā versija sāks darboties, kad Pūrlādi aizvērsiet un atvērsiet no jauna.",
                                parent=root)

    root.after(200, poll)


class ProgressDialog(tk.Toplevel):
    def __init__(self, root, version):
        super().__init__(root)
        self.title("Atjaunināšana")
        self.configure(bg=CREAM, padx=22, pady=18)
        self.transient(root)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", lambda: None)   # cannot be closed half way
        tk.Label(self, text=f"Atjaunina uz Pūrlāde v{version}", font=("Georgia", 13, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w")
        self.var = tk.StringVar(value="Lejupielādē… (serverim var būt vajadzīga minūte, lai pamostos)")
        tk.Label(self, textvariable=self.var, bg=CREAM, fg=NAVY, font=("Segoe UI", 9)).pack(anchor="w", pady=(8, 6))
        self.bar = ttk.Progressbar(self, length=380, mode="determinate", maximum=1000)
        self.bar.pack(fill="x")
        self._fraction = 0.0
        self._text = None
        self._tick()
        self.grab_set()

    # called from the download thread: only store, the Tk thread shows it
    def set_fraction(self, value):
        self._fraction = value

    def set_text(self, text):
        self._text = text

    def _tick(self):
        try:
            self.bar["value"] = int(self._fraction * 1000)
            if self._text:
                self.var.set(self._text)
            self.after(150, self._tick)
        except tk.TclError:
            pass


def download(key, current_version, info, on_progress, url):
    tmp = os.path.join(APP_DIR, ".atjauninajums.zip.tmp")
    req = urllib.request.Request(url + DOWNLOAD_PATH,
                                 headers={"User-Agent": user_agent(current_version), KEY_HEADER: key})
    digest = hashlib.sha256()
    try:
        with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT) as resp, open(tmp, "wb") as out:
            total = int(resp.headers.get("Content-Length") or info.get("size") or 0)
            done = 0
            while True:
                chunk = resp.read(256 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                if total:
                    on_progress(min(done / total, 1.0))
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            raise RuntimeError("serveris neatpazina šī datora atslēgu (vai dators lieto kolektīva tiešsaistes "
                               "datubāzi?)") from None
        if exc.code == 404:
            raise RuntimeError("serverī vēl nav sagatavota lejupielāde") from None
        raise RuntimeError(f"servera kļūda {exc.code}") from None
    expected = (info.get("sha256") or "").lower()
    if expected and digest.hexdigest() != expected:
        os.remove(tmp)
        raise RuntimeError("lejupielādētais fails ir bojāts (kontrolsumma nesakrīt) — mēģiniet vēlreiz")
    with zipfile.ZipFile(tmp) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"lejupielādētais fails ir bojāts ({bad})")
    return tmp


def _safe_target(name):
    """Zip member name → absolute path inside the Pūrlāde folder (None for names that must be skipped)."""
    if not name.startswith(ZIP_ROOT) or name.endswith("/"):
        return None
    rel = name[len(ZIP_ROOT):]
    if not rel or rel.startswith("/") or ".." in rel.replace("\\", "/").split("/"):
        return None
    if rel in NEVER_OVERWRITE or rel.lower().endswith((".db", ".log")):
        return None
    target = os.path.normpath(os.path.join(APP_DIR, rel))
    if os.path.commonpath([target, os.path.normpath(APP_DIR)]) != os.path.normpath(APP_DIR):
        return None
    return target


def install(zip_path, new_version):
    """Write the program files from the zip into the Pūrlāde folder. Each file is first written next to its
    place and then swapped in, so an interrupted update never leaves a half-written file."""
    written = 0
    try:
        with zipfile.ZipFile(zip_path) as z:
            members = [(m, _safe_target(m.filename)) for m in z.infolist()]
            members = [(m, t) for m, t in members if t]
            if not any(PROGRAM_RE.match(os.path.basename(t)) for _m, t in members):
                raise RuntimeError("lejupielādētajā failā nav programmas faila “Pūrlāde vX.Y.Z.py”")
            for member, target in members:
                os.makedirs(os.path.dirname(target), exist_ok=True)
                part = target + ".jauns"
                with z.open(member) as src, open(part, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                try:
                    os.replace(part, target)
                except PermissionError:
                    # e.g. Pūrlāde.exe still starting: keep the old one, the program itself is updated
                    os.remove(part)
                    continue
                written += 1
    finally:
        try:
            os.remove(zip_path)
        except OSError:
            pass
    move_old_versions(new_version)
    return written


def move_old_versions(new_version):
    """Older “Pūrlāde vX.Y.Z.py” files go to “Vecās versijas” (Pūrlāde.pyw / .exe always open the newest)."""
    newest = version_key(new_version)
    for name in os.listdir(APP_DIR):
        m = PROGRAM_RE.match(name)
        if m and version_key(m.group(1)) < newest:
            os.makedirs(OLD_DIR, exist_ok=True)
            try:
                os.replace(os.path.join(APP_DIR, name), os.path.join(OLD_DIR, name))
            except OSError:
                pass


def launch_new_version():
    """Start Pūrlāde again (the newest version) in a new process, without a console window."""
    pyw = os.path.join(APP_DIR, "Pūrlāde.pyw")
    exe = sys.executable
    if os.name == "nt":
        pythonw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pythonw):
            exe = pythonw
    if os.path.exists(pyw):
        args = [exe, pyw]
    else:
        newest = max((n for n in os.listdir(APP_DIR) if PROGRAM_RE.match(n)),
                     key=lambda n: version_key(PROGRAM_RE.match(n).group(1)))
        args = [exe, os.path.join(APP_DIR, newest)]
    flags = 0
    if os.name == "nt":
        flags = 0x00000008 | 0x00000200   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(args, cwd=APP_DIR, creationflags=flags, close_fds=True)
