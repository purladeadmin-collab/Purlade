#!/usr/bin/env python3
"""
Pūrlāde — modulis "Cītības pūrs" (mēģinājumu un pasākumu apmeklējuma uzskaitei)

Katram notikumam (mēģinājumam, koncertam, skatei …) dejotājiem tiek atzīmēts:
    Ieradās · Nokavēja · Attaisnoti nebija · Neattaisnoti nebija
Dejotāju saraksts tiek ņemts no Kopas pūra, deju saraksts — no Deju pūra
(katram notikumam var atzīmēt, kuras dejas tajā mēģinātas vai dejotas).

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/citibas_purs.py
"""

import calendar
import csv
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import date, timedelta
from tkinter import ttk, messagebox, filedialog

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible,
                               ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                               STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64, GENDER_MALE, GENDER_FEMALE,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible,
                        ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                        STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64, GENDER_MALE, GENDER_FEMALE,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

try:  # started from Pūrlāde
    from moduli.kopeja import (DANCER_GROUPS, DEFAULT_DANCER_GROUP, ensure_event_detail_columns, event_groups,
                               event_groups_text, groups_label, in_event_groups, date_picker_button)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DANCER_GROUPS, DEFAULT_DANCER_GROUP, ensure_event_detail_columns, event_groups,
                        event_groups_text, groups_label, in_event_groups, date_picker_button)

PROGRAM_NAME = "Cītības pūrs"
APP_VERSION = "0.2.2"
COPPER = "#C4703A"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Mēģinājumu un pasākumu apmeklējuma uzskaite",
    "letter": "C",
    "color": COPPER,
}

# ---- choices --------------------------------------------------------------
KIND_REHEARSAL = "Mēģinājums"
KIND_EXTRA = "Papildmēģinājums"
KIND_CONCERT = "Koncerts"
KIND_REVIEW = "Skate"
KIND_EVENT = "Kolektīva pasākums"
KINDS = [KIND_REHEARSAL, KIND_EXTRA, KIND_CONCERT, KIND_EVENT, KIND_REVIEW]
OLD_KINDS = {"Cits": KIND_EVENT}  # names used in v0.1.0 – v0.1.1, renamed in the database on start
REHEARSAL_KINDS = (KIND_REHEARSAL, KIND_EXTRA)
# dancers' answers (mobile app / Notikumu pūrs, table event_participants)
APP_YES, APP_NO, APP_MAYBE, APP_LATE = "Būs", "Nebūs", "Varbūt", "Kavēšu"
KIND_SHORT = {KIND_REHEARSAL: "", KIND_EXTRA: " P", KIND_CONCERT: " K", KIND_EVENT: " KP", KIND_REVIEW: " S"}

MARK_PRESENT = "Ieradās"
MARK_LATE = "Nokavēja"
MARK_EXCUSED = "Attaisnoti"
MARK_ABSENT = "Neattaisnoti"
MARKS = [MARK_PRESENT, MARK_LATE, MARK_EXCUSED, MARK_ABSENT]
CAME = (MARK_PRESENT, MARK_LATE)            # counted as attended
MARK_BUTTON = {MARK_PRESENT: "Ieradās", MARK_LATE: "Nokavēja",
               MARK_EXCUSED: "Attaisnoti nebija", MARK_ABSENT: "Neattaisnoti nebija"}
MARK_SYMBOL = {MARK_PRESENT: "✓", MARK_LATE: "N", MARK_EXCUSED: "A", MARK_ABSENT: "✗", "": ""}
MARK_TINT = {MARK_PRESENT: "#CDE8D5", MARK_LATE: "#F6E3B0", MARK_EXCUSED: "#D9DEEA", MARK_ABSENT: "#F2C4CB"}
MARK_CYCLE = ["", MARK_PRESENT, MARK_LATE, MARK_EXCUSED, MARK_ABSENT]

# dance statuses of Deju pūrs (in the order they are offered when choosing dances)
DANCE_LEARNING = "Procesā"
DANCE_IN_REPERTOIRE = "Repertuārā"
DANCE_RESTING = "Atpūtā"
DANCE_ARCHIVED = "Arhīvā"
DANCE_GROUPS = [DANCE_LEARNING, DANCE_IN_REPERTOIRE, DANCE_RESTING, DANCE_ARCHIVED]

GOOD_PCT = 90   # ≥ 90 % — cītīgs
LOW_PCT = 70    # < 70 % — zema cītība

MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts",
          "Septembris", "Oktobris", "Novembris", "Decembris"]
WEEKDAYS = ["Pirmd.", "Otrd.", "Trešd.", "Ceturtd.", "Piektd.", "Sestd.", "Svētd."]
WEEKDAYS_FULL = ["Pirmdiena", "Otrdiena", "Trešdiena", "Ceturtdiena", "Piektdiena", "Sestdiena", "Svētdiena"]

# planning a series of events (only when a new event is created) — the same as in Notikumu pūrs
REPEAT_WEEKDAYS = "weekdays"
REPEAT_DATES = "dates"
EVERY_WEEK = "katru nedēļu"
EVERY_2_WEEKS = "katru otro nedēļu"
EVERY_CHOICES = [EVERY_WEEK, EVERY_2_WEEKS]
MAX_REPEATS = 200
PLANNED = "Gaidāms"

# who is shown when marking attendance
SHOW_ALL = "Visi"
SHOW_MEN = "Puiši"
SHOW_WOMEN = "Meitas"
SHOW_GENDER = {SHOW_ALL: "", SHOW_MEN: GENDER_MALE, SHOW_WOMEN: GENDER_FEMALE}
SORT_FIRST = "Vārda"
SORT_LAST = "Uzvārda"

PERIOD_SEASON = "Šī sezona"
PERIOD_LAST_SEASON = "Iepriekšējā sezona"
PERIOD_MONTH = "Šis mēnesis"
PERIOD_YEAR = "Šis gads"
PERIOD_ALL = "Viss laiks"
PERIOD_CUSTOM = "Cits periods"
PERIODS = [PERIOD_SEASON, PERIOD_LAST_SEASON, PERIOD_MONTH, PERIOD_YEAR, PERIOD_ALL, PERIOD_CUSTOM]

SESSION_COLUMNS = [
    ("date", "Datums", 95),
    ("weekday", "Diena", 70),
    ("kind", "Veids", 130),
    ("groups", "Grupa", 80),
    ("title", "Nosaukums / tēma", 170),
    ("dances", "Dejas", 220),
    ("time", "Laiks", 60),
    ("app", "Atbildes lietotnē", 150),
    ("came", "Ieradās", 75),
    ("marked", "Atzīmēti", 75),
    ("pct", "Apmeklējums", 100),
]

STAT_COLUMNS = [
    ("first_name", "Vārds", 110),
    ("last_name", "Uzvārds", 130),
    ("status", "Statuss", 85),
    ("marked", "Notikumi", 90),
    ("present", "Ieradās", 70),
    ("late", "Nokavēja", 80),
    ("excused", "Attaisnoti", 85),
    ("absent", "Neattaisnoti", 95),
    ("pct", "Apmeklējums", 100),
    ("last_seen", "Pēdējoreiz", 95),
    ("streak", "Neieradās pēc kārtas", 145),
]


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attendance_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_date TEXT NOT NULL,
    kind TEXT DEFAULT '',
    title TEXT DEFAULT '',
    start_time TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    mark TEXT NOT NULL,
    note TEXT DEFAULT '',
    UNIQUE (session_id, dancer_id)
);
CREATE TABLE IF NOT EXISTS session_dances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    UNIQUE (session_id, dance_id)
);
CREATE INDEX IF NOT EXISTS idx_attendance_dancer ON attendance(dancer_id);
CREATE INDEX IF NOT EXISTS idx_sessions_date ON attendance_sessions(session_date);
CREATE TABLE IF NOT EXISTS event_details (
    session_id INTEGER PRIMARY KEY REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    status TEXT DEFAULT '', place TEXT DEFAULT '', address TEXT DEFAULT '', arrival_time TEXT DEFAULT '',
    end_time TEXT DEFAULT '', organizer TEXT DEFAULT '', contact TEXT DEFAULT '', transport TEXT DEFAULT '',
    fee TEXT DEFAULT '', costume_notes TEXT DEFAULT ''
);
"""


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        ensure_dancer_schema(self.con)
        self.con.executescript(SCHEMA)
        for old, new in OLD_KINDS.items():
            self.con.execute("UPDATE attendance_sessions SET kind=? WHERE kind=?", (new, old))
        ensure_event_detail_columns(self.con)   # event_details.for_groups (kurām grupām notikums)
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def set_mark(self, session_id, dancer_id, mark):
        if mark:
            self.x("INSERT INTO attendance (session_id, dancer_id, mark) VALUES (?,?,?) "
                   "ON CONFLICT(session_id, dancer_id) DO UPDATE SET mark=excluded.mark",
                   (session_id, dancer_id, mark))
        else:
            self.x("DELETE FROM attendance WHERE session_id=? AND dancer_id=?", (session_id, dancer_id))

    def has_dances(self):
        # the dances table belongs to Deju pūrs and exists only once that module has been used
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dances'"))

    def all_dances(self):
        """[(id, title, status)] from Deju pūrs, sorted by title."""
        if not self.has_dances():
            return []
        rows = self.q("SELECT id, title, status FROM dances")
        return sorted(((i, t or "", st or DANCE_IN_REPERTOIRE) for i, t, st in rows), key=lambda r: _norm(r[1]))

    def session_dances(self, session_ids=None):
        """{session id: [dance titles]} (for the given sessions or all)."""
        if not self.has_dances():
            return {}
        sql = ("SELECT sd.session_id, d.title FROM session_dances sd JOIN dances d ON d.id = sd.dance_id")
        params = []
        if session_ids is not None:
            ids = list(session_ids)
            if not ids:
                return {}
            sql += " WHERE sd.session_id IN (" + ",".join("?" * len(ids)) + ")"
            params = ids
        result = {}
        for sid, title in self.q(sql, params):
            result.setdefault(sid, []).append(title or "")
        for titles in result.values():
            titles.sort(key=_norm)
        return result

    def dance_cast(self, dance_ids):
        """Dancer ids in the casts of the given dances (Deju pūrs)."""
        ids = list(dance_ids)
        if not ids or not self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dance_cast'"):
            return set()
        return {r[0] for r in self.q("SELECT dancer_id FROM dance_cast WHERE dance_id IN ("
                                     + ",".join("?" * len(ids)) + ")", ids)}

    def dancer_groups(self):
        """{dancer id: group (A, Studija, VPDK)} from Kopas pūrs."""
        if "dancer_group" not in {c[1] for c in self.q("PRAGMA table_info(dancers)")}:
            return {}
        return {i: (g or "") for i, g in self.q("SELECT id, dancer_group FROM dancers")}

    def session_groups(self, session_ids=None):
        """{session id: 'A,Studija'} — which groups each event is for (empty — all groups)."""
        rows = self.q("SELECT session_id, for_groups FROM event_details")
        return {sid: (g or "") for sid, g in rows if session_ids is None or sid in session_ids}

    def save_groups(self, session_id, groups_text):
        self.con.execute("INSERT INTO event_details (session_id, for_groups) VALUES (?, ?) "
                         "ON CONFLICT(session_id) DO UPDATE SET for_groups=excluded.for_groups",
                         (session_id, groups_text))

    def dancers(self, include_ids=()):
        """Active dancers + the given ones (e.g. already marked in a session), sorted by name."""
        ids = list(include_ids)
        extra = (" OR id IN (" + ",".join("?" * len(ids)) + ")") if ids else ""
        rows = self.q("SELECT id, first_name, last_name, gender, status FROM dancers WHERE "
                      + active_dancer_sql("dancers") + extra, ids)
        rows.sort(key=lambda r: (_norm(r[2]), _norm(r[1])))
        return rows


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def groups_short(text):
    label = groups_label(text)
    return "visas" if label == "visas grupas" else label


def weekday(iso):
    try:
        return WEEKDAYS[date.fromisoformat(iso).weekday()]
    except (TypeError, ValueError):
        return ""


def parse_time(text):
    """'18', '18:30', '18.30', '1830' -> '18:30'; '' when empty; None when bad."""
    text = (text or "").strip()
    if not text:
        return ""
    m = re.fullmatch(r"(\d{1,2})(?:[:.\s]?(\d{2}))?", text)
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2) or 0)
    return f"{h:02d}:{mi:02d}" if h < 24 and mi < 60 else None


def pct(came, marked):
    return round(100 * came / marked) if marked else None


def pct_text(value):
    return "—" if value is None else f"{value} %"


def pct_tag(value):
    if value is None:
        return "none"
    if value >= GOOD_PCT:
        return "good"
    return "low" if value < LOW_PCT else "mid"


def season_of(day):
    """Dance season runs from 1 September to 31 August."""
    start_year = day.year if day.month >= 9 else day.year - 1
    return date(start_year, 9, 1), date(start_year + 1, 8, 31)


def period_dates(name, today=None):
    today = today or date.today()
    if name == PERIOD_SEASON:
        return season_of(today)
    if name == PERIOD_LAST_SEASON:
        s, _e = season_of(today)
        return date(s.year - 1, 9, 1), date(s.year, 8, 31)
    if name == PERIOD_MONTH:
        return today.replace(day=1), today.replace(day=calendar.monthrange(today.year, today.month)[1])
    if name == PERIOD_YEAR:
        return date(today.year, 1, 1), date(today.year, 12, 31)
    return None, None  # Viss laiks


def sort_rows(rows, key, desc):
    """Stable sort by one column; empty values (None, '') always stay at the bottom."""
    filled = [r for r in rows if r[key] not in (None, "")]
    empty = [r for r in rows if r[key] in (None, "")]
    filled.sort(key=lambda r: r[key] if isinstance(r[key], int) else _norm(r[key]), reverse=desc)
    return filled + empty


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def tag_colours(tree):
    tree.tag_configure("good", foreground=GREEN)
    tree.tag_configure("mid", foreground=AMBER)
    tree.tag_configure("low", foreground=RED)
    tree.tag_configure("none", foreground=GREY)
    tree.tag_configure("planned", foreground="#7A5C99")
    tree.tag_configure("today", background="#FCEFC7", font=("Segoe UI", 10, "bold"))


# --------------------------------------------------------------------------
# One session: details + marks for every dancer
# --------------------------------------------------------------------------
class SessionWindow(tk.Toplevel):
    def __init__(self, app, session_id=None, on_saved=None, day=None):
        super().__init__(app.root)
        self.app, self.db, self.session_id, self.on_saved = app, app.db, session_id, on_saved
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title("Jauns notikums" if session_id is None else "Notikums")
        self.geometry("900x740")
        self.transient(app.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.changed = False
        self.selected_dances = set()
        self.dance_info = {i: (t, st) for i, t, st in self.db.all_dances()}

        tk.Label(self, text="Jauns notikums" if session_id is None else "Notikums",
                 font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w", pady=(0, 8))

        # ---- buttons (packed first so they never leave the window) ----
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.cancel).pack(side="right", padx=6)
        if session_id is not None:
            ttk.Button(btns, text="Dzēst notikumu", style="Danger.TButton",
                       command=self.delete).pack(side="left")

        # ---- session details ----
        form = tk.Frame(self, bg=CREAM)
        form.pack(fill="x")
        self.v_date, self.v_kind, self.v_title = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_time, self.v_notes = tk.StringVar(), tk.StringVar()

        def label(text, r, c):
            tk.Label(form, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))
        label("Datums *", 0, 0)
        date_box = tk.Frame(form, bg=CREAM)
        date_box.grid(row=0, column=1, sticky="w", padx=(8, 0))
        date_entry = ttk.Entry(date_box, textvariable=self.v_date, width=12)
        date_entry.pack(side="left")
        date_picker_button(date_box, self.v_date).pack(side="left", padx=(2, 0))   # izvēle no kalendāra
        self.weekday_lbl = tk.Label(date_box, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), width=11,
                                    anchor="w")
        self.weekday_lbl.pack(side="left", padx=(4, 0))
        label("Veids", 0, 2)
        ttk.Combobox(form, textvariable=self.v_kind, values=KINDS, state="readonly", width=18).grid(
            row=0, column=3, sticky="w", padx=(8, 0))
        label("Sākuma laiks", 0, 4)
        ttk.Entry(form, textvariable=self.v_time, width=8).grid(row=0, column=5, sticky="w", padx=(8, 0))
        label("Nosaukums / tēma", 1, 0)
        ttk.Entry(form, textvariable=self.v_title).grid(row=1, column=1, columnspan=5, sticky="ew", padx=(8, 0),
                                                        pady=4)
        label("Piezīmes", 2, 0)
        ttk.Entry(form, textvariable=self.v_notes).grid(row=2, column=1, columnspan=5, sticky="ew", padx=(8, 0),
                                                        pady=4)
        label("Dejas", 3, 0)
        self.dances_lbl = tk.Label(form, text="", bg=WHITE, fg=NAVY, anchor="w", justify="left", wraplength=480,
                                   padx=6, pady=3, highlightthickness=1, highlightbackground=CREAM_DARK)
        self.dances_lbl.grid(row=3, column=1, columnspan=4, sticky="ew", padx=(8, 0), pady=4)
        dbtn = tk.Frame(form, bg=CREAM)
        dbtn.grid(row=3, column=5, sticky="e", padx=(8, 0))
        ttk.Button(dbtn, text="Izvēlēties dejas…", command=self.pick_dances).pack(side="left")
        ttk.Button(dbtn, text="Kā pēdējā reizē", command=self.dances_like_last).pack(side="left", padx=(4, 0))
        form.columnconfigure(5, weight=1)
        tk.Label(form, text="Datumu raksta formā DD.MM.GGGG, laiku — 18:30. Dejas — no Deju pūra: mēģinājumā "
                            "mēģinātās, koncertā vai skatē dejotās.", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=4, column=0, columnspan=6, sticky="w")
        self.form = form
        self.repeat = None
        if session_id is None:  # a series of events can be planned only for a new event
            self.repeat = tk.BooleanVar(value=False)
            ttk.Checkbutton(form, text="↻ Atkārtojas (ieplānot vairākus notikumus)", variable=self.repeat,
                            command=self.toggle_repeat).grid(row=5, column=1, columnspan=5, sticky="w",
                                                             padx=(8, 0), pady=(2, 0))
            self.build_repeat()
        # which groups the event is for (Kopas pūrs → Grupa): only their dancers are listed for marking
        label("Grupa *", 6, 0)
        gbox = tk.Frame(form, bg=CREAM)
        gbox.grid(row=6, column=1, columnspan=5, sticky="w", padx=(8, 0))
        self.group_vars = {}
        for g in DANCER_GROUPS:
            var = tk.BooleanVar(value=False)
            ttk.Checkbutton(gbox, text=g, variable=var, command=self.on_groups).pack(side="left", padx=(0, 10))
            self.group_vars[g] = var
        tk.Label(gbox, text="sarakstā — tikai šo grupu dejotāji (un jau atzīmētie); Kabatas Pūrlādē notikumu redz "
                            "tikai šīs grupas", bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).pack(side="left")
        self.dancer_group = self.db.dancer_groups()

        # ---- toolbar ----
        tools = tk.Frame(self, bg=CREAM)
        tools.pack(fill="x", pady=(10, 4))
        tk.Label(tools, text="Dejotāju atzīmes", font=("Georgia", 12, "bold"), bg=CREAM, fg=NAVY).pack(side="left")
        tk.Label(tools, text="(blakus vārdam — atbilde lietotnē)", font=("Segoe UI", 8, "italic"), bg=CREAM,
                 fg=GREY).pack(side="left", padx=(6, 0))
        ttk.Button(tools, text="✓ Pārējie ieradās", command=self.mark_rest_present).pack(side="left", padx=(14, 4))
        ttk.Button(tools, text="Notīrīt atzīmes", command=self.clear_marks).pack(side="left", padx=4)
        self.only_cast = tk.BooleanVar(value=False)
        self.only_cast_cb = ttk.Checkbutton(tools, text="Tikai izvēlēto deju sastāvs", variable=self.only_cast,
                                            command=self.apply_filter)
        self.only_cast_cb.pack(side="left", padx=(10, 0))
        self.show_who = tk.StringVar(value=SHOW_ALL)
        who = tk.Frame(tools, bg=CREAM)
        who.pack(side="left", padx=(14, 0))
        tk.Label(who, text="Rādīt:", bg=CREAM, fg=NAVY).pack(side="left", padx=(0, 4))
        for option in (SHOW_ALL, SHOW_MEN, SHOW_WOMEN):
            tk.Radiobutton(who, text=option, variable=self.show_who, value=option, indicatoron=0, width=7,
                           bg=CREAM_DARK, fg=NAVY, selectcolor=GOLD, activebackground=GOLD, activeforeground=NAVY,
                           relief="flat", bd=1, offrelief="flat", overrelief="ridge", font=("Segoe UI", 9),
                           cursor="hand2", command=self.apply_filter).pack(side="left", padx=1)
        self.counter = tk.Label(tools, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"))
        self.counter.pack(side="right")

        # ---- search and sorting ----
        tools2 = tk.Frame(self, bg=CREAM)
        tools2.pack(fill="x", pady=(0, 4))
        tk.Label(tools2, text="Meklēt dejotāju:", bg=CREAM, fg=NAVY).pack(side="left")
        self.search = tk.StringVar()
        self.search_entry = ttk.Entry(tools2, textvariable=self.search, width=24)
        self.search_entry.pack(side="left", padx=(6, 2))
        tk.Button(tools2, text="✕", command=lambda: self.search.set(""), bg=CREAM, fg=GREY, relief="flat", bd=0,
                  activebackground=GOLD, cursor="hand2", font=("Segoe UI", 9)).pack(side="left", padx=(0, 14))
        self.search.trace_add("write", lambda *a: self.apply_filter())
        tk.Label(tools2, text="Kārtot pēc:", bg=CREAM, fg=NAVY).pack(side="left", padx=(0, 4))
        self.sort_by = tk.StringVar(value=SORT_FIRST)
        for option in (SORT_FIRST, SORT_LAST):
            tk.Radiobutton(tools2, text=option + " ▲", variable=self.sort_by, value=option, indicatoron=0, width=10,
                           bg=CREAM_DARK, fg=NAVY, selectcolor=GOLD, activebackground=GOLD, activeforeground=NAVY,
                           relief="flat", bd=1, offrelief="flat", overrelief="ridge", font=("Segoe UI", 9),
                           cursor="hand2", command=self.apply_filter).pack(side="left", padx=1)
        tk.Label(tools2, text="(alfabēta secībā)", bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).pack(
            side="left", padx=(6, 0))

        # ---- scrollable list of dancers ----
        box = tk.Frame(self, bg=CREAM, highlightthickness=1, highlightbackground=GOLD)
        box.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(box, bg=WHITE, highlightthickness=0)
        sb = ttk.Scrollbar(box, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.rows_frame = tk.Frame(self.canvas, bg=WHITE)
        win_id = self.canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        self.rows_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(win_id, width=e.width))
        self.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                                     "units"))
        self.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        self.bind("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))

        # ---- load ----
        existing = {}
        if session_id is not None:
            d, kind, title, tm, notes = self.db.q("SELECT session_date, kind, title, start_time, notes FROM "
                                                  "attendance_sessions WHERE id=?", (session_id,))[0]
            self.v_date.set(show_date(d))
            self.v_kind.set(kind or KIND_REHEARSAL)
            self.v_title.set(title or "")
            self.v_time.set(tm or "")
            self.v_notes.set(notes or "")
            existing = {did: (mark, note) for did, mark, note in
                        self.db.q("SELECT dancer_id, mark, note FROM attendance WHERE session_id=?", (session_id,))}
            chosen = event_groups(self.db.session_groups({session_id}).get(session_id, "")) or DANCER_GROUPS
            if self.dance_info:
                self.selected_dances = {r[0] for r in self.db.q("SELECT dance_id FROM session_dances "
                                                                "WHERE session_id=?", (session_id,))}
        else:
            self.v_date.set(show_date((day or date.today()).isoformat()))
            self.v_kind.set(KIND_REHEARSAL)
            last_time = self.db.q("SELECT start_time FROM attendance_sessions WHERE kind=? AND start_time<>'' "
                                  "ORDER BY session_date DESC, id DESC LIMIT 1", (KIND_REHEARSAL,))
            if last_time:
                self.v_time.set(last_time[0][0])
            # groups as in the last rehearsal (else the default group A)
            last = self.db.q("SELECT e.for_groups FROM attendance_sessions s JOIN event_details e ON e.session_id = s.id "
                             "WHERE s.kind=? AND TRIM(COALESCE(e.for_groups,''))<>'' "
                             "ORDER BY s.session_date DESC, s.id DESC LIMIT 1", (KIND_REHEARSAL,))
            chosen = event_groups(last[0][0]) if last else [DEFAULT_DANCER_GROUP]
        for g, var in self.group_vars.items():
            var.set(g in chosen)

        # answers given in the mobile app (Notikumu pūrs uses the same table): shown next to each dancer;
        # "Nebūs" / "Kavēšu" pre-fill the mark of a dancer who has no mark yet (saved with "Saglabāt")
        self.app_answers = self.load_app_answers(session_id)
        self.marks, self.notes, self.rows, self.visible, self.genders, self.names = {}, {}, {}, [], {}, {}
        dancers = self.db.dancers(existing.keys())
        dancers.sort(key=lambda r: (_norm(r[1]), _norm(r[2])))  # alphabetically by first name
        if not dancers:
            tk.Label(self.rows_frame, text="Kopas pūrā nav neviena aktīva dejotāja.\n"
                                           "Vispirms pievienojiet dejotājus Kopas pūrā.",
                     bg=WHITE, fg=GREY, font=("Segoe UI", 11, "italic"), pady=30).pack(fill="x")
        for i, (did, first, last, gender, status) in enumerate(dancers):
            self.genders[did] = gender or ""
            self.names[did] = (first or "", last or "")
            mark, note = existing.get(did, ("", ""))
            answer = self.app_answers.get(did)
            if not mark and answer:
                ans, reason, late = answer
                if ans == APP_NO:
                    mark, note = MARK_EXCUSED, note or ("Lietotnē: nebūs" + (f" — {reason}" if reason else ""))
                elif ans == APP_LATE:
                    mark, note = MARK_LATE, note or (f"Lietotnē: kavēs {late} min" if late else "Lietotnē: kavēs") \
                        + (f" — {reason}" if reason else "")
            self.add_row(i, did, full_name(first, last), status, mark, note, answer)

        for var in (self.v_date, self.v_kind, self.v_title, self.v_time, self.v_notes):
            var.trace_add("write", lambda *a: self.set_changed())
        self.v_date.trace_add("write", lambda *a: self.show_weekday())
        if self.repeat is not None:
            self.v_date.trace_add("write", lambda *a: self.update_repeat())
        self.show_weekday()
        self.show_dances()
        self.apply_filter()
        self.bind("<Escape>", lambda e: self.cancel())
        date_entry.focus_set()
        self.after(100, lambda: fit_min_size(self))

    def load_app_answers(self, session_id):
        """{dancer id: (answer, reason/comment, late minutes)} — answers from the mobile app / Notikumu pūrs."""
        if session_id is None:
            return {}
        try:
            rows = self.db.q("SELECT dancer_id, answer, note FROM event_participants WHERE session_id=?", (session_id,))
        except sqlite3.Error:
            return {}
        late = {}
        try:
            late = dict(self.db.q("SELECT dancer_id, late_minutes FROM app_answers WHERE session_id=?", (session_id,)))
        except sqlite3.Error:
            pass   # the mobile app has not been used yet
        return {did: (ans or "", note or "", int(late.get(did) or 0)) for did, ans, note in rows if ans}

    def add_row(self, i, did, name, status, mark, note, answer=None):
        bg = WHITE if i % 2 == 0 else CREAM
        row = tk.Frame(self.rows_frame, bg=bg)
        row.pack(fill="x")
        self.rows[did] = row
        inactive = (status or STATUS_ACTIVE) != STATUS_ACTIVE
        tk.Label(row, text=name + (f"  ({status.lower()})" if inactive else ""), bg=bg,
                 fg=GREY if inactive else NAVY, font=("Segoe UI", 10, "bold"), width=28, anchor="w").pack(
            side="left", padx=(10, 6), pady=4)
        ans_text, ans_fg = "", GREY
        if answer:
            ans, reason, late = answer
            ans_text = {APP_LATE: f"Kavēs {late} min" if late else "Kavēs"}.get(ans, ans)
            ans_fg = {APP_YES: GREEN, APP_NO: RED, APP_MAYBE: AMBER, APP_LATE: COPPER}.get(ans, NAVY)
        ans_lbl = tk.Label(row, text=ans_text, bg=bg, fg=ans_fg, font=("Segoe UI", 9, "bold"), width=12, anchor="w")
        ans_lbl.pack(side="left", padx=(0, 4))
        if answer and answer[1]:
            tip = answer[1]
            ans_lbl.bind("<Enter>", lambda e: self.counter.configure(text=f"{name}: {tip}"))
            ans_lbl.bind("<Leave>", lambda e: self.update_counter())
        var = tk.StringVar(value=mark)
        for m in MARKS:
            tk.Radiobutton(row, text=MARK_BUTTON[m], variable=var, value=m, indicatoron=0, width=15,
                           bg=CREAM_DARK, fg=NAVY, selectcolor=MARK_TINT[m], activebackground=GOLD,
                           activeforeground=NAVY, relief="flat", bd=1, offrelief="flat", overrelief="ridge",
                           font=("Segoe UI", 9), cursor="hand2").pack(side="left", padx=2, pady=4)
        tk.Button(row, text="✕", command=lambda: var.set(""), bg=bg, fg=GREY, relief="flat", bd=0,
                  activebackground=GOLD, cursor="hand2", font=("Segoe UI", 9)).pack(side="left", padx=(2, 8))
        note_var = tk.StringVar(value=note or "")
        ttk.Entry(row, textvariable=note_var, width=22).pack(side="left", fill="x", expand=True, padx=(0, 10))
        var.trace_add("write", lambda *a: (self.set_changed(), self.update_counter()))
        note_var.trace_add("write", lambda *a: self.set_changed())
        self.marks[did], self.notes[did] = var, note_var

    def set_changed(self):
        self.changed = True

    def show_weekday(self):
        d = parse_date(self.v_date.get())
        self.weekday_lbl.configure(text=WEEKDAYS_FULL[date.fromisoformat(d).weekday()] if d else "")

    # ---- planning a series (the same as in Notikumu pūrs) ------------------------
    def build_repeat(self):
        f = self.repeat_frame = tk.Frame(self, bg=CREAM_DARK, padx=12, pady=8, highlightthickness=1,
                                         highlightbackground=GOLD)
        self.repeat_mode = tk.StringVar(value=REPEAT_WEEKDAYS)
        self.repeat_days = [tk.BooleanVar(value=False) for _ in WEEKDAYS]
        self.repeat_every = tk.StringVar(value=EVERY_WEEK)
        self.repeat_until = tk.StringVar()
        self.repeat_dates = tk.StringVar()
        opts = dict(bg=CREAM_DARK, fg=NAVY, activebackground=CREAM_DARK, selectcolor=WHITE, cursor="hand2",
                    command=self.update_repeat)

        row1 = tk.Frame(f, bg=CREAM_DARK)
        row1.pack(fill="x")
        tk.Radiobutton(row1, text="Nedēļas dienās:", variable=self.repeat_mode, value=REPEAT_WEEKDAYS,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        for i, name in enumerate(WEEKDAYS):
            tk.Checkbutton(row1, text=name, variable=self.repeat_days[i], **opts).pack(side="left", padx=(0, 2))
        every = ttk.Combobox(row1, textvariable=self.repeat_every, values=EVERY_CHOICES, state="readonly", width=17)
        every.pack(side="left", padx=(10, 0))
        every.bind("<<ComboboxSelected>>", lambda e: self.update_repeat())
        tk.Label(row1, text="līdz", bg=CREAM_DARK, fg=NAVY).pack(side="left", padx=(10, 4))
        ttk.Entry(row1, textvariable=self.repeat_until, width=12).pack(side="left")
        date_picker_button(row1, self.repeat_until, bg=CREAM_DARK, fallback_var=self.v_date).pack(side="left", padx=(2, 0))
        tk.Label(row1, text="(ieskaitot)", bg=CREAM_DARK, fg=GREY, font=("Segoe UI", 8, "italic")).pack(
            side="left", padx=(4, 0))

        row2 = tk.Frame(f, bg=CREAM_DARK)
        row2.pack(fill="x", pady=(6, 0))
        tk.Radiobutton(row2, text="Konkrētos datumos:", variable=self.repeat_mode, value=REPEAT_DATES,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        ttk.Entry(row2, textvariable=self.repeat_dates).pack(side="left", fill="x", expand=True)
        tk.Label(row2, text="atdala ar komatu, piem., 07.11.2026, 21.11.2026", bg=CREAM_DARK, fg=GREY,
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(6, 0))

        self.repeat_lbl = tk.Label(f, text="", bg=CREAM_DARK, fg=NAVY, font=("Segoe UI", 9), anchor="w",
                                   justify="left", wraplength=820)
        self.repeat_lbl.pack(fill="x", pady=(6, 0))
        for var in (self.repeat_until, self.repeat_dates):
            var.trace_add("write", lambda *a: self.update_repeat())

    def toggle_repeat(self):
        if self.repeat.get():
            first = parse_date(self.v_date.get())
            if first and not any(v.get() for v in self.repeat_days):
                self.repeat_days[date.fromisoformat(first).weekday()].set(True)
            self.repeat_frame.pack(fill="x", pady=(6, 0), after=self.form)
        else:
            self.repeat_frame.pack_forget()
        self.update_repeat()

    def repeat_list(self):
        """(sorted ISO dates of all events to create, error text or None)."""
        first = parse_date(self.v_date.get())
        if not first:
            return None, "Norādiet pareizu datumu formā DD.MM.GGGG."
        if self.repeat is None or not self.repeat.get():
            return [first], None
        dates = {first}
        if self.repeat_mode.get() == REPEAT_WEEKDAYS:
            days = {i for i, v in enumerate(self.repeat_days) if v.get()}
            if not days:
                return None, "Izvēlieties vismaz vienu nedēļas dienu."
            until = parse_date(self.repeat_until.get())
            if not until:
                return None, "Norādiet, līdz kuram datumam notikums atkārtojas (DD.MM.GGGG)."
            if until < first:
                return None, "Datums “līdz” ir agrāks par notikuma datumu."
            step = 2 if self.repeat_every.get() == EVERY_2_WEEKS else 1
            d0 = date.fromisoformat(first)
            monday0 = d0 - timedelta(days=d0.weekday())
            d, end = d0, date.fromisoformat(until)
            while d <= end:
                week = ((d - timedelta(days=d.weekday())) - monday0).days // 7
                if d.weekday() in days and week % step == 0:
                    dates.add(d.isoformat())
                d += timedelta(days=1)
        else:
            parts = [p for p in re.split(r"[,;\s]+", self.repeat_dates.get()) if p]
            if not parts:
                return None, "Ierakstiet datumus, kuros notikums atkārtojas, atdalot tos ar komatu."
            for part in parts:
                d = parse_date(part)
                if not d:
                    return None, f"Nesaprotams datums “{part}”. Datumu raksta formā DD.MM.GGGG."
                dates.add(d)
        if len(dates) > MAX_REPEATS:
            return None, f"Pārāk daudz notikumu ({len(dates)}). Vienā reizē var izveidot līdz {MAX_REPEATS}."
        return sorted(dates), None

    def update_repeat(self):
        if self.repeat is None or not self.repeat.get():
            return
        dates, error = self.repeat_list()
        if error:
            self.repeat_lbl.configure(text="⚠ " + error, fg=RED)
            return
        shown = ", ".join(f"{show_date(d)} ({weekday(d)})" for d in dates[:14])
        more = f" … un vēl {len(dates) - 14}" if len(dates) > 14 else ""
        self.repeat_lbl.configure(text=f"Tiks izveidoti {len(dates)} notikumi ar vienādu veidu, laiku, nosaukumu, "
                                       f"piezīmēm un dejām: {shown}{more}. Dejotāju atzīmes tiek saglabātas tikai "
                                       f"{show_date(parse_date(self.v_date.get()))} notikumam.", fg=NAVY)

    # ---- dances --------------------------------------------------------------
    def show_dances(self):
        titles = sorted((self.dance_info[i][0] for i in self.selected_dances if i in self.dance_info), key=_norm)
        if titles:
            text = ", ".join(titles)
        elif self.dance_info:
            text = "— nav izvēlētas —"
        else:
            text = "Deju pūrā vēl nav nevienas dejas."
        self.dances_lbl.configure(text=text, fg=NAVY if titles else GREY)
        self.only_cast_cb.configure(state="normal" if titles else "disabled")
        if not titles and self.only_cast.get():
            self.only_cast.set(False)

    def set_dances(self, ids):
        ids = set(ids)
        if ids != self.selected_dances:
            self.selected_dances = ids
            self.set_changed()
        self.show_dances()
        self.apply_filter()

    def pick_dances(self):
        if not self.dance_info:
            messagebox.showinfo("Dejas", "Deju pūrā vēl nav nevienas dejas. Vispirms pievienojiet dejas Deju pūrā.",
                                parent=self)
            return
        DancePicker(self, self.dance_info, self.selected_dances, self.set_dances)

    def dances_like_last(self):
        rows = self.db.q("SELECT s.id FROM attendance_sessions s WHERE s.id<>? AND EXISTS "
                         "(SELECT 1 FROM session_dances sd WHERE sd.session_id = s.id) "
                         "ORDER BY s.session_date DESC, s.start_time DESC, s.id DESC LIMIT 1",
                         (self.session_id or -1,)) if self.dance_info else []
        if not rows:
            messagebox.showinfo("Dejas", "Nevienā citā notikumā vēl nav atzīmētas dejas.", parent=self)
            return
        self.set_dances(r[0] for r in self.db.q("SELECT dance_id FROM session_dances WHERE session_id=?",
                                                (rows[0][0],)))

    def chosen_groups(self):
        return [g for g, var in self.group_vars.items() if var.get()]

    def on_groups(self):
        self.changed = True
        self.apply_filter()

    def apply_filter(self):
        """Which dancers are shown and in what order: dancers of the event's groups and cast of the chosen
        dances (plus anyone already marked), boys / girls, the search text; sorted by first or last name."""
        if not hasattr(self, "sort_by") or not hasattr(self, "group_vars"):  # still building the window
            return
        groups = event_groups_text(self.chosen_groups())
        cast = self.db.dance_cast(self.selected_dances) if self.only_cast.get() else None
        gender = SHOW_GENDER.get(self.show_who.get(), "")
        term = _norm(self.search.get())
        by_last = self.sort_by.get() == SORT_LAST

        def key(did):
            first, last = self.names.get(did, ("", ""))
            return (_norm(last), _norm(first)) if by_last else (_norm(first), _norm(last))
        for row in self.rows.values():
            row.pack_forget()
        self.visible = []
        for did in sorted(self.rows, key=key):
            row = self.rows[did]
            if gender and self.genders.get(did) != gender:
                continue
            if term and term not in _norm(full_name(*self.names.get(did, ("", "")))):
                continue
            in_group = in_event_groups(self.dancer_group.get(did, ""), groups) or (cast is not None and did in cast)
            if (cast is None or did in cast or self.marks[did].get()) and (in_group or self.marks[did].get()):
                row.pack(fill="x")
                self.visible.append(did)
        for n, did in enumerate(self.visible):  # keep the white / cream stripes after filtering
            bg = WHITE if n % 2 == 0 else CREAM
            row = self.rows[did]
            row.configure(bg=bg)
            for child in row.winfo_children():
                if child.winfo_class() in ("Label", "Button"):
                    child.configure(bg=bg)
        self.canvas.yview_moveto(0)
        self.update_counter()

    def update_counter(self):
        values = [self.marks[did].get() for did in self.visible]
        marked = sum(1 for v in values if v)
        came = sum(1 for v in values if v in CAME)
        self.counter.configure(text=f"Atzīmēti {marked} no {len(values)}  ·  ieradās {came}"
                                    + (f"  ·  apmeklējums {pct_text(pct(came, marked))}" if marked else "")
                                    + "   (piezīmi var ierakstīt rindas beigās)")

    def mark_rest_present(self):
        for did in self.visible:
            if not self.marks[did].get():
                self.marks[did].set(MARK_PRESENT)

    def clear_marks(self):
        if any(v.get() for v in self.marks.values()) and messagebox.askyesno(
                "Notīrīt", "Noņemt visas šī notikuma atzīmes?", parent=self):
            for var in self.marks.values():
                var.set("")

    def save(self):
        day = parse_date(self.v_date.get())
        if not day:
            messagebox.showwarning("Datums", "Norādiet pareizu datumu formā DD.MM.GGGG.", parent=self)
            return
        tm = parse_time(self.v_time.get())
        if tm is None:
            messagebox.showwarning("Laiks", "Sākuma laiku norādiet formā 18:30.", parent=self)
            return
        dates, error = self.repeat_list()
        if error:
            messagebox.showwarning("Atkārtošana", error, parent=self)
            return
        if not self.chosen_groups():
            messagebox.showwarning("Grupa", "Atzīmējiet, kurai grupai (vai kurām grupām) ir šis notikums.", parent=self)
            return
        groups_text = event_groups_text(self.chosen_groups())
        kind = self.v_kind.get() or KIND_REHEARSAL
        busy = [d for d in dates if self.db.q("SELECT COUNT(*) FROM attendance_sessions WHERE session_date=? AND "
                                              "kind=? AND id<>?", (d, kind, self.session_id or -1))[0][0]]
        if busy:
            listed = ", ".join(show_date(d) for d in busy[:10]) + (" …" if len(busy) > 10 else "")
            text = (f"{show_date(day)} jau ir notikums ar veidu “{kind}”. Vai tomēr saglabāt vēl vienu?"
                    if len(dates) == 1 else
                    f"Šajos datumos jau ir notikums ar veidu “{kind}”: {listed}.\n\nVai tomēr izveidot arī tur?")
            if not messagebox.askyesno("Dublikāts", text, parent=self):
                return
        marks = {did: var.get() for did, var in self.marks.items() if var.get()}
        if (self.marks and not marks and day <= date.today().isoformat() and not messagebox.askyesno(
                "Nav atzīmju", "Nevienam dejotājam nav atzīmes. Saglabāt notikumu bez atzīmēm?", parent=self)):
            return
        if len(dates) > 1 and not messagebox.askyesno(
                "Ieplānot notikumus", f"Izveidot {len(dates)} notikumus ({show_date(dates[0])} – "
                                     f"{show_date(dates[-1])})?", parent=self):
            return
        info = (kind, self.v_title.get().strip(), tm, self.v_notes.get().strip())
        dances = [i for i in self.selected_dances if i in self.dance_info]
        con = self.db.con
        try:
            if self.session_id is None:
                created = {}
                for d in dates:
                    cur = con.execute("INSERT INTO attendance_sessions (session_date, kind, title, start_time, "
                                      "notes) VALUES (?,?,?,?,?)", (d,) + info)
                    created[d] = cur.lastrowid
                    self.db.save_groups(created[d], groups_text)
                    con.executemany("INSERT INTO session_dances (session_id, dance_id) VALUES (?,?)",
                                    [(created[d], i) for i in dances])
                self.session_id = created[day]
            else:
                con.execute("UPDATE attendance_sessions SET session_date=?, kind=?, title=?, start_time=?, notes=? "
                            "WHERE id=?", (day,) + info + (self.session_id,))
                self.db.save_groups(self.session_id, groups_text)
                con.execute("DELETE FROM session_dances WHERE session_id=?", (self.session_id,))
                con.executemany("INSERT INTO session_dances (session_id, dance_id) VALUES (?,?)",
                                [(self.session_id, i) for i in dances])
            # dancers' marks belong only to the event of the entered date
            con.execute("DELETE FROM attendance WHERE session_id=?", (self.session_id,))
            con.executemany("INSERT INTO attendance (session_id, dancer_id, mark, note) VALUES (?,?,?,?)",
                            [(self.session_id, did, m, self.notes[did].get().strip()) for did, m in marks.items()])
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        self.changed = False
        self.app.refresh(select_session=self.session_id)
        if self.on_saved:
            self.on_saved()
        self.destroy()

    def delete(self):
        d = show_date(self.db.q("SELECT session_date FROM attendance_sessions WHERE id=?", (self.session_id,))[0][0])
        if not messagebox.askyesno("Dzēst", f"Dzēst notikumu ({d}) un visas tā atzīmes?", parent=self):
            return
        self.db.x("DELETE FROM attendance WHERE session_id=?", (self.session_id,))
        self.db.x("DELETE FROM session_dances WHERE session_id=?", (self.session_id,))
        self.db.x("DELETE FROM attendance_sessions WHERE id=?", (self.session_id,))
        self.app.refresh()
        if self.on_saved:
            self.on_saved()
        self.destroy()

    def cancel(self):
        if self.changed and not messagebox.askyesno("Nesaglabātas izmaiņas",
                                                    "Aizvērt, nesaglabājot izmaiņas?", parent=self):
            return
        self.destroy()


# --------------------------------------------------------------------------
# Several events today: which one to open
# --------------------------------------------------------------------------
class TodayChooser(tk.Toplevel):
    def __init__(self, app, rows):
        super().__init__(app.root)
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Šodienas notikumi")
        self.transient(app.root)
        self.resizable(False, False)
        tk.Label(self, text="Šodien ir vairāki notikumi", font=("Georgia", 13, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w", pady=(0, 8))
        for sid, kind, title, tm in rows:
            text = "  ·  ".join(p for p in (tm, kind, title) if p)
            ttk.Button(self, text=text, command=lambda s=sid: self.open(app, s)).pack(fill="x", pady=2)
        ttk.Button(self, text="Atcelt", command=self.destroy).pack(anchor="e", pady=(10, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()

    def open(self, app, sid):
        self.destroy()
        SessionWindow(app, sid)


# --------------------------------------------------------------------------
# Choosing the dances of a session
# --------------------------------------------------------------------------
class DancePicker(tk.Toplevel):
    def __init__(self, parent, dance_info, selected, on_ok):
        super().__init__(parent)
        self.on_ok = on_ok
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title("Notikuma dejas")
        self.geometry("460x560")
        self.transient(parent)
        self.grab_set()
        tk.Label(self, text="Kuras dejas mēģinātas vai dejotas?", font=("Georgia", 13, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w", pady=(0, 6))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Button(btns, text="Gatavs", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        ttk.Button(btns, text="Noņemt visas", command=lambda: [v.set(False) for v in self.vars.values()]).pack(
            side="left")

        box = tk.Frame(self, bg=WHITE, highlightthickness=1, highlightbackground=GOLD)
        box.pack(fill="both", expand=True)
        canvas = tk.Canvas(box, bg=WHITE, highlightthickness=0)
        sb = ttk.Scrollbar(box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=WHITE)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))
        self.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                                "units"))
        self.bind("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))
        self.bind("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))

        self.vars = {}
        groups = {g: [] for g in DANCE_GROUPS}
        for did, (title, status) in dance_info.items():
            groups.setdefault(status if status in groups else DANCE_IN_REPERTOIRE, []).append((did, title))
        for group, dances in groups.items():
            if not dances:
                continue
            tk.Label(inner, text=group, font=("Segoe UI", 10, "bold"), bg=WHITE,
                     fg=GREY if group in (DANCE_RESTING, DANCE_ARCHIVED) else RED).pack(anchor="w", padx=10,
                                                                                       pady=(8, 2))
            for did, title in sorted(dances, key=lambda r: _norm(r[1])):
                var = tk.BooleanVar(value=did in selected)
                tk.Checkbutton(inner, text=title, variable=var, bg=WHITE, fg=NAVY, activebackground=CREAM,
                               selectcolor=WHITE, anchor="w", font=("Segoe UI", 10), cursor="hand2").pack(
                    fill="x", padx=(22, 10))
                self.vars[did] = var
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.ok())

    def ok(self):
        self.on_ok(did for did, var in self.vars.items() if var.get())
        self.destroy()


# --------------------------------------------------------------------------
# One dancer: all sessions in the chosen period
# --------------------------------------------------------------------------
class DancerHistory(tk.Toplevel):
    def __init__(self, app, dancer_id):
        super().__init__(app.root)
        self.app, self.dancer_id = app, dancer_id
        self.configure(bg=CREAM, padx=16, pady=12)
        self.geometry("760x560")
        self.transient(app.root)
        name = app.db.q("SELECT name FROM dancers WHERE id=?", (dancer_id,))[0][0]
        self.title(f"Cītība — {name}")
        tk.Label(self, text=name, font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        self.summary = tk.Label(self, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 10), justify="left")
        self.summary.pack(anchor="w", pady=(2, 8))

        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(8, 0))
        ttk.Button(btns, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        tk.Label(btns, text="Dubultklikšķis uz rindas atver notikumu.", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(side="left")

        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        cols = [("date", "Datums", 95), ("weekday", "Diena", 70), ("kind", "Veids", 130),
                ("title", "Nosaukums / tēma", 190), ("mark", "Atzīme", 140), ("note", "Piezīme", 150)]
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=key in ("title", "note"))
        for m in MARKS:
            self.tree.tag_configure(m, background=MARK_TINT[m])
        self.tree.bind("<Double-1>", self.open_session)
        make_tree_with_scroll(holder, self.tree)
        self.bind("<Escape>", lambda e: self.destroy())
        self.fill()

    def fill(self):
        if not self.winfo_exists():
            return
        start, end, kind = self.app.filters()
        sql = ("SELECT s.id, s.session_date, s.kind, s.title, a.mark, a.note FROM attendance a "
               "JOIN attendance_sessions s ON s.id=a.session_id WHERE a.dancer_id=? AND s.session_date BETWEEN ? AND ?")
        params = [self.dancer_id, start, end]
        if kind:
            sql += " AND s.kind=?"
            params.append(kind)
        rows = self.app.db.q(sql + " ORDER BY s.session_date DESC, s.start_time DESC, s.id DESC", params)
        self.tree.delete(*self.tree.get_children())
        counts = {m: 0 for m in MARKS}
        for sid, d, k, title, mark, note in rows:
            counts[mark] = counts.get(mark, 0) + 1
            self.tree.insert("", "end", iid=str(sid), tags=(mark,),
                             values=(show_date(d), weekday(d), k, title, MARK_BUTTON.get(mark, mark), note or ""))
        came = counts[MARK_PRESENT] + counts[MARK_LATE]
        p = pct(came, len(rows))
        self.summary.configure(
            text=f"Periods: {self.app.period_text()}\n"
                 f"Notikumi: {len(rows)}  ·  ieradās {counts[MARK_PRESENT]}  ·  nokavēja {counts[MARK_LATE]}  ·  "
                 f"attaisnoti nebija {counts[MARK_EXCUSED]}  ·  neattaisnoti nebija {counts[MARK_ABSENT]}  ·  "
                 f"apmeklējums {pct_text(p)}")

    def open_session(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            SessionWindow(self.app, int(row), on_saved=self.fill)


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        today = date.today()
        self.journal_month = (today.year, today.month)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
        s.configure("TFrame", background=CREAM)
        s.configure("TLabel", background=CREAM, foreground=NAVY)
        s.configure("TCheckbutton", background=CREAM, foreground=NAVY)
        s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
        s.map("TButton", background=[("active", GOLD)])
        s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Danger.TButton", background=CREAM_DARK, foreground=RED, font=("Segoe UI", 10, "bold"))
        s.map("Danger.TButton", background=[("active", RED)], foreground=[("active", CREAM)])
        s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                    bordercolor=GOLD)
        s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                    padding=6)
        s.map("Treeview.Heading", background=[("active", RED)])
        s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])
        s.configure("TNotebook", background=CREAM, borderwidth=0)
        s.configure("TNotebook.Tab", background=CREAM_DARK, foreground=NAVY, padding=(14, 5),
                    font=("Segoe UI", 10, "bold"))
        s.map("TNotebook.Tab", background=[("selected", NAVY)], foreground=[("selected", CREAM)])

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        header = tk.Frame(self.root, bg=NAVY)
        header.pack(fill="x")
        header.columnconfigure(0, weight=1, uniform="h")
        header.columnconfigure(2, weight=1, uniform="h")
        left = tk.Frame(header, bg=NAVY)
        left.grid(row=0, column=0, sticky="w")
        logo = module_logo(left, "citibas_purs", on_click=self.show_main)
        if logo is not None:
            logo.pack(side="left", padx=(16, 0), pady=6)
        title_box = tk.Frame(left, bg=NAVY)
        title_box.pack(side="left", padx=(12 if logo is not None else 20, 12), pady=12)
        tk.Label(title_box, text=PROGRAM_NAME, font=("Georgia", 20, "bold"), bg=NAVY, fg=CREAM).pack(anchor="w")
        centre = tk.Frame(header, bg=NAVY)
        centre.place(relx=0.5, rely=0.5, anchor="center")
        # collective name with the collective logo underneath
        self.group_logo = group_logo(150, 40)
        tk.Label(centre, text=read_setting("app.group_name", "Tautas deju kolektīvs"),
                 font=("Georgia", 14, "italic"), bg=NAVY, fg=GOLD).pack(
            side="top", pady=(4, 2) if self.group_logo is not None else 12)
        if self.group_logo is not None:
            tk.Label(centre, image=self.group_logo, bg=NAVY).pack(side="top", pady=(0, 4))
        right = tk.Frame(header, bg=NAVY)
        right.grid(row=0, column=2, sticky="e", padx=14, pady=10)
        try:
            self.power_icon = tk.PhotoImage(data=HOME_ICON_B64 if self.on_exit is not None else POWER_ICON_B64)
        except Exception:
            self.power_icon = None
        embedded = self.on_exit is not None
        tk.Button(right, text=" Atgriezties moduļu izvēlē" if embedded else " Beigt darbu",
                  image=self.power_icon or "", compound="left",
                  command=self.on_exit if embedded else self.root.destroy, font=("Segoe UI", 11, "bold"),
                  bg=NAVY, fg=GOLD, activebackground=RED, activeforeground=CREAM, relief="flat", bd=0,
                  highlightthickness=2, highlightbackground=GOLD, highlightcolor=GOLD, cursor="hand2",
                  padx=12, pady=3).pack()
        tk.Frame(self.root, bg=GOLD, height=4).pack(fill="x")
        copyright_footer(self.root)

        # summary cards
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=18, pady=(14, 6))
        self.card_vars = {}
        for i, (key, title, colour) in enumerate([
                ("sessions", "Notikušie periodā (+ gaidāmie)", NAVY),
                ("average", "Vidējais apmeklējums", COPPER),
                ("last", "Pēdējā notikumā", GOLD),
                ("good", f"Cītīgie (≥ {GOOD_PCT} %)", GREEN),
                ("low", f"Zema cītība (< {LOW_PCT} %)", RED)]):
            card = tk.Frame(cards, bg=WHITE, highlightbackground=colour, highlightthickness=3)
            card.grid(row=0, column=i, padx=6, sticky="ew")
            cards.columnconfigure(i, weight=1, uniform="card")
            var = tk.StringVar(value="—")
            self.card_vars[key] = var
            tk.Label(card, textvariable=var, font=("Georgia", 24, "bold"), bg=WHITE, fg=colour).pack(pady=(6, 0))
            tk.Label(card, text=title, font=("Segoe UI", 9), bg=WHITE, fg=NAVY).pack(pady=(0, 6))

        # filters
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=18, pady=(8, 4))
        self.search = tk.StringVar()
        self.f_period = tk.StringVar(value=PERIOD_SEASON)
        self.f_from, self.f_to = tk.StringVar(), tk.StringVar()
        self.f_kind = tk.StringVar(value=ALL)
        ttk.Label(bar, text="Meklēt:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=18).pack(side="left", padx=(4, 12))
        self.search.trace_add("write", lambda *a: self.refresh())
        ttk.Label(bar, text="Periods:").pack(side="left")
        pcb = ttk.Combobox(bar, textvariable=self.f_period, values=PERIODS, state="readonly", width=17)
        pcb.pack(side="left", padx=(4, 6))
        pcb.bind("<<ComboboxSelected>>", lambda e: self.apply_period_preset())
        ttk.Label(bar, text="no").pack(side="left")
        e_from = ttk.Entry(bar, textvariable=self.f_from, width=11)
        e_from.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_from, on_pick=self.custom_period).pack(side="left", padx=(1, 4))
        ttk.Label(bar, text="līdz").pack(side="left")
        e_to = ttk.Entry(bar, textvariable=self.f_to, width=11)
        e_to.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_to, on_pick=self.custom_period).pack(side="left", padx=(1, 12))
        for e in (e_from, e_to):
            e.bind("<Return>", lambda ev: self.custom_period())
            e.bind("<FocusOut>", lambda ev: self.custom_period())
        ttk.Label(bar, text="Veids:").pack(side="left")
        kcb = ttk.Combobox(bar, textvariable=self.f_kind, values=[ALL] + KINDS, state="readonly", width=18)
        kcb.pack(side="left", padx=(4, 12))
        kcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Label(bar, text="Grupa:").pack(side="left")
        self.f_group = tk.StringVar(value=ALL)
        gcb = ttk.Combobox(bar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=8)
        gcb.pack(side="left", padx=4)
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Button(bar, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")
        self._period_dates_text = ("", "")
        self.apply_period_preset(refresh=False)

        btns = ttk.Frame(self.root)
        btns.pack(fill="x", padx=18, pady=4)
        ttk.Button(btns, text="＋ Jauns notikums", style="Accent.TButton",
                   command=lambda: SessionWindow(self)).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="⇩ Eksportēt cītību (Excel)", command=self.export).pack(side="left", padx=3)
        self.delete_btn = ttk.Button(btns, text="🗑 Dzēst iezīmētos notikumus", style="Danger.TButton",
                                     command=self.delete_sessions)
        self.delete_btn.pack(side="left", padx=(14, 3))
        count_box = tk.Frame(btns, bg=CREAM)
        count_box.pack(side="right")
        self.count_var = tk.StringVar()
        tk.Label(count_box, textvariable=self.count_var, bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(anchor="e")
        self.today_btn = ttk.Button(count_box, text="▶ Atvērt šodienas notikumu", style="Accent.TButton",
                                    command=self.open_today)
        self.today_btn.pack(anchor="e", pady=(4, 0))

        # tabs
        self.n_sessions, self.n_dancers, self.stat_rows, self.j_sessions = (0, 0), (0, 0), [], []
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=18, pady=(6, 6))
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.update_count())

        # 1) sessions
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Notikumi  ")
        self.s_tree = ttk.Treeview(tab, columns=[c[0] for c in SESSION_COLUMNS], show="headings",
                                   selectmode="extended")
        for key, title, width in SESSION_COLUMNS:
            self.s_tree.heading(key, text=title, command=lambda k=key: self.sort_sessions(k))
            self.s_tree.column(key, width=width, minwidth=45, anchor="w", stretch=key in ("title", "dances"))
        tag_colours(self.s_tree)
        self.s_tree.bind("<Double-1>", self.open_session)
        self.s_tree.bind("<Return>", self.open_session)
        self.s_tree.bind("<Delete>", lambda e: self.delete_sessions())
        self.s_tree.bind("<Control-a>", self.select_all_sessions)
        self.s_tree.bind("<Control-A>", self.select_all_sessions)
        self.s_tree.bind("<<TreeviewSelect>>", lambda e: self.update_count())
        make_tree_with_scroll(tab, self.s_tree)
        self.s_sort, self.s_desc = "date", True

        # 2) dancers
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Dejotāju cītība  ")
        top = ttk.Frame(tab)
        top.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        self.show_inactive = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Rādīt arī dejotājus uz pauzes un izstājušos", variable=self.show_inactive,
                        command=self.refresh).pack(side="left")
        tk.Label(top, text=f"Apmeklējums = (ieradās + nokavēja) / atzīmētie notikumi.  "
                           f"Zaļš ≥ {GOOD_PCT} %, dzeltens {LOW_PCT}–{GOOD_PCT - 1} %, sarkans < {LOW_PCT} %.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(side="right")
        holder = ttk.Frame(tab)
        holder.grid(row=1, column=0, sticky="nsew")
        tab.rowconfigure(1, weight=1)
        tab.columnconfigure(0, weight=1)
        self.d_tree = ttk.Treeview(holder, columns=[c[0] for c in STAT_COLUMNS], show="headings")
        for key, title, width in STAT_COLUMNS:
            self.d_tree.heading(key, text=title, command=lambda k=key: self.sort_stats(k))
            self.d_tree.column(key, width=width, minwidth=45,
                               anchor="w" if key in ("first_name", "last_name", "status") else "center",
                               stretch=False)
        tag_colours(self.d_tree)
        self.d_tree.bind("<Double-1>", self.open_dancer)
        self.d_tree.bind("<Return>", self.open_dancer)
        make_tree_with_scroll(holder, self.d_tree)
        self.d_sort, self.d_desc = "last_name", False

        # 3) journal (one month, dancers × sessions)
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Žurnāls  ")
        nav = ttk.Frame(tab)
        nav.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        ttk.Button(nav, text="◀", width=3, command=lambda: self.move_month(-1)).pack(side="left")
        self.month_lbl = tk.Label(nav, text="", font=("Georgia", 13, "bold"), bg=CREAM, fg=RED, width=16)
        self.month_lbl.pack(side="left", padx=6)
        ttk.Button(nav, text="▶", width=3, command=lambda: self.move_month(1)).pack(side="left")
        ttk.Button(nav, text="Šis mēnesis", command=self.this_month).pack(side="left", padx=(10, 0))
        tk.Label(nav, text="✓ ieradās   N nokavēja   A attaisnoti nebija   ✗ neattaisnoti nebija.   "
                           "Dubultklikšķis uz šūnas maina atzīmi, uz vārda — dejotāja vēsture, "
                           "uz datuma — notikums.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(side="right")
        holder = ttk.Frame(tab)
        holder.grid(row=1, column=0, sticky="nsew")
        tab.rowconfigure(1, weight=1)
        tab.columnconfigure(0, weight=1)
        self.j_tree = ttk.Treeview(holder, columns=("name",), show="headings")
        tag_colours(self.j_tree)
        self.j_tree.bind("<Double-1>", self.journal_click)
        make_tree_with_scroll(holder, self.j_tree)
        self.j_sessions = []

        self.refresh()

    # ---- filters ------------------------------------------------------------
    def apply_period_preset(self, refresh=True):
        name = self.f_period.get()
        if name == PERIOD_CUSTOM:
            return
        start, end = period_dates(name)
        self.f_from.set(show_date(start.isoformat()) if start else "")
        self.f_to.set(show_date(end.isoformat()) if end else "")
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        if refresh:
            self.refresh()

    def custom_period(self):
        if (self.f_from.get(), self.f_to.get()) == self._period_dates_text:
            return
        for var in (self.f_from, self.f_to):
            if parse_date(var.get()) is None:
                messagebox.showwarning("Periods", "Datumu raksta formā DD.MM.GGGG.", parent=self.root)
                var.set(self._period_dates_text[0 if var is self.f_from else 1])
                return
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        self.f_period.set(PERIOD_CUSTOM)
        self.refresh()

    def filters(self):
        """(start ISO, end ISO, kind or None) of the current filter."""
        start = parse_date(self.f_from.get()) or "0000-01-01"
        end = parse_date(self.f_to.get()) or "9999-12-31"
        kind = self.f_kind.get()
        return start, end, (None if kind == ALL else kind)

    def period_text(self):
        a, b = self.f_from.get().strip(), self.f_to.get().strip()
        if not a and not b:
            return PERIOD_ALL.lower()
        text = f"{a or '…'} – {b or '…'}"
        kind = self.f_kind.get()
        group = self.f_group.get() if hasattr(self, "f_group") else ALL
        return text + ("" if kind == ALL else f" ({kind.lower()})") + ("" if group == ALL else f", grupa {group}")

    def group_of_filter(self):
        g = self.f_group.get() if hasattr(self, "f_group") else ALL
        return None if g == ALL else g

    def clear_filters(self):
        self.search.set("")
        self.f_kind.set(ALL)
        self.f_group.set(ALL)
        self.f_period.set(PERIOD_SEASON)
        self.show_inactive.set(False)
        self.apply_period_preset()

    def show_main(self):
        """Module logo: back to the main view — this season, no filters, first tab."""
        self.clear_filters()
        self.nb.select(0)
        self.s_tree.selection_remove(self.s_tree.selection())
        self.s_tree.yview_moveto(0)

    # ---- data -------------------------------------------------------------
    def refresh(self, select_session=None):
        start, end, kind = self.filters()
        where, params = " WHERE s.session_date BETWEEN ? AND ?", [start, end]
        if kind:
            where += " AND s.kind=?"
            params.append(kind)
        sessions = self.db.q("SELECT s.id, s.session_date, s.kind, s.title, s.start_time FROM attendance_sessions s"
                             + where, params)
        marks = self.db.q("SELECT a.session_id, a.dancer_id, a.mark, s.session_date, s.start_time "
                          "FROM attendance a JOIN attendance_sessions s ON s.id=a.session_id" + where, params)
        self.groups_of = self.db.session_groups()
        group = self.group_of_filter()
        if group:   # only the events of this group, and only its dancers' marks
            sessions = [x for x in sessions if in_event_groups(group, self.groups_of.get(x[0], ""))]
            ids = {x[0] for x in sessions}
            dgroups = self.db.dancer_groups()
            marks = [m for m in marks if m[0] in ids and in_event_groups(dgroups.get(m[1], ""), group)]
        self.fill_sessions(sessions, marks, self.db.session_dances(s[0] for s in sessions), select_session,
                           self.app_answer_counts([s[0] for s in sessions]))
        stats = self.fill_stats(sessions, marks)
        self.update_cards(sessions, marks, stats)
        self.fill_journal()
        self.update_count()

    def app_answer_counts(self, session_ids):
        """{session id: 'Nebūs 2 · Kavēs 1 · Būs ✓ 5'} — answers from the mobile app (event_participants)."""
        if not session_ids:
            return {}
        try:
            rows = self.db.q("SELECT session_id, answer, COUNT(*) FROM event_participants WHERE answer<>'' "
                             "AND session_id IN (" + ",".join("?" * len(session_ids)) + ") GROUP BY session_id, answer",
                             session_ids)
        except sqlite3.Error:
            return {}
        per = {}
        for sid, ans, n in rows:
            per.setdefault(sid, {})[ans] = n
        labels = [(APP_NO, "Nebūs"), (APP_LATE, "Kavēs"), (APP_MAYBE, "Varbūt"), (APP_YES, "Būs ✓")]
        return {sid: " · ".join(f"{text} {c[a]}" for a, text in labels if c.get(a)) for sid, c in per.items()}

    def fill_sessions(self, sessions, marks, dances, select=None, app_counts=None):
        app_counts = app_counts or {}
        per = {}
        for sid, _did, mark, _d, _t in marks:
            m, c = per.get(sid, (0, 0))
            per[sid] = (m + 1, c + (mark in CAME))
        term = _norm(self.search.get())
        today = date.today().isoformat()
        rows = []
        for sid, d, kind, title, tm in sessions:
            dance_text = ", ".join(dances.get(sid, []))
            if term and term not in _norm(f"{kind} {title} {show_date(d)} {dance_text}"):
                continue
            marked, came = per.get(sid, (0, 0))
            rows.append({"id": sid, "date": d, "weekday": weekday(d), "kind": kind or "", "title": title or "",
                         "dances": dance_text, "planned": d > today and not marked, "today": d == today,
                         "time": tm or "", "app": app_counts.get(sid, ""), "came": came, "marked": marked, "pct": pct(came, marked)})

        rows.sort(key=lambda r: (r["date"], r["time"], r["id"]), reverse=True)
        if self.s_sort == "date":
            rows.sort(key=lambda r: (r["date"], r["time"], r["id"]), reverse=self.s_desc)
        else:
            rows = sort_rows(rows, self.s_sort, self.s_desc)
        keep = select or (self.s_tree.selection()[0] if self.s_tree.selection() else None)
        self.s_tree.delete(*self.s_tree.get_children())
        for r in rows:
            tags = ("planned",) if r["planned"] else (pct_tag(r["pct"]),)
            if r["today"]:
                tags += ("today",)
            self.s_tree.insert("", "end", iid=str(r["id"]), tags=tags, values=(
                show_date(r["date"]), r["weekday"], r["kind"], groups_short(self.groups_of.get(r["id"], "")),
                r["title"], r["dances"], r["time"], r["app"],
                "—" if r["planned"] else r["came"], r["marked"] or "—",
                PLANNED if r["planned"] else pct_text(r["pct"])))
        if keep is not None and self.s_tree.exists(str(keep)):
            self.s_tree.selection_set(str(keep))
            self.s_tree.see(str(keep))
        self.n_sessions = (len(rows), len(sessions))

    def fill_stats(self, sessions, marks):
        by_dancer = {}
        for _sid, did, mark, d, tm in marks:
            by_dancer.setdefault(did, []).append(((d, tm or ""), mark))
        show_all = self.show_inactive.get()
        dancers = self.db.q("SELECT id, first_name, last_name, status FROM dancers WHERE " + dancer_role_sql("dancers"))
        group = self.group_of_filter()
        if group:
            dgroups = self.db.dancer_groups()
            dancers = [r for r in dancers if in_event_groups(dgroups.get(r[0], ""), group)]
        stats, shown = [], []
        term = _norm(self.search.get())
        for did, first, last, status in dancers:
            status = status or STATUS_ACTIVE
            history = sorted(by_dancer.get(did, []))
            c = {m: 0 for m in MARKS}
            for _when, mark in history:
                c[mark] = c.get(mark, 0) + 1
            came = c[MARK_PRESENT] + c[MARK_LATE]
            last_seen = max((w[0] for w, m in history if m in CAME), default="")
            streak = 0
            for _when, mark in reversed(history):
                if mark in CAME:
                    break
                streak += 1
            r = {"id": did, "first_name": first or "", "last_name": last or "", "status": status,
                 "marked": len(history), "present": c[MARK_PRESENT], "late": c[MARK_LATE],
                 "excused": c[MARK_EXCUSED], "absent": c[MARK_ABSENT], "pct": pct(came, len(history)),
                 "last_seen": last_seen, "streak": streak}
            if status == STATUS_ACTIVE or history:
                stats.append(r)
            if status != STATUS_ACTIVE and not show_all:
                continue
            if term and term not in _norm(f"{first} {last}"):
                continue
            shown.append(r)

        shown.sort(key=lambda r: (_norm(r["last_name"]), _norm(r["first_name"])))
        shown = sort_rows(shown, self.d_sort, self.d_desc)
        keep = self.d_tree.selection()[0] if self.d_tree.selection() else None
        self.d_tree.delete(*self.d_tree.get_children())
        for r in shown:
            self.d_tree.insert("", "end", iid=str(r["id"]), tags=(pct_tag(r["pct"]),), values=(
                r["first_name"], r["last_name"], r["status"], r["marked"], r["present"], r["late"], r["excused"],
                r["absent"], pct_text(r["pct"]), show_date(r["last_seen"]) or "—",
                r["streak"] if r["streak"] else "—"))
        if keep is not None and self.d_tree.exists(keep):
            self.d_tree.selection_set(keep)
        self.stat_rows = shown
        self.n_dancers = (len(shown), len(stats))
        return stats

    def update_cards(self, sessions, marks, stats):
        today = date.today().isoformat()
        came = sum(1 for m in marks if m[2] in CAME)
        held = sum(1 for s in sessions if s[1] <= today)
        planned = len(sessions) - held
        self.card_vars["sessions"].set(f"{held} (+{planned})" if planned else str(held))
        self.card_vars["average"].set(pct_text(pct(came, len(marks))))
        past = [s for s in sessions if s[1] <= today]
        last_text = "—"
        if past:
            last = max(past, key=lambda s: (s[1], s[4] or "", s[0]))
            marked = [m for m in marks if m[0] == last[0]]
            if marked:
                last_text = f"{sum(1 for m in marked if m[2] in CAME)} / {len(marked)}"
        self.card_vars["last"].set(last_text)
        active = [r for r in stats if r["status"] == STATUS_ACTIVE and r["pct"] is not None]
        self.card_vars["good"].set(str(sum(1 for r in active if r["pct"] >= GOOD_PCT)))
        self.card_vars["low"].set(str(sum(1 for r in active if r["pct"] < LOW_PCT)))

    def update_count(self):
        try:
            tab = self.nb.index(self.nb.select())
        except tk.TclError:
            tab = 0
        if tab == 0:
            chosen = len(self.s_tree.selection()) if hasattr(self, "s_tree") else 0
            text = (f"Rādīti {self.n_sessions[0]} no {self.n_sessions[1]} notikumiem"
                    + (f", iezīmēti {chosen}" if chosen > 1 else "") + ". "
                    "Dubultklikšķis — atvērt; Ctrl / Shift — iezīmēt vairākus; Ctrl+A — visus.")
        elif tab == 1:
            text = (f"Rādīti {self.n_dancers[0]} dejotāji. "
                    "Dubultklikšķis — dejotāja apmeklējuma vēsture; klikšķis uz virsraksta — kārtot.")
        else:
            text = f"Žurnālā {len(self.j_sessions)} notikumi šajā mēnesī."
        self.count_var.set(text)

    def sort_sessions(self, key):
        self.s_desc = not self.s_desc if key == self.s_sort else key in ("date", "pct", "came", "marked")
        self.s_sort = key
        self.refresh()

    def sort_stats(self, key):
        numeric = key in ("marked", "present", "late", "excused", "absent", "pct", "streak", "last_seen")
        self.d_desc = not self.d_desc if key == self.d_sort else numeric
        self.d_sort = key
        self.refresh()

    # ---- journal ------------------------------------------------------------
    def move_month(self, step):
        y, m = self.journal_month
        m += step
        y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
        self.journal_month = (y, m)
        self.fill_journal()
        self.update_count()

    def this_month(self):
        today = date.today()
        self.journal_month = (today.year, today.month)
        self.fill_journal()
        self.update_count()

    def fill_journal(self):
        y, m = self.journal_month
        self.month_lbl.configure(text=f"{MONTHS[m - 1]} {y}")
        start = f"{y:04d}-{m:02d}-01"
        end = f"{y:04d}-{m:02d}-{calendar.monthrange(y, m)[1]:02d}"
        _s, _e, kind = self.filters()
        sql, params = "SELECT id, session_date, kind FROM attendance_sessions WHERE session_date BETWEEN ? AND ?", \
            [start, end]
        if kind:
            sql += " AND kind=?"
            params.append(kind)
        sessions = self.db.q(sql + " ORDER BY session_date, start_time, id", params)
        group = self.group_of_filter()
        if group:
            sgroups = self.db.session_groups()
            sessions = [x for x in sessions if in_event_groups(group, sgroups.get(x[0], ""))]
        self.j_sessions = [s[0] for s in sessions]
        marks = {}
        if sessions:
            ids = self.j_sessions
            for sid, did, mark in self.db.q("SELECT session_id, dancer_id, mark FROM attendance WHERE session_id IN ("
                                            + ",".join("?" * len(ids)) + ")", ids):
                marks[(sid, did)] = mark
        dancers = self.db.dancers({did for _sid, did in marks})
        if group:
            dgroups = self.db.dancer_groups()
            dancers = [r for r in dancers if in_event_groups(dgroups.get(r[0], ""), group)]
        term = _norm(self.search.get())

        cols = ["name"] + [f"s{sid}" for sid in self.j_sessions] + ["pct"]
        y_pos = self.j_tree.yview()[0]
        keep = self.j_tree.selection()[0] if self.j_tree.selection() else None
        self.j_tree.delete(*self.j_tree.get_children())
        self.j_tree.configure(columns=cols)
        self.j_tree.heading("name", text="Dejotājs")
        self.j_tree.column("name", width=200, minwidth=120, anchor="w", stretch=False)
        for sid, d, k in sessions:
            self.j_tree.heading(f"s{sid}", text=f"{d[8:10]}.{d[5:7]}{KIND_SHORT.get(k, '')}")
            self.j_tree.column(f"s{sid}", width=62, minwidth=50, anchor="center", stretch=False)
        self.j_tree.heading("pct", text="Mēnesī")
        self.j_tree.column("pct", width=80, minwidth=60, anchor="center", stretch=False)
        for did, first, last, _g, status in dancers:
            name = full_name(first, last)
            if term and term not in _norm(name):
                continue
            row = [marks.get((sid, did), "") for sid in self.j_sessions]
            marked = sum(1 for v in row if v)
            p = pct(sum(1 for v in row if v in CAME), marked)
            self.j_tree.insert("", "end", iid=str(did), tags=(pct_tag(p),),
                               values=[name] + [MARK_SYMBOL.get(v, v) for v in row] + [pct_text(p)])
        if not dancers:
            self.j_tree.insert("", "end", iid="empty", values=["Nav aktīvu dejotāju"], tags=("none",))
        if keep and self.j_tree.exists(keep):
            self.j_tree.selection_set(keep)
        self.j_tree.yview_moveto(y_pos)

    def journal_click(self, event):
        region = self.j_tree.identify_region(event.x, event.y)
        col = self.j_tree.identify_column(event.x)
        try:
            idx = int(col.lstrip("#")) - 1
        except ValueError:
            return
        if region == "heading":
            if 1 <= idx <= len(self.j_sessions):
                SessionWindow(self, self.j_sessions[idx - 1])
            return
        row = self.j_tree.identify_row(event.y)
        if not row or row == "empty":
            return
        did = int(row)
        if idx == 0:
            DancerHistory(self, did)
        elif 1 <= idx <= len(self.j_sessions):
            sid = self.j_sessions[idx - 1]
            current = self.db.q("SELECT mark FROM attendance WHERE session_id=? AND dancer_id=?", (sid, did))
            current = current[0][0] if current else ""
            nxt = MARK_CYCLE[(MARK_CYCLE.index(current) + 1) % len(MARK_CYCLE)] if current in MARK_CYCLE else ""
            self.db.set_mark(sid, did, nxt)
            self.refresh()
            self.j_tree.selection_set(row)

    # ---- actions ------------------------------------------------------------
    def open_session(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.s_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.s_tree.selection()
        if sel:
            SessionWindow(self, int(sel[0]))

    def select_all_sessions(self, event=None):
        self.s_tree.selection_set(self.s_tree.get_children())
        return "break"

    def delete_sessions(self):
        """Delete all events selected in the Notikumi list (with their marks, dances and app answers)."""
        if self.nb.index(self.nb.select()) != 0:
            self.nb.select(0)
        ids = [int(i) for i in self.s_tree.selection()]
        if not ids:
            messagebox.showinfo("Dzēst notikumus", "Cilnē “Notikumi” iezīmējiet notikumus, kurus dzēst.\n\n"
                                                   "Vairākus var iezīmēt, turot Ctrl vai Shift; visus — ar Ctrl+A.",
                                parent=self.root)
            return
        marks_sql = ",".join("?" * len(ids))
        rows = self.db.q("SELECT id, session_date, kind, title FROM attendance_sessions WHERE id IN (" + marks_sql
                         + ") ORDER BY session_date, start_time, id", ids)
        marked = dict(self.db.q("SELECT session_id, COUNT(*) FROM attendance WHERE session_id IN (" + marks_sql
                                + ") GROUP BY session_id", ids))
        lines = [f"{show_date(d)} ({weekday(d)})  {kind}" + (f" — {title}" if title else "")
                 + (f"  · atzīmes: {marked[sid]}" if marked.get(sid) else "")
                 for sid, d, kind, title in rows]
        listed = "\n".join(lines[:15]) + (f"\n… un vēl {len(lines) - 15}" if len(lines) > 15 else "")
        with_marks = sum(1 for sid, *_ in rows if marked.get(sid))
        warn = (f"\n\n⚠ {with_marks} no tiem ir dejotāju apmeklējuma atzīmes — arī tās tiks dzēstas."
                if with_marks else "")
        if not messagebox.askyesno(
                "Dzēst notikumus", f"Dzēst {len(rows)} notikumus?\n\n{listed}{warn}\n\n"
                                   "Tiks dzēstas arī to dejas, programma un dejotāju atbildes lietotnē. "
                                   "To nevar atsaukt.", icon="warning", parent=self.root):
            return
        if len(rows) >= 10 and not messagebox.askyesno(
                "Dzēst notikumus", f"Vai tiešām dzēst visus {len(rows)} notikumus?", icon="warning",
                parent=self.root):
            return
        existing = {r[0] for r in self.db.q("SELECT name FROM sqlite_master WHERE type='table'")}
        con = self.db.con
        try:
            for table in ("attendance", "session_dances", "event_details", "event_program", "event_participants",
                          "app_answers"):
                if table in existing:
                    con.execute(f"DELETE FROM {table} WHERE session_id IN ({marks_sql})", ids)
            con.execute(f"DELETE FROM attendance_sessions WHERE id IN ({marks_sql})", ids)
            con.commit()
        except sqlite3.Error as exc:
            con.rollback()
            messagebox.showerror("Dzēst notikumus", f"Neizdevās dzēst notikumus:\n{exc}", parent=self.root)
            return
        self.refresh()
        messagebox.showinfo("Dzēst notikumus", f"Dzēsti {len(rows)} notikumi.", parent=self.root)

    def open_today(self):
        """Open today's event; with several — choose one; with none — offer to create one."""
        today = date.today().isoformat()
        rows = self.db.q("SELECT id, kind, title, start_time FROM attendance_sessions WHERE session_date=? "
                         "ORDER BY start_time, id", (today,))
        if len(rows) == 1:
            SessionWindow(self, rows[0][0])
        elif rows:
            TodayChooser(self, rows)
        elif messagebox.askyesno("Šodienas notikums",
                                 f"Šodien ({show_date(today)}) nav ieplānots neviens notikums.\n\n"
                                 "Izveidot jaunu notikumu ar šodienas datumu?", parent=self.root):
            SessionWindow(self)

    def open_dancer(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.d_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.d_tree.selection()
        if sel:
            DancerHistory(self, int(sel[0]))

    def export(self):
        if not self.stat_rows:
            messagebox.showinfo("Eksports", "Nav datu, ko eksportēt.", parent=self.root)
            return
        today = show_date(date.today().isoformat())
        path = filedialog.asksaveasfilename(parent=self.root, title="Saglabāt cītības pārskatu",
                                            defaultextension=".csv", initialfile=f"Cītība {today}.csv",
                                            filetypes=[("Excel / CSV", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as fh:
                w = csv.writer(fh, delimiter=";")
                w.writerow([f"{PROGRAM_NAME} — dejotāju cītība", f"Periods: {self.period_text()}",
                            f"Sagatavots: {today}"])
                w.writerow([])
                w.writerow([t for _k, t, _w in STAT_COLUMNS])
                for r in self.stat_rows:
                    w.writerow([r["first_name"], r["last_name"], r["status"], r["marked"], r["present"], r["late"],
                                r["excused"], r["absent"], "" if r["pct"] is None else r["pct"],
                                show_date(r["last_seen"]), r["streak"]])
        except OSError as exc:
            messagebox.showerror("Eksports", f"Neizdevās saglabāt failu:\n{exc}", parent=self.root)
            return
        messagebox.showinfo("Eksports", f"Pārskats saglabāts:\n{path}\n\nFailu var atvērt ar Excel.",
                            parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
