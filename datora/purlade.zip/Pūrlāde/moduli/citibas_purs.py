#!/usr/bin/env python3
"""
Pūrlāde — modulis "Cītības pūrs" (mēģinājumu un pasākumu apmeklējuma uzskaitei)

Katram notikumam (mēģinājumam, koncertam, skatei …) dejotājiem tiek atzīmēts:
    Ieradās · Nokavēja · Attaisnoti nebija · Neattaisnoti nebija
Dejotāju saraksts tiek ņemts no Kopas pūra, deju saraksts — no Deju pūra
(katram notikumam var atzīmēt, kuras dejas tajā mēģinātas vai dejotas).

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/citibas_purs.py
"""

import calendar
import csv
import re
import sqlite3
import traceback
import tkinter as tk
import tkinter.font as tkfont
from datetime import date, datetime, timedelta
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible,
                               ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                               STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64, GENDER_MALE, GENDER_FEMALE,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible,
                        ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                        STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64, GENDER_MALE, GENDER_FEMALE,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

try:  # started from Pūrlāde
    from moduli.kopeja import (DANCER_GROUPS, DEFAULT_DANCER_GROUP, ensure_event_detail_columns, event_groups,
                               event_groups_text, groups_label, in_event_groups, date_picker_button)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DANCER_GROUPS, DEFAULT_DANCER_GROUP, ensure_event_detail_columns, event_groups,
                        event_groups_text, groups_label, in_event_groups, date_picker_button)

PROGRAM_NAME = "Cītības pūrs"
APP_VERSION = "0.2.9"
COPPER = "#C4703A"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Mēģinājumu un pasākumu apmeklējuma uzskaite",
    "letter": "C",
    "color": COPPER,
}

# ---- choices --------------------------------------------------------------
KIND_REHEARSAL = "Mēģinājums"
KIND_EXTRA = "Papildmēģinājums"
KIND_CONCERT = "Koncerts"
KIND_REVIEW = "Skate"
KIND_EVENT = "Kolektīva pasākums"
KINDS = [KIND_REHEARSAL, KIND_EXTRA, KIND_CONCERT, KIND_EVENT, KIND_REVIEW]
OLD_KINDS = {"Cits": KIND_EVENT}  # names used in v0.1.0 – v0.1.1, renamed in the database on start
REHEARSAL_KINDS = (KIND_REHEARSAL, KIND_EXTRA)
# dancers' answers (mobile app / Notikumu pūrs, table event_participants)
APP_YES, APP_NO, APP_MAYBE, APP_LATE = "Būs", "Nebūs", "Varbūt", "Kavēšu"
KIND_SHORT = {KIND_REHEARSAL: "", KIND_EXTRA: " P", KIND_CONCERT: " K", KIND_EVENT: " KP", KIND_REVIEW: " S"}

MARK_PRESENT = "Ieradās"
MARK_LATE = "Nokavēja"
MARK_EXCUSED = "Attaisnoti"
MARK_ABSENT = "Neattaisnoti"
MARKS = [MARK_PRESENT, MARK_LATE, MARK_EXCUSED, MARK_ABSENT]
CAME = (MARK_PRESENT, MARK_LATE)            # counted as attended
MARK_BUTTON = {MARK_PRESENT: "Ieradās", MARK_LATE: "Nokavēja",
               MARK_EXCUSED: "Attaisnoti nebija", MARK_ABSENT: "Neattaisnoti nebija"}
MARK_SYMBOL = {MARK_PRESENT: "✓", MARK_LATE: "N", MARK_EXCUSED: "A", MARK_ABSENT: "✗", "": ""}
MARK_TINT = {MARK_PRESENT: "#CDE8D5", MARK_LATE: "#F6E3B0", MARK_EXCUSED: "#D9DEEA", MARK_ABSENT: "#F2C4CB"}
MARK_CYCLE = ["", MARK_PRESENT, MARK_LATE, MARK_EXCUSED, MARK_ABSENT]

# dance statuses of Deju pūrs (in the order they are offered when choosing dances)
DANCE_LEARNING = "Procesā"
DANCE_IN_REPERTOIRE = "Repertuārā"
DANCE_RESTING = "Atpūtā"
DANCE_ARCHIVED = "Arhīvā"
DANCE_GROUPS = [DANCE_LEARNING, DANCE_IN_REPERTOIRE, DANCE_RESTING, DANCE_ARCHIVED]

GOOD_PCT = 90   # ≥ 90 % — cītīgs
LOW_PCT = 70    # < 70 % — zema cītība

MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts",
          "Septembris", "Oktobris", "Novembris", "Decembris"]
WEEKDAYS = ["Pirmd.", "Otrd.", "Trešd.", "Ceturtd.", "Piektd.", "Sestd.", "Svētd."]
WEEKDAYS_FULL = ["Pirmdiena", "Otrdiena", "Trešdiena", "Ceturtdiena", "Piektdiena", "Sestdiena", "Svētdiena"]

# planning a series of events (only when a new event is created) — the same as in Notikumu pūrs
REPEAT_WEEKDAYS = "weekdays"
REPEAT_DATES = "dates"
EVERY_WEEK = "katru nedēļu"
EVERY_2_WEEKS = "katru otro nedēļu"
EVERY_CHOICES = [EVERY_WEEK, EVERY_2_WEEKS]
MAX_REPEATS = 200
PLANNED = "Gaidāms"

# who is shown when marking attendance
SHOW_ALL = "Visi"
SHOW_MEN = "Puiši"
SHOW_WOMEN = "Meitas"
SHOW_GENDER = {SHOW_ALL: "", SHOW_MEN: GENDER_MALE, SHOW_WOMEN: GENDER_FEMALE}
SORT_FIRST = "Vārda"
SORT_LAST = "Uzvārda"

PERIOD_SEASON = "Šī sezona"
PERIOD_LAST_SEASON = "Iepriekšējā sezona"
PERIOD_MONTH = "Šis mēnesis"
PERIOD_YEAR = "Šis gads"
PERIOD_ALL = "Viss laiks"
PERIOD_CUSTOM = "Cits periods"
PERIODS = [PERIOD_SEASON, PERIOD_LAST_SEASON, PERIOD_MONTH, PERIOD_YEAR, PERIOD_ALL, PERIOD_CUSTOM]

SESSION_COLUMNS = [
    ("date", "Datums", 95),
    ("weekday", "Diena", 70),
    ("kind", "Veids", 130),
    ("groups", "Grupa", 80),
    ("title", "Nosaukums / tēma", 170),
    ("dances", "Dejas", 220),
    ("time", "Laiks", 60),
    ("app", "Atbildes lietotnē", 150),
    ("came", "Ieradās", 75),
    ("marked", "Atzīmēti", 75),
    ("pct", "Apmeklējums", 100),
]

STAT_COLUMNS = [
    ("first_name", "Vārds", 110),
    ("last_name", "Uzvārds", 130),
    ("status", "Statuss", 85),
    ("marked", "Notikumi", 90),
    ("present", "Ieradās", 70),
    ("late", "Nokavēja", 80),
    ("excused", "Attaisnoti", 85),
    ("absent", "Neattaisnoti", 95),
    ("pct", "Apmeklējums", 100),
    ("last_seen", "Pēdējoreiz", 95),
    ("streak", "Neieradās pēc kārtas", 145),
]


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attendance_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_date TEXT NOT NULL,
    kind TEXT DEFAULT '',
    title TEXT DEFAULT '',
    start_time TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    mark TEXT NOT NULL,
    note TEXT DEFAULT '',
    UNIQUE (session_id, dancer_id)
);
CREATE TABLE IF NOT EXISTS session_dances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    UNIQUE (session_id, dance_id)
);
CREATE INDEX IF NOT EXISTS idx_attendance_dancer ON attendance(dancer_id);
CREATE INDEX IF NOT EXISTS idx_sessions_date ON attendance_sessions(session_date);
CREATE TABLE IF NOT EXISTS event_details (
    session_id INTEGER PRIMARY KEY REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    status TEXT DEFAULT '', place TEXT DEFAULT '', address TEXT DEFAULT '', arrival_time TEXT DEFAULT '',
    end_time TEXT DEFAULT '', organizer TEXT DEFAULT '', contact TEXT DEFAULT '', transport TEXT DEFAULT '',
    fee TEXT DEFAULT '', costume_notes TEXT DEFAULT ''
);
"""


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        ensure_dancer_schema(self.con)
        self.con.executescript(SCHEMA)
        for old, new in OLD_KINDS.items():
            self.con.execute("UPDATE attendance_sessions SET kind=? WHERE kind=?", (new, old))
        ensure_event_detail_columns(self.con)   # event_details.for_groups (kurām grupām notikums)
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def set_mark(self, session_id, dancer_id, mark):
        if mark:
            self.x("INSERT INTO attendance (session_id, dancer_id, mark) VALUES (?,?,?) "
                   "ON CONFLICT(session_id, dancer_id) DO UPDATE SET mark=excluded.mark",
                   (session_id, dancer_id, mark))
        else:
            self.x("DELETE FROM attendance WHERE session_id=? AND dancer_id=?", (session_id, dancer_id))

    def has_dances(self):
        # the dances table belongs to Deju pūrs and exists only once that module has been used
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dances'"))

    def all_dances(self):
        """[(id, title, status)] from Deju pūrs, sorted by title."""
        if not self.has_dances():
            return []
        rows = self.q("SELECT id, title, status FROM dances")
        return sorted(((i, t or "", st or DANCE_IN_REPERTOIRE) for i, t, st in rows), key=lambda r: _norm(r[1]))

    def session_dances(self, session_ids=None):
        """{session id: [dance titles]} (for the given sessions or all)."""
        if not self.has_dances():
            return {}
        sql = ("SELECT sd.session_id, d.title FROM session_dances sd JOIN dances d ON d.id = sd.dance_id")
        params = []
        if session_ids is not None:
            ids = list(session_ids)
            if not ids:
                return {}
            sql += " WHERE sd.session_id IN (" + ",".join("?" * len(ids)) + ")"
            params = ids
        result = {}
        for sid, title in self.q(sql, params):
            result.setdefault(sid, []).append(title or "")
        for titles in result.values():
            titles.sort(key=_norm)
        return result

    def dance_cast(self, dance_ids):
        """Dancer ids in the casts of the given dances (Deju pūrs)."""
        ids = list(dance_ids)
        if not ids or not self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dance_cast'"):
            return set()
        return {r[0] for r in self.q("SELECT dancer_id FROM dance_cast WHERE dance_id IN ("
                                     + ",".join("?" * len(ids)) + ")", ids)}

    def dancer_groups(self):
        """{dancer id: group (A, Studija, VPDK)} from Kopas pūrs."""
        if "dancer_group" not in {c[1] for c in self.q("PRAGMA table_info(dancers)")}:
            return {}
        return {i: (g or "") for i, g in self.q("SELECT id, dancer_group FROM dancers")}

    def session_groups(self, session_ids=None):
        """{session id: 'A,Studija'} — which groups each event is for (empty — all groups)."""
        rows = self.q("SELECT session_id, for_groups FROM event_details")
        return {sid: (g or "") for sid, g in rows if session_ids is None or sid in session_ids}

    def save_groups(self, session_id, groups_text):
        self.con.execute("INSERT INTO event_details (session_id, for_groups) VALUES (?, ?) "
                         "ON CONFLICT(session_id) DO UPDATE SET for_groups=excluded.for_groups",
                         (session_id, groups_text))

    # ---- answers from Kabatas Pūrlāde become marks when the event starts ----------------
    AUTO_DAYS = 14   # look back this many days (older events are left as they are)

    def auto_app_marks(self, now=None):
        """Marks from Kabatas Pūrlāde (Cītības pūrs v0.2.8):
        • “Nebūs” → “Attaisnoti nebija” and “Kavēšu” → “Nokavēja” (reason and minutes in the note) — at once,
          as soon as the dancer answers, also for events still to come; if the dancer changes the answer,
          the mark follows it (or disappears);
        • when a rehearsal starts (date + start time) every dancer of its group who has not said “Nebūs”,
          “Kavēšu” or “Varbūt” gets “Ieradās” (no answer = coming); for other events only those who answered “Būs”.
        Marks put in this way are remembered in settings (citiba.auto.<event id> = 'dancer=mark,…'); a mark that
        a leader has put in, changed or removed is never touched. Returns how many marks were added or changed."""
        if not self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_participants'"):
            return 0
        now = now or datetime.now()
        today, hm = now.date().isoformat(), now.strftime("%H:%M")
        since = (now.date() - timedelta(days=self.AUTO_DAYS)).isoformat()
        sessions = self.q("SELECT id, session_date, kind, COALESCE(start_time, '') FROM attendance_sessions "
                          "WHERE session_date >= ?", (since,))
        if not sessions:
            return 0
        ids = [r[0] for r in sessions]
        marks_sql = ",".join("?" * len(ids))
        answers = {}
        for sid, did, answer, reason in self.q("SELECT session_id, dancer_id, answer, note FROM event_participants "
                                               "WHERE session_id IN (" + marks_sql + ")", ids):
            answers.setdefault(sid, {})[did] = (answer or "", (reason or "").strip())
        late = {}
        if self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='app_answers'"):
            late = {(sid, did): int(m or 0) for sid, did, m in self.q(
                "SELECT session_id, dancer_id, late_minutes FROM app_answers WHERE session_id IN (" + marks_sql + ")",
                ids)}
        marks = {}
        for sid, did, mark, note in self.q("SELECT session_id, dancer_id, mark, note FROM attendance "
                                           "WHERE session_id IN (" + marks_sql + ")", ids):
            marks.setdefault(sid, {})[did] = (mark, note or "")
        auto_all = {}
        for key, value in self.q("SELECT key, value FROM settings WHERE key LIKE 'citiba.auto.%'"):
            try:
                auto_all[int(key.rsplit(".", 1)[1])] = value or ""
            except ValueError:
                pass
        cancelled = set()
        if "status" in {c[1] for c in self.q("PRAGMA table_info(event_details)")}:
            cancelled = {r[0] for r in self.q("SELECT session_id FROM event_details WHERE status=? AND session_id IN ("
                                              + marks_sql + ")", ["Atcelts"] + ids)}
        # “Ieradās” on its own only for events from the day this was first used (older ones are left as they are)
        got = self.q("SELECT value FROM settings WHERE key='citiba.auto_present_since'")
        present_since = (got[0][0] if got else "") or today
        if not got:
            self.con.execute("INSERT INTO settings (key, value) VALUES ('citiba.auto_present_since', ?) "
                             "ON CONFLICT(key) DO NOTHING", (today,))
        groups_of = self.session_groups(set(ids))
        dgroups = self.dancer_groups()
        active = [r[0] for r in self.q("SELECT id FROM dancers WHERE " + active_dancer_sql("dancers"))]

        changed = 0
        for sid, day, kind, tm in sessions:
            started = day < today or (day == today and tm <= hm)
            ans = answers.get(sid, {})
            have = marks.get(sid, {})
            # what was put in automatically before: {dancer id: mark}; an old entry without '=' — hands off
            auto = {}
            for part in auto_all.get(sid, "").split(","):
                part = part.strip()
                if not part:
                    continue
                did, _, mark = part.partition("=")
                try:
                    auto[int(did)] = mark or None
                except ValueError:
                    pass
            expected = set()
            if started and sid not in cancelled and day >= present_since:
                if kind in REHEARSAL_KINDS:
                    expected = {did for did in active if in_event_groups(dgroups.get(did, ""), groups_of.get(sid, ""))}
                expected |= {did for did, (a, _r) in ans.items() if a == APP_YES}
            before = dict(auto)
            for did in set(ans) | expected | set(auto):
                answer, reason = ans.get(did, ("", ""))
                want = None
                if sid in cancelled:
                    want = None
                elif answer == APP_NO:
                    want = (MARK_EXCUSED, "Lietotnē: nebūs" + (f" — {reason}" if reason else ""))
                elif answer == APP_LATE:
                    minutes = late.get((sid, did), 0)
                    want = (MARK_LATE, (f"Lietotnē: kavēs {minutes} min" if minutes else "Lietotnē: kavēs")
                            + (f" — {reason}" if reason else ""))
                elif answer != APP_MAYBE and did in expected:
                    want = (MARK_PRESENT, "")
                cur = have.get(did)
                if did in auto:
                    if auto[did] is None or cur is None or cur[0] != auto[did]:
                        continue   # removed or changed by a leader (or an old entry) — leave it
                    if want is None:
                        self.con.execute("DELETE FROM attendance WHERE session_id=? AND dancer_id=?", (sid, did))
                        del auto[did]
                        changed += 1
                    elif want != cur:
                        self.con.execute("UPDATE attendance SET mark=?, note=? WHERE session_id=? AND dancer_id=?",
                                         (want[0], want[1], sid, did))
                        auto[did] = want[0]
                        changed += 1
                elif want is not None and cur is None:
                    self.con.execute("INSERT INTO attendance (session_id, dancer_id, mark, note) VALUES (?,?,?,?) "
                                     "ON CONFLICT(session_id, dancer_id) DO NOTHING", (sid, did, want[0], want[1]))
                    auto[did] = want[0]
                    changed += 1
            if auto != before:
                self.con.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                                 (f"citiba.auto.{sid}", ",".join(f"{d}={m}" if m else str(d)
                                                                 for d, m in sorted(auto.items()))))
        self.con.commit()
        return changed

    def dancers(self, include_ids=()):
        """Active dancers + the given ones (e.g. already marked in a session), sorted by name."""
        ids = list(include_ids)
        extra = (" OR id IN (" + ",".join("?" * len(ids)) + ")") if ids else ""
        rows = self.q("SELECT id, first_name, last_name, gender, status FROM dancers WHERE "
                      + active_dancer_sql("dancers") + extra, ids)
        rows.sort(key=lambda r: (_norm(r[2]), _norm(r[1])))
        return rows


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def groups_short(text):
    label = groups_label(text)
    return "visas" if label == "visas grupas" else label


def weekday(iso):
    try:
        return WEEKDAYS[date.fromisoformat(iso).weekday()]
    except (TypeError, ValueError):
        return ""


def parse_time(text):
    """'18', '18:30', '18.30', '1830' -> '18:30'; '' when empty; None when bad."""
    text = (text or "").strip()
    if not text:
        return ""
    m = re.fullmatch(r"(\d{1,2})(?:[:.\s]?(\d{2}))?", text)
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2) or 0)
    return f"{h:02d}:{mi:02d}" if h < 24 and mi < 60 else None


def pct(came, marked):
    return round(100 * came / marked) if marked else None


def pct_text(value):
    return "—" if value is None else f"{value} %"


def pct_tag(value):
    if value is None:
        return "none"
    if value >= GOOD_PCT:
        return "good"
    return "low" if value < LOW_PCT else "mid"


def season_of(day):
    """Dance season runs from 1 September to 31 August."""
    start_year = day.year if day.month >= 9 else day.year - 1
    return date(start_year, 9, 1), date(start_year + 1, 8, 31)


def period_dates(name, today=None):
    today = today or date.today()
    if name == PERIOD_SEASON:
        return season_of(today)
    if name == PERIOD_LAST_SEASON:
        s, _e = season_of(today)
        return date(s.year - 1, 9, 1), date(s.year, 8, 31)
    if name == PERIOD_MONTH:
        return today.replace(day=1), today.replace(day=calendar.monthrange(today.year, today.month)[1])
    if name == PERIOD_YEAR:
        return date(today.year, 1, 1), date(today.year, 12, 31)
    return None, None  # Viss laiks


def sort_rows(rows, key, desc):
    """Stable sort by one column; empty values (None, '') always stay at the bottom."""
    filled = [r for r in rows if r[key] not in (None, "")]
    empty = [r for r in rows if r[key] in (None, "")]
    filled.sort(key=lambda r: r[key] if isinstance(r[key], int) else _norm(r[key]), reverse=desc)
    return filled + empty


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def tag_colours(tree):
    tree.tag_configure("good", foreground=GREEN)
    tree.tag_configure("mid", foreground=AMBER)
    tree.tag_configure("low", foreground=RED)
    tree.tag_configure("none", foreground=GREY)
    tree.tag_configure("planned", foreground="#7A5C99")
    tree.tag_configure("today", background="#FCEFC7", font=("Segoe UI", 10, "bold"))


# --------------------------------------------------------------------------
# Parts of the new look (Pūrlāde v0.8.9)
# --------------------------------------------------------------------------
LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = (izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED,
                                                izskats.SELECTED)
OK_BG, OK_FG, WARN_BG, WARN_FG, BAD_BG, BAD_FG = (izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG,
                                                  izskats.BAD_BG, izskats.BAD_FG)
ZEBRA = izskats.ZEBRA
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL
DARK_GOLD = "#A8841A"
SOFT_BG = "#FAF6EC"           # “Atkārtojas” box, the head of the Šodien view
# mark buttons: (background, text and border colour) when chosen
MARK_LOOK = {MARK_PRESENT: (OK_BG, OK_FG), MARK_LATE: ("#FBEDE3", "#8A4A1F"), MARK_EXCUSED: (WARN_BG, WARN_FG),
             MARK_ABSENT: (BAD_BG, RED)}
MARK_OFF = ("#FFFFFF", "#4A4535", "#D8CFB8")   # not chosen: background, text, border


zebra = izskats.zebra   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


boxed = izskats.boxed   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


white_bar = izskats.white_bar   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


recolour = izskats.recolour   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


TabHost = izskats.TabHost   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


def app_answers(db, session_id):
    """{dancer id: (answer, reason/comment, late minutes)} — answers from the mobile app / Notikumu pūrs."""
    if session_id is None:
        return {}
    try:
        rows = db.q("SELECT dancer_id, answer, note FROM event_participants WHERE session_id=?", (session_id,))
    except sqlite3.Error:
        return {}
    late = {}
    try:
        late = dict(db.q("SELECT dancer_id, late_minutes FROM app_answers WHERE session_id=?", (session_id,)))
    except sqlite3.Error:
        pass   # the mobile app has not been used yet
    return {did: (ans or "", note or "", int(late.get(did) or 0)) for did, ans, note in rows if ans}


def session_started(db, session_id):
    """True when this (saved) event has already begun (its day has passed, or it is today and the start time
    has come)."""
    if session_id is None:
        return False
    row = db.q("SELECT session_date, COALESCE(start_time, '') FROM attendance_sessions WHERE id=?", (session_id,))
    if not row:
        return False
    now = datetime.now()
    day, start = row[0][0] or "", (row[0][1] or "").strip()
    today = now.date().isoformat()
    return day < today or (day == today and start <= now.strftime("%H:%M"))


def prefill_mark(answer, started, mark, note):
    """The mark and note shown for a dancer without a saved mark: from his answer in the app."""
    if mark or not answer:
        return mark, note
    ans, reason, late = answer
    if ans == APP_YES and started:
        return MARK_PRESENT, note
    if ans == APP_NO:
        return MARK_EXCUSED, note or ("Lietotnē: nebūs" + (f" — {reason}" if reason else ""))
    if ans == APP_LATE:
        return MARK_LATE, note or ((f"Lietotnē: kavēs {late} min" if late else "Lietotnē: kavēs")
                                   + (f" — {reason}" if reason else ""))
    return mark, note


def answer_look(answer):
    """(text, colour) of a dancer's answer in the app."""
    if not answer:
        return "nav atbildējis", MUTED
    ans, _reason, late = answer
    text = {APP_LATE: f"Kavēs {late} min" if late else "Kavēs"}.get(ans, ans)
    return text, {APP_YES: OK_FG, APP_NO: RED, APP_MAYBE: WARN_FG, APP_LATE: "#8A4A1F"}.get(ans, NAVY)


def pct_colour(value):
    if value is None:
        return MUTED
    return OK_FG if value >= 80 else (COPPER if value >= LOW_PCT else RED)


# --------------------------------------------------------------------------
# Tab “Šodien”: marking today's event right in the module
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Žurnāls — krāsains režģis (Pūrlāde v0.9.20): katra atzīme savā krāsā
# --------------------------------------------------------------------------
WEEKDAY_SHORT = ["P", "O", "T", "C", "Pk", "S", "Sv"]
PCT_FG = {"good": GREEN, "mid": AMBER, "low": RED, "none": GREY}


class JournalGrid(tk.Frame):
    """A month of marks: dancers (rows) × events (columns). Each mark is a coloured cell, as the mark buttons
    in Šodien / the event window. The dancer column, the dates and the totals stay in place while scrolling.

    set_data(columns, rows) — columns: [(session_id, date_iso, kind)];
    rows: [(dancer_id, name, [mark per column], [note per column], month_pct)].
    on_cell(dancer_id, column_index), on_name(dancer_id), on_head(column_index) — double click."""

    NAME_W, CELL_W, PCT_W = 210, 58, 80
    HEAD_H, ROW_H, FOOT_H = 42, 26, 28

    def __init__(self, parent, on_cell=None, on_name=None, on_head=None):
        super().__init__(parent, bg=WHITE)
        self.on_cell, self.on_name, self.on_head = on_cell, on_name, on_head
        self.columns, self.rows, self.selected, self._tip = [], [], None, None
        self.font = tkfont.Font(font=FONT)
        self.bold = tkfont.Font(font=FONT_BOLD)
        self.small = tkfont.Font(font=FONT_SMALL)

        def canvas(width=None, height=None):
            c = tk.Canvas(self, bg=WHITE, highlightthickness=0, bd=0)
            if width:
                c.configure(width=width)
            if height:
                c.configure(height=height)
            return c
        self.corner = canvas(self.NAME_W, self.HEAD_H)
        self.head = canvas(height=self.HEAD_H)
        self.pct_head = canvas(self.PCT_W, self.HEAD_H)
        self.names = canvas(self.NAME_W)
        self.body = canvas()
        self.pcts = canvas(self.PCT_W)
        self.foot_name = canvas(self.NAME_W, self.FOOT_H)
        self.foot = canvas(height=self.FOOT_H)
        self.foot_pct = canvas(self.PCT_W, self.FOOT_H)
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.yview)
        self.hbar = ttk.Scrollbar(self, orient="horizontal", command=self.xview)
        for c in (self.names, self.body, self.pcts):
            c.configure(yscrollcommand=self.vbar.set)
        for c in (self.head, self.body, self.foot):
            c.configure(xscrollcommand=self.hbar.set)

        self.corner.grid(row=0, column=0, sticky="nsew")
        self.head.grid(row=0, column=1, sticky="nsew")
        self.pct_head.grid(row=0, column=2, sticky="nsew")
        self.names.grid(row=1, column=0, sticky="nsew")
        self.body.grid(row=1, column=1, sticky="nsew")
        self.pcts.grid(row=1, column=2, sticky="nsew")
        self.vbar.grid(row=1, column=3, sticky="ns")
        self.foot_name.grid(row=2, column=0, sticky="nsew")
        self.foot.grid(row=2, column=1, sticky="nsew")
        self.foot_pct.grid(row=2, column=2, sticky="nsew")
        self.hbar.grid(row=3, column=1, sticky="ew")
        self.rowconfigure(1, weight=1)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(4, weight=0)     # filler: a short month keeps “Mēnesī” next to the last date
        self.bind("<Configure>", lambda e: self._fit_width())

        for c in (self.names, self.body, self.pcts, self.head, self.foot, self.corner, self.pct_head):
            c.bind("<MouseWheel>", self._wheel)
            c.bind("<Shift-MouseWheel>", self._wheel_x)
            c.bind("<Button-4>", lambda e: self._scroll_y(-1))
            c.bind("<Button-5>", lambda e: self._scroll_y(1))
            c.bind("<Shift-Button-4>", lambda e: self._scroll_x(-1))
            c.bind("<Shift-Button-5>", lambda e: self._scroll_x(1))
        for c in (self.names, self.body, self.pcts):
            c.bind("<Button-1>", self._click)
        self.body.bind("<Double-1>", self._double_body)
        self.names.bind("<Double-1>", self._double_name)
        self.head.bind("<Double-1>", self._double_head)
        self.body.bind("<Motion>", self._motion_body)
        self.head.bind("<Motion>", self._motion_head)
        self.names.bind("<Motion>", lambda e: self._hide_tip())
        for c in (self.body, self.head):
            c.bind("<Leave>", lambda e: (self._hide_tip(), self.body.delete("hover")))
        self.body.configure(cursor="hand2")

    # ---- scrolling -------------------------------------------------------
    def yview(self, *args):
        for c in (self.names, self.body, self.pcts):
            c.yview(*args)

    def xview(self, *args):
        for c in (self.head, self.body, self.foot):
            c.xview(*args)

    def _scroll_y(self, units):
        self.yview("scroll", units, "units")
        self._hide_tip()
        return "break"

    def _scroll_x(self, units):
        self.xview("scroll", units, "units")
        self._hide_tip()
        return "break"

    def _wheel(self, event):
        return self._scroll_y(-1 if event.delta > 0 else 1) if event.delta else "break"

    def _wheel_x(self, event):
        return self._scroll_x(-1 if event.delta > 0 else 1) if event.delta else "break"

    # ---- data ------------------------------------------------------------
    def set_data(self, columns, rows):
        y_pos = self.body.yview()[0] if self.rows else 0.0
        self.columns, self.rows = list(columns), list(rows)
        if self.selected not in {r[0] for r in self.rows}:
            self.selected = None
        self.draw()
        self.yview("moveto", y_pos)

    def row_index(self, dancer_id):
        for i, r in enumerate(self.rows):
            if r[0] == dancer_id:
                return i
        return None

    def select(self, dancer_id):
        self.selected = dancer_id if self.row_index(dancer_id) is not None else None
        self._draw_selection()

    def _fit(self, text, font, width):
        if font.measure(text) <= width:
            return text
        while text and font.measure(text + "…") > width:
            text = text[:-1]
        return text + "…"

    def draw(self):
        W, H, R = self.CELL_W, self.HEAD_H, self.ROW_H
        n_cols, n_rows = len(self.columns), len(self.rows)
        width, height = max(n_cols * W, 1), max(n_rows * R, R)
        for c in (self.corner, self.head, self.pct_head, self.names, self.body, self.pcts, self.foot_name,
                  self.foot, self.foot_pct):
            c.delete("all")
        today = date.today().isoformat()

        # headers
        self.corner.create_rectangle(0, 0, self.NAME_W, H, fill=CREAM_DARK, outline="")
        self.corner.create_text(12, H / 2, text="Dejotājs", anchor="w", font=self.bold, fill=NAVY)
        self.pct_head.create_rectangle(0, 0, self.PCT_W, H, fill=CREAM_DARK, outline="")
        self.pct_head.create_text(self.PCT_W / 2, H / 2, text="Mēnesī", font=self.bold, fill=NAVY)
        for j, (sid, day, kind) in enumerate(self.columns):
            x = j * W
            is_today = day == today
            self.head.create_rectangle(x, 0, x + W, H, fill=GOLD if is_today else CREAM_DARK, outline=WHITE,
                                       tags=(f"h{j}",))
            self.head.create_text(x + W / 2, 14, text=f"{day[8:10]}.{day[5:7]}", font=self.bold,
                                  fill=WHITE if is_today else NAVY)
            try:
                wd = WEEKDAY_SHORT[date.fromisoformat(day).weekday()]
            except ValueError:
                wd = ""
            self.head.create_text(x + W / 2, 30, text=wd + KIND_SHORT.get(kind, "").replace(" ", " · "),
                                  font=self.small, fill=WHITE if is_today else MUTED)
        self.head.configure(scrollregion=(0, 0, width, H))

        # rows
        totals = [[0, 0] for _ in self.columns]       # per column: came, marked
        all_came = all_marked = 0
        for i, (did, name, marks, _notes, p) in enumerate(self.rows):
            y = i * R
            bg = ZEBRA if i % 2 else WHITE
            self.names.create_rectangle(0, y, self.NAME_W, y + R, fill=bg, outline="", tags=("rowbg", f"rb{i}"))
            self.names.create_text(12, y + R / 2, text=self._fit(name, self.font, self.NAME_W - 20), anchor="w",
                                   font=self.font, fill=NAVY)
            self.pcts.create_rectangle(0, y, self.PCT_W, y + R, fill=bg, outline="", tags=("rowbg", f"rb{i}"))
            self.pcts.create_text(self.PCT_W / 2, y + R / 2, text=pct_text(p), font=self.bold,
                                  fill=PCT_FG.get(pct_tag(p), GREY))
            for j, mark in enumerate(marks):
                x = j * W
                if mark in MARK_LOOK:
                    fill, fg = MARK_LOOK[mark]
                    totals[j][1] += 1
                    all_marked += 1
                    if mark in CAME:
                        totals[j][0] += 1
                        all_came += 1
                else:
                    fill, fg = bg, MUTED
                self.body.create_rectangle(x + 2, y + 2, x + W - 2, y + R - 2, fill=fill,
                                           outline=fg if mark in MARK_LOOK else LINE_SOFT)
                if mark:
                    self.body.create_text(x + W / 2, y + R / 2, text=MARK_SYMBOL.get(mark, mark), font=self.bold,
                                          fill=fg)
                if _notes[j]:
                    self.body.create_polygon(x + W - 9, y + 2, x + W - 2, y + 2, x + W - 2, y + 9, fill=fg,
                                             outline="")
        if not self.rows:
            self.body.create_text(14, R / 2, text="Nav aktīvu dejotāju", anchor="w", font=self.font, fill=MUTED)
        self.names.configure(scrollregion=(0, 0, self.NAME_W, height))
        self.pcts.configure(scrollregion=(0, 0, self.PCT_W, height))
        self.body.configure(scrollregion=(0, 0, width, height))

        # totals
        F = self.FOOT_H
        self.foot_name.create_rectangle(0, 0, self.NAME_W, F, fill=CREAM_DARK, outline="")
        self.foot_name.create_text(12, F / 2, text="Ieradās", anchor="w", font=self.bold, fill=NAVY)
        for j, (came, marked) in enumerate(totals):
            x = j * W
            p = pct(came, marked)
            self.foot.create_rectangle(x, 0, x + W, F, fill=CREAM_DARK, outline=WHITE)
            self.foot.create_text(x + W / 2, F / 2, text=f"{came}/{marked}" if marked else "—", font=self.small,
                                  fill=PCT_FG.get(pct_tag(p), GREY))
        self.foot.configure(scrollregion=(0, 0, width, F))
        p = pct(all_came, all_marked)
        self.foot_pct.create_rectangle(0, 0, self.PCT_W, F, fill=CREAM_DARK, outline="")
        self.foot_pct.create_text(self.PCT_W / 2, F / 2, text=pct_text(p), font=self.bold,
                                  fill=PCT_FG.get(pct_tag(p), GREY))
        self._draw_selection()
        self._fit_width()

    def _fit_width(self):
        content = max(len(self.columns) * self.CELL_W, self.CELL_W)
        free = self.winfo_width() - self.NAME_W - self.PCT_W - self.vbar.winfo_reqwidth()
        fits = free > 1 and content <= free
        for c in (self.head, self.body, self.foot):
            c.configure(width=content if fits else 10)
        self.columnconfigure(1, weight=0 if fits else 1)
        self.columnconfigure(4, weight=1 if fits else 0)
        if fits:
            self.hbar.grid_remove()
            self.xview("moveto", 0)
        else:
            self.hbar.grid()

    def _draw_selection(self):
        for c in (self.names, self.pcts):
            for item in c.find_withtag("rowbg"):
                tags = c.gettags(item)
                i = next((int(t[2:]) for t in tags if t.startswith("rb")), 0)
                c.itemconfigure(item, fill=ZEBRA if i % 2 else WHITE)
        self.body.delete("sel")
        i = self.row_index(self.selected) if self.selected is not None else None
        if i is None:
            return
        for c in (self.names, self.pcts):
            for item in c.find_withtag(f"rb{i}"):
                c.itemconfigure(item, fill=SELECTED)
        y = i * self.ROW_H
        self.body.create_rectangle(0, y, max(len(self.columns) * self.CELL_W, 1), y + self.ROW_H, outline=NAVY,
                                   width=2, tags=("sel",))

    # ---- mouse -----------------------------------------------------------
    def _cell_at(self, event, canvas):
        x, y = canvas.canvasx(event.x), canvas.canvasy(event.y)
        i, j = int(y // self.ROW_H), int(x // self.CELL_W)
        row = i if 0 <= i < len(self.rows) else None
        col = j if 0 <= j < len(self.columns) else None
        return row, col

    def _click(self, event):
        row, _col = self._cell_at(event, event.widget)
        if row is not None:
            self.select(self.rows[row][0])

    def _double_body(self, event):
        row, col = self._cell_at(event, self.body)
        if row is not None and col is not None and self.on_cell:
            self._hide_tip()
            self.on_cell(self.rows[row][0], col)

    def _double_name(self, event):
        row, _col = self._cell_at(event, self.names)
        if row is not None and self.on_name:
            self.on_name(self.rows[row][0])

    def _double_head(self, event):
        col = int(self.head.canvasx(event.x) // self.CELL_W)
        if 0 <= col < len(self.columns) and self.on_head:
            self.on_head(col)

    def _motion_body(self, event):
        row, col = self._cell_at(event, self.body)
        self.body.delete("hover")
        if row is None or col is None:
            return self._hide_tip()
        x, y = col * self.CELL_W, row * self.ROW_H
        self.body.create_rectangle(x + 1, y + 1, x + self.CELL_W - 1, y + self.ROW_H - 1, outline=GOLD, width=2,
                                   tags=("hover",))
        _did, name, marks, notes, _p = self.rows[row]
        _sid, day, kind = self.columns[col]
        text = f"{name}\n{show_date(day)} · {kind}\n{marks[col] or 'nav atzīmes'}"
        if notes[col]:
            text += f" — {notes[col]}"
        self._show_tip(event, text)

    def _motion_head(self, event):
        col = int(self.head.canvasx(event.x) // self.CELL_W)
        if not 0 <= col < len(self.columns):
            return self._hide_tip()
        _sid, day, kind = self.columns[col]
        self._show_tip(event, f"{show_date(day)} · {kind}\nDubultklikšķis — atvērt notikumu")

    def _show_tip(self, event, text):
        if self._tip is None:
            self._tip = tk.Toplevel(self)
            self._tip.wm_overrideredirect(True)
            self._tip.keep_open = True
            self._tip_lbl = tk.Label(self._tip, bg=NAVY, fg=WHITE, font=FONT_SMALL, justify="left", padx=8, pady=5)
            self._tip_lbl.pack()
        self._tip_lbl.configure(text=text)
        self._tip.wm_geometry(f"+{event.x_root + 14}+{event.y_root + 16}")
        self._tip.deiconify()
        self._tip.lift()

    def _hide_tip(self):
        if self._tip is not None:
            try:
                self._tip.withdraw()
            except tk.TclError:
                self._tip = None


class TodayView(tk.Frame):
    SIDE = 300

    def __init__(self, master, app):
        super().__init__(master, bg=CREAM)
        self.app, self.db = app, app.db
        self.session_id, self.changed, self.readonly, self.stale = None, False, False, True
        self.marks, self.notes, self.rows, self.names, self.genders = {}, {}, {}, {}, {}
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.main = boxed(self)
        self.main.grid(row=0, column=0, sticky="nsew")
        side = tk.Frame(self, bg=CREAM, width=self.SIDE)
        side.grid(row=0, column=1, sticky="ns", padx=(12, 0))
        side.pack_propagate(False)
        outer, _head, self.recent = izskats.panel(side, "Pēdējie mēģinājumi")
        outer.pack(fill="x")
        outer, _head, self.low = izskats.panel(side, f"Zema cītība (< {LOW_PCT} %)")
        outer.pack(fill="both", expand=True, pady=(12, 0))
        self.search = tk.StringVar()
        self.who = tk.StringVar(value=SHOW_ALL)
        self.search.trace_add("write", lambda *a: self.apply_filter())

    # ---- the module asks before leaving (moduli/aizversana.py) ----
    def dirty(self):
        return bool(self.changed) and not self.readonly and self.session_id is not None

    def set_changed(self):
        if not self.readonly:
            self.changed = True

    def refresh(self, force=False):
        """Called by App.refresh: the side panels always; the marking list only when nothing is being changed."""
        self.fill_side()
        if self.dirty() and not force:
            return
        if self.app.nb.select() != 0 and not force:
            self.stale = True   # rebuilt when the tab is opened
            return
        self.load()

    def today_sessions(self):
        return self.db.q("SELECT id, kind, title, start_time FROM attendance_sessions WHERE session_date=? "
                         "ORDER BY COALESCE(start_time, ''), id", (date.today().isoformat(),))

    def choose(self, session_id):
        if session_id == self.session_id:
            return
        if self.dirty() and not messagebox.askyesno(
                "Nesaglabātas atzīmes", "Pāriet uz citu notikumu, nesaglabājot atzīmes?", parent=self.app.root):
            self.pick.set(self.session_id)
            return
        self.session_id = session_id
        self.changed = False
        self.load()

    # ---- the marking list --------------------------------------------------------
    def load(self):
        self.stale = False
        for w in self.main.winfo_children():
            w.destroy()
        self.rows, self.marks, self.notes = {}, {}, {}
        sessions = self.today_sessions()
        ids = [s[0] for s in sessions]
        if self.session_id not in ids:
            self.session_id = ids[0] if ids else None
            self.changed = False
        if not sessions:
            self.show_empty()
            return
        sid = self.session_id
        d, kind, title, tm, notes = self.db.q("SELECT session_date, kind, title, start_time, notes FROM "
                                              "attendance_sessions WHERE id=?", (sid,))[0]
        groups_text = self.db.session_groups({sid}).get(sid, "")
        acc = piekluve.current()
        self.readonly = not acc.can_edit("citibas_purs", groups=event_groups(groups_text) or DANCER_GROUPS)

        # head: which event, when, dances; counter and quick buttons
        head = tk.Frame(self.main, bg=WHITE)
        head.pack(fill="x", padx=16, pady=(12, 8))
        if len(sessions) > 1:
            self.pick = tk.IntVar(value=sid)
            seg = izskats.Segmented(head, [(s[0], "  ".join(p for p in (s[3], s[1]) if p)) for s in sessions],
                                    self.pick, command=lambda: self.choose(self.pick.get()))
            seg.pack(anchor="w", pady=(0, 10))
        right = tk.Frame(head, bg=WHITE)
        right.pack(side="right", anchor="n")
        left = tk.Frame(head, bg=WHITE)
        left.pack(side="left", fill="x", expand=True)
        groups = groups_label(groups_text) if groups_text else "visas grupas"
        tk.Label(left, text=f"{kind or KIND_REHEARSAL} · {groups}" + (f" — {title}" if title else ""), bg=WHITE,
                 fg=NAVY, font=("Georgia", 15, "bold"), anchor="w", justify="left").pack(fill="x")
        dances = self.db.session_dances([sid]).get(sid, [])
        sub = f"{WEEKDAYS_FULL[date.fromisoformat(d).weekday()]}, {show_date(d)}" + (f" · {tm}" if tm else "")
        sub += f" · dejas: {', '.join(dances)}" if dances else " · dejas vēl nav izvēlētas"
        wrapped = [tk.Label(left, text=sub, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w", justify="left")]
        wrapped[0].pack(fill="x", pady=(2, 0))
        if notes:
            wrapped.append(tk.Label(left, text=notes, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w",
                                    justify="left"))
            wrapped[-1].pack(fill="x")
        left.bind("<Configure>", lambda e: [w.configure(wraplength=max(200, e.width - 10)) for w in wrapped])
        self.counter = tk.Label(right, text="", bg=WHITE, fg=NAVY, font=FONT_BOLD)
        self.counter.pack(side="left", padx=(0, 12))
        if not self.readonly:
            ttk.Button(right, text="✓ Pārējie ieradās", command=self.rest_present).pack(side="left")
        ttk.Button(right, text="Atvērt notikumu…", command=self.open_window).pack(side="left", padx=(6, 0))

        # search, boys / girls
        tools = tk.Frame(self.main, bg=WHITE)
        tools.pack(fill="x", padx=16, pady=(0, 8))
        izskats.search_box(tools, self.search, width=20).pack(side="left")
        izskats.Segmented(tools, [(v, v) for v in (SHOW_ALL, SHOW_MEN, SHOW_WOMEN)], self.who,
                          command=self.apply_filter).pack(side="left", padx=(12, 0))
        izskats.note(tools, "blakus vārdam — atbilde lietotnē", bg=WHITE).pack(side="right")
        tk.Frame(self.main, bg=LINE_SOFT, height=1).pack(fill="x")

        # buttons at the bottom (packed before the list so that they are always seen)
        foot = tk.Frame(self.main, bg=WHITE)
        foot.pack(side="bottom", fill="x", padx=16, pady=10)
        tk.Frame(self.main, bg=LINE_SOFT, height=1).pack(side="bottom", fill="x")
        if self.readonly:
            tk.Label(foot, text="🔒 Tikai skatīšanai — " + ("jūsu lomai Cītības pūrā nav labošanas tiesību."
                                                          if acc.view_only("citibas_purs") else
                                                          f"atzīmes var likt tikai {acc.scope_text('citibas_purs')}s "
                                                          "notikumos."),
                     bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold")).pack(side="left")
        else:
            ttk.Button(foot, text="Saglabāt atzīmes", style="Accent.TButton", command=self.save).pack(side="right")
            ttk.Button(foot, text="Atcelt", command=self.discard).pack(side="right", padx=6)
            self.saved_lbl = tk.Label(foot, text="", bg=WHITE, fg=OK_FG, font=("Segoe UI", 9, "bold"))
            self.saved_lbl.pack(side="left")

        # the list of dancers
        holder = tk.Frame(self.main, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(holder, bg=WHITE, highlightthickness=0)
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.rows_frame = tk.Frame(self.canvas, bg=WHITE)
        win_id = self.canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        self.rows_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(win_id, width=e.width))
        self.canvas.bind("<MouseWheel>", self.wheel)
        self.rows_frame.bind("<MouseWheel>", self.wheel)

        existing = {did: (mark, note) for did, mark, note in
                    self.db.q("SELECT dancer_id, mark, note FROM attendance WHERE session_id=?", (sid,))}
        answers = app_answers(self.db, sid)
        started = session_started(self.db, sid)
        dgroups = self.db.dancer_groups()
        self.event_groups_text = groups_text
        self.names, self.genders, self.in_group = {}, {}, {}
        dancers = self.db.dancers(existing.keys())
        dancers.sort(key=lambda r: (_norm(r[1]), _norm(r[2])))
        for did, first, last, gender, status in dancers:
            in_group = in_event_groups(dgroups.get(did, ""), groups_text)
            if not (in_group or did in existing):
                continue
            mark, note = existing.get(did, ("", ""))
            mark, note = prefill_mark(answers.get(did), started, mark, note or "")
            self.names[did] = (first or "", last or "")
            self.genders[did] = gender or ""
            self.add_row(did, full_name(first, last), status, mark, note, answers.get(did))
        if not self.rows:
            tk.Label(self.rows_frame, text="Šī notikuma grupām nav neviena aktīva dejotāja.", bg=WHITE, fg=MUTED,
                     font=FONT, pady=30).pack(fill="x")
        self.changed = False
        self.apply_filter()

    def wheel(self, e):
        self.canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")

    def add_row(self, did, name, status, mark, note, answer):
        row = tk.Frame(self.rows_frame, bg=WHITE)
        self.rows[did] = row
        inactive = (status or STATUS_ACTIVE) != STATUS_ACTIVE
        name_lbl = tk.Label(row, text=name + (f"  ({status.lower()})" if inactive else ""), bg=WHITE,
                            fg=GREY if inactive else NAVY, font=FONT_BOLD, width=24, anchor="w")
        name_lbl.pack(side="left", padx=(16, 6), pady=5)
        text, colour = answer_look(answer)
        ans = tk.Label(row, text=text, bg=WHITE, fg=colour, font=("Segoe UI", 9, "bold" if answer else "normal"),
                       width=14, anchor="w")
        ans.pack(side="left", padx=(0, 8))
        var = tk.StringVar(value=mark)
        buttons = {}
        for m in MARKS:
            b = tk.Label(row, text=m, font=FONT_SMALL, padx=6, pady=3, width=11,
                         highlightthickness=1, cursor="" if self.readonly else "hand2")
            b.pack(side="left", padx=2)
            if not self.readonly:
                b.bind("<Button-1>", lambda e, v=var, m=m: v.set("" if v.get() == m else m))
            buttons[m] = b
        note_var = tk.StringVar(value=note or "")
        entry = tk.Entry(row, textvariable=note_var, relief="flat", bd=0, bg=WHITE, fg=MUTED, font=FONT_SMALL,
                         highlightthickness=1, highlightbackground=LINE, highlightcolor=NAVY,
                         state="readonly" if self.readonly else "normal", readonlybackground=WHITE)
        entry.pack(side="left", fill="x", expand=True, padx=(10, 16), ipady=3)
        row.parts = (name_lbl, ans)
        row.buttons = buttons

        def paint(*_a):
            for m, b in buttons.items():
                on = var.get() == m
                bg, fg = MARK_LOOK[m] if on else MARK_OFF[:2]
                b.configure(bg=bg, fg=fg, font=("Segoe UI", 9, "bold") if on else FONT_SMALL,
                            highlightbackground=MARK_LOOK[m][1] if on else MARK_OFF[2])
        paint()
        var.trace_add("write", lambda *a: (paint(), self.set_changed(), self.update_counter()))
        note_var.trace_add("write", lambda *a: self.set_changed())
        for w in (row, name_lbl, ans) + tuple(buttons.values()):
            w.bind("<MouseWheel>", self.wheel, add="+")
        self.marks[did], self.notes[did] = var, note_var

    def apply_filter(self):
        if not self.rows:
            return
        gender = SHOW_GENDER.get(self.who.get(), "")
        term = _norm(self.search.get())
        for row in self.rows.values():
            row.pack_forget()
        self.visible = []
        for did, row in self.rows.items():
            if gender and self.genders.get(did) != gender:
                continue
            if term and term not in _norm(full_name(*self.names.get(did, ("", "")))):
                continue
            bg = ZEBRA if len(self.visible) % 2 else WHITE
            for w in (row,) + row.parts:
                w.configure(bg=bg)
            row.pack(fill="x")
            self.visible.append(did)
        self.canvas.yview_moveto(0)
        self.update_counter()

    def update_counter(self):
        values = [v.get() for v in self.marks.values()]
        marked = sum(1 for v in values if v)
        came = sum(1 for v in values if v in CAME)
        self.counter.configure(text=f"{marked} no {len(values)} atzīmēti" + (f" · ieradās {came}" if marked else ""))

    def rest_present(self):
        for did in self.visible:
            if not self.marks[did].get():
                self.marks[did].set(MARK_PRESENT)

    def discard(self):
        if self.changed and not messagebox.askyesno("Atcelt", "Atcelt nesaglabātās atzīmes?", parent=self.app.root):
            return
        self.changed = False
        self.load()

    def save(self):
        """Save the marks of the shown event. True when saved (also used by Pūrlāde before leaving the module)."""
        if self.readonly or self.session_id is None:
            return False
        acc = piekluve.current()
        if not acc.can_edit("citibas_purs", groups=event_groups(self.event_groups_text) or DANCER_GROUPS):
            piekluve.deny(self.app.root, f"Atzīmes var likt tikai {acc.scope_text('citibas_purs')}s notikumos.")
            return False
        con, sid = self.db.con, self.session_id
        try:
            con.execute("DELETE FROM attendance WHERE session_id=?", (sid,))
            con.executemany("INSERT INTO attendance (session_id, dancer_id, mark, note) VALUES (?,?,?,?)",
                            [(sid, did, var.get(), self.notes[did].get().strip())
                             for did, var in self.marks.items() if var.get()])
            con.commit()
        except sqlite3.Error:
            con.rollback()
            log_error(traceback.format_exc())
            messagebox.showerror("Saglabāšana", "Neizdevās saglabāt atzīmes.", parent=self.app.root)
            return False
        self.changed = False
        self.app.refresh(select_session=sid)
        try:
            self.saved_lbl.configure(text=f"✓ Saglabāts {datetime.now().strftime('%H:%M')}")
        except (tk.TclError, AttributeError):
            pass
        return True

    def open_window(self):
        if self.dirty():
            if not messagebox.askyesno("Nesaglabātas atzīmes", "Vispirms saglabāt atzīmes?", parent=self.app.root):
                return
            if not self.save():
                return
        SessionWindow(self.app, self.session_id)

    def show_empty(self):
        box = tk.Frame(self.main, bg=WHITE)
        box.pack(fill="x", padx=28, pady=40)
        today = date.today()
        tk.Label(box, text=f"{WEEKDAYS_FULL[today.weekday()]}, {show_date(today.isoformat())}", bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")
        tk.Label(box, text="Šodien nav neviena notikuma", bg=WHITE, fg=NAVY, font=("Georgia", 16, "bold"),
                 anchor="w").pack(fill="x", pady=(4, 0))
        izskats.note(box, "Kad šodien notiek mēģinājums, šeit varēs uzreiz atzīmēt, kurš ieradās. Lietotnes "
                          "atbildes (Būs / Nebūs / Kavēs) jau būs ieliktas.", bg=WHITE, wrap=520).pack(
            fill="x", pady=(6, 14))
        btns = tk.Frame(box, bg=WHITE)
        btns.pack(fill="x")
        if piekluve.current().can_edit("citibas_purs"):
            ttk.Button(btns, text="＋ Jauns notikums šodien", style="Accent.TButton",
                       command=lambda: SessionWindow(self.app)).pack(side="left")
        nxt = self.db.q("SELECT id, session_date, kind, start_time FROM attendance_sessions WHERE session_date>? "
                        "ORDER BY session_date, COALESCE(start_time, ''), id LIMIT 1", (today.isoformat(),))
        last = self.db.q("SELECT id, session_date, kind FROM attendance_sessions WHERE session_date<? "
                         "ORDER BY session_date DESC, COALESCE(start_time, '') DESC, id DESC LIMIT 1",
                         (today.isoformat(),))
        if last:
            ttk.Button(btns, text=f"Pēdējais: {show_date(last[0][1])} {last[0][2].lower()}",
                       command=lambda: SessionWindow(self.app, last[0][0])).pack(side="left", padx=(8, 0))
        if nxt:
            sid, d, kind, tm = nxt[0]
            izskats.note(box, f"Nākamais notikums: {WEEKDAYS_FULL[date.fromisoformat(d).weekday()].lower()}, "
                              f"{show_date(d)}" + (f" {tm}" if tm else "") + f" — {kind.lower()}", bg=WHITE).pack(
                fill="x", pady=(14, 0))

    # ---- side panels -----------------------------------------------------------------
    def fill_side(self):
        for part in (self.recent, self.low):
            for w in part.winfo_children():
                w.destroy()
        group = self.app.group_of_filter()
        today = date.today().isoformat()
        rows = self.db.q("SELECT s.id, s.session_date FROM attendance_sessions s WHERE s.kind IN (?, ?) AND "
                         "s.session_date <= ? AND EXISTS (SELECT 1 FROM attendance a WHERE a.session_id = s.id) "
                         "ORDER BY s.session_date DESC, s.id DESC LIMIT 30", REHEARSAL_KINDS + (today,))
        if group:
            sg = self.db.session_groups()
            rows = [r for r in rows if in_event_groups(group, sg.get(r[0], ""))]
        rows = rows[:5]
        dgroups = self.db.dancer_groups() if group else {}
        for sid, d in rows:
            marks = [m for did, m in self.db.q("SELECT dancer_id, mark FROM attendance WHERE session_id=?", (sid,))
                     if not group or in_event_groups(dgroups.get(did, ""), group)]
            p = pct(sum(1 for m in marks if m in CAME), len(marks))
            line = tk.Frame(self.recent, bg=WHITE, cursor="hand2")
            line.pack(fill="x", padx=14, pady=4)
            tk.Label(line, text=f"{d[8:10]}.{d[5:7]}.", bg=WHITE, fg=NAVY, font=FONT_SMALL, width=6,
                     anchor="w").pack(side="left")
            tk.Label(line, text=pct_text(p), bg=WHITE, fg=pct_colour(p), font=("Segoe UI", 9, "bold"), width=6,
                     anchor="e").pack(side="right")
            bar = tk.Canvas(line, height=8, bg="#F1ECDF", highlightthickness=0)
            bar.pack(side="left", fill="x", expand=True, padx=(4, 8))
            bar.bind("<Configure>", lambda e, c=bar, v=p or 0, col=pct_colour(p): (
                c.delete("all"), c.create_rectangle(0, 0, e.width * v / 100, 8, fill=col, outline="")))
            for w in (line,) + tuple(line.winfo_children()):
                w.bind("<Button-1>", lambda e, s=sid: SessionWindow(self.app, s))
        if not rows:
            izskats.note(self.recent, "Vēl nav mēģinājumu ar atzīmēm.", bg=WHITE).pack(fill="x", padx=14, pady=8)
        tk.Frame(self.recent, bg=WHITE, height=6).pack()

        stats = [r for r in getattr(self.app, "all_stats", []) if r["status"] == STATUS_ACTIVE
                 and r["pct"] is not None and r["pct"] < LOW_PCT]
        stats.sort(key=lambda r: (r["pct"], _norm(r["last_name"])))
        for r in stats[:12]:
            line = tk.Frame(self.low, bg=WHITE, cursor="hand2")
            line.pack(fill="x", padx=14, pady=3)
            tk.Label(line, text=full_name(r["first_name"], r["last_name"]), bg=WHITE, fg=NAVY, font=FONT,
                     anchor="w").pack(side="left")
            tk.Label(line, text=pct_text(r["pct"]), bg=WHITE, fg=RED, font=FONT_BOLD).pack(side="right")
            for w in (line,) + tuple(line.winfo_children()):
                w.bind("<Button-1>", lambda e, did=r["id"]: DancerHistory(self.app, did))
        if not stats:
            izskats.note(self.low, "Periodā nevienam aktīvam dejotājam nav zemas cītības.", bg=WHITE,
                         wrap=self.SIDE - 40).pack(fill="x", padx=14, pady=8)
        elif len(stats) > 12:
            izskats.note(self.low, f"… un vēl {len(stats) - 12} (cilnē “Dejotāju cītība”)", bg=WHITE).pack(
                fill="x", padx=14, pady=(4, 0))
        izskats.note(self.low, f"Periods: {self.app.period_text()}", bg=WHITE, wrap=self.SIDE - 40).pack(
            fill="x", padx=14, pady=(8, 10))


# --------------------------------------------------------------------------
# One session: details + marks for every dancer
# --------------------------------------------------------------------------
class SessionWindow(tk.Toplevel):
    def __init__(self, app, session_id=None, on_saved=None, day=None):
        super().__init__(app.root)
        self.app, self.db, self.session_id, self.on_saved = app, app.db, session_id, on_saved
        if session_id is None and not piekluve.current().can_edit("citibas_purs"):
            self.withdraw()
            piekluve.deny(app.root, "Jūsu loma nevar izveidot notikumus.")
            self.destroy()
            return
        self.configure(bg=CREAM)
        self.title("Jauns notikums" if session_id is None else "Notikums")
        self.geometry("1000x820")
        self.transient(app.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.changed = False
        self.selected_dances = set()
        self.dance_info = {i: (t, st) for i, t, st in self.db.all_dances()}

        # Pūrlāde v0.8.9: baltā virsraksta josla, lauki baltos paneļos, pogas baltā joslā apakšā
        izskats.dialog_header(self, "Jauns notikums" if session_id is None else "Notikums",
                              "Mēģinājums, koncerts vai cits notikums un dejotāju apmeklējuma atzīmes."
                              if session_id is None else "", colour=COPPER)

        # ---- buttons (packed first so they never leave the window) ----
        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.cancel).pack(side="right", padx=6)
        if session_id is not None:
            ttk.Button(btns, text="Dzēst notikumu", style="Danger.TButton",
                       command=self.delete).pack(side="left")

        # ---- session details ----
        self.body = tk.Frame(self, bg=CREAM)
        self.body.pack(fill="both", expand=True, padx=18, pady=(12, 14))
        form_box = boxed(self.body)
        form_box.pack(fill="x")
        form = tk.Frame(form_box, bg=CREAM)
        form.pack(fill="x", padx=14, pady=8)
        self.v_date, self.v_kind, self.v_title = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.v_time, self.v_notes = tk.StringVar(), tk.StringVar()

        def label(text, r, c):
            tk.Label(form, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))
        label("Datums *", 0, 0)
        date_box = tk.Frame(form, bg=CREAM)
        date_box.grid(row=0, column=1, sticky="w", padx=(8, 0))
        date_entry = ttk.Entry(date_box, textvariable=self.v_date, width=12)
        date_entry.pack(side="left")
        date_picker_button(date_box, self.v_date).pack(side="left", padx=(2, 0))   # izvēle no kalendāra
        self.weekday_lbl = tk.Label(date_box, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), width=11,
                                    anchor="w")
        self.weekday_lbl.pack(side="left", padx=(4, 0))
        label("Veids", 0, 2)
        ttk.Combobox(form, textvariable=self.v_kind, values=KINDS, state="readonly", width=18).grid(
            row=0, column=3, sticky="w", padx=(8, 0))
        label("Sākuma laiks", 0, 4)
        ttk.Entry(form, textvariable=self.v_time, width=8).grid(row=0, column=5, sticky="w", padx=(8, 0))
        label("Nosaukums / tēma", 1, 0)
        ttk.Entry(form, textvariable=self.v_title).grid(row=1, column=1, columnspan=5, sticky="ew", padx=(8, 0),
                                                        pady=4)
        label("Piezīmes", 2, 0)
        ttk.Entry(form, textvariable=self.v_notes).grid(row=2, column=1, columnspan=5, sticky="ew", padx=(8, 0),
                                                        pady=4)
        label("Dejas", 3, 0)
        self.dances_lbl = tk.Label(form, text="", bg=SOFT_BG, fg=NAVY, anchor="w", justify="left", wraplength=520,
                                   padx=6, pady=3, highlightthickness=1, highlightbackground=LINE)
        self.dances_lbl.grid(row=3, column=1, columnspan=4, sticky="ew", padx=(8, 0), pady=4)
        dbtn = tk.Frame(form, bg=CREAM)
        dbtn.grid(row=3, column=5, sticky="e", padx=(8, 0))
        ttk.Button(dbtn, text="Izvēlēties dejas…", command=self.pick_dances).pack(side="left")
        ttk.Button(dbtn, text="Kā pēdējā reizē", command=self.dances_like_last).pack(side="left", padx=(4, 0))
        form.columnconfigure(5, weight=1)
        tk.Label(form, text="Datumu raksta formā DD.MM.GGGG, laiku — 18:30. Dejas — no Deju pūra: mēģinājumā "
                            "mēģinātās, koncertā vai skatē dejotās.", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=4, column=0, columnspan=6, sticky="w")
        self.form = form
        self.repeat = None
        if session_id is None:  # a series of events can be planned only for a new event
            self.repeat = tk.BooleanVar(value=False)
            ttk.Checkbutton(form, text="↻ Atkārtojas (ieplānot vairākus notikumus)", variable=self.repeat,
                            command=self.toggle_repeat).grid(row=5, column=1, columnspan=5, sticky="w",
                                                             padx=(8, 0), pady=(2, 0))
            self.build_repeat()
        # which groups the event is for (Kopas pūrs → Grupa): only their dancers are listed for marking
        label("Grupa *", 6, 0)
        gbox = tk.Frame(form, bg=CREAM)
        gbox.grid(row=6, column=1, columnspan=5, sticky="w", padx=(8, 0))
        self.group_vars, self.group_cbs = {}, {}
        for g in DANCER_GROUPS:
            var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(gbox, text=g, variable=var, command=self.on_groups)
            cb.pack(side="left", padx=(0, 10))
            self.group_vars[g] = var
            self.group_cbs[g] = cb
        tk.Label(gbox, text="sarakstā — tikai šo grupu dejotāji (un jau atzīmētie); Kabatas Pūrlādē notikumu redz "
                            "tikai šīs grupas", bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).pack(side="left")
        self.dancer_group = self.db.dancer_groups()

        # ---- toolbar ----
        list_box = boxed(self.body)
        list_box.pack(fill="both", expand=True, pady=(10, 0))
        tools = tk.Frame(list_box, bg=CREAM)
        tools.pack(fill="x", padx=12, pady=(8, 4))
        tk.Label(tools, text="Dejotāju atzīmes", font=("Georgia", 12, "bold"), bg=CREAM, fg=NAVY).pack(side="left")
        tk.Label(tools, text="(blakus vārdam — atbilde lietotnē)", font=("Segoe UI", 8, "italic"), bg=CREAM,
                 fg=GREY).pack(side="left", padx=(6, 0))
        ttk.Button(tools, text="✓ Pārējie ieradās", command=self.mark_rest_present).pack(side="left", padx=(14, 4))
        ttk.Button(tools, text="Notīrīt atzīmes", command=self.clear_marks).pack(side="left", padx=4)
        self.only_cast = tk.BooleanVar(value=False)
        self.only_cast_cb = ttk.Checkbutton(tools, text="Tikai izvēlēto deju sastāvs", variable=self.only_cast,
                                            command=self.apply_filter)
        self.only_cast_cb.pack(side="left", padx=(10, 0))
        self.show_who = tk.StringVar(value=SHOW_ALL)
        who = tk.Frame(tools, bg=CREAM)
        who.pack(side="left", padx=(14, 0))
        tk.Label(who, text="Rādīt:", bg=CREAM, fg=NAVY).pack(side="left", padx=(0, 4))
        for option in (SHOW_ALL, SHOW_MEN, SHOW_WOMEN):
            tk.Radiobutton(who, text=option, variable=self.show_who, value=option, indicatoron=0, width=7,
                           bg=WHITE, fg=NAVY, selectcolor=SELECTED, activebackground=SELECTED, activeforeground=NAVY,
                           relief="flat", bd=1, offrelief="flat", overrelief="ridge", font=("Segoe UI", 9),
                           cursor="hand2", command=self.apply_filter).pack(side="left", padx=1)
        self.counter = tk.Label(tools, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"))
        self.counter.pack(side="right")

        # ---- search and sorting ----
        tools2 = tk.Frame(list_box, bg=CREAM)
        tools2.pack(fill="x", padx=12, pady=(0, 8))
        tk.Label(tools2, text="Meklēt dejotāju:", bg=CREAM, fg=NAVY).pack(side="left")
        self.search = tk.StringVar()
        self.search_entry = ttk.Entry(tools2, textvariable=self.search, width=24)
        self.search_entry.pack(side="left", padx=(6, 2))
        tk.Button(tools2, text="✕", command=lambda: self.search.set(""), bg=CREAM, fg=GREY, relief="flat", bd=0,
                  activebackground=GOLD, cursor="hand2", font=("Segoe UI", 9)).pack(side="left", padx=(0, 14))
        self.search.trace_add("write", lambda *a: self.apply_filter())
        tk.Label(tools2, text="Kārtot pēc:", bg=CREAM, fg=NAVY).pack(side="left", padx=(0, 4))
        self.sort_by = tk.StringVar(value=SORT_FIRST)
        for option in (SORT_FIRST, SORT_LAST):
            tk.Radiobutton(tools2, text=option + " ▲", variable=self.sort_by, value=option, indicatoron=0, width=10,
                           bg=WHITE, fg=NAVY, selectcolor=SELECTED, activebackground=SELECTED, activeforeground=NAVY,
                           relief="flat", bd=1, offrelief="flat", overrelief="ridge", font=("Segoe UI", 9),
                           cursor="hand2", command=self.apply_filter).pack(side="left", padx=1)
        tk.Label(tools2, text="(alfabēta secībā)", bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).pack(
            side="left", padx=(6, 0))

        # ---- scrollable list of dancers ----
        tk.Frame(list_box, bg=LINE_SOFT, height=1).pack(fill="x")
        box = tk.Frame(list_box, bg=WHITE)
        box.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(box, bg=WHITE, highlightthickness=0)
        sb = ttk.Scrollbar(box, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.rows_frame = tk.Frame(self.canvas, bg=WHITE)
        win_id = self.canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        self.rows_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(win_id, width=e.width))
        self.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                                     "units"))
        self.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        self.bind("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))
        recolour(self.body)   # the fields on white panels

        # ---- load ----
        existing = {}
        if session_id is not None:
            try:   # the newest answers from Kabatas Pūrlāde first
                self.db.auto_app_marks()
            except Exception:
                log_error(traceback.format_exc())
            d, kind, title, tm, notes = self.db.q("SELECT session_date, kind, title, start_time, notes FROM "
                                                  "attendance_sessions WHERE id=?", (session_id,))[0]
            self.orig = (d, kind or KIND_REHEARSAL)   # date and kind when opened (no duplicate warning for them)
            self.v_date.set(show_date(d))
            self.v_kind.set(kind or KIND_REHEARSAL)
            self.v_title.set(title or "")
            self.v_time.set(tm or "")
            self.v_notes.set(notes or "")
            existing = {did: (mark, note) for did, mark, note in
                        self.db.q("SELECT dancer_id, mark, note FROM attendance WHERE session_id=?", (session_id,))}
            chosen = event_groups(self.db.session_groups({session_id}).get(session_id, "")) or DANCER_GROUPS
            if self.dance_info:
                self.selected_dances = {r[0] for r in self.db.q("SELECT dance_id FROM session_dances "
                                                                "WHERE session_id=?", (session_id,))}
        else:
            self.v_date.set(show_date((day or date.today()).isoformat()))
            self.v_kind.set(KIND_REHEARSAL)
            last_time = self.db.q("SELECT start_time FROM attendance_sessions WHERE kind=? AND start_time<>'' "
                                  "ORDER BY session_date DESC, id DESC LIMIT 1", (KIND_REHEARSAL,))
            if last_time:
                self.v_time.set(last_time[0][0])
            # groups as in the last rehearsal (else the default group A)
            last = self.db.q("SELECT e.for_groups FROM attendance_sessions s JOIN event_details e ON e.session_id = s.id "
                             "WHERE s.kind=? AND TRIM(COALESCE(e.for_groups,''))<>'' "
                             "ORDER BY s.session_date DESC, s.id DESC LIMIT 1", (KIND_REHEARSAL,))
            chosen = event_groups(last[0][0]) if last else [DEFAULT_DANCER_GROUP]
        for g, var in self.group_vars.items():
            var.set(g in chosen)

        # answers given in the mobile app (Notikumu pūrs uses the same table): shown next to each dancer;
        # "Nebūs" / "Kavēšu" pre-fill the mark of a dancer who has no mark yet (saved with "Saglabāt");
        # "Būs" — "Ieradās", but only once the event has started
        self.app_answers = self.load_app_answers(session_id)
        started = self.event_started(session_id)
        self.marks, self.notes, self.rows, self.visible, self.genders, self.names = {}, {}, {}, [], {}, {}
        dancers = self.db.dancers(existing.keys())
        dancers.sort(key=lambda r: (_norm(r[1]), _norm(r[2])))  # alphabetically by first name
        if not dancers:
            tk.Label(self.rows_frame, text="Kopas pūrā nav neviena aktīva dejotāja.\n"
                                           "Vispirms pievienojiet dejotājus Kopas pūrā.",
                     bg=WHITE, fg=GREY, font=("Segoe UI", 11, "italic"), pady=30).pack(fill="x")
        for i, (did, first, last, gender, status) in enumerate(dancers):
            self.genders[did] = gender or ""
            self.names[did] = (first or "", last or "")
            mark, note = existing.get(did, ("", ""))
            answer = self.app_answers.get(did)
            if not mark and answer:
                ans, reason, late = answer
                if ans == APP_YES and started:
                    mark = MARK_PRESENT
                elif ans == APP_NO:
                    mark, note = MARK_EXCUSED, note or ("Lietotnē: nebūs" + (f" — {reason}" if reason else ""))
                elif ans == APP_LATE:
                    mark, note = MARK_LATE, note or (f"Lietotnē: kavēs {late} min" if late else "Lietotnē: kavēs") \
                        + (f" — {reason}" if reason else "")
            self.add_row(i, did, full_name(first, last), status, mark, note, answer)

        for var in (self.v_date, self.v_kind, self.v_title, self.v_time, self.v_notes):
            var.trace_add("write", lambda *a: self.set_changed())
        self.v_date.trace_add("write", lambda *a: self.show_weekday())
        if self.repeat is not None:
            self.v_date.trace_add("write", lambda *a: self.update_repeat())
        self.show_weekday()
        self.show_dances()
        self.apply_filter()
        self.bind("<Escape>", lambda e: self.cancel())
        date_entry.focus_set()
        self.apply_rights()
        self.after(100, lambda: fit_min_size(self))

    def event_started(self, session_id):
        """True when this (saved) event has already begun (its day has passed, or it is today and the start
        time has come)."""
        if session_id is None:
            return False
        row = self.db.q("SELECT session_date, COALESCE(start_time, '') FROM attendance_sessions WHERE id=?",
                        (session_id,))
        if not row:
            return False
        now = datetime.now()
        day, start = row[0][0] or "", (row[0][1] or "").strip()
        today = now.date().isoformat()
        return day < today or (day == today and start <= now.strftime("%H:%M"))

    def apply_rights(self):
        """Lietotāju lomas: marks of events of other groups only to look at; new events only for own groups."""
        acc = piekluve.current()
        self.old_groups = list(self.chosen_groups()) if self.session_id is not None else []
        if self.session_id is not None and not acc.can_edit("citibas_purs", groups=self.old_groups):
            piekluve.make_readonly(self, note=(
                "Tikai skatīšanai — " + ("jūsu lomai Cītības pūrā nav labošanas tiesību."
                                         if acc.view_only("citibas_purs") else
                                         f"labot var tikai {acc.scope_text('citibas_purs')}s notikumus.")))
            return
        if not acc.edits_all("citibas_purs"):
            allowed = acc.groups("citibas_purs")
            for g, cb in self.group_cbs.items():
                if g not in allowed:
                    cb.configure(state="disabled")
            if self.session_id is None:
                for g, var in self.group_vars.items():
                    var.set(g == (allowed[0] if allowed else DEFAULT_DANCER_GROUP))
                self.on_groups()
        self.changed = False

    def load_app_answers(self, session_id):
        """{dancer id: (answer, reason/comment, late minutes)} — answers from the mobile app / Notikumu pūrs."""
        if session_id is None:
            return {}
        try:
            rows = self.db.q("SELECT dancer_id, answer, note FROM event_participants WHERE session_id=?", (session_id,))
        except sqlite3.Error:
            return {}
        late = {}
        try:
            late = dict(self.db.q("SELECT dancer_id, late_minutes FROM app_answers WHERE session_id=?", (session_id,)))
        except sqlite3.Error:
            pass   # the mobile app has not been used yet
        return {did: (ans or "", note or "", int(late.get(did) or 0)) for did, ans, note in rows if ans}

    def add_row(self, i, did, name, status, mark, note, answer=None):
        bg = WHITE if i % 2 == 0 else ZEBRA
        row = tk.Frame(self.rows_frame, bg=bg)
        row.pack(fill="x")
        self.rows[did] = row
        inactive = (status or STATUS_ACTIVE) != STATUS_ACTIVE
        tk.Label(row, text=name + (f"  ({status.lower()})" if inactive else ""), bg=bg,
                 fg=GREY if inactive else NAVY, font=("Segoe UI", 10, "bold"), width=28, anchor="w").pack(
            side="left", padx=(10, 6), pady=4)
        ans_text, ans_fg = "", GREY
        if answer:
            ans, reason, late = answer
            ans_text = {APP_LATE: f"Kavēs {late} min" if late else "Kavēs"}.get(ans, ans)
            ans_fg = answer_look(answer)[1]
        ans_lbl = tk.Label(row, text=ans_text, bg=bg, fg=ans_fg, font=("Segoe UI", 9, "bold"), width=12, anchor="w")
        ans_lbl.pack(side="left", padx=(0, 4))
        if answer and answer[1]:
            tip = answer[1]
            ans_lbl.bind("<Enter>", lambda e: self.counter.configure(text=f"{name}: {tip}"))
            ans_lbl.bind("<Leave>", lambda e: self.update_counter())
        var = tk.StringVar(value=mark)
        for m in MARKS:
            tk.Radiobutton(row, text=m, variable=var, value=m, indicatoron=0, width=12,
                           bg=WHITE, fg=NAVY, selectcolor=MARK_LOOK[m][0], activebackground=SELECTED,
                           activeforeground=NAVY, relief="flat", bd=0, offrelief="flat", overrelief="flat",
                           highlightthickness=1, highlightbackground=MARK_OFF[2],
                           font=("Segoe UI", 9), cursor="hand2").pack(side="left", padx=2, pady=4)
        tk.Button(row, text="✕", command=lambda: var.set(""), bg=bg, fg=GREY, relief="flat", bd=0,
                  activebackground=SELECTED, cursor="hand2", font=("Segoe UI", 9)).pack(side="left", padx=(2, 8))
        note_var = tk.StringVar(value=note or "")
        ttk.Entry(row, textvariable=note_var, width=22).pack(side="left", fill="x", expand=True, padx=(0, 10))
        var.trace_add("write", lambda *a: (self.set_changed(), self.update_counter()))
        note_var.trace_add("write", lambda *a: self.set_changed())
        self.marks[did], self.notes[did] = var, note_var

    def set_changed(self):
        if getattr(self, "readonly", False):
            return
        self.changed = True

    def show_weekday(self):
        d = parse_date(self.v_date.get())
        self.weekday_lbl.configure(text=WEEKDAYS_FULL[date.fromisoformat(d).weekday()] if d else "")

    # ---- planning a series (the same as in Notikumu pūrs) ------------------------
    def build_repeat(self):
        f = self.repeat_frame = tk.Frame(self, bg=SOFT_BG, padx=12, pady=8, highlightthickness=1,
                                         highlightbackground=LINE)
        self.repeat_mode = tk.StringVar(value=REPEAT_WEEKDAYS)
        self.repeat_days = [tk.BooleanVar(value=False) for _ in WEEKDAYS]
        self.repeat_every = tk.StringVar(value=EVERY_WEEK)
        self.repeat_until = tk.StringVar()
        self.repeat_dates = tk.StringVar()
        opts = dict(bg=SOFT_BG, fg=NAVY, activebackground=SOFT_BG, selectcolor=WHITE, cursor="hand2",
                    command=self.update_repeat)

        row1 = tk.Frame(f, bg=SOFT_BG)
        row1.pack(fill="x")
        tk.Radiobutton(row1, text="Nedēļas dienās:", variable=self.repeat_mode, value=REPEAT_WEEKDAYS,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        for i, name in enumerate(WEEKDAYS):
            tk.Checkbutton(row1, text=name, variable=self.repeat_days[i], **opts).pack(side="left", padx=(0, 2))
        every = ttk.Combobox(row1, textvariable=self.repeat_every, values=EVERY_CHOICES, state="readonly", width=17)
        every.pack(side="left", padx=(10, 0))
        every.bind("<<ComboboxSelected>>", lambda e: self.update_repeat())
        tk.Label(row1, text="līdz", bg=SOFT_BG, fg=NAVY).pack(side="left", padx=(10, 4))
        ttk.Entry(row1, textvariable=self.repeat_until, width=12).pack(side="left")
        date_picker_button(row1, self.repeat_until, bg=SOFT_BG, fallback_var=self.v_date).pack(side="left", padx=(2, 0))
        tk.Label(row1, text="(ieskaitot)", bg=SOFT_BG, fg=GREY, font=("Segoe UI", 8, "italic")).pack(
            side="left", padx=(4, 0))

        row2 = tk.Frame(f, bg=SOFT_BG)
        row2.pack(fill="x", pady=(6, 0))
        tk.Radiobutton(row2, text="Konkrētos datumos:", variable=self.repeat_mode, value=REPEAT_DATES,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        ttk.Entry(row2, textvariable=self.repeat_dates).pack(side="left", fill="x", expand=True)
        tk.Label(row2, text="atdala ar komatu, piem., 07.11.2026, 21.11.2026", bg=SOFT_BG, fg=GREY,
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(6, 0))

        self.repeat_lbl = tk.Label(f, text="", bg=SOFT_BG, fg=NAVY, font=("Segoe UI", 9), anchor="w",
                                   justify="left", wraplength=820)
        self.repeat_lbl.pack(fill="x", pady=(6, 0))
        for var in (self.repeat_until, self.repeat_dates):
            var.trace_add("write", lambda *a: self.update_repeat())

    def toggle_repeat(self):
        if self.repeat.get():
            first = parse_date(self.v_date.get())
            if first and not any(v.get() for v in self.repeat_days):
                self.repeat_days[date.fromisoformat(first).weekday()].set(True)
            self.repeat_frame.pack(fill="x", padx=14, pady=(0, 10), after=self.form)
        else:
            self.repeat_frame.pack_forget()
        self.update_repeat()

    def repeat_list(self):
        """(sorted ISO dates of all events to create, error text or None)."""
        first = parse_date(self.v_date.get())
        if not first:
            return None, "Norādiet pareizu datumu formā DD.MM.GGGG."
        if self.repeat is None or not self.repeat.get():
            return [first], None
        dates = {first}
        if self.repeat_mode.get() == REPEAT_WEEKDAYS:
            days = {i for i, v in enumerate(self.repeat_days) if v.get()}
            if not days:
                return None, "Izvēlieties vismaz vienu nedēļas dienu."
            until = parse_date(self.repeat_until.get())
            if not until:
                return None, "Norādiet, līdz kuram datumam notikums atkārtojas (DD.MM.GGGG)."
            if until < first:
                return None, "Datums “līdz” ir agrāks par notikuma datumu."
            step = 2 if self.repeat_every.get() == EVERY_2_WEEKS else 1
            d0 = date.fromisoformat(first)
            monday0 = d0 - timedelta(days=d0.weekday())
            d, end = d0, date.fromisoformat(until)
            while d <= end:
                week = ((d - timedelta(days=d.weekday())) - monday0).days // 7
                if d.weekday() in days and week % step == 0:
                    dates.add(d.isoformat())
                d += timedelta(days=1)
        else:
            parts = [p for p in re.split(r"[,;\s]+", self.repeat_dates.get()) if p]
            if not parts:
                return None, "Ierakstiet datumus, kuros notikums atkārtojas, atdalot tos ar komatu."
            for part in parts:
                d = parse_date(part)
                if not d:
                    return None, f"Nesaprotams datums “{part}”. Datumu raksta formā DD.MM.GGGG."
                dates.add(d)
        if len(dates) > MAX_REPEATS:
            return None, f"Pārāk daudz notikumu ({len(dates)}). Vienā reizē var izveidot līdz {MAX_REPEATS}."
        return sorted(dates), None

    def update_repeat(self):
        if self.repeat is None or not self.repeat.get():
            return
        dates, error = self.repeat_list()
        if error:
            self.repeat_lbl.configure(text="⚠ " + error, fg=RED)
            return
        shown = ", ".join(f"{show_date(d)} ({weekday(d)})" for d in dates[:14])
        more = f" … un vēl {len(dates) - 14}" if len(dates) > 14 else ""
        self.repeat_lbl.configure(text=f"Tiks izveidoti {len(dates)} notikumi ar vienādu veidu, laiku, nosaukumu, "
                                       f"piezīmēm un dejām: {shown}{more}. Dejotāju atzīmes tiek saglabātas tikai "
                                       f"{show_date(parse_date(self.v_date.get()))} notikumam.", fg=NAVY)

    # ---- dances --------------------------------------------------------------
    def show_dances(self):
        titles = sorted((self.dance_info[i][0] for i in self.selected_dances if i in self.dance_info), key=_norm)
        if titles:
            text = ", ".join(titles)
        elif self.dance_info:
            text = "— nav izvēlētas —"
        else:
            text = "Deju pūrā vēl nav nevienas dejas."
        self.dances_lbl.configure(text=text, fg=NAVY if titles else GREY)
        self.only_cast_cb.configure(state="normal" if titles else "disabled")
        if not titles and self.only_cast.get():
            self.only_cast.set(False)

    def set_dances(self, ids):
        ids = set(ids)
        if ids != self.selected_dances:
            self.selected_dances = ids
            self.set_changed()
        self.show_dances()
        self.apply_filter()

    def pick_dances(self):
        if not self.dance_info:
            messagebox.showinfo("Dejas", "Deju pūrā vēl nav nevienas dejas. Vispirms pievienojiet dejas Deju pūrā.",
                                parent=self)
            return
        DancePicker(self, self.dance_info, self.selected_dances, self.set_dances)

    def dances_like_last(self):
        rows = self.db.q("SELECT s.id FROM attendance_sessions s WHERE s.id<>? AND EXISTS "
                         "(SELECT 1 FROM session_dances sd WHERE sd.session_id = s.id) "
                         "ORDER BY s.session_date DESC, s.start_time DESC, s.id DESC LIMIT 1",
                         (self.session_id or -1,)) if self.dance_info else []
        if not rows:
            messagebox.showinfo("Dejas", "Nevienā citā notikumā vēl nav atzīmētas dejas.", parent=self)
            return
        self.set_dances(r[0] for r in self.db.q("SELECT dance_id FROM session_dances WHERE session_id=?",
                                                (rows[0][0],)))

    def chosen_groups(self):
        return [g for g, var in self.group_vars.items() if var.get()]

    def on_groups(self):
        self.changed = True
        self.apply_filter()

    def apply_filter(self):
        """Which dancers are shown and in what order: dancers of the event's groups and cast of the chosen
        dances (plus anyone already marked), boys / girls, the search text; sorted by first or last name."""
        if not hasattr(self, "sort_by") or not hasattr(self, "group_vars"):  # still building the window
            return
        groups = event_groups_text(self.chosen_groups())
        cast = self.db.dance_cast(self.selected_dances) if self.only_cast.get() else None
        gender = SHOW_GENDER.get(self.show_who.get(), "")
        term = _norm(self.search.get())
        by_last = self.sort_by.get() == SORT_LAST

        def key(did):
            first, last = self.names.get(did, ("", ""))
            return (_norm(last), _norm(first)) if by_last else (_norm(first), _norm(last))
        for row in self.rows.values():
            row.pack_forget()
        self.visible = []
        for did in sorted(self.rows, key=key):
            row = self.rows[did]
            if gender and self.genders.get(did) != gender:
                continue
            if term and term not in _norm(full_name(*self.names.get(did, ("", "")))):
                continue
            in_group = in_event_groups(self.dancer_group.get(did, ""), groups) or (cast is not None and did in cast)
            if (cast is None or did in cast or self.marks[did].get()) and (in_group or self.marks[did].get()):
                row.pack(fill="x")
                self.visible.append(did)
        for n, did in enumerate(self.visible):  # keep the white / cream stripes after filtering
            bg = WHITE if n % 2 == 0 else ZEBRA
            row = self.rows[did]
            row.configure(bg=bg)
            for child in row.winfo_children():
                if child.winfo_class() in ("Label", "Button"):
                    child.configure(bg=bg)
        self.canvas.yview_moveto(0)
        self.update_counter()

    def update_counter(self):
        values = [self.marks[did].get() for did in self.visible]
        marked = sum(1 for v in values if v)
        came = sum(1 for v in values if v in CAME)
        self.counter.configure(text=f"Atzīmēti {marked} no {len(values)}  ·  ieradās {came}"
                                    + (f"  ·  apmeklējums {pct_text(pct(came, marked))}" if marked else ""))

    def mark_rest_present(self):
        for did in self.visible:
            if not self.marks[did].get():
                self.marks[did].set(MARK_PRESENT)

    def clear_marks(self):
        if any(v.get() for v in self.marks.values()) and messagebox.askyesno(
                "Notīrīt", "Noņemt visas šī notikuma atzīmes?", parent=self):
            for var in self.marks.values():
                var.set("")

    def save(self):
        acc = piekluve.current()
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        if not acc.can_edit("citibas_purs", groups=self.chosen_groups()) or (
                self.session_id is not None and not acc.can_edit("citibas_purs", groups=self.old_groups)):
            return piekluve.deny(self, f"Labot var tikai {acc.scope_text('citibas_purs')}s notikumus.")
        day = parse_date(self.v_date.get())
        if not day:
            messagebox.showwarning("Datums", "Norādiet pareizu datumu formā DD.MM.GGGG.", parent=self)
            return
        tm = parse_time(self.v_time.get())
        if tm is None:
            messagebox.showwarning("Laiks", "Sākuma laiku norādiet formā 18:30.", parent=self)
            return
        dates, error = self.repeat_list()
        if error:
            messagebox.showwarning("Atkārtošana", error, parent=self)
            return
        if not self.chosen_groups():
            messagebox.showwarning("Grupa", "Atzīmējiet, kurai grupai (vai kurām grupām) ir šis notikums.", parent=self)
            return
        groups_text = event_groups_text(self.chosen_groups())
        kind = self.v_kind.get() or KIND_REHEARSAL
        # an event of the same kind already on that day?
        busy = {}
        if self.session_id is None or (day, kind) != getattr(self, "orig", None):
            for d in dates:
                found = self.db.q("SELECT id, start_time, title FROM attendance_sessions WHERE session_date=? AND "
                                  "kind=? AND id<>? ORDER BY start_time, id", (d, kind, self.session_id or -1))
                if found:
                    busy[d] = found[0]
        merge_into = {}   # date -> id of the existing event that gets this event's dances (and marks)
        if busy and self.session_id is None:
            if len(dates) == 1:
                sid, tm0, title0 = busy[day]
                what = ", ".join(p for p in (tm0, title0) if p)
                text = (f"{show_date(day)} jau ir mēģinājums" + (f" ({what})" if what else "") + ".\n\n"
                        "Jā — pievienot izvēlētās dejas un atzīmes esošajam notikumam (ieteicams).\n"
                        "Nē — izveidot vēl vienu, atsevišķu notikumu.\n"
                        "Atcelt — atgriezties logā.") if kind == KIND_REHEARSAL else (
                       f"{show_date(day)} jau ir notikums ar veidu “{kind}”" + (f" ({what})" if what else "") +
                       ".\n\nJā — pievienot izvēlētās dejas un atzīmes esošajam notikumam (ieteicams).\n"
                       "Nē — izveidot vēl vienu, atsevišķu notikumu.\nAtcelt — atgriezties logā.")
            else:
                listed = ", ".join(show_date(d) for d in sorted(busy)[:10]) + (" …" if len(busy) > 10 else "")
                text = (f"Šajos datumos jau ir notikums ar veidu “{kind}”: {listed}.\n\n"
                        "Jā — tajos datumos pievienot izvēlētās dejas esošajiem notikumiem, pārējos izveidot jaunus "
                        "(ieteicams).\nNē — visos datumos izveidot jaunus notikumus.\nAtcelt — atgriezties logā.")
            choice = messagebox.askyesnocancel("Notikums jau ir", text, parent=self)
            if choice is None:
                return
            if choice:
                merge_into = {d: row[0] for d, row in busy.items()}
        elif busy:   # an existing event moved to a day that already has one
            if not messagebox.askyesno(
                    "Dublikāts", f"{show_date(day)} jau ir cits notikums ar veidu “{kind}”. Vai tomēr pārcelt "
                                 "šo notikumu uz šo dienu?", parent=self):
                return
        marks = {did: var.get() for did, var in self.marks.items() if var.get()}
        if (self.marks and not marks and day <= date.today().isoformat() and not messagebox.askyesno(
                "Nav atzīmju", "Nevienam dejotājam nav atzīmes. Saglabāt notikumu bez atzīmēm?", parent=self)):
            return
        new_dates = [d for d in dates if d not in merge_into]
        if len(dates) > 1 and not messagebox.askyesno(
                "Ieplānot notikumus", f"Izveidot {len(new_dates)} notikumus ({show_date(dates[0])} – "
                                     f"{show_date(dates[-1])})"
                                     + (f" un dejas pievienot {len(merge_into)} esošajiem" if merge_into else "")
                                     + "?", parent=self):
            return
        info = (kind, self.v_title.get().strip(), tm, self.v_notes.get().strip())
        dances = [i for i in self.selected_dances if i in self.dance_info]
        con = self.db.con
        try:
            if self.session_id is None:
                created = {}
                for d, sid in merge_into.items():   # add to the event that is already there
                    con.executemany("INSERT OR IGNORE INTO session_dances (session_id, dance_id) VALUES (?,?)",
                                    [(sid, i) for i in dances])
                    old = self.db.q("SELECT title, start_time, notes FROM attendance_sessions WHERE id=?", (sid,))[0]
                    con.execute("UPDATE attendance_sessions SET title=?, start_time=?, notes=? WHERE id=?",
                                (old[0] or info[1], old[1] or info[2], old[2] or info[3], sid))
                    have = event_groups(self.db.session_groups({sid}).get(sid, ""))
                    if have:   # the event is now for its own groups and the chosen ones
                        self.db.save_groups(sid, event_groups_text(list(dict.fromkeys(
                            have + list(self.chosen_groups())))))
                    created[d] = sid
                for d in new_dates:
                    cur = con.execute("INSERT INTO attendance_sessions (session_date, kind, title, start_time, "
                                      "notes) VALUES (?,?,?,?,?)", (d,) + info)
                    created[d] = cur.lastrowid
                    self.db.save_groups(created[d], groups_text)
                    con.executemany("INSERT INTO session_dances (session_id, dance_id) VALUES (?,?)",
                                    [(created[d], i) for i in dances])
                self.session_id = created[day]
            else:
                con.execute("UPDATE attendance_sessions SET session_date=?, kind=?, title=?, start_time=?, notes=? "
                            "WHERE id=?", (day,) + info + (self.session_id,))
                self.db.save_groups(self.session_id, groups_text)
                con.execute("DELETE FROM session_dances WHERE session_id=?", (self.session_id,))
                con.executemany("INSERT INTO session_dances (session_id, dance_id) VALUES (?,?)",
                                [(self.session_id, i) for i in dances])
            # dancers' marks belong only to the event of the entered date
            if day in merge_into:   # existing event: the marks given here are added to (or replace) its marks
                for did, m in marks.items():
                    con.execute("INSERT INTO attendance (session_id, dancer_id, mark, note) VALUES (?,?,?,?) "
                                "ON CONFLICT(session_id, dancer_id) DO UPDATE SET mark=excluded.mark, "
                                "note=excluded.note", (self.session_id, did, m, self.notes[did].get().strip()))
            else:
                con.execute("DELETE FROM attendance WHERE session_id=?", (self.session_id,))
                con.executemany("INSERT INTO attendance (session_id, dancer_id, mark, note) VALUES (?,?,?,?)",
                                [(self.session_id, did, m, self.notes[did].get().strip())
                                 for did, m in marks.items()])
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        self.changed = False
        self.app.refresh(select_session=self.session_id)
        if self.on_saved:
            self.on_saved()
        self.destroy()

    def delete(self):
        if getattr(self, "readonly", False) or not piekluve.current().can_edit("citibas_purs",
                                                                               groups=self.old_groups):
            return piekluve.deny(self, "Šo notikumu jūsu loma nevar dzēst.")
        d = show_date(self.db.q("SELECT session_date FROM attendance_sessions WHERE id=?", (self.session_id,))[0][0])
        if not messagebox.askyesno("Dzēst", f"Dzēst notikumu ({d}) un visas tā atzīmes?", parent=self):
            return
        self.db.x("DELETE FROM attendance WHERE session_id=?", (self.session_id,))
        self.db.x("DELETE FROM session_dances WHERE session_id=?", (self.session_id,))
        self.db.x("DELETE FROM attendance_sessions WHERE id=?", (self.session_id,))
        self.app.refresh()
        if self.on_saved:
            self.on_saved()
        self.destroy()

    def cancel(self):
        if self.changed and not messagebox.askyesno("Nesaglabātas izmaiņas",
                                                    "Aizvērt, nesaglabājot izmaiņas?", parent=self):
            return
        self.destroy()


# --------------------------------------------------------------------------
# Choosing the dances of a session
# --------------------------------------------------------------------------
class DancePicker(tk.Toplevel):
    def __init__(self, parent, dance_info, selected, on_ok):
        super().__init__(parent)
        self.on_ok = on_ok
        self.configure(bg=CREAM)
        self.title("Notikuma dejas")
        self.geometry("480x620")
        self.transient(parent)
        self.grab_set()
        izskats.dialog_header(self, "Kuras dejas mēģinātas vai dejotas?", "Dejas no Deju pūra — pēc tām Deju pūrs "
                              "skaita, cik reižu deja mēģināta.", colour=COPPER, wrap=420)
        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Gatavs", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        ttk.Button(btns, text="Noņemt visas", command=lambda: [v.set(False) for v in self.vars.values()]).pack(
            side="left")

        box = boxed(self)
        box.pack(fill="both", expand=True, padx=18, pady=14)
        canvas = tk.Canvas(box, bg=WHITE, highlightthickness=0)
        sb = ttk.Scrollbar(box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=WHITE)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))
        self.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                                "units"))
        self.bind("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))
        self.bind("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))

        self.vars = {}
        groups = {g: [] for g in DANCE_GROUPS}
        for did, (title, status) in dance_info.items():
            groups.setdefault(status if status in groups else DANCE_IN_REPERTOIRE, []).append((did, title))
        for group, dances in groups.items():
            if not dances:
                continue
            tk.Label(inner, text=group.upper(), font=("Segoe UI", 8, "bold"), bg=WHITE,
                     fg=MUTED if group in (DANCE_RESTING, DANCE_ARCHIVED) else COPPER).pack(anchor="w", padx=12,
                                                                                         pady=(10, 2))
            for did, title in sorted(dances, key=lambda r: _norm(r[1])):
                var = tk.BooleanVar(value=did in selected)
                tk.Checkbutton(inner, text=title, variable=var, bg=WHITE, fg=NAVY, activebackground=SELECTED,
                               highlightthickness=0, bd=0, selectcolor=WHITE, anchor="w", font=("Segoe UI", 10),
                               cursor="hand2").pack(
                    fill="x", padx=(22, 10))
                self.vars[did] = var
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.ok())

    def ok(self):
        self.on_ok(did for did, var in self.vars.items() if var.get())
        self.destroy()


# --------------------------------------------------------------------------
# One dancer: all sessions in the chosen period
# --------------------------------------------------------------------------
class DancerHistory(tk.Toplevel):
    def __init__(self, app, dancer_id):
        super().__init__(app.root)
        self.app, self.dancer_id = app, dancer_id
        self.configure(bg=CREAM)
        self.geometry("820x600")
        self.transient(app.root)
        name = app.db.q("SELECT name FROM dancers WHERE id=?", (dancer_id,))[0][0]
        self.title(f"Cītība — {name}")
        self.summary = izskats.dialog_header(self, name, " ", colour=COPPER, wrap=760).subtitle

        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        izskats.note(btns, "Dubultklikšķis uz rindas atver notikumu.", bg=WHITE).pack(side="left")

        holder = boxed(self)
        holder.pack(fill="both", expand=True, padx=18, pady=14)
        cols = [("date", "Datums", 95), ("weekday", "Diena", 70), ("kind", "Veids", 130),
                ("title", "Nosaukums / tēma", 190), ("mark", "Atzīme", 140), ("note", "Piezīme", 150)]
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=key in ("title", "note"))
        for m in MARKS:
            self.tree.tag_configure(m, background=MARK_LOOK[m][0], foreground=MARK_LOOK[m][1])
        self.tree.bind("<Double-1>", self.open_session)
        make_tree_with_scroll(holder, self.tree)
        self.bind("<Escape>", lambda e: self.destroy())
        self.fill()

    def fill(self):
        if not self.winfo_exists():
            return
        start, end, kind = self.app.filters()
        sql = ("SELECT s.id, s.session_date, s.kind, s.title, a.mark, a.note FROM attendance a "
               "JOIN attendance_sessions s ON s.id=a.session_id WHERE a.dancer_id=? AND s.session_date BETWEEN ? AND ?")
        params = [self.dancer_id, start, end]
        if kind:
            sql += " AND s.kind=?"
            params.append(kind)
        rows = self.app.db.q(sql + " ORDER BY s.session_date DESC, s.start_time DESC, s.id DESC", params)
        self.tree.delete(*self.tree.get_children())
        counts = {m: 0 for m in MARKS}
        for sid, d, k, title, mark, note in rows:
            counts[mark] = counts.get(mark, 0) + 1
            self.tree.insert("", "end", iid=str(sid), tags=(mark,),
                             values=(show_date(d), weekday(d), k, title, MARK_BUTTON.get(mark, mark), note or ""))
        came = counts[MARK_PRESENT] + counts[MARK_LATE]
        p = pct(came, len(rows))
        self.summary.configure(
            text=f"Periods: {self.app.period_text()}  ·  "
                 f"notikumi: {len(rows)}  ·  ieradās {counts[MARK_PRESENT]}  ·  nokavēja {counts[MARK_LATE]}  ·  "
                 f"attaisnoti nebija {counts[MARK_EXCUSED]}  ·  neattaisnoti nebija {counts[MARK_ABSENT]}  ·  "
                 f"apmeklējums {pct_text(p)}")

    def open_session(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            SessionWindow(self.app, int(row), on_saved=self.fill)


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        today = date.today()
        self.journal_month = (today.year, today.month)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        izskats.apply_style()   # kopīgais izskats (Pūrlāde v0.8)
        s = ttk.Style()
        s.configure("White.TLabel", background=WHITE, foreground=NAVY)
        s.configure("White.TCheckbutton", background=WHITE, foreground=NAVY)
        s.map("White.TCheckbutton", background=[("active", WHITE), ("disabled", WHITE)])

    # ---- layout -----------------------------------------------------------

    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        # Pūrlāde v0.8: baltā moduļa galvene ar cilnēm (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = hr = izskats.module_header(
            self.root, "citibas_purs", PROGRAM_NAME, f"Apmeklējuma uzskaite · v{APP_VERSION}", on_logo=self.show_main,
            on_exit=None if self.on_exit is not None else self.root.destroy, tabs=True)
        acc = piekluve.current()
        if acc.can_edit("citibas_purs"):
            izskats.header_button(hr, "＋ Jauns notikums", lambda: SessionWindow(self), primary=True).pack(
                side="right", padx=(8, 0))
        izskats.header_button(hr, "⇩ Eksportēt cītību", self.export).pack(side="right")
        if not acc.edits_all("citibas_purs"):
            tk.Label(hr, text="🔒 " + ("tikai skatīšanai" if acc.view_only("citibas_purs") else
                                      "labot var " + acc.scope_text("citibas_purs") + "s notikumus"),
                     bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold")).pack(side="right", padx=(0, 10))

        # summary cards and filters — for the tabs Notikumi, Dejotāju cītība, Žurnāls (not for Šodien)
        self.top = tk.Frame(self.root, bg=CREAM)
        cards = tk.Frame(self.top, bg=CREAM)
        cards.pack(fill="x", pady=(14, 0))
        self.card_vars = {}
        specs = [("sessions", "Notikušie periodā (+ gaidāmie)", NAVY), ("average", "Vidējais apmeklējums", COPPER),
                 ("last", "Pēdējā notikumā", DARK_GOLD), ("good", f"Cītīgie (≥ {GOOD_PCT} %)", OK_FG),
                 ("low", f"Zema cītība (< {LOW_PCT} %)", RED)]
        for i, (key, title, colour) in enumerate(specs):
            cards.columnconfigure(i, weight=1, uniform="card")
            card = boxed(cards)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 4, 0 if i == len(specs) - 1 else 4))
            tk.Frame(card, bg=colour, width=4).pack(side="left", fill="y")
            inner = tk.Frame(card, bg=WHITE)
            inner.pack(side="left", fill="both", expand=True, padx=10, pady=8)
            var = tk.StringVar(value="—")
            self.card_vars[key] = var
            tk.Label(inner, text=title, font=("Segoe UI", 8), bg=WHITE, fg=MUTED, anchor="w", justify="left",
                     wraplength=170).pack(fill="x")
            tk.Label(inner, textvariable=var, font=("Georgia", 15, "bold"), bg=WHITE, fg=colour, anchor="w").pack(
                fill="x")

        outer = boxed(self.top)
        outer.pack(fill="x", pady=(12, 0))
        bar = tk.Frame(outer, bg=WHITE)
        bar.pack(fill="x", padx=12, pady=(8, 4))
        bar2 = tk.Frame(outer, bg=WHITE)
        bar2.pack(fill="x", padx=12, pady=(2, 8))
        self.search = tk.StringVar()
        self.f_period = tk.StringVar(value=PERIOD_SEASON)
        self.f_from, self.f_to = tk.StringVar(), tk.StringVar()
        self.f_kind = tk.StringVar(value=ALL)
        self.f_group = tk.StringVar(value=ALL)
        izskats.search_box(bar, self.search, width=22).pack(side="left", padx=(0, 14))
        self.search.trace_add("write", lambda *a: self.refresh())

        def caption(parent, text, first=False):
            tk.Label(parent, text=text, bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(
                side="left", padx=(0 if first else 12, 4))
        caption(bar, "PERIODS", True)
        pcb = ttk.Combobox(bar, textvariable=self.f_period, values=PERIODS, state="readonly", width=17)
        pcb.pack(side="left", padx=(0, 6))
        pcb.bind("<<ComboboxSelected>>", lambda e: self.apply_period_preset())
        tk.Label(bar, text="no", bg=WHITE, fg=NAVY).pack(side="left")
        e_from = ttk.Entry(bar, textvariable=self.f_from, width=11)
        e_from.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_from, on_pick=self.custom_period).pack(side="left", padx=(1, 4))
        tk.Label(bar, text="līdz", bg=WHITE, fg=NAVY).pack(side="left")
        e_to = ttk.Entry(bar, textvariable=self.f_to, width=11)
        e_to.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_to, on_pick=self.custom_period).pack(side="left", padx=(1, 0))
        for e in (e_from, e_to):
            e.bind("<Return>", lambda ev: self.custom_period())
            e.bind("<FocusOut>", lambda ev: self.custom_period())
        ttk.Button(bar, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")
        caption(bar2, "VEIDS", True)
        kcb = ttk.Combobox(bar2, textvariable=self.f_kind, values=[ALL] + KINDS, state="readonly", width=18)
        kcb.pack(side="left")
        caption(bar2, "GRUPA")
        gcb = ttk.Combobox(bar2, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=8)
        gcb.pack(side="left")
        for cb in (kcb, gcb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        self.count_var = tk.StringVar()
        tk.Label(bar2, textvariable=self.count_var, bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="right")
        self._period_dates_text = ("", "")
        self.apply_period_preset(refresh=False)

        # tabs
        self.n_sessions, self.n_dancers, self.stat_rows, self.j_sessions = (0, 0), (0, 0), [], []
        self.all_stats = []
        self.nb = TabHost(self.root, hr.tabs, on_change=self.tab_changed)
        self.nb.pack(fill="both", expand=True, padx=20, pady=(12, 14))

        # 0) today: marking right here
        self.today = TodayView(self.nb, self)
        self.nb.add(self.today, "Šodien")
        self.view_widget = self.today   # Pūrlāde asks about unsaved marks before leaving the module
        self.current_view = TodayView

        # 1) sessions
        tab = tk.Frame(self.nb, bg=CREAM)
        self.nb.add(tab, "Notikumi")
        tools = white_bar(tab)
        self.delete_btn = ttk.Button(tools, text="🗑 Dzēst iezīmētos notikumus", style="Danger.TButton",
                                     command=self.delete_sessions)
        if acc.can_edit("citibas_purs"):
            self.delete_btn.pack(side="left")
        izskats.note(tools, "Dubultklikšķis — atvērt notikumu un atzīmes · Ctrl / Shift — iezīmēt vairākus · "
                            "Ctrl+A — visus", bg=WHITE).pack(side="right")
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.s_tree = ttk.Treeview(holder, columns=[c[0] for c in SESSION_COLUMNS], show="headings",
                                   selectmode="extended")
        for key, title, width in SESSION_COLUMNS:
            self.s_tree.heading(key, text=title, command=lambda k=key: self.sort_sessions(k))
            self.s_tree.column(key, width=width, minwidth=45, anchor="w", stretch=key in ("title", "dances"))
        zebra(self.s_tree)
        tag_colours(self.s_tree)
        self.s_tree.bind("<Double-1>", self.open_session)
        self.s_tree.bind("<Return>", self.open_session)
        self.s_tree.bind("<Delete>", lambda e: self.delete_sessions())
        self.s_tree.bind("<Control-a>", self.select_all_sessions)
        self.s_tree.bind("<Control-A>", self.select_all_sessions)
        self.s_tree.bind("<<TreeviewSelect>>", lambda e: self.update_count())
        make_tree_with_scroll(holder, self.s_tree)
        self.s_sort, self.s_desc = "date", True

        # 2) dancers
        tab = tk.Frame(self.nb, bg=CREAM)
        self.nb.add(tab, "Dejotāju cītība")
        top = white_bar(tab)
        self.show_inactive = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Rādīt arī dejotājus uz pauzes un izstājušos", variable=self.show_inactive,
                        style="White.TCheckbutton", command=self.refresh).pack(side="left")
        izskats.note(top, f"Apmeklējums = (ieradās + nokavēja) / atzīmētie notikumi · zaļš ≥ {GOOD_PCT} %, "
                          f"dzeltens {LOW_PCT}–{GOOD_PCT - 1} %, sarkans < {LOW_PCT} %", bg=WHITE).pack(side="right")
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.d_tree = ttk.Treeview(holder, columns=[c[0] for c in STAT_COLUMNS], show="headings")
        for key, title, width in STAT_COLUMNS:
            self.d_tree.heading(key, text=title, command=lambda k=key: self.sort_stats(k))
            self.d_tree.column(key, width=width, minwidth=45,
                               anchor="w" if key in ("first_name", "last_name", "status") else "center",
                               stretch=False)
        zebra(self.d_tree)
        tag_colours(self.d_tree)
        self.d_tree.bind("<Double-1>", self.open_dancer)
        self.d_tree.bind("<Return>", self.open_dancer)
        make_tree_with_scroll(holder, self.d_tree)
        self.d_sort, self.d_desc = "last_name", False

        # 3) journal (one month, dancers × sessions)
        tab = tk.Frame(self.nb, bg=CREAM)
        self.nb.add(tab, "Žurnāls")
        nav = white_bar(tab)
        ttk.Button(nav, text="◀", width=3, command=lambda: self.move_month(-1)).pack(side="left")
        self.month_lbl = tk.Label(nav, text="", font=("Georgia", 14, "bold"), bg=WHITE, fg=NAVY, width=15)
        self.month_lbl.pack(side="left", padx=6)
        ttk.Button(nav, text="▶", width=3, command=lambda: self.move_month(1)).pack(side="left")
        ttk.Button(nav, text="Šis mēnesis", command=self.this_month).pack(side="left", padx=(10, 0))
        legend = tk.Frame(nav, bg=WHITE)          # Pūrlāde v0.9.20: atzīmju krāsas
        legend.pack(side="right")
        for m, text in ((MARK_PRESENT, "ieradās"), (MARK_LATE, "nokavēja"), (MARK_EXCUSED, "attaisnoti nebija"),
                        (MARK_ABSENT, "neattaisnoti nebija")):
            bg, fg = MARK_LOOK[m]
            tk.Label(legend, text=MARK_SYMBOL[m], bg=bg, fg=fg, font=FONT_BOLD, width=3, highlightthickness=1,
                     highlightbackground=fg).pack(side="left", padx=(8, 3))
            tk.Label(legend, text=text, bg=WHITE, fg=NAVY, font=FONT_SMALL).pack(side="left")
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.j_grid = JournalGrid(holder, on_cell=self.journal_cell, on_name=lambda did: DancerHistory(self, did),
                                  on_head=lambda j: SessionWindow(self, self.j_sessions[j]))
        self.j_grid.pack(fill="both", expand=True)
        izskats.note(tab, "Dubultklikšķis uz šūnas maina atzīmi, uz vārda — dejotāja vēsture, uz datuma — notikums. "
                          "Stūrītis šūnā — ir piezīme (redzama, uzbraucot ar peli).", bg=CREAM).pack(
            side="bottom", anchor="w", pady=(4, 0), before=holder)
        self.j_sessions = []

        try:
            self.db.auto_app_marks()   # app answers → marks for events that have already started
        except Exception:
            log_error(traceback.format_exc())
        self.refresh()
        self.nb.select(0)
        if not getattr(self, "_auto_tick_on", False):   # one timer, even if the page is built again
            self._auto_tick_on = True
            self.root.after(30000, self.auto_tick)

    def tab_changed(self):
        tab = self.nb.select()
        if tab == 0:
            self.top.pack_forget()
            if getattr(self, "today", None) is not None and self.today.stale:
                self.today.load()
        elif not self.top.winfo_manager():
            self.top.pack(fill="x", padx=20, before=self.nb)
        if hasattr(self, "count_var"):
            self.update_count()

    # ---- filters ------------------------------------------------------------
    def apply_period_preset(self, refresh=True):
        name = self.f_period.get()
        if name == PERIOD_CUSTOM:
            return
        start, end = period_dates(name)
        self.f_from.set(show_date(start.isoformat()) if start else "")
        self.f_to.set(show_date(end.isoformat()) if end else "")
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        if refresh:
            self.refresh()

    def custom_period(self):
        if (self.f_from.get(), self.f_to.get()) == self._period_dates_text:
            return
        for var in (self.f_from, self.f_to):
            if parse_date(var.get()) is None:
                messagebox.showwarning("Periods", "Datumu raksta formā DD.MM.GGGG.", parent=self.root)
                var.set(self._period_dates_text[0 if var is self.f_from else 1])
                return
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        self.f_period.set(PERIOD_CUSTOM)
        self.refresh()

    def filters(self):
        """(start ISO, end ISO, kind or None) of the current filter."""
        start = parse_date(self.f_from.get()) or "0000-01-01"
        end = parse_date(self.f_to.get()) or "9999-12-31"
        kind = self.f_kind.get()
        return start, end, (None if kind == ALL else kind)

    def period_text(self):
        a, b = self.f_from.get().strip(), self.f_to.get().strip()
        if not a and not b:
            return PERIOD_ALL.lower()
        text = f"{a or '…'} – {b or '…'}"
        kind = self.f_kind.get()
        group = self.f_group.get() if hasattr(self, "f_group") else ALL
        return text + ("" if kind == ALL else f" ({kind.lower()})") + ("" if group == ALL else f", grupa {group}")

    def group_of_filter(self):
        g = self.f_group.get() if hasattr(self, "f_group") else ALL
        return None if g == ALL else g

    def clear_filters(self):
        self.search.set("")
        self.f_kind.set(ALL)
        self.f_group.set(ALL)
        self.f_period.set(PERIOD_SEASON)
        self.show_inactive.set(False)
        self.apply_period_preset()

    def show_main(self):
        """Module logo: back to the main view — this season, no filters, the tab Šodien."""
        self.clear_filters()
        self.nb.select(0)
        self.s_tree.selection_remove(self.s_tree.selection())
        self.s_tree.yview_moveto(0)

    # ---- data -------------------------------------------------------------
    def auto_tick(self):
        """Every minute while Cītības pūrs is open: put in the marks of events that have just started."""
        try:
            if not self.s_tree.winfo_exists():
                self._auto_tick_on = False
                return
        except tk.TclError:
            self._auto_tick_on = False
            return
        try:
            if self.db.auto_app_marks():
                self.refresh()
        except Exception:
            log_error(traceback.format_exc())
        self.root.after(30000, self.auto_tick)

    def refresh(self, select_session=None):
        start, end, kind = self.filters()
        where, params = " WHERE s.session_date BETWEEN ? AND ?", [start, end]
        if kind:
            where += " AND s.kind=?"
            params.append(kind)
        sessions = self.db.q("SELECT s.id, s.session_date, s.kind, s.title, s.start_time FROM attendance_sessions s"
                             + where, params)
        marks = self.db.q("SELECT a.session_id, a.dancer_id, a.mark, s.session_date, s.start_time "
                          "FROM attendance a JOIN attendance_sessions s ON s.id=a.session_id" + where, params)
        self.groups_of = self.db.session_groups()
        group = self.group_of_filter()
        if group:   # only the events of this group, and only its dancers' marks
            sessions = [x for x in sessions if in_event_groups(group, self.groups_of.get(x[0], ""))]
            ids = {x[0] for x in sessions}
            dgroups = self.db.dancer_groups()
            marks = [m for m in marks if m[0] in ids and in_event_groups(dgroups.get(m[1], ""), group)]
        self.fill_sessions(sessions, marks, self.db.session_dances(s[0] for s in sessions), select_session,
                           self.app_answer_counts([s[0] for s in sessions]))
        # statistics only from events that have already started (answers from the app are marked in advance)
        now = datetime.now()
        today, hm = now.date().isoformat(), now.strftime("%H:%M")
        held = [m for m in marks if m[3] < today or (m[3] == today and (m[4] or "") <= hm)]
        stats = self.fill_stats(sessions, held)
        self.all_stats = stats
        self.update_cards(sessions, held, stats)
        self.fill_journal()
        self.update_header()
        self.today.refresh()
        self.update_count()

    def update_header(self):
        """“Apmeklējuma uzskaite · sezonas cītība 86 %” (all groups, this season, events that have taken place)."""
        start, end = season_of(date.today())
        came, marked = self.db.q("SELECT COALESCE(SUM(CASE WHEN a.mark IN (?, ?) THEN 1 ELSE 0 END), 0), COUNT(*) "
                                 "FROM attendance a JOIN attendance_sessions s ON s.id = a.session_id "
                                 "WHERE s.session_date BETWEEN ? AND ?",
                                 CAME + (start.isoformat(), min(end, date.today()).isoformat()))[0]
        p = pct(came, marked)
        sub = self.header_right.subtitle
        if sub is not None:
            sub.configure(text="Apmeklējuma uzskaite" + (f" · sezonas cītība {p} %" if p is not None else "")
                               + f" · v{APP_VERSION}")

    def app_answer_counts(self, session_ids):
        """{session id: 'Nebūs 2 · Kavēs 1 · Būs ✓ 5'} — answers from the mobile app (event_participants)."""
        if not session_ids:
            return {}
        try:
            rows = self.db.q("SELECT session_id, answer, COUNT(*) FROM event_participants WHERE answer<>'' "
                             "AND session_id IN (" + ",".join("?" * len(session_ids)) + ") GROUP BY session_id, answer",
                             session_ids)
        except sqlite3.Error:
            return {}
        per = {}
        for sid, ans, n in rows:
            per.setdefault(sid, {})[ans] = n
        labels = [(APP_NO, "Nebūs"), (APP_LATE, "Kavēs"), (APP_MAYBE, "Varbūt"), (APP_YES, "Būs ✓")]
        return {sid: " · ".join(f"{text} {c[a]}" for a, text in labels if c.get(a)) for sid, c in per.items()}

    def fill_sessions(self, sessions, marks, dances, select=None, app_counts=None):
        app_counts = app_counts or {}
        per = {}
        for sid, _did, mark, _d, _t in marks:
            m, c = per.get(sid, (0, 0))
            per[sid] = (m + 1, c + (mark in CAME))
        term = _norm(self.search.get())
        now = datetime.now()
        today, hm = now.date().isoformat(), now.strftime("%H:%M")
        rows = []
        for sid, d, kind, title, tm in sessions:
            dance_text = ", ".join(dances.get(sid, []))
            if term and term not in _norm(f"{kind} {title} {show_date(d)} {dance_text}"):
                continue
            marked, came = per.get(sid, (0, 0))
            rows.append({"id": sid, "date": d, "weekday": weekday(d), "kind": kind or "", "title": title or "",
                         "dances": dance_text, "planned": d > today or (d == today and (tm or "") > hm),
                         "today": d == today,
                         "time": tm or "", "app": app_counts.get(sid, ""), "came": came, "marked": marked, "pct": pct(came, marked)})

        rows.sort(key=lambda r: (r["date"], r["time"], r["id"]), reverse=True)
        if self.s_sort == "date":
            rows.sort(key=lambda r: (r["date"], r["time"], r["id"]), reverse=self.s_desc)
        else:
            rows = sort_rows(rows, self.s_sort, self.s_desc)
        keep = select or (self.s_tree.selection()[0] if self.s_tree.selection() else None)
        self.s_tree.delete(*self.s_tree.get_children())
        for i, r in enumerate(rows):
            tags = ("planned",) if r["planned"] else (pct_tag(r["pct"]),)
            if r["today"]:
                tags += ("today",)
            elif i % 2:
                tags += ("odd",)
            self.s_tree.insert("", "end", iid=str(r["id"]), tags=tags, values=(
                show_date(r["date"]), r["weekday"], r["kind"], groups_short(self.groups_of.get(r["id"], "")),
                r["title"], r["dances"], r["time"], r["app"],
                "—" if r["planned"] else r["came"], r["marked"] or "—",
                PLANNED if r["planned"] else pct_text(r["pct"])))
        if keep is not None and self.s_tree.exists(str(keep)):
            self.s_tree.selection_set(str(keep))
            self.s_tree.see(str(keep))
        self.n_sessions = (len(rows), len(sessions))

    def fill_stats(self, sessions, marks):
        by_dancer = {}
        for _sid, did, mark, d, tm in marks:
            by_dancer.setdefault(did, []).append(((d, tm or ""), mark))
        show_all = self.show_inactive.get()
        dancers = self.db.q("SELECT id, first_name, last_name, status FROM dancers WHERE " + dancer_role_sql("dancers"))
        group = self.group_of_filter()
        if group:
            dgroups = self.db.dancer_groups()
            dancers = [r for r in dancers if in_event_groups(dgroups.get(r[0], ""), group)]
        stats, shown = [], []
        term = _norm(self.search.get())
        for did, first, last, status in dancers:
            status = status or STATUS_ACTIVE
            history = sorted(by_dancer.get(did, []))
            c = {m: 0 for m in MARKS}
            for _when, mark in history:
                c[mark] = c.get(mark, 0) + 1
            came = c[MARK_PRESENT] + c[MARK_LATE]
            last_seen = max((w[0] for w, m in history if m in CAME), default="")
            streak = 0
            for _when, mark in reversed(history):
                if mark in CAME:
                    break
                streak += 1
            r = {"id": did, "first_name": first or "", "last_name": last or "", "status": status,
                 "marked": len(history), "present": c[MARK_PRESENT], "late": c[MARK_LATE],
                 "excused": c[MARK_EXCUSED], "absent": c[MARK_ABSENT], "pct": pct(came, len(history)),
                 "last_seen": last_seen, "streak": streak}
            if status == STATUS_ACTIVE or history:
                stats.append(r)
            if status != STATUS_ACTIVE and not show_all:
                continue
            if term and term not in _norm(f"{first} {last}"):
                continue
            shown.append(r)

        shown.sort(key=lambda r: (_norm(r["last_name"]), _norm(r["first_name"])))
        shown = sort_rows(shown, self.d_sort, self.d_desc)
        keep = self.d_tree.selection()[0] if self.d_tree.selection() else None
        self.d_tree.delete(*self.d_tree.get_children())
        for i, r in enumerate(shown):
            self.d_tree.insert("", "end", iid=str(r["id"]), tags=(pct_tag(r["pct"]),) + (("odd",) if i % 2 else ()),
                               values=(
                r["first_name"], r["last_name"], r["status"], r["marked"], r["present"], r["late"], r["excused"],
                r["absent"], pct_text(r["pct"]), show_date(r["last_seen"]) or "—",
                r["streak"] if r["streak"] else "—"))
        if keep is not None and self.d_tree.exists(keep):
            self.d_tree.selection_set(keep)
        self.stat_rows = shown
        self.n_dancers = (len(shown), len(stats))
        return stats

    def update_cards(self, sessions, marks, stats):
        today = date.today().isoformat()
        came = sum(1 for m in marks if m[2] in CAME)
        held = sum(1 for s in sessions if s[1] <= today)
        planned = len(sessions) - held
        self.card_vars["sessions"].set(f"{held} (+{planned})" if planned else str(held))
        self.card_vars["average"].set(pct_text(pct(came, len(marks))))
        past = [s for s in sessions if s[1] <= today]
        last_text = "—"
        if past:
            last = max(past, key=lambda s: (s[1], s[4] or "", s[0]))
            marked = [m for m in marks if m[0] == last[0]]
            if marked:
                last_text = f"{sum(1 for m in marked if m[2] in CAME)} / {len(marked)}"
        self.card_vars["last"].set(last_text)
        active = [r for r in stats if r["status"] == STATUS_ACTIVE and r["pct"] is not None]
        self.card_vars["good"].set(str(sum(1 for r in active if r["pct"] >= GOOD_PCT)))
        self.card_vars["low"].set(str(sum(1 for r in active if r["pct"] < LOW_PCT)))

    def update_count(self):
        tab = self.nb.select() or 0
        if tab == 0:
            self.count_var.set("")
            return
        if tab == 1:
            chosen = len(self.s_tree.selection()) if hasattr(self, "s_tree") else 0
            text = (f"Rādīti {self.n_sessions[0]} no {self.n_sessions[1]} notikumiem"
                    + (f" · iezīmēti {chosen}" if chosen > 1 else ""))
        elif tab == 2:
            text = f"Rādīti {self.n_dancers[0]} dejotāji · dubultklikšķis — dejotāja apmeklējuma vēsture"
        else:
            text = f"Žurnālā {len(self.j_sessions)} notikumi šajā mēnesī"
        self.count_var.set(text)

    def sort_sessions(self, key):
        self.s_desc = not self.s_desc if key == self.s_sort else key in ("date", "pct", "came", "marked")
        self.s_sort = key
        self.refresh()

    def sort_stats(self, key):
        numeric = key in ("marked", "present", "late", "excused", "absent", "pct", "streak", "last_seen")
        self.d_desc = not self.d_desc if key == self.d_sort else numeric
        self.d_sort = key
        self.refresh()

    # ---- journal ------------------------------------------------------------
    def move_month(self, step):
        y, m = self.journal_month
        m += step
        y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
        self.journal_month = (y, m)
        self.fill_journal()
        self.update_count()

    def this_month(self):
        today = date.today()
        self.journal_month = (today.year, today.month)
        self.fill_journal()
        self.update_count()

    def fill_journal(self):
        y, m = self.journal_month
        self.month_lbl.configure(text=f"{MONTHS[m - 1]} {y}")
        start = f"{y:04d}-{m:02d}-01"
        end = f"{y:04d}-{m:02d}-{calendar.monthrange(y, m)[1]:02d}"
        _s, _e, kind = self.filters()
        sql, params = "SELECT id, session_date, kind FROM attendance_sessions WHERE session_date BETWEEN ? AND ?", \
            [start, end]
        if kind:
            sql += " AND kind=?"
            params.append(kind)
        sessions = self.db.q(sql + " ORDER BY session_date, start_time, id", params)
        group = self.group_of_filter()
        if group:
            sgroups = self.db.session_groups()
            sessions = [x for x in sessions if in_event_groups(group, sgroups.get(x[0], ""))]
        self.j_sessions = [s[0] for s in sessions]
        marks, notes = {}, {}
        if sessions:
            ids = self.j_sessions
            for sid, did, mark, note in self.db.q(
                    "SELECT session_id, dancer_id, mark, COALESCE(note, '') FROM attendance WHERE session_id IN ("
                    + ",".join("?" * len(ids)) + ")", ids):
                marks[(sid, did)] = mark
                notes[(sid, did)] = note
        dancers = self.db.dancers({did for _sid, did in marks})
        if group:
            dgroups = self.db.dancer_groups()
            dancers = [r for r in dancers if in_event_groups(dgroups.get(r[0], ""), group)]
        term = _norm(self.search.get())

        rows = []
        for did, first, last, _g, status in dancers:
            name = full_name(first, last)
            if term and term not in _norm(name):
                continue
            row = [marks.get((sid, did), "") for sid in self.j_sessions]
            p = pct(sum(1 for v in row if v in CAME), sum(1 for v in row if v))
            rows.append((did, name, row, [notes.get((sid, did), "") for sid in self.j_sessions], p))
        self.j_grid.set_data(sessions, rows)

    def journal_cell(self, did, idx):
        """Double click on a cell of the journal: the next mark (none → ✓ → N → A → ✗ → none)."""
        sid = self.j_sessions[idx]
        acc = piekluve.current()
        if not acc.edits_all("citibas_purs") and not acc.can_edit(
                "citibas_purs", groups=event_groups(self.db.session_groups([sid]).get(sid, ""))):
            return piekluve.deny(self.root, f"Atzīmes var mainīt tikai {acc.scope_text('citibas_purs')}s "
                                            "notikumos.")
        current = self.db.q("SELECT mark FROM attendance WHERE session_id=? AND dancer_id=?", (sid, did))
        current = current[0][0] if current else ""
        nxt = MARK_CYCLE[(MARK_CYCLE.index(current) + 1) % len(MARK_CYCLE)] if current in MARK_CYCLE else ""
        self.db.set_mark(sid, did, nxt)
        self.refresh()
        self.j_grid.select(did)

    # ---- actions ------------------------------------------------------------
    def open_session(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.s_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.s_tree.selection()
        if sel:
            SessionWindow(self, int(sel[0]))

    def select_all_sessions(self, event=None):
        self.s_tree.selection_set(self.s_tree.get_children())
        return "break"

    def delete_sessions(self):
        """Delete all events selected in the Notikumi list (with their marks, dances and app answers)."""
        if self.nb.select() != 1:
            self.nb.select(1)
        ids = [int(i) for i in self.s_tree.selection()]
        if not ids:
            messagebox.showinfo("Dzēst notikumus", "Cilnē “Notikumi” iezīmējiet notikumus, kurus dzēst.\n\n"
                                                   "Vairākus var iezīmēt, turot Ctrl vai Shift; visus — ar Ctrl+A.",
                                parent=self.root)
            return
        marks_sql = ",".join("?" * len(ids))
        acc = piekluve.current()
        if not acc.edits_all("citibas_purs"):
            groups = self.db.session_groups(ids)
            if not all(acc.can_edit("citibas_purs", groups=event_groups(groups.get(i, ""))) for i in ids):
                return piekluve.deny(self.root, f"Dzēst var tikai {acc.scope_text('citibas_purs')}s notikumus.")
        rows = self.db.q("SELECT id, session_date, kind, title FROM attendance_sessions WHERE id IN (" + marks_sql
                         + ") ORDER BY session_date, start_time, id", ids)
        marked = dict(self.db.q("SELECT session_id, COUNT(*) FROM attendance WHERE session_id IN (" + marks_sql
                                + ") GROUP BY session_id", ids))
        lines = [f"{show_date(d)} ({weekday(d)})  {kind}" + (f" — {title}" if title else "")
                 + (f"  · atzīmes: {marked[sid]}" if marked.get(sid) else "")
                 for sid, d, kind, title in rows]
        listed = "\n".join(lines[:15]) + (f"\n… un vēl {len(lines) - 15}" if len(lines) > 15 else "")
        with_marks = sum(1 for sid, *_ in rows if marked.get(sid))
        warn = (f"\n\n⚠ {with_marks} no tiem ir dejotāju apmeklējuma atzīmes — arī tās tiks dzēstas."
                if with_marks else "")
        if not messagebox.askyesno(
                "Dzēst notikumus", f"Dzēst {len(rows)} notikumus?\n\n{listed}{warn}\n\n"
                                   "Tiks dzēstas arī to dejas, programma un dejotāju atbildes lietotnē. "
                                   "To nevar atsaukt.", icon="warning", parent=self.root):
            return
        if len(rows) >= 10 and not messagebox.askyesno(
                "Dzēst notikumus", f"Vai tiešām dzēst visus {len(rows)} notikumus?", icon="warning",
                parent=self.root):
            return
        existing = {r[0] for r in self.db.q("SELECT name FROM sqlite_master WHERE type='table'")}
        con = self.db.con
        try:
            for table in ("attendance", "session_dances", "event_details", "event_program", "event_participants",
                          "app_answers"):
                if table in existing:
                    con.execute(f"DELETE FROM {table} WHERE session_id IN ({marks_sql})", ids)
            con.execute(f"DELETE FROM attendance_sessions WHERE id IN ({marks_sql})", ids)
            con.commit()
        except sqlite3.Error as exc:
            con.rollback()
            messagebox.showerror("Dzēst notikumus", f"Neizdevās dzēst notikumus:\n{exc}", parent=self.root)
            return
        self.refresh()
        messagebox.showinfo("Dzēst notikumus", f"Dzēsti {len(rows)} notikumi.", parent=self.root)

    def open_today(self):
        """Start page “▶ Šodienas mēģinājums”: the tab Šodien (marking today's event right here)."""
        self.nb.select(0)

    def open_dancer(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.d_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.d_tree.selection()
        if sel:
            DancerHistory(self, int(sel[0]))

    def export(self):
        if not self.stat_rows:
            messagebox.showinfo("Eksports", "Nav datu, ko eksportēt.", parent=self.root)
            return
        today = show_date(date.today().isoformat())
        path = filedialog.asksaveasfilename(parent=self.root, title="Saglabāt cītības pārskatu",
                                            defaultextension=".csv", initialfile=f"Cītība {today}.csv",
                                            filetypes=[("Excel / CSV", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as fh:
                w = csv.writer(fh, delimiter=";")
                w.writerow([f"{PROGRAM_NAME} — dejotāju cītība", f"Periods: {self.period_text()}",
                            f"Sagatavots: {today}"])
                w.writerow([])
                w.writerow([t for _k, t, _w in STAT_COLUMNS])
                for r in self.stat_rows:
                    w.writerow([r["first_name"], r["last_name"], r["status"], r["marked"], r["present"], r["late"],
                                r["excused"], r["absent"], "" if r["pct"] is None else r["pct"],
                                show_date(r["last_seen"]), r["streak"]])
        except OSError as exc:
            messagebox.showerror("Eksports", f"Neizdevās saglabāt failu:\n{exc}", parent=self.root)
            return
        messagebox.showinfo("Eksports", f"Pārskats saglabāts:\n{path}\n\nFailu var atvērt ar Excel.",
                            parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
