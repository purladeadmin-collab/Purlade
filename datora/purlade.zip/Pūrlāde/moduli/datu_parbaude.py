"""Pūrlāde v0.9.35 — Datu pārbaude un “Kad dejotājs izstājas”.

1) LeaveWindow — atveras Kopas pūrā, kad dejotāja statusu nomaina uz “Izstājies” (un no Datu pārbaudes):
   kas vēl jānokārto — izsniegtie tērpi (var uzreiz atzīmēt kā atdotus), deju sastāvi (var izņemt),
   uzliktās soda naudas un dalības maksas / tērpu fonda parāds šajā sezonā (no Zelta pūra; tikai, ja loma drīkst
   atvērt Zelta pūru). Ja nekā nav — logs neatveras.
2) DataCheckWindow — sānu joslā “Datu pārbaude”: viens saraksts ar to, kas trūkst vai neatbilst (pa grupām);
   dubultklikšķis atver vietu, kur to izlabot. Redzams tikai tas, ko loma drīkst atvērt.
"""
import sys
import sqlite3
import traceback
import tkinter as tk
from datetime import date
from tkinter import ttk, messagebox

try:
    from moduli import kopeja as K
    from moduli import izskats
    from moduli import piekluve
except ImportError:  # palaists no moduļu mapes
    import kopeja as K
    import izskats
    import piekluve

CREAM, WHITE, NAVY, RED, GOLD = izskats.CREAM, izskats.WHITE, izskats.NAVY, izskats.RED, izskats.GOLD
MUTED, LINE, FONT, FONT_BOLD, FONT_SMALL = izskats.MUTED, izskats.LINE, izskats.FONT, izskats.FONT_BOLD, \
    izskats.FONT_SMALL

ACTIVE_DANCE_STATUSES = ("Repertuārā", "Procesā")     # Deju pūrs: dejas, kuras dejo / iestudē
CANCELLED = "Atcelts"


# --------------------------------------------------------------------------
# small helpers (work with purlade.db and the online database)
# --------------------------------------------------------------------------
def has_table(con, name):
    try:
        return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())
    except Exception:
        return False


def columns(con, table):
    try:
        return {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
    except Exception:
        return set()


def show_date(iso):
    try:
        y, m, d = (iso or "")[:10].split("-")
        return f"{int(d):02d}.{int(m):02d}.{int(y):04d}"
    except ValueError:
        return ""


def money(cents):
    return f"{cents / 100:.2f} €".replace(".", ",")


def season_start(day=None):
    day = day or date.today()
    return date(day.year if day.month >= 9 else day.year - 1, 9, 1)


def is_dancer_role(role):
    return (role or "").strip() in ("", K.ROLE_DANCER)


def dancer_info(con, did):
    row = con.execute("SELECT first_name, last_name, name, COALESCE(dancer_group,''), COALESCE(status,''), "
                      "COALESCE(left_date,''), COALESCE(role,'') FROM dancers WHERE id=?", (did,)).fetchone()
    if not row:
        return None
    first, last, name, group, status, left, role = row
    return {"id": did, "name": K.full_name(first, last) or name or f"#{did}",
            "group": group.strip() or K.DEFAULT_DANCER_GROUP, "status": status, "left": left, "role": role}


# --------------------------------------------------------------------------
# What is still open for one dancer
# --------------------------------------------------------------------------
def open_costumes(con, did):
    """[(checkout id, inventory no., name / type, issued)] — costume pieces not given back."""
    if not has_table(con, "checkouts") or not has_table(con, "costume_pieces"):
        return []
    rows = con.execute("SELECT c.id, COALESCE(p.inv_no,''), COALESCE(p.name,''), COALESCE(c.checkout_date,'') "
                       "FROM checkouts c JOIN costume_pieces p ON p.id = c.piece_id WHERE c.dancer_id=? "
                       "AND (c.return_date IS NULL OR TRIM(c.return_date) = '') ORDER BY c.checkout_date",
                       (did,)).fetchall()
    return [tuple(r) for r in rows]


def open_casts(con, did):
    """[(dance id, title, status)] — dances in the repertoire / being learned that still have this dancer."""
    if not has_table(con, "dance_cast") or not has_table(con, "dances"):
        return []
    marks = ",".join("?" * len(ACTIVE_DANCE_STATUSES))
    rows = con.execute(f"SELECT d.id, d.title, COALESCE(d.status,'') FROM dance_cast c JOIN dances d "
                       f"ON d.id = c.dance_id WHERE c.dancer_id=? AND d.status IN ({marks}) ORDER BY d.title",
                       (did,) + ACTIVE_DANCE_STATUSES).fetchall()
    return [tuple(r) for r in rows]


def active_fines(con, did):
    """[(date, text, cents)] — fines with status “uzlikts” (Tērpu pūrs)."""
    if not has_table(con, "costume_fines"):
        return []
    fc = columns(con, "costume_fines")
    day = next((c for c in ("fine_date", "created_at", "created") if c in fc), None)
    text = next((c for c in ("rule_text", "description", "reason", "notes") if c in fc), None)
    cents = next((c for c in ("amount_cents", "cents") if c in fc), None)
    if cents is None:
        return []
    rows = con.execute(f"SELECT {('COALESCE(' + day + ',\'\')') if day else '\'\''}, "
                       f"{('COALESCE(' + text + ',\'\')') if text else '\'\''}, COALESCE({cents},0) "
                       "FROM costume_fines WHERE dancer_id=? AND status=?", (did, K.FINE_ACTIVE)).fetchall()
    return [(str(d)[:10], t, int(c or 0)) for d, t, c in rows]


def money_owed(con, did, until=None):
    """(fee debt, costume fund debt) in cents for this season up to `until` (ISO date, default today) — calculated
    as in Zelta pūrs. (None, None) when Zelta pūrs is not used or cannot be read."""
    if not has_table(con, "fin_entries") or not has_table(con, "fin_fee_rates"):
        return None, None
    try:
        try:
            from moduli import zelta_purs as Z
        except ImportError:
            import zelta_purs as Z
        db = Z.Database.__new__(Z.Database)     # only the reading methods — no tables are created
        db.con = con
        dancer = Z.Database.dancers(db).get(did)
        if dancer is None:
            return None, None
        entries = Z.Database.entries(db)
        last = min((until or date.today().isoformat())[:10], date.today().isoformat())
        season = Z.season_of(last[:7])
        rates, personal = Z.Database.fee_rates(db), Z.Database.personal_fees(db)
        paid = Z.fee_paid_by_month(entries).get(did, {})
        fee = 0
        for month in Z.due_months(dancer, season):
            if month > last[:7]:
                break
            fee += max(Z.fee_due(rates, personal, dancer, month) - paid.get(month, 0), 0)
        costume = 0
        if has_table(con, "fin_costume_rates"):
            crates = Z.Database.costume_rates(db)
            cpaid = Z.costume_paid(entries).get(did, {})
            for half in (1, 2):
                key = Z.half_key(season, half)
                if Z.half_deadline(key).isoformat() > last:
                    continue
                costume += max(Z.costume_due(crates, dancer, key) - cpaid.get(key, 0), 0)
        return fee, costume
    except Exception:
        K.log_error("Datu pārbaude — parāda aprēķins:\n" + traceback.format_exc())
        return None, None


def leave_summary(con, did, acc=None):
    """Everything still open for a dancer who leaves (only what the role may see)."""
    acc = acc or piekluve.current()
    info = dancer_info(con, did)
    out = {"info": info, "costumes": [], "casts": [], "fines": [], "fee": None, "costume_fund": None}
    if info is None:
        return out
    if acc.can_open("terpu_purs"):
        out["costumes"] = open_costumes(con, did)
        out["fines"] = active_fines(con, did)
    if acc.can_open("deju_purs"):
        out["casts"] = open_casts(con, did)
    if acc.can_open("zelta_purs"):
        out["fee"], out["costume_fund"] = money_owed(con, did, info["left"] or None)
    return out


def anything_open(s):
    return bool(s["costumes"] or s["casts"] or s["fines"] or (s["fee"] or 0) > 0 or (s["costume_fund"] or 0) > 0)


# --------------------------------------------------------------------------
# “Kad dejotājs izstājas”
# --------------------------------------------------------------------------
class LeaveWindow(tk.Toplevel):
    def __init__(self, root, did, on_change=None, summary=None):
        super().__init__(root)
        self.root_win, self.did, self.on_change = root, did, on_change
        self.con = K.connect_db()
        self.acc = piekluve.current()
        self.s = summary or leave_summary(self.con, did, self.acc)
        info = self.s["info"]
        self.title("Dejotājs izstājas")
        self.configure(bg=CREAM)
        self.transient(root)
        self.geometry("640x620")
        self.minsize(520, 420)
        left = f"izstājās {show_date(info['left'])}" if info["left"] else "izstāšanās datums nav ierakstīts"
        izskats.dialog_header(self, f"{info['name']} — kas vēl jānokārto",
                              f"{info['group']} grupa · {left}. Pārbaudiet tērpus, dejas un naudu.", wrap=580)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.close).pack(side="right")
        self.protocol("WM_DELETE_WINDOW", self.close)

        outer = tk.Frame(self, bg=CREAM)
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=CREAM, highlightthickness=0)
        bar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        self.body = tk.Frame(canvas, bg=CREAM, padx=18, pady=12)
        item = canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(item, width=e.width))
        self.build()

    def section(self, title, subtitle=""):
        box = tk.Frame(self.body, bg=WHITE, highlightthickness=1, highlightbackground=LINE, padx=14, pady=10)
        box.pack(fill="x", pady=(0, 10))
        tk.Label(box, text=title, bg=WHITE, fg=NAVY, font=("Georgia", 12, "bold"), anchor="w").pack(fill="x")
        if subtitle:
            tk.Label(box, text=subtitle, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w", justify="left",
                     wraplength=540).pack(fill="x", pady=(0, 6))
        return box

    def build(self):
        for w in self.body.winfo_children():
            w.destroy()
        s, info = self.s, self.s["info"]
        if not anything_open(s):
            tk.Label(self.body, text="✓ Viss nokārtots — izsniegtu tērpu, deju sastāvu un parādu nav.",
                     bg=CREAM, fg=izskats.GREEN, font=FONT_BOLD).pack(anchor="w", pady=10)
            return
        # costumes
        if s["costumes"]:
            may = self.acc.can_edit("terpu_purs", group=info["group"])
            box = self.section(f"Izsniegti tērpi ({len(s['costumes'])})",
                               "Atzīmējiet, kurus tērpus dejotājs ir atdevis." if may else
                               "Atdošanu var atzīmēt tērpu pārzinis (jūsu lomai — tikai skatīšanai).")
            self.costume_vars = []
            for cid, inv, name, issued in s["costumes"]:
                var = tk.BooleanVar(value=True)
                text = " · ".join(x for x in (inv, name) if x) + (f"   (izsniegts {show_date(issued)})"
                                                                   if issued else "")
                ttk.Checkbutton(box, text=text, variable=var, style="White.TCheckbutton",
                                state="normal" if may else "disabled").pack(anchor="w")
                self.costume_vars.append((cid, var))
            if may:
                row = tk.Frame(box, bg=WHITE)
                row.pack(fill="x", pady=(8, 0))
                tk.Label(row, text="Atdošanas datums:", bg=WHITE, fg=NAVY, font=FONT).pack(side="left")
                self.return_day = tk.StringVar(value=show_date(min(info["left"] or date.today().isoformat(),
                                                                   date.today().isoformat())))
                ttk.Entry(row, textvariable=self.return_day, width=12).pack(side="left", padx=6)
                ttk.Button(row, text="✓ Atzīmēt kā atdotus", style="Accent.TButton",
                           command=self.return_costumes).pack(side="left", padx=(6, 0))
        # dances
        if s["casts"]:
            may = self.acc.can_edit("deju_purs", group=info["group"])
            box = self.section(f"Deju sastāvos ({len(s['casts'])})",
                               "Izņemot no sastāva, dejai jāatrod aizvietotājs (Deju pūrs → Sastāvs)." if may else
                               "Sastāvus maina Deju pūrā (jūsu lomai — tikai skatīšanai).")
            for _id, title, status in s["casts"]:
                tk.Label(box, text=f"• {title}  ({status.lower()})", bg=WHITE, fg=NAVY, font=FONT,
                         anchor="w").pack(fill="x")
            if may:
                ttk.Button(box, text="Izņemt no šo deju sastāviem", style="Danger.TButton",
                           command=self.remove_casts).pack(anchor="w", pady=(8, 0))
        # money
        lines = []
        if (s["fee"] or 0) > 0:
            lines.append(f"Dalības maksa šajā sezonā nav samaksāta: {money(s['fee'])}")
        if (s["costume_fund"] or 0) > 0:
            lines.append(f"Tērpu fonds šajā sezonā nav samaksāts: {money(s['costume_fund'])}")
        for day, text, cents in s["fines"]:
            lines.append(f"Soda nauda {money(cents)}" + (f" — {text}" if text else "") +
                         (f" ({show_date(day)})" if day else ""))
        if lines:
            box = self.section("Nauda", "Aprēķināts tāpat kā Zelta pūrā (līdz izstāšanās dienai). Samaksu ieraksta "
                                        "Zelta pūrā, soda naudas — Tērpu pūrā.")
            for text in lines:
                tk.Label(box, text="• " + text, bg=WHITE, fg=RED, font=FONT, anchor="w", justify="left",
                         wraplength=540).pack(fill="x")

    def return_costumes(self):
        chosen = [cid for cid, var in self.costume_vars if var.get()]
        if not chosen:
            return messagebox.showinfo("Tērpi", "Nav atzīmēts neviens tērps.", parent=self)
        day = K.parse_date(self.return_day.get().strip())
        if not day:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formātā DD.MM.GGGG.", parent=self)
        if day > date.today().isoformat():
            return messagebox.showwarning("Datums", "Atdošanas datums nevar būt nākotnē.", parent=self)
        for cid in chosen:
            self.con.execute("UPDATE checkouts SET return_date=? WHERE id=? AND (return_date IS NULL OR "
                             "TRIM(return_date) = '')", (day, cid))
            # the piece is back in the store (as Tērpu pūrs does it — also where there are no triggers)
            self.con.execute("UPDATE costume_pieces SET status = CASE WHEN EXISTS (SELECT 1 FROM checkouts c "
                             "WHERE c.piece_id = costume_pieces.id AND (c.return_date IS NULL OR "
                             "TRIM(c.return_date) = '')) THEN 'Izsniegts' ELSE 'Noliktavā' END "
                             "WHERE id = (SELECT piece_id FROM checkouts WHERE id=?)", (cid,))
        self.con.commit()
        self.changed()

    def remove_casts(self):
        titles = ", ".join(t for _i, t, _s in self.s["casts"])
        if not messagebox.askyesno("Deju sastāvi", f"Izņemt {self.s['info']['name']} no šo deju sastāviem?\n\n"
                                                   f"{titles}", parent=self):
            return
        for dance_id, _t, _s in self.s["casts"]:
            self.con.execute("DELETE FROM dance_cast WHERE dance_id=? AND dancer_id=?", (dance_id, self.did))
        self.con.commit()
        self.changed()

    def changed(self):
        self.s = leave_summary(self.con, self.did, self.acc)
        self.build()
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                K.log_error(traceback.format_exc())

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass
        self.destroy()


def offer_leave(root, did, on_change=None):
    """Kopas pūrs: a dancer has just been marked “Izstājies” — show what is still open (nothing open — nothing)."""
    try:
        con = K.connect_db()
        try:
            summary = leave_summary(con, did)
        finally:
            con.close()
        if anything_open(summary):
            return LeaveWindow(root, did, on_change=on_change)
    except Exception:
        K.log_error("Datu pārbaude — izstāšanās:\n" + traceback.format_exc())
    return None


# --------------------------------------------------------------------------
# Datu pārbaude
# --------------------------------------------------------------------------
def module_of(app):
    return sys.modules[type(app).__module__]


def open_dancer(did):
    return "kopas_purs", lambda m: module_of(m).DancerForm(m, did)


def collect(con, acc=None):
    """[(title, explanation, [(name, detail, action)])] — action: ("leave", did) or (module key, then(module app))."""
    acc = acc or piekluve.current()
    today = date.today().isoformat()
    out = []
    if not has_table(con, "dancers"):
        return out
    dc = columns(con, "dancers")
    left_sql = "COALESCE(left_date,'')" if "left_date" in dc else "''"
    people = con.execute(f"SELECT id, first_name, last_name, name, COALESCE(status,''), COALESCE(role,''), "
                         f"COALESCE(dancer_group,''), COALESCE(join_date,''), COALESCE(birth_date,''), "
                         f"COALESCE(height,''), COALESCE(clothing_size,''), {left_sql} FROM dancers").fetchall()
    people = [{"id": r[0], "name": K.full_name(r[1], r[2]) or r[3] or f"#{r[0]}", "status": r[4] or K.STATUS_ACTIVE,
               "dancer": is_dancer_role(r[5]), "group": (r[6] or "").strip() or K.DEFAULT_DANCER_GROUP,
               "join": r[7], "birth": r[8], "height": r[9], "size": r[10], "left": r[11]} for r in people]
    people.sort(key=lambda p: K._norm(p["name"]) if hasattr(K, "_norm") else p["name"].lower())
    left = [p for p in people if p["status"] == K.STATUS_LEFT]
    staying = [p for p in people if p["status"] != K.STATUS_LEFT]

    def add(title, explain, items):
        if items:
            out.append((title, explain, items))

    if acc.can_open("kopas_purs"):
        add("Izstājušies bez izstāšanās datuma", "Kolektīva vēsturē viņu aiziešana neparādās.",
            [(p["name"], f"{p['group']} grupa", open_dancer(p["id"])) for p in left if not p["left"]])
        add("Bez iestāšanās datuma", "Vajadzīgs stāžam, Kolektīva vēsturei un dalības maksām.",
            [(p["name"], f"{p['group']} grupa · {p['status'].lower()}", open_dancer(p["id"]))
             for p in staying if not p["join"]])
        add("Bez dzimšanas datuma", "Vajadzīgs vecumam un apsveikumiem.",
            [(p["name"], f"{p['group']} grupa", open_dancer(p["id"])) for p in staying if not p["birth"]])
        emails = K.app_emails(con) if hasattr(K, "app_emails") else {}
        add("Aktīvi dejotāji bez e-pasta Kabatas Pūrlādei", "Bez e-pasta nevar ielogoties lietotnē.",
            [(p["name"], f"{p['group']} grupa", open_dancer(p["id"])) for p in staying
             if p["dancer"] and p["status"] == K.STATUS_ACTIVE and not emails.get(p["id"])])
        add("Aktīvi dejotāji bez auguma vai apģērba izmēra", "Vajadzīgs, izvēloties tērpus.",
            [(p["name"], ", ".join(x for x, v in (("nav auguma", p["height"]), ("nav izmēra", p["size"])) if not v),
              open_dancer(p["id"])) for p in staying
             if p["dancer"] and p["status"] == K.STATUS_ACTIVE and not (p["height"] and p["size"])])

    # people who have left with things still open
    if acc.can_open("terpu_purs") or acc.can_open("deju_purs"):
        items = []
        for p in left:
            costumes = open_costumes(con, p["id"]) if acc.can_open("terpu_purs") else []
            casts = open_casts(con, p["id"]) if acc.can_open("deju_purs") else []
            if costumes or casts:
                parts = []
                if costumes:
                    parts.append(f"{len(costumes)} tērp{'s' if len(costumes) == 1 else 'i'} nav atdot"
                                 f"{'s' if len(costumes) == 1 else 'i'}")
                if casts:
                    parts.append(f"{len(casts)} dej{'as' if len(casts) == 1 else 'u'} sastāvā")
                items.append((p["name"], " · ".join(parts), ("leave", p["id"])))
        add("Izstājušies ar nenokārtotām lietām", "Dubultklikšķis — logs, kur tērpus atzīmēt kā atdotus un "
                                                 "izņemt no deju sastāviem.", items)

    if acc.can_open("deju_purs") and has_table(con, "dances") and has_table(con, "dance_cast"):
        marks = ",".join("?" * len(ACTIVE_DANCE_STATUSES))
        rows = con.execute(f"SELECT d.id, d.title, COALESCE(d.status,'') FROM dances d WHERE d.status IN ({marks}) "
                           "AND NOT EXISTS (SELECT 1 FROM dance_cast c WHERE c.dance_id = d.id) ORDER BY d.title",
                           ACTIVE_DANCE_STATUSES).fetchall()
        add("Dejas bez sastāva", "Repertuārā vai procesā, bet nav norādīts, kas tās dejo.",
            [(t, s.lower(), ("deju_purs", lambda m, i=i: module_of(m).CastWindow(m, i))) for i, t, s in rows])

    if acc.can_open("citibas_purs") and has_table(con, "attendance_sessions") and has_table(con, "attendance"):
        start = season_start().isoformat()
        cancelled = ""
        params = [start, today]
        if has_table(con, "event_details") and "status" in columns(con, "event_details"):
            cancelled = ("AND NOT EXISTS (SELECT 1 FROM event_details e WHERE e.session_id = s.id "
                         "AND e.status = ?) ")
            params.append(CANCELLED)
        rows = con.execute("SELECT s.id, s.session_date, COALESCE(s.kind,''), COALESCE(s.title,'') "
                           "FROM attendance_sessions s WHERE s.session_date >= ? AND s.session_date < ? "
                           + cancelled + "AND NOT EXISTS (SELECT 1 FROM attendance a WHERE a.session_id = s.id) "
                           "ORDER BY s.session_date DESC", params).fetchall()
        add("Notikušie notikumi bez apmeklējuma atzīmēm", "Šajā sezonā (līdz vakardienai); atceltie netiek rādīti.",
            [(f"{show_date(d)} · {k}", t, ("citibas_purs", lambda m, i=i: module_of(m).SessionWindow(m, i)))
             for i, d, k, t in rows])
    return out


class DataCheckWindow(tk.Toplevel):
    def __init__(self, root, open_in):
        super().__init__(root)
        self.root_win, self.open_in = root, open_in
        self.title("Datu pārbaude")
        self.configure(bg=CREAM)
        self.transient(root)
        self.geometry("900x700")
        self.minsize(700, 460)
        self.actions = {}
        self.head = izskats.dialog_header(
            self, "Datu pārbaude", "Kas trūkst vai neatbilst. Dubultklikšķis uz rindas atver vietu, kur to izlabot; "
                                   "pēc labošanas saraksts atjaunojas, atgriežoties šajā logā.", wrap=840)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.destroy).pack(side="right")
        ttk.Button(foot, text="↻ Atjaunot", command=self.refresh).pack(side="right", padx=(0, 8))
        self.summary = tk.Label(foot, text="", bg=WHITE, fg=MUTED, font=FONT_SMALL)
        self.summary.pack(side="left")

        holder = izskats.boxed(self)
        holder.pack(fill="both", expand=True, padx=18, pady=12)
        self.tree = ttk.Treeview(holder, columns=("detail",), show="tree headings")
        self.tree.heading("#0", text="Kas", anchor="w")
        self.tree.heading("detail", text="Sīkāk", anchor="w")
        self.tree.column("#0", width=420, stretch=True)
        self.tree.column("detail", width=340, stretch=True)
        self.tree.tag_configure("group", font=FONT_BOLD, background=izskats.CREAM_DARK)
        self.tree.tag_configure("explain", foreground=MUTED, font=FONT_SMALL)
        self.tree.tag_configure("ok", foreground=izskats.GREEN, font=FONT_BOLD)
        bar = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", self.activate)
        self.tree.bind("<Return>", self.activate)
        self._busy = False
        self.bind("<FocusIn>", self.focus_back)
        self.refresh()

    def refresh(self):
        open_ids = {self.tree.item(i, "text") for i in self.tree.get_children() if self.tree.item(i, "open")}
        first = not self.tree.get_children()
        self.tree.delete(*self.tree.get_children())
        self.actions = {}
        try:
            con = K.connect_db()
            try:
                groups = collect(con)
            finally:
                con.close()
        except Exception:
            K.log_error("Datu pārbaude:\n" + traceback.format_exc())
            groups = []
            self.tree.insert("", "end", text="Datus neizdevās nolasīt — sīkāk kludas.log", tags=("group",))
        total = 0
        for title, explain, items in groups:
            total += len(items)
            parent = self.tree.insert("", "end", text=f"{title} ({len(items)})", values=(explain,),
                                      tags=("group",), open=first or f"{title} ({len(items)})" in open_ids)
            for name, detail, action in items:
                iid = self.tree.insert(parent, "end", text="   " + name, values=(detail,))
                self.actions[iid] = action
        if not groups:
            self.tree.insert("", "end", text="✓ Viss kārtībā — nekas netrūkst", tags=("ok",))
        self.summary.configure(text=f"Atrastas {total} lietas {len(groups)} grupās" if total else "")

    def focus_back(self, event):
        if event.widget is self and not self._busy:
            self._busy = True
            self.after(250, self._refresh_soon)

    def _refresh_soon(self):
        self._busy = False
        if self.winfo_exists():
            self.refresh()

    def activate(self, _event=None):
        sel = self.tree.focus()
        action = self.actions.get(sel)
        if action is None:
            if sel:
                self.tree.item(sel, open=not self.tree.item(sel, "open"))
            return
        if action[0] == "leave":
            return LeaveWindow(self, action[1], on_change=self.refresh)
        key, then = action
        self.open_in(key, then)


def show(root, open_in):
    for win in root.winfo_children():
        if isinstance(win, DataCheckWindow):
            win.deiconify()
            win.lift()
            win.refresh()
            return win
    return DataCheckWindow(root, open_in)
