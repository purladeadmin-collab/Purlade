"""
Pūrlāde — datubāzes iestatījumu logs (Administrēšana → “Datubāze…”, un pie startēšanas, ja
tiešsaistes datubāze nav sasniedzama vai datorā vēl nav nevienas datubāzes)

* pieslēgšanās tiešsaistes datubāzei ar savu e-pastu un kodu (EmailConnect) — adrese un parole nav jāzina;
* tiešsaistes datubāzes (Supabase) savienojuma ievadīšana un pārbaude (administratoram);
* pārslēgšanās starp tiešsaistes datubāzi un lokālo purlade.db;
* datu pārnešana purlade.db → tiešsaistes datubāze (purlade.db netiek mainīts — paliek kā rezerves kopija).
"""

import json
import os
import queue
import sqlite3
import threading
import urllib.error
import urllib.request
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from moduli import datubaze
    from moduli.kopeja import DB_PATH, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, log_error
except ImportError:
    import datubaze
    from kopeja import DB_PATH, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, log_error

HELP_TEXT = (
    "Supabase: atveriet savu projektu → poga “Connect” → “Session pooler” un nokopējiet adresi, "
    "kas sākas ar postgresql://postgres.… (ports 5432). Paroli ievadiet atsevišķi — tā ir datubāzes "
    "parole, ko norādījāt, veidojot projektu.")
SECURITY_TEXT = (
    "Savienojuma dati tiek glabāti tikai šajā datorā (mapē {dir}); parole ir šifrēta ar šī datora Windows "
    "lietotāja kontu. Kamēr Pūrlādē nav pieteikšanās ar lietotājvārdu, ikviens, kurš var lietot šo datoru, "
    "var redzēt un mainīt kolektīva datus — ievadiet savienojumu tikai uzticamos datoros.")


def local_has_data():
    if not os.path.exists(DB_PATH):
        return False
    try:
        con = sqlite3.connect(DB_PATH)
        try:
            total = 0
            for table in ("dancers", "costume_pieces", "dances", "attendance_sessions"):
                if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                    total += con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            return total > 0
        finally:
            con.close()
    except sqlite3.Error:
        return False


class Worker:
    """Runs a slow function (network) in a thread and calls `done(result, error)` in the Tk thread."""

    def __init__(self, widget, fn, done, progress=None):
        self.q = queue.Queue()
        self.widget, self.done, self.progress = widget, done, progress

        def run():
            try:
                result = fn(lambda text: self.q.put(("progress", text)))
                self.q.put(("done", (result, None)))
            except Exception as exc:  # shown to the user
                self.q.put(("done", (None, exc)))

        threading.Thread(target=run, daemon=True).start()
        self.poll()

    def poll(self):
        try:
            while True:
                kind, value = self.q.get_nowait()
                if kind == "progress":
                    if self.progress:
                        self.progress(value)
                else:
                    self.done(*value)
                    return
        except queue.Empty:
            pass
        try:
            self.widget.after(100, self.poll)
        except tk.TclError:
            pass


class DatabaseWindow(tk.Toplevel):
    def __init__(self, parent, on_change=None, startup_message=None):
        super().__init__(parent)
        self.on_change = on_change
        self.changed = False
        self.busy = False
        self.title("Datubāze")
        self.configure(bg=CREAM, padx=18, pady=14)
        self.resizable(False, False)
        if parent.winfo_viewable():      # a hidden main window (first start) would hide this one too
            self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self.close)
        cfg = datubaze.load_config()

        tk.Label(self, text="Datubāze", font=("Georgia", 16, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=3, sticky="w")
        self.mode_lbl = tk.Label(self, text="", font=("Segoe UI", 10, "bold"), bg=CREAM, fg=NAVY,
                                 justify="left", anchor="w")
        self.mode_lbl.grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))
        if startup_message:
            tk.Label(self, text=startup_message, bg=CREAM, fg=RED, font=("Segoe UI", 9, "bold"),
                     wraplength=560, justify="left").grid(row=2, column=0, columnspan=3, sticky="w", pady=(0, 8))

        box = tk.LabelFrame(self, text=" Tiešsaistes datubāze (kopīga visiem datoriem) ", bg=CREAM, fg=NAVY,
                            font=("Segoe UI", 10, "bold"), padx=12, pady=8)
        box.grid(row=3, column=0, columnspan=3, sticky="ew")
        tk.Label(box, text=HELP_TEXT, bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), wraplength=540,
                 justify="left").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        tk.Label(box, text="Savienojuma adrese:", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=3)
        self.uri = ttk.Entry(box, width=62)
        self.uri.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=3)
        tk.Label(box, text="Datubāzes parole:", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=3)
        self.password = ttk.Entry(box, width=30, show="•")
        self.password.grid(row=2, column=1, sticky="w", padx=(8, 0), pady=3)
        if cfg.get("host"):
            self.uri.insert(0, f"postgresql://{cfg.get('user', 'postgres')}@{cfg['host']}:{cfg.get('port', 5432)}/"
                               f"{cfg.get('database', 'postgres')}")
            self.password.insert(0, cfg.get("password", ""))
        self.status = tk.Label(box, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9), wraplength=540,
                               justify="left")
        self.status.grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 2))
        row = tk.Frame(box, bg=CREAM)
        row.grid(row=4, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.test_btn = ttk.Button(row, text="Pārbaudīt savienojumu", command=self.test)
        self.test_btn.pack(side="left")
        self.online_btn = ttk.Button(row, text="Lietot tiešsaistes datubāzi", style="Accent.TButton",
                                     command=self.use_online)
        self.online_btn.pack(side="left", padx=8)
        self.transfer_btn = ttk.Button(row, text="Pārnest datus no purlade.db…", command=self.transfer_again)
        self.transfer_btn.pack(side="left")

        local = tk.LabelFrame(self, text=" Lokālā datubāze (tikai šajā datorā) ", bg=CREAM, fg=NAVY,
                              font=("Segoe UI", 10, "bold"), padx=12, pady=8)
        local.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(10, 0))
        tk.Label(local, text=DB_PATH, bg=CREAM, fg=NAVY, font=("Segoe UI", 9)).pack(side="left")
        self.local_btn = ttk.Button(local, text="Lietot lokālo datubāzi", command=self.use_local)
        self.local_btn.pack(side="right")

        tk.Label(self, text=SECURITY_TEXT.format(dir=datubaze.config_dir()), bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic"), wraplength=580, justify="left").grid(
            row=5, column=0, columnspan=3, sticky="w", pady=(10, 0))
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=580)
        self.progress.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        self.progress.grid_remove()
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=7, column=0, columnspan=3, sticky="e", pady=(10, 0))
        self.close_btn = ttk.Button(btns, text="Aizvērt", command=self.close)
        self.close_btn.pack(side="right")
        self.update_mode()
        self.grab_set()
        self.uri.focus_set()

    # -- helpers ---------------------------------------------------------------
    def update_mode(self):
        cfg = datubaze.online_config()
        if cfg:
            text = f"Šis dators lieto: TIEŠSAISTES datubāzi ({cfg.get('host')})"
        else:
            text = "Šis dators lieto: LOKĀLO datubāzi (purlade.db)"
        self.mode_lbl.configure(text=text)
        self.local_btn.configure(state="disabled" if not cfg else "normal")

    def say(self, text, colour=NAVY):
        self.status.configure(text=text, fg=colour)

    def set_busy(self, busy):
        self.busy = busy
        state = "disabled" if busy else "normal"
        for b in (self.test_btn, self.online_btn, self.transfer_btn, self.local_btn, self.close_btn):
            b.configure(state=state)
        if busy:
            self.progress.grid()
            self.progress.start(12)
        else:
            self.progress.stop()
            self.progress.grid_remove()
            self.update_mode()

    def read_form(self):
        try:
            cfg = datubaze.parse_connection_uri(self.uri.get())
        except ValueError as exc:
            messagebox.showwarning("Savienojums", str(exc), parent=self)
            return None
        if self.password.get():
            cfg["password"] = self.password.get()
        if not cfg.get("password"):
            messagebox.showwarning("Savienojums", "Ievadiet datubāzes paroli.", parent=self)
            return None
        cfg["mode"] = datubaze.MODE_ONLINE
        cfg["ssl_mode"] = "require"
        return cfg

    # -- actions -----------------------------------------------------------------
    def test(self, then=None):
        cfg = self.read_form()
        if cfg is None:
            return
        self.say("Savienojas…")
        self.set_busy(True)

        def done(result, error):
            self.set_busy(False)
            if error is not None:
                self.say(f"Neizdevās: {error}", RED)
                return
            ok, message, present, has_data = result
            if not ok:
                self.say("Neizdevās pieslēgties: " + message, RED)
                return
            extra = (" Datubāzē jau ir Pūrlādes dati." if has_data else
                     " Datubāze vēl ir tukša." if present else " Pūrlādes tabulas vēl nav izveidotas.")
            self.say(message + extra, GREEN)
            if then:
                then(cfg, has_data)

        Worker(self, lambda _p: datubaze.test_connection(cfg), done)

    def use_online(self):
        self.test(then=self._switch_online)

    def _switch_online(self, cfg, online_has_data):
        if not online_has_data and local_has_data():
            answer = messagebox.askyesnocancel(
                "Datu pārnešana",
                "Tiešsaistes datubāze ir tukša. Vai pārnest uz to visus šī datora datus no purlade.db?\n\n"
                "• Jā — dati tiek nokopēti (purlade.db netiek mainīts un paliek kā rezerves kopija).\n"
                "• Nē — sākt ar tukšu tiešsaistes datubāzi.", parent=self)
            if answer is None:
                return
            if answer:
                self.run_transfer(cfg, replace=False, then_switch=True)
                return
        self.finish_switch(cfg)

    def finish_switch(self, cfg):
        datubaze.close_shared()
        datubaze.save_config(cfg)
        try:
            datubaze.shared_connection()   # creates the online tables when they are not there yet
        except sqlite3.Error as exc:
            self.say(f"Iestatījumi saglabāti, bet savienojums neizdevās: {exc}", RED)
        self.changed = True
        self.update_mode()
        messagebox.showinfo("Datubāze", "Šis dators tagad lieto tiešsaistes datubāzi.", parent=self)

    def transfer_again(self):
        cfg = self.read_form()
        if cfg is None:
            return
        if not os.path.exists(DB_PATH):
            messagebox.showinfo("Pārnešana", "Šajā datorā nav faila purlade.db.", parent=self)
            return

        def check_done(result, error):
            self.set_busy(False)
            if error is not None or not result[0]:
                self.say(f"Neizdevās pieslēgties: {error or result[1]}", RED)
                return
            has_data = result[3]
            if has_data:
                if not messagebox.askyesno(
                        "Aizstāt tiešsaistes datus?",
                        "Tiešsaistes datubāzē JAU IR dati. Ja turpināsiet, VISI tiešsaistes dati tiks dzēsti un "
                        "aizstāti ar šī datora purlade.db datiem (arī tas, ko citi datori ir ievadījuši).\n\n"
                        "Turpināt?", icon="warning", parent=self):
                    return
                if not messagebox.askyesno("Vēlreiz apstipriniet",
                                           "Tiešām dzēst tiešsaistes datus un aizstāt tos ar purlade.db?",
                                           icon="warning", parent=self):
                    return
            self.run_transfer(cfg, replace=has_data, then_switch=False)

        self.say("Savienojas…")
        self.set_busy(True)
        Worker(self, lambda _p: datubaze.test_connection(cfg), check_done)

    def run_transfer(self, cfg, replace, then_switch):
        self.set_busy(True)
        datubaze.close_shared()

        def done(result, error):
            self.set_busy(False)
            if error is not None:
                log_error(f"Datu pārnešana neizdevās: {error!r}")
                self.say(f"Pārnešana neizdevās — tiešsaistes datubāzē nekas netika mainīts.\n{error}", RED)
                return
            counts, check = result
            bad = [(t, a, b) for t, a, b in check if a != b]
            total = sum(a for _t, a, _b in check)
            if bad:
                self.say("Pārnests, bet skaits nesakrīt: " + ", ".join(f"{t} {a}/{b}" for t, a, b in bad), RED)
                return
            self.say(f"Pārnesti {total} ieraksti no {len(check)} tabulām; skaits pārbaudīts — viss sakrīt.", GREEN)
            if then_switch:
                self.finish_switch(cfg)
            else:
                self.changed = True

        Worker(self, lambda p: datubaze.transfer_from_sqlite(DB_PATH, cfg, progress=p, replace=replace), done,
               progress=lambda text: self.say(text))

    def use_local(self):
        if not messagebox.askyesno(
                "Lokālā datubāze",
                "Pārslēgties uz lokālo datubāzi purlade.db?\n\nTiešsaistes datubāzē ievadītie dati purlade.db "
                "NEPARĀDĪSIES — šis dators strādās atsevišķi no pārējiem.", parent=self):
            return
        cfg = datubaze.load_config()
        cfg["mode"] = datubaze.MODE_LOCAL
        datubaze.close_shared()
        datubaze.save_config(cfg)
        self.changed = True
        self.update_mode()

    def close(self):
        if self.busy:
            return
        self.destroy()
        if self.changed and self.on_change:
            self.on_change()


def open_window(parent, on_change=None, startup_message=None):
    win = DatabaseWindow(parent, on_change=on_change, startup_message=startup_message)
    parent.wait_window(win)
    return win.changed


# --------------------------------------------------------------------------
# Pieslēgšanās ar e-pastu un kodu (Kabatas Pūrlādes serveris izsniedz savienojumu)
# --------------------------------------------------------------------------
SERVER_TIMEOUT = 90   # the free cloud server may need up to a minute to wake up


def server_url():
    try:
        from moduli import atjauninasana
    except ImportError:
        import atjauninasana
    return atjauninasana.server_url()


def server_post(path, data):
    """POST JSON to the Kabatas Pūrlāde server; returns the answer or raises ValueError with a readable text."""
    req = urllib.request.Request(server_url() + path, data=json.dumps(data).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": "Purlade-dators"})
    try:
        with urllib.request.urlopen(req, timeout=SERVER_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as exc:
        try:
            text = json.loads(exc.read().decode("utf-8")).get("kluda")
        except Exception:
            text = None
        raise ValueError(text or f"Serveris atbildēja ar kļūdu {exc.code}.")
    except (urllib.error.URLError, OSError) as exc:
        raise ValueError("Neizdevās sazināties ar Pūrlādes serveri. Pārbaudiet interneta savienojumu un "
                         f"mēģiniet vēlreiz.\n({getattr(exc, 'reason', exc)})")


class EmailConnect(tk.Toplevel):
    """Connect this computer to the collective's online database with one's own e-mail (the one entered in
    Kopas pūrs) and a code sent to it. Allowed for everyone who may use the desktop Pūrlāde."""

    def __init__(self, parent, startup_message=None, first_start=False):
        super().__init__(parent)
        self.parent = parent
        self.connected = False
        self.advanced = False
        self.local = False          # first start: “strādāt bez ielogošanās” (new database on this computer)
        self.busy = False
        self.first_start = first_start
        self.title("Pūrlāde — ielogoties" if first_start else "Pieslēgties tiešsaistes datubāzei")
        self.configure(bg=CREAM, padx=20, pady=16)
        self.resizable(False, False)
        if parent.winfo_viewable():
            self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self.close)

        heading = "Laipni lūdzam Pūrlādē!" if first_start else "Pieslēgties kolektīva datubāzei"
        tk.Label(self, text=heading, font=("Georgia", 16, "bold"), bg=CREAM,
                 fg=RED).grid(row=0, column=0, columnspan=3, sticky="w")
        if startup_message:
            tk.Label(self, text=startup_message, bg=CREAM, fg=RED, font=("Segoe UI", 9, "bold"), wraplength=480,
                     justify="left").grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))
        intro = ("Ielogojieties ar savu e-pastu — to pašu, ar kuru piesakāties Kabatas Pūrlādē (norādīts Kopas "
                 "pūrā). Uz to atnāks kods, un Pūrlāde atvērs jūsu kolektīva datus." if first_start else
                 "Ierakstiet savu e-pastu — to pašu, kas norādīts Kopas pūrā (ar to piesakāties arī "
                 "Kabatas Pūrlādē). Uz to atnāks kods, un Pūrlāde pieslēgsies pati.")
        tk.Label(self, text=intro, bg=CREAM, fg=NAVY, wraplength=480, justify="left").grid(
            row=2, column=0, columnspan=3, sticky="w", pady=(8, 10))
        tk.Label(self, text="E-pasts:", bg=CREAM, fg=NAVY).grid(row=3, column=0, sticky="w", pady=4)
        self.email = ttk.Entry(self, width=34)
        self.email.grid(row=3, column=1, sticky="w", padx=(8, 0), pady=4)
        self.send_btn = ttk.Button(self, text="Sūtīt kodu", command=self.send_code)
        self.send_btn.grid(row=3, column=2, sticky="w", padx=(8, 0), pady=4)
        tk.Label(self, text="Kods no e-pasta:", bg=CREAM, fg=NAVY).grid(row=4, column=0, sticky="w", pady=4)
        self.code = ttk.Entry(self, width=12, state="disabled")
        self.code.grid(row=4, column=1, sticky="w", padx=(8, 0), pady=4)
        self.connect_btn = ttk.Button(self, text="Ielogoties" if first_start else "Pieslēgties",
                                      style="Accent.TButton", command=self.connect, state="disabled")
        self.connect_btn.grid(row=4, column=2, sticky="w", padx=(8, 0), pady=4)
        self.status = tk.Label(self, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9), wraplength=480,
                               justify="left")
        self.status.grid(row=5, column=0, columnspan=3, sticky="w", pady=(8, 2))
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=480)
        self.progress.grid(row=6, column=0, columnspan=3, sticky="w")
        self.progress.grid_remove()
        foot = tk.Frame(self, bg=CREAM)
        foot.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(12, 0))
        links = tk.Frame(foot, bg=CREAM)
        links.pack(side="left", anchor="w")
        if first_start:
            loc = tk.Label(links, text="Strādāt bez ielogošanās — jauna datubāze tikai šajā datorā", bg=CREAM,
                           fg=NAVY, font=("Segoe UI", 8, "underline"), cursor="hand2")
            loc.pack(anchor="w")
            loc.bind("<Button-1>", lambda e: self.use_local())
        adv = tk.Label(links, text="Sistēmas administratoram: ievadīt datubāzes adresi un paroli…", bg=CREAM,
                       fg=NAVY, font=("Segoe UI", 8, "underline"), cursor="hand2")
        adv.pack(anchor="w")
        adv.bind("<Button-1>", lambda e: self.open_advanced())
        self.close_btn = ttk.Button(foot, text="Iziet" if first_start else "Atcelt", command=self.close)
        self.close_btn.pack(side="right", anchor="s")
        self.email.bind("<Return>", lambda e: self.send_code())
        self.code.bind("<Return>", lambda e: self.connect())
        if first_start:   # the main window is hidden: centre this one on the screen and bring it to the front
            self.update_idletasks()
            x = (self.winfo_screenwidth() - self.winfo_reqwidth()) // 2
            y = (self.winfo_screenheight() - self.winfo_reqheight()) // 3
            self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
            self.lift()
            self.attributes("-topmost", True)
            self.after(300, lambda: self.attributes("-topmost", False))
            self.focus_force()
        self.email.focus_set()
        self.grab_set()

    def say(self, text, colour=NAVY):
        self.status.configure(text=text, fg=colour)

    def set_busy(self, busy):
        self.busy = busy
        for b in (self.send_btn, self.close_btn):
            b.configure(state="disabled" if busy else "normal")
        self.connect_btn.configure(state="disabled" if busy or str(self.code["state"]) == "disabled" else "normal")
        if busy:
            self.progress.grid()
            self.progress.start(12)
        else:
            self.progress.stop()
            self.progress.grid_remove()

    def send_code(self):
        if self.busy:
            return
        email = self.email.get().strip().lower()
        if "@" not in email or "." not in email.split("@")[-1]:
            messagebox.showwarning("E-pasts", "Ierakstiet derīgu e-pasta adresi.", parent=self)
            return
        self.say("Sūta kodu… (pirmajā reizē serveris var mosties līdz minūtei)")
        self.set_busy(True)

        def done(_result, error):
            self.set_busy(False)
            if error is not None:
                self.say(str(error), RED)
                return
            self.code.configure(state="normal")
            self.connect_btn.configure(state="normal")
            self.code.focus_set()
            self.say(f"Ja e-pasts {email} ir Kopas pūrā, uz to tikko nosūtīts kods (derīgs dažas minūtes). "
                     "Ja vēstule neatnāk, pārbaudiet arī mēstuļu (spam) mapi.", GREEN)

        Worker(self, lambda _p: server_post("/api/pieteikties", {"email": email, "purpose": "dators"}), done)

    def connect(self):
        if self.busy or str(self.code["state"]) == "disabled":
            return
        email, code = self.email.get().strip().lower(), self.code.get().strip()
        if not code:
            messagebox.showwarning("Kods", "Ierakstiet kodu no e-pasta.", parent=self)
            return
        self.say("Pārbauda kodu un pieslēdzas datubāzei…")
        self.set_busy(True)

        def work(_p):
            answer = server_post("/api/dators/pieslegties", {"email": email, "code": code})
            cfg = dict(answer.get("database") or {})
            if not cfg.get("host"):
                raise ValueError("Serveris neatsūtīja savienojuma datus.")
            cfg["mode"] = datubaze.MODE_ONLINE
            cfg["connected_by"] = email
            ok, message, _present, _has_data = datubaze.test_connection(cfg)
            if not ok:
                raise ValueError("Neizdevās pieslēgties datubāzei: " + message)
            return cfg, answer

        def done(result, error):
            self.set_busy(False)
            if error is not None:
                self.say(str(error), RED)
                return
            cfg, answer = result
            datubaze.close_shared()
            datubaze.save_config(cfg)
            try:
                datubaze.shared_connection()
            except sqlite3.Error as exc:
                self.say(f"Iestatījumi saglabāti, bet savienojums neizdevās: {exc}", RED)
                return
            self.connected = True
            who = f", {answer['name']}" if answer.get("name") else ""
            messagebox.showinfo("Pieslēgts", f"Sveiki{who}! Šis dators tagad lieto kolektīva "
                                             f"“{answer.get('group') or 'Pūrlāde'}” tiešsaistes datubāzi.", parent=self)
            self.destroy()

        Worker(self, work, done)

    def open_advanced(self):
        if self.busy:
            return
        self.advanced = True
        self.destroy()

    def use_local(self):
        if self.busy:
            return
        if not messagebox.askyesno(
                "Strādāt bez ielogošanās",
                "Sākt ar jaunu, tukšu datubāzi tikai šajā datorā?\n\nKolektīva kopīgie dati šeit neparādīsies. "
                "Vēlāk var ielogoties (sākuma lapa → “Mainīt lietotāju” vai Administrēšana → “Datubāze…”), "
                "un tad šī datora datus var pārnest tiešsaistē.", parent=self):
            return
        self.local = True
        self.destroy()

    def close(self):
        if not self.busy:
            self.destroy()


def connect_with_email(parent, startup_message=None, on_change=None):
    """The normal way to connect: e-mail + code. The address / password window only for the administrator.
    Returns True when this computer now uses the online database."""
    win = EmailConnect(parent, startup_message=startup_message)
    parent.wait_window(win)
    if win.advanced:
        return open_window(parent, on_change=on_change, startup_message=startup_message)
    if win.connected and on_change:
        on_change()
    return win.connected


class StartupProblem(tk.Toplevel):
    """Shown at start when the online database cannot be reached."""

    def __init__(self, parent, error):
        super().__init__(parent)
        self.choice = "quit"
        self.title("Pūrlāde — datubāze nav sasniedzama")
        self.configure(bg=CREAM, padx=20, pady=16)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        tk.Label(self, text="Neizdevās pieslēgties tiešsaistes datubāzei", font=("Georgia", 14, "bold"),
                 bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text=("Pārbaudiet interneta savienojumu. Ja internets darbojas, iespējams, mainīta datubāzes "
                             "parole vai adrese — tad atveriet “Pieslēgties no jauna” un piesakieties ar savu e-pastu.\n\n" + str(error)),
                 bg=CREAM, fg=NAVY, wraplength=520, justify="left").pack(anchor="w", pady=(8, 12))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x")
        ttk.Button(btns, text="Iziet", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="Pieslēgties no jauna…", command=lambda: self.pick("settings")).pack(side="right", padx=6)
        ttk.Button(btns, text="Mēģināt vēlreiz", style="Accent.TButton",
                   command=lambda: self.pick("retry")).pack(side="right")
        self.grab_set()

    def pick(self, choice):
        self.choice = choice
        self.destroy()


class FirstStart(tk.Toplevel):
    """Shown on a computer that has neither connection settings nor purlade.db."""

    def __init__(self, parent):
        super().__init__(parent)
        self.choice = "local"
        self.title("Pūrlāde — pirmā palaišana")
        self.configure(bg=CREAM, padx=20, pady=16)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        tk.Label(self, text="Laipni lūdzam Pūrlādē!", font=("Georgia", 16, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text=("Šajā datorā vēl nav Pūrlādes datu. Ja kolektīvs jau lieto tiešsaistes datubāzi, "
                             "pieslēdzieties tai — tad redzēsiet tos pašus datus, ko citos datoros. Citādi "
                             "sāciet ar jaunu datubāzi tikai šajā datorā (to vēlāk var pārnest tiešsaistē)."),
                 bg=CREAM, fg=NAVY, wraplength=500, justify="left").pack(anchor="w", pady=(8, 12))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x")
        ttk.Button(btns, text="Jauna datubāze šajā datorā", command=lambda: self.pick("local")).pack(side="right")
        ttk.Button(btns, text="Pieslēgties tiešsaistes datubāzei…", style="Accent.TButton",
                   command=lambda: self.pick("online")).pack(side="right", padx=6)
        self.grab_set()

    def pick(self, choice):
        self.choice = choice
        self.destroy()


def startup_check(root):
    """Called before the start page is built. Returns False when Pūrlāde should quit."""
    from moduli import administresana
    administresana.setup_style()
    if not datubaze.config_exists() and not os.path.exists(DB_PATH) and not os.path.exists(
            os.path.join(os.path.dirname(DB_PATH), "costume_inventory.db")):
        # first start (e.g. right after the installer): log in with one's e-mail straight away
        root.withdraw()
        win = EmailConnect(root, first_start=True)
        root.wait_window(win)
        if win.advanced:
            open_window(root)
        elif win.local:
            cfg = datubaze.load_config()
            cfg["mode"] = datubaze.MODE_LOCAL
            datubaze.save_config(cfg)
        if not datubaze.config_exists():
            return False        # closed without logging in — next start asks again
        root.deiconify()
    while datubaze.is_online():
        try:
            datubaze.shared_connection()
            return True
        except sqlite3.Error as exc:
            log_error(f"Tiešsaistes datubāze nav sasniedzama: {exc}")
            root.withdraw()
            dlg = StartupProblem(root, exc)
            root.wait_window(dlg)
            if dlg.choice == "quit":
                return False
            if dlg.choice == "settings":
                connect_with_email(root, startup_message=str(exc))
            root.deiconify()
    return True
