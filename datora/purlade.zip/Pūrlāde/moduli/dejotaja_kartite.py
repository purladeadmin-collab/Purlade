"""Pūrlāde v0.9.36 — Dejotāja pilnā kartīte.

Viens logs ar visu par cilvēku no visiem moduļiem: personas dati, lomas un to vēsture, cītība pa sezonām un pēdējās
atzīmes, koncerti un skates, dejas, tērpi un soda naudas, dalības maksas un tērpu fonds (Zelta pūrs).
Katra daļa redzama tikai, ja loma drīkst atvērt attiecīgo moduli. “⎙ Drukāt / PDF” — HTML ar A4 stilu (kā Sezonas
pārskatam), atveras pārlūkā.
Atver: Kopas pūrs — sānu panelī “Pilnā kartīte”; Datu pārbaudē — dejotāja izvēlne.
"""
import os
import traceback
import webbrowser
import tkinter as tk
from datetime import date
from tkinter import ttk, messagebox, filedialog

try:
    from moduli import kopeja as K
    from moduli import izskats
    from moduli import piekluve
    from moduli import datu_parbaude as DP
except ImportError:  # palaists no moduļu mapes
    import kopeja as K
    import izskats
    import piekluve
    import datu_parbaude as DP

CREAM, WHITE, NAVY, RED, GOLD, GREEN = izskats.CREAM, izskats.WHITE, izskats.NAVY, izskats.RED, izskats.GOLD, \
    izskats.GREEN
MUTED, LINE, LINE_SOFT = izskats.MUTED, izskats.LINE, izskats.LINE_SOFT
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL

CAME = ("Ieradās", "Nokavēja")
MARKS = ("Ieradās", "Nokavēja", "Attaisnoti", "Neattaisnoti")
SHOW_KINDS = ("Koncerts", "Skate", "Kolektīva pasākums")
LOW_PCT = 70

show_date, money, has_table, columns = DP.show_date, DP.money, DP.has_table, DP.columns


def season_of(iso):
    y, m = int(iso[:4]), int(iso[5:7])
    return y if m >= 9 else y - 1


def season_label(start):
    return f"{start}/{start + 1}"


def years_text(n):
    if n is None:
        return ""
    return f"{n} gad{'s' if n % 10 == 1 and n % 100 != 11 else 'i'}"


def pct(came, marked):
    return round(100 * came / marked) if marked else None


# --------------------------------------------------------------------------
# The card as blocks (the same blocks as Sezonas pārskats: h / p / kv / table / bars)
# --------------------------------------------------------------------------
class Card:
    def __init__(self, con, did, acc=None):
        self.con, self.did = con, did
        self.acc = acc or piekluve.current()
        self.today = date.today().isoformat()
        self.blocks = []
        self.person = None

    def add(self, *block):
        self.blocks.append(block)

    def build(self):
        con, did = self.con, self.did
        dc = columns(con, "dancers")
        want = ["first_name", "last_name", "name", "gender", "birth_date", "join_date", "left_date", "status", "role",
                "app_roles", "dancer_group", "height", "clothing_size", "contact"]
        cols = [c for c in want if c in dc]
        row = con.execute(f"SELECT {', '.join(cols)} FROM dancers WHERE id=?", (did,)).fetchone()
        if not row:
            self.add("p", "Šis dejotājs vairs nav atrodams (iespējams, izdzēsts).")
            return self.blocks
        p = {c: (v if v is not None else "") for c, v in zip(cols, row)}
        for c in want:
            p.setdefault(c, "")
        p["full"] = K.full_name(p["first_name"], p["last_name"]) or p["name"] or f"#{did}"
        p["group"] = (p["dancer_group"] or "").strip() or K.DEFAULT_DANCER_GROUP
        p["status"] = p["status"] or K.STATUS_ACTIVE
        self.person = p
        sections = [("Personas dati", "kopas_purs", self.personal),
                    ("Lomas", "kopas_purs", self.roles),
                    ("Cītība", "citibas_purs", self.attendance),
                    ("Koncerti, skates un pasākumi", "citibas_purs", self.shows),
                    ("Dejas", "deju_purs", self.dances),
                    ("Tērpi", "terpu_purs", self.costumes),
                    ("Nauda", "zelta_purs", self.money)]
        for title, module, fn in sections:
            if not self.acc.can_open(module):
                continue
            start = len(self.blocks)
            self.add("h", title)
            try:
                if fn() is False:          # nothing to show in this section
                    del self.blocks[start:]
            except Exception as exc:
                K.log_error("Dejotāja kartīte:\n" + traceback.format_exc())
                self.add("p", f"Šo daļu neizdevās sagatavot: {exc}")
        return self.blocks

    # ---- Personas dati ------------------------------------------------------------
    def personal(self):
        p = self.person
        age = K.years_between(p["birth_date"]) if p["birth_date"] else None
        end = None
        if p["status"] == K.STATUS_LEFT and p["left_date"]:
            try:
                end = date.fromisoformat(p["left_date"])
            except ValueError:
                end = None
        tenure = K.years_between(p["join_date"], end) if p["join_date"] else None
        kv = [("Grupa", p["group"]), ("Statuss", p["status"]),
              ("Loma kolektīvā", p["role"] or K.ROLE_DANCER)]
        if p["birth_date"]:
            kv.append(("Dzimšanas datums", show_date(p["birth_date"]) + (f" ({years_text(age)})" if age is not None
                                                                         else "")))
        try:
            try:
                from moduli.vardadienas import name_day_text
            except ImportError:
                from vardadienas import name_day_text
            nd = name_day_text(p["first_name"] or "")
            if nd:
                kv.append(("Vārda diena", nd))
        except Exception:
            pass
        if p["join_date"]:
            kv.append(("Iestājās", show_date(p["join_date"]) + (f" (stāžs {years_text(tenure)})"
                                                                 if tenure is not None else "")))
        if p["status"] == K.STATUS_LEFT:
            kv.append(("Izstājās", show_date(p["left_date"]) or "datums nav zināms"))
        if p["height"] or p["clothing_size"]:
            kv.append(("Augums · izmērs", " · ".join(x for x in (f"{p['height']} cm" if p["height"] else "",
                                                                  p["clothing_size"]) if x)))
        email = K.app_email(self.con, self.did) if hasattr(K, "app_email") else ""
        kv.append(("Kabatas Pūrlāde", email or "nav e-pasta — nevar ielogoties"))
        self.add("kv", kv)
        if p["contact"].strip():
            self.add("p", "Kontakti: " + " · ".join(x.strip() for x in p["contact"].splitlines() if x.strip()))

    # ---- Lomas ---------------------------------------------------------------------
    def roles(self):
        p = self.person
        extra = [r.strip() for r in (p["app_roles"] or "").split(",") if r.strip()]
        if not DP.is_dancer_role(p["role"]):
            extra = [p["role"]] + extra          # Vadītājs / Repetitors
        now = ", ".join(extra) or "Dejotājs (papildu lomu nav)"
        self.add("kv", [("Lomas Pūrlādē tagad", now)])
        if not has_table(self.con, "role_history"):
            return
        rows = self.con.execute("SELECT role, COALESCE(start_date,''), COALESCE(end_date,''), COALESCE(notes,'') "
                                "FROM role_history WHERE dancer_id=? ORDER BY start_date", (self.did,)).fetchall()
        if rows:
            self.add("table", ["Loma", "No", "Līdz", "Piezīmes"],
                     [[r, show_date(s) or "—", show_date(e) or "tagad", n] for r, s, e, n in rows], "llll")
        elif not extra:
            return False

    # ---- Cītība --------------------------------------------------------------------
    def _marks(self):
        if not (has_table(self.con, "attendance") and has_table(self.con, "attendance_sessions")):
            return []
        return self.con.execute(
            "SELECT s.session_date, COALESCE(s.kind,''), COALESCE(s.title,''), a.mark, COALESCE(a.note,'') "
            "FROM attendance a JOIN attendance_sessions s ON s.id = a.session_id WHERE a.dancer_id=? "
            "AND s.session_date <= ? ORDER BY s.session_date DESC", (self.did, self.today)).fetchall()

    def attendance(self):
        rows = self._marks()
        if not rows:
            self.add("p", "Apmeklējuma atzīmju vēl nav.")
            return
        per = {}
        for day, _k, _t, mark, _n in rows:
            s = season_of(day)
            c = per.setdefault(s, {m: 0 for m in MARKS})
            if mark in c:
                c[mark] += 1
        bars, table = [], []
        for s in sorted(per, reverse=True):
            c = per[s]
            marked = sum(c.values())
            value = pct(c["Ieradās"] + c["Nokavēja"], marked)
            bars.append((f"Sezona {season_label(s)}", value or 0, f"{value} % no {marked} atzīmēm"))
            table.append([season_label(s), str(marked), str(c["Ieradās"]), str(c["Nokavēja"]), str(c["Attaisnoti"]),
                          str(c["Neattaisnoti"]), f"{value} %"])
        self.add("bars", bars)
        self.add("table", ["Sezona", "Atzīmes", "Ieradās", "Nokavēja", "Attaisnoti", "Neattaisnoti", "Cītība"],
                 table, "lrrrrrr")
        last = [[show_date(d), k, t, m + (" nebija" if m in ("Attaisnoti", "Neattaisnoti") else ""), n]
                for d, k, t, m, n in rows[:12]]
        self.add("table", ["Pēdējās atzīmes", "Veids", "Nosaukums", "Atzīme", "Piezīme"], last, "lllll")

    def shows(self):
        rows = [r for r in self._marks() if r[1] in SHOW_KINDS and r[3] in CAME]
        if not rows:
            return False
        this = season_of(self.today)
        n_this = sum(1 for r in rows if season_of(r[0]) == this)
        self.add("kv", [("Šajā sezonā", str(n_this)), ("Pavisam (ar atzīmēm)", str(len(rows)))])
        self.add("table", ["Datums", "Veids", "Nosaukums"], [[show_date(d), k, t] for d, k, t, _m, _n in rows[:20]],
                 "lll")

    # ---- Dejas ---------------------------------------------------------------------
    def dances(self):
        if not (has_table(self.con, "dance_cast") and has_table(self.con, "dances")):
            return False
        rows = self.con.execute("SELECT d.title, COALESCE(d.status,''), COALESCE(c.role,''), COALESCE(c.pair_no,'') "
                                "FROM dance_cast c JOIN dances d ON d.id = c.dance_id WHERE c.dancer_id=? "
                                "ORDER BY CASE d.status WHEN 'Repertuārā' THEN 0 WHEN 'Procesā' THEN 1 "
                                "WHEN 'Atpūtā' THEN 2 ELSE 3 END, d.title", (self.did,)).fetchall()
        if not rows:
            self.add("p", "Nav nevienas dejas sastāvā.")
            return
        active = sum(1 for r in rows if r[1] in DP.ACTIVE_DANCE_STATUSES)
        self.add("kv", [("Repertuārā un procesā", str(active)), ("Pavisam sastāvos", str(len(rows)))])
        self.add("table", ["Deja", "Statuss", "Loma sastāvā", "Pāris"],
                 [[t, s, r or "—", p or "—"] for t, s, r, p in rows], "llll")

    # ---- Tērpi ---------------------------------------------------------------------
    def costumes(self):
        con = self.con
        if not (has_table(con, "checkouts") and has_table(con, "costume_pieces")):
            return False
        rows = con.execute("SELECT COALESCE(p.inv_no,''), COALESCE(p.name,''), COALESCE(c.checkout_date,''), "
                           "COALESCE(c.return_date,'') FROM checkouts c JOIN costume_pieces p ON p.id = c.piece_id "
                           "WHERE c.dancer_id=? ORDER BY c.checkout_date DESC", (self.did,)).fetchall()
        out = [r for r in rows if not (r[3] or "").strip()]
        fines = []
        if has_table(con, "costume_fines"):
            fines = con.execute("SELECT COALESCE(fine_date,''), COALESCE(description,''), COALESCE(amount_cents,0), "
                                "status FROM costume_fines WHERE dancer_id=? ORDER BY fine_date DESC",
                                (self.did,)).fetchall()
        if not rows and not fines:
            self.add("p", "Tērpi nav izsniegti.")
            return
        active_fines = [f for f in fines if f[3] == K.FINE_ACTIVE]
        self.add("kv", [("Tagad izsniegti", str(len(out))), ("Izsniegti pavisam", str(len(rows))),
                        ("Uzliktas soda naudas", f"{len(active_fines)} · {money(sum(f[2] for f in active_fines))}"
                                                 if active_fines else "nav")])
        if out:
            self.add("table", ["Izsniegts tagad", "Nosaukums", "Kopš"],
                     [[i, n, show_date(d)] for i, n, d, _r in out], "lll")
        back = [r for r in rows if (r[3] or "").strip()]
        if back:
            self.add("table", ["Atdoti (pēdējie)", "Nosaukums", "Izsniegts", "Atdots"],
                     [[i, n, show_date(d), show_date(r)] for i, n, d, r in back[:12]], "llll")
        if fines:
            self.add("table", ["Soda nauda", "Iemesls", "Summa", "Statuss"],
                     [[show_date(d), t, money(c), s] for d, t, c, s in fines], "llrl")

    # ---- Nauda (Zelta pūrs) --------------------------------------------------------
    def money(self):
        con, did = self.con, self.did
        if not (has_table(con, "fin_entries") and has_table(con, "fin_fee_rates")):
            return False
        try:
            from moduli import zelta_purs as Z
        except ImportError:
            import zelta_purs as Z
        db = Z.Database.__new__(Z.Database)
        db.con = con
        dancer = Z.Database.dancers(db).get(did)
        if dancer is None:
            return False
        entries = Z.Database.entries(db)
        p = self.person
        last = self.today
        if p["status"] == K.STATUS_LEFT and p["left_date"]:
            last = min(last, p["left_date"])
        season = Z.season_of(last[:7])
        rates, personal = Z.Database.fee_rates(db), Z.Database.personal_fees(db)
        paid = Z.fee_paid_by_month(entries).get(did, {})
        rows, owed = [], 0
        for month in Z.due_months(dancer, season):
            if month > last[:7]:
                break
            due = Z.fee_due(rates, personal, dancer, month)
            got = paid.get(month, 0)
            if not due and not got:
                continue
            owed += max(due - got, 0)
            rows.append([Z.month_label(month), money(due), money(got),
                         money(due - got) if due > got else ("✓" if due else "—")])
        kv = [(f"Dalības maksa {season_label(season)} — parāds", money(owed))]
        if did in personal:
            kv.append(("Individuālā maksa", money(personal[did][0]) + (f" ({personal[did][1]})"
                                                                         if personal[did][1] else "")))
        costume_rows, costume_owed = [], 0
        if has_table(con, "fin_costume_rates"):
            crates = Z.Database.costume_rates(db)
            cpaid = Z.costume_paid(entries).get(did, {})
            for half in (1, 2):
                key = Z.half_key(season, half)
                due, got = Z.costume_due(crates, dancer, key), cpaid.get(key, 0)
                if not due and not got:
                    continue
                late = Z.half_deadline(key).isoformat() <= last
                if late:
                    costume_owed += max(due - got, 0)
                costume_rows.append([Z.half_label(key), show_date(Z.half_deadline(key).isoformat()), money(due),
                                     money(got), money(due - got) if due > got else "✓"])
            kv.append(("Tērpu fonds — nokavēts", money(costume_owed)))
        self.add("kv", kv)
        if rows:
            self.add("table", ["Mēnesis", "Jāmaksā", "Samaksāts", "Parāds"], rows, "lrrr")
        if costume_rows:
            self.add("table", ["Tērpu fonds", "Termiņš", "Jāmaksā", "Samaksāts", "Atlikums"], costume_rows, "llrrr")
        mine = [e for e in entries if e.get("dancer_id") == did]
        mine.sort(key=lambda e: e.get("entry_date") or "", reverse=True)
        if mine:
            self.add("table", ["Maksājums", "Kategorija", "Summa", "Piezīmes"],
                     [[show_date(e.get("entry_date")), e.get("category") or "", money(int(e.get("amount_cents") or 0)),
                       e.get("notes") or ""] for e in mine[:15]], "llrl")


# --------------------------------------------------------------------------
# Window
# --------------------------------------------------------------------------
class CardWindow(tk.Toplevel):
    def __init__(self, root, did):
        super().__init__(root)
        self.did = did
        self.configure(bg=CREAM)
        self.transient(root)
        self.geometry("900x820")
        self.minsize(720, 520)
        self.con = K.connect_db()
        self.title("Dejotāja kartīte")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda e: self.close())

        self.head = tk.Frame(self, bg=WHITE)
        self.head.pack(fill="x", side="top")
        tk.Frame(self, bg=LINE, height=1).pack(fill="x", side="top")
        tk.Frame(self, bg=izskats.MODULE_COLORS.get("kopas_purs", GOLD), height=3).pack(fill="x", side="top")
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.close).pack(side="right")
        ttk.Button(foot, text="⎙ Drukāt / PDF", command=self.print_card).pack(side="right", padx=(0, 8))
        ttk.Button(foot, text="↻ Atjaunot", command=self.refresh).pack(side="right", padx=(0, 8))
        tk.Label(foot, text="Redzamas tikai tās daļas, ko jūsu loma drīkst atvērt.", bg=WHITE, fg=MUTED,
                 font=FONT_SMALL).pack(side="left")

        outer = tk.Frame(self, bg=CREAM)
        outer.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(outer, bg=CREAM, highlightthickness=0)
        bar = ttk.Scrollbar(outer, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=CREAM, padx=20, pady=14)
        item = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(item, width=e.width))
        self.bind_all_wheel()
        self.refresh()

    def bind_all_wheel(self):
        def wheel(event):
            if not self.winfo_exists():
                return
            w = self.winfo_containing(event.x_root, event.y_root)
            if w is None or w.winfo_toplevel() is not self or isinstance(w, ttk.Treeview):
                return
            step = -1 if (getattr(event, "delta", 0) > 0 or getattr(event, "num", 0) == 4) else 1
            self.canvas.yview_scroll(step * 3, "units")
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.bind(seq, wheel, add="+")
            self.body.bind(seq, wheel, add="+")
            self.canvas.bind(seq, wheel, add="+")
        self._wheel = wheel

    def refresh(self):
        try:
            card = Card(self.con, self.did)
            self.blocks = card.build()
            self.person = card.person
        except Exception:
            K.log_error("Dejotāja kartīte:\n" + traceback.format_exc())
            self.blocks, self.person = [("p", "Kartīti neizdevās sagatavot — detaļas kļūdu žurnālā.")], None
        self.draw_head()
        for w in self.body.winfo_children():
            w.destroy()
        box = None
        for block in self.blocks:
            kind = block[0]
            if kind == "h":
                box = tk.Frame(self.body, bg=WHITE, highlightthickness=1, highlightbackground=LINE, padx=16, pady=12)
                box.pack(fill="x", pady=(0, 12))
                tk.Label(box, text=block[1], bg=WHITE, fg=NAVY, font=("Georgia", 13, "bold"),
                         anchor="w").pack(fill="x", pady=(0, 6))
                continue
            parent = box or self.body
            if kind == "p":
                tk.Label(parent, text=block[1], bg=WHITE if box else CREAM, fg=MUTED, font=FONT, anchor="w",
                         justify="left", wraplength=780).pack(fill="x", pady=2)
            elif kind == "kv":
                grid = tk.Frame(parent, bg=WHITE)
                grid.pack(fill="x", pady=(0, 6))
                for i, (k, v) in enumerate(block[1]):
                    cell = tk.Frame(grid, bg=WHITE, highlightthickness=1, highlightbackground=LINE_SOFT, padx=10,
                                    pady=6)
                    cell.grid(row=i // 3, column=i % 3, sticky="nsew", padx=(0, 8), pady=(0, 8))
                    tk.Label(cell, text=k.upper(), bg=WHITE, fg=MUTED, font=("Segoe UI", 8), anchor="w").pack(fill="x")
                    tk.Label(cell, text=v, bg=WHITE, fg=NAVY, font=("Segoe UI", 10, "bold"), anchor="w",
                             justify="left", wraplength=230).pack(fill="x")
                for c in range(3):
                    grid.columnconfigure(c, weight=1, uniform="kv")
            elif kind == "table":
                header, rows, align = block[1], block[2], block[3]
                cols = [f"c{i}" for i in range(len(header))]
                tree = ttk.Treeview(parent, columns=cols, show="headings", height=min(len(rows), 12) or 1)
                for i, h in enumerate(header):
                    tree.heading(cols[i], text=h, anchor="e" if align[i] == "r" else "w")
                    tree.column(cols[i], anchor="e" if align[i] == "r" else "w", stretch=True,
                                width=90 if align[i] == "r" else 160)
                izskats.zebra(tree)
                for n, r in enumerate(rows):
                    tree.insert("", "end", values=r, tags=izskats.row_tags(n))
                tree.pack(fill="x", pady=(2, 8))
            elif kind == "bars":
                for label, value, text in block[1]:
                    row = tk.Frame(parent, bg=WHITE)
                    row.pack(fill="x", pady=2)
                    tk.Label(row, text=label, bg=WHITE, fg=NAVY, font=FONT, width=18, anchor="w").pack(side="left")
                    track = tk.Frame(row, bg=LINE_SOFT, height=12, width=300)
                    track.pack(side="left", padx=8)
                    track.pack_propagate(False)
                    colour = GREEN if value >= 80 else ("#C4703A" if value >= LOW_PCT else RED)
                    tk.Frame(track, bg=colour, height=12, width=max(1, 3 * min(100, value))).place(x=0, y=0,
                                                                                                    relheight=1)
                    tk.Label(row, text=text, bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="left")
        for w in self._all(self.body):
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                if not isinstance(w, ttk.Treeview):
                    w.bind(seq, self._wheel, add="+")
        self.canvas.yview_moveto(0)

    def _all(self, w):
        for c in w.winfo_children():
            yield c
            yield from self._all(c)

    def draw_head(self):
        for w in self.head.winfo_children():
            w.destroy()
        p = self.person
        name = p["full"] if p else "Dejotājs"
        self.title(f"Dejotāja kartīte — {name}")
        row = tk.Frame(self.head, bg=WHITE)
        row.pack(fill="x", padx=20, pady=14)
        initials = "".join(x[0] for x in name.split()[:2]).upper() or "?"
        colour = izskats.MODULE_COLORS.get("kopas_purs", NAVY)
        tk.Label(row, text=initials, bg=colour, fg=WHITE, font=("Georgia", 16, "bold"), width=3, height=1,
                 pady=8).pack(side="left")
        text = tk.Frame(row, bg=WHITE)
        text.pack(side="left", padx=14)
        tk.Label(text, text=name, bg=WHITE, fg=NAVY, font=("Georgia", 18, "bold"), anchor="w").pack(fill="x")
        if p:
            sub = f"{p['group']} grupa · {p['status']}" + (f" · {p['role']}" if p["role"] and
                                                           p["role"] != K.ROLE_DANCER else "")
            tk.Label(text, text=sub, bg=WHITE, fg=MUTED, font=FONT, anchor="w").pack(fill="x")

    def heading(self):
        p = self.person
        group_name = K.read_setting("app.group_name", "Tautas deju kolektīvs")
        title = f"Dejotāja kartīte — {p['full']}" if p else "Dejotāja kartīte"
        sub = group_name + (f" · {p['group']} grupa · {p['status']}" if p else "") + \
            f" · sagatavota {date.today().strftime('%d.%m.%Y')}"
        return title, sub

    def print_card(self):
        try:
            try:
                from moduli.sezonas_parskats import to_html
            except ImportError:
                from sezonas_parskats import to_html
            title, sub = self.heading()
            name = (self.person["full"] if self.person else "dejotājs").replace("/", "-")
            path = filedialog.asksaveasfilename(parent=self, title="Saglabāt dejotāja kartīti",
                                                initialfile=f"Dejotāja kartīte {name}.html", defaultextension=".html",
                                                filetypes=[("Tīmekļa lapa (HTML)", "*.html")])
            if not path:
                return
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(to_html(self.blocks, title, sub, f"Pūrlāde · {K.COPYRIGHT}"))
        except Exception as exc:
            K.log_error(traceback.format_exc())
            return messagebox.showerror("Dejotāja kartīte", f"Neizdevās saglabāt:\n{exc}", parent=self)
        try:
            if os.name == "nt":
                os.startfile(path)   # noqa: the default browser
            else:
                webbrowser.open("file://" + os.path.abspath(path))
        except Exception:
            messagebox.showinfo("Dejotāja kartīte", f"Kartīte saglabāta:\n{path}", parent=self)

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass
        self.destroy()


def show(root, did):
    for win in root.winfo_children():
        if isinstance(win, CardWindow) and win.did == did:
            win.deiconify()
            win.lift()
            win.refresh()
            return win
    return CardWindow(root, did)
