#!/usr/bin/env python3
"""
Pūrlāde — modulis "Deju pūrs" (deju / repertuāra uzskaitei)

Šeit tiek uzturēts kolektīva repertuārs: katra deja ar horeogrāfu, mūziku,
veidu, puišu un meitu skaitu, ilgumu, tērpu komplektu un aprakstu, kā arī dejas
sastāvs — kuri dejotāji (no Kopas pūra) to dejo pamatsastāvā vai rezervē.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/deju_purs.py
"""

import re
import sqlite3
import traceback
from datetime import date
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve
try:  # started from Pūrlāde
    from moduli.kopeja import ensure_cast_substitutes, DANCER_GROUPS, DEFAULT_DANCER_GROUP
except ImportError:  # started directly from the moduli folder
    from kopeja import ensure_cast_substitutes, DANCER_GROUPS, DEFAULT_DANCER_GROUP
try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible, ensure_dancer_schema,
                               full_name, parse_date, read_table, _norm, active_dancer_sql, dancer_role_sql,
                               GENDERS, GENDER_MALE, GENDER_FEMALE, STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible, ensure_dancer_schema,
                        full_name, parse_date, read_table, _norm, active_dancer_sql, dancer_role_sql,
                        GENDERS, GENDER_MALE, GENDER_FEMALE, STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

DANCE_GROUP_SEEDED = "dance_group.initial"   # settings key: existing dances were given group A

PROGRAM_NAME = "Deju pūrs"
APP_VERSION = "0.3.2"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Deju uzskaite: repertuārs, dejas apraksts, horeogrāfs, dejotāju sastāvs",
    "letter": "D",
    "color": NAVY,
}

# ---- choices --------------------------------------------------------------
DANCE_IN_REPERTOIRE = "Repertuārā"
DANCE_LEARNING = "Procesā"
OLD_DANCE_LEARNING = ("Iestudējumā", "Apgūšanas procesā")  # earlier names, renamed in the database on start
DANCE_RESTING = "Atpūtā"
DANCE_ARCHIVED = "Arhīvā"
DANCE_STATUSES = [DANCE_IN_REPERTOIRE, DANCE_LEARNING, DANCE_RESTING, DANCE_ARCHIVED]

TYPE_STAGE = "Latviešu skatuviskā deja"
TYPE_SHOW = "Uzveduma deja"
TYPE_PLAY = "Rotaļdeja"
DANCE_TYPES = [TYPE_STAGE, TYPE_SHOW, TYPE_PLAY]
OLD_DANCE_TYPES = {"Skatuves deja": TYPE_STAGE, "Rotaļa": TYPE_PLAY}  # names used in v0.1

LINEUP_MIXED = "Jaukts"
LINEUP_WOMEN = "Sieviešu"
LINEUP_MEN = "Vīriešu"
LINEUPS = [LINEUP_MIXED, LINEUP_WOMEN, LINEUP_MEN]

# Tērpu pūrs keeps costume pieces in two categories; a dance chooses costume types for each gender
COSTUME_CATEGORY = {GENDER_FEMALE: "Meiteņu tērpi", GENDER_MALE: "Puišu tērpi"}
COSTUME_TITLE = {GENDER_FEMALE: "Sievietēm (meiteņu tērpi)", GENDER_MALE: "Vīriešiem (puišu tērpi)"}
AVAILABLE_PIECE = "Noliktavā"

# Cītības pūrs: which session kinds count as rehearsals
REHEARSAL_KINDS = ("Mēģinājums", "Papildmēģinājums")

ROLE_MAIN = "Pamatsastāvs"
ROLE_RESERVE = "Rezerve"
ROLES = [ROLE_MAIN, ROLE_RESERVE]

# table columns: key, heading, width
COLUMNS = [
    ("title", "Deja", 150),
    ("dance_group", "Grupa", 65),
    ("choreographer", "Horeogrāfs", 120),
    ("music", "Mūzika", 110),
    ("dance_type", "Veids", 170),
    ("lineup", "Sastāvs", 75),
    ("counts", "Puiši / meitas", 95),
    ("cast", "Dejotāji", 90),
    ("duration", "Ilgums", 55),
    ("costume_set", "Tērpu komplekts", 110),
    ("status", "Statuss", 90),
    ("rehearsed", "Mēģināta", 75),
    ("learned_date", "Iestudēta", 85),
]

FIELDS = ("title", "choreographer", "music", "dance_type", "production", "lineup", "men_count", "women_count",
          "duration",
          "costume_set", "status", "learned_date", "video", "description", "notes", "dance_group")


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS dances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    choreographer TEXT DEFAULT '',
    music TEXT DEFAULT '',
    dance_type TEXT DEFAULT '',
    production TEXT DEFAULT '',
    lineup TEXT DEFAULT '',
    pairs TEXT DEFAULT '',
    men_count TEXT DEFAULT '',
    women_count TEXT DEFAULT '',
    duration TEXT DEFAULT '',
    costume_set TEXT DEFAULT '',
    status TEXT DEFAULT '',
    learned_date TEXT DEFAULT '',
    video TEXT DEFAULT '',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS dance_costumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    gender TEXT NOT NULL,
    type_name TEXT NOT NULL,
    UNIQUE (dance_id, gender, type_name)
);
CREATE TABLE IF NOT EXISTS dance_cast (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    role TEXT DEFAULT '',
    pair_no TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    UNIQUE (dance_id, dancer_id)
);
"""


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        ensure_dancer_schema(self.con)
        self.con.executescript(SCHEMA)
        have = {r[1] for r in self.con.execute("PRAGMA table_info(dances)")}
        for column in FIELDS:  # later versions may add columns
            if column not in have:
                self.con.execute(f"ALTER TABLE dances ADD COLUMN {column} TEXT DEFAULT ''")
        # v0.1.10 and earlier kept one "pāru skaits": turn it into the numbers of boys and girls
        for did, lineup, pairs in self.con.execute(
                "SELECT id, lineup, pairs FROM dances WHERE TRIM(COALESCE(pairs,'')) <> '' "
                "AND TRIM(COALESCE(men_count,'')) = '' AND TRIM(COALESCE(women_count,'')) = ''").fetchall():
            if not str(pairs).strip().isdigit():
                continue
            n = int(pairs)
            men, women = {LINEUP_WOMEN: (0, 2 * n), LINEUP_MEN: (2 * n, 0)}.get(lineup, (n, n))
            self.con.execute("UPDATE dances SET men_count=?, women_count=?, pairs='' WHERE id=?",
                             (str(men) if men else "", str(women) if women else "", did))
        for old in OLD_DANCE_LEARNING:
            self.con.execute("UPDATE dances SET status=? WHERE status=?", (DANCE_LEARNING, old))
        for old, new in OLD_DANCE_TYPES.items():
            self.con.execute("UPDATE dances SET dance_type=? WHERE dance_type=?", (new, old))
        self.con.commit()
        ensure_cast_substitutes(self.con)
        # Deju pūrs v0.2.4: every dance belongs to a group (A / Studija / VPDK, as in Kopas pūrs). The dances that
        # existed then got group A — once, so later changes are never overwritten.
        if not self.con.execute("SELECT 1 FROM settings WHERE key=?", (DANCE_GROUP_SEEDED,)).fetchone():
            self.con.execute("UPDATE dances SET dance_group=? WHERE TRIM(COALESCE(dance_group,'')) = ''",
                             (DEFAULT_DANCER_GROUP,))
            self.con.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (DANCE_GROUP_SEEDED, "1"))
            self.con.commit()  # each main-cast dancer can have his own reserve dancer

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    # ---- costume types from Tērpu pūrs ----------------------------------
    def costume_types(self):
        """Costume types kept in Tērpu pūrs → Administrēšana (plus types used on pieces)."""
        names = set()
        for sql in ("SELECT name FROM piece_types", "SELECT DISTINCT type FROM costume_pieces"):
            try:
                names.update(r[0] for r in self.q(sql))
            except sqlite3.Error:
                pass
        return sorted((n for n in names if (n or "").strip()), key=_norm)

    def costume_types_for(self, gender):
        """Costume types offered for a gender: only the types whose category in Tērpu pūrs →
        Administrēšana is "Meiteņu tērpi" (women) or "Puišu tērpi" (men)."""
        try:
            rows = self.q("SELECT name FROM piece_types WHERE category=?", (COSTUME_CATEGORY[gender],))
        except sqlite3.Error:  # older database without type categories: all types
            return self.costume_types()
        return sorted((r[0] for r in rows if (r[0] or "").strip()), key=_norm)

    def type_stock(self):
        """{(category, type): (pieces, in stock)} from Tērpu pūrs."""
        try:
            rows = self.q("SELECT category, type, COUNT(*), SUM(CASE WHEN status=? THEN 1 ELSE 0 END) "
                          "FROM costume_pieces GROUP BY category, type", (AVAILABLE_PIECE,))
        except sqlite3.Error:
            return {}
        return {(c, _norm(t)): (n, a or 0) for c, t, n, a in rows}

    def dance_costumes(self, dance_id):
        result = {g: [] for g in GENDERS}
        for gender, name in self.q("SELECT gender, type_name FROM dance_costumes WHERE dance_id=? ORDER BY id",
                                   (dance_id,)):
            result.setdefault(gender, []).append(name)
        return result

    def save_dance_costumes(self, dance_id, costumes):
        self.con.execute("DELETE FROM dance_costumes WHERE dance_id=?", (dance_id,))
        for gender, names in costumes.items():
            for name in names:
                self.con.execute("INSERT OR IGNORE INTO dance_costumes (dance_id, gender, type_name) "
                                 "VALUES (?, ?, ?)", (dance_id, gender, name))
        self.con.commit()

    def costume_sets(self):
        """Costume set names from Tērpu pūrs (its table exists only once that module has been used)."""
        names = set()
        try:
            names.update(r[0] for r in self.q("SELECT name FROM piece_sets"))
        except sqlite3.Error:
            pass
        try:
            names.update(r[0] for r in self.q("SELECT DISTINCT set_name FROM costume_pieces"))
        except sqlite3.Error:
            pass
        names.update(r[0] for r in self.q("SELECT DISTINCT costume_set FROM dances"))
        return sorted((n for n in names if (n or "").strip()), key=_norm)

    def rehearsal_stats(self):
        """From Cītības pūrs: {dance id: {"season": n, "total": n, "last": ISO date, "performed": n}}.
        Season = from 1 September. Empty while Cītības pūrs has not been used."""
        if not self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='session_dances'"):
            return {}
        today = date.today()
        season_start = date(today.year if today.month >= 9 else today.year - 1, 9, 1).isoformat()
        result = {}
        cancelled = set()  # events cancelled in Notikumu pūrs are not counted as performed
        if self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_details'"):
            cancelled = {r[0] for r in self.q("SELECT session_id FROM event_details WHERE status='Atcelts'")}
        for sid, dance_id, day, kind in self.q("SELECT sd.session_id, sd.dance_id, s.session_date, s.kind "
                                               "FROM session_dances sd "
                                               "JOIN attendance_sessions s ON s.id = sd.session_id"):
            r = result.setdefault(dance_id, {"season": 0, "total": 0, "last": "", "performed": 0})
            if kind in REHEARSAL_KINDS:
                r["total"] += 1
                if day >= season_start:
                    r["season"] += 1
                if day <= today.isoformat() and day > r["last"]:
                    r["last"] = day
            elif day <= today.isoformat() and sid not in cancelled:  # planned concerts are not counted yet
                r["performed"] += 1
        return result

    def distinct(self, column):
        return sorted((r[0] for r in self.q(f"SELECT DISTINCT {column} FROM dances")
                       if (r[0] or "").strip()), key=_norm)


def save_dance(db, values, dance_id=None):
    data = [values.get(f, "") for f in FIELDS]
    if dance_id is None:
        return db.x("INSERT INTO dances (" + ", ".join(FIELDS) + ") VALUES (" + ",".join("?" * len(FIELDS)) + ")",
                    data)
    db.x("UPDATE dances SET " + ", ".join(f + "=?" for f in FIELDS) + " WHERE id=?", data + [dance_id])
    return dance_id


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def parse_duration(text):
    """'3:45', '3.45', '3 min 45 s', '225 s' or '4' (minutes) -> seconds as text; '' when empty; None when bad."""
    text = str(text or "").strip().lower()
    if not text:
        return ""
    m = re.fullmatch(r"(\d{1,3})\s*[:.,']\s*(\d{1,2})\s*(\"|'')?", text)
    if m:
        minutes, seconds = int(m.group(1)), int(m.group(2))
        if seconds < 60:
            return str(minutes * 60 + seconds)
        return None
    m = re.fullmatch(r"(?:(\d{1,3})\s*min\.?)?\s*(?:(\d{1,4})\s*(?:s|sek\.?|sec))?", text)
    if m and (m.group(1) or m.group(2)):
        return str(int(m.group(1) or 0) * 60 + int(m.group(2) or 0))
    if re.fullmatch(r"\d{1,2}", text):  # a single small number = minutes
        return str(int(text) * 60)
    if re.fullmatch(r"\d{3,4}", text):  # a larger number = seconds
        return str(int(text))
    return None


def show_duration(seconds):
    try:
        s = int(seconds)
    except (TypeError, ValueError):
        return ""
    return f"{s // 60}:{s % 60:02d}"


def show_total(seconds):
    if not seconds:
        return "0 min"
    h, rest = divmod(int(seconds), 3600)
    m = round(rest / 60)
    if m == 60:
        h, m = h + 1, 0
    return f"{h} h {m} min" if h else f"{m} min"


def normalize_dance_status(text):
    s = _norm(text)
    if not s:
        return DANCE_IN_REPERTOIRE
    if s.startswith(("repert", "aktiv", "dejo", "ja")):
        return DANCE_IN_REPERTOIRE
    if s.startswith(("proces", "apgus", "iestud", "macam", "macas", "jauna")):
        return DANCE_LEARNING
    if s.startswith(("atpu", "pauz", "neakt")):
        return DANCE_RESTING
    if s.startswith(("arhiv", "nedejo", "vec")):
        return DANCE_ARCHIVED
    return None


def normalize_dance_type(text):
    """Excel text -> one of DANCE_TYPES ('' when empty, None when unknown)."""
    s = _norm(text)
    if not s:
        return ""
    if s.startswith(("latv", "skatuv")):
        return TYPE_STAGE
    if s.startswith("uzved"):
        return TYPE_SHOW
    if s.startswith("rotal"):
        return TYPE_PLAY
    return None  # unknown type


def type_text(dance_type, production):
    """'Uzveduma deja: <uzvedums>' for the table."""
    if dance_type == TYPE_SHOW and production:
        return f"{dance_type}: {production}"
    return dance_type


def normalize_lineup(text):
    s = _norm(text)
    if not s:
        return ""
    if s.startswith(("jauk", "mix", "pari")):
        return LINEUP_MIXED
    if s.startswith(("siev", "meit", "women", "girls")):
        return LINEUP_WOMEN
    if s.startswith(("vir", "puis", "men", "boys")):
        return LINEUP_MEN
    return None


def needed_by_gender(men_count, women_count):
    """How many women / men a dance needs: (women, men) or None when neither number is given."""
    men, women = str(men_count or "").strip(), str(women_count or "").strip()
    if not men.isdigit() and not women.isdigit():
        return None
    return (int(women) if women.isdigit() else 0), (int(men) if men.isdigit() else 0)


def counts_text(men_count, women_count):
    """'12 / 12' for the table (boys / girls)."""
    men, women = (men_count or "").strip(), (women_count or "").strip()
    if not men and not women:
        return ""
    return f"{men or 0} / {women or 0}"


def cast_status(in_cast, men_count, women_count):
    """Text and colour describing whether the cast is complete.
    in_cast rows: (..., ..., name, gender, role, ...)"""
    main = [r for r in in_cast if (r[4] or ROLE_MAIN) == ROLE_MAIN]
    women = sum(1 for r in main if r[3] == GENDER_FEMALE)
    men = sum(1 for r in main if r[3] == GENDER_MALE)
    reserve = len(in_cast) - len(main)
    have = f"Pamatsastāvā — puiši: {men}, meitas: {women}; rezervē: {reserve}."
    need = needed_by_gender(men_count, women_count)
    if need is None:
        return have + "  (Puišu un meitu skaits dejai nav norādīts.)", NAVY
    nw, nm = need
    missing = []
    if women < nw:
        missing.append(f"meitas: {nw - women}")
    if men < nm:
        missing.insert(0, f"puiši: {nm - men}")
    extra = (women - nw) + (men - nm) if women >= nw and men >= nm else 0
    text = f"Vajag — puiši: {nm}, meitas: {nw}.  " + have
    if missing:
        return text + "  Trūkst: " + ", ".join(missing) + ".", RED
    if extra:
        return text + f"  Pamatsastāvā vairāk nekā vajag (+{extra}).", AMBER
    return text + "  Sastāvs pilns ✓", GREEN


def load_cast(db, dance_id):
    """Rows (cast id, dancer id, name, gender, role, pair no, notes, active) sorted by role and pair."""
    rows = db.q("SELECT c.id, c.dancer_id, d.name, d.gender, c.role, c.pair_no, c.notes, "
                + active_dancer_sql("d") + " FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                "WHERE c.dance_id=?", (dance_id,))

    def pair_key(r):
        m = re.match(r"\d+", r[5] or "")
        return ((r[4] or ROLE_MAIN) != ROLE_MAIN, int(m.group(0)) if m else 9999, r[5] or "",
                r[3] != GENDER_FEMALE, _norm(r[2]))
    return sorted(rows, key=pair_key)


def substitute_info(db, dance_id):
    """({main dancer id: substitute's name}, {substitute id: [names of the dancers he replaces]}) for a dance."""
    names = dict(db.q("SELECT id, name FROM dancers"))
    subs, covers = {}, {}
    for main, sub in db.q("SELECT dancer_id, substitute_id FROM dance_cast WHERE dance_id=? AND "
                          "substitute_id IS NOT NULL", (dance_id,)):
        subs[main] = names.get(sub, "")
        covers.setdefault(sub, []).append(names.get(main, ""))
    return subs, covers


def substitute_text(dancer_id, role, subs, covers):
    """Text for the "Rezerve" column of a cast list."""
    if (role or ROLE_MAIN) == ROLE_MAIN:
        return subs.get(dancer_id) or "—"
    return ("aizvieto: " + ", ".join(sorted(covers[dancer_id], key=_norm))) if dancer_id in covers else ""


def clear_substitute(db, dance_id, dancer_id):
    """A dancer taken out of a dance is no longer anybody's reserve in it."""
    db.x("UPDATE dance_cast SET substitute_id=NULL WHERE dance_id=? AND substitute_id=?", (dance_id, dancer_id))


OTHER_GROUP = "#5B3FA0"   # colour of a dancer from another group than the dance's group


def dance_group_of(db, dance_id):
    rows = db.q("SELECT dance_group FROM dances WHERE id=?", (dance_id,))
    return (rows[0][0] or "") if rows else ""


def group_text(dancer_group, dance_group):
    """Group shown in a cast list; a dancer from another group than the dance gets a mark."""
    if dance_group and dancer_group and dancer_group != dance_group:
        return f"{dancer_group} (cita)"
    return dancer_group or ""


def status_notes(db):
    """{dancer id: ' (uz pauzes)' / ' (izstājies)'} for dancers who are not active — shown after the name."""
    return {did: f" ({status.strip().lower()})" for did, status in
            db.q("SELECT id, status FROM dancers WHERE TRIM(COALESCE(status,'')) NOT IN ('', ?)", (STATUS_ACTIVE,))}


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


# --------------------------------------------------------------------------
# Dance form
# --------------------------------------------------------------------------
class DanceForm(tk.Toplevel):
    """Add or edit one dance."""

    def __init__(self, app, dance_id=None):
        super().__init__(app.root)
        self.app, self.dance_id = app, dance_id
        db = app.db
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Jauna deja" if dance_id is None else "Deja")
        self.transient(app.root)
        self.grab_set()
        tk.Label(self, text="Jauna deja" if dance_id is None else "Deja",
                 font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))

        text_fields = ("description", "notes")
        self.vars = {f: tk.StringVar() for f in FIELDS if f not in text_fields}
        self.vars["status"].set(DANCE_IN_REPERTOIRE)
        self.vars["lineup"].set(LINEUP_MIXED)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(3, weight=1)

        def label(text, r, c):
            tk.Label(self, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))

        def entry(key, r, c, width=26, span=1):
            w = ttk.Entry(self, textvariable=self.vars[key], width=width)
            w.grid(row=r, column=c + 1, columnspan=span, sticky="ew", pady=4, padx=(8, 0))
            return w

        def combo(key, values, r, c, readonly=True):
            w = ttk.Combobox(self, textvariable=self.vars[key], values=values, width=24,
                             state="readonly" if readonly else "normal")
            w.grid(row=r, column=c + 1, sticky="ew", pady=4, padx=(8, 0))
            return w

        label("Dejas nosaukums *", 1, 0)
        title = entry("title", 1, 0, span=3)
        label("Horeogrāfs", 2, 0)
        ttk.Combobox(self, textvariable=self.vars["choreographer"], values=db.distinct("choreographer"),
                     width=24).grid(row=2, column=1, sticky="ew", pady=4, padx=(8, 0))
        label("Mūzika (autors, apdare)", 2, 2)
        entry("music", 2, 2)
        label("Veids", 3, 0)
        type_cb = ttk.Combobox(self, textvariable=self.vars["dance_type"], values=DANCE_TYPES, width=24, state="readonly")
        type_cb.grid(row=3, column=1, sticky="ew", pady=4, padx=(8, 0))
        type_cb.bind("<<ComboboxSelected>>", lambda e: self.show_production())
        label("Statuss", 3, 2)
        combo("status", DANCE_STATUSES, 3, 2)
        # shown only for "Uzveduma deja": the show (uzvedums) the dance belongs to
        self.prod_label = tk.Label(self, text="Uzvedums *", bg=CREAM, fg=RED, font=("Segoe UI", 10, "bold"))
        self.prod_box = ttk.Combobox(self, textvariable=self.vars["production"], values=db.distinct("production"),
                                     width=24)
        self.prod_hint = tk.Label(self, text="Izvēlieties uzvedumu, kura sastāvā ir šī deja, vai ierakstiet jaunu.",
                                  bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"))
        label("Sastāvs", 5, 0)
        lineup_cb = combo("lineup", LINEUPS, 5, 0)
        label("Grupa *", 5, 2)
        self.group_box = combo("dance_group", DANCER_GROUPS, 5, 2)
        lineup_cb.bind("<<ComboboxSelected>>", lambda e: (self.show_costume_columns(), self.lock_counts()))
        label("Puišu skaits", 6, 0)
        self.men_entry = entry("men_count", 6, 0)
        label("Meitu skaits", 6, 2)
        self.women_entry = entry("women_count", 6, 2)
        label("Ilgums (min:sek)", 7, 0)
        entry("duration", 7, 0)
        label("Iestudēta (datums)", 7, 2)
        entry("learned_date", 7, 2)
        label("Tērpu komplekts", 8, 0)
        combo("costume_set", db.costume_sets(), 8, 0, readonly=False)
        label("Video / mūzikas saite", 8, 2)
        entry("video", 8, 2)
        tk.Label(self, text="Datumu raksta formā DD.MM.GGGG. Ilgumu — piemēram, 3:45. "
                            "Puišu un meitu skaits — cik dejotāju dejā vajag (sieviešu dejai puišu nav).",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(row=9, column=0, columnspan=4, sticky="w")

        label("Tērpi", 10, 0)
        self.build_costume_panel(db, dance_id)

        label("Dejas apraksts", 11, 0)
        self.description = tk.Text(self, width=70, height=4, wrap="word", relief="solid", bd=1)
        self.description.grid(row=11, column=1, columnspan=3, sticky="nsew", pady=4, padx=(8, 0))
        label("Piezīmes", 12, 0)
        self.notes = tk.Text(self, width=70, height=2, wrap="word", relief="solid", bd=1)
        self.notes.grid(row=12, column=1, columnspan=3, sticky="nsew", pady=4, padx=(8, 0))
        self.rowconfigure(11, weight=1)

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=13, column=0, columnspan=5, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Aizvērt" if dance_id is not None else "Atcelt",
                   command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if dance_id is not None:
            ttk.Button(btns, text="✖ Dzēst deju", style="Danger.TButton", command=self.delete).pack(side="left")
            self.build_cast_panel()
        self.bind("<Escape>", lambda e: self.destroy())

        if dance_id is not None:
            row = db.q("SELECT " + ", ".join(FIELDS) + " FROM dances WHERE id=?", (dance_id,))[0]
            for f, v in zip(FIELDS, row):
                if f == "description":
                    self.description.insert("1.0", v or "")
                elif f == "notes":
                    self.notes.insert("1.0", v or "")
                elif f == "learned_date":
                    self.vars[f].set(show_date(v))
                elif f == "duration":
                    self.vars[f].set(show_duration(v))
                else:
                    self.vars[f].set(v or "")
            if self.vars["status"].get() not in DANCE_STATUSES:
                self.vars["status"].set(DANCE_IN_REPERTOIRE)
            if self.vars["dance_type"].get() not in DANCE_TYPES:
                self.vars["dance_type"].set(TYPE_STAGE)
            if self.vars["dance_group"].get() not in DANCER_GROUPS:
                self.vars["dance_group"].set(DEFAULT_DANCER_GROUP)
        else:
            self.vars["dance_type"].set(TYPE_STAGE)
            self.vars["dance_group"].set(DEFAULT_DANCER_GROUP)
        self.show_production()
        self.show_costume_columns()
        self.lock_counts()
        # lietotāju lomas: all / only the costume types (Tērpu pārzinis) / nothing
        acc = piekluve.current()
        self.old_group = self.vars["dance_group"].get()
        self.costumes_only = False
        if dance_id is None:
            allowed = acc.groups("deju_purs")
            self.group_box.configure(values=allowed)
            if self.vars["dance_group"].get() not in allowed and allowed:
                self.vars["dance_group"].set(allowed[0])
        elif not acc.can_edit("deju_purs", group=self.old_group):
            if acc.costumes:
                self.costumes_only = True
                piekluve.make_readonly(self, keep=("saglabāt",), skip=(self.costume_box,),
                                       note="Var mainīt tikai dejas tērpu veidus (tērpu pārzinis).")
            else:
                piekluve.make_readonly(self, note=(
                    "Tikai skatīšanai — " + ("jūsu lomai Deju pūrā nav labošanas tiesību."
                                             if acc.view_only("deju_purs") else
                                             f"labot var tikai {acc.scope_text('deju_purs')}s dejas.")))
        title.focus_set()
        self.after(100, lambda: fit_min_size(self))

    # ---- costume types for each gender (from Tērpu pūrs) ------------------
    def build_costume_panel(self, db, dance_id):
        self.costume_types = db.costume_types()
        self.types_for = {g: db.costume_types_for(g) for g in GENDERS}
        self.stock = db.type_stock()
        self.costumes = db.dance_costumes(dance_id) if dance_id is not None else {g: [] for g in GENDERS}
        box = tk.Frame(self, bg=CREAM)
        self.costume_box = box
        box.grid(row=10, column=1, columnspan=3, sticky="ew", pady=4, padx=(8, 0))
        box.columnconfigure(0, weight=1, uniform="cost")
        box.columnconfigure(1, weight=1, uniform="cost")
        self.costume_cols, self.costume_lists, self.costume_choice, self.costume_combos = {}, {}, {}, {}
        for i, gender in enumerate((GENDER_FEMALE, GENDER_MALE)):
            col = tk.Frame(box, bg=WHITE, highlightbackground=GOLD, highlightthickness=1, padx=8, pady=6)
            self.costume_cols[gender] = col
            col.grid(row=0, column=i, sticky="nsew", padx=(0, 6) if i == 0 else (6, 0))
            tk.Label(col, text=COSTUME_TITLE[gender], font=("Segoe UI", 9, "bold"), bg=WHITE, fg=NAVY).pack(
                anchor="w")
            lb = tk.Listbox(col, height=4, relief="flat", bg=WHITE, fg=NAVY, selectbackground=GOLD,
                            selectforeground=NAVY, activestyle="none", highlightthickness=0,
                            font=("Segoe UI", 10))
            lb.pack(fill="both", expand=True, pady=(2, 4))
            lb.bind("<Double-1>", lambda e, g=gender: self.remove_costume(g, e))
            self.costume_lists[gender] = lb
            row = tk.Frame(col, bg=WHITE)
            row.pack(fill="x")
            var = tk.StringVar()
            self.costume_choice[gender] = var
            cb = ttk.Combobox(row, textvariable=var, state="readonly", width=18)
            cb.pack(side="left", fill="x", expand=True)
            cb.bind("<<ComboboxSelected>>", lambda e, g=gender: self.add_costume(g))
            self.costume_combos[gender] = cb
        any_types = any(self.types_for.values())
        hint = ("Izvēlieties tērpa veidu sarakstā — tas tiek pievienots. Sievietēm piedāvāti meiteņu tērpu veidi, "
                "vīriešiem — puišu tērpu veidi. Dubultklikšķis uz pievienotā — izņemt."
                if any_types else
                "Tērpu veidu ar kategoriju “Meiteņu tērpi” vai “Puišu tērpi” vēl nav. Tos izveido Tērpu pūrā → "
                "Noliktavas pārvaldība → Administrēšana (tērpu veidi).")
        tk.Label(box, text=hint, bg=CREAM, fg=NAVY if any_types else RED, wraplength=640, justify="left",
                 font=("Segoe UI", 8, "italic")).grid(row=1, column=0, columnspan=2, sticky="w", pady=(2, 0))
        for gender in GENDERS:
            self.refresh_costumes(gender)

    def stock_text(self, gender, name):
        pieces, free = self.stock.get((COSTUME_CATEGORY[gender], _norm(name)), (0, 0))
        none_pieces, none_free = self.stock.get(("Nekategorizēts", _norm(name)), (0, 0))  # for either gender
        pieces, free = pieces + none_pieces, free + none_free
        if not pieces:
            return f"{name}   (Tērpu pūrā nav)"
        return f"{name}   ({pieces} gab., noliktavā {free})"

    def refresh_costumes(self, gender):
        lb = self.costume_lists[gender]
        lb.delete(0, tk.END)
        for name in self.costumes.get(gender, []):
            lb.insert(tk.END, self.stock_text(gender, name))
        chosen = {_norm(n) for n in self.costumes.get(gender, [])}
        offered = [n for n in self.types_for.get(gender, []) if _norm(n) not in chosen]
        self.costume_combos[gender].configure(values=offered)
        self.costume_choice[gender].set("＋ pievienot tērpa veidu…" if self.types_for.get(gender) else
                                        "(nav šīs kategorijas veidu)")

    def add_costume(self, gender):
        name = self.costume_choice[gender].get()
        if name in self.types_for.get(gender, []) and name not in self.costumes.setdefault(gender, []):
            self.costumes[gender].append(name)
        self.refresh_costumes(gender)

    def remove_costume(self, gender, event):
        lb = self.costume_lists[gender]
        index = lb.nearest(event.y)
        if 0 <= index < len(self.costumes.get(gender, [])):
            bbox = lb.bbox(index)
            if bbox and bbox[1] <= event.y <= bbox[1] + bbox[3]:
                del self.costumes[gender][index]
                self.refresh_costumes(gender)

    def costume_genders(self):
        lineup = self.vars["lineup"].get()
        if lineup == LINEUP_WOMEN:
            return [GENDER_FEMALE]
        if lineup == LINEUP_MEN:
            return [GENDER_MALE]
        return [GENDER_FEMALE, GENDER_MALE]

    def lock_counts(self):
        """A women's dance has no boys and a men's dance no girls: that field is cleared and locked."""
        lineup = self.vars["lineup"].get()
        for entry, key, off in ((self.men_entry, "men_count", lineup == LINEUP_WOMEN),
                                (self.women_entry, "women_count", lineup == LINEUP_MEN)):
            if off:
                self.vars[key].set("")
            entry.configure(state="disabled" if off else "normal")

    def show_costume_columns(self):
        shown = self.costume_genders()
        for i, gender in enumerate((GENDER_FEMALE, GENDER_MALE)):
            col = self.costume_cols[gender]
            if gender in shown:
                col.grid()
            else:
                col.grid_remove()

    # ---- cast of the dance (only for a saved dance) ----------------------
    def build_cast_panel(self):
        panel = tk.Frame(self, bg=WHITE, highlightbackground=GOLD, highlightthickness=1, padx=10, pady=8)
        panel.grid(row=1, column=4, rowspan=12, sticky="nsew", padx=(18, 0), pady=4)
        self.columnconfigure(4, weight=1)
        top = tk.Frame(panel, bg=WHITE)
        top.pack(fill="x")
        tk.Label(top, text="Dejas sastāvs", font=("Georgia", 13, "bold"), bg=WHITE, fg=RED).pack(side="left")
        ttk.Button(top, text="♫ Mainīt sastāvu", command=self.open_cast).pack(side="right")
        self.cast_info = tk.Label(panel, text="", font=("Segoe UI", 9, "bold"), bg=WHITE, fg=NAVY,
                                  justify="left", anchor="w", wraplength=380)
        self.cast_info.pack(fill="x", pady=(6, 6))
        holder = tk.Frame(panel, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.cast_tree = ttk.Treeview(holder, columns=("pair_no", "name", "group", "gender", "role", "sub"),
                                      show="headings", height=12)
        for key, text, width in (("pair_no", "Pāris", 50), ("name", "Dejotājs", 150), ("group", "Grupa", 110),
                                 ("gender", "Dzimums", 75), ("role", "Loma", 95), ("sub", "Rezerve", 140)):
            self.cast_tree.heading(key, text=text)
            self.cast_tree.column(key, width=width, minwidth=40, stretch=key == "name")
        self.cast_tree.tag_configure(ROLE_RESERVE, foreground=AMBER)
        self.cast_tree.tag_configure("inactive", foreground=GREY)
        self.cast_tree.tag_configure("othergroup", foreground=OTHER_GROUP)
        self.cast_tree.bind("<Double-1>", lambda e: self.open_cast())
        make_tree_with_scroll(holder, self.cast_tree)
        self.refresh_cast()

    def refresh_cast(self):
        db = self.app.db
        men_count, women_count = db.q("SELECT men_count, women_count FROM dances WHERE id=?", (self.dance_id,))[0]
        rows = load_cast(db, self.dance_id)
        self.cast_tree.delete(*self.cast_tree.get_children())
        notes_by_id = status_notes(db)
        subs, covers = substitute_info(db, self.dance_id)
        groups = dict(db.q("SELECT id, dancer_group FROM dancers"))
        dance_group = dance_group_of(db, self.dance_id)
        for cid, did, name, gender, role, pair_no, _notes, active in rows:
            other = bool(dance_group and groups.get(did) and groups.get(did) != dance_group)
            tags = (role or ROLE_MAIN,) + (() if active else ("inactive",)) + (("othergroup",) if other else ())
            self.cast_tree.insert("", "end", iid=str(cid), tags=tags,
                                  values=(pair_no or "", name + ("" if active else notes_by_id.get(did, "")),
                                          group_text(groups.get(did), dance_group), gender or "",
                                          role or ROLE_MAIN, substitute_text(did, role, subs, covers)))
        if rows:
            text, colour = cast_status(rows, men_count, women_count)
        else:
            text, colour = "Sastāvs vēl nav izveidots. Spiediet “♫ Mainīt sastāvu”.", NAVY
        self.cast_info.configure(text=text.replace("  ", "\n"), fg=colour)

    def open_cast(self):
        if not piekluve.current().can_edit("deju_purs", group=self.old_group):
            return piekluve.deny(self, "Dejas sastāvu var mainīt tikai tie, kas drīkst labot šīs grupas dejas.")
        CastWindow(self.app, self.dance_id, parent=self, on_close=self.after_cast)

    def after_cast(self):
        if self.winfo_exists():
            self.refresh_cast()
            self.grab_set()
            self.focus_set()

    def delete(self):
        if self.app.delete_dance(self.dance_id, parent=self):
            self.destroy()

    def show_production(self):
        if self.vars["dance_type"].get() == TYPE_SHOW:
            self.prod_label.grid(row=4, column=0, sticky="w", pady=4)
            self.prod_box.grid(row=4, column=1, sticky="ew", pady=4, padx=(8, 0))
            self.prod_hint.grid(row=4, column=2, columnspan=2, sticky="w", padx=(18, 0))
        else:
            for w in (self.prod_label, self.prod_box, self.prod_hint):
                w.grid_remove()
        fit_min_size(self)

    def save(self):
        acc = piekluve.current()
        if self.costumes_only:   # Tērpu pārzinis: only the costume types of the dance
            if not acc.costumes:
                return piekluve.deny(self)
            shown = self.costume_genders()
            self.app.db.save_dance_costumes(self.dance_id, {g: n for g, n in self.costumes.items() if g in shown})
            self.app.refresh(select=self.dance_id)
            self.destroy()
            return
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        v = {f: var.get().strip() for f, var in self.vars.items()}
        v["description"] = self.description.get("1.0", tk.END).strip()
        v["notes"] = self.notes.get("1.0", tk.END).strip()
        if not acc.can_edit("deju_purs", group=v["dance_group"]) or (
                self.dance_id is not None and not acc.can_edit("deju_purs", group=self.old_group)):
            return piekluve.deny(self, f"Labot var tikai {acc.scope_text('deju_purs')}s dejas.")
        if not v["title"]:
            messagebox.showwarning("Trūkst datu", "Lūdzu, norādiet dejas nosaukumu.", parent=self)
            return
        if v["dance_group"] not in DANCER_GROUPS:
            messagebox.showwarning("Grupa", "Izvēlieties, kurai grupai ir šī deja: " + ", ".join(DANCER_GROUPS) + ".",
                                   parent=self)
            return
        if v["dance_type"] == TYPE_SHOW:
            if not v["production"]:
                messagebox.showwarning("Uzvedums", "Uzveduma dejai jānorāda uzvedums, kura sastāvā ir šī deja.",
                                       parent=self)
                self.prod_box.focus_set()
                return
        else:
            v["production"] = ""
        for key, title in (("men_count", "Puišu skaits"), ("women_count", "Meitu skaits")):
            if v[key]:
                if not re.fullmatch(r"\d{1,3}", v[key]):
                    messagebox.showwarning(title, f"{title}: norādiet ar veselu skaitli (piemēram, 8).", parent=self)
                    return
                v[key] = str(int(v[key])) if int(v[key]) else ""
        duration = parse_duration(v["duration"])
        if duration is None:
            messagebox.showwarning("Ilgums", "Ilgumu norādiet minūtēs un sekundēs, piemēram, 3:45.", parent=self)
            return
        v["duration"] = duration
        learned = parse_date(v["learned_date"])
        if learned is None:
            messagebox.showwarning("Datums", "Iestudēšanas datums: nepareizs datums. Izmantojiet DD.MM.GGGG.",
                                   parent=self)
            return
        v["learned_date"] = learned
        db = self.app.db
        if self.dance_id is None:
            same = db.q("SELECT COUNT(*) FROM dances WHERE LOWER(title)=LOWER(?) AND LOWER(choreographer)=LOWER(?)",
                        (v["title"], v["choreographer"]))[0][0]
            if same and not messagebox.askyesno(
                    "Dublikāts", "Šāda deja jau ir sarakstā. Vai tomēr pievienot vēl vienu?", parent=self):
                return
        new_id = save_dance(db, v, self.dance_id)
        shown = self.costume_genders()
        db.save_dance_costumes(new_id, {g: names for g, names in self.costumes.items() if g in shown})
        self.app.refresh(select=new_id)
        self.destroy()


# --------------------------------------------------------------------------
# Cast of a dance
# --------------------------------------------------------------------------
class CastWindow(tk.Toplevel):
    """Choose which dancers (from Kopas pūrs) dance this dance."""

    def __init__(self, app, dance_id, parent=None, on_close=None):
        super().__init__(parent or app.root)
        self.app, self.dance_id, self.on_close = app, dance_id, on_close
        db = app.db
        self.configure(bg=CREAM, padx=16, pady=12)
        self.transient(parent or app.root)
        self.grab_set()
        title, lineup, men_count, women_count, dance_group = db.q(
            "SELECT title, lineup, men_count, women_count, dance_group FROM dances WHERE id=?", (dance_id,))[0]
        self.lineup, self.men_count, self.women_count = lineup or LINEUP_MIXED, men_count, women_count
        self.dance_group = dance_group if dance_group in DANCER_GROUPS else ""
        self.title(f"Sastāvs — {title}")
        tk.Label(self, text=f"Dejas sastāvs: {title}", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(
            anchor="w")
        self.need_var = tk.StringVar()
        self.need_lbl = tk.Label(self, textvariable=self.need_var, font=("Segoe UI", 10, "bold"), bg=CREAM, fg=NAVY)
        self.need_lbl.pack(anchor="w", pady=(2, 8))

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=2, uniform="b")
        body.columnconfigure(2, weight=3, uniform="b")
        body.rowconfigure(1, weight=1)

        # left: dancers not yet in the cast
        tk.Label(body, text="Kolektīva dejotāji", font=("Segoe UI", 10, "bold"), bg=CREAM, fg=NAVY).grid(
            row=0, column=0, sticky="w")
        left = tk.Frame(body, bg=CREAM)
        left.grid(row=1, column=0, sticky="nsew")
        fbar = tk.Frame(left, bg=CREAM)
        fbar.pack(fill="x", pady=(0, 4))
        self.search = tk.StringVar()
        ttk.Entry(fbar, textvariable=self.search, width=16).pack(side="left")
        self.f_gender = tk.StringVar(value={LINEUP_WOMEN: GENDER_FEMALE, LINEUP_MEN: GENDER_MALE}.get(
            self.lineup, ALL))
        gcb = ttk.Combobox(fbar, textvariable=self.f_gender, values=[ALL] + GENDERS, state="readonly", width=10)
        gcb.pack(side="left", padx=4)
        # dancers of the dance's group are offered first; "Visi" or another group lets a dancer from another
        # group be put into the dance by hand
        self.f_group = tk.StringVar(value=dance_group if dance_group in DANCER_GROUPS else ALL)
        tk.Label(fbar, text="Grupa:", bg=CREAM, fg=NAVY).pack(side="left", padx=(4, 0))
        grcb = ttk.Combobox(fbar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=8)
        grcb.pack(side="left", padx=(2, 4))
        grcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        if self.dance_group:
            other_bar = tk.Frame(left, bg=CREAM)
            other_bar.pack(fill="x", pady=(0, 4))
            self.other_btn = ttk.Button(other_bar, text="＋ Rādīt arī citu grupu dejotājus",
                                        command=self.toggle_other_groups)
            self.other_btn.pack(side="left")
            tk.Label(other_bar, text=f"Dejas grupa: {self.dance_group}", bg=CREAM, fg=NAVY,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
        self.only_active = tk.BooleanVar(value=True)
        ttk.Checkbutton(fbar, text="tikai aktīvie", variable=self.only_active,
                        command=self.refresh).pack(side="left", padx=4)
        self.search.trace_add("write", lambda *a: self.refresh())
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        holder = tk.Frame(left, bg=CREAM)
        holder.pack(fill="both", expand=True)
        self.pool = ttk.Treeview(holder, columns=("name", "group", "gender", "dances"), show="headings", height=16)
        self.pool.tag_configure("othergroup", foreground=OTHER_GROUP)
        for key, text, width in (("name", "Dejotājs", 170), ("group", "Grupa", 60), ("gender", "Dzimums", 75),
                                 ("dances", "Dejas", 55)):
            self.pool.heading(key, text=text)
            self.pool.column(key, width=width, minwidth=40, stretch=key == "name")
        self.pool.bind("<Double-1>", lambda e: self.add(ROLE_MAIN))
        make_tree_with_scroll(holder, self.pool)

        # middle: buttons
        mid = tk.Frame(body, bg=CREAM)
        mid.grid(row=1, column=1, padx=10)
        ttk.Button(mid, text="Pamatsastāvā ▸", command=lambda: self.add(ROLE_MAIN)).pack(fill="x", pady=3)
        ttk.Button(mid, text="Rezervē ▸", command=lambda: self.add(ROLE_RESERVE)).pack(fill="x", pady=3)
        ttk.Button(mid, text="◂ Izņemt", command=self.remove).pack(fill="x", pady=(14, 3))

        # right: the cast
        tk.Label(body, text="Dejas sastāvs", font=("Segoe UI", 10, "bold"), bg=CREAM, fg=NAVY).grid(
            row=0, column=2, sticky="w")
        right = tk.Frame(body, bg=CREAM)
        right.grid(row=1, column=2, sticky="nsew")
        holder2 = tk.Frame(right, bg=CREAM)
        holder2.pack(fill="both", expand=True)
        self.cast = ttk.Treeview(holder2, columns=("pair_no", "name", "group", "gender", "role", "sub", "notes"),
                                 show="headings", height=16)
        for key, text, width in (("pair_no", "Pāris / vieta", 70), ("name", "Dejotājs", 140),
                                 ("group", "Grupa", 115), ("gender", "Dzimums", 70), ("role", "Loma", 90),
                                 ("sub", "Rezerve", 120), ("notes", "Piezīmes", 70)):
            self.cast.heading(key, text=text)
            self.cast.column(key, width=width, minwidth=40, stretch=key == "notes")
        self.cast.tag_configure(ROLE_RESERVE, foreground=AMBER)
        self.cast.tag_configure("inactive", foreground=GREY)
        self.cast.tag_configure("othergroup", foreground=OTHER_GROUP)
        self.cast.bind("<Double-1>", self.remove_clicked)
        make_tree_with_scroll(holder2, self.cast)

        edit = tk.Frame(right, bg=CREAM)
        edit.pack(fill="x", pady=(6, 0))
        self.e_pair, self.e_role, self.e_notes = tk.StringVar(), tk.StringVar(), tk.StringVar()
        tk.Label(edit, text="Pāris / vieta", bg=CREAM, fg=NAVY).grid(row=0, column=0, sticky="w")
        ttk.Entry(edit, textvariable=self.e_pair, width=8).grid(row=0, column=1, padx=(4, 10))
        tk.Label(edit, text="Loma", bg=CREAM, fg=NAVY).grid(row=0, column=2, sticky="w")
        ttk.Combobox(edit, textvariable=self.e_role, values=ROLES, state="readonly", width=13).grid(
            row=0, column=3, padx=(4, 10))
        tk.Label(edit, text="Piezīmes", bg=CREAM, fg=NAVY).grid(row=0, column=4, sticky="w")
        ttk.Entry(edit, textvariable=self.e_notes, width=18).grid(row=0, column=5, padx=4, sticky="ew")
        edit.columnconfigure(5, weight=1)
        ttk.Button(edit, text="Saglabāt izmaiņas", command=self.save_entry).grid(row=0, column=6, rowspan=2,
                                                                                 padx=(6, 0), sticky="ns")
        # the reserve dancer who automatically replaces this (main-cast) dancer when he cannot come
        self.e_sub = tk.StringVar()
        self.sub_map = {}
        tk.Label(edit, text="Rezerves dejotājs", bg=CREAM, fg=NAVY).grid(row=1, column=0, columnspan=2, sticky="w",
                                                                          pady=(6, 0))
        self.sub_cb = ttk.Combobox(edit, textvariable=self.e_sub, state="readonly", width=40)
        self.sub_cb.grid(row=1, column=2, columnspan=4, sticky="ew", padx=(4, 4), pady=(6, 0))
        self.sub_cb.configure(state="disabled")
        self.cast.bind("<<TreeviewSelect>>", lambda e: self.load_entry())

        bottom = tk.Frame(self, bg=CREAM)
        bottom.pack(fill="x", pady=(10, 0))
        tk.Label(bottom, text="Dubultklikšķis kreisajā sarakstā — pievienot pamatsastāvam; labajā sarakstā — "
                              "izņemt no dejas.\nPāra numurs palīdz sastādīt pārus "
                              "(vienam pārim abiem dejotājiem — viens numurs).\n"
                              "Pamatsastāva dejotājam var norādīt rezerves dejotāju: ja notikumam viņš atbildējis "
                              "“Nebūs”, viņa vietā automātiski tiek ņemts rezerves dejotājs.\n"
                              "Citas grupas dejotāju dejā var ielikt ar “＋ Rādīt arī citu grupu dejotājus” (vai grupas "
                              "izvēli “Visi”); sastāvā tas ir iezīmēts violetā krāsā ar “(cita)”.", justify="left",
                 font=("Segoe UI", 8, "italic"), bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Button(bottom, text="Aizvērt", style="Accent.TButton", command=self.close).pack(side="right")
        self.bind("<Escape>", lambda e: self.close())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        self.after(100, lambda: fit_min_size(self))

    def close(self):
        self.app.refresh(select=self.dance_id)
        self.destroy()
        if self.on_close:
            self.on_close()

    def refresh(self, select=None):
        db = self.app.db
        counts = dict(db.q("SELECT dancer_id, COUNT(*) FROM dance_cast c JOIN dances d ON d.id = c.dance_id "
                           "WHERE d.status IN (?, ?) GROUP BY dancer_id", (DANCE_IN_REPERTOIRE, DANCE_LEARNING)))
        in_cast = db.q("SELECT c.id, c.dancer_id, d.name, d.gender, c.role, c.pair_no, c.notes, "
                       + active_dancer_sql("d") + " FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                       "WHERE c.dance_id=?", (self.dance_id,))
        taken = {r[1] for r in in_cast}

        term = _norm(self.search.get())
        cond = " WHERE " + (active_dancer_sql("dancers") if self.only_active.get() else dancer_role_sql("dancers"))
        pool = []
        for did, name, gender, group in db.q("SELECT id, name, gender, dancer_group FROM dancers" + cond):
            if did in taken:
                continue
            if self.f_gender.get() != ALL and gender != self.f_gender.get():
                continue
            if self.f_group.get() != ALL and (group or "") != self.f_group.get():
                continue
            if term and term not in _norm(name):
                continue
            pool.append((did, name, gender, group or ""))
        pool.sort(key=lambda r: _norm(r[1]))
        self.pool.delete(*self.pool.get_children())
        # the dance's own group first, then the other groups
        pool.sort(key=lambda r: (bool(self.dance_group) and r[3] != self.dance_group, _norm(r[1])))
        for did, name, gender, group in pool:
            other = bool(self.dance_group and group and group != self.dance_group)
            self.pool.insert("", "end", iid=str(did), tags=("othergroup",) if other else (),
                             values=(name, group_text(group, self.dance_group), gender or "", counts.get(did, 0)))
        if getattr(self, "other_btn", None) is not None:
            self.other_btn.configure(text="− Rādīt tikai dejas grupas dejotājus" if self.f_group.get() != self.dance_group
                                     else "＋ Rādīt arī citu grupu dejotājus")

        def pair_key(r):
            m = re.match(r"\d+", r[5] or "")
            return (r[4] != ROLE_MAIN, int(m.group(0)) if m else 9999, r[5] or "", r[3] != GENDER_FEMALE,
                    _norm(r[2]))
        keep = select or (self.cast.selection()[0] if self.cast.selection() else None)
        self.cast.delete(*self.cast.get_children())
        status_by_id = status_notes(self.app.db)
        subs, covers = substitute_info(db, self.dance_id)
        groups = dict(db.q("SELECT id, dancer_group FROM dancers"))
        for cid, did, name, gender, role, pair_no, notes, active in sorted(in_cast, key=pair_key):
            other = bool(self.dance_group and groups.get(did) and groups.get(did) != self.dance_group)
            tags = (role or ROLE_MAIN,) + (() if active else ("inactive",)) + (("othergroup",) if other else ())
            self.cast.insert("", "end", iid=str(cid), tags=tags,
                             values=(pair_no or "", name + ("" if active else status_by_id.get(did, "")),
                                     group_text(groups.get(did), self.dance_group), gender or "",
                                     role or ROLE_MAIN, substitute_text(did, role, subs, covers), notes or ""))
        if keep is not None and self.cast.exists(str(keep)):
            self.cast.selection_set(str(keep))
            self.cast.see(str(keep))
        self.update_need(in_cast)

    def toggle_other_groups(self):
        """Show every group (to put a dancer from another group into the dance by hand) or only the dance's group."""
        self.f_group.set(ALL if self.f_group.get() == self.dance_group else self.dance_group)
        self.refresh()

    def update_need(self, in_cast):
        text, colour = cast_status(in_cast, self.men_count, self.women_count)
        self.need_var.set(text)
        self.need_lbl.configure(fg=colour)

    def add(self, role):
        sel = self.pool.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju kreisajā sarakstā "
                                          "(ar Ctrl vai Shift var izvēlēties vairākus).", parent=self)
            return
        for did in sel:
            self.app.db.x("INSERT OR IGNORE INTO dance_cast (dance_id, dancer_id, role) VALUES (?, ?, ?)",
                          (self.dance_id, int(did), role))
        self.refresh()

    def remove_clicked(self, event):
        """Double click in the cast list: take that dancer out of the dance."""
        row = self.cast.identify_row(event.y)
        if not row:
            return
        self.delete_entry(int(row))
        self.clear_entry()
        self.refresh()

    def delete_entry(self, cid):
        found = self.app.db.q("SELECT dancer_id FROM dance_cast WHERE id=?", (cid,))
        self.app.db.x("DELETE FROM dance_cast WHERE id=?", (cid,))
        if found:
            clear_substitute(self.app.db, self.dance_id, found[0][0])

    def clear_entry(self):
        self.e_pair.set("")
        self.e_role.set("")
        self.e_notes.set("")
        self.e_sub.set("")
        self.sub_map = {}
        self.sub_cb.configure(values=[], state="disabled")

    def remove(self):
        sel = self.cast.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sastāva sarakstā.", parent=self)
            return
        for cid in sel:
            self.delete_entry(int(cid))
        self.clear_entry()
        self.refresh()

    NO_SUB = "— nav —"

    def substitute_choices(self, dancer_id):
        """Reserve dancers of this dance first, then other active dancers of the same gender who are
        not in this dance. -> {label: dancer id}"""
        db = self.app.db
        gender = (db.q("SELECT gender FROM dancers WHERE id=?", (dancer_id,)) or [("",)])[0][0]
        cast = {d: r for d, r in db.q("SELECT dancer_id, role FROM dance_cast WHERE dance_id=?", (self.dance_id,))}
        reserves, others = [], []
        for did, name, g, grp in db.q("SELECT id, name, gender, dancer_group FROM dancers WHERE "
                                      + active_dancer_sql("dancers")
                                      + " OR id IN (SELECT dancer_id FROM dance_cast WHERE dance_id=?)", (self.dance_id,)):
            if self.dance_group and grp and grp != self.dance_group:
                name = f"{name} [{grp}]"
            if did == dancer_id:
                continue
            if cast.get(did) == ROLE_RESERVE:
                reserves.append((did, name + "  (šīs dejas rezerve)"))
            elif did not in cast and (not gender or g == gender):
                others.append((did, name))
        choices = {self.NO_SUB: None}
        for did, label in sorted(reserves, key=lambda r: _norm(r[1])) + sorted(others, key=lambda r: _norm(r[1])):
            if label in choices:
                label = f"{label} (#{did})"
            choices[label] = did
        return choices

    def load_entry(self):
        sel = self.cast.selection()
        if len(sel) != 1:
            return
        row = self.app.db.q("SELECT pair_no, role, notes, dancer_id, substitute_id FROM dance_cast WHERE id=?",
                            (int(sel[0]),))
        if row:
            pair_no, role, notes, dancer_id, sub = row[0]
            self.e_pair.set(pair_no or "")
            self.e_role.set(role or ROLE_MAIN)
            self.e_notes.set(notes or "")
            if (role or ROLE_MAIN) == ROLE_MAIN:
                self.sub_map = self.substitute_choices(dancer_id)
                self.sub_cb.configure(values=list(self.sub_map), state="readonly")
                self.e_sub.set(next((k for k, v in self.sub_map.items() if v == sub and v is not None), self.NO_SUB))
            else:
                self.sub_map = {}
                self.sub_cb.configure(values=[], state="disabled")
                self.e_sub.set("(tikai pamatsastāva dejotājam)")

    def edit_entry(self):
        self.load_entry()

    def save_entry(self):
        sel = self.cast.selection()
        if len(sel) != 1:
            messagebox.showinfo("Izvēle", "Izvēlieties vienu dejotāju sastāva sarakstā.", parent=self)
            return
        db = self.app.db
        role = self.e_role.get() or ROLE_MAIN
        sub = self.sub_map.get(self.e_sub.get()) if role == ROLE_MAIN else None
        if sub is not None and not db.q("SELECT 1 FROM dance_cast WHERE dance_id=? AND dancer_id=?",
                                        (self.dance_id, sub)):
            # a reserve dancer from outside the dance joins it as "Rezerve"
            db.x("INSERT INTO dance_cast (dance_id, dancer_id, role) VALUES (?, ?, ?)",
                 (self.dance_id, sub, ROLE_RESERVE))
        db.x("UPDATE dance_cast SET pair_no=?, role=?, notes=?, substitute_id=? WHERE id=?",
             (self.e_pair.get().strip(), role, self.e_notes.get().strip(), sub, int(sel[0])))
        self.refresh(select=sel[0])
        self.load_entry()


# --------------------------------------------------------------------------
# Dancers overview: who dances what
# --------------------------------------------------------------------------
class DancerOverview(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title("Dejotāju noslodze")
        self.transient(app.root)
        tk.Label(self, text="Dejotāju noslodze", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text="Cik dejās (repertuārā un procesā) piedalās katrs aktīvais dejotājs.",
                 font=("Segoe UI", 9, "italic"), bg=CREAM, fg=NAVY).pack(anchor="w", pady=(0, 8))
        holder = tk.Frame(self, bg=CREAM)
        holder.pack(fill="both", expand=True)
        cols = (("name", "Dejotājs", 180), ("gender", "Dzimums", 80), ("main", "Pamatsastāvā", 95),
                ("reserve", "Rezervē", 70), ("dances", "Dejas", 460))
        tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings", height=20)
        for key, text, width in cols:
            tree.heading(key, text=text)
            tree.column(key, width=width, minwidth=40, stretch=key == "dances")
        tree.tag_configure("none", foreground=RED)
        make_tree_with_scroll(holder, tree)

        db = app.db
        rows = db.q("SELECT d.id, d.name, d.gender, c.role, x.title FROM dancers d "
                    "LEFT JOIN dance_cast c ON c.dancer_id = d.id "
                    "LEFT JOIN dances x ON x.id = c.dance_id AND x.status IN (?, ?) "
                    "WHERE " + active_dancer_sql("d"), (DANCE_IN_REPERTOIRE, DANCE_LEARNING))
        people = {}
        for did, name, gender, role, title in rows:
            p = people.setdefault(did, {"name": name, "gender": gender or "", "main": [], "reserve": []})
            if title:
                p["reserve" if role == ROLE_RESERVE else "main"].append(title)
        for p in sorted(people.values(), key=lambda p: (-len(p["main"]), _norm(p["name"]))):
            titles = sorted(p["main"], key=_norm) + [t + " (rez.)" for t in sorted(p["reserve"], key=_norm)]
            tree.insert("", "end", values=(p["name"], p["gender"], len(p["main"]), len(p["reserve"]),
                                           ", ".join(titles) or "—"),
                        tags=() if titles else ("none",))
        tk.Label(self, text=f"Aktīvo dejotāju: {len(people)}. Sarkanā krāsā — dejotāji, kuri vēl nav "
                            "iekļauti nevienā dejā.", font=("Segoe UI", 9), bg=CREAM, fg=NAVY).pack(
            anchor="w", pady=(6, 0))
        ttk.Button(self, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(anchor="e", pady=(6, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        self.after(100, lambda: fit_min_size(self))


# --------------------------------------------------------------------------
# Import from Excel / CSV
# --------------------------------------------------------------------------
IMPORT_ALIASES = {
    "title": ["deja", "dejas nosaukums", "nosaukums", "dance", "title", "name"],
    "dance_group": ["grupa", "dejas grupa", "group"],
    "choreographer": ["horeografs", "horeografe", "horeografija", "horeografs e", "autors", "choreographer"],
    "music": ["muzika", "muzikas autors", "komponists", "apdare", "music", "composer"],
    "dance_type": ["veids", "dejas veids", "zanrs", "type"],
    "production": ["uzvedums", "uzveduma nosaukums", "production", "show"],
    "lineup": ["sastavs", "sastava veids", "lineup"],
    "men_count": ["puisi", "puisu skaits", "puisu sk", "viriesi", "viriesu skaits", "boys", "men"],
    "women_count": ["meitas", "meitu skaits", "meitu sk", "meitenes", "meitenu skaits", "sievietes",
                    "sieviesu skaits", "girls", "women"],
    "pairs": ["pari", "paru skaits", "pairs"],
    "duration": ["ilgums", "garums", "laiks", "duration", "length"],
    "costume_set": ["terps", "terpi", "terpu komplekts", "komplekts", "costume"],
    "status": ["statuss", "status"],
    "learned_date": ["iestudeta", "iestudesanas datums", "iestudets", "datums", "learned"],
    "video": ["video", "saite", "links", "link"],
    "description": ["apraksts", "description"],
    "notes": ["piezimes", "notes"],
}


def import_dances(db, rows):
    aliases = {k: {_norm(a) for a in v} for k, v in IMPORT_ALIASES.items()}
    header, mp, found = None, {}, []
    for i, row in enumerate(rows):
        if any(c for c in row):
            header = i
            for col, cell in enumerate(row):
                n = _norm(cell)
                for field, names in aliases.items():
                    if field not in mp and n in names:
                        mp[field] = col
            found = [c for c in row if c]
            break
    if header is None or "title" not in mp:
        return {"error": "Failā nav atrasta kolonna “Deja” (vai “Dejas nosaukums”).\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}

    def cell(row, field):
        col = mp.get(field)
        return row[col].strip() if col is not None and col < len(row) else ""

    existing = {(_norm(t), _norm(c)) for t, c in db.q("SELECT title, choreographer FROM dances")}
    added, skipped = 0, []
    for i in range(header + 1, len(rows)):
        row = rows[i]
        if not any(row):
            continue
        v = {f: cell(row, f) for f in FIELDS}
        if not v["title"]:
            skipped.append((i + 1, "nav dejas nosaukuma"))
            continue
        status = normalize_dance_status(v["status"])
        if status is None:
            skipped.append((i + 1, f"nezināms statuss “{v['status']}”"))
            continue
        v["status"] = status
        dance_type = normalize_dance_type(v["dance_type"])
        if dance_type is None:
            skipped.append((i + 1, f"nezināms dejas veids “{v['dance_type']}”"))
            continue
        v["dance_type"] = dance_type or TYPE_STAGE
        if v["dance_type"] == TYPE_SHOW and not v["production"]:
            skipped.append((i + 1, "uzveduma dejai nav norādīts uzvedums"))
            continue
        if v["dance_type"] != TYPE_SHOW:
            v["production"] = ""
        lineup = normalize_lineup(v["lineup"])
        if lineup is None:
            skipped.append((i + 1, f"nezināms sastāvs “{v['lineup']}”"))
            continue
        v["lineup"] = lineup or LINEUP_MIXED
        group = next((g for g in DANCER_GROUPS if _norm(g) == _norm(v["dance_group"])), None)
        if v["dance_group"] and group is None:
            skipped.append((i + 1, f"nezināma grupa “{v['dance_group']}” (der: {', '.join(DANCER_GROUPS)})"))
            continue
        v["dance_group"] = group or DEFAULT_DANCER_GROUP
        for key in ("men_count", "women_count"):
            m = re.search(r"\d{1,3}", v[key])
            v[key] = str(int(m.group(0))) if m and int(m.group(0)) else ""
        m = re.search(r"\d{1,3}", cell(row, "pairs"))  # older files: one "pāri" column
        if m and int(m.group(0)) and not v["men_count"] and not v["women_count"]:
            n = int(m.group(0))
            men, women = {LINEUP_WOMEN: (0, 2 * n), LINEUP_MEN: (2 * n, 0)}.get(v["lineup"], (n, n))
            v["men_count"], v["women_count"] = (str(men) if men else ""), (str(women) if women else "")
        if v["lineup"] == LINEUP_WOMEN:
            v["men_count"] = ""
        elif v["lineup"] == LINEUP_MEN:
            v["women_count"] = ""
        duration = parse_duration(v["duration"])
        if duration is None:
            skipped.append((i + 1, f"nesaprotams ilgums “{v['duration']}”"))
            continue
        v["duration"] = duration
        learned = parse_date(v["learned_date"])
        if learned is None:
            skipped.append((i + 1, f"nepareizs datums “{v['learned_date']}”"))
            continue
        v["learned_date"] = learned
        key = (_norm(v["title"]), _norm(v["choreographer"]))
        if key in existing:
            skipped.append((i + 1, f"deja “{v['title']}” jau ir sarakstā"))
            continue
        save_dance(db, v)
        existing.add(key)
        added += 1
    return {"error": None, "added": added, "skipped": skipped}


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
        s.configure("TFrame", background=CREAM)
        s.configure("TLabel", background=CREAM, foreground=NAVY)
        s.configure("TCheckbutton", background=CREAM, foreground=NAVY)
        s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
        s.map("TButton", background=[("active", GOLD)])
        s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Danger.TButton", background=CREAM_DARK, foreground=RED, font=("Segoe UI", 10, "bold"))
        s.map("Danger.TButton", background=[("active", RED)], foreground=[("active", CREAM)])
        s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                    bordercolor=GOLD)
        s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                    padding=6)
        s.map("Treeview.Heading", background=[("active", RED)])
        s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        header = tk.Frame(self.root, bg=NAVY)
        header.pack(fill="x")
        header.columnconfigure(0, weight=1, uniform="h")
        header.columnconfigure(2, weight=1, uniform="h")
        left = tk.Frame(header, bg=NAVY)
        left.grid(row=0, column=0, sticky="w")
        logo = module_logo(left, "deju_purs", on_click=self.show_main)
        if logo is not None:
            logo.pack(side="left", padx=(16, 0), pady=6)
        title_box = tk.Frame(left, bg=NAVY)
        title_box.pack(side="left", padx=(12 if logo is not None else 20, 12), pady=12)
        tk.Label(title_box, text=PROGRAM_NAME, font=("Georgia", 20, "bold"), bg=NAVY, fg=CREAM).pack(anchor="w")
        centre = tk.Frame(header, bg=NAVY)
        centre.place(relx=0.5, rely=0.5, anchor="center")
        # collective name with the collective logo underneath
        self.group_logo = group_logo(150, 40)
        tk.Label(centre, text=read_setting("app.group_name", "Tautas deju kolektīvs"),
                 font=("Georgia", 14, "italic"), bg=NAVY, fg=GOLD).pack(
            side="top", pady=(4, 2) if self.group_logo is not None else 12)
        if self.group_logo is not None:
            tk.Label(centre, image=self.group_logo, bg=NAVY).pack(side="top", pady=(0, 4))
        right = tk.Frame(header, bg=NAVY)
        right.grid(row=0, column=2, sticky="e", padx=14, pady=10)
        try:
            self.power_icon = tk.PhotoImage(data=HOME_ICON_B64 if self.on_exit is not None else POWER_ICON_B64)
        except Exception:
            self.power_icon = None
        embedded = self.on_exit is not None
        tk.Button(right, text=" Atgriezties moduļu izvēlē" if embedded else " Beigt darbu",
                  image=self.power_icon or "", compound="left",
                  command=self.on_exit if embedded else self.root.destroy, font=("Segoe UI", 11, "bold"),
                  bg=NAVY, fg=GOLD, activebackground=RED, activeforeground=CREAM, relief="flat", bd=0,
                  highlightthickness=2, highlightbackground=GOLD, highlightcolor=GOLD, cursor="hand2",
                  padx=12, pady=3).pack()
        tk.Frame(self.root, bg=GOLD, height=4).pack(fill="x")
        copyright_footer(self.root)

        # summary cards
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=18, pady=(14, 6))
        self.card_vars = {}
        for i, (key, title, colour) in enumerate([
                ("total", "Kopā deju", NAVY),
                ("repertoire", "Repertuārā", GREEN),
                ("learning", "Procesā", AMBER),
                ("length", "Repertuāra kopējais ilgums", GOLD),
                ("unfilled", "Dejas ar nepilnu sastāvu", RED)]):
            card = tk.Frame(cards, bg=WHITE, highlightbackground=colour, highlightthickness=3)
            card.grid(row=0, column=i, padx=6, sticky="ew")
            cards.columnconfigure(i, weight=1, uniform="card")
            var = tk.StringVar(value="—")
            self.card_vars[key] = var
            tk.Label(card, textvariable=var, font=("Georgia", 24, "bold"), bg=WHITE, fg=colour).pack(pady=(6, 0))
            tk.Label(card, text=title, font=("Segoe UI", 9), bg=WHITE, fg=NAVY).pack(pady=(0, 6))

        # filters
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=18, pady=(8, 4))
        self.search = tk.StringVar()
        self.f_status = tk.StringVar(value=ALL)
        self.f_type = tk.StringVar(value=ALL)
        self.f_lineup = tk.StringVar(value=ALL)
        self.f_group = tk.StringVar(value=ALL)
        ttk.Label(bar, text="Meklēt:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=22).pack(side="left", padx=(4, 14))
        self.search.trace_add("write", lambda *a: self.refresh())
        ttk.Label(bar, text="Statuss:").pack(side="left")
        scb = ttk.Combobox(bar, textvariable=self.f_status, values=[ALL] + DANCE_STATUSES, state="readonly",
                           width=17)
        scb.pack(side="left", padx=(4, 14))
        ttk.Label(bar, text="Veids:").pack(side="left")
        self.type_cb = ttk.Combobox(bar, textvariable=self.f_type, state="readonly", width=16)
        self.type_cb.pack(side="left", padx=(4, 14))
        ttk.Label(bar, text="Sastāvs:").pack(side="left")
        lcb = ttk.Combobox(bar, textvariable=self.f_lineup, values=[ALL] + LINEUPS, state="readonly", width=9)
        lcb.pack(side="left", padx=(4, 14))
        ttk.Label(bar, text="Grupa:").pack(side="left")
        grcb = ttk.Combobox(bar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=9)
        grcb.pack(side="left", padx=4)
        for cb in (scb, self.type_cb, lcb, grcb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Button(bar, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")

        btns = ttk.Frame(self.root)
        btns.pack(fill="x", padx=18, pady=4)
        acc = piekluve.current()
        add_btn = ttk.Button(btns, text="＋ Jauna deja", style="Accent.TButton", command=lambda: DanceForm(self))
        add_btn.pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="Dejotāju noslodze", command=lambda: DancerOverview(self)).pack(side="left", padx=3)
        imp_btn = ttk.Button(btns, text="⇪ Importēt no Excel", command=self.run_import)
        imp_btn.pack(side="left", padx=3)
        if not acc.can_edit("deju_purs"):
            add_btn.configure(state="disabled")
        if not acc.edits_all("deju_purs"):
            imp_btn.configure(state="disabled")
            note = ("tikai skatīšanai" if acc.view_only("deju_purs") else
                    "labot var " + acc.scope_text("deju_purs") + "s dejas")
            if acc.costumes and acc.view_only("deju_purs"):
                note = "var mainīt tikai dejas tērpu veidus"
            tk.Label(btns, text="🔒 " + note, bg=CREAM, fg=RED,
                     font=("Segoe UI", 9, "bold")).pack(side="left", padx=(12, 0))
        self.count_var = tk.StringVar()
        tk.Label(btns, textvariable=self.count_var, bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(side="right")

        # list of dances + description of the selected one
        pane = ttk.Frame(self.root)
        pane.pack(fill="both", expand=True, padx=18, pady=(4, 6))
        pane.rowconfigure(0, weight=1)
        pane.columnconfigure(0, weight=1)
        holder = ttk.Frame(pane)
        holder.grid(row=0, column=0, sticky="nsew")
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in COLUMNS], show="headings")
        for key, title, width in COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=40, anchor="w", stretch=key == "title")
        self.tree.tag_configure(DANCE_IN_REPERTOIRE, foreground=NAVY)
        self.tree.tag_configure(DANCE_LEARNING, foreground=AMBER)
        self.tree.tag_configure(DANCE_RESTING, foreground=GREY)
        self.tree.tag_configure(DANCE_ARCHIVED, foreground=GREY)
        self.tree.bind("<Double-1>", self.open_dance)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_details())
        make_tree_with_scroll(holder, self.tree)

        details = tk.Frame(pane, bg=WHITE, highlightbackground=GOLD, highlightthickness=1)
        details.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        self.detail_title = tk.Label(details, text="", font=("Georgia", 12, "bold"), bg=WHITE, fg=RED, anchor="w")
        self.detail_title.pack(fill="x", padx=10, pady=(6, 0))
        self.detail_text = tk.Text(details, height=4, wrap="word", relief="flat", bg=WHITE, fg=NAVY,
                                   font=("Segoe UI", 10), padx=8, pady=4)
        self.detail_text.pack(fill="x")
        self.detail_text.configure(state="disabled")

        self.sort_key, self.sort_desc = "title", False
        self.refresh()

    # ---- data -------------------------------------------------------------
    def show_main(self):
        """Module logo: back to the main view — all dances, no filters, top of the list."""
        self.clear_filters()
        self.tree.selection_remove(self.tree.selection())
        self.tree.yview_moveto(0)
        self.show_details()

    def clear_filters(self):
        self.search.set("")
        self.f_status.set(ALL)
        self.f_type.set(ALL)
        self.f_lineup.set(ALL)
        self.f_group.set(ALL)
        self.refresh()

    def sort_by(self, key):
        self.sort_desc = not self.sort_desc if key == self.sort_key else False
        self.sort_key = key
        self.refresh()

    def load_records(self):
        db = self.db
        cast = {}
        for dance_id, gender, role in db.q("SELECT c.dance_id, d.gender, c.role FROM dance_cast c "
                                           "JOIN dancers d ON d.id = c.dancer_id WHERE " + active_dancer_sql("d")):
            c = cast.setdefault(dance_id, {"women": 0, "men": 0, "reserve": 0})
            if role == ROLE_RESERVE:
                c["reserve"] += 1
            elif gender == GENDER_FEMALE:
                c["women"] += 1
            elif gender == GENDER_MALE:
                c["men"] += 1
        rehearsals = db.rehearsal_stats()
        records = []
        for row in db.q("SELECT id, " + ", ".join(FIELDS) + " FROM dances"):
            r = dict(zip(("id",) + FIELDS, row))
            for k in FIELDS:
                r[k] = r[k] or ""
            if r["status"] not in DANCE_STATUSES:
                r["status"] = DANCE_IN_REPERTOIRE
            c = cast.get(r["id"], {"women": 0, "men": 0, "reserve": 0})
            r["cast_main"] = c["women"] + c["men"]
            r["cast_reserve"] = c["reserve"]
            r["rehearsed"] = rehearsals.get(r["id"], {}).get("season", 0)
            need = needed_by_gender(r["men_count"], r["women_count"])
            r["counts"] = counts_text(r["men_count"], r["women_count"])
            r["unfilled"] = bool(need) and (c["women"] < need[0] or c["men"] < need[1])
            r["cast"] = (f"{r['cast_main']}" + (f" + {c['reserve']} rez." if c["reserve"] else "")) \
                if (r["cast_main"] or c["reserve"]) else "—"
            records.append(r)
        return records

    def refresh(self, select=None):
        records = self.load_records()
        self.update_cards(records)
        self.type_cb.configure(values=[ALL] + DANCE_TYPES)
        if self.f_type.get() not in [ALL] + DANCE_TYPES:
            self.f_type.set(ALL)

        term = _norm(self.search.get())
        shown = []
        for r in records:
            if self.f_status.get() != ALL and r["status"] != self.f_status.get():
                continue
            if self.f_type.get() != ALL and r["dance_type"] != self.f_type.get():
                continue
            if self.f_lineup.get() != ALL and r["lineup"] != self.f_lineup.get():
                continue
            if self.f_group.get() != ALL and r["dance_group"] != self.f_group.get():
                continue
            if term and term not in _norm(" ".join(r[k] for k in ("title", "dance_group", "choreographer", "music", "production",
                                                                    "costume_set", "description", "notes"))):
                continue
            shown.append(r)

        def sort_value(r):
            if self.sort_key == "duration":
                v = r[self.sort_key]
                return (v == "", int(v) if v.isdigit() else 0)
            if self.sort_key == "counts":
                need = needed_by_gender(r["men_count"], r["women_count"])
                return (need is None, sum(need) if need else 0)
            if self.sort_key == "rehearsed":
                return (False, r["rehearsed"])
            if self.sort_key == "cast":
                return (False, r["cast_main"] * 1000 + r["cast_reserve"])
            if self.sort_key == "status":
                return (False, DANCE_STATUSES.index(r["status"]))
            v = r[self.sort_key]
            return (v == "", _norm(v))
        shown.sort(key=lambda r: _norm(r["title"]))
        shown.sort(key=sort_value, reverse=self.sort_desc)

        keep = select or (self.tree.selection()[0] if self.tree.selection() else None)
        self.tree.delete(*self.tree.get_children())
        for r in shown:
            values = []
            for key, _t, _w in COLUMNS:
                v = r[key]
                if key == "dance_type":
                    v = type_text(v, r["production"])
                elif key == "duration":
                    v = show_duration(v)
                elif key == "learned_date":
                    v = show_date(v)
                elif key == "rehearsed":
                    v = v or "—"
                elif key == "cast" and r["unfilled"] and r["status"] in (DANCE_IN_REPERTOIRE, DANCE_LEARNING):
                    v = f"{v}  ⚠"
                values.append(v)
            self.tree.insert("", "end", iid=str(r["id"]), values=values, tags=(r["status"],))
        if keep is not None and self.tree.exists(str(keep)):
            self.tree.selection_set(str(keep))
            self.tree.see(str(keep))
        self.count_var.set(f"Rādītas {len(shown)} no {len(records)} dejām. "
                           "Dubultklikšķis uz dejas — sastāvs, labošana, dzēšana; klikšķis uz virsraksta — kārtot. "
                           "“Mēģināta” — mēģinājumu skaits šajā sezonā (no Cītības pūra).")
        self.show_details()

    def update_cards(self, records):
        rep = [r for r in records if r["status"] == DANCE_IN_REPERTOIRE]
        learning = [r for r in records if r["status"] == DANCE_LEARNING]
        total = sum(int(r["duration"]) for r in rep if r["duration"].isdigit())
        unfilled = sum(1 for r in rep + learning if r["unfilled"])
        self.card_vars["total"].set(str(len(records)))
        self.card_vars["repertoire"].set(str(len(rep)))
        self.card_vars["learning"].set(str(len(learning)))
        self.card_vars["length"].set(show_total(total))
        self.card_vars["unfilled"].set(str(unfilled))

    def show_details(self):
        sel = self.tree.selection()
        text, title = "", ""
        if sel:
            row = self.db.q("SELECT title, description, notes, video, costume_set, dance_type, production "
                            "FROM dances WHERE id=?", (int(sel[0]),))
            if row:
                title, desc, notes, video, costume, dance_type, production = row[0]
                parts = [desc.strip() if (desc or "").strip() else "Apraksts nav ievadīts."]
                if dance_type == TYPE_SHOW and (production or "").strip():
                    parts.insert(0, "Uzvedums: " + production.strip())
                costumes = self.db.dance_costumes(int(sel[0]))
                wear = [f"{'sievietēm' if g == GENDER_FEMALE else 'vīriešiem'} — {', '.join(n)}"
                        for g, n in ((x, costumes.get(x, [])) for x in (GENDER_FEMALE, GENDER_MALE)) if n]
                if wear:
                    parts.append("Tērpi: " + "; ".join(wear))
                reh = self.db.rehearsal_stats().get(int(sel[0]))
                if reh:
                    line = (f"Mēģināta: šajā sezonā {reh['season']}, pavisam {reh['total']} reizes"
                            + (f"; pēdējoreiz {show_date(reh['last'])}" if reh["last"] else "") + ".")
                    if reh["performed"]:
                        line += f" Dejota koncertos, skatēs u. c.: {reh['performed']} reizes."
                    parts.append(line)
                if (notes or "").strip():
                    parts.append("Piezīmes: " + notes.strip())
                if (costume or "").strip():
                    parts.append("Tērpu komplekts: " + costume.strip())
                if (video or "").strip():
                    parts.append("Saite: " + video.strip())
                text = "\n".join(parts)
        else:
            title = "Izvēlieties deju, lai redzētu tās aprakstu"
        self.detail_title.configure(text=title)
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", tk.END)
        self.detail_text.insert("1.0", text)
        self.detail_text.configure(state="disabled")

    def selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties deju sarakstā.", parent=self.root)
            return None
        return int(sel[0])

    def open_dance(self, event):
        """Double click on a dance: the dance window (cast, editing, deleting)."""
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            DanceForm(self, int(row))

    def delete_dance(self, did, parent=None):
        """Ask and delete a dance with its cast. True when deleted."""
        title, group = self.db.q("SELECT title, dance_group FROM dances WHERE id=?", (did,))[0]
        if not piekluve.current().can_edit("deju_purs", group=group):
            return piekluve.deny(parent or self.root, "Šo deju jūsu loma nevar dzēst.")
        cast = self.db.q("SELECT COUNT(*) FROM dance_cast WHERE dance_id=?", (did,))[0][0]
        extra = f"\n\nTiks dzēsts arī dejas sastāvs ({cast} dejotāji)." if cast else ""
        if not messagebox.askyesno(
                "Dzēst", f"Dzēst deju “{title}”?{extra}\n\nJa deju vienkārši vairs nedejo, labāk nomainiet "
                         f"statusu uz “{DANCE_ARCHIVED}”.", parent=parent or self.root):
            return False
        self.db.x("DELETE FROM dance_cast WHERE dance_id=?", (did,))
        self.db.x("DELETE FROM dance_costumes WHERE dance_id=?", (did,))
        self.db.x("DELETE FROM dances WHERE id=?", (did,))
        self.refresh()
        return True

    def run_import(self):
        if not piekluve.current().edits_all("deju_purs"):
            return piekluve.deny(self.root, "Importēt dejas var tikai lietotāji, kas drīkst labot visas grupas.")
        cols = ["Deja", f"Grupa ({' / '.join(DANCER_GROUPS)}; ja nav — {DEFAULT_DANCER_GROUP})", "Horeogrāfs", "Mūzika",
                "Veids (latviešu skatuviskā deja / uzveduma deja / rotaļdeja)", "Uzvedums (uzveduma dejai)", "Sastāvs (jaukts / sieviešu / vīriešu)", "Puišu skaits", "Meitu skaits",
                "Ilgums (piem. 3:45)", "Tērpu komplekts", "Statuss (repertuārā / procesā / atpūtā / arhīvā)",
                "Iestudēta (DD.MM.GGGG)", "Apraksts", "Piezīmes"]
        info = ("Excel faila pirmajā rindā jābūt kolonnu nosaukumiem:\n\n  • " + "\n  • ".join(cols) +
                "\n\nObligāta ir kolonna “Deja”, bet uzveduma dejai — arī “Uzvedums”. Jau esošās dejas (tas pats nosaukums un horeogrāfs) "
                "tiks izlaistas. Ja statuss nav norādīts, deja būs repertuārā.")
        if not messagebox.askokcancel("Importēt no Excel", info, parent=self.root):
            return
        path = filedialog.askopenfilename(parent=self.root, title="Izvēlieties Excel failu",
                                          filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            result = import_dances(self.db, read_table(path))
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self.root)
            return
        if result["error"]:
            messagebox.showerror("Importa kļūda", result["error"], parent=self.root)
            return
        self.refresh()
        text = f"Pievienotas dejas: {result['added']}\nIzlaistas rindas: {len(result['skipped'])}"
        if result["skipped"]:
            text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
            if len(result["skipped"]) > 12:
                text += f"\n… un vēl {len(result['skipped']) - 12}"
        (messagebox.showwarning if result["skipped"] else messagebox.showinfo)("Imports pabeigts", text,
                                                                              parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
