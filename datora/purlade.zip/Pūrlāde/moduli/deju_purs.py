#!/usr/bin/env python3
"""
Pūrlāde — modulis "Deju pūrs" (deju / repertuāra uzskaitei)

Šeit tiek uzturēts kolektīva repertuārs: katra deja ar horeogrāfu, mūziku,
veidu, puišu un meitu skaitu, ilgumu, tērpu komplektu un aprakstu, kā arī dejas
sastāvs — kuri dejotāji (no Kopas pūra) to dejo pamatsastāvā vai rezervē.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/deju_purs.py
"""

import re
import sqlite3
import traceback
from datetime import date
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve
try:  # started from Pūrlāde
    from moduli.kopeja import ensure_cast_substitutes, DANCER_GROUPS, DEFAULT_DANCER_GROUP, dance_lineup
except ImportError:  # started directly from the moduli folder
    from kopeja import ensure_cast_substitutes, DANCER_GROUPS, DEFAULT_DANCER_GROUP, dance_lineup
try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible, ensure_dancer_schema,
                               full_name, parse_date, read_table, _norm, active_dancer_sql, dancer_role_sql,
                               GENDERS, GENDER_MALE, GENDER_FEMALE, STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible, ensure_dancer_schema,
                        full_name, parse_date, read_table, _norm, active_dancer_sql, dancer_role_sql,
                        GENDERS, GENDER_MALE, GENDER_FEMALE, STATUS_ACTIVE, POWER_ICON_B64, HOME_ICON_B64,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

DANCE_GROUP_SEEDED = "dance_group.initial"   # settings key: existing dances were given group A

PROGRAM_NAME = "Deju pūrs"
APP_VERSION = "0.3.8"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Deju uzskaite: repertuārs, dejas apraksts, horeogrāfs, dejotāju sastāvs",
    "letter": "D",
    "color": NAVY,
}

# ---- choices --------------------------------------------------------------
DANCE_IN_REPERTOIRE = "Repertuārā"
DANCE_LEARNING = "Procesā"
OLD_DANCE_LEARNING = ("Iestudējumā", "Apgūšanas procesā")  # earlier names, renamed in the database on start
DANCE_RESTING = "Atpūtā"
DANCE_ARCHIVED = "Arhīvā"
DANCE_STATUSES = [DANCE_IN_REPERTOIRE, DANCE_LEARNING, DANCE_RESTING, DANCE_ARCHIVED]

TYPE_STAGE = "Latviešu skatuviskā deja"
TYPE_SHOW = "Uzveduma deja"
TYPE_PLAY = "Rotaļdeja"
DANCE_TYPES = [TYPE_STAGE, TYPE_SHOW, TYPE_PLAY]
OLD_DANCE_TYPES = {"Skatuves deja": TYPE_STAGE, "Rotaļa": TYPE_PLAY}  # names used in v0.1

LINEUP_MIXED = "Jaukts"
LINEUP_WOMEN = "Sieviešu"
LINEUP_MEN = "Vīriešu"
LINEUPS = [LINEUP_MIXED, LINEUP_WOMEN, LINEUP_MEN]

# Tērpu pūrs keeps costume pieces in two categories; a dance chooses costume types for each gender
COSTUME_CATEGORY = {GENDER_FEMALE: "Meiteņu tērpi", GENDER_MALE: "Puišu tērpi"}
COSTUME_TITLE = {GENDER_FEMALE: "Sievietēm (meiteņu tērpi)", GENDER_MALE: "Vīriešiem (puišu tērpi)"}
AVAILABLE_PIECE = "Noliktavā"

# Cītības pūrs: which session kinds count as rehearsals
REHEARSAL_KINDS = ("Mēģinājums", "Papildmēģinājums")

ROLE_MAIN = "Pamatsastāvs"
ROLE_RESERVE = "Rezerve"
ROLE_SOLO = "Solists"            # Deju pūrs v0.3.6: soloists — a pair (girl + boy), only a girl or only a boy
ROLES = [ROLE_MAIN, ROLE_SOLO, ROLE_RESERVE]
ROLE_ORDER = {ROLE_MAIN: 0, ROLE_SOLO: 1, ROLE_RESERVE: 2}
SOLO_FG = "#8A5A00"              # colour of the soloists in cast lists

# table columns: key, heading, width
COLUMNS = [
    ("title", "Deja", 150),
    ("dance_group", "Grupa", 65),
    ("choreographer", "Horeogrāfs", 120),
    ("music", "Mūzika", 110),
    ("dance_type", "Veids", 170),
    ("lineup", "Sastāvs", 75),
    ("counts", "Puiši / meitas", 95),
    ("cast", "Dejotāji", 90),
    ("duration", "Ilgums", 55),
    ("costume_set", "Tērpu komplekts", 110),
    ("status", "Statuss", 90),
    ("rehearsed", "Mēģināta", 75),
    ("learned_date", "Iestudēta", 85),
]

FIELDS = ("title", "choreographer", "music", "dance_type", "production", "lineup", "men_count", "women_count",
          "duration",
          "costume_set", "status", "learned_date", "video", "description", "notes", "dance_group")


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS dances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    choreographer TEXT DEFAULT '',
    music TEXT DEFAULT '',
    dance_type TEXT DEFAULT '',
    production TEXT DEFAULT '',
    lineup TEXT DEFAULT '',
    pairs TEXT DEFAULT '',
    men_count TEXT DEFAULT '',
    women_count TEXT DEFAULT '',
    duration TEXT DEFAULT '',
    costume_set TEXT DEFAULT '',
    status TEXT DEFAULT '',
    learned_date TEXT DEFAULT '',
    video TEXT DEFAULT '',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS dance_costumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    gender TEXT NOT NULL,
    type_name TEXT NOT NULL,
    UNIQUE (dance_id, gender, type_name)
);
CREATE TABLE IF NOT EXISTS dance_cast (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    role TEXT DEFAULT '',
    pair_no TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    UNIQUE (dance_id, dancer_id)
);
CREATE TABLE IF NOT EXISTS dance_formations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    name TEXT DEFAULT '',
    sort_no INTEGER DEFAULT 0,
    positions TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
"""


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        ensure_dancer_schema(self.con)
        self.con.executescript(SCHEMA)
        have = {r[1] for r in self.con.execute("PRAGMA table_info(dances)")}
        for column in FIELDS:  # later versions may add columns
            if column not in have:
                self.con.execute(f"ALTER TABLE dances ADD COLUMN {column} TEXT DEFAULT ''")
        # v0.1.10 and earlier kept one "pāru skaits": turn it into the numbers of boys and girls
        for did, lineup, pairs in self.con.execute(
                "SELECT id, lineup, pairs FROM dances WHERE TRIM(COALESCE(pairs,'')) <> '' "
                "AND TRIM(COALESCE(men_count,'')) = '' AND TRIM(COALESCE(women_count,'')) = ''").fetchall():
            if not str(pairs).strip().isdigit():
                continue
            n = int(pairs)
            men, women = {LINEUP_WOMEN: (0, 2 * n), LINEUP_MEN: (2 * n, 0)}.get(lineup, (n, n))
            self.con.execute("UPDATE dances SET men_count=?, women_count=?, pairs='' WHERE id=?",
                             (str(men) if men else "", str(women) if women else "", did))
        for old in OLD_DANCE_LEARNING:
            self.con.execute("UPDATE dances SET status=? WHERE status=?", (DANCE_LEARNING, old))
        for old, new in OLD_DANCE_TYPES.items():
            self.con.execute("UPDATE dances SET dance_type=? WHERE dance_type=?", (new, old))
        self.con.commit()
        ensure_cast_substitutes(self.con)
        # Deju pūrs v0.2.4: every dance belongs to a group (A / Studija / VPDK, as in Kopas pūrs). The dances that
        # existed then got group A — once, so later changes are never overwritten.
        if not self.con.execute("SELECT 1 FROM settings WHERE key=?", (DANCE_GROUP_SEEDED,)).fetchone():
            self.con.execute("UPDATE dances SET dance_group=? WHERE TRIM(COALESCE(dance_group,'')) = ''",
                             (DEFAULT_DANCER_GROUP,))
            self.con.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (DANCE_GROUP_SEEDED, "1"))
            self.con.commit()  # each main-cast dancer can have his own reserve dancer
        # Deju pūrs v0.3.5: in mixed dances every main-cast girl and boy is in a numbered pair
        for (dance_id,) in self.q("SELECT id FROM dances WHERE TRIM(COALESCE(lineup,'')) IN ('', ?) AND id IN "
                                  "(SELECT dance_id FROM dance_cast)", (LINEUP_MIXED,)):
            auto_pair(self, dance_id)

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    # ---- costume types from Tērpu pūrs ----------------------------------
    def costume_types(self):
        """Costume types kept in Tērpu pūrs → Administrēšana (plus types used on pieces)."""
        names = set()
        for sql in ("SELECT name FROM piece_types", "SELECT DISTINCT type FROM costume_pieces"):
            try:
                names.update(r[0] for r in self.q(sql))
            except sqlite3.Error:
                pass
        return sorted((n for n in names if (n or "").strip()), key=_norm)

    def costume_types_for(self, gender):
        """Costume types offered for a gender: only the types whose category in Tērpu pūrs →
        Administrēšana is "Meiteņu tērpi" (women) or "Puišu tērpi" (men)."""
        try:
            rows = self.q("SELECT name FROM piece_types WHERE category=?", (COSTUME_CATEGORY[gender],))
        except sqlite3.Error:  # older database without type categories: all types
            return self.costume_types()
        return sorted((r[0] for r in rows if (r[0] or "").strip()), key=_norm)

    def type_stock(self):
        """{(category, type): (pieces, in stock)} from Tērpu pūrs."""
        try:
            rows = self.q("SELECT category, type, COUNT(*), SUM(CASE WHEN status=? THEN 1 ELSE 0 END) "
                          "FROM costume_pieces GROUP BY category, type", (AVAILABLE_PIECE,))
        except sqlite3.Error:
            return {}
        return {(c, _norm(t)): (n, a or 0) for c, t, n, a in rows}

    def dance_costumes(self, dance_id):
        result = {g: [] for g in GENDERS}
        for gender, name in self.q("SELECT gender, type_name FROM dance_costumes WHERE dance_id=? ORDER BY id",
                                   (dance_id,)):
            result.setdefault(gender, []).append(name)
        return result

    def save_dance_costumes(self, dance_id, costumes):
        self.con.execute("DELETE FROM dance_costumes WHERE dance_id=?", (dance_id,))
        for gender, names in costumes.items():
            for name in names:
                self.con.execute("INSERT OR IGNORE INTO dance_costumes (dance_id, gender, type_name) "
                                 "VALUES (?, ?, ?)", (dance_id, gender, name))
        self.con.commit()

    def costume_sets(self):
        """Costume set names from Tērpu pūrs (its table exists only once that module has been used)."""
        names = set()
        try:
            names.update(r[0] for r in self.q("SELECT name FROM piece_sets"))
        except sqlite3.Error:
            pass
        try:
            names.update(r[0] for r in self.q("SELECT DISTINCT set_name FROM costume_pieces"))
        except sqlite3.Error:
            pass
        names.update(r[0] for r in self.q("SELECT DISTINCT costume_set FROM dances"))
        return sorted((n for n in names if (n or "").strip()), key=_norm)

    def rehearsal_stats(self):
        """From Cītības pūrs: {dance id: {"season": n, "total": n, "last": ISO date, "performed": n}}.
        Season = from 1 September. Empty while Cītības pūrs has not been used."""
        if not self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='session_dances'"):
            return {}
        today = date.today()
        season_start = date(today.year if today.month >= 9 else today.year - 1, 9, 1).isoformat()
        result = {}
        cancelled = set()  # events cancelled in Notikumu pūrs are not counted as performed
        if self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_details'"):
            cancelled = {r[0] for r in self.q("SELECT session_id FROM event_details WHERE status='Atcelts'")}
        for sid, dance_id, day, kind in self.q("SELECT sd.session_id, sd.dance_id, s.session_date, s.kind "
                                               "FROM session_dances sd "
                                               "JOIN attendance_sessions s ON s.id = sd.session_id"):
            r = result.setdefault(dance_id, {"season": 0, "total": 0, "last": "", "performed": 0})
            if kind in REHEARSAL_KINDS:
                r["total"] += 1
                if day >= season_start:
                    r["season"] += 1
                if day <= today.isoformat() and day > r["last"]:
                    r["last"] = day
            elif day <= today.isoformat() and sid not in cancelled:  # planned concerts are not counted yet
                r["performed"] += 1
        return result

    def distinct(self, column):
        return sorted((r[0] for r in self.q(f"SELECT DISTINCT {column} FROM dances")
                       if (r[0] or "").strip()), key=_norm)


def save_dance(db, values, dance_id=None):
    data = [values.get(f, "") for f in FIELDS]
    if dance_id is None:
        return db.x("INSERT INTO dances (" + ", ".join(FIELDS) + ") VALUES (" + ",".join("?" * len(FIELDS)) + ")",
                    data)
    db.x("UPDATE dances SET " + ", ".join(f + "=?" for f in FIELDS) + " WHERE id=?", data + [dance_id])
    return dance_id


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def parse_duration(text):
    """'3:45', '3.45', '3 min 45 s', '225 s' or '4' (minutes) -> seconds as text; '' when empty; None when bad."""
    text = str(text or "").strip().lower()
    if not text:
        return ""
    m = re.fullmatch(r"(\d{1,3})\s*[:.,']\s*(\d{1,2})\s*(\"|'')?", text)
    if m:
        minutes, seconds = int(m.group(1)), int(m.group(2))
        if seconds < 60:
            return str(minutes * 60 + seconds)
        return None
    m = re.fullmatch(r"(?:(\d{1,3})\s*min\.?)?\s*(?:(\d{1,4})\s*(?:s|sek\.?|sec))?", text)
    if m and (m.group(1) or m.group(2)):
        return str(int(m.group(1) or 0) * 60 + int(m.group(2) or 0))
    if re.fullmatch(r"\d{1,2}", text):  # a single small number = minutes
        return str(int(text) * 60)
    if re.fullmatch(r"\d{3,4}", text):  # a larger number = seconds
        return str(int(text))
    return None


def show_duration(seconds):
    try:
        s = int(seconds)
    except (TypeError, ValueError):
        return ""
    return f"{s // 60}:{s % 60:02d}"


def show_total(seconds):
    if not seconds:
        return "0 min"
    h, rest = divmod(int(seconds), 3600)
    m = round(rest / 60)
    if m == 60:
        h, m = h + 1, 0
    return f"{h} h {m} min" if h else f"{m} min"


def normalize_dance_status(text):
    s = _norm(text)
    if not s:
        return DANCE_IN_REPERTOIRE
    if s.startswith(("repert", "aktiv", "dejo", "ja")):
        return DANCE_IN_REPERTOIRE
    if s.startswith(("proces", "apgus", "iestud", "macam", "macas", "jauna")):
        return DANCE_LEARNING
    if s.startswith(("atpu", "pauz", "neakt")):
        return DANCE_RESTING
    if s.startswith(("arhiv", "nedejo", "vec")):
        return DANCE_ARCHIVED
    return None


def normalize_dance_type(text):
    """Excel text -> one of DANCE_TYPES ('' when empty, None when unknown)."""
    s = _norm(text)
    if not s:
        return ""
    if s.startswith(("latv", "skatuv")):
        return TYPE_STAGE
    if s.startswith("uzved"):
        return TYPE_SHOW
    if s.startswith("rotal"):
        return TYPE_PLAY
    return None  # unknown type


def type_text(dance_type, production):
    """'Uzveduma deja: <uzvedums>' for the table."""
    if dance_type == TYPE_SHOW and production:
        return f"{dance_type}: {production}"
    return dance_type


def normalize_lineup(text):
    s = _norm(text)
    if not s:
        return ""
    if s.startswith(("jauk", "mix", "pari")):
        return LINEUP_MIXED
    if s.startswith(("siev", "meit", "women", "girls")):
        return LINEUP_WOMEN
    if s.startswith(("vir", "puis", "men", "boys")):
        return LINEUP_MEN
    return None


def needed_by_gender(men_count, women_count):
    """How many women / men a dance needs: (women, men) or None when neither number is given."""
    men, women = str(men_count or "").strip(), str(women_count or "").strip()
    if not men.isdigit() and not women.isdigit():
        return None
    return (int(women) if women.isdigit() else 0), (int(men) if men.isdigit() else 0)


def counts_text(men_count, women_count):
    """'12 / 12' for the table (boys / girls)."""
    men, women = (men_count or "").strip(), (women_count or "").strip()
    if not men and not women:
        return ""
    return f"{men or 0} / {women or 0}"


def cast_status(in_cast, men_count, women_count):
    """Text and colour describing whether the cast is complete.
    in_cast rows: (..., ..., name, gender, role, ...)"""
    main = [r for r in in_cast if (r[4] or ROLE_MAIN) == ROLE_MAIN]
    women = sum(1 for r in main if r[3] == GENDER_FEMALE)
    men = sum(1 for r in main if r[3] == GENDER_MALE)
    reserve = sum(1 for r in in_cast if r[4] == ROLE_RESERVE)
    solo = sum(1 for r in in_cast if r[4] == ROLE_SOLO)
    have = (f"Pamatsastāvā — puiši: {men}, meitas: {women}; " + (f"solisti: {solo}; " if solo else "")
            + f"rezervē: {reserve}.")
    need = needed_by_gender(men_count, women_count)
    if need is None:
        return have + "  (Puišu un meitu skaits dejai nav norādīts.)", NAVY
    nw, nm = need
    missing = []
    if women < nw:
        missing.append(f"meitas: {nw - women}")
    if men < nm:
        missing.insert(0, f"puiši: {nm - men}")
    extra = (women - nw) + (men - nm) if women >= nw and men >= nm else 0
    text = f"Vajag — puiši: {nm}, meitas: {nw}.  " + have
    if missing:
        return text + "  Trūkst: " + ", ".join(missing) + ".", RED
    if extra:
        return text + f"  Pamatsastāvā vairāk nekā vajag (+{extra}).", AMBER
    return text + "  Sastāvs pilns ✓", GREEN


def load_cast(db, dance_id):
    """Rows (cast id, dancer id, name, gender, role, pair no, notes, active) sorted by role and pair."""
    rows = db.q("SELECT c.id, c.dancer_id, d.name, d.gender, c.role, c.pair_no, c.notes, "
                + active_dancer_sql("d") + " FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                "WHERE c.dance_id=?", (dance_id,))

    def pair_key(r):
        m = re.match(r"\d+", r[5] or "")
        return (ROLE_ORDER.get(r[4] or ROLE_MAIN, 0), int(m.group(0)) if m else 9999, r[5] or "",
                r[3] != GENDER_FEMALE, _norm(r[2]))
    return sorted(rows, key=pair_key)


def substitute_info(db, dance_id):
    """({main dancer id: substitute's name}, {substitute id: [names of the dancers he replaces]}) for a dance."""
    names = dict(db.q("SELECT id, name FROM dancers"))
    subs, covers = {}, {}
    for main, sub in db.q("SELECT dancer_id, substitute_id FROM dance_cast WHERE dance_id=? AND "
                          "substitute_id IS NOT NULL", (dance_id,)):
        subs[main] = names.get(sub, "")
        covers.setdefault(sub, []).append(names.get(main, ""))
    return subs, covers


def substitute_text(dancer_id, role, subs, covers):
    """Text for the "Rezerve" column of a cast list."""
    if (role or ROLE_MAIN) != ROLE_RESERVE:   # main-cast dancers and soloists have a reserve dancer
        return subs.get(dancer_id) or "—"
    return ("aizvieto: " + ", ".join(sorted(covers[dancer_id], key=_norm))) if dancer_id in covers else ""


def clear_substitute(db, dance_id, dancer_id):
    """A dancer taken out of a dance is no longer anybody's reserve in it."""
    db.x("UPDATE dance_cast SET substitute_id=NULL WHERE dance_id=? AND substitute_id=?", (dance_id, dancer_id))


# --------------------------------------------------------------------------
# Pairs of a mixed dance (Deju pūrs v0.3.5): every main-cast girl and boy is in a numbered pair
# --------------------------------------------------------------------------
def pair_number(text):
    """'3' / '3.' / '3. pāris' -> 3; anything else -> None."""
    m = re.match(r"\s*[Ss]?\s*(\d+)", text or "")     # also 'S2' (soloists)
    return int(m.group(1)) if m and int(m.group(1)) > 0 else None


def lowest_free(numbers):
    n = 1
    while n in numbers:
        n += 1
    return n


def is_mixed(lineup):
    return (lineup or LINEUP_MIXED) == LINEUP_MIXED


def auto_pair(db, dance_id):
    """Mixed dance: every main-cast girl and boy gets a pair number. A pair is one girl + one boy; a dancer
    without a (valid) pair number goes into the lowest-numbered pair that still lacks his/her gender, else into
    a new pair with the lowest free number. Reserve dancers have no pair. Returns True when something changed."""
    changed = auto_solo(db, dance_id)
    found = db.q("SELECT lineup FROM dances WHERE id=?", (dance_id,))
    if not found or not is_mixed(found[0][0]):
        return changed
    rows = db.q("SELECT c.id, d.gender, c.role, c.pair_no FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                "WHERE c.dance_id=? ORDER BY c.id", (dance_id,))
    slots, pending, changes = {}, [], {}
    for cid, gender, role, pair_no in rows:
        if role == ROLE_SOLO:      # soloists have their own numbers (auto_solo)
            continue
        if (role or ROLE_MAIN) == ROLE_RESERVE:
            if (pair_no or "").strip():
                changes[cid] = ""
            continue
        if gender not in (GENDER_FEMALE, GENDER_MALE):
            continue
        n = pair_number(pair_no)
        if n and gender not in slots.get(n, {}):
            slots.setdefault(n, {})[gender] = cid
            if (pair_no or "").strip() != str(n):
                changes[cid] = str(n)
        else:
            pending.append((cid, gender))
    for cid, gender in pending:
        free = [n for n in sorted(slots) if gender not in slots[n]]
        n = free[0] if free else lowest_free(set(slots))
        slots.setdefault(n, {})[gender] = cid
        changes[cid] = str(n)
    for cid, pair_no in changes.items():
        db.x("UPDATE dance_cast SET pair_no=? WHERE id=?", (pair_no, cid))
    return bool(changes) or changed


def auto_solo(db, dance_id):
    """Soloists (Deju pūrs v0.3.6) are numbered S1, S2, … (stored as '1', '2', … in pair_no). One number = a solo
    pair (one girl + one boy), or only a girl, or only a boy. A soloist without a (valid) number or with the same
    gender as another soloist of that number gets a new number. Returns True when something changed."""
    rows = db.q("SELECT c.id, d.gender, c.pair_no FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                "WHERE c.dance_id=? AND c.role=? ORDER BY c.id", (dance_id, ROLE_SOLO))
    slots, pending, changes = {}, [], {}
    for cid, gender, pair_no in rows:
        n = pair_number(pair_no)
        key = gender if gender in (GENDER_FEMALE, GENDER_MALE) else f"?{cid}"
        if n and key not in slots.get(n, {}):
            slots.setdefault(n, {})[key] = cid
            if (pair_no or "").strip() != str(n):
                changes[cid] = str(n)
        else:
            pending.append((cid, key))
    for cid, key in pending:   # every new soloist starts as a solo of his/her own
        n = lowest_free(set(slots))
        slots.setdefault(n, {})[key] = cid
        changes[cid] = str(n)
    for cid, pair_no in changes.items():
        db.x("UPDATE dance_cast SET pair_no=? WHERE id=?", (pair_no, cid))
    return bool(changes)


def solo_table(db, dance_id):
    """Soloists of a dance -> [(nr, girl row or None, boy row or None)] (rows as load_cast()); a soloist without a
    gender is shown on the girl's side."""
    units = {}
    for r in load_cast(db, dance_id):
        if r[4] != ROLE_SOLO:
            continue
        n = pair_number(r[5]) or 0
        unit = units.setdefault(n, {})
        side = GENDER_MALE if r[3] == GENDER_MALE else GENDER_FEMALE
        if side in unit:     # (should not happen after auto_solo) — show it as a solo of its own
            n = -r[0]
            unit = units.setdefault(n, {})
        unit[side] = r
    return [(n, units[n].get(GENDER_FEMALE), units[n].get(GENDER_MALE)) for n in sorted(units, key=lambda k: (k <= 0, abs(k)))]


def solo_label(no):
    return f"S{no}" if no and no > 0 else "S"


def pair_table(db, dance_id, men_count="", women_count=""):
    """Mixed dance -> (pairs, reserves). pairs = [(nr, girl row or None, boy row or None)] — also the empty
    pairs still needed (by the numbers of boys and girls); reserves = rows of the reserve dancers (and of
    dancers without a gender). Rows as load_cast()."""
    rows = load_cast(db, dance_id)
    by_no, reserves = {}, []
    for r in rows:
        n = pair_number(r[5])
        if (r[4] or ROLE_MAIN) == ROLE_MAIN and n and r[3] in (GENDER_FEMALE, GENDER_MALE):
            by_no.setdefault(n, {})[r[3]] = r
        elif r[4] != ROLE_SOLO:     # soloists: solo_table()
            reserves.append(r)
    need = needed_by_gender(men_count, women_count)
    count = max([max(by_no) if by_no else 0] + ([max(need)] if need else []))
    numbers = sorted(set(range(1, count + 1)) | set(by_no))
    pairs = [(n, by_no.get(n, {}).get(GENDER_FEMALE), by_no.get(n, {}).get(GENDER_MALE)) for n in numbers]
    return pairs, reserves


OTHER_GROUP = "#5B3FA0"   # colour of a dancer from another group than the dance's group


def dance_group_of(db, dance_id):
    rows = db.q("SELECT dance_group FROM dances WHERE id=?", (dance_id,))
    return (rows[0][0] or "") if rows else ""


def group_text(dancer_group, dance_group):
    """Group shown in a cast list; a dancer from another group than the dance gets a mark."""
    if dance_group and dancer_group and dancer_group != dance_group:
        return f"{dancer_group} (cita)"
    return dancer_group or ""


def status_notes(db):
    """{dancer id: ' (uz pauzes)' / ' (izstājies)'} for dancers who are not active — shown after the name."""
    return {did: f" ({status.strip().lower()})" for did, status in
            db.q("SELECT id, status FROM dancers WHERE TRIM(COALESCE(status,'')) NOT IN ('', ?)", (STATUS_ACTIVE,))}


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


# --------------------------------------------------------------------------
# The common look (Pūrlāde v0.8 — moduli/izskats.py)
# --------------------------------------------------------------------------
LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED, \
    izskats.SELECTED
OK_BG, OK_FG, WARN_BG, WARN_FG, BAD_BG, BAD_FG = (izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG,
                                                  izskats.BAD_BG, izskats.BAD_FG)
ZEBRA = izskats.ZEBRA
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL
MODULE_COLOUR = NAVY
GROUP_BG = "#E8EEF7"   # light navy: group chips
STATUS_COLOURS = {DANCE_IN_REPERTOIRE: (OK_BG, OK_FG), DANCE_LEARNING: (WARN_BG, WARN_FG),
                  DANCE_RESTING: ("#F3F1EC", MUTED), DANCE_ARCHIVED: ("#F3F1EC", MUTED)}
EVENT_KINDS_SHOWN = ("Mēģinājums", "Papildmēģinājums")   # not shown under “Tuvākie notikumi”

# tabs of the module: key -> (text, statuses shown)
TAB_REPERTOIRE, TAB_LEARNING, TAB_RESTING, TAB_ALL, TAB_LOAD = "rep", "learn", "rest", "all", "load"
TAB_STATUSES = {TAB_REPERTOIRE: (DANCE_IN_REPERTOIRE,), TAB_LEARNING: (DANCE_LEARNING,),
                TAB_RESTING: (DANCE_RESTING, DANCE_ARCHIVED), TAB_ALL: tuple(DANCE_STATUSES)}

SORTS = {"Nosaukums": "title", "Ilgums": "duration", "Mēģināta šosezon": "rehearsed", "Sastāvs (nepilnās augšā)": "cast",
         "Grupa": "dance_group", "Horeogrāfs": "choreographer"}


zebra = izskats.zebra   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


row_tags = izskats.row_tags   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


def small_label(parent, text, bg=WHITE):
    return tk.Label(parent, text=text, bg=bg, fg=MUTED, font=("Segoe UI", 8, "bold"))


def times_word(n):
    return "reize" if n % 10 == 1 and n % 100 != 11 else "reizes"


def dances_word(n):
    return "deja" if n % 10 == 1 and n % 100 != 11 else "dejas"


def status_chip(parent, status):
    bg, fg = STATUS_COLOURS.get(status, (SELECTED, NAVY))
    return izskats.chip(parent, status, bg, fg)


def lineup_text(r):
    """'8 puiši, 8 meitas · jaukts' for the details card."""
    men, women = (r.get("men_count") or "").strip(), (r.get("women_count") or "").strip()
    parts = []
    if men:
        parts.append(f"{men} puiši")
    if women:
        parts.append(f"{women} meitas")
    text = ", ".join(parts) or "skaits nav norādīts"
    return text + (f" · {r['lineup'].lower()}" if r.get("lineup") else "")


# --------------------------------------------------------------------------
# Dance form
# --------------------------------------------------------------------------
class DanceForm(tk.Toplevel):
    """Add or edit one dance."""

    def __init__(self, app, dance_id=None):
        super().__init__(app.root)
        self.app, self.dance_id = app, dance_id
        db = app.db
        self.configure(bg=CREAM)
        self.title("Jauna deja" if dance_id is None else "Deja")
        self.transient(app.root)
        self.grab_set()
        old_title = db.q("SELECT title FROM dances WHERE id=?", (dance_id,))[0][0] if dance_id is not None else ""
        izskats.dialog_header(self, "Jauna deja" if dance_id is None else (old_title or "Deja"),
                              "Ar * atzīmētie lauki ir obligāti. Datumu raksta DD.MM.GGGG, ilgumu — piemēram, 3:45."
                              if dance_id is None else "Dejas dati, tērpi, apraksts un sastāvs",
                              colour=MODULE_COLOUR)
        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Aizvērt" if dance_id is not None else "Atcelt",
                   command=self.destroy).pack(side="right", padx=6)
        if dance_id is not None:
            ttk.Button(btns, text="Dzēst deju", style="Danger.TButton", command=self.delete).pack(side="left")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=3)
        left = tk.Frame(body, bg=CREAM)
        left.grid(row=0, column=0, sticky="nsew")

        text_fields = ("description", "notes")
        self.vars = {f: tk.StringVar() for f in FIELDS if f not in text_fields}
        self.vars["status"].set(DANCE_IN_REPERTOIRE)
        self.vars["lineup"].set(LINEUP_MIXED)

        data_outer, _h, data = izskats.panel(left, "Dejas dati")
        data_outer.pack(fill="x")
        g = tk.Frame(data, bg=WHITE)
        g.pack(fill="x", padx=14, pady=(8, 12))
        self.grid_box = g
        for c in (0, 1):
            g.columnconfigure(c, weight=1, uniform="f")

        def field(text, r, c, widget):
            small_label(g, text.upper()).grid(row=r, column=c, sticky="w", padx=(0 if c == 0 else 12, 0), pady=(6, 0))
            widget.grid(row=r + 1, column=c, sticky="ew", padx=(0 if c == 0 else 12, 0))
            return widget

        title = field("Dejas nosaukums *", 0, 0, ttk.Entry(g, textvariable=self.vars["title"], width=30))
        self.group_box = field("Grupa *", 0, 1, ttk.Combobox(g, textvariable=self.vars["dance_group"],
                                                            values=DANCER_GROUPS, state="readonly", width=26))
        field("Horeogrāfs", 2, 0, ttk.Combobox(g, textvariable=self.vars["choreographer"],
                                               values=db.distinct("choreographer"), width=28))
        field("Mūzika (autors, apdare)", 2, 1, ttk.Entry(g, textvariable=self.vars["music"], width=28))
        type_cb = field("Veids", 4, 0, ttk.Combobox(g, textvariable=self.vars["dance_type"], values=DANCE_TYPES,
                                                    state="readonly", width=28))
        type_cb.bind("<<ComboboxSelected>>", lambda e: self.show_production())
        status_cb = field("Statuss", 4, 1, ttk.Combobox(g, textvariable=self.vars["status"], values=DANCE_STATUSES,
                                                        state="readonly", width=26))
        status_cb.bind("<<ComboboxSelected>>", lambda e: self.status_chosen())
        # shown only for "Uzveduma deja": the show (uzvedums) the dance belongs to
        self.prod_label = tk.Label(g, text="UZVEDUMS *", bg=WHITE, fg=RED, font=("Segoe UI", 8, "bold"))
        self.prod_box = ttk.Combobox(g, textvariable=self.vars["production"], values=db.distinct("production"),
                                     width=28)
        self.prod_hint = izskats.note(g, "Uzvedums, kura sastāvā ir šī deja (izvēlieties vai ierakstiet jaunu).",
                                      bg=WHITE, wrap=260)
        lineup_cb = field("Sastāvs", 8, 0, ttk.Combobox(g, textvariable=self.vars["lineup"], values=LINEUPS,
                                                        state="readonly", width=28))
        lineup_cb.bind("<<ComboboxSelected>>", lambda e: (self.show_costume_columns(), self.lock_counts()))
        counts = tk.Frame(g, bg=WHITE)
        small_label(g, "PUIŠU / MEITU SKAITS").grid(row=8, column=1, sticky="w", padx=(12, 0), pady=(6, 0))
        counts.grid(row=9, column=1, sticky="ew", padx=(12, 0))
        self.men_entry = ttk.Entry(counts, textvariable=self.vars["men_count"], width=8)
        self.men_entry.pack(side="left")
        tk.Label(counts, text="puiši   ", bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="left", padx=(4, 0))
        self.women_entry = ttk.Entry(counts, textvariable=self.vars["women_count"], width=8)
        self.women_entry.pack(side="left")
        tk.Label(counts, text="meitas", bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="left", padx=(4, 0))
        field("Ilgums (min:sek)", 10, 0, ttk.Entry(g, textvariable=self.vars["duration"], width=28))
        field("Iestudēta (DD.MM.GGGG)", 10, 1, ttk.Entry(g, textvariable=self.vars["learned_date"], width=26))
        field("Tērpu komplekts", 12, 0, ttk.Combobox(g, textvariable=self.vars["costume_set"],
                                                     values=db.costume_sets(), width=28))
        field("Video / mūzikas saite", 12, 1, ttk.Entry(g, textvariable=self.vars["video"], width=26))

        cost_outer, _h, cost = izskats.panel(left, "Tērpi")
        cost_outer.pack(fill="x", pady=(10, 0))
        self.build_costume_panel(db, dance_id, cost)

        right = tk.Frame(body, bg=CREAM)
        right.grid(row=0, column=1, sticky="nsew", padx=(14, 0))
        body.columnconfigure(1, weight=2)
        text_outer, _h, tb = izskats.panel(right, "Apraksts un piezīmes")
        text_outer.pack(side="bottom", fill="x", pady=(10, 0) if dance_id is not None else 0)
        inner = tk.Frame(tb, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=14, pady=(8, 12))
        small_label(inner, "DEJAS APRAKSTS").pack(anchor="w")
        self.description = tk.Text(inner, width=50, height=5, wrap="word", relief="flat", bd=0, highlightthickness=1,
                                   highlightbackground=FIELD_LINE, highlightcolor=NAVY, fg=NAVY, font=FONT,
                                   padx=6, pady=4)
        self.description.pack(fill="both", expand=True)
        small_label(inner, "PIEZĪMES").pack(anchor="w", pady=(6, 0))
        self.notes = tk.Text(inner, width=50, height=2, wrap="word", relief="flat", bd=0, highlightthickness=1,
                             highlightbackground=FIELD_LINE, highlightcolor=NAVY, fg=NAVY, font=FONT, padx=6, pady=4)
        self.notes.pack(fill="x")

        if dance_id is not None:
            self.build_cast_panel(right)
        self.bind("<Escape>", lambda e: self.destroy())

        if dance_id is not None:
            row = db.q("SELECT " + ", ".join(FIELDS) + " FROM dances WHERE id=?", (dance_id,))[0]
            for f, v in zip(FIELDS, row):
                if f == "description":
                    self.description.insert("1.0", v or "")
                elif f == "notes":
                    self.notes.insert("1.0", v or "")
                elif f == "learned_date":
                    self.vars[f].set(show_date(v))
                elif f == "duration":
                    self.vars[f].set(show_duration(v))
                else:
                    self.vars[f].set(v or "")
            if self.vars["status"].get() not in DANCE_STATUSES:
                self.vars["status"].set(DANCE_IN_REPERTOIRE)
            if self.vars["dance_type"].get() not in DANCE_TYPES:
                self.vars["dance_type"].set(TYPE_STAGE)
            if self.vars["dance_group"].get() not in DANCER_GROUPS:
                self.vars["dance_group"].set(DEFAULT_DANCER_GROUP)
        else:
            self.vars["dance_type"].set(TYPE_STAGE)
            self.vars["dance_group"].set(DEFAULT_DANCER_GROUP)
            self.status_chosen()   # a new dance starts "Repertuārā": today as the learning date (can be changed)
        self.show_production()
        self.show_costume_columns()
        self.lock_counts()
        # lietotāju lomas: all / only the costume types (Tērpu pārzinis) / nothing
        acc = piekluve.current()
        self.old_group = self.vars["dance_group"].get()
        self.costumes_only = False
        if dance_id is None:
            allowed = acc.groups("deju_purs")
            self.group_box.configure(values=allowed)
            if self.vars["dance_group"].get() not in allowed and allowed:
                self.vars["dance_group"].set(allowed[0])
        elif not acc.can_edit("deju_purs", group=self.old_group):
            if acc.costumes:
                self.costumes_only = True
                piekluve.make_readonly(self, keep=("saglabāt",), skip=(self.costume_box,),
                                       note="Var mainīt tikai dejas tērpu veidus (tērpu pārzinis).")
            else:
                piekluve.make_readonly(self, note=(
                    "Tikai skatīšanai — " + ("jūsu lomai Deju pūrā nav labošanas tiesību."
                                             if acc.view_only("deju_purs") else
                                             f"labot var tikai {acc.scope_text('deju_purs')}s dejas.")))
        title.focus_set()
        self.after(100, lambda: fit_min_size(self))

    # ---- costume types for each gender (from Tērpu pūrs) ------------------
    def build_costume_panel(self, db, dance_id, parent):
        self.costume_types = db.costume_types()
        self.types_for = {g: db.costume_types_for(g) for g in GENDERS}
        self.stock = db.type_stock()
        self.costumes = db.dance_costumes(dance_id) if dance_id is not None else {g: [] for g in GENDERS}
        box = tk.Frame(parent, bg=WHITE)
        self.costume_box = box
        box.pack(fill="x", padx=14, pady=(8, 12))
        box.columnconfigure(0, weight=1, uniform="cost")
        box.columnconfigure(1, weight=1, uniform="cost")
        self.costume_cols, self.costume_lists, self.costume_choice, self.costume_combos = {}, {}, {}, {}
        for i, gender in enumerate((GENDER_FEMALE, GENDER_MALE)):
            col = tk.Frame(box, bg=WHITE)
            self.costume_cols[gender] = col
            col.grid(row=0, column=i, sticky="nsew", padx=(0, 8) if i == 0 else (8, 0))
            small_label(col, ("Meitām" if gender == GENDER_FEMALE else "Puišiem").upper()).pack(anchor="w")
            lb = tk.Listbox(col, height=4, relief="flat", bg=WHITE, fg=NAVY, selectbackground=SELECTED,
                            selectforeground=NAVY, activestyle="none", highlightthickness=1,
                            highlightbackground=LINE, font=FONT_SMALL)
            lb.pack(fill="both", expand=True, pady=(2, 4))
            lb.bind("<Double-1>", lambda e, g=gender: self.remove_costume(g, e))
            self.costume_lists[gender] = lb
            var = tk.StringVar()
            self.costume_choice[gender] = var
            cb = ttk.Combobox(col, textvariable=var, state="readonly", width=18)
            cb.pack(fill="x")
            cb.bind("<<ComboboxSelected>>", lambda e, g=gender: self.add_costume(g))
            self.costume_combos[gender] = cb
        any_types = any(self.types_for.values())
        hint = ("Izvēlieties tērpa veidu sarakstā — tas tiek pievienots; dubultklikšķis uz pievienotā — izņemt. "
                "Iekavās — cik tādu tērpu ir Tērpu pūrā un cik noliktavā."
                if any_types else
                "Tērpu veidu ar kategoriju “Meiteņu tērpi” vai “Puišu tērpi” vēl nav. Tos izveido Tērpu pūrā → "
                "Noliktava → ⚙ Veidi un komplekti.")
        tk.Label(box, text=hint, bg=WHITE, fg=MUTED if any_types else RED, wraplength=560, justify="left",
                 font=FONT_SMALL).grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        for gender in GENDERS:
            self.refresh_costumes(gender)

    def stock_text(self, gender, name):
        pieces, free = self.stock.get((COSTUME_CATEGORY[gender], _norm(name)), (0, 0))
        none_pieces, none_free = self.stock.get(("Nekategorizēts", _norm(name)), (0, 0))  # for either gender
        pieces, free = pieces + none_pieces, free + none_free
        if not pieces:
            return f"{name}   (Tērpu pūrā nav)"
        return f"{name}   ({pieces} gab., noliktavā {free})"

    def refresh_costumes(self, gender):
        lb = self.costume_lists[gender]
        lb.delete(0, tk.END)
        for name in self.costumes.get(gender, []):
            lb.insert(tk.END, self.stock_text(gender, name))
        chosen = {_norm(n) for n in self.costumes.get(gender, [])}
        offered = [n for n in self.types_for.get(gender, []) if _norm(n) not in chosen]
        self.costume_combos[gender].configure(values=offered)
        self.costume_choice[gender].set("＋ pievienot tērpa veidu…" if self.types_for.get(gender) else
                                        "(nav šīs kategorijas veidu)")

    def add_costume(self, gender):
        name = self.costume_choice[gender].get()
        if name in self.types_for.get(gender, []) and name not in self.costumes.setdefault(gender, []):
            self.costumes[gender].append(name)
        self.refresh_costumes(gender)

    def remove_costume(self, gender, event):
        lb = self.costume_lists[gender]
        index = lb.nearest(event.y)
        if 0 <= index < len(self.costumes.get(gender, [])):
            bbox = lb.bbox(index)
            if bbox and bbox[1] <= event.y <= bbox[1] + bbox[3]:
                del self.costumes[gender][index]
                self.refresh_costumes(gender)

    def costume_genders(self):
        lineup = self.vars["lineup"].get()
        if lineup == LINEUP_WOMEN:
            return [GENDER_FEMALE]
        if lineup == LINEUP_MEN:
            return [GENDER_MALE]
        return [GENDER_FEMALE, GENDER_MALE]

    def lock_counts(self):
        """A women's dance has no boys and a men's dance no girls: that field is cleared and locked."""
        lineup = self.vars["lineup"].get()
        for entry, key, off in ((self.men_entry, "men_count", lineup == LINEUP_WOMEN),
                                (self.women_entry, "women_count", lineup == LINEUP_MEN)):
            if off:
                self.vars[key].set("")
            entry.configure(state="disabled" if off else "normal")

    def show_costume_columns(self):
        shown = self.costume_genders()
        for gender in (GENDER_FEMALE, GENDER_MALE):
            col = self.costume_cols[gender]
            if gender in shown:
                col.grid()
            else:
                col.grid_remove()

    # ---- cast of the dance (only for a saved dance) ----------------------
    def build_cast_panel(self, body):
        outer, head, panel = izskats.panel(body, "Dejas sastāvs")
        outer.pack(side="top", fill="both", expand=True)
        ttk.Button(head.right, text="♫ Mainīt sastāvu", command=self.open_cast).pack(side="right")
        ttk.Button(head.right, text="⌗ Zīmējumi",
                   command=lambda: FormationWindow(self.app, self.dance_id, parent=self)).pack(side="right", padx=(0, 6))
        self.cast_info = tk.Label(panel, text="", font=FONT_SMALL, bg=WHITE, fg=NAVY, justify="left", anchor="w",
                                  wraplength=380)
        self.cast_info.pack(fill="x", padx=14, pady=8)
        holder = tk.Frame(panel, bg=WHITE)
        holder.pack(fill="both", expand=True)
        lineup = self.app.db.q("SELECT lineup FROM dances WHERE id=?", (self.dance_id,))[0][0]
        self.cast_mixed = is_mixed(lineup)
        if self.cast_mixed:   # pairs side by side: girl and boy with their reserve dancers
            self.cast_tree = ttk.Treeview(holder, columns=("no", "girl", "girl_sub", "boy", "boy_sub"),
                                          show="headings", height=9)
            for key, text, width in (("no", "Pāris", 46), ("girl", "Meita", 130), ("girl_sub", "Rezerve", 105),
                                     ("boy", "Puisis", 130), ("boy_sub", "Rezerve", 105)):
                self.cast_tree.heading(key, text=text)
                self.cast_tree.column(key, width=width, minwidth=36, stretch=key != "no",
                                      anchor="center" if key == "no" else "w")
        else:
            self.cast_tree = ttk.Treeview(holder, columns=("pair_no", "name", "group", "role", "sub"),
                                          show="headings", height=9)
            for key, text, width in (("pair_no", "Pāris", 50), ("name", "Dejotājs", 150), ("group", "Grupa", 90),
                                     ("role", "Loma", 95), ("sub", "Rezerve", 140)):
                self.cast_tree.heading(key, text=text)
                self.cast_tree.column(key, width=width, minwidth=40, stretch=key == "name")
        zebra(self.cast_tree)
        self.cast_tree.tag_configure(ROLE_RESERVE, foreground=WARN_FG)
        self.cast_tree.tag_configure(ROLE_SOLO, foreground=SOLO_FG)
        self.cast_tree.tag_configure("inactive", foreground=GREY)
        self.cast_tree.tag_configure("othergroup", foreground=OTHER_GROUP)
        self.cast_tree.bind("<Double-1>", lambda e: self.open_cast())
        make_tree_with_scroll(holder, self.cast_tree)
        self.refresh_cast()

    def refresh_cast(self):
        db = self.app.db
        men_count, women_count = db.q("SELECT men_count, women_count FROM dances WHERE id=?", (self.dance_id,))[0]
        rows = load_cast(db, self.dance_id)
        self.cast_tree.delete(*self.cast_tree.get_children())
        notes_by_id = status_notes(db)
        subs, covers = substitute_info(db, self.dance_id)
        groups = dict(db.q("SELECT id, dancer_group FROM dancers"))
        dance_group = dance_group_of(db, self.dance_id)
        if self.cast_mixed:
            pairs, reserves = pair_table(db, self.dance_id, men_count, women_count)
            label = lambda r: (r[2] + ("" if r[7] else notes_by_id.get(r[1], ""))) if r else "—"
            for i, (no, girl, boy) in enumerate(pairs):
                people = [x for x in (girl, boy) if x]
                tags = row_tags(i, "" if all(x[7] for x in people) else "inactive",
                                "othergroup" if any(dance_group and groups.get(x[1]) and
                                                    groups.get(x[1]) != dance_group for x in people) else "")
                self.cast_tree.insert("", "end", tags=tags, values=(
                    f"{no}.", label(girl), (subs.get(girl[1]) or "—") if girl else "",
                    label(boy), (subs.get(boy[1]) or "—") if boy else ""))
            solos = solo_table(db, self.dance_id)
            for k, (no, girl, boy) in enumerate(solos):     # soloists (Deju pūrs v0.3.6)
                self.cast_tree.insert("", "end", tags=row_tags(len(pairs) + k, ROLE_SOLO), values=(
                    solo_label(no), label(girl) if girl else "", (subs.get(girl[1]) or "—") if girl else "",
                    label(boy) if boy else "", (subs.get(boy[1]) or "—") if boy else ""))
            pairs = pairs + solos
            for j, r in enumerate(reserves):
                who = covers.get(r[1])
                text = ("aizvieto: " + ", ".join(sorted(who, key=_norm))) if who else "rezerve"
                girl_side = r[3] == GENDER_FEMALE
                self.cast_tree.insert("", "end", tags=row_tags(len(pairs) + j, ROLE_RESERVE), values=(
                    "rez.", label(r) if girl_side else "", text if girl_side else "",
                    "" if girl_side else label(r), "" if girl_side else text))
            rows = rows or []
        for i, (cid, did, name, gender, role, pair_no, _notes, active) in enumerate([] if self.cast_mixed else rows):
            other = bool(dance_group and groups.get(did) and groups.get(did) != dance_group)
            tags = row_tags(i, role or ROLE_MAIN, "" if active else "inactive", "othergroup" if other else "")
            self.cast_tree.insert("", "end", iid=str(cid), tags=tags,
                                  values=(solo_label(pair_number(pair_no)) if role == ROLE_SOLO else (pair_no or ""),
                                          name + ("" if active else notes_by_id.get(did, "")),
                                          group_text(groups.get(did), dance_group),
                                          role or ROLE_MAIN, substitute_text(did, role, subs, covers)))
        if rows:
            text, colour = cast_status(rows, men_count, women_count)
        else:
            text, colour = "Sastāvs vēl nav izveidots. Spiediet “♫ Mainīt sastāvu”.", MUTED
        self.cast_info.configure(text=text.replace("  ", "\n"), fg=colour)

    def open_cast(self):
        if not piekluve.current().can_edit("deju_purs", group=self.old_group):
            return piekluve.deny(self, "Dejas sastāvu var mainīt tikai tie, kas drīkst labot šīs grupas dejas.")
        CastWindow(self.app, self.dance_id, parent=self, on_close=self.after_cast)

    def after_cast(self):
        if self.winfo_exists():
            self.refresh_cast()
            self.grab_set()
            self.focus_set()

    def delete(self):
        if self.app.delete_dance(self.dance_id, parent=self):
            self.destroy()

    def status_chosen(self):
        """Status "Repertuārā" chosen: an empty "Iestudēta" date gets today's date (it can still be changed)."""
        if self.vars["status"].get() == DANCE_IN_REPERTOIRE and not self.vars["learned_date"].get().strip():
            self.vars["learned_date"].set(date.today().strftime("%d.%m.%Y"))

    def show_production(self):
        if self.vars["dance_type"].get() == TYPE_SHOW:
            self.prod_label.grid(row=6, column=0, sticky="w", pady=(6, 0))
            self.prod_box.grid(row=7, column=0, sticky="ew")
            self.prod_hint.grid(row=7, column=1, sticky="w", padx=(12, 0))
        else:
            for w in (self.prod_label, self.prod_box, self.prod_hint):
                w.grid_remove()
        fit_min_size(self)

    def save(self):
        acc = piekluve.current()
        if self.costumes_only:   # Tērpu pārzinis: only the costume types of the dance
            if not acc.costumes:
                return piekluve.deny(self)
            shown = self.costume_genders()
            self.app.db.save_dance_costumes(self.dance_id, {g: n for g, n in self.costumes.items() if g in shown})
            self.app.refresh(select=self.dance_id)
            self.destroy()
            return
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        v = {f: var.get().strip() for f, var in self.vars.items()}
        v["description"] = self.description.get("1.0", tk.END).strip()
        v["notes"] = self.notes.get("1.0", tk.END).strip()
        if not acc.can_edit("deju_purs", group=v["dance_group"]) or (
                self.dance_id is not None and not acc.can_edit("deju_purs", group=self.old_group)):
            return piekluve.deny(self, f"Labot var tikai {acc.scope_text('deju_purs')}s dejas.")
        if not v["title"]:
            messagebox.showwarning("Trūkst datu", "Lūdzu, norādiet dejas nosaukumu.", parent=self)
            return
        if v["dance_group"] not in DANCER_GROUPS:
            messagebox.showwarning("Grupa", "Izvēlieties, kurai grupai ir šī deja: " + ", ".join(DANCER_GROUPS) + ".",
                                   parent=self)
            return
        if v["dance_type"] == TYPE_SHOW:
            if not v["production"]:
                messagebox.showwarning("Uzvedums", "Uzveduma dejai jānorāda uzvedums, kura sastāvā ir šī deja.",
                                       parent=self)
                self.prod_box.focus_set()
                return
        else:
            v["production"] = ""
        for key, title in (("men_count", "Puišu skaits"), ("women_count", "Meitu skaits")):
            if v[key]:
                if not re.fullmatch(r"\d{1,3}", v[key]):
                    messagebox.showwarning(title, f"{title}: norādiet ar veselu skaitli (piemēram, 8).", parent=self)
                    return
                v[key] = str(int(v[key])) if int(v[key]) else ""
        duration = parse_duration(v["duration"])
        if duration is None:
            messagebox.showwarning("Ilgums", "Ilgumu norādiet minūtēs un sekundēs, piemēram, 3:45.", parent=self)
            return
        v["duration"] = duration
        learned = parse_date(v["learned_date"])
        if learned is None:
            messagebox.showwarning("Datums", "Iestudēšanas datums: nepareizs datums. Izmantojiet DD.MM.GGGG.",
                                   parent=self)
            return
        v["learned_date"] = learned
        db = self.app.db
        if self.dance_id is None:
            same = db.q("SELECT COUNT(*) FROM dances WHERE LOWER(title)=LOWER(?) AND LOWER(choreographer)=LOWER(?)",
                        (v["title"], v["choreographer"]))[0][0]
            if same and not messagebox.askyesno(
                    "Dublikāts", "Šāda deja jau ir sarakstā. Vai tomēr pievienot vēl vienu?", parent=self):
                return
        new_id = save_dance(db, v, self.dance_id)
        shown = self.costume_genders()
        db.save_dance_costumes(new_id, {g: names for g, names in self.costumes.items() if g in shown})
        self.app.refresh(select=new_id)
        self.destroy()


# --------------------------------------------------------------------------
# Cast of a dance
# --------------------------------------------------------------------------
class CastWindow(tk.Toplevel):
    """Choose which dancers (from Kopas pūrs) dance this dance."""

    def __init__(self, app, dance_id, parent=None, on_close=None):
        super().__init__(parent or app.root)
        self.app, self.dance_id, self.on_close = app, dance_id, on_close
        db = app.db
        self.configure(bg=CREAM)
        self.transient(parent or app.root)
        self.grab_set()
        title, lineup, men_count, women_count, dance_group = db.q(
            "SELECT title, lineup, men_count, women_count, dance_group FROM dances WHERE id=?", (dance_id,))[0]
        self.lineup, self.men_count, self.women_count = lineup or LINEUP_MIXED, men_count, women_count
        self.dance_group = dance_group if dance_group in DANCER_GROUPS else ""
        # mixed dance: the cast is shown as numbered pairs (girl + boy side by side), filled automatically
        self.mixed = is_mixed(self.lineup)
        self.sel_cid = None          # mixed dance: the dancer chosen by a click on his/her place
        self.slots = {}              # mixed dance: (row iid, column) -> cast id
        self.slot_info = {}          # mixed dance: row iid -> (pair nr, girl cast id, boy cast id)
        self.solo_info = {}          # mixed dance: row iid -> (solo nr, girl cast id, boy cast id)
        auto_pair(db, dance_id)      # pairs (mixed dance) and soloists' numbers
        self.title(f"Sastāvs — {title}")
        head = izskats.dialog_header(self, f"Dejas sastāvs: {title}", " ", colour=MODULE_COLOUR, wrap=900)
        self.need_var = tk.StringVar()
        self.need_lbl = head.subtitle
        self.need_lbl.configure(textvariable=self.need_var, font=FONT_BOLD)

        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", style="Accent.TButton", command=self.close).pack(side="right")
        ttk.Button(foot, text="⌗ Zīmējumi", command=lambda: FormationWindow(self.app, self.dance_id, parent=self)).pack(
            side="right", padx=(0, 6))
        if self.mixed:
            izskats.note(foot, "Jaukta deja: pamatsastāva meitas un puiši automātiski tiek salikti numurētos pāros "
                               "(dubultklikšķis kreisajā sarakstā — ielikt pirmajā brīvajā vietā). Dejotāju var arī ievilkt ar peli "
                               "konkrētā pārī, solistos vai rezervē (atpakaļ kreisajā sarakstā — izņemt). Dubultklikšķis uz "
                               "meitas vai puiša vietas pārī — ielikt, nomainīt vai izņemt dejotāju; uz rezerves "
                               "vietas — izvēlēties šī dejotāja aizvietotāju. Solisti (S1, S2, …) — solo pāris, tikai "
                               "meita vai tikai puisis: “Solistos ▸” vai dubultklikšķis uz solistu vietas. Rezerves "
                               "dejotājs automātiski aizvieto dejotāju, kurš notikumam atbildējis “Nebūs”. Citas grupas "
                               "dejotājs — violetā krāsā ar “(cita)”.", bg=WHITE, wrap=820).pack(side="left")
        else:
            izskats.note(foot, "Dubultklikšķis kreisajā sarakstā — pievienot pamatsastāvam; labajā — izņemt no dejas. "
                               "Ievelkot dejotāju uz cita dejotāja rindas, viņš tiek ielikts tajā pašā pārī. "
                               "Pāra numurs — vienam pārim abiem dejotājiem viens numurs. Solistiem numurs (S1, S2, …) "
                               "— vienam solo pārim viens numurs. Rezerves dejotājs "
                               "automātiski aizvieto pamatsastāva dejotāju, kurš notikumam atbildējis “Nebūs”. Citas "
                               "grupas dejotājs sastāvā — violetā krāsā ar “(cita)”.", bg=WHITE, wrap=760).pack(
                side="left")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.columnconfigure(0, weight=2, uniform="b")
        body.columnconfigure(2, weight=3, uniform="b")
        body.rowconfigure(0, weight=1)

        # left: dancers not yet in the cast
        lo, lh, left = izskats.panel(body, "Kolektīva dejotāji", subtitle="")
        lo.grid(row=0, column=0, sticky="nsew")
        self.pool_head = lh
        fbar = tk.Frame(left, bg=WHITE)
        fbar.pack(fill="x", padx=12, pady=(8, 4))
        self.search = tk.StringVar()
        izskats.search_box(fbar, self.search, width=14).pack(side="left", fill="x", expand=True)
        self.f_gender = tk.StringVar(value={LINEUP_WOMEN: GENDER_FEMALE, LINEUP_MEN: GENDER_MALE}.get(
            self.lineup, ALL))
        gcb = ttk.Combobox(fbar, textvariable=self.f_gender, values=[ALL] + GENDERS, state="readonly", width=9)
        gcb.pack(side="left", padx=(6, 0))
        # dancers of the dance's group are offered first; "Visi" or another group lets a dancer from another
        # group be put into the dance by hand
        self.f_group = tk.StringVar(value=dance_group if dance_group in DANCER_GROUPS else ALL)
        grcb = ttk.Combobox(fbar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=8)
        grcb.pack(side="left", padx=(6, 0))
        grcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        fbar2 = tk.Frame(left, bg=WHITE)
        fbar2.pack(fill="x", padx=12, pady=(0, 6))
        self.only_active = tk.BooleanVar(value=True)
        tk.Checkbutton(fbar2, text="tikai aktīvie", variable=self.only_active, command=self.refresh, bg=WHITE,
                       fg=NAVY, activebackground=WHITE, selectcolor=WHITE, font=FONT).pack(side="left")
        if self.dance_group:
            self.other_btn = tk.Label(fbar2, text="", bg=WHITE, fg=NAVY, font=("Segoe UI", 9, "underline"),
                                      cursor="hand2")
            self.other_btn.pack(side="right")
            self.other_btn.bind("<Button-1>", lambda e: self.toggle_other_groups())
        self.search.trace_add("write", lambda *a: self.refresh())
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        holder = tk.Frame(left, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.pool = ttk.Treeview(holder, columns=("name", "group", "gender", "dances"), show="headings", height=16)
        zebra(self.pool)
        self.pool.tag_configure("othergroup", foreground=OTHER_GROUP)
        for key, text, width in (("name", "Dejotājs", 170), ("group", "Grupa", 60), ("gender", "Dzimums", 75),
                                 ("dances", "Dejas", 55)):
            self.pool.heading(key, text=text)
            self.pool.column(key, width=width, minwidth=40, stretch=key == "name",
                             anchor="center" if key == "dances" else "w")
        self.pool.bind("<Double-1>", lambda e: self.add(ROLE_MAIN))
        # Deju pūrs v0.3.7: a dancer can be dragged with the mouse into a pair / soloists' place or the reserve
        self.pool.bind("<ButtonPress-1>", self.drag_press_pool, add="+")
        self.pool.bind("<B1-Motion>", self.drag_motion, add="+")
        self.pool.bind("<ButtonRelease-1>", self.drag_release, add="+")
        make_tree_with_scroll(holder, self.pool)

        # middle: buttons
        mid = tk.Frame(body, bg=CREAM)
        mid.grid(row=0, column=1, padx=10)
        ttk.Button(mid, text="Pamatsastāvā ▸", style="Accent.TButton", command=lambda: self.add(ROLE_MAIN)).pack(
            fill="x", pady=3)
        ttk.Button(mid, text="Solistos ▸", command=lambda: self.add(ROLE_SOLO)).pack(fill="x", pady=3)
        ttk.Button(mid, text="Rezervē ▸", command=lambda: self.add(ROLE_RESERVE)).pack(fill="x", pady=3)
        ttk.Button(mid, text="◂ Izņemt", style="Danger.TButton", command=self.remove).pack(fill="x", pady=(14, 3))

        # right: the cast
        ro, rh, right = izskats.panel(body, "Dejas sastāvs", subtitle="")
        ro.grid(row=0, column=2, sticky="nsew")
        self.cast_head = rh
        edit = tk.Frame(right, bg=WHITE)
        edit.pack(side="bottom", fill="x", padx=12, pady=10)
        tk.Frame(right, bg=LINE_SOFT, height=1).pack(side="bottom", fill="x")
        holder2 = tk.Frame(right, bg=WHITE)
        holder2.pack(fill="both", expand=True)
        if self.mixed:
            # one row per pair: girl and boy side by side, each with his/her reserve dancer
            self.cast = ttk.Treeview(holder2, columns=("no", "girl", "girl_sub", "boy", "boy_sub"),
                                     show="headings", height=16, selectmode="browse")
            for key, text, width in (("no", "Pāris", 52), ("girl", "Meita", 150), ("girl_sub", "Meitas rezerve", 130),
                                     ("boy", "Puisis", 150), ("boy_sub", "Puiša rezerve", 130)):
                self.cast.heading(key, text=text)
                self.cast.column(key, width=width, minwidth=40, stretch=key != "no",
                                 anchor="center" if key == "no" else "w")
            self.cast.tag_configure("empty", foreground=MUTED)
            self.cast.tag_configure("section", background=SELECTED, foreground=NAVY, font=FONT_BOLD)
            self.cast.bind("<ButtonRelease-1>", self.slot_click)
            self.cast.bind("<Double-1>", self.slot_double)
        else:
            self.cast = ttk.Treeview(holder2, columns=("pair_no", "name", "group", "gender", "role", "sub", "notes"),
                                     show="headings", height=16)
            for key, text, width in (("pair_no", "Pāris", 55), ("name", "Dejotājs", 140),
                                     ("group", "Grupa", 95), ("gender", "Dzimums", 70), ("role", "Loma", 90),
                                     ("sub", "Rezerve", 120), ("notes", "Piezīmes", 80)):
                self.cast.heading(key, text=text)
                self.cast.column(key, width=width, minwidth=40, stretch=key == "notes")
            self.cast.bind("<Double-1>", self.remove_clicked)
        zebra(self.cast)
        self.cast.tag_configure(ROLE_RESERVE, foreground=WARN_FG)
        self.cast.tag_configure(ROLE_SOLO, foreground=SOLO_FG)
        self.cast.tag_configure("inactive", foreground=GREY)
        self.cast.tag_configure("othergroup", foreground=OTHER_GROUP)
        make_tree_with_scroll(holder2, self.cast)
        self.cast.tag_configure("drop", background="#F6E3A8")
        self.drag = None             # (source, value, start x, start y, moved) while a dancer is being dragged
        self.drag_win = None
        self.drop_row = None
        if self.mixed:   # a place in a pair can be dragged to another place, to the reserve or out of the dance
            self.cast.bind("<ButtonPress-1>", self.drag_press_cast, add="+")
            self.cast.bind("<B1-Motion>", self.drag_motion, add="+")

        self.e_pair, self.e_role, self.e_notes = tk.StringVar(), tk.StringVar(), tk.StringVar()
        if self.mixed:   # which dancer the fields below belong to (chosen by a click on his/her place)
            self.chosen_lbl = tk.Label(edit, text="Uzklikšķiniet uz dejotāja vietas pārī vai solistos, lai mainītu "
                                                  "numuru, lomu, piezīmi vai rezerves dejotāju.",
                                       bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w", justify="left")
            self.chosen_lbl.grid(row=4, column=0, columnspan=4, sticky="w", pady=(8, 0))
        small_label(edit, "PĀRA / SOLO NR." if self.mixed else "PĀRIS / NR.").grid(row=0, column=0, sticky="w")
        ttk.Entry(edit, textvariable=self.e_pair, width=8).grid(row=1, column=0, sticky="w", padx=(0, 10))
        small_label(edit, "LOMA").grid(row=0, column=1, sticky="w")
        ttk.Combobox(edit, textvariable=self.e_role, values=ROLES, state="readonly", width=13).grid(
            row=1, column=1, sticky="w", padx=(0, 10))
        small_label(edit, "PIEZĪMES").grid(row=0, column=2, sticky="w")
        ttk.Entry(edit, textvariable=self.e_notes, width=18).grid(row=1, column=2, sticky="ew")
        edit.columnconfigure(2, weight=1)
        # the reserve dancer who automatically replaces this (main-cast) dancer when he cannot come
        self.e_sub = tk.StringVar()
        self.sub_map = {}
        small_label(edit, "REZERVES DEJOTĀJS (AIZVIETO, JA “NEBŪS”)").grid(row=2, column=0, columnspan=3, sticky="w",
                                                                         pady=(6, 0))
        self.sub_cb = ttk.Combobox(edit, textvariable=self.e_sub, state="readonly", width=40)
        self.sub_cb.grid(row=3, column=0, columnspan=3, sticky="ew")
        self.sub_cb.configure(state="disabled")
        ttk.Button(edit, text="Saglabāt izmaiņas", style="Accent.TButton", command=self.save_entry).grid(
            row=1, column=3, rowspan=3, padx=(10, 0), sticky="nsew")
        if not self.mixed:
            self.cast.bind("<<TreeviewSelect>>", lambda e: self.load_entry())

        self.bind("<Escape>", lambda e: self.close())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        self.after(100, lambda: fit_min_size(self))

    def close(self):
        self.app.refresh(select=self.dance_id)
        self.destroy()
        if self.on_close:
            self.on_close()

    def refresh(self, select=None):
        db = self.app.db
        counts = dict(db.q("SELECT dancer_id, COUNT(*) FROM dance_cast c JOIN dances d ON d.id = c.dance_id "
                           "WHERE d.status IN (?, ?) GROUP BY dancer_id", (DANCE_IN_REPERTOIRE, DANCE_LEARNING)))
        in_cast = db.q("SELECT c.id, c.dancer_id, d.name, d.gender, c.role, c.pair_no, c.notes, "
                       + active_dancer_sql("d") + " FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id "
                       "WHERE c.dance_id=?", (self.dance_id,))
        taken = {r[1] for r in in_cast}

        term = _norm(self.search.get())
        cond = " WHERE " + (active_dancer_sql("dancers") if self.only_active.get() else dancer_role_sql("dancers"))
        pool = []
        for did, name, gender, group in db.q("SELECT id, name, gender, dancer_group FROM dancers" + cond):
            if did in taken:
                continue
            if self.f_gender.get() != ALL and gender != self.f_gender.get():
                continue
            if self.f_group.get() != ALL and (group or "") != self.f_group.get():
                continue
            if term and term not in _norm(name):
                continue
            pool.append((did, name, gender, group or ""))
        self.pool.delete(*self.pool.get_children())
        # the dance's own group first, then the other groups
        pool.sort(key=lambda r: (bool(self.dance_group) and r[3] != self.dance_group, _norm(r[1])))
        for i, (did, name, gender, group) in enumerate(pool):
            other = bool(self.dance_group and group and group != self.dance_group)
            self.pool.insert("", "end", iid=str(did), tags=row_tags(i, "othergroup" if other else ""),
                             values=(name, group_text(group, self.dance_group), gender or "", counts.get(did, 0)))
        self.pool_head.subtitle.configure(text=str(len(pool)))
        if getattr(self, "other_btn", None) is not None:
            self.other_btn.configure(text="− rādīt tikai dejas grupu" if self.f_group.get() != self.dance_group
                                     else "＋ rādīt arī citu grupu dejotājus")

        if self.mixed:
            self.fill_pairs()
            self.cast_head.subtitle.configure(text=str(len(in_cast)))
            self.update_need(in_cast)
            return

        def pair_key(r):
            m = re.match(r"\d+", r[5] or "")
            return (ROLE_ORDER.get(r[4] or ROLE_MAIN, 0), int(m.group(0)) if m else 9999, r[5] or "",
                    r[3] != GENDER_FEMALE, _norm(r[2]))
        keep = select or (self.cast.selection()[0] if self.cast.selection() else None)
        self.cast.delete(*self.cast.get_children())
        status_by_id = status_notes(self.app.db)
        subs, covers = substitute_info(db, self.dance_id)
        groups = dict(db.q("SELECT id, dancer_group FROM dancers"))
        for i, (cid, did, name, gender, role, pair_no, notes, active) in enumerate(sorted(in_cast, key=pair_key)):
            other = bool(self.dance_group and groups.get(did) and groups.get(did) != self.dance_group)
            tags = row_tags(i, role or ROLE_MAIN, "" if active else "inactive", "othergroup" if other else "")
            self.cast.insert("", "end", iid=str(cid), tags=tags,
                             values=(solo_label(pair_number(pair_no)) if role == ROLE_SOLO else (pair_no or ""),
                                     name + ("" if active else status_by_id.get(did, "")),
                                     group_text(groups.get(did), self.dance_group), gender or "",
                                     role or ROLE_MAIN, substitute_text(did, role, subs, covers), notes or ""))
        if keep is not None and self.cast.exists(str(keep)):
            self.cast.selection_set(str(keep))
            self.cast.see(str(keep))
        self.cast_head.subtitle.configure(text=str(len(in_cast)))
        self.update_need(in_cast)

    # ---- mixed dance: the pairs ---------------------------------------------------------------
    EMPTY_SLOT = "＋ brīva vieta"

    def fill_pairs(self):
        """One row per pair (girl and boy side by side with their reserve dancers), then the reserve dancers."""
        db = self.app.db
        pairs, reserves = pair_table(db, self.dance_id, self.men_count, self.women_count)
        status_by_id = status_notes(db)
        subs, covers = substitute_info(db, self.dance_id)
        groups = dict(db.q("SELECT id, dancer_group FROM dancers"))
        self.cast.delete(*self.cast.get_children())
        self.slots, self.slot_info, self.solo_info = {}, {}, {}

        def name_of(r):
            if r is None:
                return self.EMPTY_SLOT
            other = bool(self.dance_group and groups.get(r[1]) and groups.get(r[1]) != self.dance_group)
            return (r[2] + ("" if r[7] else status_by_id.get(r[1], ""))
                    + (f"  ({groups.get(r[1])} · cita)" if other else ""))

        for i, (no, girl, boy) in enumerate(pairs):
            iid = f"p{no}"
            people = [x for x in (girl, boy) if x is not None]
            tags = row_tags(i, "empty" if not people else "",
                            "inactive" if any(not x[7] for x in people) else "",
                            "othergroup" if any(self.dance_group and groups.get(x[1]) and
                                                groups.get(x[1]) != self.dance_group for x in people) else "")
            self.cast.insert("", "end", iid=iid, tags=tags, values=(
                f"{no}.", name_of(girl), (subs.get(girl[1]) or "—") if girl else "",
                name_of(boy), (subs.get(boy[1]) or "—") if boy else ""))
            self.slot_info[iid] = (no, girl[0] if girl else None, boy[0] if boy else None)
            for col, r in (("girl", girl), ("girl_sub", girl), ("boy", boy), ("boy_sub", boy)):
                if r is not None:
                    self.slots[(iid, col)] = r[0]
        # soloists (Deju pūrs v0.3.6): S1, S2, … — a solo pair, only a girl or only a boy; the last row is free
        solos = solo_table(db, self.dance_id)
        self.cast.insert("", "end", iid="sec_solo", tags=("section",), values=("", "Solisti", "", "", ""))
        free_no = lowest_free({n for n, _g, _b in solos if n > 0})
        for k, (no, girl, boy) in enumerate(solos + [(free_no, None, None)]):
            iid = f"x{no}" if no > 0 else f"xq{k}"
            new_row = girl is None and boy is None
            self.cast.insert("", "end", iid=iid, tags=row_tags(k, "empty" if new_row else ROLE_SOLO), values=(
                solo_label(no),
                "＋ solists (meita)" if new_row else (name_of(girl) if girl else "—"),
                (subs.get(girl[1]) or "—") if girl else "",
                "＋ solists (puisis)" if new_row else (name_of(boy) if boy else "—"),
                (subs.get(boy[1]) or "—") if boy else ""))
            self.solo_info[iid] = (no if no > 0 else free_no, girl[0] if girl else None, boy[0] if boy else None)
            for col, r in (("girl", girl), ("girl_sub", girl), ("boy", boy), ("boy_sub", boy)):
                if r is not None:
                    self.slots[(iid, col)] = r[0]
        if reserves:
            self.cast.insert("", "end", iid="sec_res", tags=("section",),
                             values=("", "Rezerves dejotāji", "", "", ""))
            for j, r in enumerate(sorted(reserves, key=lambda x: (x[3] != GENDER_FEMALE, _norm(x[2])))):
                iid = f"r{r[0]}"
                who = covers.get(r[1])
                text = ("aizvieto: " + ", ".join(sorted(who, key=_norm))) if who else "rezerve"
                girl_side = r[3] == GENDER_FEMALE
                self.cast.insert("", "end", iid=iid, tags=row_tags(j, ROLE_RESERVE, "" if r[7] else "inactive"),
                                 values=("rez.", name_of(r) if girl_side else "", text if girl_side else "",
                                         "" if girl_side else name_of(r), "" if girl_side else text))
                for col in ("girl", "girl_sub", "boy", "boy_sub", "no"):
                    self.slots[(iid, col)] = r[0]
        # keep the chosen dancer visible
        if self.sel_cid is not None:
            row = next((iid for (iid, _c), cid in self.slots.items() if cid == self.sel_cid), None)
            if row:
                self.cast.selection_set(row)
                self.cast.see(row)
            else:
                self.sel_cid = None
                self.clear_entry()

    def cell_at(self, event):
        """(row iid, column key) under the mouse in the pairs table."""
        return self.cell_at_xy(event.x, event.y)

    def cell_at_xy(self, x, y):
        row = self.cast.identify_row(y)
        col = self.cast.identify_column(x)
        if not row or not col.startswith("#"):
            return None, None
        cols = self.cast["displaycolumns"]
        if cols in ("#all", ("#all",)):
            cols = self.cast["columns"]
        idx = int(col[1:]) - 1
        return row, (cols[idx] if 0 <= idx < len(cols) else None)

    # ---- dragging dancers with the mouse (Deju pūrs v0.3.7) ------------------------------------
    def drag_press_pool(self, event):
        row = self.pool.identify_row(event.y)
        self.drag = ("pool", int(row), event.x_root, event.y_root, False) if row else None

    def drag_press_cast(self, event):
        row, col = self.cell_at(event)
        cid = self.slots.get((row, col)) if row else None
        if cid is None and row and row[0] in "px" and col == "no":
            _no, g, b = (self.slot_info if row[0] == "p" else self.solo_info).get(row, (None, None, None))
            cid = g or b
        self.drag = ("cast", cid, event.x_root, event.y_root, False) if cid is not None else None

    def drag_name(self, source, value):
        db = self.app.db
        if source == "pool":
            found = db.q("SELECT name FROM dancers WHERE id=?", (value,))
        else:
            found = db.q("SELECT d.name FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id WHERE c.id=?", (value,))
        return found[0][0] if found else ""

    def drag_motion(self, event):
        if not self.drag:
            return
        source, value, x0, y0, moved = self.drag
        if not moved:
            if abs(event.x_root - x0) + abs(event.y_root - y0) < 8:
                return
            self.drag = (source, value, x0, y0, True)
            self.drag_win = tk.Toplevel(self)
            self.drag_win.overrideredirect(True)
            try:
                self.drag_win.attributes("-topmost", True)
            except tk.TclError:
                pass
            tk.Label(self.drag_win, text="⇄ " + self.drag_name(source, value), bg=NAVY, fg=WHITE, font=FONT_BOLD,
                     padx=8, pady=3).pack()
        self.drag_win.geometry(f"+{event.x_root + 14}+{event.y_root + 10}")
        self.mark_drop(self.drop_target(event.x_root, event.y_root)[1])
        return "break"

    def mark_drop(self, row):
        if row == self.drop_row:
            return
        for r in (self.drop_row, row):
            if r and self.cast.exists(r):
                tags = [t for t in self.cast.item(r, "tags") if t != "drop"]
                if r == row:
                    tags.append("drop")
                self.cast.item(r, tags=tags)
        self.drop_row = row

    def drop_target(self, x_root, y_root):
        """('cast', row iid or '') over the cast list, ('pool', None) over the dancers' list, else (None, None)."""
        w = self.winfo_containing(x_root, y_root)
        if w is self.cast:
            row = self.cast.identify_row(y_root - self.cast.winfo_rooty())
            return "cast", (row or "")
        if w is self.pool:
            return "pool", None
        return None, None

    def drag_release(self, event):
        """End of dragging (also a plain click — then nothing is done here)."""
        drag, self.drag = self.drag, None
        if self.drag_win is not None:
            self.drag_win.destroy()
            self.drag_win = None
        self.mark_drop(None)
        if not drag or not drag[4]:
            return False
        source, value = drag[0], drag[1]
        where, row = self.drop_target(event.x_root, event.y_root)
        if where == "cast":
            self.drop_on_cast(source, value, row)
        elif where == "pool" and source == "cast":     # dragged back to the dancers' list: out of the dance
            self.delete_entry(value)
            self.sel_cid = None
            self.clear_entry()
            self.refresh()
        return True

    def drop_on_cast(self, source, value, row):
        db = self.app.db
        if source == "pool":
            dancer_id = value
            found = db.q("SELECT id FROM dance_cast WHERE dance_id=? AND dancer_id=?", (self.dance_id, dancer_id))
            choice = ("cast", found[0][0]) if found else ("dancer", dancer_id)
        else:
            found = db.q("SELECT dancer_id FROM dance_cast WHERE id=?", (value,))
            if not found:
                return
            dancer_id, choice = found[0][0], ("cast", value)
        gender = (db.q("SELECT gender FROM dancers WHERE id=?", (dancer_id,)) or [("",)])[0][0]
        if not self.mixed:   # a list: dropped on a dancer — the same pair (and role); elsewhere — main cast
            role, pair_no = ROLE_MAIN, ""
            if row and row.isdigit():
                found = db.q("SELECT role, pair_no FROM dance_cast WHERE id=?", (int(row),))
                if found:
                    role, pair_no = found[0][0] or ROLE_MAIN, found[0][1] or ""
            if choice[0] == "dancer":
                db.x("INSERT INTO dance_cast (dance_id, dancer_id, role, pair_no) VALUES (?, ?, ?, ?)",
                     (self.dance_id, dancer_id, role, pair_no))
            auto_pair(db, self.dance_id)
            self.refresh()
            return
        if row.startswith("p") or row.startswith("x") or row == "sec_solo":
            if gender not in (GENDER_FEMALE, GENDER_MALE):
                messagebox.showinfo("Dzimums", "Dejotājam Kopas pūrā nav norādīts dzimums — pārī viņu ielikt nevar.",
                                    parent=self)
                return
            if row == "sec_solo":   # the heading of the soloists: new soloists
                row = next((r for r, (_n, g, b) in self.solo_info.items() if g is None and b is None), None)
                if row is None:
                    return
            info = (self.slot_info if row.startswith("p") else self.solo_info).get(row)
            if not info:
                return
            no, girl_cid, boy_cid = info
            occupant = girl_cid if gender == GENDER_FEMALE else boy_cid
            if choice == ("cast", occupant):
                return
            self.place_in_pair(no, gender, occupant, choice, role=ROLE_SOLO if row.startswith("x") else ROLE_MAIN)
        elif row.startswith("r") or row == "sec_res":   # the reserve
            if choice[0] == "dancer":
                db.x("INSERT INTO dance_cast (dance_id, dancer_id, role) VALUES (?, ?, ?)",
                     (self.dance_id, dancer_id, ROLE_RESERVE))
            else:
                db.x("UPDATE dance_cast SET role=?, pair_no='', substitute_id=NULL WHERE id=?",
                     (ROLE_RESERVE, choice[1]))
            auto_pair(db, self.dance_id)
            self.refresh()
        elif not row and choice[0] == "dancer":   # below the rows: into the first free place of a pair
            db.x("INSERT INTO dance_cast (dance_id, dancer_id, role) VALUES (?, ?, ?)",
                 (self.dance_id, dancer_id, ROLE_MAIN))
            auto_pair(db, self.dance_id)
            self.refresh()

    def slot_click(self, event):
        if self.drag_release(event):   # the end of dragging a place, not a click
            return
        row, col = self.cell_at(event)
        if row is None or row.startswith("sec"):
            return
        cid = self.slots.get((row, col))
        if cid is None and row[0] in "px":   # the number column: the girl, else the boy
            _no, g, b = (self.slot_info if row[0] == "p" else self.solo_info).get(row, (None, None, None))
            cid = g or b
        if cid is not None:
            self.sel_cid = cid
            self.load_entry()

    def slot_double(self, event):
        row, col = self.cell_at(event)
        if row is None or row.startswith("sec"):
            return "break"
        if row.startswith("r"):    # a reserve dancer: double click takes him/her out of the dance
            self.delete_entry(int(row[1:]))
            self.sel_cid = None
            self.clear_entry()
            self.refresh()
            return "break"
        solo = row.startswith("x")
        no, girl_cid, boy_cid = (self.solo_info if solo else self.slot_info).get(row, (None, None, None))
        if col in ("girl", "boy", "no"):
            gender = GENDER_MALE if col == "boy" else GENDER_FEMALE
            if col == "no":
                gender = GENDER_FEMALE if girl_cid is None or boy_cid is not None else GENDER_MALE
            SlotDialog(self, no, gender, girl_cid if gender == GENDER_FEMALE else boy_cid,
                       role=ROLE_SOLO if solo else ROLE_MAIN)
        elif col in ("girl_sub", "boy_sub"):
            cid = girl_cid if col == "girl_sub" else boy_cid
            if cid is None:
                messagebox.showinfo("Rezerves dejotājs", "Šajā vietā vēl nav dejotāja — vispirms ielieciet dejotāju "
                                                         "(dubultklikšķis uz meitas vai puiša vietas).", parent=self)
                return "break"
            self.sel_cid = cid
            self.load_entry()
            self.choose_substitute()
        return "break"

    def choose_substitute(self):
        """Pop-up list of possible reserve dancers for the chosen main-cast dancer."""
        if not self.sub_map:
            return
        current = self.e_sub.get()
        items = [(label, label, "") for label in self.sub_map]
        name = self.chosen_name or "dejotājam"

        def done(label):
            self.e_sub.set(label)
            self.save_entry()
        ChoiceDialog(self, f"Rezerves dejotājs — {name}",
                     "Rezerves dejotājs automātiski aizvieto šo dejotāju, ja notikumam viņš atbildējis “Nebūs”. "
                     "Augšā — šīs dejas rezerves, tālāk — citi tā paša dzimuma dejotāji (viņi tiks pievienoti dejai "
                     "kā rezerve).", items, done, current=current)

    def place_in_pair(self, no, gender, cid_now, choice, role=ROLE_MAIN):
        """Put a dancer into pair `no` (role ROLE_MAIN) or soloists S`no` (ROLE_SOLO), girl's or boy's place.
        choice = ('cast', cast id) for a dancer of this dance or ('dancer', dancer id) for one not in it yet. The
        dancer now in that place takes the chosen dancer's old place (if he/she was in a pair or among the
        soloists), else moves to the reserve."""
        db = self.app.db
        kind, ident = choice
        if kind == "dancer":
            db.x("INSERT INTO dance_cast (dance_id, dancer_id, role, pair_no) VALUES (?, ?, ?, ?)",
                 (self.dance_id, ident, role, str(no)))
            new_cid = db.q("SELECT id FROM dance_cast WHERE dance_id=? AND dancer_id=?", (self.dance_id, ident))[0][0]
            old_no, old_role = None, ROLE_RESERVE
        else:
            new_cid = ident
            old_role, old_pair = db.q("SELECT role, pair_no FROM dance_cast WHERE id=?", (ident,))[0]
            old_role = old_role or ROLE_MAIN
            old_no = pair_number(old_pair) if old_role in (ROLE_MAIN, ROLE_SOLO) else None
            db.x("UPDATE dance_cast SET role=?, pair_no=? WHERE id=?", (role, str(no), ident))
        if cid_now is not None and cid_now != new_cid:
            if old_no:   # both had a place: they swap places
                db.x("UPDATE dance_cast SET role=?, pair_no=? WHERE id=?", (old_role, str(old_no), cid_now))
            else:        # the dancer who was in the place goes to the reserve (and is nobody's main dancer)
                db.x("UPDATE dance_cast SET role=?, pair_no='', substitute_id=NULL WHERE id=?", (ROLE_RESERVE, cid_now))
        auto_pair(db, self.dance_id)
        self.sel_cid = new_cid
        self.refresh()
        self.load_entry()

    def toggle_other_groups(self):
        """Show every group (to put a dancer from another group into the dance by hand) or only the dance's group."""
        self.f_group.set(ALL if self.f_group.get() == self.dance_group else self.dance_group)
        self.refresh()

    def update_need(self, in_cast):
        text, colour = cast_status(in_cast, self.men_count, self.women_count)
        self.need_var.set(text)
        self.need_lbl.configure(fg=colour)

    def add(self, role):
        sel = self.pool.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju kreisajā sarakstā "
                                          "(ar Ctrl vai Shift var izvēlēties vairākus).", parent=self)
            return
        db = self.app.db
        pair_no = ""
        if role == ROLE_SOLO and len(sel) == 2:   # one girl + one boy chosen together: one solo pair
            genders = {did: g for did, g in db.q("SELECT id, gender FROM dancers")}
            if {genders.get(int(d)) for d in sel} == {GENDER_FEMALE, GENDER_MALE}:
                used = {pair_number(p) for (p,) in db.q("SELECT pair_no FROM dance_cast WHERE dance_id=? AND role=?",
                                                        (self.dance_id, ROLE_SOLO))}
                pair_no = str(lowest_free(used))
        for did in sel:
            db.x("INSERT OR IGNORE INTO dance_cast (dance_id, dancer_id, role, pair_no) VALUES (?, ?, ?, ?)",
                 (self.dance_id, int(did), role, pair_no))
        # main-cast dancers go into the first free place of a pair (mixed dance); soloists get a number
        auto_pair(db, self.dance_id)
        self.refresh()

    def remove_clicked(self, event):
        """Double click in the cast list: take that dancer out of the dance."""
        row = self.cast.identify_row(event.y)
        if not row:
            return
        self.delete_entry(int(row))
        self.clear_entry()
        self.refresh()

    def delete_entry(self, cid):
        found = self.app.db.q("SELECT dancer_id FROM dance_cast WHERE id=?", (cid,))
        self.app.db.x("DELETE FROM dance_cast WHERE id=?", (cid,))
        if found:
            clear_substitute(self.app.db, self.dance_id, found[0][0])

    def selected_cids(self):
        """Cast ids of the chosen dancers (mixed dance: the place clicked last)."""
        if self.mixed:
            return [self.sel_cid] if self.sel_cid is not None else []
        return [int(i) for i in self.cast.selection()]

    def clear_entry(self):
        if self.mixed and hasattr(self, "chosen_lbl"):
            self.chosen_name = ""
            self.chosen_lbl.configure(text="Uzklikšķiniet uz dejotāja vietas pārī vai solistos, lai mainītu numuru, "
                                           "lomu, piezīmi vai rezerves dejotāju.", fg=MUTED)
        self.e_pair.set("")
        self.e_role.set("")
        self.e_notes.set("")
        self.e_sub.set("")
        self.sub_map = {}
        self.sub_cb.configure(values=[], state="disabled")

    def remove(self):
        sel = self.selected_cids()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sastāva sarakstā" +
                                (" (uzklikšķiniet uz viņa vietas pārī)." if self.mixed else "."), parent=self)
            return
        for cid in sel:
            self.delete_entry(int(cid))
        self.sel_cid = None
        self.clear_entry()
        self.refresh()

    NO_SUB = "— nav —"

    def substitute_choices(self, dancer_id):
        """Reserve dancers of this dance first, then other active dancers of the same gender who are
        not in this dance. -> {label: dancer id}"""
        db = self.app.db
        gender = (db.q("SELECT gender FROM dancers WHERE id=?", (dancer_id,)) or [("",)])[0][0]
        cast = {d: r for d, r in db.q("SELECT dancer_id, role FROM dance_cast WHERE dance_id=?", (self.dance_id,))}
        reserves, others = [], []
        for did, name, g, grp in db.q("SELECT id, name, gender, dancer_group FROM dancers WHERE "
                                      + active_dancer_sql("dancers")
                                      + " OR id IN (SELECT dancer_id FROM dance_cast WHERE dance_id=?)", (self.dance_id,)):
            if self.dance_group and grp and grp != self.dance_group:
                name = f"{name} [{grp}]"
            if did == dancer_id:
                continue
            if cast.get(did) == ROLE_RESERVE:
                reserves.append((did, name + "  (šīs dejas rezerve)"))
            elif did not in cast and (not gender or g == gender):
                others.append((did, name))
        choices = {self.NO_SUB: None}
        for did, label in sorted(reserves, key=lambda r: _norm(r[1])) + sorted(others, key=lambda r: _norm(r[1])):
            if label in choices:
                label = f"{label} (#{did})"
            choices[label] = did
        return choices

    chosen_name = ""

    def load_entry(self):
        sel = self.selected_cids()
        if len(sel) != 1:
            return
        row = self.app.db.q("SELECT c.pair_no, c.role, c.notes, c.dancer_id, c.substitute_id, d.name, d.gender "
                            "FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id WHERE c.id=?", (int(sel[0]),))
        if row:
            pair_no, role, notes, dancer_id, sub, name, gender = row[0]
            if self.mixed:
                self.chosen_name = name
                who = "meita" if gender == GENDER_FEMALE else "puisis"
                if (role or ROLE_MAIN) == ROLE_MAIN and pair_number(pair_no):
                    where = f"{pair_number(pair_no)}. pāris, {who}"
                elif role == ROLE_SOLO:
                    where = f"solisti {solo_label(pair_number(pair_no))}, {who}"
                else:
                    where = "rezerve"
                self.chosen_lbl.configure(text=f"Izvēlēts: {name} ({where})", fg=NAVY)
            self.e_pair.set(solo_label(pair_number(pair_no)) if role == ROLE_SOLO else (pair_no or ""))
            self.e_role.set(role or ROLE_MAIN)
            self.e_notes.set(notes or "")
            if (role or ROLE_MAIN) != ROLE_RESERVE:   # main cast and soloists
                self.sub_map = self.substitute_choices(dancer_id)
                self.sub_cb.configure(values=list(self.sub_map), state="readonly")
                self.e_sub.set(next((k for k, v in self.sub_map.items() if v == sub and v is not None), self.NO_SUB))
            else:
                self.sub_map = {}
                self.sub_cb.configure(values=[], state="disabled")
                self.e_sub.set("(tikai pamatsastāva dejotājam vai solistam)")

    def edit_entry(self):
        self.load_entry()

    def save_entry(self):
        sel = self.selected_cids()
        if len(sel) != 1:
            messagebox.showinfo("Izvēle", "Izvēlieties vienu dejotāju sastāva sarakstā" +
                                (" (uzklikšķiniet uz viņa vietas pārī)." if self.mixed else "."), parent=self)
            return
        db = self.app.db
        cid = int(sel[0])
        role = self.e_role.get() or ROLE_MAIN
        sub = self.sub_map.get(self.e_sub.get()) if role != ROLE_RESERVE else None
        if sub is not None and not db.q("SELECT 1 FROM dance_cast WHERE dance_id=? AND dancer_id=?",
                                        (self.dance_id, sub)):
            # a reserve dancer from outside the dance joins it as "Rezerve"
            db.x("INSERT INTO dance_cast (dance_id, dancer_id, role) VALUES (?, ?, ?)",
                 (self.dance_id, sub, ROLE_RESERVE))
        pair_no = self.e_pair.get().strip()
        if self.mixed or role == ROLE_SOLO:
            pair_no = ""
            if role in (ROLE_MAIN, ROLE_SOLO):
                old_pair, gender = db.q("SELECT c.pair_no, d.gender FROM dance_cast c JOIN dancers d "
                                        "ON d.id = c.dancer_id WHERE c.id=?", (cid,))[0]
                wanted = pair_number(self.e_pair.get())
                old_role = db.q("SELECT role FROM dance_cast WHERE id=?", (cid,))[0][0] or ROLE_MAIN
                if old_role != role:   # moved between the pairs and the soloists: a new place is found automatically
                    wanted = None
                elif self.e_pair.get().strip() and wanted is None:
                    messagebox.showwarning("Numurs", "Pāra vai solistu numuru norādiet ar skaitli (piemēram, 3 vai "
                                                     "S2).", parent=self)
                    return
                if wanted:
                    pair_no = str(wanted)
                    # the same place in the wanted pair is taken: those two dancers swap pairs
                    for other_cid, other_pair, other_gender, other_role in db.q(
                            "SELECT c.id, c.pair_no, d.gender, c.role FROM dance_cast c JOIN dancers d "
                            "ON d.id = c.dancer_id WHERE c.dance_id=? AND c.id<>?", (self.dance_id, cid)):
                        if ((other_role or ROLE_MAIN) == role and other_gender == gender
                                and pair_number(other_pair) == wanted):
                            db.x("UPDATE dance_cast SET pair_no=? WHERE id=?",
                                 (str(pair_number(old_pair) or ""), other_cid))
            else:
                sub = None
        elif pair_no.upper().startswith("S") and pair_number(pair_no):   # no longer a soloist: no solo number
            pair_no = ""
        db.x("UPDATE dance_cast SET pair_no=?, role=?, notes=?, substitute_id=? WHERE id=?",
             (pair_no, role, self.e_notes.get().strip(), sub, cid))
        auto_pair(db, self.dance_id)
        self.refresh(select=str(cid))
        self.load_entry()


# --------------------------------------------------------------------------
# Zīmējumi (Deju pūrs v0.3.8): a place to try out the dance's figures — the pairs are dragged on the stage,
# the mouse over a pair shows its dancers and their reserve dancers
# --------------------------------------------------------------------------
GIRL_COLOUR, BOY_COLOUR, EMPTY_COLOUR = "#B8456A", NAVY, "#D8D2C4"
STAGE_BG, STRIP_BG = "#FBF6EA", "#F1EBDD"
TOKEN_R = 17
FORMATION_PRESETS = ["Aplis", "Pusaplis", "Rinda", "Divas rindas", "Kolonna", "Šahs", "Ķīlis"]


def ensure_formation_schema(db):
    db.con.executescript("""
CREATE TABLE IF NOT EXISTS dance_formations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    name TEXT DEFAULT '',
    sort_no INTEGER DEFAULT 0,
    positions TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
""")
    db.con.commit()


def surname(name):
    parts = (name or "").split()
    return parts[-1] if parts else ""


def formation_units(db, dance_id):
    """What stands on the stage: [dict(key, label, kind, girl, boy)] — pairs (mixed dance), else every main-cast
    dancer; then the soloists. girl / boy = load_cast() rows or None."""
    lineup, men_count, women_count = db.q("SELECT lineup, men_count, women_count FROM dances WHERE id=?",
                                          (dance_id,))[0]
    units = []
    if is_mixed(lineup):
        pairs, _reserves = pair_table(db, dance_id, men_count, women_count)
        for no, girl, boy in pairs:
            units.append({"key": f"p{no}", "label": str(no), "kind": "pair", "girl": girl, "boy": boy})
    else:
        main = [r for r in load_cast(db, dance_id) if (r[4] or ROLE_MAIN) == ROLE_MAIN]
        for i, r in enumerate(main, start=1):
            girl = r if r[3] != GENDER_MALE else None
            units.append({"key": f"d{r[1]}", "label": (r[5] or "").strip()[:3] or str(i), "kind": "dancer",
                          "girl": girl, "boy": None if girl else r})
    for no, girl, boy in solo_table(db, dance_id):
        units.append({"key": f"s{no}", "label": solo_label(no), "kind": "solo", "girl": girl, "boy": boy})
    return units


def preset_positions(name, keys):
    """Relative stage places (x 0 left … 1 right, y 0 back … 1 front, by the audience) for a figure."""
    import math
    n = len(keys)
    out = {}
    if not n:
        return out
    if name == "Aplis":
        for i, k in enumerate(keys):
            a = -math.pi / 2 + 2 * math.pi * i / n
            out[k] = (0.5 + 0.38 * math.cos(a), 0.46 + 0.34 * math.sin(a))
    elif name == "Pusaplis":   # open to the audience
        for i, k in enumerate(keys):
            a = math.pi * (i / (n - 1) if n > 1 else 0.5)
            out[k] = (0.5 - 0.42 * math.cos(a), 0.7 - 0.58 * math.sin(a))
    elif name == "Rinda":
        for i, k in enumerate(keys):
            out[k] = ((i + 1) / (n + 1), 0.55)
    elif name == "Divas rindas":
        back = (n + 1) // 2
        for i, k in enumerate(keys):
            row, j, m = (0, i, back) if i < back else (1, i - back, n - back)
            out[k] = ((j + 1) / (m + 1), 0.35 if row == 0 else 0.68)
    elif name == "Kolonna":   # pairs one behind the other (two columns when there are many)
        cols = 1 if n <= 8 else 2
        rows = (n + cols - 1) // cols
        for i, k in enumerate(keys):
            c, r = i % cols, i // cols
            out[k] = (0.5 if cols == 1 else (0.38 if c == 0 else 0.62), 0.08 + 0.84 * (r + 0.5) / rows)
    elif name == "Šahs":
        per = 5 if n > 12 else 4
        rows = (n + per - 1) // per
        for i, k in enumerate(keys):
            r, c = i // per, i % per
            out[k] = (0.1 + 0.8 * (c + (0.5 if r % 2 else 0)) / per + 0.04, 0.12 + 0.76 * (r + 0.5) / rows)
    elif name == "Ķīlis":     # a wedge with the point to the audience
        for i, k in enumerate(keys):
            side = -1 if i % 2 else 1
            step = (i + 1) // 2
            depth = max(1, (n - 1) // 2 + 1)
            out[k] = (0.5 + side * 0.42 * step / depth, 0.8 - 0.68 * step / depth)
    return {k: (min(0.97, max(0.03, x)), min(0.97, max(0.03, y))) for k, (x, y) in out.items()}


def ask_text(parent, title, label, initial=""):
    """A small window asking for one line of text; returns it or None."""
    win = tk.Toplevel(parent)
    win.title(title)
    win.configure(bg=CREAM)
    win.transient(parent)
    win.resizable(False, False)
    result = {"value": None}
    tk.Label(win, text=label, bg=CREAM, fg=NAVY, font=FONT).pack(anchor="w", padx=18, pady=(14, 4))
    var = tk.StringVar(value=initial)
    ent = ttk.Entry(win, textvariable=var, width=36)
    ent.pack(padx=18, fill="x")
    ent.select_range(0, "end")
    ent.focus_set()
    btns = tk.Frame(win, bg=CREAM)
    btns.pack(fill="x", padx=18, pady=12)

    def ok(*_):
        if var.get().strip():
            result["value"] = var.get().strip()
            win.destroy()
    ttk.Button(btns, text="Labi", style="Accent.TButton", command=ok).pack(side="right")
    ttk.Button(btns, text="Atcelt", command=win.destroy).pack(side="right", padx=6)
    win.bind("<Return>", ok)
    win.bind("<Escape>", lambda e: win.destroy())
    win.grab_set()
    parent.wait_window(win)
    try:
        parent.grab_set()
    except tk.TclError:
        pass
    return result["value"]


class FormationWindow(tk.Toplevel):
    """Zīmējumi: the figures of one dance. Pairs (soloists, dancers) are dragged on the stage; every figure keeps
    its own places. The mouse over a pair shows the girl and the boy with their reserve dancers."""

    def __init__(self, app, dance_id, parent=None):
        super().__init__(parent or app.root)
        self.app, self.dance_id, self.parent_win = app, dance_id, parent
        db = app.db
        ensure_formation_schema(db)
        self.configure(bg=CREAM)
        self.transient(parent or app.root)
        title, group = db.q("SELECT title, dance_group FROM dances WHERE id=?", (dance_id,))[0]
        self.can_edit = piekluve.current().can_edit("deju_purs", group=group)
        self.title(f"Zīmējumi — {title}")
        izskats.dialog_header(self, f"Zīmējumi: {title}",
                              "Pārbaudes vieta dejas zīmējumiem: ievelciet pārus uz skatuves vajadzīgajās vietās "
                              "(no aizkulisēm augšā; atpakaļ aizkulisēs — noņemt no skatuves). Katram zīmējumam "
                              "savas vietas. Uzliekot peli uz pāra, redzami dejotāji un viņu rezerves."
                              + ("" if self.can_edit else "  Tikai skatīšanai."),
                              colour=MODULE_COLOUR, wrap=1000)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", style="Accent.TButton", command=self.close).pack(side="right")
        self.show_names = tk.BooleanVar(value=True)
        tk.Checkbutton(foot, text="rādīt uzvārdus", variable=self.show_names, command=self.draw, bg=WHITE, fg=NAVY,
                       activebackground=WHITE, selectcolor=WHITE, font=FONT).pack(side="left")
        self.status = tk.Label(foot, text="", bg=WHITE, fg=MUTED, font=FONT_SMALL)
        self.status.pack(side="left", padx=14)

        # figure bar: choose / step / new / copy / rename / delete / arrange
        bar = tk.Frame(self, bg=CREAM)
        bar.pack(fill="x", padx=18, pady=(12, 0))
        small_label(bar, "ZĪMĒJUMS", bg=CREAM).pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="◂", width=3, command=lambda: self.step(-1)).pack(side="left")
        self.f_name = tk.StringVar()
        self.f_cb = ttk.Combobox(bar, textvariable=self.f_name, state="readonly", width=26)
        self.f_cb.pack(side="left", padx=4)
        self.f_cb.bind("<<ComboboxSelected>>", lambda e: self.choose(self.f_cb.current()))
        ttk.Button(bar, text="▸", width=3, command=lambda: self.step(1)).pack(side="left")
        self.edit_buttons = []
        for text, cmd in (("＋ Jauns", self.new_formation), ("Kopēt", self.copy_formation),
                          ("Pārdēvēt", self.rename_formation), ("Dzēst", self.delete_formation)):
            b = ttk.Button(bar, text=text, command=cmd, style="Danger.TButton" if text == "Dzēst" else "TButton")
            b.pack(side="left", padx=(8 if text == "＋ Jauns" else 3, 0))
            self.edit_buttons.append(b)
        self.preset = tk.StringVar(value="Sakārtot…")
        pcb = ttk.Combobox(bar, textvariable=self.preset, values=FORMATION_PRESETS, state="readonly", width=14)
        pcb.pack(side="right")
        pcb.bind("<<ComboboxSelected>>", lambda e: self.apply_preset())
        small_label(bar, "SĀKUMA IZKĀRTOJUMS", bg=CREAM).pack(side="right", padx=6)
        self.edit_buttons.append(pcb)

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=12)
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)
        stage_box = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        stage_box.grid(row=0, column=0, sticky="nsew")
        self.canvas = tk.Canvas(stage_box, bg=WHITE, width=820, height=560, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.draw())
        notes_row = tk.Frame(stage_box, bg=WHITE)
        notes_row.pack(fill="x", padx=10, pady=(0, 8))
        small_label(notes_row, "PIEZĪMES ZĪMĒJUMAM").pack(side="left", padx=(0, 6))
        self.f_notes = tk.StringVar()
        self.notes_entry = ttk.Entry(notes_row, textvariable=self.f_notes)
        self.notes_entry.pack(side="left", fill="x", expand=True)
        self.notes_entry.bind("<FocusOut>", lambda e: self.save_notes())
        self.notes_entry.bind("<Return>", lambda e: self.save_notes())

        # right: the pairs (a click lights the pair up on the stage)
        lo, _lh, right = izskats.panel(body, "Pāri")
        lo.grid(row=0, column=1, sticky="nsew", padx=(14, 0))
        holder = tk.Frame(right, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.list = ttk.Treeview(holder, columns=("no", "girl", "boy"), show="headings", height=18,
                                 selectmode="browse")
        for key, text, width in (("no", "Nr.", 44), ("girl", "Meita", 130), ("boy", "Puisis", 130)):
            self.list.heading(key, text=text)
            self.list.column(key, width=width, minwidth=36, stretch=key != "no", anchor="center" if key == "no" else "w")
        zebra(self.list)
        self.list.tag_configure("off", foreground=MUTED)
        self.list.tag_configure(ROLE_SOLO, foreground=SOLO_FG)
        self.list.bind("<<TreeviewSelect>>", lambda e: self.draw())
        make_tree_with_scroll(holder, self.list)

        if not self.can_edit:
            for b in self.edit_buttons:
                b.configure(state="disabled")
            self.notes_entry.configure(state="disabled")
        self.drag = None
        self.cur = -1
        self.load_units()
        self.load_formations()
        if not self.formations and self.can_edit:
            self.add_formation("1. zīmējums", {})
        self.choose(0)
        self.bind("<Escape>", lambda e: self.close())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.grab_set()
        self.after(100, lambda: fit_min_size(self))

    # ---- data ------------------------------------------------------------------------------------
    def load_units(self):
        db = self.app.db
        self.units = formation_units(db, self.dance_id)
        self.by_key = {u["key"]: u for u in self.units}
        self.subs, _covers = substitute_info(db, self.dance_id)
        self.notes_by_id = status_notes(db)
        self.list.delete(*self.list.get_children())
        for i, u in enumerate(self.units):
            people = [x for x in (u["girl"], u["boy"]) if x]
            tags = row_tags(i, ROLE_SOLO if u["kind"] == "solo" else "", "" if people else "off")
            if u["kind"] == "dancer":
                vals = (u["label"], u["girl"][2] if u["girl"] else "", u["boy"][2] if u["boy"] else "")
            else:
                vals = (u["label"], u["girl"][2] if u["girl"] else "—", u["boy"][2] if u["boy"] else "—")
            self.list.insert("", "end", iid=u["key"], values=vals, tags=tags)

    def load_formations(self):
        import json
        self.formations = []
        for fid, name, positions, notes in self.app.db.q(
                "SELECT id, name, positions, notes FROM dance_formations WHERE dance_id=? ORDER BY sort_no, id",
                (self.dance_id,)):
            try:
                pos = {k: (float(v[0]), float(v[1])) for k, v in json.loads(positions or "{}").items()}
            except (ValueError, TypeError, IndexError, AttributeError):
                pos = {}
            self.formations.append({"id": fid, "name": name or "Zīmējums", "pos": pos, "notes": notes or ""})
        self.f_cb.configure(values=[f"{i + 1}. {f['name']}" if not f["name"][:1].isdigit() else f["name"]
                                    for i, f in enumerate(self.formations)])

    def add_formation(self, name, pos, notes=""):
        import json
        sort_no = (max([0] + [i + 1 for i, _f in enumerate(self.formations)]))
        self.app.db.x("INSERT INTO dance_formations (dance_id, name, sort_no, positions, notes) VALUES (?, ?, ?, ?, ?)",
                      (self.dance_id, name, sort_no, json.dumps(pos), notes))
        self.load_formations()
        return len(self.formations) - 1

    @property
    def current(self):
        return self.formations[self.cur] if self.formations and 0 <= self.cur < len(self.formations) else None

    def save_positions(self):
        import json
        f = self.current
        if f is None or not self.can_edit:
            return
        self.app.db.x("UPDATE dance_formations SET positions=? WHERE id=?",
                      (json.dumps({k: [round(x, 4), round(y, 4)] for k, (x, y) in f["pos"].items()}), f["id"]))

    def save_notes(self):
        f = self.current
        if f is None or not self.can_edit or self.f_notes.get().strip() == f["notes"]:
            return
        f["notes"] = self.f_notes.get().strip()
        self.app.db.x("UPDATE dance_formations SET notes=? WHERE id=?", (f["notes"], f["id"]))

    # ---- figures ---------------------------------------------------------------------------------
    def choose(self, index):
        self.save_notes()
        self.cur = index if self.formations else -1
        if self.current:
            self.f_cb.current(self.cur)
            self.f_notes.set(self.current["notes"])
        else:
            self.f_name.set("")
            self.f_notes.set("")
        self.draw()

    def step(self, delta):
        if self.formations:
            self.choose((self.cur + delta) % len(self.formations))

    def new_formation(self):
        name = ask_text(self, "Jauns zīmējums", "Zīmējuma nosaukums:", f"{len(self.formations) + 1}. zīmējums")
        if name:
            # the new figure starts from the places of the current one (easier to change a little)
            self.choose(self.add_formation(name, dict(self.current["pos"]) if self.current else {}))

    def copy_formation(self):
        if self.current:
            self.choose(self.add_formation(self.current["name"] + " (kopija)", dict(self.current["pos"]),
                                           self.current["notes"]))

    def rename_formation(self):
        f = self.current
        if f is None:
            return
        name = ask_text(self, "Pārdēvēt zīmējumu", "Zīmējuma nosaukums:", f["name"])
        if name:
            self.app.db.x("UPDATE dance_formations SET name=? WHERE id=?", (name, f["id"]))
            keep = self.cur
            self.load_formations()
            self.choose(keep)

    def delete_formation(self):
        f = self.current
        if f is None or not messagebox.askyesno("Dzēst zīmējumu", f"Dzēst zīmējumu “{f['name']}”?", parent=self):
            return
        self.app.db.x("DELETE FROM dance_formations WHERE id=?", (f["id"],))
        keep = max(0, self.cur - 1)
        self.load_formations()
        if not self.formations:
            self.add_formation("1. zīmējums", {})
        self.choose(min(keep, len(self.formations) - 1))

    def apply_preset(self):
        name = self.preset.get()
        self.preset.set("Sakārtot…")
        f = self.current
        if f is None or name not in FORMATION_PRESETS:
            return
        if f["pos"] and not messagebox.askyesno("Sakārtot", f"Novietot visus pārus izkārtojumā “{name}”? "
                                                             "Pašreizējās vietas šajā zīmējumā tiks aizstātas.",
                                                parent=self):
            return
        main = [u["key"] for u in self.units if u["kind"] != "solo" and (u["girl"] or u["boy"])]
        solos = [u["key"] for u in self.units if u["kind"] == "solo"]
        pos = preset_positions(name, main)
        for i, k in enumerate(solos):   # the soloists in front, in the middle
            pos[k] = (0.5 + (i - (len(solos) - 1) / 2) * 0.1, 0.89)
        f["pos"] = pos
        self.save_positions()
        self.draw()

    # ---- drawing ---------------------------------------------------------------------------------
    def geometry_of_stage(self):
        w = max(self.canvas.winfo_width(), 300)
        h = max(self.canvas.winfo_height(), 300)
        strip = 2 * TOKEN_R + 34
        return w, h, strip, (24, strip + 18, w - 24, h - 30)

    def to_canvas(self, rel):
        _w, _h, _s, (x0, y0, x1, y1) = self.geometry_of_stage()
        return x0 + rel[0] * (x1 - x0), y0 + rel[1] * (y1 - y0)

    def to_rel(self, x, y):
        _w, _h, _s, (x0, y0, x1, y1) = self.geometry_of_stage()
        return (min(0.98, max(0.02, (x - x0) / (x1 - x0))), min(0.98, max(0.02, (y - y0) / (y1 - y0))))

    def draw(self):
        c = self.canvas
        c.delete("all")
        w, h, strip, (x0, y0, x1, y1) = self.geometry_of_stage()
        # backstage strip with the pairs not yet on the stage
        c.create_rectangle(8, 6, w - 8, strip, fill=STRIP_BG, outline=LINE)
        c.create_text(16, 14, text="AIZKULISES", anchor="nw", fill=MUTED, font=("Segoe UI", 7, "bold"))
        # the stage
        c.create_rectangle(x0, y0, x1, y1, fill=STAGE_BG, outline=NAVY, width=2)
        for i in range(1, 4):
            gx = x0 + (x1 - x0) * i / 4
            c.create_line(gx, y0, gx, y1, fill="#E9E1CF", dash=(2, 4) if i != 2 else (6, 4))
        for i in range(1, 3):
            gy = y0 + (y1 - y0) * i / 3
            c.create_line(x0, gy, x1, gy, fill="#E9E1CF", dash=(2, 4))
        c.create_text((x0 + x1) / 2, y0 + 10, text="AIZMUGURE", fill="#B9AE95", font=("Segoe UI", 7, "bold"))
        c.create_text((x0 + x1) / 2, y1 + 15, text="▼  SKATĪTĀJI  ▼", fill=NAVY, font=("Segoe UI", 8, "bold"))
        f = self.current
        if f is None:
            c.create_text((x0 + x1) / 2, (y0 + y1) / 2, text="Šai dejai vēl nav neviena zīmējuma.", fill=MUTED,
                          font=FONT)
            return
        if not self.units:
            c.create_text((x0 + x1) / 2, (y0 + y1) / 2, text="Dejai vēl nav sastāva — vispirms izveidojiet sastāvu.",
                          fill=MUTED, font=FONT)
        off = [u for u in self.units if u["key"] not in f["pos"]]
        step = 2 * TOKEN_R + 10
        per_row = max(1, int((w - 40 - 80) // step))
        for i, u in enumerate(off):
            self.draw_token(u, 96 + (i % per_row) * step, 8 + TOKEN_R + 4 + (i // per_row) * step, small=True)
        if len(off) > per_row:
            c.create_text(w - 14, 14, text=f"+{len(off) - per_row}", anchor="ne", fill=MUTED, font=FONT_SMALL)
        for u in self.units:
            if u["key"] in f["pos"]:
                self.draw_token(u, *self.to_canvas(f["pos"][u["key"]]))
        on = sum(1 for u in self.units if u["key"] in f["pos"])
        self.status.configure(text=f"Uz skatuves {on} no {len(self.units)}" +
                              (f" · zīmējums {self.cur + 1} no {len(self.formations)}" if self.formations else ""))

    def draw_token(self, u, x, y, small=False):
        c = self.canvas
        r = TOKEN_R
        tag = f"u_{u['key']}"
        tags = ("tok", tag)
        selected = u["key"] in self.list.selection()
        empty = not (u["girl"] or u["boy"])
        if u["kind"] == "solo":
            fill = SOLO_FG if not empty else EMPTY_COLOUR
            c.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline=GOLD, width=2, tags=tags)
        elif u["kind"] == "dancer":
            fill = GIRL_COLOUR if u["girl"] else BOY_COLOUR
            c.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline=WHITE, width=2, tags=tags)
        else:   # a pair: the girl's half (left) and the boy's half (right)
            c.create_arc(x - r, y - r, x + r, y + r, start=90, extent=180, style="pieslice", outline="",
                         fill=GIRL_COLOUR if u["girl"] else EMPTY_COLOUR, tags=tags)
            c.create_arc(x - r, y - r, x + r, y + r, start=270, extent=180, style="pieslice", outline="",
                         fill=BOY_COLOUR if u["boy"] else EMPTY_COLOUR, tags=tags)
            c.create_oval(x - r, y - r, x + r, y + r, outline=WHITE, width=2, tags=tags)
        if selected:
            c.create_oval(x - r - 5, y - r - 5, x + r + 5, y + r + 5, outline=GOLD, width=3, tags=tags)
        if any(x_ is not None and not x_[7] and not self.subs.get(x_[1]) for x_ in (u["girl"], u["boy"])):
            c.create_oval(x + r - 9, y - r - 1, x + r + 1, y - r + 9, fill=RED, outline=WHITE, tags=tags)
        c.create_text(x, y, text=u["label"], fill=WHITE, font=("Segoe UI", 9 if len(u["label"]) < 3 else 8, "bold"),
                      tags=tags)
        if self.show_names.get() and not small and not empty:
            names = " / ".join(surname(p[2]) for p in (u["girl"], u["boy"]) if p)
            c.create_text(x, y + r + 8, text=names, fill=NAVY, font=("Segoe UI", 7), tags=tags)
        c.tag_bind(tag, "<Enter>", lambda e, u=u: self.show_tip(u))
        c.tag_bind(tag, "<Leave>", lambda e: self.canvas.delete("tip"))
        if self.can_edit:
            c.tag_bind(tag, "<ButtonPress-1>", lambda e, k=u["key"]: self.press(e, k))
            c.tag_bind(tag, "<B1-Motion>", self.motion)
            c.tag_bind(tag, "<ButtonRelease-1>", self.release)

    def tip_lines(self, u):
        def who(row, title):
            if row is None:
                return f"{title}: — brīva vieta"
            name = row[2] + ("" if row[7] else self.notes_by_id.get(row[1], ""))
            sub = self.subs.get(row[1])
            return f"{title}: {name}\n      rezerve: {sub or '— nav'}"
        if u["kind"] == "pair":
            head = f"{u['label']}. pāris"
        elif u["kind"] == "solo":
            head = f"Solisti {u['label']}"
        else:
            head = "Dejotājs" + (f" · pāris {u['label']}" if u["label"] else "")
        lines = [head]
        if u["kind"] == "dancer":
            row = u["girl"] or u["boy"]
            lines.append(who(row, "Dejotāja" if u["girl"] else "Dejotājs"))
        else:
            if u["girl"] is not None or u["kind"] == "pair":
                lines.append(who(u["girl"], "Meita"))
            if u["boy"] is not None or u["kind"] == "pair":
                lines.append(who(u["boy"], "Puisis"))
        return "\n".join(lines)

    def show_tip(self, u):
        if self.drag:
            return
        c = self.canvas
        c.delete("tip")
        items = c.find_withtag(f"u_{u['key']}")
        if not items:
            return
        bx0, by0, bx1, by1 = c.bbox(f"u_{u['key']}")
        x, y = bx1 + 10, by0
        text = c.create_text(x + 8, y + 6, text=self.tip_lines(u), anchor="nw", fill=NAVY, font=FONT_SMALL,
                             tags=("tip",))
        tx0, ty0, tx1, ty1 = c.bbox(text)
        w = max(c.winfo_width(), 300)
        h = max(c.winfo_height(), 300)
        dx = -(tx1 - tx0 + 16 + (bx1 - bx0) + 20) if tx1 + 8 > w else 0
        dy = -(ty1 + 8 - h) if ty1 + 8 > h else 0
        c.move(text, dx, dy)
        tx0, ty0, tx1, ty1 = c.bbox(text)
        box = c.create_rectangle(tx0 - 8, ty0 - 6, tx1 + 8, ty1 + 6, fill=WHITE, outline=GOLD, width=1, tags=("tip",))
        c.tag_lower(box, text)

    # ---- dragging --------------------------------------------------------------------------------
    def press(self, event, key):
        self.canvas.delete("tip")
        self.drag = {"key": key, "x": event.x, "y": event.y, "moved": False}
        self.canvas.tag_raise(f"u_{key}")

    def motion(self, event):
        d = self.drag
        if not d:
            return
        dx, dy = event.x - d["x"], event.y - d["y"]
        if not d["moved"] and abs(dx) + abs(dy) < 3:
            return
        d["moved"] = True
        self.canvas.move(f"u_{d['key']}", dx, dy)
        d["x"], d["y"] = event.x, event.y

    def release(self, event):
        d, self.drag = self.drag, None
        if not d:
            return
        key = d["key"]
        if not d["moved"]:   # a click: choose the pair in the list
            self.list.selection_set(key)
            self.list.see(key)
            return
        f = self.current
        _w, _h, strip, (x0, y0, x1, y1) = self.geometry_of_stage()
        if event.y <= strip:            # back to the backstage: off the stage
            f["pos"].pop(key, None)
        else:
            f["pos"][key] = self.to_rel(event.x, event.y)
        self.save_positions()
        self.draw()

    def close(self):
        self.save_notes()
        self.destroy()
        if self.parent_win is not None:
            try:
                self.parent_win.grab_set()
                self.parent_win.focus_set()
            except tk.TclError:
                pass


class SlotDialog(tk.Toplevel):
    """Mixed dance: put a dancer straight into one place (girl or boy) of one pair or of the soloists, change or
    take him/her out."""

    def __init__(self, cw, no, gender, cid_now, role=ROLE_MAIN):
        super().__init__(cw)
        self.cw, self.no, self.gender, self.cid_now, self.role = cw, no, gender, cid_now, role
        db = cw.app.db
        self.configure(bg=CREAM)
        self.transient(cw)
        place = "meita" if gender == GENDER_FEMALE else "puisis"
        unit = f"Solisti {solo_label(no)}" if role == ROLE_SOLO else f"{no}. pāris"
        self.title(f"{unit} — {place}")
        now_name = ""
        if cid_now is not None:
            found = db.q("SELECT d.name FROM dance_cast c JOIN dancers d ON d.id = c.dancer_id WHERE c.id=?",
                         (cid_now,))
            now_name = found[0][0] if found else ""
        izskats.dialog_header(self, f"{unit} — {place}",
                              (f"Tagad: {now_name}. Izvēloties dejotāju no cita pāra vai solistiem, abi mainās "
                               f"vietām; citādi {now_name} tiek pārcelts uz rezervi." if now_name else
                               ("Vieta ir brīva. Izvēlieties solistu — solisti var būt pāris (meita un puisis), tikai "
                                "meita vai tikai puisis." if role == ROLE_SOLO else
                                "Vieta ir brīva. Izvēlieties, kurš dejotājs šajā pārī dejos.")),
                              colour=MODULE_COLOUR, wrap=560)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Ielikt solistos" if role == ROLE_SOLO else "Ielikt pārī", style="Accent.TButton",
                   command=self.ok).pack(side="right")
        ttk.Button(foot, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        if cid_now is not None:
            ttk.Button(foot, text=f"Izņemt no dejas", style="Danger.TButton", command=self.remove).pack(side="left")
            if role == ROLE_SOLO:   # stays in the dance (as a reserve), only not a soloist any more
                ttk.Button(foot, text="Nav solists (uz rezervi)", command=self.to_reserve).pack(side="left", padx=6)
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=12)
        bar = tk.Frame(body, bg=CREAM)
        bar.pack(fill="x", pady=(0, 6))
        self.search = tk.StringVar()
        izskats.search_box(bar, self.search, width=24, bg=CREAM).pack(side="left", fill="x", expand=True)
        self.all_groups = tk.BooleanVar(value=not cw.dance_group)
        if cw.dance_group:
            tk.Checkbutton(bar, text="arī citu grupu dejotāji", variable=self.all_groups, command=self.fill,
                           bg=CREAM, fg=NAVY, activebackground=CREAM, selectcolor=WHITE, font=FONT).pack(
                side="left", padx=(10, 0))
        self.search.trace_add("write", lambda *a: self.fill())
        holder = tk.Frame(body, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=("name", "group", "where"), show="headings", height=14,
                                 selectmode="browse")
        for key, text, width in (("name", "Dejotājs", 200), ("group", "Grupa", 70), ("where", "Tagad", 170)):
            self.tree.heading(key, text=text)
            self.tree.column(key, width=width, minwidth=40, stretch=key == "name")
        zebra(self.tree)
        self.tree.tag_configure("othergroup", foreground=OTHER_GROUP)
        self.tree.tag_configure(ROLE_RESERVE, foreground=WARN_FG)
        self.tree.bind("<Double-1>", lambda e: self.ok())
        self.tree.bind("<Return>", lambda e: self.ok())
        make_tree_with_scroll(holder, self.tree)
        self.load()
        self.fill()
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        self.after(80, lambda: fit_min_size(self))

    def load(self):
        """Every possible dancer of this gender: this dance's reserves, dancers not in the dance, dancers of
        other pairs (to swap)."""
        db, cw = self.cw.app.db, self.cw
        cast = {d: (cid, role, pair_no) for cid, d, role, pair_no in
                db.q("SELECT id, dancer_id, role, pair_no FROM dance_cast WHERE dance_id=?", (cw.dance_id,))}
        self.items = []
        for did, name, gender, group in db.q(
                "SELECT id, name, gender, dancer_group FROM dancers WHERE " + active_dancer_sql("dancers")
                + " OR id IN (SELECT dancer_id FROM dance_cast WHERE dance_id=?)", (cw.dance_id,)):
            if gender != self.gender:
                continue
            if did in cast:
                cid, role, pair_no = cast[did]
                if cid == self.cid_now:
                    continue
                if (role or ROLE_MAIN) == ROLE_RESERVE:
                    order, where, choice = 0, "šīs dejas rezerve", ("cast", cid)
                else:
                    n = pair_number(pair_no)
                    swap = " (mainīsies vietām)" if self.cid_now is not None else ""
                    if role == ROLE_SOLO:
                        where = f"solistos {solo_label(n)}{swap}"
                    else:
                        where = f"{n}. pārī{swap}" if n else "dejā"
                    order, choice = 3, ("cast", cid)
            else:
                order, where, choice = 1, "nav šajā dejā", ("dancer", did)
            other = bool(cw.dance_group and group and group != cw.dance_group)
            if other and order == 1:
                order = 2
            self.items.append((order, name, group or "", where, choice, other))
        self.items.sort(key=lambda x: (x[0], _norm(x[1])))

    def fill(self):
        term = _norm(self.search.get())
        self.tree.delete(*self.tree.get_children())
        self.choices = {}
        i = 0
        for order, name, group, where, choice, other in self.items:
            if other and order == 2 and not self.all_groups.get():
                continue
            if term and term not in _norm(name):
                continue
            iid = f"{choice[0]}{choice[1]}"
            self.choices[iid] = choice
            self.tree.insert("", "end", iid=iid, values=(name, group_text(group, self.cw.dance_group), where),
                             tags=row_tags(i, "othergroup" if other else "", ROLE_RESERVE if order == 0 else ""))
            i += 1
        kids = self.tree.get_children()
        if kids:
            self.tree.selection_set(kids[0])

    def destroy(self):
        super().destroy()
        try:   # the cast window gets the input back
            self.cw.grab_set()
        except tk.TclError:
            pass

    def ok(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sarakstā.", parent=self)
            return
        choice = self.choices[sel[0]]
        self.destroy()
        self.cw.place_in_pair(self.no, self.gender, self.cid_now, choice, role=self.role)

    def to_reserve(self):
        cw = self.cw
        self.destroy()
        cw.app.db.x("UPDATE dance_cast SET role=?, pair_no='', substitute_id=NULL WHERE id=?",
                    (ROLE_RESERVE, self.cid_now))
        cw.sel_cid = None
        cw.clear_entry()
        cw.refresh()

    def remove(self):
        cw = self.cw
        self.destroy()
        cw.delete_entry(self.cid_now)
        cw.sel_cid = None
        cw.clear_entry()
        cw.refresh()


class ChoiceDialog(tk.Toplevel):
    """A short list to choose one item from (with search); on_done(value) is called with the chosen one."""

    def __init__(self, parent, title, subtitle, items, on_done, current=None):
        super().__init__(parent)
        self.items, self.on_done, self.parent_win = items, on_done, parent
        self.configure(bg=CREAM)
        self.transient(parent)
        self.title(title)
        izskats.dialog_header(self, title, subtitle, colour=MODULE_COLOUR, wrap=520)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Izvēlēties", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(foot, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=12)
        self.search = tk.StringVar()
        izskats.search_box(body, self.search, width=28, bg=CREAM).pack(fill="x", pady=(0, 6))
        self.search.trace_add("write", lambda *a: self.fill())
        self.lb = tk.Listbox(body, height=14, relief="flat", bg=WHITE, fg=NAVY, selectbackground=SELECTED,
                             selectforeground=NAVY, activestyle="none", highlightthickness=1,
                             highlightbackground=LINE, font=FONT, width=46)
        self.lb.pack(fill="both", expand=True)
        self.lb.bind("<Double-1>", lambda e: self.ok())
        self.lb.bind("<Return>", lambda e: self.ok())
        self.current = current
        self.fill()
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        self.after(80, lambda: fit_min_size(self))

    def fill(self):
        term = _norm(self.search.get())
        self.lb.delete(0, tk.END)
        self.shown = [it for it in self.items if not term or term in _norm(it[0])]
        for i, (label, _v, _t) in enumerate(self.shown):
            self.lb.insert(tk.END, label)
            if label == self.current:
                self.lb.selection_set(i)
                self.lb.see(i)

    def destroy(self):
        super().destroy()
        try:
            self.parent_win.grab_set()
        except tk.TclError:
            pass

    def ok(self):
        sel = self.lb.curselection()
        if not sel:
            return
        value = self.shown[sel[0]][1]
        self.destroy()
        self.on_done(value)


# --------------------------------------------------------------------------
# Dejotāju noslodze (a tab now): who dances what
# --------------------------------------------------------------------------
class DancerLoadView(tk.Frame):
    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        self.search = tk.StringVar()
        self.f_group = tk.StringVar(value=ALL)
        self.only_none = tk.BooleanVar(value=False)
        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=20, pady=(14, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        izskats.search_box(bar, self.search, width=18).pack(side="left")
        small_label(bar, "GRUPA").pack(side="left", padx=(16, 4))
        gcb = ttk.Combobox(bar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=9)
        gcb.pack(side="left")
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        tk.Checkbutton(bar, text="Tikai dejotāji bez dejām", variable=self.only_none, command=self.refresh, bg=WHITE,
                       fg=NAVY, activebackground=WHITE, selectcolor=WHITE, font=FONT).pack(side="left", padx=(16, 0))
        self.search.trace_add("write", lambda *a: self.refresh())
        self.count_var = tk.StringVar()
        info = tk.Frame(self, bg=CREAM)
        info.pack(fill="x", padx=20, pady=(8, 0))
        tk.Label(info, textvariable=self.count_var, bg=CREAM, fg=NAVY, font=FONT_BOLD).pack(side="left")
        izskats.note(info, "Cik dejās (repertuārā un procesā) piedalās katrs aktīvais dejotājs. Sarkanā — vēl nevienā "
                           "dejā.").pack(side="right")
        outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=(6, 14))
        holder = tk.Frame(outer, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = (("name", "Dejotājs", 180), ("group", "Grupa", 70), ("gender", "Dzimums", 80),
                ("main", "Pamatsastāvā", 95), ("reserve", "Rezervē", 70), ("dances", "Dejas", 520))
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, text, width in cols:
            self.tree.heading(key, text=text)
            self.tree.column(key, width=width, minwidth=40, stretch=key == "dances",
                             anchor="center" if key in ("main", "reserve") else "w")
        zebra(self.tree)
        self.tree.tag_configure("none", foreground=RED)
        make_tree_with_scroll(holder, self.tree)
        self.refresh()

    def refresh(self, select=None):
        db = self.app.db
        rows = db.q("SELECT d.id, d.name, d.gender, d.dancer_group, c.role, x.title FROM dancers d "
                    "LEFT JOIN dance_cast c ON c.dancer_id = d.id "
                    "LEFT JOIN dances x ON x.id = c.dance_id AND x.status IN (?, ?) "
                    "WHERE " + active_dancer_sql("d"), (DANCE_IN_REPERTOIRE, DANCE_LEARNING))
        people = {}
        for did, name, gender, group, role, title in rows:
            p = people.setdefault(did, {"name": name, "gender": gender or "", "group": group or "",
                                        "main": [], "reserve": []})
            if title:
                p["reserve" if role == ROLE_RESERVE else "main"].append(title + (" (solists)" if role == ROLE_SOLO
                                                                                 else ""))
        term = _norm(self.search.get())
        self.tree.delete(*self.tree.get_children())
        n = none = 0
        for p in sorted(people.values(), key=lambda p: (-len(p["main"]), _norm(p["name"]))):
            titles = sorted(p["main"], key=_norm) + [t + " (rez.)" for t in sorted(p["reserve"], key=_norm)]
            if self.f_group.get() != ALL and p["group"] != self.f_group.get():
                continue
            if self.only_none.get() and titles:
                continue
            if term and term not in _norm(p["name"] + " " + " ".join(titles)):
                continue
            none += 0 if titles else 1
            self.tree.insert("", "end", values=(p["name"], p["group"], p["gender"], len(p["main"]), len(p["reserve"]),
                                                ", ".join(titles) or "— nevienā dejā"),
                             tags=row_tags(n, "" if titles else "none"))
            n += 1
        self.count_var.set(f"{n} aktīvie dejotāji" + (f" · {none} vēl nevienā dejā" if none else ""))


# --------------------------------------------------------------------------
# The list of dances on the left (drawn on a canvas: title, length, how full the cast is)
# --------------------------------------------------------------------------
class DanceList(tk.Frame):
    ROW = 54

    def __init__(self, master, on_select, on_open):
        super().__init__(master, bg=WHITE)
        self.on_select, self.on_open = on_select, on_open
        self.records, self.selected = [], None
        self.canvas = tk.Canvas(self, bg=WHITE, highlightthickness=0, takefocus=1)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.draw())
        self.canvas.bind("<Button-1>", self.click)
        self.canvas.bind("<Double-1>", self.double)
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.canvas.bind(seq, self.wheel)
        self.canvas.bind("<Up>", lambda e: self.move(-1))
        self.canvas.bind("<Down>", lambda e: self.move(1))
        self.canvas.bind("<Return>", lambda e: self.selected is not None and self.on_open(self.selected))

    def wheel(self, event):
        step = -1 if (getattr(event, "num", 0) == 4 or getattr(event, "delta", 0) > 0) else 1
        self.canvas.yview_scroll(step * 2, "units")

    def set(self, records, selected=None, show_status=False):
        self.records, self.selected, self.show_status = records, selected, show_status
        self.draw()

    def index_of(self, did):
        return next((i for i, r in enumerate(self.records) if r["id"] == did), None)

    def see(self, did):
        i = self.index_of(did)
        if i is None or not self.records:
            return
        total = len(self.records) * self.ROW
        top, bottom = self.canvas.yview()
        y0, y1 = i * self.ROW / total, (i + 1) * self.ROW / total
        if y0 < top:
            self.canvas.yview_moveto(y0)
        elif y1 > bottom:
            self.canvas.yview_moveto(max(0.0, y1 - (bottom - top)))

    def draw(self):
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), 200)
        if not self.records:
            c.create_text(w / 2, 40, text="Nav nevienas dejas", fill=MUTED, font=FONT)
            c.configure(scrollregion=(0, 0, w, 80))
            return
        for i, r in enumerate(self.records):
            y = i * self.ROW
            on = r["id"] == self.selected
            c.create_rectangle(0, y, w, y + self.ROW, fill=SELECTED if on else WHITE, outline="")
            if on:
                c.create_rectangle(0, y, 3, y + self.ROW, fill=MODULE_COLOUR, outline="")
            c.create_line(0, y + self.ROW - 1, w, y + self.ROW - 1, fill=LINE_SOFT)
            right = show_duration(r["duration"]) or "—"
            c.create_text(w - 12, y + 16, text=right, anchor="e", fill=MUTED, font=FONT_SMALL)
            title = r["title"]
            limit = max(8, int((w - 80) / 7.5))
            if len(title) > limit:
                title = title[:limit - 1] + "…"
            c.create_text(14, y + 16, text=title, anchor="w", fill=NAVY, font=FONT_BOLD)
            # second line: group (and status in "Visas dejas") · cast bar · cast text
            sub = r["dance_group"] + (f" · {r['status'].lower()}" if self.show_status else "")
            c.create_text(14, y + 38, text=sub, anchor="w", fill=MUTED, font=FONT_SMALL)
            need = needed_by_gender(r["men_count"], r["women_count"])
            have = r["cast_main"]
            bar_x0, bar_x1 = 14 + 90, w - 92
            if need is not None and sum(need):
                total = sum(need)
                full = not r["unfilled"]
                colour = OK_FG if full else RED
                c.create_rectangle(bar_x0, y + 35, bar_x1, y + 41, fill=LINE_SOFT, outline="")
                c.create_rectangle(bar_x0, y + 35, bar_x0 + (bar_x1 - bar_x0) * min(1, have / total), y + 41,
                                   fill=colour, outline="")
                text = "pilns" if full else f"{min(have, total)} no {total}"
            else:
                colour, text = MUTED, (f"{have} dejotāji" if have else "nav sastāva")
            c.create_text(w - 12, y + 38, text=text, anchor="e", fill=colour, font=("Segoe UI", 8, "bold"))
        c.configure(scrollregion=(0, 0, w, len(self.records) * self.ROW))

    def row_at(self, event):
        i = int(self.canvas.canvasy(event.y) // self.ROW)
        return self.records[i]["id"] if 0 <= i < len(self.records) else None

    def click(self, event):
        self.canvas.focus_set()
        did = self.row_at(event)
        if did is not None and did != self.selected:
            self.selected = did
            self.draw()
            self.on_select(did)

    def double(self, event):
        did = self.row_at(event)
        if did is not None:
            self.on_open(did)

    def move(self, step):
        if not self.records:
            return
        i = self.index_of(self.selected)
        i = 0 if i is None else max(0, min(len(self.records) - 1, i + step))
        self.selected = self.records[i]["id"]
        self.draw()
        self.see(self.selected)
        self.on_select(self.selected)


# --------------------------------------------------------------------------
# The dances view: list on the left, the chosen dance on the right
# --------------------------------------------------------------------------
class DancesView(tk.Frame):
    def __init__(self, app, parent, tab):
        super().__init__(parent, bg=CREAM)
        self.app, self.tab = app, tab
        self.records = []
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=14)
        body.columnconfigure(0, weight=0, minsize=360)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1, width=380)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        bar = tk.Frame(left, bg=WHITE)
        bar.pack(fill="x", padx=12, pady=(10, 4))
        izskats.search_box(bar, app.search, width=16).pack(side="left", fill="x", expand=True)
        gcb = ttk.Combobox(bar, textvariable=app.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=7)
        gcb.pack(side="left", padx=(6, 0))
        bar2 = tk.Frame(left, bg=WHITE)
        bar2.pack(fill="x", padx=12, pady=(2, 8))
        tcb = ttk.Combobox(bar2, textvariable=app.f_type, values=[ALL] + DANCE_TYPES, state="readonly", width=15)
        tcb.pack(side="left")
        lcb = ttk.Combobox(bar2, textvariable=app.f_lineup, values=[ALL] + LINEUPS, state="readonly", width=8)
        lcb.pack(side="left", padx=(6, 0))
        scb = ttk.Combobox(bar2, textvariable=app.sort_name, values=list(SORTS), state="readonly", width=12)
        scb.pack(side="left", padx=(6, 0), fill="x", expand=True)
        for cb in (gcb, tcb, lcb, scb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        tk.Frame(left, bg=LINE_SOFT, height=1).pack(fill="x")
        self.count_var = tk.StringVar()
        foot = tk.Frame(left, bg=WHITE)
        foot.pack(side="bottom", fill="x")
        tk.Frame(foot, bg=LINE_SOFT, height=1).pack(fill="x")
        tk.Label(foot, textvariable=self.count_var, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w").pack(
            fill="x", padx=12, pady=5)
        self.list = DanceList(left, self.select, self.open)
        self.list.pack(fill="both", expand=True)

        self.right = tk.Frame(body, bg=CREAM)
        self.right.grid(row=0, column=1, sticky="nsew")
        self.refresh()

    # -- list --------------------------------------------------------------------
    def refresh(self, select=None):
        app = self.app
        records = app.load_records()
        app.update_header(records)
        wanted = TAB_STATUSES[self.tab]
        term = _norm(app.search.get())
        shown = []
        for r in records:
            if r["status"] not in wanted:
                continue
            if app.f_type.get() != ALL and r["dance_type"] != app.f_type.get():
                continue
            if app.f_lineup.get() != ALL and r["lineup"] != app.f_lineup.get():
                continue
            if app.f_group.get() != ALL and r["dance_group"] != app.f_group.get():
                continue
            if term and term not in _norm(" ".join(r[k] for k in ("title", "dance_group", "choreographer", "music",
                                                                    "production", "costume_set", "description",
                                                                    "notes"))):
                continue
            shown.append(r)
        key = SORTS.get(app.sort_name.get(), "title")
        shown.sort(key=lambda r: _norm(r["title"]))
        if key == "duration":
            shown.sort(key=lambda r: (not r["duration"].isdigit(), -int(r["duration"]) if r["duration"].isdigit() else 0))
        elif key == "rehearsed":
            shown.sort(key=lambda r: -r["rehearsed"])
        elif key == "cast":
            shown.sort(key=lambda r: not r["unfilled"])
        elif key != "title":
            shown.sort(key=lambda r: (r[key] == "", _norm(r[key])))
        self.records = shown
        ids = [r["id"] for r in shown]
        current = select if select in ids else (app.selected_id if app.selected_id in ids else (ids[0] if ids else None))
        app.selected_id = current
        total = sum(int(r["duration"]) for r in shown if r["duration"].isdigit())
        self.count_var.set(f"{len(shown)} {dances_word(len(shown))} · kopā {show_total(total)}"
                           + ("  ·  dubultklikšķis — atvērt" if shown else ""))
        self.list.set(shown, current, show_status=self.tab in (TAB_ALL, TAB_RESTING))
        self.list.see(current)
        self.show_dance(current)

    def select(self, did):
        self.app.selected_id = did
        self.show_dance(did)

    def open(self, did):
        DanceForm(self.app, did)

    # -- the chosen dance ----------------------------------------------------------
    def show_dance(self, did):
        for w in self.right.winfo_children():
            w.destroy()
        r = next((x for x in self.records if x["id"] == did), None)
        if r is None:
            box = tk.Frame(self.right, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
            box.pack(fill="both", expand=True)
            izskats.note(box, "Šajā sarakstā nav nevienas dejas." if not self.records else
                         "Izvēlieties deju sarakstā kreisajā pusē.", bg=WHITE).pack(padx=20, pady=30)
            return
        db = self.app.db
        acc = piekluve.current()
        reh = db.rehearsal_stats().get(did, {})

        # -- header card -------------------------------------------------------------
        card = tk.Frame(self.right, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        card.pack(fill="x")
        inner = tk.Frame(card, bg=WHITE)
        inner.pack(fill="x", padx=18, pady=(14, 14))
        top = tk.Frame(inner, bg=WHITE)
        top.pack(fill="x")
        tk.Label(top, text=r["title"], bg=WHITE, fg=NAVY, font=("Georgia", 18, "bold"), anchor="w").pack(side="left")
        btn_text = "Atvērt / labot" if acc.can_edit("deju_purs", group=r["dance_group"]) or acc.costumes else "Atvērt"
        ttk.Button(top, text=btn_text, command=lambda: self.open(did)).pack(side="right")
        status_chip(top, r["status"]).pack(side="right", padx=(6, 12))
        if r["dance_group"]:
            izskats.chip(top, f"{r['dance_group']} grupa", GROUP_BG, NAVY).pack(side="right")
        sub = type_text(r["dance_type"], r["production"])
        if sub:
            tk.Label(inner, text=sub, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x", pady=(2, 0))
        facts = tk.Frame(inner, bg=WHITE)
        facts.pack(fill="x", pady=(10, 0))
        last = f" · pēdējoreiz {show_date(reh['last'])[:6]}" if reh.get("last") else ""
        items = [("Horeogrāfs", r["choreographer"] or "—"), ("Ilgums", show_duration(r["duration"]) or "—"),
                 ("Sastāvs", lineup_text(r)),
                 ("Mēģināta šosezon", f"{reh.get('season', 0)} {times_word(reh.get('season', 0))}{last}"),
                 ("Mūzika", r["music"] or "—"), ("Iestudēta", show_date(r["learned_date"]) or "—"),
                 ("Tērpu komplekts", r["costume_set"] or "—"),
                 ("Dejota koncertos", f"{reh.get('performed', 0)} {times_word(reh.get('performed', 0))}")]
        for i, (k, v) in enumerate(items):
            facts.columnconfigure(i % 4, weight=1, uniform="fact")
            cell = tk.Frame(facts, bg=WHITE)
            cell.grid(row=i // 4, column=i % 4, sticky="nw", pady=(0, 6))
            tk.Label(cell, text=k, bg=WHITE, fg=MUTED, font=("Segoe UI", 8), anchor="w").pack(anchor="w")
            tk.Label(cell, text=v, bg=WHITE, fg=NAVY, font=FONT, anchor="w", justify="left", wraplength=200).pack(
                anchor="w")
        desc = (r["description"] or "").strip()
        extra = [desc] if desc else []
        if (r["notes"] or "").strip():
            extra.append("Piezīmes: " + r["notes"].strip())
        if extra:
            tk.Frame(inner, bg=LINE_SOFT, height=1).pack(fill="x", pady=(4, 8))
            tk.Label(inner, text="\n".join(extra), bg=WHITE, fg="#4A4535", font=FONT_SMALL, anchor="w",
                     justify="left", wraplength=760).pack(fill="x")
        if (r["video"] or "").strip():
            url = r["video"].strip()
            lnk = tk.Label(inner, text="▶ " + url, bg=WHITE, fg=NAVY, font=("Segoe UI", 9, "underline"),
                           cursor="hand2", anchor="w")
            lnk.pack(fill="x", pady=(6, 0))
            lnk.bind("<Button-1>", lambda e: __import__("webbrowser").open(url))

        # -- cast + costumes + events ---------------------------------------------------------
        low = tk.Frame(self.right, bg=CREAM)
        low.pack(fill="both", expand=True, pady=(14, 0))
        low.columnconfigure(0, weight=3)
        low.columnconfigure(1, weight=2)
        low.rowconfigure(0, weight=1)
        self.build_cast(low, r)
        side = tk.Frame(low, bg=CREAM)
        side.grid(row=0, column=1, sticky="nsew", padx=(14, 0))
        self.build_costumes(side, r)
        self.build_events(side, r)

    def build_cast(self, parent, r):
        db = self.app.db
        did = r["id"]
        rows = load_cast(db, did)
        need = needed_by_gender(r["men_count"], r["women_count"])
        main = [x for x in rows if (x[4] or ROLE_MAIN) == ROLE_MAIN]
        title = f"Sastāvs · {len(main)} no {sum(need)}" if need and sum(need) else f"Sastāvs · {len(main)}"
        outer, head, body = izskats.panel(parent, title)
        outer.grid(row=0, column=0, sticky="nsew")
        if r["unfilled"] and r["status"] in (DANCE_IN_REPERTOIRE, DANCE_LEARNING):
            head.title.configure(fg=RED)
        acc = piekluve.current()
        if acc.can_edit("deju_purs", group=r["dance_group"]):
            ttk.Button(head.right, text="♫ Mainīt sastāvu",
                       command=lambda: CastWindow(self.app, did)).pack(side="right")
        if rows:   # Deju pūrs v0.3.8: the dance's figures on the stage
            ttk.Button(head.right, text="⌗ Zīmējumi",
                       command=lambda: FormationWindow(self.app, did)).pack(side="right", padx=(0, 6))
        holder = tk.Frame(body, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = ("no", "girl", "boy", "sub")
        tree = ttk.Treeview(holder, columns=cols, show="headings", height=8, selectmode="none")
        for key, text, width in (("no", "Nr.", 46), ("girl", "Meita", 150), ("boy", "Puisis", 150),
                                 ("sub", "Rezerve / piezīme", 190)):
            tree.heading(key, text=text)
            tree.column(key, width=width, minwidth=36, stretch=key != "no")
        if r["lineup"] == LINEUP_WOMEN:
            tree["displaycolumns"] = ("no", "girl", "sub")
            tree.heading("girl", text="Dejotāja")
        elif r["lineup"] == LINEUP_MEN:
            tree["displaycolumns"] = ("no", "boy", "sub")
            tree.heading("boy", text="Dejotājs")
        zebra(tree)
        tree.tag_configure("problem", foreground=RED)
        tree.tag_configure("reserve", foreground=WARN_FG)
        tree.tag_configure("solo", foreground=SOLO_FG)
        make_tree_with_scroll(holder, tree)
        tree.bind("<Double-1>", lambda e: self.open(did))
        if not rows:
            tree.insert("", "end", values=("", "Sastāvs vēl nav izveidots", "", ""))
            return
        subs, covers = substitute_info(db, did)
        notes = status_notes(db)
        short = lambda name: (name.split()[0][:1] + ". " + " ".join(name.split()[1:])) if len(name.split()) > 1 else name
        pairs, singles = {}, []
        for x in main:
            if (x[5] or "").strip():
                pairs.setdefault(x[5].strip(), []).append(x)
            else:
                singles.append(x)

        def sort_no(k):
            m = re.match(r"\d+", k)
            return (int(m.group(0)) if m else 9999, k)
        def side_by_side(people, no):
            """Girls in the left column, boys in the right one, row by row (a pair = one row)."""
            girls = [x for x in people if x[3] == GENDER_FEMALE]
            boys = [x for x in people if x[3] != GENDER_FEMALE]
            out = []
            for j in range(max(len(girls), len(boys))):
                out.append((no if j == 0 else "", girls[j] if j < len(girls) else None,
                            boys[j] if j < len(boys) else None))
            return out
        lines = []
        for k in sorted(pairs, key=sort_no):
            lines += side_by_side(pairs[k], k)
        lines += side_by_side(singles, "")
        n_pairs = len(lines)
        lines += [(solo_label(no), girl, boy) for no, girl, boy in solo_table(db, did)]   # soloists (v0.3.6)
        for i, (no, girl, boy) in enumerate(lines):
            people = [x for x in (girl, boy) if x is not None]
            info, problem = [], False
            for x in people:
                name = x[2]
                if not x[7]:
                    problem = problem or not subs.get(x[1])
                    info.append(f"{short(name)}{notes.get(x[1], '')}" + ("" if subs.get(x[1]) else " — aizvietotāja nav"))
                elif subs.get(x[1]):
                    info.append("rezerve: " + short(subs[x[1]]))
            label = lambda x: (x[2] + ("" if x[7] else " ⚠")) if x else ""
            tree.insert("", "end", values=(no, label(girl), label(boy), "; ".join(info) or "—"),
                        tags=row_tags(i, "problem" if problem else ("solo" if i >= n_pairs else "")))
        reserves = [x for x in rows if (x[4] or ROLE_MAIN) == ROLE_RESERVE]
        for j, x in enumerate(reserves):
            who = covers.get(x[1])
            values = ("rez.", x[2] if x[3] == GENDER_FEMALE else "", x[2] if x[3] != GENDER_FEMALE else "",
                      ("aizvieto: " + ", ".join(short(n) for n in who)) if who else "rezerve")
            tree.insert("", "end", values=values, tags=row_tags(len(lines) + j, "reserve"))

    def build_costumes(self, parent, r):
        outer, _h, body = izskats.panel(parent, "Tērpi")
        outer.pack(fill="x")
        costumes = self.app.db.dance_costumes(r["id"])
        inner = tk.Frame(body, bg=WHITE)
        inner.pack(fill="x", padx=14, pady=(6, 10))
        shown = False
        for gender, title in ((GENDER_FEMALE, "Meitām"), (GENDER_MALE, "Puišiem")):
            names = costumes.get(gender, [])
            if not names:
                continue
            shown = True
            tk.Label(inner, text=title, bg=WHITE, fg=MUTED, font=("Segoe UI", 8), anchor="w").pack(fill="x",
                                                                                                    pady=(4, 2))
            row = tk.Frame(inner, bg=WHITE)
            row.pack(fill="x")
            col = 0
            for name in names:
                lbl = tk.Label(row, text=name, bg=SELECTED, fg=NAVY, font=FONT_SMALL, padx=7, pady=2)
                lbl.grid(row=col // 3, column=col % 3, sticky="w", padx=(0, 5), pady=(0, 4))
                col += 1
        if not shown:
            izskats.note(inner, "Tērpu veidi nav norādīti — tos pievieno dejas logā (“Atvērt / labot” → Tērpi).",
                         bg=WHITE, wrap=260).pack(fill="x")

    def build_events(self, parent, r):
        outer, _h, body = izskats.panel(parent, "Tuvākie notikumi")
        outer.pack(fill="both", expand=True, pady=(14, 0))
        inner = tk.Frame(body, bg=WHITE)
        inner.pack(fill="x", padx=14, pady=(6, 10))
        db = self.app.db
        events = []
        if db.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='session_dances'"):
            events = db.q("SELECT s.id, s.session_date, s.kind, s.title FROM session_dances sd "
                          "JOIN attendance_sessions s ON s.id = sd.session_id WHERE sd.dance_id = ? "
                          "AND s.session_date >= ? AND s.kind NOT IN (?, ?) ORDER BY s.session_date LIMIT 4",
                          (r["id"], date.today().isoformat()) + EVENT_KINDS_SHOWN)
        if not events:
            izskats.note(inner, "Nākamajos notikumos (Notikumu pūrā) šī deja nav ielikta.", bg=WHITE,
                         wrap=260).pack(fill="x")
            return
        has_answers = bool(db.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_participants'"))
        names = dict(db.q("SELECT id, name FROM dancers"))
        for sid, day, kind, title in events:
            line = f"{show_date(day)[:6]} {kind}" + (f" “{title}”" if title else "")
            tk.Label(inner, text=line, bg=WHITE, fg=NAVY, font=FONT, anchor="w", justify="left",
                     wraplength=260).pack(fill="x", pady=(4, 0))
            if has_answers:
                declined = {d for (d,) in db.q("SELECT dancer_id FROM event_participants WHERE session_id=? AND "
                                               "answer=?", (sid, "Nebūs"))}
                lineup, uncovered = dance_lineup(db.con, r["id"], declined)
                replaced = [x for x in lineup if x[1]]
                if uncovered:
                    who = ", ".join(names.get(d, "") for d in uncovered[:3]) + ("…" if len(uncovered) > 3 else "")
                    tk.Label(inner, text=f"“Nebūs” bez aizvietotāja: {who}", bg=WHITE, fg=RED, font=FONT_SMALL,
                             anchor="w", justify="left", wraplength=260).pack(fill="x")
                elif replaced:
                    tk.Label(inner, text=f"↺ aizvietoti: {len(replaced)}", bg=WHITE, fg=WARN_FG, font=FONT_SMALL,
                             anchor="w").pack(fill="x")
                else:
                    tk.Label(inner, text="sastāvs pilns", bg=WHITE, fg=OK_FG, font=FONT_SMALL, anchor="w").pack(fill="x")


# --------------------------------------------------------------------------
# Import from Excel / CSV
# --------------------------------------------------------------------------

IMPORT_ALIASES = {
    "title": ["deja", "dejas nosaukums", "nosaukums", "dance", "title", "name"],
    "dance_group": ["grupa", "dejas grupa", "group"],
    "choreographer": ["horeografs", "horeografe", "horeografija", "horeografs e", "autors", "choreographer"],
    "music": ["muzika", "muzikas autors", "komponists", "apdare", "music", "composer"],
    "dance_type": ["veids", "dejas veids", "zanrs", "type"],
    "production": ["uzvedums", "uzveduma nosaukums", "production", "show"],
    "lineup": ["sastavs", "sastava veids", "lineup"],
    "men_count": ["puisi", "puisu skaits", "puisu sk", "viriesi", "viriesu skaits", "boys", "men"],
    "women_count": ["meitas", "meitu skaits", "meitu sk", "meitenes", "meitenu skaits", "sievietes",
                    "sieviesu skaits", "girls", "women"],
    "pairs": ["pari", "paru skaits", "pairs"],
    "duration": ["ilgums", "garums", "laiks", "duration", "length"],
    "costume_set": ["terps", "terpi", "terpu komplekts", "komplekts", "costume"],
    "status": ["statuss", "status"],
    "learned_date": ["iestudeta", "iestudesanas datums", "iestudets", "datums", "learned"],
    "video": ["video", "saite", "links", "link"],
    "description": ["apraksts", "description"],
    "notes": ["piezimes", "notes"],
}


def import_dances(db, rows):
    aliases = {k: {_norm(a) for a in v} for k, v in IMPORT_ALIASES.items()}
    header, mp, found = None, {}, []
    for i, row in enumerate(rows):
        if any(c for c in row):
            header = i
            for col, cell in enumerate(row):
                n = _norm(cell)
                for field, names in aliases.items():
                    if field not in mp and n in names:
                        mp[field] = col
            found = [c for c in row if c]
            break
    if header is None or "title" not in mp:
        return {"error": "Failā nav atrasta kolonna “Deja” (vai “Dejas nosaukums”).\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}

    def cell(row, field):
        col = mp.get(field)
        return row[col].strip() if col is not None and col < len(row) else ""

    existing = {(_norm(t), _norm(c)) for t, c in db.q("SELECT title, choreographer FROM dances")}
    added, skipped = 0, []
    for i in range(header + 1, len(rows)):
        row = rows[i]
        if not any(row):
            continue
        v = {f: cell(row, f) for f in FIELDS}
        if not v["title"]:
            skipped.append((i + 1, "nav dejas nosaukuma"))
            continue
        status = normalize_dance_status(v["status"])
        if status is None:
            skipped.append((i + 1, f"nezināms statuss “{v['status']}”"))
            continue
        v["status"] = status
        dance_type = normalize_dance_type(v["dance_type"])
        if dance_type is None:
            skipped.append((i + 1, f"nezināms dejas veids “{v['dance_type']}”"))
            continue
        v["dance_type"] = dance_type or TYPE_STAGE
        if v["dance_type"] == TYPE_SHOW and not v["production"]:
            skipped.append((i + 1, "uzveduma dejai nav norādīts uzvedums"))
            continue
        if v["dance_type"] != TYPE_SHOW:
            v["production"] = ""
        lineup = normalize_lineup(v["lineup"])
        if lineup is None:
            skipped.append((i + 1, f"nezināms sastāvs “{v['lineup']}”"))
            continue
        v["lineup"] = lineup or LINEUP_MIXED
        group = next((g for g in DANCER_GROUPS if _norm(g) == _norm(v["dance_group"])), None)
        if v["dance_group"] and group is None:
            skipped.append((i + 1, f"nezināma grupa “{v['dance_group']}” (der: {', '.join(DANCER_GROUPS)})"))
            continue
        v["dance_group"] = group or DEFAULT_DANCER_GROUP
        for key in ("men_count", "women_count"):
            m = re.search(r"\d{1,3}", v[key])
            v[key] = str(int(m.group(0))) if m and int(m.group(0)) else ""
        m = re.search(r"\d{1,3}", cell(row, "pairs"))  # older files: one "pāri" column
        if m and int(m.group(0)) and not v["men_count"] and not v["women_count"]:
            n = int(m.group(0))
            men, women = {LINEUP_WOMEN: (0, 2 * n), LINEUP_MEN: (2 * n, 0)}.get(v["lineup"], (n, n))
            v["men_count"], v["women_count"] = (str(men) if men else ""), (str(women) if women else "")
        if v["lineup"] == LINEUP_WOMEN:
            v["men_count"] = ""
        elif v["lineup"] == LINEUP_MEN:
            v["women_count"] = ""
        duration = parse_duration(v["duration"])
        if duration is None:
            skipped.append((i + 1, f"nesaprotams ilgums “{v['duration']}”"))
            continue
        v["duration"] = duration
        learned = parse_date(v["learned_date"])
        if learned is None:
            skipped.append((i + 1, f"nepareizs datums “{v['learned_date']}”"))
            continue
        v["learned_date"] = learned
        key = (_norm(v["title"]), _norm(v["choreographer"]))
        if key in existing:
            skipped.append((i + 1, f"deja “{v['title']}” jau ir sarakstā"))
            continue
        save_dance(db, v)
        existing.add(key)
        added += 1
    return {"error": None, "added": added, "skipped": skipped}


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1240x820")
        root.minsize(1000, 680)
        root.configure(bg=CREAM)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        izskats.apply_style()   # kopīgais izskats (Pūrlāde v0.8)

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")
        self.search = tk.StringVar()
        self.f_type = tk.StringVar(value=ALL)
        self.f_lineup = tk.StringVar(value=ALL)
        self.f_group = tk.StringVar(value=ALL)
        self.sort_name = tk.StringVar(value="Nosaukums")
        self.selected_id = None
        self.view = None
        self.current_tab = None
        self.search.trace_add("write", lambda *a: self.refresh())

        # Pūrlāde v0.8: baltā moduļa galvene ar cilnēm (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = izskats.module_header(
            self.root, "deju_purs", PROGRAM_NAME, f"Repertuārs, dejas un sastāvi · v{APP_VERSION}",
            on_logo=self.show_main, on_exit=None if self.on_exit is not None else self.root.destroy, tabs=True)
        acc = piekluve.current()
        if acc.can_edit("deju_purs"):
            izskats.header_button(self.header_right, "＋ Jauna deja", lambda: DanceForm(self), primary=True).pack(
                side="right", padx=(8, 0))
        if acc.edits_all("deju_purs"):
            izskats.header_button(self.header_right, "⇪ Importēt no Excel", self.run_import).pack(side="right")
        else:
            note = ("tikai skatīšanai" if acc.view_only("deju_purs") else
                    "labot var " + acc.scope_text("deju_purs") + "s dejas")
            if acc.costumes and acc.view_only("deju_purs"):
                note = "var mainīt tikai dejas tērpu veidus"
            tk.Label(self.header_right, text="🔒 " + note, bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold")).pack(
                side="right", padx=(0, 8))
        self.tabs = self.header_right.tabs
        self.tab_labels = {}
        for key, text in ((TAB_REPERTOIRE, "Repertuārs"), (TAB_LEARNING, "Procesā"),
                          (TAB_RESTING, "Atpūtā un arhīvā"), (TAB_ALL, "Visas dejas"),
                          (TAB_LOAD, "Dejotāju noslodze")):
            self.tab_labels[key] = self.tabs.add(key, text, lambda k=key: self.open_tab(k))
        self.content = tk.Frame(self.root, bg=CREAM)
        self.content.pack(fill="both", expand=True)
        self.open_tab(TAB_REPERTOIRE)

    def open_tab(self, key, select=None):
        if key == self.current_tab and self.view is not None:
            return self.view
        for child in self.content.winfo_children():
            child.destroy()
        self.current_tab = key
        self.tabs.set_active(key)
        if key == TAB_LOAD:
            self.view = DancerLoadView(self, self.content)
            self.update_header(self.load_records())
        else:
            if select is not None:
                self.selected_id = select
            self.view = DancesView(self, self.content, key)
        self.view.pack(fill="both", expand=True)
        return self.view

    # ---- data -------------------------------------------------------------
    def show_main(self):
        """Module logo: back to the main view — the repertoire, no filters."""
        self.clear_filters(refresh=False)
        self.current_tab = None
        self.open_tab(TAB_REPERTOIRE)

    def clear_filters(self, refresh=True):
        self.f_type.set(ALL)
        self.f_lineup.set(ALL)
        self.f_group.set(ALL)
        self.sort_name.set("Nosaukums")
        self.search.set("")   # (refreshes)
        if refresh:
            self.refresh()

    def load_records(self):
        db = self.db
        cast = {}
        for dance_id, gender, role in db.q("SELECT c.dance_id, d.gender, c.role FROM dance_cast c "
                                           "JOIN dancers d ON d.id = c.dancer_id WHERE " + active_dancer_sql("d")):
            c = cast.setdefault(dance_id, {"women": 0, "men": 0, "reserve": 0})
            if role == ROLE_RESERVE:
                c["reserve"] += 1
            elif role == ROLE_SOLO:     # soloists are not counted in the needed numbers of boys and girls
                pass
            elif gender == GENDER_FEMALE:
                c["women"] += 1
            elif gender == GENDER_MALE:
                c["men"] += 1
        rehearsals = db.rehearsal_stats()
        records = []
        for row in db.q("SELECT id, " + ", ".join(FIELDS) + " FROM dances"):
            r = dict(zip(("id",) + FIELDS, row))
            for k in FIELDS:
                r[k] = r[k] or ""
            if r["status"] not in DANCE_STATUSES:
                r["status"] = DANCE_IN_REPERTOIRE
            c = cast.get(r["id"], {"women": 0, "men": 0, "reserve": 0})
            r["cast_main"] = c["women"] + c["men"]
            r["cast_reserve"] = c["reserve"]
            r["rehearsed"] = rehearsals.get(r["id"], {}).get("season", 0)
            need = needed_by_gender(r["men_count"], r["women_count"])
            r["counts"] = counts_text(r["men_count"], r["women_count"])
            r["unfilled"] = bool(need) and (c["women"] < need[0] or c["men"] < need[1])
            r["cast"] = (f"{r['cast_main']}" + (f" + {c['reserve']} rez." if c["reserve"] else "")) \
                if (r["cast_main"] or c["reserve"]) else "—"
            records.append(r)
        return records

    def update_header(self, records):
        """“18 dejas repertuārā · kopā 1 h 04 min” and the number on the “Procesā” tab."""
        rep = [r for r in records if r["status"] == DANCE_IN_REPERTOIRE]
        learning = [r for r in records if r["status"] == DANCE_LEARNING]
        total = sum(int(r["duration"]) for r in rep if r["duration"].isdigit())
        unfilled = sum(1 for r in rep + learning if r["unfilled"])
        text = f"{len(rep)} {dances_word(len(rep))} repertuārā · kopā {show_total(total)}"
        if unfilled:
            text += f" · {unfilled} ar nepilnu sastāvu"
        sub = self.header_right.subtitle
        if sub is not None:
            sub.configure(text=f"{text} · v{APP_VERSION}")
        self.tab_labels[TAB_LEARNING].configure(text=f"Procesā ({len(learning)})")

    def refresh(self, select=None):
        """Called after any change (dance window, cast window, import)."""
        if self.view is None:
            return
        if select is not None and self.current_tab != TAB_LOAD:
            row = self.db.q("SELECT status FROM dances WHERE id=?", (select,))
            status = (row[0][0] if row else "") or DANCE_IN_REPERTOIRE
            if status not in TAB_STATUSES.get(self.current_tab, ()):
                tab = next((k for k, v in TAB_STATUSES.items() if status in v and k != TAB_ALL), TAB_ALL)
                self.current_tab = None
                self.open_tab(tab, select=select)
                return
        try:
            self.view.refresh(select=select)
        except tk.TclError:
            pass

    def delete_dance(self, did, parent=None):
        """Ask and delete a dance with its cast. True when deleted."""
        title, group = self.db.q("SELECT title, dance_group FROM dances WHERE id=?", (did,))[0]
        if not piekluve.current().can_edit("deju_purs", group=group):
            return piekluve.deny(parent or self.root, "Šo deju jūsu loma nevar dzēst.")
        cast = self.db.q("SELECT COUNT(*) FROM dance_cast WHERE dance_id=?", (did,))[0][0]
        extra = f"\n\nTiks dzēsts arī dejas sastāvs ({cast} dejotāji)." if cast else ""
        if not messagebox.askyesno(
                "Dzēst", f"Dzēst deju “{title}”?{extra}\n\nJa deju vienkārši vairs nedejo, labāk nomainiet "
                         f"statusu uz “{DANCE_ARCHIVED}”.", parent=parent or self.root):
            return False
        self.db.x("DELETE FROM dance_cast WHERE dance_id=?", (did,))
        self.db.x("DELETE FROM dance_costumes WHERE dance_id=?", (did,))
        self.db.x("DELETE FROM dance_formations WHERE dance_id=?", (did,))
        self.db.x("DELETE FROM dances WHERE id=?", (did,))
        if self.selected_id == did:
            self.selected_id = None
        self.refresh()
        return True


    def run_import(self):
        if not piekluve.current().edits_all("deju_purs"):
            return piekluve.deny(self.root, "Importēt dejas var tikai lietotāji, kas drīkst labot visas grupas.")
        cols = ["Deja", f"Grupa ({' / '.join(DANCER_GROUPS)}; ja nav — {DEFAULT_DANCER_GROUP})", "Horeogrāfs", "Mūzika",
                "Veids (latviešu skatuviskā deja / uzveduma deja / rotaļdeja)", "Uzvedums (uzveduma dejai)", "Sastāvs (jaukts / sieviešu / vīriešu)", "Puišu skaits", "Meitu skaits",
                "Ilgums (piem. 3:45)", "Tērpu komplekts", "Statuss (repertuārā / procesā / atpūtā / arhīvā)",
                "Iestudēta (DD.MM.GGGG)", "Apraksts", "Piezīmes"]
        info = ("Excel faila pirmajā rindā jābūt kolonnu nosaukumiem:\n\n  • " + "\n  • ".join(cols) +
                "\n\nObligāta ir kolonna “Deja”, bet uzveduma dejai — arī “Uzvedums”. Jau esošās dejas (tas pats nosaukums un horeogrāfs) "
                "tiks izlaistas. Ja statuss nav norādīts, deja būs repertuārā.")
        if not messagebox.askokcancel("Importēt no Excel", info, parent=self.root):
            return
        path = filedialog.askopenfilename(parent=self.root, title="Izvēlieties Excel failu",
                                          filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            result = import_dances(self.db, read_table(path))
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self.root)
            return
        if result["error"]:
            messagebox.showerror("Importa kļūda", result["error"], parent=self.root)
            return
        self.refresh()
        text = f"Pievienotas dejas: {result['added']}\nIzlaistas rindas: {len(result['skipped'])}"
        if result["skipped"]:
            text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
            if len(result["skipped"]) > 12:
                text += f"\n… un vēl {len(result['skipped']) - 12}"
        (messagebox.showwarning if result["skipped"] else messagebox.showinfo)("Imports pabeigts", text,
                                                                              parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
