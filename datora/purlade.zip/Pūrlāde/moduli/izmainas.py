"""
Pūrlāde — izmaiņu vēsture (shown by the "Izmaiņu vēsture" button on the start page)

Add a new entry at the TOP of CHANGELOG with every delivery:
    ("versija", "dd.mm.gggg", ["izmaiņa", "izmaiņa", ...])
"""

import tkinter as tk
from tkinter import ttk

try:
    from moduli.kopeja import CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE
except ImportError:
    from kopeja import CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE

CHANGELOG = [
    ("Pūrlāde v0.9.5 — logi vairs nepaslēpjas zem uzdevumjoslas", "05.11.2026", [
        "Labots: uz mazākiem ekrāniem (piem., klēpjdatorā) daļa uznirstošo logu bija garāki par ekrānu, un to "
        "apakšējās pogas (Saglabāt, Atcelt …) palika zem Windows uzdevumjoslas — tās nevarēja nospiest.",
        "Tagad katrs logs (arī Pūrlādes galvenais logs), parādoties, tiek pielāgots ekrāna brīvajai daļai: ja tas ir "
        "augstāks vai platāks, tas tiek samazināts un pārvietots tā, lai apakšējā josla ar pogām vienmēr būtu redzama; "
        "saturs (saraksti, cilnes) kļūst nedaudz īsāks.",
    ]),
    ("Pūrlāde v0.9.4 — rezerves kopijas (arī Google Drive)", "05.11.2026", [
        "Pūrlāde pati veido visu datu rezerves kopijas: ik pēc 7 dienām (var mainīt) un pēc katras jaunas versijas "
        "palaišanas; patur pēdējās 10 (var mainīt). Kopija ir viens .zip fails ar visiem datiem (arī tiešsaistes "
        "datubāzes) un tērpu fotogrāfijām; to veido fonā — darbu tas netraucē.",
        "Administrēšana → “Rezerves kopijas…”: mape kopijām — ieteicams Google Drive mapē (Pūrlāde to atrod pati, ja "
        "datorā ir “Google Drive datoram”, piem., G:\\Mans disks), tad kopijas nonāk arī mākonī; cik bieži un cik "
        "paturēt; kopiju saraksts, “＋ Izveidot kopiju tagad”, “Atvērt mapi” un “↺ Atjaunot no kopijas…”.",
        "Atjaunojot pašreizējie dati vispirms tiek saglabāti kopijā “pirms atjaunošanas”; tiešsaistes datubāzei "
        "jāieraksta “ATJAUNOT”, jo dati mainās visiem datoriem un Kabatas Pūrlādei.",
        "Ja Google Drive mape nav pieejama, kopija tiek saglabāta šajā datorā (lietotāja datu mapē), un "
        "administrators saņem paziņojumu, ja kopiju neizdodas izveidot.",
    ]),
    ("Pūrlāde v0.9.3 — Sezonas pārskats", "05.11.2026", [
        "Jauns sānu joslā (Kolektīvs): “Sezonas pārskats” — visa sezona (1. septembris – 31. augusts) vienā dokumentā "
        "no visiem moduļiem: Kolektīvs (dejotāji pa grupām, sievietes / vīrieši, sezonā pievienojušies), Mēģinājumi "
        "un apmeklējums (cik notika, vidējais apmeklējums kopā un pa mēnešiem, cītīgie un zemas cītības dejotāji), "
        "Koncerti, skates un pasākumi (saraksts ar vietu, dejām un dalībniekiem), Repertuārs (dejas pēc statusa, "
        "sezonā iestudētās, visvairāk dejotās), Tērpi (cik daļu, izsniegtas, jālabo) un Finanses (ienākumi un "
        "izdevumi pa kategorijām, atlikums).",
        "Var izvēlēties sezonu, grupu (visas / A / Studija / VPDK) un kuras daļas iekļaut; redzamas tikai to moduļu "
        "daļas, kurus lietotāja loma drīkst atvērt (piem., kasierim — Kolektīvs un Finanses).",
        "Poga “⎙ Saglabāt un atvērt drukāšanai / PDF” saglabā pārskatu kā glītu lapu un atver to pārlūkā — tur to "
        "var izdrukāt vai saglabāt kā PDF (Ctrl+P).",
    ]),
    ("Pūrlāde v0.9.2 — vecās versijas, “Skatīt kā” bez saglabāšanas, interneta pārtraukumi", "05.11.2026", [
        "Vecās programmas versijas (faili “Pūrlāde vX.Y.py”) pēc jaunās versijas palaišanas automātiski pārceļas uz "
        "mapi “Vecās versijas” — programmas mapē paliek tikai jaunākā.",
        "“Skatīt kā”: skatoties kā cita loma, pogas un logi strādā kā šai lomai, bet nekas netiek saglabāts; zelta "
        "joslā parādās “✋ … izmaiņa netika saglabāta”.",
        "Ja pazūd savienojums ar tiešsaistes datubāzi: virs lapas sarkana josla “Nav savienojuma ar tiešsaistes "
        "datubāzi” ar pogu “Mēģināt tagad”; Pūrlāde ik pēc 5 sekundēm pārbauda savienojumu un, kad tas atjaunojas, "
        "josla pazūd pati. Kļūdu ziņojumu vietā — viens skaidrs paziņojums (ne biežāk kā reizi 20 sekundēs), "
        "kļūdu žurnālā — viens ieraksts par katru pārtraukumu.",
    ]),
    ("Pūrlāde v0.9.1 — “Skatīt kā”: programma citas lomas acīm", "05.11.2026", [
        "Sistēmas administrators sānu joslā zem sava vārda var izvēlēties “👁 Skatīt kā…” un redzēt datora Pūrlādi "
        "tā, kā to redz Prezidents, Studijas vecākais, Tērpu pārzinis, Sociālo tīklu administrators, A grupas "
        "kasieris vai Studijas kasieris: tikai tos moduļus, pogas un labošanas iespējas, kas ir šai lomai.",
        "Kamēr skats ir citas lomas, virs lapas ir zelta josla ar lomas nosaukumu, “Cita loma…” un “✕ Atgriezties "
        "pie sava skata”; sānu joslā — “skats kā: …”. Darbojas tikai izvēlētās lomas tiesības, un tas, ko tā drīkst "
        "mainīt, tiek saglabāts pa īstam.",
        "Mainot skatu, atvērtais modulis tiek aizvērts (ja ir nesaglabātas izmaiņas — vispirms jautā), atvērtie logi "
        "aizveras. Tāpat var skatīties arī ar lokālo datubāzi.",
    ]),
    ("Pūrlāde v0.9 — Kolektīva vēsture ar laika līniju; visi moduļi jaunajā noformējumā", "05.11.2026", [
        "Ar šo versiju visi Pūrlādes moduļi (Tērpu, Deju, Kopas, Notikumu, Cītības un Zelta pūrs) un Kolektīva "
        "vēsture ir jaunajā noformējumā.",
        "Kolektīva vēsture: loga augšā jauna laika līnija — katram ieraksta veidam (dejas, koncerti, skates, "
        "pasākumi, lomas, dejotāji, mēģinājumi, citi notikumi) sava josla, katrs ieraksts ar datumu — krāsains "
        "punkts; zelta līnija rāda šodienu. Uzbraucot uz punkta, redzams datums un nosaukums; klikšķis atrod "
        "ierakstu sarakstā zemāk un parāda tā aprakstu, dubultklikšķis — labo.",
        "Laika līnija rāda visus gadus; klikšķis uz gada (vai izvēle “Gads”) parāda šo gadu pa mēnešiem, "
        "“← visi gadi” — atpakaļ. Tā ņem vērā arī filtrus zemāk (veidi, grupa, meklēšana, plānotie).",
        "Zemāk viss kā līdz šim (cilnes Hronoloģija un Lomas); logam balta virsraksta josla, pogas apakšējā joslā, "
        "ieraksta un lomas perioda logi jaunā izskatā.",
    ]),
    ("Pūrlāde v0.8.10 — Deju pūrs v0.3.5: pāri jauktā sastāva dejās", "05.11.2026", [
        "Izvēloties dejai statusu “Repertuārā”, iestudēšanas datumā automātiski ielasās šodienas datums "
        "(tikai tad, ja lauks ir tukšs); datumu joprojām var labot. Jaunai dejai šodienas datums ielikts jau sākumā.",
        "Jaukta sastāva dejās pamatsastāva dejotāji automātiski tiek salikti numurētos pāros (meita + puisis); "
        "esošās dejas sapārojas automātiski, palaižot programmu. Rezerves dejotājiem pāra nav.",
        "Dejas sastāvā pāri rādās blakus: Pāris / Meita / Meitas rezerve / Puisis / Puiša rezerve; brīvās vietas "
        "līdz vajadzīgajam pāru skaitam redzamas kā “＋ brīva vieta”. Tāpat arī dejas logā.",
        "Dubultklikšķis uz meitas vai puiša vietas atver dejotāja izvēli konkrētajam pārim: dejotājs no citā pāra "
        "tiek samainīts vietām, iepriekšējais vietas dejotājs pāriet uz rezervi; ir arī “Izņemt no dejas”.",
        "Dubultklikšķis uz rezerves vietas ļauj izvēlēties aizvietotāju konkrētajam pāra dejotājam.",
        "Mainot pāra numuru, dejotāji samainās vietām ar tā paša dzimuma dejotāju attiecīgajā pārī.",
    ]),
    ("Pūrlāde v0.8.9 — Cītības pūrs v0.2.7: jaunais noformējums", "05.11.2026", [
        "Cītības pūrs pārveidots pēc jaunā parauga. Cilnes (Šodien, Notikumi, Dejotāju cītība, Žurnāls) ir moduļa "
        "galvenē; tur arī pogas “⇩ Eksportēt cītību” un “＋ Jauns notikums”, apakšvirsrakstā — sezonas cītība.",
        "Jauna cilne “Šodien”: šodienas notikuma atzīmēšana tieši modulī, bez atsevišķa loga. Augšā notikuma veids, "
        "grupas, datums, laiks un dejas, skaitītājs “N no M atzīmēti”, pogas “✓ Pārējie ieradās” un “Atvērt "
        "notikumu…”; katram dejotājam — atbilde lietotnē un pogas Ieradās / Nokavēja / Attaisnoti / Neattaisnoti "
        "(otrs klikšķis atzīmi noņem) un piezīme; meklēšana un Visi / Puiši / Meitas; apakšā “Saglabāt atzīmes”. "
        "Ja šodien ir vairāki notikumi — izvēle augšā; ja neviena — poga “＋ Jauns notikums šodien”.",
        "Labajā pusē: “Pēdējie mēģinājumi” (apmeklējuma josla katram, klikšķis atver) un “Zema cītība” (dejotāji "
        "zem 70 %, klikšķis — dejotāja vēsture).",
        "Nesaglabātas atzīmes cilnē “Šodien”: pārejot uz citu moduli vai aizverot Pūrlādi, tiek jautāts, vai tās "
        "saglabāt.",
        "Kartītes un filtri jaunā izskatā (redzami cilnēs Notikumi, Dejotāju cītība, Žurnāls); tabulas baltos rāmjos "
        "ar svītrotām rindām. Sākuma lapas poga “▶ Šodienas mēģinājums” atver cilni “Šodien”.",
        "Notikuma logs, deju izvēle un dejotāja vēsture — jaunā izskatā (balta galvene, lauki baltos paneļos, pogas "
        "apakšējā joslā; atzīmju krāsas kā cilnē “Šodien”).",
        "Labots: Žurnālā pēc mēneša maiņas varēja rasties kļūda “Invalid column index”.",
    ]),
    ("Pūrlāde v0.8.8 — Notikumu pūrs v0.2.7: jaunais noformējums", "05.11.2026", [
        "Notikumu pūrs pārveidots pēc jaunā parauga. Cilnes (Saraksts, Kalendārs, Dejotāju dalība) ir moduļa galvenē; "
        "tur arī pogas “⇩ Eksportēt” un “＋ Jauns notikums”.",
        "Piecas kartītes jaunā izskatā: nākamais notikums (nosaukums, datums, pēc cik dienām), gaidāmie, vēl "
        "neapstiprinātie, koncerti un skates šajā sezonā. Filtri — baltā joslā virs cilnēm.",
        "Saraksts un Kalendārs: labajā pusē izvēlētā notikuma panelis — krāsaina josla ar dienu, datumu, laiku, "
        "nosaukumu, vietu, ierašanās laiku un grupām; statuss; dejotāju atbildes kā krāsaina josla (Būs / Nebūs / "
        "Varbūt / nav atbildējuši, pēc notikuma — cik ieradās); programma ar katras dejas sastāva stāvokli (pilns, "
        "↺ aizvietots, ⚠ trūkst N); pogas “Atvērt notikumu” un “✉ Info dejotājiem”.",
        "Kalendārs: notikumi krāsainās plāksnītēs (mēģinājums — oranžs, koncerts — violets, skate — sarkans, "
        "pasākums — zaļš); šodiena zelta rāmī, izvēlētā diena gaiši violeta. Klikšķis — parāda notikumu panelī, "
        "dubultklikšķis — atver; tukšā dienā panelī poga “＋ Jauns notikums šajā dienā”.",
        "Tabulas baltos rāmjos ar svītrotām rindām. Notikuma logs, deju izvēle, “Informācija dejotājiem” un dejotāja "
        "notikumu logs — jaunā izskatā: balta galvene, lauki baltā panelī, pogas apakšējā joslā.",
        "Visos moduļos: sarkanā josla “🔒 Tikai skatīšanai …” logā vairs neaizsedz loga virsrakstu.",
    ]),
    ("Pūrlāde v0.8.7 — Zelta pūrs v0.1.6: jaunais noformējums", "05.11.2026", [
        "Zelta pūrs pārveidots pēc jaunā parauga. Cilnes (Darījumi, Dalības maksas, Tērpu fonds, Autobusi, Honorāri, "
        "Pārskats) ir moduļa galvenē; tur arī grupas un gada izvēle un pogas “Sākuma atlikums”, “⚙ Kategorijas”, "
        "“⇪ Importēt no Excel”.",
        "Septiņas kartītes jaunā izskatā: atlikums kopā, kasē, kontā, gada ienākumi un izdevumi, dalības maksu un tērpu "
        "fonda parāds.",
        "Dalības maksas un Tērpu fonds: tabula ar krāsainām šūnām — zaļa ✓ samaksāts, dzeltena — daļēji (summa), "
        "sarkana ✗ — parāds, pelēka – nav jāmaksā, balta — mēnesis vēl nav pienācis (tērpu fondā zila “jāmaksā” — "
        "termiņš vēl priekšā); virs tabulas krāsu skaidrojums. Dubultklikšķis uz šūnas kā līdz šim — reģistrēt "
        "samaksu vai atvērt jau reģistrēto.",
        "Katras cilnes pogas un filtri baltā joslā; tabulas baltos rāmjos ar svītrotām rindām. “－ Izdevums” un "
        "“Dzēst” — sarkanā apmalē, “＋ Reģistrēt samaksu” — galvenā (tumšzilā) poga.",
        "Pārskatā jauna diagramma “Ienākumi un izdevumi pa mēnešiem”.",
        "Visi logi (ienākums / izdevums, dalības maksas un tērpu fonda samaksa, autobusa samaksa, apmēri, individuāla "
        "maksa, sākuma atlikums, kategorijas) jaunā izskatā: balta galvene ar paskaidrojumu, lauki baltā panelī, pogas "
        "apakšējā joslā.",
    ]),
    ("Pūrlāde v0.8.6 — Kopas pūrs v0.2.6: jaunais noformējums", "05.11.2026", [
        "Kopas pūrs pārveidots pēc jaunā parauga. Cilnes: Dejotāji, Statistika, Dzimšanas un vārda dienas; galvenē "
        "pogas “＋ Jauns dejotājs” un “⇪ Importēt no Excel”.",
        "Dejotāji: augšā kartītes — kopā dejotāju (izvēlētajā grupā, cik aktīvi un uz pauzes), sievietes / vīrieši, "
        "vidējais vecums, vidējais stāžs un “Bez e-pasta” (aktīvie dejotāji, kas nevar pieslēgties lietotnei; klikšķis "
        "parāda tikai viņus). Uzbraucot ar peli uz kartītes — skaitļi pa grupām.",
        "Filtri: meklēšana, grupa, statuss, loma (arī lietotnes lomas, piem., “Prezidents”), dzimums un “Kolonnas” — "
        "Pamata / Kontakti un lietotne / Dzimšanas un vārda dienas / Augums un izmēri / Visas kolonnas.",
        "Labajā pusē izvēlētā dejotāja panelis: grupa, statuss, stāžs, dzimšanas un vārda diena, lietotnes lomas, "
        "e-pasts, augums un izmērs, izsniegtie tērpi, cītība šosezon (no Cītības pūra), dejas (no Deju pūra), kontakti; "
        "pogas “Rediģēt” un “Dzēst”.",
        "Statistika: tabula pa grupām (kopā, aktīvi, uz pauzes, izstājušies, sievietes / vīrieši, vidējais vecums un "
        "stāžs, bez e-pasta) un diagrammas — vecums, stāžs, iestājušies pa gadiem (visām grupām vai vienai).",
        "Dzimšanas un vārda dienas: tuvākās 7 / 30 dienas, 3 mēneši vai viss gads — datums, nedēļas diena, pēc cik "
        "dienām, kurš svētki un cik gadu paliek; šodienas svētki zaļi; dubultklikšķis atver dejotāju.",
        "Dejotāja logs jaunā izskatā: galvenē vārds, iniciāļi, grupa un statuss; paneļi “Personas dati”, “Kolektīvā”, "
        "“Lietotnes lomas” (ar e-pastu Kabatas Pūrlādei) un “Kontakti”.",
    ]),
    ("Pūrlāde v0.8.5 — Deju pūrs v0.3.4: jaunais noformējums", "05.11.2026", [
        "Deju pūrs pārveidots pēc jaunā parauga. Cilnes: Repertuārs, Procesā (skaits), Atpūtā un arhīvā, Visas dejas, "
        "Dejotāju noslodze. Galvenē — cik deju repertuārā, kopējais ilgums un cik deju ar nepilnu sastāvu; pogas "
        "“＋ Jauna deja” un “⇪ Importēt no Excel”.",
        "Kreisajā pusē deju saraksts: nosaukums, ilgums, grupa un josla, cik pilns ir sastāvs (zaļš — pilns, sarkans — "
        "“15 no 16”); meklēšana, grupa, veids, sastāvs un kārtošana (nosaukums, ilgums, mēģināta šosezon, nepilnās "
        "augšā …). Bultiņas ↑ ↓ pārvietojas pa sarakstu, Enter vai dubultklikšķis atver deju.",
        "Labajā pusē izvēlētā deja: grupa un statuss, horeogrāfs, ilgums, sastāvs, cik reižu mēģināta šosezon un dejota "
        "koncertos, mūzika, iestudēšanas datums, apraksts un saite. Zem tā — sastāvs pa pāriem (meita / puisis, "
        "rezerves un neaktīvie dejotāji sarkani, ja aizvietotāja nav) ar pogu “♫ Mainīt sastāvu”, dejas tērpi un "
        "tuvākie notikumi ar brīdinājumu, ja kāds atbildējis “Nebūs” un aizvietotāja nav.",
        "“Dejotāju noslodze” tagad ir cilne (meklēšana, grupa, “Tikai dejotāji bez dejām”).",
        "Jaunā izskatā arī dejas logs (dati, tērpi, apraksts un sastāvs paneļos) un sastāva logs.",
        "Tērpu pūrs v0.5.6: pārskata diagrammas vairs nevaicā datubāzi katrā pārzīmēšanā (pārtrūkstot savienojumam ar "
        "tiešsaistes datubāzi, kļūdu žurnālā vairs nekrājas desmitiem ierakstu).",
    ]),
    ("Pūrlāde v0.8.4 — Cītības pūrs v0.2.6: “Būs” → “Ieradās”", "04.11.2026", [
        "Ja dejotājs Kabatas Pūrlādē atbildējis “Būs”, līdz ar notikuma (piem., mēģinājuma) sākumu Cītības pūrā "
        "viņam pašam ieliekas atzīme “Ieradās” — tāpat kā “Nebūs” kļūst par “Attaisnoti nebija” un “Kavēšu” par "
        "“Nokavēja”. Atzīme ieliekas, atverot Cītības pūru, un katru minūti, kamēr tas ir atvērts.",
        "Ja dejotājs tomēr neatnāca, vadītājs atzīmi nomaina; noņemta atzīme netiek ielikta atkārtoti, un jau "
        "ieliktas atzīmes netiek mainītas. “Varbūt” atzīmi neieliek.",
        "Notikuma logā “Būs” tiek iepriekš atzīmēts kā “Ieradās” tikai tad, kad notikums jau sācies.",
    ]),
    ("Pūrlāde v0.8.3 — Tērpu pūrs v0.5.5: jaunais noformējums", "04.11.2026", [
        "Tērpu pūrs pārveidots pēc jaunā parauga. Cilnes augšā: Pārskats, Izsniegt, Atgriezt, Noliktava un "
        "Izsniegtie (ar izsniegto tērpu skaitu); galvenē — tērpa detaļu un izsniegto tērpu skaits.",
        "Pārskats: piecas kartītes — kopā tērpu, noliktavā, izsniegti, izsniegti ilgāk par 30 dienām, jālabo "
        "(klikšķis atver attiecīgo sarakstu) — un četras diagrammas baltos paneļos (“⚙ Pārskata iestatījumi”).",
        "Izsniegt: trīs soļi kartītēs — 1 · Notikums, 2 · Deja (redzami dejai vajadzīgie tērpu veidi puišiem un "
        "meitām), 3 · Dejotājs (augums, izmērs, cik no vajadzīgajiem tērpiem jau izsniegti); kārtējais solis "
        "iezīmēts sarkani. Kreisajā pusē “Vajadzīgie tērpi šai dejai” (Izsniegts / Izvēlēts / Trūkst; klikšķis "
        "uz veida atlasa pieejamos) un dejotāja tērpi; labajā — pieejamie tērpi ar stāvokli, pogu “＋ Izvēlēties” "
        "(arī dubultklikšķis) un pagājušoreiz izsniegto tērpu augšā (★). Apakšā josla: kas izvēlēts, datums ar "
        "📅, piezīme un poga “Izsniegt N tērpus”. Izsniegta tērpa noņemšanai tiek prasīts apstiprinājums.",
        "Atgriezt: kreisajā pusē dejotāji ar tērpiem (cik tērpu, kopš kura datuma; sarkani — ilgāk par 30 "
        "dienām; meklēšana), labajā — dejotāja tērpi ar dienu skaitu; atzīmē ar klikšķi, apakšā “Atgriezt N "
        "tērpus” un datums ar 📅.",
        "Noliktava (agrāk “Noliktavas pārvaldība”): filtru josla (arī jauns filtrs “Stāvoklis”), pogas “＋ Jauns "
        "tērps”, “Rediģēt”, “Dzēst”, “⇪ Importēt no Excel”, “⚙ Veidi un komplekti”, skaits “Rādīti … · noliktavā "
        "… · izsniegti …”. Labajā pusē izvēlētā tērpa panelis: statuss, stāvoklis, kam izsniegts un cik dienas, "
        "pirmais foto, pēdējie izsniegumi.",
        "Izsniegtie: agrākais atsevišķais izsniegumu saraksta logs tagad ir cilne — Izsniegtie / Atgrieztie / Visi, "
        "filtri, “Ilgāk par 30 dienām”, kolonna “Dienas”; dubultklikšķis atver dejotāja tērpus cilnē “Atgriezt”.",
        "Jaunā izskatā arī visi logi: tērpa anketa (statuss un stāvoklis augšā, foto, izsniegumu vēsture), tērpu "
        "kopsavilkums (skaits ar / bez tērpa, “Rādīt tikai dejotājus bez tērpa”), veida vēsture, tērpu veidi un "
        "komplekti, pārskata iestatījumi, jautājums par nesaglabātām izmaiņām (“Atmest izmaiņas / Palikt / "
        "Saglabāt un iziet”).",
        "Sākuma lapā brīdinājums “… tērpi izsniegti ilgāk par 30 dienām” atver šo sarakstu Tērpu pūrā.",
        "Kopīgajā izskatā (moduli/izskats.py) jaunas detaļas citiem moduļiem: panelis ar virsrakstu, meklēšanas "
        "lauks, pārslēdzējs, krāsainas atzīmes, logu galvene un pogu josla.",
    ]),
    ("Pūrlāde v0.8.2 — Cītības pūrs v0.2.5", "04.11.2026", [
        "Labojot esošu notikumu (dubultklikšķis sarakstā), vairs neparādās brīdinājums “jau ir notikums” — izmaiņas "
        "(piem., izvēlētās dejas) vienkārši saglabājas tajā pašā notikumā. Brīdinājums ir tikai tad, ja notikumu "
        "pārceļ uz citu dienu, kurā jau ir tāda paša veida notikums.",
        "Veidojot jaunu notikumu dienā, kurā jau ir tāda paša veida notikums (piem., mēģinājums), var izvēlēties: "
        "“Jā” — pievienot izvēlētās dejas un atzīmes esošajam notikumam (dublikāts netiek veidots), “Nē” — izveidot "
        "atsevišķu notikumu, “Atcelt”. Plānojot atkārtojumus, aizņemtajos datumos dejas tiek pievienotas esošajiem.",
        "Dejotāju atbildes Kabatas Pūrlādē kļūst par atzīmēm pašas, tiklīdz notikums ir sācies: “Nebūs” → "
        "“Attaisnoti nebija”, “Kavēšu” → “Nokavēja” (piezīmē iemesls un minūtes). Tas notiek, atverot Cītības pūru, "
        "un katru minūti, kamēr tas ir atvērts; notikums nav jāatver un jāsaglabā. Jau ieliktas atzīmes netiek "
        "mainītas, un atzīme, ko vadītājs pēc tam noņem, netiek ielikta atkārtoti. Attiecas uz pēdējo 14 dienu "
        "notikumiem.",
    ]),
    ("Pūrlāde v0.8.1 — Zelta pūrs v0.1.5: tērpu fonds", "04.11.2026", [
        "Zelta pūrā jauna cilne “Tērpu fonds” (blakus “Dalības maksas”): katram dejotājam par katru pusgadu jāiemaksā "
        "tērpu fondā — par 1. pusgadu līdz 15. decembrim, par 2. pusgadu līdz 15. maijam. Tabulā katram dejotājam abi "
        "izvēlētās sezonas pusgadi (✓ samaksāts, daļa, ✗ termiņš pagājis, “jāmaksā” — termiņš vēl priekšā, – nav "
        "jāmaksā), samaksāts sezonā un parāds; jauna kartīte augšā “Tērpu fonda parāds”. Eksports uz Excel.",
        "“Tērpu fonda apmērs…”: summa par pusgadu katrai grupai un sezonas, kurās tā spēkā. “Reģistrēt samaksu” — "
        "par vienu vai abiem pusgadiem (summa aprēķinās pati); “Nav jāmaksā / atjaunot maksu” atbrīvo dejotāju no "
        "atzīmētā pusgada. Dejotājam, kas iestājies pēc termiņa, par to pusgadu nav jāmaksā.",
        "Jau ievestie tērpu fonda maksājumi (arī no Excel importa) automātiski pārcelti uz jauno cilni — katram "
        "maksājumam ierakstīts, par kuru pusgadu tas ir (no piezīmes “1. pusgads 2025/2026”, citādi pēc datuma).",
        "Excel imports no lapām “Tērpi A/B” tagad ieraksta arī tērpu fonda apmēru katrai sezonai un individuālos "
        "pusgadus (cita summa, “x” — nav jāmaksā). Ja tabula jau bija importēta, importu var palaist vēlreiz — "
        "maksājumi netiks dublēti, tiks pievienots apmērs un atbrīvojumi.",
        "Kategorija “Tērpu fonds” vairs netiek piedāvāta parastajā “＋ Ienākums” logā — to reģistrē cilnē “Tērpu fonds”; "
        "to nevar pārdēvēt vai dzēst.",
    ]),
    ("Pūrlāde v0.8 — jaunais noformējums (1. posms): Tērpu pūrs v0.5.4, Deju pūrs v0.3.3, Kopas pūrs v0.2.5, "
     "Notikumu pūrs v0.2.6, Cītības pūrs v0.2.4, Zelta pūrs v0.1.4", "04.11.2026", [
        "Programmas versija pasludināta par 0.8 — jauns izskats ar sānu joslu.",
        "Sānu josla kreisajā pusē: Pūrlādes logo un kolektīva nosaukums, “Sākums”, moduļi (tikai tie, kuriem lietotāja "
        "lomai ir piekļuve), “Kolektīva vēsture”, “Izmaiņu vēsture”, vadībai — “Administrēšana” un “Izstrādes darbi”; "
        "apakšā lietotājs ar lomām, “Mainīt lietotāju” un poga “Beigt darbu”. Atvērtais modulis izcelts.",
        "No viena moduļa uz citu var pāriet uzreiz sānu joslā; ja atvērtajā modulī ir nesaglabātas izmaiņas, "
        "programma pajautā — saglabāt, atmest vai palikt.",
        "Jauna sākuma lapa — vadības panelis: datums un sezona; rādītāji (aktīvie dejotāji pa grupām, sezonas cītība, "
        "izsniegtie tērpi, dejas repertuārā); “Tuvākie notikumi” ar atbildēm (klikšķis atver notikumu); “Jāpievērš "
        "uzmanība” — neatbildējušie dejotāji tuvākajiem notikumiem, “Nebūs” koncertā vai skatē, dejas ar nepilnu "
        "sastāvu, ilgi neatgriezti tērpi, tuvākās dzimšanas dienas; pogas “▶ Šodienas mēģinājums” un “+ Jauns "
        "notikums”. Katra daļa redzama tikai, ja lomai ir piekļuve attiecīgajam modulim.",
        "Visos moduļos jauna baltā galvene: moduļa logo, nosaukums, apraksts un versija, zem tās līnija moduļa krāsā "
        "(tumšzilā galvene un poga “Atgriezties moduļu izvēlē” vairs nav vajadzīga). Tērpu pūrā lielo pogu vietā cilnes: "
        "Pārskats, Izsniegt, Atgriezt, Noliktavas pārvaldība.",
        "Kopīgs pogu un tabulu stils (moduli/izskats.py): galvenā darbība tumšzila, otrā — balta ar smilškrāsas malu, "
        "dzēšana — sarkana; atslēgtas pogas skaidri pelēkas; tabulu galvenes gaišas.",
        "Moduļu saturs (sarakstu, logu un pārskatu izkārtojums) tiks pārkārtots nākamajos posmos — pa vienam modulim.",
    ]),
    ("Pūrlāde v0.7.7 — Notikumu pūrs v0.2.5, Kabatas Pūrlāde v0.27: tērpu izsniegšanas un atgriešanas datums", "04.11.2026", [
        "Notikumu pūrā cilnē “Informācija” jauna rinda “Tērpi”: datums, kad tērpus izsniedz, un datums, līdz kuram tie "
        "jāatgriež (abiem poga 📅 izvēlei no kalendāra). Ja atgriešanas datums ir agrāks par izsniegšanas datumu — "
        "brīdinājums.",
        "Atkārtotiem notikumiem šie datumi pārbīdās līdzi katra notikuma datumam (piem., izsniegšana dienu pirms).",
        "Datumi redzami tekstā “Informācija dejotājiem”, eksportā uz Excel, Kabatas Pūrlādē notikuma lapā (“Tērpu "
        "izsniegšana”, “Tērpi jāatgriež līdz …”) un personīgajā kalendārā.",
        "Lai izmaiņa nonāktu Kabatas Pūrlādē, jāpalaiž “Sagatavot lejupielādi.pyw”.",
    ]),
    ("Pūrlāde v0.7.6 — Kabatas Pūrlāde v0.26: dejotājs pats atzīmē “Nebraukšu ar autobusu”", "04.11.2026", [
        "Kabatas Pūrlādē arī dejotājs, kurš dejo notikumā, notikuma lapas sadaļā “Autobuss” var pats atzīmēt "
        "“Nebraukšu ar autobusu” (tad par autobusu nav jāmaksā) un vajadzības gadījumā atkal “Braukšu ar autobusu”.",
        "Atzīmi dejotājs var mainīt līdz 10 dienām pirms notikuma vai, ja atbilžu termiņš beidzas agrāk, līdz brīdim, kad "
        "atbildes dejotāji paši vairs mainīt nevar. Lietotnē redzams, līdz kuram datumam to var izdarīt; pēc tam atzīmi "
        "var mainīt tikai vadītājs (Notikumu pūrā). Ja par autobusu jau samaksāts, atzīmi lietotnē mainīt nevar.",
        "Lai izmaiņa nonāktu Kabatas Pūrlādē, jāpalaiž “Sagatavot lejupielādi.pyw”.",
    ]),
    ("Pūrlāde v0.7.5 — autobusa maksa: Notikumu pūrs v0.2.4, Zelta pūrs v0.1.3, Kabatas Pūrlāde v0.25", "04.11.2026", [
        "Notikumu pūrā cilnē “Informācija” transportam tagad izvēlas veidu (Autobuss / Savs transports / Sabiedriskais "
        "transports / Cits) un blakus var ierakstīt sīkāk. Ja izvēlēts “Autobuss”, parādās lauks “Autobusa cena” — cik "
        "eiro jāmaksā katram dejotājam. Vecajiem notikumiem, kuru transporta tekstā ir vārds “autobuss”, veids tiek "
        "piedāvāts automātiski.",
        "Par autobusu maksā tie, kuri dejo šajā notikumā (programmas deju sastāvs, arī rezerves dejotāji, kas kādu "
        "aizvieto), un tie, kas atzīmēti “brauks ar autobusu”. Nemaksā tie, kas atbildējuši “Nebūs”, un tie, kas "
        "atzīmēti “nebrauks”. Cilnē “Dalībnieki” josla “🚌 Autobuss” ar pogām “Brauks” / “Nebrauks” / “Nav atzīmēts”, "
        "kolonna “Autobuss” (dejo / brauks · jāmaksā … / ✓ samaksāts) un kopsavilkums: cik jāmaksā, cik samaksājuši, "
        "cik saņemts.",
        "Zelta pūrā jauna cilne “Autobusi”: notikumi ar autobusu (cena, cik jāmaksā, samaksājuši, saņemts, parāds) un "
        "izvēlētā notikuma dejotāji. Poga “＋ Reģistrēt samaksu” (vai dubultklikšķis) ieraksta samaksu vienam vai "
        "vairākiem dejotājiem — katram ienākums “Iemaksas par autobusiem un pasākumiem” ar notikumu un dejotāju. "
        "Dubultklikšķis uz jau samaksājuša dejotāja atver viņa maksājumu labošanai. Filtrs “Tikai ar parādu”, "
        "eksports uz Excel. Autobusa maksājumi netiek skaitīti kā honorārs.",
        "Kabatas Pūrlādē dejotājs, kuram jāmaksā par autobusu, plāna augšā redz sarkanu atgādinājumu “🚌 Jāsamaksā "
        "par autobusu” un notikuma kartītē “jāmaksā …” — līdz kasieris samaksu reģistrē Zelta pūrā. Notikuma lapā "
        "sadaļa “Autobuss”; tie, kas nedejo, var paši atzīmēt “Braukšu ar autobusu” (un noņemt, kamēr nav samaksāts).",
        "Lai izmaiņas nonāktu Kabatas Pūrlādē, jāpalaiž “Sagatavot lejupielādi.pyw”.",
    ]),
    ("Pūrlāde v0.7.4 — Kabatas Pūrlāde v0.24: mājaslapas pasākumu plānā tikai apstiprinātie", "04.11.2026", [
        "Mājaslapas pasākumu plānā no Notikumu pūra tagad tiek rādīti tikai koncerti un skates ar statusu "
        "“Apstiprināts”. Notikumi ar statusu “Iecerēts” vai “Atcelts” mājaslapā neparādās; kad statusu nomaina uz "
        "“Apstiprināts”, notikums parādās pats. Notikumi bez statusa (piem., ievadīti Cītības pūrā) skaitās apstiprināti.",
        "Mājaslapā ar roku pievienotie pasākumi netiek ietekmēti. Lai izmaiņa nonāktu serverī, jāpalaiž "
        "“Sagatavot lejupielādi.pyw”.",
    ]),
    ("Pūrlāde v0.7.3 — Zelta pūrs v0.1.2: imports no kases Excel tabulas", "04.11.2026", [
        "Zelta pūrā jauna poga “⇪ Importēt no Excel…”: ievada līdzšinējo kases tabulu (lapas “Fonds A/B”, “Tērpi A/B”, "
        "“Bilance A/B 2526” …). Pirms ierakstīšanas logā redzams priekšskatījums: cik ierakstu un par kādu summu katrā "
        "grupā, kuri cilvēki nav atrasti Kopas pūrā, un piezīmes par šūnām, ko nevarēja saprast.",
        "Ko var importēt (katru atsevišķi): dalības maksas pa mēnešiem; iemaksas par autobusiem, ballēm, nometnēm, "
        "pusdienām (cena no kolonnas virsraksta, piem., “(10 €)”, vai summa šūnā; “(+1)” — maksāts arī par viesi); "
        "tērpu fondu (pusgada maksas); izdevumus no Bilance lapu blokiem (dāvanas, tērpi, autobusi, pasākumi, "
        "uzvedums, bankas izmaksas …) un papildu ienākumus (koncerti, avansi, uzveduma ieņēmumi). Saraksts “Maksājumi "
        "ar rēķiniem” un kopsavilkumi netiek ņemti, jo tie atkārto tos pašus izdevumus.",
        "Tabulas grupu burti tiek piesaistīti Pūrlādes grupām (A → A, B → Studija; var mainīt). Var izvēlēties, no "
        "kuras sezonas importēt. Dalības maksas apmērs katrai sezonai tiek ņemts no tabulas; dejotājiem ar citu maksu "
        "un mēnešiem ar “x” — individuāla maksa tieši tajā mēnesī (“x” — nav jāmaksā).",
        "Importu var atkārtot, kad Excel tabula papildināta: jau ievestie ieraksti netiek dublēti (katram ir atslēga "
        "— lapa un šūna). Ja vēlas, trūkstošos cilvēkus var pievienot Kopas pūrā.",
        "Datumi: ja Excel datumā sajaukta diena ar mēnesi vai gads (bieži pēc ievades “08/10”), tiek ņemts ticamākais "
        "datums tuvu attiecīgajam mēnesim; ja datuma nav, — mēneša 15. datums (dalības maksai) vai iepriekšējā ieraksta "
        "datums (izdevumiem).",
        "Dalības maksas logā poga “Nav jāmaksā / atjaunot maksu”: atzīmētajiem mēnešiem dejotājam maksa nepienākas (–).",
    ]),
    ("Pūrlāde v0.7.2 — Tērpu pūrs v0.5.3", "04.11.2026", [
        "Tērpu izsniegšanā “Tērpu kopsavilkumā” tagad tiek rādītas tikai meitenes vai tikai puiši — atkarībā no izvēles "
        "“Visi dejotāji / Meitenes / Puiši” virs dejotāju saraksta; kopsavilkuma virsrakstā redzams izvēlētais filtrs.",
    ]),
    ("Pūrlāde v0.7.1 — Zelta pūrs v0.1.1: dalības maksas pa sezonām", "01.11.2026", [
        "Dalības maksas tagad skatās pa sezonām: sezona sākas septembrī un beidzas nākamā gada augustā. Cilnē "
        "“Dalības maksas” ir izvēle “Sezona” (piem., 2026/2027), tabulas mēneši ir no septembra līdz augustam; arī "
        "parāds un kartīte “Dalības maksu parāds” ir par izvēlēto sezonu. Samaksas logā arī jāizvēlas sezona.",
        "Dalības maksas apmēram tagad norāda, no kura LĪDZ kuram mēnesim tas spēkā (abi ieskaitot), vai “bez beigām”. "
        "Pogas “Visa sezona” (septembris–augusts) un “Sept.–maijs” aizpilda periodu ar vienu klikšķi. Mēnešos, kuros "
        "neviena maksa nav spēkā (piem., vasarā), dalības maksa nepienākas (–), arī individuālā maksa. Uzklikšķinot uz "
        "rindas, tās dati parādās laukos — tos var mainīt un saglabāt.",
        "Samaksa par vairākiem mēnešiem tiek sadalīta pa mēnešiem pēc tā, cik katrā vēl jāmaksā (vispirms agrākie), "
        "nevis vienādi; mēneši, kuros maksa nepienākas, naudu nesaņem. Sadalījums tiek saglabāts kopā ar maksājumu.",
    ]),
    ("Pūrlāde v0.7 — jauns modulis Zelta pūrs v0.1 (finanšu pārvaldība)", "01.11.2026", [
        "Zelta pūrs ir gatavs un atverams no sākuma lapas. Augšā: atlikums kopā, kasē (skaidrā naudā) un kontā, "
        "izvēlētā gada ienākumi un izdevumi un dalības maksu parāds. Grupu un gadu izvēlas loga augšā — tas attiecas "
        "uz visām cilnēm.",
        "Cilne “Darījumi”: visi ienākumi un izdevumi — datums, kategorija, summa, grupa, maksātājs / saņēmējs, "
        "maksājuma veids (skaidrā naudā / pārskaitījums), notikums no Notikumu pūra, dokumenta nr., piezīmes. "
        "Meklēšana, filtri pēc mēneša, veida un kategorijas, kārtošana, eksports uz Excel (CSV).",
        "Cilne “Dalības maksas”: katram dejotājam 12 mēneši (✓ samaksāts, ✗ nav samaksāts, – nepienākas), samaksāts "
        "gadā un parāds. Samaksu reģistrē par vienu vai vairākiem mēnešiem — summa tiek aprēķināta pati. "
        "Dalības maksas apmērs katrai grupai ar mēnesi, no kura tas spēkā (mainot maksu, iepriekšējie mēneši paliek ar "
        "veco); individuāla maksa atsevišķiem dejotājiem (atlaide vai 0 € — atbrīvots). Maksa pienākas no iestāšanās "
        "mēneša; dejotājiem “Uz pauzes” un izstājušamies parāds netiek skaitīts.",
        "Cilne “Honorāri”: Notikumu pūra notikumi ar ierakstītu honorāru — vai tas jau saņemts. Ar “Reģistrēt saņemto "
        "honorāru” ienākums tiek piesaistīts notikumam (summa, grupa un kategorija “Honorārs” jau ieliktas).",
        "Cilne “Pārskats”: gada ienākumi un izdevumi pa kategorijām un pa mēnešiem ar atlikumu mēneša beigās; "
        "eksports uz Excel.",
        "Kategorijas (⚙ Kategorijas…) var pievienot, pārdēvēt (mainās arī ierakstītajos darījumos) un dzēst, ja tās "
        "nav izmantotas. “Sākuma atlikums…” — cik naudas katrai grupai bija kasē un kontā pirms pirmā ieraksta.",
        "Piekļuve: vadītājs, repetitors, sistēmas administrators — visas grupas; A grupas kasieris un Prezidents — "
        "tikai A grupas finanses, Studijas kasieris un Studijas vecākais — tikai Studijas (citu grupu finanses netiek "
        "rādītas). Kategorijas maina tikai tie, kas drīkst labot visas grupas.",
        "Ja divi lietotāji vienlaikus labo vienu un to pašu darījumu, otrajam saglabājot tiek paziņots, ka ierakstu "
        "pa to laiku kāds ir mainījis vai dzēsis — nekas netiek pārrakstīts.",
        "Summas tiek glabātas centos (bez noapaļošanas kļūdām), ievadīt var gan ar komatu, gan ar punktu (12,50).",
    ]),
    ("Pūrlāde v0.6.11 —lietotāju lomu piekļuve (Tērpu pūrs v0.5.2, Deju pūrs v0.3.2, Kopas pūrs v0.2.4, "
     "Notikumu pūrs v0.2.3, Cītības pūrs v0.2.3)", "01.11.2026", [
        "Datora Pūrlāde tagad zina, kas to lieto: tas ir cilvēks, ar kura e-pastu un kodu dators pieslēgts tiešsaistes "
        "datubāzei. Viņa vārds un lomas redzami sākuma lapā; ar “👤 Mainīt lietotāju” var pieslēgties ar cita cilvēka "
        "e-pastu. Ar lokālo datubāzi (purlade.db) vai datubāzes adresi un paroli — visas tiesības, kā līdz šim.",
        "Vadītājs, repetitors, sistēmas administrators — visi moduļi, visu var labot.",
        "Prezidents — visi moduļi, bet labot var tikai A grupas informāciju: A grupas dejotājus, dejas, notikumus un "
        "apmeklējumu, tērpu izsniegšanu un pieņemšanu A grupas dejotājiem. Studijas vecākais — tas pats Studijai. "
        "Citu grupu informācija redzama, bet tikai skatīšanai.",
        "Tērpu pārzinis — visi moduļi tikai skatīšanai, izņemot Tērpu pūru (viss), dejas tērpu veidus Deju pūrā un "
        "publicitātes pasākuma cilni “Tērpi” Notikumu pūrā.",
        "Sociālo tīklu administrators — tikai Notikumu pūrs: redz visus notikumus, var izveidot, labot un dzēst "
        "publicitātes pasākumus (arī uzaicināt dejotājus).",
        "A grupas kasieris / Studijas kasieris — Zelta pūrs (savas grupas finanses, kad modulis būs gatavs) un Kopas pūrs "
        "tikai skatīšanai. Sveicējam un dejotājiem datora Pūrlāde nav pieejama (paziņojums un iespēja pieslēgties ar "
        "citu e-pastu).",
        "Logi, ko loma drīkst tikai skatīt, atveras ar sarkanu joslu “🔒 Tikai skatīšanai”, slēgtiem laukiem un bez "
        "saglabāšanas / dzēšanas pogām; arī katra saglabāšana, dzēšana un imports pārbauda tiesības. Moduļi bez piekļuves "
        "sākuma lapā ar atzīmi “Nav piekļuves”; tikai skatāmiem — “Skatīt ▸”.",
        "Kopas pūrā lietotnes lomas, “Lomu kolektīvā” un Kabatas Pūrlādes e-pastu drīkst mainīt tikai vadītājs un "
        "sistēmas administrators (citādi ar tiem varētu piešķirt sev citas tiesības vai pieslēgties cita vārdā).",
        "Administrēšana, Izstrādes darbi un Kolektīva vēstures labošana — vadītājam, repetitoram un sistēmas "
        "administratoram. Dejotāju, deju un tērpu imports — tiem, kas drīkst labot visas grupas.",
        "Sociālo tīklu administrators var arī lejupielādēt un pieslēgt datora Pūrlādi (tiesības “desktop”).",
        "Jauns kopīgs fails moduli/piekluve.py — lomu un tiesību tabula datora versijai.",
    ]),
    ("Pūrlāde v0.6.10", "31.10.2026", [
        "Lietotnes loma “Kasieris” aizstāta ar divām lomām: “A grupas kasieris” un “Studijas kasieris”. Katra dos "
        "piekļuvi savas grupas finansēm Zelta pūrā, kad tas būs izstrādāts (sistēmas administratoram — visām).",
        "Abiem kasieriem, tāpat kā līdz šim, ir tiesības lejupielādēt un pieslēgt datora Pūrlādi; Kabatas Pūrlādē — "
        "tāpat kā dejotājam. Ja kādam jau bija piešķirta loma “Kasieris”, tā jāpiešķir no jauna (A grupas vai "
        "Studijas).",
    ]),
    ("Pūrlāde v0.6.9", "31.10.2026", [
        "Jauna lietotnes loma “Kasieris” (tikai dejotājiem; piešķir vadītājs vai sistēmas administrators Kopas pūrā "
        "vai Kabatas Pūrlādē). Tā dos piekļuvi finanšu modulim Zelta pūrs, kad tas būs izstrādāts (tiesības "
        "“finance”; sistēmas administratoram tās ir arī tāpat).",
        "Kasieris var lejupielādēt datora Pūrlādi mājaslapā un pieslēgt to tiešsaistes datubāzei ar savu e-pastu. "
        "Kabatas Pūrlādē kasierim ir tādas pašas iespējas kā dejotājam.",
        "Lomu sarakstā Kolektīva vēsturē, mājaslapas lomu tabulā un servera logā — jaunā loma.",
    ]),
    ("Pūrlāde v0.6.8 — Kabatas Pūrlāde serveris v0.21", "31.10.2026", [
        "Visās tabulās visos moduļos (arī Kolektīva vēsturē un dialoglogos): uzspiežot ar labo peles taustiņu uz "
        "kolonnas nosaukuma, atveras mazs logs “Rādīt kolonnas”, kurā var atzīmēt, kuras kolonnas redzēt; “Rādīt "
        "visas” atjauno visas. Izvēle tiek atcerēta šajā datorā katrai tabulai atsevišķi (fails kolonnas.json "
        "Pūrlādes iestatījumu mapē); vismaz viena kolonna paliek redzama. Moduļu faili nav mainīti — to dara jaunais "
        "moduli/kolonnas.py.",
        "Jauna lietotnes loma “Studijas vecākais” (tikai dejotājiem; piešķir vadītājs vai sistēmas administrators "
        "Kopas pūrā vai Kabatas Pūrlādē): tādas pašas tiesības kā prezidentam, bet tikai par grupu Studija.",
        "Prezidenta tiesības tagad attiecas tikai uz grupu A: Kabatas Pūrlādes pārskatā redzami tikai A grupas (un "
        "visu grupu) notikumi un tikai A grupas dejotāju atbildes; vadības paziņojumi — tikai par A grupas "
        "dejotājiem un notikumiem; tērpu kopsavilkums — tikai A grupas notikumiem. Studijas vecākajam — tas pats "
        "par Studiju. Pārskata virsrakstā redzams “— grupa A” / “— grupa Studija”.",
        "Ja cilvēkam ir arī loma bez grupas ierobežojuma (piem., tērpu pārzinis — tērpu kopsavilkumam un “Nebūs” "
        "paziņojumiem), šīs tiesības paliek par visām grupām. Datora Pūrlādē un mājaslapā grupu ierobežojuma nav "
        "(Studijas vecākais var lejupielādēt datora Pūrlādi un pievienot mājaslapas saturu tāpat kā prezidents).",
        "Sistēmas administrators var skatīties lietotni kā Studijas vecākais (Profils → Skatīt kā); Kolektīva "
        "vēsturē jaunā loma ir lomu sarakstā.",
    ]),
    ("Pūrlāde v0.6.7 — Kopas pūrs v0.2.3, Kabatas Pūrlāde serveris v0.20", "31.10.2026", [
        "Jauna lietotnes loma “Sveicējs” (tikai dejotājiem; piešķir vadītājs vai sistēmas administrators Kopas pūrā "
        "vai Kabatas Pūrlādē).",
        "Sveicējs Kabatas Pūrlādē redz sveikšanas sarakstu — visu kolektīva dalībnieku (arī vadītāju un repetitoru; "
        "izstājušies netiek rādīti) dzimšanas dienas ar vecumu un vārda dienas, grupu un kontaktus (tālruni var "
        "uzreiz zvanīt); 30 / 60 dienas vai viss gads, atlase “Dzimšanas” / “Vārda”. Saite plāna augšā un profilā.",
        "Sveicējs saņem paziņojumu par katras dienas dzimšanas un vārda dienām 3 dienas iepriekš (ja serveris tajā "
        "dienā nedarbojās — vēlāk, “pēc 2 dienām” / “rīt”). Vārdiem, kas nav kalendārā, — neparasto vārdu diena "
        "(22. maijs). Citiem vadības paziņojumu sarakstā šie paziņojumi nav redzami.",
        "Sistēmas administrators var skatīties lietotni kā sveicējs (Profils → Skatīt kā).",
        "Kopas pūrā dejotāja logā lietotnes lomu izvēles rūtiņas tagad izkārtotas pa trim rindā (lomu kļuvis daudz).",
        "Kolektīva vēsturē lomu saraksts tagad ņemts no lietotnes lomām — tajā ir arī “Sveicējs”, un jaunas lomas "
        "parādīsies pašas.",
        "Kolektīva vēsturē ierakstus, kuriem nav datuma (piem., pašreizējās lomas, kuru sākums nav zināms, dejas bez "
        "iestudēšanas datuma), rāda grupā “Datums nav zināms” saraksta beigās — agrāk tie hronoloģijā nebija redzami.",
        "Dejas bez iestudēšanas datuma vēsturē parādās dienā, kad tās pirmo reizi dejotas koncertā vai skatē "
        "(“Pirmo reizi uz skatuves”).",
        "Jauns vēstures veids “Mēģinājumi”: katras sezonas (1. septembris – 31. augusts) kopsavilkums no Cītības un "
        "Notikumu pūra — mēģinājumu skaits, vidējais apmeklējums, koncerti un skates; tekošajai sezonai — “līdz šim”.",
        "“Sagatavot lejupielādi.pyw” mākoņa serverim tagad nokopē arī vārda dienu kalendāru (moduli/vardadienas.py).",
    ]),
    ("Pūrlāde v0.6.6 — Kabatas Pūrlāde serveris v0.18", "31.10.2026", [
        "Pieslēgšanās tiešsaistes datubāzei ar savu e-pastu: pirmajā palaišanā (“Pieslēgties tiešsaistes "
        "datubāzei…”) vairs nav jāievada datubāzes adrese un parole. Ieraksta savu e-pastu (to pašu, kas Kopas "
        "pūrā), uz to atnāk kods, un Pūrlāde pieslēdzas pati — savienojumu izsniedz Kabatas Pūrlādes serveris.",
        "Pieslēgties var tie, kam ir tiesības lietot datora Pūrlādi: vadītāji, repetitori, tērpu pārziņi, "
        "prezidents un sistēmas administrators (tāpat kā lejupielādei mājaslapā). Dejotājiem — atteikums.",
        "Ja datubāze startējot nav sasniedzama, poga “Pieslēgties no jauna…” atver to pašu e-pasta logu.",
        "Sistēmas administratoram adreses un paroles logs joprojām pieejams — saite e-pasta loga apakšā un "
        "Administrēšana → Datubāze.",
    ]),
    ("Pūrlāde v0.6.5 — Tērpu pūrs v0.5.1, Deju pūrs v0.3.1, Kopas pūrs v0.2.2, Notikumu pūrs v0.2.2, "
     "Cītības pūrs v0.2.2", "31.10.2026", [
        "Visos moduļos pogai “Atgriezties moduļu izvēlē” ieslēgšanas ikonas vietā tagad mājiņas ikona (tādā pašā "
        "zelta krāsā). Poga “Beigt darbu” (sākuma lapā un atsevišķi palaistos moduļos) patur ieslēgšanas ikonu.",
    ]),
    ("Pūrlāde v0.6.4 — Notikumu pūrs v0.2.1, Cītības pūrs v0.2.1", "31.10.2026", [
        "Notikuma logā blakus laukam “Datums” poga 📅: atveras mēneša kalendārs, kurā datumu var izvēlēties ar "
        "klikšķi (‹ › — mēnesis, « » — gads, “Šodien”; nedēļa sākas ar pirmdienu, brīvdienas sarkanas, šodiena "
        "iezīmēta). Datumu joprojām var arī ierakstīt formā DD.MM.GGGG.",
        "Tāda pati poga atkārtošanas laukam “līdz” (kalendārs atveras notikuma mēnesī) un galvenā loga perioda "
        "laukiem “no” un “līdz” — Notikumu pūrā un Cītības pūrā.",
    ]),
    ("Pūrlāde v0.6.3 — Kopas pūrs v0.2.1, Kabatas Pūrlāde v0.16", "31.10.2026", [
        "Sākuma lapā jauna poga “Kolektīva vēsture”: kolektīva hronoloģiskā vēsture pa gadiem — iestudētās dejas "
        "(ar horeogrāfu un pirmo reizi, kad deja dejota koncertā vai skatē), notikušie koncerti, skates un kolektīva "
        "pasākumi (ar vietu, grupām, dalībnieku skaitu un programmu; atceltie netiek rādīti), lomu maiņas, jaunie "
        "dejotāji un pašu ievadīti notikumi.",
        "Vēsturi var atlasīt pēc veida (Dejas, Koncerti, Skates, Pasākumi, Lomas, Dejotāji, Citi notikumi), grupas, "
        "gada un meklējamā vārda; jaunākie vai vecākie augšā; pēc izvēles arī plānotie notikumi. Izvēlētā ieraksta "
        "sīkāka informācija redzama loga apakšā.",
        "“+ Pievienot notikumu” — pašu ierakstīti notikumi (piem., kolektīva dibināšana, jubilejas, braucieni, "
        "apbalvojumi); tos var labot un dzēst. Dejas, koncerti un dejotāji tiek ņemti no moduļiem un maināmi tur.",
        "Cilne “Lomas”: kurš kad bijis vadītājs, repetitors, prezidents, tērpu pārzinis, sistēmas administrators un "
        "sociālo tīklu administrators (no, līdz, ilgums, piezīmes; pašreizējie izcelti).",
        "Lomas, ko piešķir Kopas pūrā vai Kabatas Pūrlādē, ierakstās automātiski: periods sākas dienā, kad loma "
        "piešķirta, un beidzas, kad tā noņemta vai cilvēks izstājies. Pirmajā reizē pašreizējiem lomu turētājiem "
        "sākuma datums nav zināms (vadītājiem un repetitoriem — iestāšanās datums); to var ievadīt ar “Labot”.",
        "Agrākos periodus var pievienot ar “+ Pievienot lomas periodu” — arī cilvēkiem, kuru Kopas pūrā nav "
        "(ierakstot vārdu).",
        "Datubāzē jaunas tabulas role_history (lomu periodi) un history_entries (pašu ievadītie notikumi); tās "
        "izveidojas automātiski, arī tiešsaistes datubāzē.",
    ]),
    ("Pūrlāde v0.6.2 — Kabatas Pūrlāde v0.15", "30.10.2026", [
        "Koncertiem un skatēm dejotāji Kabatas Pūrlādē visas atbildes (Būs, Nebūs, Varbūt) var atzīmēt un mainīt "
        "tikai līdz 10 dienām pirms notikuma sākuma; pēc tam atbildi var mainīt tikai vadītājs vai repetitors "
        "(agrāk “Būs” un “Nebūs” varēja mainīt līdz 1 stundai pirms).",
        "Notikuma kartītē un lapā redzams viens termiņš: “Atbildi (Būs / Nebūs / Varbūt) var mainīt līdz …”; "
        "30 dienu aicinājumā atbildēt norādīts šis termiņš.",
        "Mēģinājumiem un kolektīva pasākumiem termiņi nav mainīti (atbilde līdz 1 stundai pirms).",
    ]),
    ("Pūrlāde v0.6.1 — Kabatas Pūrlāde v0.14", "30.10.2026", [
        "Jauna lietotnes loma “Sociālo tīklu administrators” (tikai dejotājiem; piešķir vadītājs vai sistēmas "
        "administrators Kopas pūrā vai Kabatas Pūrlādē).",
        "Kabatas Pūrlādē sociālo tīklu administrators plānā redz visus notikumus — arī citu grupu un publicitātes "
        "pasākumus, kuros nav uzaicināts; tie atzīmēti “Tikai informācijai” (bez atbildes un dejotāju atbildēm). "
        "Uz saviem notikumiem viņš atbild kā dejotājs.",
        "Sociālo tīklu administrators saņem paziņojumu, kad izveidots jauns koncerts, skate vai publicitātes pasākums "
        "un kad tas apstiprināts (statuss “Apstiprināts”). Pirmajā reizē par jau esošajiem notikumiem paziņojumi netiek "
        "sūtīti.",
        "Mājaslapā sociālo tīklu administrators var pievienot informāciju (pasākumi, galerija, dejotāju bildes), bet "
        "datora Pūrlādes lejupielāde viņam nav pieejama (Pūrlādes mājaslapā šī poga netiek rādīta).",
        "Sistēmas administrators Kabatas Pūrlādē var skatīties arī kā sociālo tīklu administrators (Profils → Skatīt kā).",
    ]),
    ("Pūrlāde v0.6 — Tērpu pūrs v0.5, Deju pūrs v0.3, Kopas pūrs v0.2, Notikumu pūrs v0.2, Cītības pūrs v0.2",
     "30.10.2026", [
        "Programmas versija pasludināta par 0.6 (saturs kā v0.6.22). Iepriekšējās versijas v0.5.10–v0.5.22 "
        "pārnumurētas par v0.6.10–v0.6.22 (saturs nemainās).",
        "Tērpu pūra versija pasludināta par 0.5 (saturs kā v0.4.8).",
        "Deju pūra versija pasludināta par 0.3 (saturs kā v0.2.7).",
        "Kopas pūra versija pasludināta par 0.2 (saturs kā v0.1.12).",
        "Notikumu pūra versija pasludināta par 0.2 (saturs kā v0.1.9).",
        "Cītības pūra versija pasludināta par 0.2 (saturs kā v0.1.12).",
    ]),
    ("Pūrlāde v0.6.22 — Kabatas Pūrlāde v0.10 (serveris)", "30.10.2026", [
        "Automātiskā atjaunināšana: katru reizi, kad datora Pūrlāde tiek atvērta, tā fonā pārbauda Kabatas "
        "Pūrlādes serverī, vai ir pieejama jaunāka versija (to sagatavo “Sagatavot lejupielādi.pyw”). Ja ir, parādās "
        "logs ar abām versijām un izvēli “Atjaunināt tagad” vai “Vēlāk”.",
        "“Atjaunināt tagad” lejupielādē jauno versiju (ar progresa joslu), pārbauda kontrolsummu, nomaina tikai "
        "programmas failus (dati — purlade.db, foto, Excel faili — netiek aiztikti), veco “Pūrlāde vX.Y.Z.py” pārvieto "
        "uz “Vecās versijas”, aizver Pūrlādi (pajautājot par nesaglabātām izmaiņām) un atver jauno versiju.",
        "Automātiski lejupielādēt var datori, kas pieslēgti kolektīva tiešsaistes datubāzei (atslēga “update.key” "
        "kopīgajā datubāzē). Datoram ar lokālo datubāzi tiek piedāvāts atvērt mājaslapas lejupielādi.",
        "Ja serveris nav sasniedzams, Pūrlāde strādā kā parasti (kļūda tiek ierakstīta kļūdu žurnālā).",
        "Serverī (Kabatas Pūrlāde v0.10) jaunas adreses: /api/atjauninajums/info (jaunākā versija, izmērs, "
        "kontrolsumma) un /api/atjauninajums (lejupielāde tikai ar atslēgu).",
    ]),
    ("Pūrlāde v0.6.21 — Kopas pūrs v0.1.12", "30.10.2026", [
        "Kopas pūrā dejotāja logā (sadaļā “Lietotnes lomas”) jauns lauks “E-pasts Kabatas Pūrlādei”: ar šo e-pastu "
        "cilvēks piesakās Kabatas Pūrlādē. Tukšs lauks — pieteikties nevar; mainot e-pastu, iepriekšējās "
        "pieteikšanās lietotnē beidzas. Viens e-pasts var piederēt tikai vienam cilvēkam.",
        "Kopas pūra sarakstā jauna kolonna “E-pasts (Kabatas Pūrlāde)”; meklēšana atrod arī pēc e-pasta.",
        "Importā no Excel kolonna “E-pasts” tagad ir Kabatas Pūrlādes e-pasts (vairs netiek pievienota kontaktiem). "
        "Jau esošiem dejotājiem no faila tiek ņemts tikai e-pasts — tā var vienā reizē ievadīt e-pastus visiem.",
        "Tie paši e-pasti redzami un maināmi arī Kabatas Pūrlādes servera logā.",
    ]),
    ("Pūrlāde v0.6.20 — Tērpu pūrs v0.4.8", "29.10.2026", [
        "Tērpu izsniegšanā pie dejotāja lauka pievienota izvēle “Visi dejotāji / Meitenes / Puiši”: dejotāju sarakstā "
        "(arī rakstot vārdu) tiek rādītas tikai meitenes vai tikai puiši. Ja izvēlētais dejotājs filtram neatbilst, "
        "izvēle tiek notīrīta (ar jautājumu, ja ir nesaglabātas izmaiņas).",
    ]),
    ("Pūrlāde v0.6.19 — Tērpu pūrs v0.4.7", "29.10.2026", [
        "Tērpu izsniegšanā dejotāja lauku var rakstīt: sākot rakstīt vārdu vai uzvārdu, saraksts sašaurinās līdz "
        "atbilstošajiem dejotājiem (atpazīstami arī bez garumzīmēm), un pirmais vārds, kas sākas ar ierakstīto, tiek "
        "automātiski papildināts. Enter vai Tab apstiprina izvēli, bultiņa atver sašaurināto sarakstu. "
        "Ja ierakstītais vārds nav apstiprināts, izsniegšana to atgādina.",
    ]),
    ("Pūrlāde v0.6.18 — Tērpu pūrs v0.4.6, Deju pūrs v0.2.7, Kopas pūrs v0.1.11, Notikumu pūrs v0.1.9, "
     "Cītības pūrs v0.1.12", "29.10.2026", [
        "Kolektīva logo galvenē vairs nav gaišās plāksnītes — tas atkal tiek rādīts uz tumšzilā fona (zem kolektīva "
        "nosaukuma; tukšās malas ap attēlu joprojām tiek nogrieztas).",
    ]),
    ("Pūrlāde v0.6.17 — Tērpu pūrs v0.4.5, Deju pūrs v0.2.6, Kopas pūrs v0.1.10, Notikumu pūrs v0.1.8, "
     "Cītības pūrs v0.1.11", "29.10.2026", [
        "Kolektīva logo galvenē pārvietots zem kolektīva nosaukuma — moduļu izvēlē un visos moduļos.",
        "Logo tiek rādīts uz gaišas plāksnītes, lai tumšs logo būtu redzams uz tumšzilās galvenes, un "
        "tukšās (caurspīdīgās) malas ap attēlu tiek nogrieztas, tāpēc logo ir lielāks.",
    ]),
    ("Pūrlāde v0.6.16 — Notikumu pūrs v0.1.7, Cītības pūrs v0.1.10, Tērpu pūrs v0.4.4, Kabatas Pūrlāde v0.7",
     "28.10.2026", [
        "Katram notikumam norāda, kurai grupai (vai kurām grupām) tas ir: A, Studija, VPDK — Notikumu pūrā (koncerti, "
        "skates, kolektīva pasākumi) un Cītības pūrā (arī mēģinājumi). Jaunam notikumam Notikumu pūrā — A, Cītības "
        "pūrā — tās pašas grupas kā pēdējā mēģinājumā. Visiem jau ievadītajiem notikumiem vienreiz piešķirta grupa A.",
        "Notikuma dalībnieku un atzīmēšanas sarakstā redzami tikai izvēlēto grupu dejotāji (un jau atzīmētie; "
        "koncertā un skatē — arī programmas deju sastāvs, ja dejā ielikts citas grupas dejotājs).",
        "Notikumu un Cītības pūra sarakstā jauna kolonna “Grupa” un filtrs “Grupa”; Cītības pūrā filtrs atlasa arī "
        "dejotāju cītību un žurnālu.",
        "Kabatas Pūrlādē notikumu redz, var atbildēt un paziņojumus saņem tikai tās grupas dejotāji, kurai tas ir "
        "(un deju sastāvs); vadītāju kopsavilkumā skaitīti tikai viņi. Notikuma informācijā redzama grupa.",
        "Publicitātes pasākumam jauna cilne “Tērpi”: tērpu veidi atsevišķi sievietēm (meiteņu tērpu veidi) un "
        "vīriešiem (puišu tērpu veidi) no Tērpu pūra. Tie redzami tekstā “Informācija dejotājiem”, Tērpu pūrā "
        "(izsniegšanā un tērpu kopsavilkumā rāda tikai šos veidus) un Kabatas Pūrlādē (“Mani tērpi”, tērpu "
        "kopsavilkums, sadaļā “Tērpi” — vajadzīgie tērpi).",
    ]),
    ("Pūrlāde v0.6.15 — Deju pūrs v0.2.5", "28.10.2026", [
        "Dejas sastāva logā var ielikt dejā arī citas grupas dejotāju: poga “＋ Rādīt arī citu grupu dejotājus” "
        "(vai grupas izvēle “Visi”) parāda visu grupu dejotājus — vispirms dejas grupas, tad pārējos; atkārtota "
        "nospiešana atkal rāda tikai dejas grupu. Blakus redzama dejas grupa.",
        "Citas grupas dejotājs sarakstos un dejas sastāvā (arī dejas logā) ir violetā krāsā ar grupu un norādi "
        "“(cita)”, piemēram, “Studija (cita)”; arī rezerves dejotāja izvēlē pie vārda redzama viņa grupa.",
    ]),
    ("Pūrlāde v0.6.14 — Deju pūrs v0.2.4", "28.10.2026", [
        "Deju pūrā katrai dejai jauns lauks “Grupa”: A, Studija vai VPDK (tāpat kā dejotājiem Kopas pūrā); jaunai "
        "dejai — A. Visām jau ievadītajām dejām automātiski piešķirta grupa A (vienreiz).",
        "Deju sarakstā kolonna “Grupa” un filtrs “Grupa”; meklēšana atrod arī pēc grupas; Excel importā neobligāta "
        "kolonna “Grupa” (ja nav norādīta — A).",
        "Dejas sastāva logā kolektīva dejotāju sarakstā kolonna “Grupa” un grupas izvēle — sākumā rādīti dejas "
        "grupas dejotāji (“Visi” — visas grupas).",
    ]),
    ("Pūrlāde v0.6.13 — Notikumu pūrs v0.1.6", "28.10.2026", [
        "Publicitātes pasākuma cilnē “Dalībnieki” dejotājus var meklēt (pēc vārda, uzvārda, grupas un piezīmes; "
        "garumzīmes nav jāraksta) un atlasīt pēc grupas (A, Studija, VPDK); redzams, cik dejotāju atrasts.",
        "Dejotājus var kārtot pēc uzvārda, vārda, grupas, atbildes vai “Uzaicinātie vispirms” — izvēlnē “Kārtot” "
        "vai uzklikšķinot uz kolonnas virsraksta; atkārtots klikšķis vai poga blakus maina secību (augošā / dilstošā).",
        "Dalībnieku sarakstā jauna kolonna “Grupa” (no Kopas pūra).",
        "Poga “Uzaicināt visus” nomainīta pret “Uzaicināt visus redzamos” — uzaicina visus, kas atbilst meklēšanai "
        "un grupas izvēlei (bez meklēšanas — visus).",
    ]),
    ("Pūrlāde v0.6.12 — Kopas pūrs v0.1.9", "28.10.2026", [
        "Kopas pūrā, uzliekot peles kursoru uz kopsavilkuma kartītes (kopā dejotāju, aktīvie, sievietes / vīrieši, "
        "vidējais vecums, vidējais stāžs), parādās logs ar šo rādītāju sadalījumā pa grupām (A, Studija, VPDK).",
    ]),
    ("Pūrlāde v0.6.11 — Kopas pūrs v0.1.8", "28.10.2026", [
        "Kopas pūrā katram dejotājam jauns lauks “Grupa”: A, Studija vai VPDK (jaunam dejotājam — A). "
        "Vadītājiem un repetitoriem grupas nav.",
        "Visiem jau ievadītajiem dejotājiem automātiski piešķirta grupa A (vienreiz).",
        "Sarakstā kolonna “Grupa” un filtrs “Grupa”; meklēšana atrod arī pēc grupas; Excel importā neobligāta "
        "kolonna “Grupa” (ja nav norādīta — A).",
    ]),
    ("Pūrlāde v0.6.10 — Tērpu pūrs v0.4.3", "27.10.2026", [
        "Tērpu izsniegšanā var izsniegt tērpus arī publicitātes pasākuma (Kolektīva pasākums ar apakšveidu "
        "“Publicitātes pasākums”) dalībniekiem. Notikumu sarakstā šādi pasākumi redzami ar apakšveidu.",
        "Izvēloties publicitātes pasākumu, deja nav jāizvēlas: dejotāju sarakstā ir Notikumu pūrā uzaicinātie "
        "dejotāji, izņemot tos, kuri atbildējuši “Nebūs”. Tērpu veidi netiek ierobežoti ar dejas tērpiem — "
        "piedāvāti visi dejotāja dzimuma (un nekategorizētie) tērpi.",
        "“Tērpu kopsavilkums” publicitātes pasākumam rāda visus uzaicinātajiem dejotājiem izsniegtos tērpus.",
    ]),
    ("Pūrlāde v0.5.9 — Notikumu pūrs v0.1.5, Kabatas Pūrlāde v0.6", "27.10.2026", [
        "Notikumu pūrā, izvēloties veidu “Kolektīva pasākums”, jāizvēlas apakšveids: Saliedēšanās pasākums, "
        "Puišu pasākums, Meiteņu pasākums vai Publicitātes pasākums. Sarakstā, kalendārā un Kabatas Pūrlādē "
        "redzams apakšveids.",
        "Kolektīva pasākumiem nav deju: cilne “Programma” paslēpjas, un, ja notikumam bija dejas, saglabājot tās "
        "tiek noņemtas (pēc apstiprinājuma). Dalībnieku sarakstā — visi aktīvie dejotāji.",
        "Publicitātes pasākumam cilnē “Dalībnieki” izvēlas uzaicinātos dejotājus (“Uzaicināt izvēlētos”, "
        "“Uzaicināt visus”, “Rādīt tikai uzaicinātos”). Kabatas Pūrlādē šo pasākumu redz, atbildi var sniegt un "
        "paziņojumus saņem tikai uzaicinātie; vadītāju pārskatā skaitīti tikai uzaicinātie.",
        "Kabatas Pūrlāde paziņo dejotājiem par kolektīva pasākumiem (30 dienas pirms vai uzreiz, ja pasākums "
        "izveidots vēlāk): par publicitātes pasākumu — tikai uzaicinātajiem (arī vēlāk uzaicinātajiem), par "
        "pārējiem — visiem dejotājiem.",
        "Labojums: atkārtotiem notikumiem katram notikumam atkal ir savas dalībnieku atbildes (logā ievadītās "
        "attiecas tikai uz notikumu laukā “Datums”).",
    ]),
    ("Pūrlāde v0.5.8 — Cītības pūrs v0.1.9", "26.10.2026", [
        "Cītības pūra galvenajā lapā cilnē “Notikumi” var iezīmēt vairākus notikumus (Ctrl vai Shift + klikšķis, "
        "Ctrl+A — visus redzamos) un dzēst tos ar pogu “🗑 Dzēst iezīmētos notikumus” vai taustiņu Delete.",
        "Pirms dzēšanas redzams dzēšamo notikumu saraksts (datums, nedēļas diena, veids, nosaukums, atzīmju skaits) "
        "un brīdinājums, ja kādam ir apmeklējuma atzīmes; 10 un vairāk notikumu dzēšana jāapstiprina divreiz.",
        "Kopā ar notikumu tiek dzēstas tā atzīmes, dejas, Notikumu pūra informācija un programma, kā arī "
        "dejotāju atbildes Kabatas Pūrlādē.",
    ]),
    ("Pūrlāde v0.5.7 — Cītības pūrs v0.1.8, Kabatas Pūrlāde v0.3", "26.10.2026", [
        "Mobilā lietotne pārsaukta par “Kabatas Pūrlāde”; servera logs — “Kabatas Pūrlāde serveris.pyw”.",
        "Cītības pūrā redzamas atbildes no Kabatas Pūrlādes: notikuma logā blakus dejotāja vārdam (Būs, Nebūs, "
        "Varbūt, Kavēs N min; iemesls — uzbraucot ar peli), sarakstā jauna kolonna “Atbildes lietotnē”. "
        "Dejotājam, kuram vēl nav atzīmes, “Nebūs” automātiski ieliek atzīmi “Attaisnoti nebija”, “Kavēšu” — "
        "“Nokavēja” ar minūtēm piezīmē (saglabājas ar “Saglabāt”).",
        "Kabatas Pūrlādē jauna sadaļa “Dejas” visiem: repertuāra dejas, pamatsastāvs ar aizvietotājiem (↺), "
        "rezerve ar to, kurus tā aizvieto, dejas bez aizvietotāja (⚠), tērpi, “Mani tērpi” un gaidāmie notikumi "
        "ar šo deju; filtrs “Manas dejas”.",
        "Sistēmas administrators Kabatas Pūrlādē var izvēlēties, kādas lomas skatu redzēt (Profils → “Skatīt kā”: "
        "Dejotājs, Tērpu pārzinis, Prezidents, Repetitors, Vadītājs); augšā redzams, kurā skatā ir, un poga "
        "atgriezties savā skatā.",
        "Kabatas Pūrlādes servera logā cilvēku saraksts pats atsvaidzinās ik pēc 30 sekundēm (redz Kopas pūrā "
        "veiktās izmaiņas arī no citiem datoriem).",
    ]),
    ("Pūrlāde v0.5.6 — Kopas pūrs v0.1.7, Mobilā lietotne v0.2", "26.10.2026", [
        "Lietotnes lomas: Dejotājs (visiem dejotājiem), Tērpu pārzinis, Sistēmas administrators, Prezidents. "
        "Papildu lomas var piešķirt tikai dejotājiem un noņemt pēc vajadzības; vadītājiem un repetitoriem "
        "lietotnes loma “Vadītājs” / “Repetitors” tiek piešķirta automātiski no lauka “Loma kolektīvā”.",
        "Kopas pūrā dejotāja logā sadaļa “Lietotnes lomas” un sarakstā kolonna “Lietotnes lomas”.",
        "Mobilajā lietotnē lomas nosaka, ko cilvēks redz un drīkst: Dejotājs — savu plānu, dejas un tērpus; "
        "Tērpu pārzinis — arī notikuma tērpu kopsavilkumu un paziņojumus par “Nebūs”; Prezidents — pārskatu par "
        "visiem un visus paziņojumus, bet nevar mainīt atbildes; Vadītājs un Repetitors — pārskatu un atbilžu "
        "maiņu; Sistēmas administrators — visu. Lietotnes lomas lietotnē piešķir vadītājs vai sistēmas "
        "administrators (Profils → Lietotnes lomas).",
        "Dejotāji ar pārskata tiesībām (prezidents, administrators) lietotnē pārslēdzas starp “Mans plāns” un "
        "“Visi dejotāji”. Jauns skats “Tērpu kopsavilkums”: katrai notikuma dejai — kas dejo (ar aizvietošanu), "
        "kādi tērpi vajadzīgi un kas jau izsniegts.",
        "Adrianam Gūtšmitam piešķirta lietotnes loma “Sistēmas administrators” (automātiski vienreiz).",
        "Datora Pūrlādē pieteikšanās vēl nav, tāpēc lomas pagaidām ierobežo tikai mobilo lietotni.",
    ]),
    ("Pūrlāde v0.5.5 — Kopas pūrs v0.1.6", "25.10.2026", [
        "Kopas pūrā noņemta kopsavilkuma kartīte “Vadītāji / repetitori”. Cik ir vadītāju un repetitoru, "
        "joprojām redzams virs saraksta un ar filtru “Loma”; dejotāju kartītes viņus neskaita.",
    ]),
    ("Pūrlāde v0.5.4 — Kopas pūrs v0.1.5", "25.10.2026", [
        "Kopas pūrā katram ierakstam jauns lauks “Loma kolektīvā”: Dejotājs, Vadītājs vai Repetitors "
        "(jaunam ierakstam — Dejotājs; jau ievadītie ieraksti ir dejotāji). Sarakstā kolonna “Loma”, "
        "vadītāji un repetitori izcelti treknrakstā.",
        "Vadītāji un repetitori netiek skaitīti dejotāju skaitā: kopsavilkuma kartītes (kopā, aktīvie, "
        "sievietes / vīrieši, vidējais vecums un stāžs) rāda tikai dejotājus; jauna kartīte "
        "“Vadītāji / repetitori”. Saraksta augšā redzams, cik ir dejotāju un cik vadītāju un repetitoru.",
        "Jauns filtrs “Loma”: Visi, Dejotāji, Vadītāji un repetitori, Vadītājs, Repetitors. "
        "Excel importā neobligāta kolonna “Loma”.",
        "Citos moduļos vadītāji un repetitori netiek piedāvāti kā dejotāji: Deju pūra sastāvos (Deju pūrs v0.2.3), "
        "Tērpu pūra izsniegšanā un diagrammā “Dejotāji pēc dzimuma” (Tērpu pūrs v0.4.2), Cītības pūra "
        "apmeklējumā (v0.1.7) un Notikumu pūra dalībniekos (v0.1.4).",
    ]),
    ("Pūrlāde v0.5.3", "25.10.2026", [
        "Administrēšanā jauna rinda “Datora nosaukums” ar pogu “Iestatīt datora nosaukumu…” (pagaidu "
        "risinājums, kamēr Pūrlādē nav lietotāju). Nosaukums glabājas tikai šajā datorā "
        "(%APPDATA%\\Pūrlāde\\dators.json), nevis kopīgajā datubāzē; ja tas nav iestatīts vai atstāts tukšs, "
        "tiek lietots Windows datora nosaukums. Kad Administrēšana ir bloķēta, poga nav pieejama.",
        "Datora nosaukums redzams sākuma lapas apakšā, un ar to Pūrlāde piesakās tiešsaistes datubāzē "
        "(stājas spēkā pēc Pūrlādes pārstartēšanas).",
    ]),
    ("Pūrlāde v0.5.2 — Tērpu pūrs v0.4.1", "25.10.2026", [
        "Administrēšanā jauna rinda “Kolektīva nosaukums” ar pogu “Mainīt nosaukumu…”: nosaukums redzams "
        "moduļu izvēlē un visu moduļu galvenē. Kad Administrēšana ir bloķēta, poga nav pieejama.",
        "Administrēšanā vairs nevar mainīt tabulu kolonnu nosaukumus; noņemta arī poga “Atjaunot sākotnējos "
        "nosaukumus”. Tērpu pūrā visur tiek rādīti sākotnējie kolonnu nosaukumi (iepriekš mainītie netiek izmantoti).",
    ]),
    ("Pūrlāde v0.5.1", "25.10.2026", [
        "Tiešsaistes datubāze (lietotnes plāna 1. posma sākums): Pūrlāde var glabāt datus kopīgā PostgreSQL "
        "datubāzē tiešsaistē (piem., Supabase), lai to pašu datubāzi var lietot no vairākiem datoriem. "
        "Pieslēgšana: Administrēšana → “Datubāze…”.",
        "Logā “Datubāze” ievada savienojuma adresi (Supabase → Connect → Session pooler) un paroli, pārbauda "
        "savienojumu un pārslēdzas uz tiešsaistes datubāzi. Ja tā vēl ir tukša, var pārnest visus datus no "
        "purlade.db; purlade.db netiek mainīts un paliek kā rezerves kopija. Pēc pārnešanas katrā tabulā tiek "
        "salīdzināts ierakstu skaits. Turpat var pārslēgties atpakaļ uz lokālo datubāzi.",
        "Savienojuma dati glabājas tikai attiecīgajā datorā (%APPDATA%\\Pūrlāde\\datubaze.json), parole šifrēta ar "
        "Windows lietotāja kontu; tie nav ne programmas mapē, ne Pūrlāde.exe.",
        "Visi moduļi lieto vienu kopīgu savienojumu no kopeja.py; moduļu SQLite vaicājumi tiešsaistes datubāzei tiek "
        "pielāgoti automātiski. Nekas papildus nav jāinstalē — savienojums izmanto tikai Python standarta "
        "bibliotēku (moduli/pgwire.py).",
        "Ja startējot tiešsaistes datubāze nav sasniedzama, parādās logs ar izvēli “Mēģināt vēlreiz”, "
        "“Savienojuma iestatījumi…” vai “Iziet”. Ja savienojums pazūd darba laikā, Pūrlāde pieslēdzas no jauna "
        "automātiski (ja tobrīd bija nesaglabātas izmaiņas, par to tiek paziņots).",
        "Datorā, kurā vēl nav ne purlade.db, ne savienojuma iestatījumu, pirmajā palaišanā var izvēlēties "
        "pieslēgties tiešsaistes datubāzei vai sākt jaunu datubāzi šajā datorā.",
        "Sākuma lapas apakšā redzams, kuru datubāzi lieto šis dators (lokālā / tiešsaistes).",
        "Tiešsaistes datubāzē meklēšana neņem vērā lielos un mazos burtus arī burtiem ar garumzīmēm un "
        "mīkstinājuma zīmēm, un saraksti (piem., tērpu veidi) tiek kārtoti latviešu alfabēta secībā.",
        "Tērpu pūrs, atverot moduli, vairs nepārraksta visu tērpu statusu — tikai tiem, kuru statuss nav pareizs.",
    ]),
    ("Pūrlāde v0.5 — Tērpu pūrs v0.4", "23.10.2026", [
        "Programmas versija pasludināta par 0.5 (saturs kā v0.4.14).",
        "Tērpu pūra versija pasludināta par 0.4 (saturs kā v0.3.11).",
    ]),
    ("Pūrlāde v0.4.14 — Tērpu pūrs v0.3.11", "23.10.2026", [
        "Tērpu izsniegšanā, kad izvēlēts notikums, pa labi no dejas lauka parādās poga “Tērpu kopsavilkums”: tā atver "
        "logu ar tabulu — notikuma dejas, katras dejas dejotāji (ar rezerves aizvietošanu) un viņiem izsniegto tērpu "
        "veids un inventāra numurs (tikai dejai Deju pūrā pievienotie veidi). Dejotāji bez izsniegta tērpa atzīmēti "
        "sarkani.",
    ]),
    ("Pūrlāde v0.4.13 — Tērpu pūrs v0.3.10", "23.10.2026", [
        "Tērpu izsniegšanā blakus ierakstam “Pēdējoreiz izsniegts” pievienota poga “Visa vēsture”: tā atver sarakstu "
        "ar visiem šī tērpu veida izsniegumiem izvēlētajam dejotājam (izsniegšanas un atgriešanas datumi, tērpa "
        "detaļa, piezīmes), jaunākie augšā.",
    ]),
    ("Pūrlāde v0.4.12", "23.10.2026", [
        "Izlabota programmas ikona: ikonas failā attēli bija PNG formātā, ko Tk nevar nolasīt, tāpēc loga "
        "virsrakstā logo pazuda un uzdevumjoslā joprojām bija Python ikona. Tagad ikona saglabāta BMP formātā "
        "(16–256 px), un Windows to izmanto loga virsrakstā, uzdevumjoslā un Alt+Tab sarakstā.",
    ]),
    ("Pūrlāde v0.4.11", "23.10.2026", [
        "Windows uzdevumjoslā (taskbar) un logu virsrakstā tagad redzams Pūrlādes logo (lāde ar moduļu "
        "kartītēm), nevis Python ikona; ikona glabājas failā moduli/logo/purlade.ico.",
        "Moduļu izvēlē zem nosaukuma “PŪRLĀDE” tagad rakstīts “Viss amatiermākslas kolektīvam vienuviet”.",
    ]),
    ("Pūrlāde v0.4.10 — Deju pūrs v0.2.2, Tērpu pūrs v0.3.9, Notikumu pūrs v0.1.3", "23.10.2026", [
        "Deju pūrā dejas sastāva logā katram pamatsastāva dejotājam var norādīt savu rezerves dejotāju "
        "(lauks “Rezerves dejotājs”): var izvēlēties kādu no šīs dejas rezervēm vai citu tā paša dzimuma dejotāju — "
        "tad viņš tiek pievienots dejai kā “Rezerve”. Sastāva sarakstos kolonna “Rezerve” rāda, kurš kuru aizvieto.",
        "Ja pamatsastāva dejotājs notikumam atbildējis “Nebūs”, viņa vietā šajā dejā automātiski tiek ņemts viņa "
        "rezerves dejotājs (ja arī tas nav atbildējis “Nebūs”).",
        "Notikumu pūrā notikuma logā: dejotāju sarakstā redzams, kurā dejā rezerve kuru aizvieto; programmā sastāva "
        "skaits ņem vērā aizvietošanu; brīdinājums parādās tikai par dejām, kur trūkstošajam dejotājam nav rezerves, "
        "bet automātiskās aizvietošanas tiek uzrādītas ar “↺”.",
        "Tērpu pūrā izsniegšanā dejotāju sarakstā rezerves dejotājs parādās tā dejotāja vietā, kurš nebūs "
        "(ar norādi “rezerve, aizvieto …”). Rezerves, kuras nevienu neaizvieto, sarakstā netiek rādītas.",
    ]),
    ("Pūrlāde v0.4.9 — Tērpu pūrs v0.3.8", "23.10.2026", [
        "Tērpu izsniegšanā, izvēloties dejotāju un tērpu veidu, blakus veida izvēlnei parādās tērpa inventāra "
        "numurs, kas šim dejotājam šī veida tērpu sarakstā bija izsniegts pēdējo reizi (ar izsniegšanas un atgriešanas "
        "datumu). Ja šis tērps ir pieejams, tas sarakstā ir iekrāsots.",
    ]),
    ("Pūrlāde v0.4.8 — Tērpu pūrs v0.3.7", "23.10.2026", [
        "Tērpu izsniegšanā pie notikuma izvēles pievienota poga “Tuvākais notikums”: tā izvēlas tuvāko gaidāmo "
        "notikumu (šodienas notikums arī skaitās; mēģinājumi netiek ņemti vērā).",
    ]),
    ("Pūrlāde v0.4.7 — Deju pūrs v0.2.1", "23.10.2026", [
        "Dejas logā (arī pievienojot jaunu deju) sadaļā “Tērpi” sievietēm piedāvāti tikai tie tērpu veidi, kuru "
        "kategorija Tērpu pūrā ir “Meiteņu tērpi”, bet vīriešiem — tikai veidi ar kategoriju “Puišu tērpi”.",
    ]),
    ("Pūrlāde v0.4.6 — Tērpu pūrs v0.3.6", "23.10.2026", [
        "Tērpu izsniegšanā pēc dejas izvēles tiek rādīti tikai tie tērpu veidi, kas šai dejai pievienoti Deju pūrā "
        "(dejotāja dzimumam): gan tērpu veida izvēlnē, gan pieejamo tērpu sarakstā.",
    ]),
    ("Pūrlāde v0.4.5 — Tērpu pūrs v0.3.5", "23.10.2026", [
        "Tērpu izsniegšanā vispirms jāizvēlas notikums (rādīti visi notikumi, izņemot mēģinājumus), pēc tam "
        "deja no šī notikuma programmas, un dejotāju sarakstā parādās tikai tie dejotāji, kuri šo deju dejo "
        "(dejas sastāvs Deju pūrā) un kuri nav atbildējuši “Nebūs” šim notikumam.",
    ]),
    ("Pūrlāde v0.4.4 — Tērpu pūrs v0.3.4", "22.10.2026", [
        "Inventāra numurs var atkārtoties, ja tērpu kategorija ir atšķirīga: piemēram, “PM1” var būt gan puišu, "
        "gan meiteņu tērpam. Tajā pašā kategorijā numuram joprojām jābūt unikālam.",
        "Tērpu importā tiek izlaistas tikai tās rindas, kuru inventāra numurs tajā pašā kategorijā jau ir; "
        "paziņojumā norādīta arī kategorija.",
        "Esošā datubāze tiek pārveidota automātiski pirmajā palaišanas reizē; tērpi, foto un izsniegumi saglabājas.",
    ]),
    ("Pūrlāde v0.4.3 — Tērpu pūrs v0.3.3", "22.10.2026", [
        "Tērpu importā (Excel/CSV) kolonna “Nosaukums” vairs nav obligāta: obligātas ir tikai “Inventāra numurs” "
        "un “Kategorija”. Ja kolonnas “Nosaukums” nav vai šūna ir tukša, nosaukumā tiek ielikts tērpa veids, "
        "bet ja tā nav arī veida – inventāra numurs. Ja kolonna ir, tā tiek izmantota kā līdz šim.",
    ]),
    ("Pūrlāde v0.4.2 — Tērpu pūrs v0.3.2", "22.10.2026", [
        "Tērpu pūrā tabulās noņemta kolonna “Nosaukums”: noliktavas pārvaldības sarakstā un izsniegšanas "
        "logā (pieejamie un dejotājam izvēlētie tērpi). Meklēšana noliktavā joprojām atrod arī pēc nosaukuma, "
        "un tērpa anketā lauks “Nosaukums” paliek.",
        "Noliktavas pārvaldībā grupēšanas rindā kopā ar grupas nosaukumu redzams tērpu skaits.",
    ]),
    ("Pūrlāde v0.4.1 — Tērpu pūrs v0.3.1", "22.10.2026", [
        "Tērpu veidu un komplektu administrēšanā jauna poga “⇪ Importēt veidus un komplektus”: vienā Excel/CSV "
        "failā var būt kolonna “Veids” (ar neobligātu “Kategorija”) un/vai “Komplekts”; abi saraksti tiek "
        "papildināti uzreiz. Importētie ieraksti tiek saglabāti ar “Saglabāt”; esošie nosaukumi tiek izlaisti. "
        "Atsevišķās importa pogas pie katra saraksta paliek.",
    ]),
    ("Pūrlāde v0.4 — Tērpu pūrs v0.3, Deju pūrs v0.2", "22.10.2026", [
        "Programmas versija pasludināta par 0.4 (saturs kā v0.3.15).",
        "Tērpu pūra versija pasludināta par 0.3 (saturs kā v0.2.10).",
        "Deju pūra versija pasludināta par 0.2 (saturs kā v0.1.12).",
    ]),
    ("Pūrlāde v0.3.15 — Tērpu pūrs v0.2.10", "22.10.2026", [
        "Tērpu veidu un komplektu administrēšanā virs saraksta izvēle “Rādīt veidus: Visi tērpi / Meiteņu tērpi / "
        "Puišu tērpi”. Izvēloties meiteņu vai puišu tērpus, sarakstā redzami attiecīgās kategorijas un "
        "nekategorizētie veidi; jauna veida logā kategorija sākumā ir izvēlētā.",
    ]),
    ("Pūrlāde v0.3.14 — Tērpu pūrs v0.2.9, Deju pūrs v0.1.12", "22.10.2026", [
        "Tērpu pūrā jauna tērpu kategorija “Nekategorizēts”, ko var piešķirt gan puišu, gan meiteņu tērpiem "
        "(tērpa anketā, noliktavas filtros, Excel importā un diagrammās). Tukša kategorija importā kļūst par "
        "“Nekategorizēts”.",
        "Tērpu veidu un komplektu administrēšanā katram tērpa veidam var piešķirt kategoriju (Puišu tērpi, "
        "Meiteņu tērpi vai Nekategorizēts); veida pievienošanas un rediģēšanas logā ir nosaukums un kategorija. "
        "Izmaiņas stājas spēkā ar “Saglabāt”. Esošie veidi automātiski saņem to kategoriju, ko lieto visi "
        "attiecīgie tērpi, citādi — “Nekategorizēts”.",
        "Izsniegšanā izvēlētajam dejotājam (dzimums no Kopas pūra) rāda tikai viņa dzimuma un nekategorizēto "
        "veidu tērpus; tāpat tiek filtrēta veidu izvēlne.",
        "Tērpu veidu un komplektu administrēšanā jauna poga “⇪ Importēt no Excel” (Excel/CSV): veidiem kolonna "
        "“Veids” un neobligāta “Kategorija”, komplektiem kolonna “Komplekts”. Importētie ieraksti tiek pievienoti "
        "sarakstam un saglabāti ar “Saglabāt”; esošie nosaukumi tiek izlaisti.",
        "Deju pūrā tērpu veida krājumā (“n gab., noliktavā m”) tiek skaitīti arī nekategorizētie tērpi.",
    ]),
    ("Pūrlāde v0.3.13 — Deju pūrs v0.1.11", "22.10.2026", [
        "Dejas logā lauka “Pāru skaits” vietā divi lauki: “Puišu skaits” un “Meitu skaits”.",
        "Ja sastāvs ir “Sieviešu”, lauks “Puišu skaits” ir tukšs un nav aizpildāms; ja “Vīriešu” — tāpat "
        "lauks “Meitu skaits”.",
        "Jau ievadītajām dejām pāru skaits pārrakstīts automātiski: jauktai dejai puišu un meitu skaits = pāru "
        "skaits, sieviešu vai vīriešu dejai — divreiz pāru skaits.",
        "Deju sarakstā kolonna “Pāri” aizstāta ar “Puiši / meitas” (piem., 12 / 12). Sastāva pārbaude rāda, "
        "cik puišu un meitu vajag, cik ir un cik trūkst.",
        "Excel importā kolonnas “Puišu skaits” un “Meitu skaits”; vecā kolonna “Pāri” joprojām tiek saprasta.",
    ]),
    ("Pūrlāde v0.3.12 — Cītības pūrs v0.1.6", "22.10.2026", [
        "Notikuma logā (apmeklējuma atzīmēšana) lauks “Meklēt dejotāju”: meklē pēc vārda un uzvārda, arī bez "
        "garumzīmēm (piem., “cuda” atrod “Čuda”).",
        "Redzama kārtošanas izvēle “Kārtot pēc: Vārda / Uzvārda” — dejotāji vienmēr alfabēta secībā.",
        "Laboti v0.3.11 jaunumi, kas iepriekš nebija nonākuši programmā: kārtošana pēc vārda un izvēle "
        "“Rādīt: Visi / Puiši / Meitas”.",
    ]),
    ("Pūrlāde v0.3.11 — Cītības pūrs v0.1.5", "22.10.2026", [
        "Atzīmējot apmeklējumu, dejotāji vienmēr sakārtoti alfabēta secībā pēc vārda (tad pēc uzvārda).",
        "Notikuma logā izvēle “Rādīt: Visi / Puiši / Meitas”; “Pārējie ieradās” atzīmē tikai redzamos dejotājus, "
        "un skaitītājs rāda redzamo dejotāju atzīmes.",
    ]),
    ("Pūrlāde v0.3.10 — Cītības pūrs v0.1.4", "21.10.2026", [
        "Cītības pūrā jauna notikuma logā izvēle “↻ Atkārtojas” — tāpat kā Notikumu pūrā: notikumus var "
        "ieplānot izvēlētās nedēļas dienās (katru vai katru otro nedēļu) līdz norādītam datumam vai konkrētos "
        "datumos. Pirms saglabāšanas redzams, kuros datumos notikumi tiks izveidoti.",
        "Katrs ieplānotais notikums ir atsevišķs, ar to pašu veidu, laiku, nosaukumu, piezīmēm un dejām; dejotāju "
        "atzīmes tiek saglabātas tikai ievadītā datuma notikumam.",
        "Notikumu sarakstā gaidāmie notikumi rādīti violetā krāsā ar “Gaidāms”, šodienas notikums — izcelts; "
        "kartīte “Notikušie periodā (+ gaidāmie)”. Blakus datumam redzama nedēļas diena.",
        "Zem uzraksta “Rādīti … notikumiem” poga “▶ Atvērt šodienas notikumu”: atver šodienas notikumu; ja to ir "
        "vairāki — ļauj izvēlēties; ja nav neviena — piedāvā izveidot jaunu.",
    ]),
    ("Pūrlāde v0.3.9", "21.10.2026", [
        "Aizverot programmu ar loga aizvēršanas pogu (X) vai pogu “Beigt darbu”, programma pārbauda, vai "
        "kādā logā nav nesaglabātu izmaiņu. Ja ir, parādās logs ar sarakstu, kuros logos dati nav saglabāti, "
        "un izvēli: “Saglabāt un aizvērt”, “Atmest un aizvērt” vai “Atcelt”.",
        "Pārbaude darbojas visos moduļos: atvērtajās anketās un logos (piemēram, dejotāja, dejas, tērpa, "
        "notikuma vai izstrādes darba logā) un Tērpu pūra skatos Izsniegt, Atgriezt un Noliktavas pārvaldība.",
        "Ja saglabāšana neizdodas (piemēram, nav aizpildīts obligāts lauks), programma netiek aizvērta.",
    ]),
    ("Pūrlāde v0.3.8", "21.10.2026", [
        "Izstrādes darbu logā poga “Kļūdu žurnāls” pārvietota no galvenes uz pogu rindu — pa labi no pogas "
        "“Atzīmēt kā izpildītu”.",
        "Poga “Atzīmēt kā izdarītu” pārdēvēta par “Atzīmēt kā izpildītu”.",
    ]),
    ("Pūrlāde v0.3.7", "21.10.2026", [
        "Izstrādes darbu loga galvenes vidū poga “Kļūdu žurnāls”: tā atver programmas kļūdu sarakstu no "
        "faila kludas.log (laiks, modulis, kļūda) ar katras kļūdas detaļām.",
        "Dubultklikšķis uz kļūdas to pievieno izstrādes darbu sarakstam ar atbilstošo moduli, kļūdas aprakstu "
        "un vietu programmā; jau pievienotās kļūdas ir atzīmētas un netiek pievienotas atkārtoti.",
        "Uz pogas redzams, cik kļūdu vēl nav pievienotas darbu sarakstam.",
    ]),
    ("Pūrlāde v0.3.6 — Tērpu pūrs v0.2.8, Deju pūrs v0.1.10, Cītības pūrs v0.1.3, Notikumu pūrs v0.1.2",
     "21.10.2026", [
        "Visos moduļos datumi tiek rādīti un ievadīti formātā DD.MM.GGGG. Tērpu pūrā tas attiecas uz "
        "izsniegšanas un atgriešanas datumu (lauki sākumā rāda šodienas datumu formātā DD.MM.GGGG) un "
        "izsniegumu sarakstiem. Arī kļūdu žurnālā (kludas.log) laiks ierakstīts formātā DD.MM.GGGG.",
        "Cītības pūrā un Notikumu pūrā izvēles rūtiņa tagad saucas “Rādīt arī dejotājus uz pauzes un izstājušos”.",
        "Deju pūrā dejas sastāvā aiz neaktīva dejotāja vārda rādīts viņa statuss — “(uz pauzes)” vai "
        "“(izstājies)” — iepriekšējā “(neaktīvs)” vietā.",
    ]),
    ("Pūrlāde v0.3.5 — Kopas pūrs v0.1.4", "21.10.2026", [
        "Dejotāja statuss “Neaktīvs” pārdēvēts par “Uz pauzes”; jau ierakstītajiem dejotājiem statuss "
        "nomainās automātiski.",
        "Kopas pūrā pa labi no kolonnas “Dzimšanas datums” jaunas kolonnas “Dzimšanas diena” (diena un mēnesis, "
        "piemēram, 25. oktobris) un “Vārda diena” (pēc vārda no Latvijas vārda dienu kalendāra, ieskaitot "
        "paplašināto; dubultvārdam — abas dienas; vārdam, kura nav kalendārā, — 22. maijs). "
        "Abas kolonnas kārto pēc kalendāra dienas.",
        "Kopas pūrā datumi sarakstā un dejotāja logā rādīti formātā DD.MM.GGGG.",
    ]),
    ("Pūrlāde v0.3.4", "21.10.2026", [
        "Galvenē blakus pogai “Administrēšana” jauna poga “Izstrādes darbi”: darbu saraksts programmas "
        "izstrādei. Katram darbam izvēlas moduli un apraksta, kas jādara; izveidošanas datums tiek ielikts "
        "automātiski, termiņu var izvēlēties, un pēc tam var ielikt datumu, kad darbs izdarīts.",
        "Sarakstā var rādīt neizpildītos, izpildītos vai visus darbus un filtrēt pēc moduļa; nokavētie darbi "
        "ir sarkani, izdarītie — pelēki.",
        "Poga “Izstrādes darbi” nav redzama, kamēr Administrēšana ir bloķēta, un parādās atkal pēc atbloķēšanas.",
    ]),
    ("Pūrlāde v0.3.2 — Notikumu pūrs v0.1.1", "21.10.2026", [
        "Jauna notikuma logā izvēle “↻ Atkārtojas”: notikumu var atkārtot izvēlētās nedēļas dienās "
        "(katru vai katru otro nedēļu) līdz norādītam datumam, vai arī konkrētos datumos.",
        "Pirms saglabāšanas redzams, kuros datumos notikumi tiks izveidoti; katrs no tiem ir atsevišķs notikums "
        "ar to pašu informāciju, programmu un dalībniekiem, ko pēc tam var labot atsevišķi.",
    ]),
    ("Pūrlāde v0.3.1 — Notikumu pūrs v0.1.0, Deju pūrs v0.1.9", "21.10.2026", [
        "Jauns modulis Notikumu pūrs koncertu, skašu un kolektīva pasākumu plānošanai. Tas izmanto tos pašus "
        "notikumus kā Cītības pūrs: šeit izveidots koncerts uzreiz redzams Cītības pūrā apmeklējuma atzīmēšanai, "
        "un Cītības pūrā ievadītie koncerti, skates un pasākumi redzami Notikumu pūrā.",
        "Notikumam norāda datumu, sākuma, ierašanās un beigu laiku, veidu, nosaukumu, statusu (Iecerēts, "
        "Apstiprināts, Atcelts; pagājušie notikumi redzami kā “Noticis”), vietu, adresi, organizatoru, "
        "kontaktpersonu, transportu, honorāru, tērpu piezīmes un piezīmes.",
        "Cilne “Programma”: dejas no Deju pūra noteiktā secībā (▲ ▼), katras dejas ilgums, sastāvs un tērpi, "
        "programmas kopējais ilgums un nepieciešamie tērpi; poga “Kā iepriekšējā reizē”.",
        "Cilne “Dalībnieki”: programmas deju sastāvs ar atbildēm Būs / Varbūt / Nebūs un piezīmi; "
        "brīdinājums, kurās dejās kāds dejotājs nebūs.",
        "Poga “Informācija dejotājiem” sagatavo ziņu (laiks, vieta, transports, tērpi, programma), ko var "
        "nokopēt un ielīmēt WhatsApp vai e-pastā.",
        "Galvenajā logā kartītes (nākamais notikums, gaidāmie, neapstiprinātie, koncerti un skates šajā sezonā), "
        "filtri (periods — pēc noklusējuma “Gaidāmie”, veids, statuss, meklēšana) un eksports uz Excel (CSV).",
        "Cilne “Kalendārs”: mēneša kalendārs ar notikumiem; dubultklikšķis uz tukšas dienas izveido jaunu notikumu.",
        "Cilne “Dejotāju dalība”: cik koncertos, skatēs un pasākumos katrs dejotājs piedalījies (pēc Cītības pūra "
        "atzīmēm), gaidāmie notikumi un atteikumi.",
        "Deju pūrs v0.1.9: “dejota koncertos un skatēs” vairs neskaita vēl gaidāmos un atceltos notikumus.",
    ]),
    ("Pūrlāde v0.3", "21.10.2026", [
        "Programmas versija pasludināta par 0.3 (saturs kā v0.2.9): pieejami moduļi Tērpu pūrs, Deju pūrs, "
        "Kopas pūrs un Cītības pūrs; Notikumu pūrs un Zelta pūrs vēl izstrādē.",
    ]),
    ("Pūrlāde v0.2.9 — Cītības pūrs v0.1.2", "21.10.2026", [
        "Poga “Jauna nodarbība” pārdēvēta par “Jauns notikums”; visā Cītības pūrā “nodarbība” nomainīta uz "
        "“notikums” (cilne “Notikumi”, kartītes, logi un paziņojumi).",
        "Notikumu veidi: Mēģinājums, Papildmēģinājums, Koncerts, Kolektīva pasākums, Skate. "
        "Veids “Cits” noņemts; jau ierakstītie notikumi ar šo veidu kļūst par “Kolektīva pasākums”.",
    ]),
    ("Pūrlāde v0.2.8 — Cītības pūrs v0.1.1, Deju pūrs v0.1.8", "21.10.2026", [
        "Cītības pūrā katrai nodarbībai var izvēlēties dejas no Deju pūra: mēģinājumā mēģinātās, koncertā vai "
        "skatē dejotās. Poga “Kā pēdējā reizē” paņem dejas no iepriekšējās nodarbības.",
        "Nodarbības logā izvēle “Tikai izvēlēto deju sastāvs” rāda tikai šo deju dejotājus (un jau atzīmētos); "
        "“Pārējie ieradās” atzīmē tikai redzamos.",
        "Nodarbību sarakstā jauna kolonna “Dejas”; meklēšana atrod nodarbības arī pēc dejas nosaukuma.",
        "Deju pūrā jauna kolonna “Mēģināta” — mēģinājumu skaits šajā sezonā (no 1. septembra); dejas aprakstā "
        "redzams arī kopējais mēģinājumu skaits, pēdējā mēģinājuma datums un cik reižu deja dejota koncertos un skatēs.",
    ]),
    ("Pūrlāde v0.2.7 — Cītības pūrs v0.1.0", "21.10.2026", [
        "Jauns modulis Cītības pūrs mēģinājumu, koncertu un citu nodarbību apmeklējuma uzskaitei; "
        "dejotāji tiek ņemti no Kopas pūra.",
        "Nodarbībai norāda datumu, veidu (Mēģinājums, Papildmēģinājums, Koncerts, Skate, Cits), nosaukumu vai tēmu, "
        "sākuma laiku un piezīmes; katram dejotājam atzīmē: Ieradās, Nokavēja, Attaisnoti nebija vai "
        "Neattaisnoti nebija, kā arī piezīmi. Poga “Pārējie ieradās” atzīmē visus vēl neatzīmētos.",
        "Cilne “Nodarbības”: saraksts ar apmeklējumu katrā nodarbībā; dubultklikšķis atver nodarbību "
        "atzīmēšanai, labošanai vai dzēšanai.",
        "Cilne “Dejotāju cītība”: katra dejotāja apmeklējums procentos, pēdējā ierašanās un cik nodarbības "
        "pēc kārtas nav ieradies; krāsas: zaļš ≥ 90 %, dzeltens 70–89 %, sarkans < 70 %. Dubultklikšķis "
        "atver dejotāja apmeklējuma vēsturi. Eksports uz Excel (CSV).",
        "Cilne “Žurnāls”: mēneša tabula dejotāji × nodarbības; dubultklikšķis uz šūnas ātri maina atzīmi.",
        "Kopsavilkuma kartītes un filtri: periods (šī sezona no 1. septembra, iepriekšējā sezona, mēnesis, gads, "
        "viss laiks vai savs periods), nodarbības veids, meklēšana.",
        "Kopas pūrs v0.1.3: dzēšanas brīdinājumā minēts, ka tiek dzēsta arī dejotāja apmeklējuma vēsture.",
    ]),
    ("Pūrlāde v0.2.6", "21.10.2026", [
        "Izmaiņu vēsturē pievienotas atsevišķās programmas Tērpu pūrs versijas pirms Pūrlādes.",
    ]),
    ("Pūrlāde v0.2.5", "21.10.2026", [
        "Moduļu izvēles labajā apakšējā stūrī pievienota poga “Izmaiņu vēsture”.",
    ]),
    ("Pūrlāde v0.2.4 — papildinājumi", "21.10.2026", [
        "Katra moduļa galvenē kreisajā augšējā stūrī ir moduļa logo; uzspiežot uz tā, "
        "atveras moduļa galvenais skats (Tērpu pūrs v0.2.7, Deju pūrs v0.1.7, Kopas pūrs v0.1.2).",
        "Tērpu pūrs saņēma jaunu logo tādā pašā stilā kā pārējie moduļi.",
        "Administrēšanā vairs nav atsevišķas “Tērpu pūra logotipa” izvēles — galvenē tiek rādīts moduļa logo.",
    ]),
    ("Pūrlāde v0.2.4", "21.10.2026", [
        "Sadaļa “Administrēšana” pārvietota no Tērpu pūra uz moduļu izvēli un kļuvusi kopīga visiem moduļiem: "
        "kolektīva nosaukums un logotips, moduļu tekstu un kolonnu nosaukumi, bloķēšana ar paroli, konsole.",
        "Kamēr Administrēšana ir atvērta, moduļus atvērt nevar; pēc aizvēršanas sākuma logs uzreiz parāda izmaiņas.",
        "“Atjaunot sākotnējos nosaukumus” atjauno tikai tekstus (logotipi un diagrammu iestatījumi paliek).",
        "Tērpu pūrs v0.2.6: noņemta poga “Administrēšana”; pārdēvējot tērpa veidu, nosaukums mainās arī Deju pūrā.",
    ]),
    ("Deju pūrs v0.1.0 – v0.1.6", "21.10.2026", [
        "Jauns modulis deju (repertuāra) uzskaitei: horeogrāfs, mūzika, veids, pāru skaits, ilgums, tērpi un apraksts.",
        "Dejas veidi: Latviešu skatuviskā deja, Uzveduma deja (ar uzveduma nosaukumu), Rotaļdeja.",
        "Dejas statuss: Repertuārā, Procesā, Atpūtā, Arhīvā.",
        "Dejas sastāvs (pamatsastāvs un rezerve) no Kopas pūra dejotājiem; pārskats “Dejotāju noslodze”.",
        "Dubultklikšķis uz dejas atver tās logu ar sastāvu, rediģēšanu un dzēšanu; imports no Excel.",
    ]),
    ("Pūrlāde v0.2.3", "21.10.2026", [
        "Moduļu izvēles galvenē Pūrlādes logo aizstāts ar lādi un moduļu kartītēm; blakus uzraksts "
        "“PŪRLĀDE” un zem tā “Viss kultūras kolektīvam vienuviet”.",
        "“© Adrians Gūtšmits 2026” pārvietots uz visu moduļu lapu apakšu vidū (Tērpu pūrs v0.2.5, Kopas pūrs v0.1.1).",
    ]),
    ("Pūrlāde v0.2.2", "21.10.2026", [
        "Pūrlādes logo galvenē palielināts un novietots uz krēmkrāsas plāksnītes, lai tas būtu labi redzams.",
    ]),
    ("Pūrlāde v0.2.1", "21.10.2026", [
        "Katram modulim izveidots apaļš logo; moduļu izvēlē tie aizstāj apli ar burtu.",
        "Moduļiem, kas vēl ir izstrādē, logo ir pelēks.",
    ]),
    ("Pūrlāde v0.2", "21.10.2026", [
        "Programmas versija pasludināta par 0.2 (saturs kā v0.1.3).",
    ]),
    ("Pūrlāde v0.1.3", "21.10.2026", [
        "Jauns modulis Kopas pūrs v0.1.0: dejotāju vārds un uzvārds, dzimums, dzimšanas un iestāšanās datums, "
        "statuss (aktīvs / neaktīvs / izstājies), augums, apģērba izmērs, kontakti; vecums un stāžs tiek aprēķināti.",
        "Kopas pūrā kopsavilkuma kartītes, meklēšana, filtri, kārtošana, imports no Excel; dejotāju ar "
        "neatgrieztiem tērpiem dzēst nevar.",
        "Tērpu pūrs v0.2.4 visu informāciju par dejotājiem ņem no Kopas pūra; sadaļa “Dejotāju pārvaldība” noņemta.",
        "Izsniegšanā redzami aktīvie dejotāji un tie, kam vēl ir tērpi; blakus parādās dejotāja augums un izmērs.",
        "Esošo dejotāju vārdi automātiski sadalīti vārdā un uzvārdā.",
    ]),
    ("Pūrlāde v0.1.2", "21.10.2026", [
        "Moduļu nosaukumi un apraksti ierakstīti arī Pūrlādes failā, lai kartīte nekad nepaliktu bez apraksta "
        "(atjaunots Kopas pūra apraksts).",
    ]),
    ("Pūrlāde v0.1.1", "21.10.2026", [
        "Tērpu pūrā (v0.2.3) poga “Beigt darbu” nomainīta uz “Atgriezties moduļu izvēlē”.",
        "Moduļu izvēles galvenē romba vietā Pūrlādes logo; tas ir arī loga ikona.",
    ]),
    ("Pūrlāde v0.1.0", "21.10.2026", [
        "Izveidota programma Pūrlāde ar sākuma logu un sešiem moduļiem: Tērpu, Deju, Kopas, Notikumu, "
        "Cītības un Zelta pūrs.",
        "Iepriekš atsevišķā programma Tērpu pūrs (v0.2.1) iekļauta kā pirmais modulis (v0.2.2) ar pogu "
        "atgriešanai Pūrlādē.",
        "Visi moduļi izmanto vienu kopīgu datubāzi purlade.db; Tērpu pūra dati pārņemti no costume_inventory.db.",
        "Pārējie pieci moduļi redzami ar atzīmi “Izstrādē”.",
    ]),
    # ---- before Pūrlāde: Tērpu pūrs as a stand-alone program ------------------------------
    ("Tērpu pūrs v0.2 – v0.2.1 (atsevišķa programma)", "20.10.2026", [
        "Versija 0.2 sākta 20.10.2026; loga virsrakstā redzama versija, galvenē — nosaukums bez versijas.",
        "Galvenais skats ar četrām diagrammām (pēc kategorijas, komplekta, noliktavā / izsniegti, pa dejotājiem); "
        "diagrammu veidu un saturu var izvēlēties “Galvenā loga iestatījumos”.",
        "Pogas Izsniegt, Atgriezt, Dejotāju pārvaldība un Noliktavas pārvaldība; izsniegšanā rādīti dejotāja "
        "dzimumam atbilstošie tērpi.",
        "Administrēšana ar paroli: tekstu un kolonnu nosaukumi, kolektīva un programmas logotips, konsoles loga "
        "rādīšana.",
        "Imports no Excel (dejotāji un tērpi), tērpa foto, stāvoklis (Lietojams / Jālabo / Nelietojams), "
        "brīdinājums par nesaglabātām izmaiņām, kļūdu žurnāls kludas.log.",
        "Poga “Beigt darbu” saglabā datus un aizver programmu.",
    ]),
    ("Tērpu pūrs v0.1 (atsevišķa programma)", "10.2026", [
        "Izveidota tautas deju kolektīva tērpu uzskaites programma Python valodā ar grafisku logu.",
        "Tabulas: tērpa detaļas, dejotāji un izsniegumi; tērpa iesniegšanas anketa.",
        "Katalogs ar meklēšanu un filtriem (kategorija, veids, komplekts, statuss) un grupēšanu.",
        "Izsniegumu lapa (aktīvie un atgrieztie); ierakstot atgriešanas datumu, statuss mainās automātiski.",
        "Kopsavilkums ar kopskaitiem un diagrammām pa kategorijām un komplektiem.",
        "Dejotāju tabula, ko var rediģēt; administrēšanas lapa kolonnu nosaukumu maiņai.",
        "Visi uzraksti latviešu valodā, termini “tērps” un “tērpa detaļa”; krēmkrāsas, sarkanais, tumšzilais "
        "un zelta dizains; programmas nosaukums “Tērpu pūrs” ar logotipu.",
        "Versijas v0.1.1, v0.1.2 … piegādātas kā faili “Tērpu pūrs vX.Y.Z”.",
    ]),
]


class ChangelogWindow(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Izmaiņu vēsture")
        self.geometry("760x620")
        self.minsize(520, 360)
        self.configure(bg=CREAM)
        self.transient(root)

        head = tk.Frame(self, bg=NAVY)
        head.pack(fill="x")
        tk.Label(head, text="Izmaiņu vēsture", font=("Georgia", 17, "bold"), bg=NAVY, fg=CREAM).pack(
            side="left", padx=18, pady=10)
        tk.Label(head, text="jaunākās izmaiņas augšā", font=("Segoe UI", 9, "italic"), bg=NAVY, fg=GOLD).pack(
            side="left", pady=(14, 8))
        tk.Frame(self, bg=GOLD, height=3).pack(fill="x")

        bottom = tk.Frame(self, bg=CREAM)
        bottom.pack(side="bottom", fill="x", padx=14, pady=10)
        ttk.Button(bottom, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")

        box = tk.Frame(self, bg=CREAM)
        box.pack(fill="both", expand=True, padx=14, pady=(10, 0))
        text = tk.Text(box, wrap="word", bg=WHITE, fg=NAVY, relief="flat", bd=0, padx=18, pady=12,
                       highlightthickness=1, highlightbackground=GOLD, font=("Segoe UI", 10), cursor="arrow")
        sb = ttk.Scrollbar(box, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=sb.set)
        text.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        text.tag_configure("version", font=("Georgia", 13, "bold"), foreground=RED, spacing1=14)
        text.tag_configure("date", font=("Segoe UI", 9, "italic"), foreground=GOLD)
        text.tag_configure("item", lmargin1=14, lmargin2=30, spacing1=3)
        text.tag_configure("rule", font=("Segoe UI", 4), background=CREAM_DARK)
        for i, (version, day, items) in enumerate(CHANGELOG):
            if i:
                text.insert("end", "\n", "rule")
            text.insert("end", version, "version")
            text.insert("end", "   " + day + "\n", "date")
            for item in items:
                text.insert("end", "•  " + item + "\n", "item")
        text.configure(state="disabled")
        self.bind("<Escape>", lambda e: self.destroy())
        self.focus_set()


def show(root):
    return ChangelogWindow(root)
