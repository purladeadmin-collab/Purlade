"""
Pūrlāde — kopīgais izskats (v0.8): krāsas, pogu un tabulu stils, sānu josla, moduļa galvene un cilnes.

  * apply_style()      — ttk stils visiem moduļiem: galvenā poga (Accent) tumšzila, bīstamā (Danger) sarkana
                         ar baltu fonu, atslēgtas pogas skaidri pelēkas; tabulām gaišas galvenes.
  * Sidebar            — tumšzilā sānu josla ar Pūrlādes logo, “Sākums”, moduļiem, “Kolektīvs” un lietotāju.
  * ModuleHost         — rāmis, kurā modulis zīmē savu saturu blakus sānu joslai; loga komandas (virsraksts,
                         izmērs) tas nodod galvenajam logam, tāpēc moduļu kods var palikt kā līdz šim.
  * module_header()    — baltā moduļa galvene: logo, nosaukums, apraksts, vieta moduļa pogām; zem tās
                         moduļa krāsas līnija.
  * TabBar             — cilnes ar pasvītrojumu moduļa krāsā.
  * panel(), chip(), search_box(), Segmented, dialog_header(), dialog_footer() — kopīgās detaļas moduļu
                         skatiem un logiem (Tērpu pūrs v0.5.5 un turpmāk).
"""

import os
import tkinter as tk
from tkinter import ttk

try:
    from moduli import kopeja as K
except ImportError:  # started from inside the moduli folder
    import kopeja as K

NAVY, GOLD, RED, CREAM, CREAM_DARK, WHITE, GREEN = K.NAVY, K.GOLD, K.RED, K.CREAM, K.CREAM_DARK, K.WHITE, K.GREEN
LINE = "#E6DCC3"          # frames and separators
LINE_SOFT = "#F0E8D4"
FIELD_LINE = "#C9BFA6"    # input fields, secondary buttons
MUTED = "#6B5D3F"         # notes and labels (instead of blue italics)
NAVY_HOVER = "#2E3B5C"
SIDE_TEXT = "#E8E2D2"
SIDE_DIM = "#9AA3B8"
SIDE_LINE = "#33405F"
GOLD_LIGHT = "#D9BE6A"
DISABLED_BG = "#E4DFD2"
DISABLED_FG = "#8C8577"
SELECTED = "#F3E8CC"

MODULE_COLORS = {"terpu_purs": RED, "deju_purs": NAVY, "kopas_purs": "#2E7D6B", "notikumu_purs": "#7A5C99",
                 "citibas_purs": "#C4703A", "zelta_purs": "#A8841A"}

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_SMALL = ("Segoe UI", 9)
TITLE_FONT = ("Georgia", 18, "bold")

POWER_ICON_B64 = K.POWER_ICON_B64


# --------------------------------------------------------------------------
# ttk style
# --------------------------------------------------------------------------
def apply_style():
    """The common look of buttons, tables, fields and notebook tabs (called by every module's setup_style)."""
    s = ttk.Style()
    try:
        s.theme_use("clam")
    except tk.TclError:
        pass
    s.configure(".", background=CREAM, foreground=NAVY, font=FONT)
    s.configure("TFrame", background=CREAM)
    s.configure("TLabel", background=CREAM, foreground=NAVY)
    for w in ("TCheckbutton", "TRadiobutton"):
        s.configure(w, background=CREAM, foreground=NAVY)
        s.map(w, background=[("active", CREAM)], foreground=[("disabled", DISABLED_FG)])
    # secondary button: white with a sand border
    s.configure("TButton", background=WHITE, foreground=NAVY, bordercolor=FIELD_LINE, lightcolor=WHITE,
                darkcolor=WHITE, padding=(12, 6), borderwidth=1, focuscolor=NAVY, font=FONT)
    s.map("TButton", background=[("disabled", "#F3F0E8"), ("pressed", SELECTED), ("active", SELECTED)],
          foreground=[("disabled", DISABLED_FG)], bordercolor=[("disabled", LINE)],
          lightcolor=[("active", SELECTED), ("disabled", "#F3F0E8")],
          darkcolor=[("active", SELECTED), ("disabled", "#F3F0E8")])
    # main action: navy
    s.configure("Accent.TButton", background=NAVY, foreground=WHITE, bordercolor=NAVY, lightcolor=NAVY,
                darkcolor=NAVY, font=FONT_BOLD, padding=(14, 6))
    s.map("Accent.TButton", background=[("disabled", DISABLED_BG), ("pressed", NAVY_HOVER), ("active", NAVY_HOVER)],
          foreground=[("disabled", DISABLED_FG), ("active", WHITE)],
          bordercolor=[("disabled", DISABLED_BG)],
          lightcolor=[("disabled", DISABLED_BG), ("active", NAVY_HOVER)],
          darkcolor=[("disabled", DISABLED_BG), ("active", NAVY_HOVER)])
    # dangerous action: red text and border; red when pressed
    s.configure("Danger.TButton", background=WHITE, foreground=RED, bordercolor=RED, lightcolor=WHITE,
                darkcolor=WHITE, font=FONT_BOLD, padding=(12, 6))
    s.map("Danger.TButton", background=[("disabled", "#F3F0E8"), ("active", RED)],
          foreground=[("disabled", DISABLED_FG), ("active", WHITE)], bordercolor=[("disabled", LINE)],
          lightcolor=[("active", RED)], darkcolor=[("active", RED)])
    s.configure("Green.TButton", background=GREEN, foreground=WHITE, bordercolor=GREEN, lightcolor=GREEN,
                darkcolor=GREEN, font=FONT_BOLD)
    s.map("Green.TButton", background=[("disabled", DISABLED_BG), ("active", NAVY)],
          foreground=[("disabled", DISABLED_FG), ("active", WHITE)])
    # fields
    for w in ("TEntry", "TCombobox", "TSpinbox"):
        s.configure(w, fieldbackground=WHITE, bordercolor=FIELD_LINE, lightcolor=WHITE, darkcolor=WHITE,
                    padding=4)
        s.map(w, fieldbackground=[("readonly", "!focus", WHITE if w == "TCombobox" else "#F7F3E9"),
                                  ("disabled", "#F3F0E8")],
              foreground=[("disabled", DISABLED_FG)], bordercolor=[("focus", NAVY)],
              lightcolor=[("focus", WHITE)])
    # tables
    s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                bordercolor=LINE, lightcolor=LINE, darkcolor=LINE)
    s.configure("Treeview.Heading", background=CREAM_DARK, foreground=NAVY, font=FONT_BOLD, padding=6,
                relief="flat", bordercolor=LINE, lightcolor=CREAM_DARK, darkcolor=CREAM_DARK)
    s.map("Treeview.Heading", background=[("active", "#E9DDB8")])
    s.map("Treeview", background=[("selected", "#E9DDB8")], foreground=[("selected", NAVY)])
    # notebook tabs: light, the open one white
    s.configure("TNotebook", background=CREAM, borderwidth=0, tabmargins=(0, 4, 0, 0))
    s.configure("TNotebook.Tab", background=CREAM_DARK, foreground="#4A4535", padding=(14, 6), font=FONT,
                bordercolor=LINE, lightcolor=CREAM_DARK)
    s.map("TNotebook.Tab", background=[("selected", WHITE)], foreground=[("selected", NAVY)],
          font=[("selected", FONT_BOLD)], lightcolor=[("selected", WHITE)])
    s.configure("TLabelframe", background=CREAM, bordercolor=LINE)
    s.configure("TLabelframe.Label", background=CREAM, foreground=RED, font=("Georgia", 11, "bold"))
    s.configure("Vertical.TScrollbar", background=CREAM_DARK, troughcolor=CREAM, bordercolor=LINE,
                arrowcolor=NAVY, lightcolor=CREAM_DARK, darkcolor=CREAM_DARK)
    s.configure("Horizontal.TScrollbar", background=CREAM_DARK, troughcolor=CREAM, bordercolor=LINE,
                arrowcolor=NAVY, lightcolor=CREAM_DARK, darkcolor=CREAM_DARK)
    s.configure("TProgressbar", background=NAVY, troughcolor=LINE_SOFT, bordercolor=LINE)


# --------------------------------------------------------------------------
# A frame that stands in for the window when a module is opened next to the side bar
# --------------------------------------------------------------------------
class ModuleHost(tk.Frame):
    """Modules were written for the whole window (they call root.title(), root.minsize() …). Inside Pūrlāde
    they get this frame instead; window commands are passed on to the real window."""

    def title(self, text=None):
        return self.winfo_toplevel().title(text) if text is not None else self.winfo_toplevel().title()

    wm_title = title

    def minsize(self, *args):
        return None   # the window's minimum size is set by Pūrlāde (side bar + module)

    def geometry(self, *args):
        return None

    def protocol(self, *args):
        return None   # closing the window is handled by Pūrlāde

    def iconbitmap(self, *args, **kw):
        return None

    def iconphoto(self, *args, **kw):
        return None

    def state(self, *args):
        return self.winfo_toplevel().state(*args)

    def clear(self):
        for child in self.winfo_children():
            child.destroy()


# --------------------------------------------------------------------------
# Module header
# --------------------------------------------------------------------------
def module_header(parent, key, name, subtitle="", on_logo=None, on_exit=None, tabs=False):
    """White header of a module. Returns the frame on its right for the module's own buttons.
    on_exit: only when the module runs on its own (no side bar) — then a “Beigt darbu” button is shown.
    tabs=True: a TabBar under the title (returned frame's .tabs)."""
    bar = tk.Frame(parent, bg=WHITE)
    bar.pack(fill="x")
    inner = tk.Frame(bar, bg=WHITE)
    inner.pack(fill="x", padx=24, pady=(12, 10))
    logo = K.module_logo(inner, key, on_click=on_logo, size=48, bg=WHITE)
    if logo is not None:
        logo.pack(side="left", padx=(0, 12))
    box = tk.Frame(inner, bg=WHITE)
    box.pack(side="left")
    title = tk.Label(box, text=name, font=TITLE_FONT, bg=WHITE, fg=NAVY, cursor="hand2" if on_logo else "")
    title.pack(anchor="w")
    if on_logo:
        title.bind("<Button-1>", lambda e: on_logo())
    sub = None
    if subtitle:
        sub = tk.Label(box, text=subtitle, font=FONT_SMALL, bg=WHITE, fg=MUTED)
        sub.pack(anchor="w")
    right = tk.Frame(inner, bg=WHITE)
    right.pack(side="right")
    right.subtitle = sub   # the module may change the text later (e.g. counts)
    if on_exit is not None:
        icon = _photo(POWER_ICON_B64)
        btn = tk.Button(right, text=" Beigt darbu", image=icon or "", compound="left", command=on_exit,
                        font=FONT_BOLD, bg=WHITE, fg=NAVY, activebackground=SELECTED, relief="flat", bd=0,
                        highlightthickness=1, highlightbackground=FIELD_LINE, cursor="hand2", padx=10, pady=4)
        btn.image = icon
        btn.pack(side="right", padx=(8, 0))
    right.tabs = None
    if tabs:
        inner.pack_configure(pady=(12, 2))
        right.tabs = TabBar(bar, colour=MODULE_COLORS.get(key, NAVY))
        right.tabs.pack(fill="x", padx=(14, 24))
    tk.Frame(parent, bg=LINE, height=1).pack(fill="x")
    tk.Frame(parent, bg=MODULE_COLORS.get(key, GOLD), height=3).pack(fill="x")
    return right


def _photo(b64):
    try:
        return tk.PhotoImage(data=b64)
    except Exception:
        return None


def header_button(parent, text, command, primary=False):
    """Small button for a module header (white background)."""
    b = tk.Button(parent, text=text, command=command, font=FONT_BOLD if primary else FONT,
                  bg=NAVY if primary else WHITE, fg=WHITE if primary else NAVY,
                  activebackground=NAVY_HOVER if primary else SELECTED,
                  activeforeground=WHITE if primary else NAVY, relief="flat", bd=0,
                  highlightthickness=0 if primary else 1, highlightbackground=FIELD_LINE, cursor="hand2",
                  padx=12, pady=5)
    return b


# --------------------------------------------------------------------------
# Tabs
# --------------------------------------------------------------------------
class TabBar(tk.Frame):
    """A row of tabs; the open one bold with a line in the module colour."""

    def __init__(self, master, colour=NAVY, bg=WHITE):
        super().__init__(master, bg=bg)
        self.colour, self.bg = colour, bg
        self.tabs = []   # (key, label, line)

    def add(self, key, text, command):
        box = tk.Frame(self, bg=self.bg)
        box.pack(side="left", padx=(0, 4))
        label = tk.Label(box, text=text, font=FONT, bg=self.bg, fg="#4A4535", padx=14, pady=8, cursor="hand2")
        label.pack()
        line = tk.Frame(box, bg=self.bg, height=3)
        line.pack(fill="x")
        for w in (box, label):
            w.bind("<Button-1>", lambda e: command())
        label.bind("<Enter>", lambda e: label.configure(fg=NAVY))
        label.bind("<Leave>", lambda e, k=key: label.configure(fg=NAVY if k == self.active else "#4A4535"))
        self.tabs.append((key, label, line))
        return label

    active = None

    def set_active(self, key):
        self.active = key
        for k, label, line in self.tabs:
            on = k == key
            label.configure(font=FONT_BOLD if on else FONT, fg=NAVY if on else "#4A4535")
            line.configure(bg=self.colour if on else self.bg)


# --------------------------------------------------------------------------
# Side bar
# --------------------------------------------------------------------------
class Sidebar(tk.Frame):
    """items: [(key, name, logo file name or None, enabled)] — the modules; extras: [(key, name)] under
    “Kolektīvs”. on_select(key) is called with "home", a module key or an extra key."""

    WIDTH = 236

    def __init__(self, master, logo_b64, group_name, user, items, extras, on_select, on_change_user=None,
                 on_quit=None, version=""):
        super().__init__(master, bg=NAVY, width=self.WIDTH)
        self.pack_propagate(False)
        self.on_select = on_select
        self.rows = {}
        self.active = None
        self.images = []

        top = tk.Frame(self, bg=NAVY)
        top.pack(fill="x", padx=14, pady=(14, 10))
        logo = _photo(logo_b64)
        if logo is not None:
            # the chest logo is wide: show it smaller
            w = logo.width()
            if w > 70:
                logo = logo.subsample(max(1, round(w / 64)))
            self.images.append(logo)
            tk.Label(top, image=logo, bg=NAVY, cursor="hand2").pack(side="left")
        tbox = tk.Frame(top, bg=NAVY)
        tbox.pack(side="left", padx=(8, 0))
        t = tk.Label(tbox, text="Pūrlāde", font=("Georgia", 16, "bold"), bg=NAVY, fg=CREAM, cursor="hand2")
        t.pack(anchor="w")
        t.bind("<Button-1>", lambda e: on_select("home"))
        tk.Label(tbox, text=group_name, font=FONT_SMALL, bg=NAVY, fg=GOLD_LIGHT, wraplength=140,
                 justify="left").pack(anchor="w")
        tk.Frame(self, bg=SIDE_LINE, height=1).pack(fill="x")

        self._item("home", "Sākums", icon="home", pady_top=8)
        self._section("MODUĻI")
        for key, name, logo_name, enabled in items:
            self._item(key, name, logo_name=logo_name, enabled=enabled)
        if extras:
            self._section("KOLEKTĪVS")
            for key, name in extras:
                self._item(key, name)

        # user and quitting at the bottom
        bottom = tk.Frame(self, bg=NAVY)
        bottom.pack(side="bottom", fill="x", padx=14, pady=(8, 12))
        tk.Label(self, text=version, font=("Segoe UI", 8), bg=NAVY, fg=SIDE_DIM).pack(side="bottom", anchor="w",
                                                                                      padx=14)
        tk.Frame(self, bg=SIDE_LINE, height=1).pack(side="bottom", fill="x", pady=(6, 4))
        initials = "".join(p[0] for p in (user.get("name") or "?").split()[:2]).upper() or "?"
        tk.Label(bottom, text=initials, font=("Segoe UI", 10, "bold"), bg=GOLD, fg=NAVY, width=3,
                 pady=6).pack(side="left")
        ubox = tk.Frame(bottom, bg=NAVY)
        ubox.pack(side="left", padx=(8, 0), fill="x", expand=True)
        tk.Label(ubox, text=user.get("name") or "", font=("Segoe UI", 9, "bold"), bg=NAVY, fg=CREAM,
                 anchor="w", wraplength=120, justify="left").pack(anchor="w")
        if user.get("roles"):
            tk.Label(ubox, text=user["roles"], font=("Segoe UI", 8), bg=NAVY, fg=GOLD_LIGHT, anchor="w",
                     wraplength=120, justify="left").pack(anchor="w")
        if on_change_user is not None:
            link = tk.Label(ubox, text="Mainīt lietotāju", font=("Segoe UI", 8, "underline"), bg=NAVY,
                            fg=GOLD_LIGHT, cursor="hand2")
            link.pack(anchor="w")
            link.bind("<Button-1>", lambda e: on_change_user())
        if on_quit is not None:
            icon = _photo(POWER_ICON_B64)
            if icon is not None:
                self.images.append(icon)
            q = tk.Button(bottom, image=icon or "", text="" if icon else "Beigt", command=on_quit, bg=NAVY,
                          activebackground=NAVY_HOVER, relief="flat", bd=0, highlightthickness=1,
                          highlightbackground=GOLD, cursor="hand2", width=32, height=32)
            q.pack(side="right")
            self.quit_button = q

    def _section(self, text):
        tk.Label(self, text=text, font=("Segoe UI", 8, "bold"), bg=NAVY, fg=SIDE_DIM, anchor="w").pack(
            fill="x", padx=16, pady=(14, 4))

    def _item(self, key, name, logo_name=None, icon=None, enabled=True, pady_top=0):
        row = tk.Frame(self, bg=NAVY, cursor="hand2" if enabled else "")
        row.pack(fill="x", pady=(pady_top, 0))
        mark = tk.Frame(row, bg=NAVY, width=4)
        mark.pack(side="left", fill="y")
        image = None
        if logo_name:
            path = os.path.join(K.MODULE_LOGO_DIR, logo_name + (".png" if enabled else "_peleks.png"))
            if not os.path.exists(path):
                path = os.path.join(K.MODULE_LOGO_DIR, logo_name + ".png")
            try:
                image = K.load_image(path, 28, 28)
            except Exception:
                image = None
        elif icon == "home":
            image = _photo(K.HOME_ICON_B64)
        if image is not None:
            self.images.append(image)
            pic = tk.Label(row, image=image, bg=NAVY)
            pic.pack(side="left", padx=(10, 8), pady=7)
        else:
            pic = tk.Label(row, text="", bg=NAVY, width=2)
            pic.pack(side="left", padx=(10, 8), pady=7)
        label = tk.Label(row, text=name, font=("Segoe UI", 10), bg=NAVY, fg=SIDE_TEXT if enabled else SIDE_DIM,
                         anchor="w")
        label.pack(side="left", fill="x", expand=True)
        widgets = (row, mark, pic, label)
        self.rows[key] = (widgets, enabled)
        if enabled:
            for w in widgets:
                w.bind("<Button-1>", lambda e, k=key: self.on_select(k))
                w.bind("<Enter>", lambda e, k=key: self._hover(k, True))
                w.bind("<Leave>", lambda e, k=key: self._hover(k, False))
        else:
            for w in widgets:
                w.bind("<Button-1>", lambda e, k=key: self.on_select(k))

    def _paint(self, key):
        widgets, enabled = self.rows[key]
        row, mark, pic, label = widgets
        on = key == self.active
        bg = NAVY_HOVER if on else NAVY
        for w in (row, pic, label):
            w.configure(bg=bg)
        mark.configure(bg=GOLD if on else bg)
        label.configure(font=("Segoe UI", 10, "bold") if on else ("Segoe UI", 10),
                        fg=WHITE if on else (SIDE_TEXT if enabled else SIDE_DIM))

    def _hover(self, key, inside):
        if key == self.active:
            return
        widgets, _enabled = self.rows[key]
        row, mark, pic, label = widgets
        bg = "#28344F" if inside else NAVY
        for w in (row, mark, pic, label):
            w.configure(bg=bg)

    def set_active(self, key):
        old, self.active = self.active, key
        for k in (old, key):
            if k in self.rows:
                self._paint(k)


# --------------------------------------------------------------------------
# Small building blocks for pages (start page and later the modules)
# --------------------------------------------------------------------------
def card(parent, title=None, padx=16, pady=12):
    """White box with a sand border; returns (outer, body)."""
    outer = tk.Frame(parent, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
    if title:
        head = tk.Frame(outer, bg=WHITE)
        head.pack(fill="x", padx=padx, pady=(10, 6))
        tk.Label(head, text=title, font=("Georgia", 13, "bold"), bg=WHITE, fg=NAVY).pack(side="left")
        tk.Frame(outer, bg=LINE_SOFT, height=1).pack(fill="x")
        outer.head = head
    body = tk.Frame(outer, bg=WHITE)
    body.pack(fill="both", expand=True, padx=padx, pady=(6 if title else pady, pady))
    return outer, body


def date_badge(parent, iso, colour):
    """Small calendar sheet: month above, day number below."""
    months = ["JAN", "FEB", "MAR", "APR", "MAI", "JŪN", "JŪL", "AUG", "SEP", "OKT", "NOV", "DEC"]
    box = tk.Frame(parent, bg=WHITE, highlightbackground=colour, highlightthickness=1)
    try:
        m, d = months[int(iso[5:7]) - 1], iso[8:10]
    except (ValueError, IndexError):
        m, d = "", ""
    tk.Label(box, text=m, font=("Segoe UI", 7, "bold"), bg=colour, fg=WHITE, width=5).pack(fill="x")
    tk.Label(box, text=d, font=("Georgia", 14, "bold"), bg=WHITE, fg=NAVY).pack()
    return box


# --------------------------------------------------------------------------
# Parts for module views and windows (Pūrlāde v0.8.1)
# --------------------------------------------------------------------------
OK_BG, OK_FG = "#E3F1E8", "#1B6B3A"         # green: done, available, usable
WARN_BG, WARN_FG = "#FBF0D2", "#7A5A00"     # amber: partly, needs repair
BAD_BG, BAD_FG = "#F7E3E7", RED             # red: missing, debt, unusable
ZEBRA = "#FDFAF2"                           # every second table row


def panel(parent, title=None, subtitle=None):
    """White box with a sand border and (optionally) a title row; the body has no inner margin, so that a
    table can fill it. Returns (outer, head, body); head is None without a title — put buttons into
    head.right (packed on the right side of the title row)."""
    outer = tk.Frame(parent, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
    head = None
    if title is not None:
        head = tk.Frame(outer, bg=WHITE)
        head.pack(fill="x", padx=14, pady=(9, 8))
        head.title = tk.Label(head, text=title, font=("Georgia", 12, "bold"), bg=WHITE, fg=NAVY, anchor="w")
        head.title.pack(side="left")
        head.subtitle = None
        if subtitle is not None:
            head.subtitle = tk.Label(head, text=subtitle, font=FONT_SMALL, bg=WHITE, fg=MUTED)
            head.subtitle.pack(side="left", padx=(10, 0))
        head.right = tk.Frame(head, bg=WHITE)
        head.right.pack(side="right")
        tk.Frame(outer, bg=LINE_SOFT, height=1).pack(fill="x")
    body = tk.Frame(outer, bg=WHITE)
    body.pack(fill="both", expand=True)
    return outer, head, body


def chip(parent, text, bg=SELECTED, fg=NAVY, bold=True):
    """Small coloured label (status, condition …)."""
    return tk.Label(parent, text=text, bg=bg, fg=fg, font=("Segoe UI", 8, "bold") if bold else ("Segoe UI", 8),
                    padx=7, pady=1)


def search_box(parent, var, width=22, bg=WHITE):
    """Search field with a magnifier; returns the frame (frame.entry is the field)."""
    box = tk.Frame(parent, bg=WHITE, highlightbackground=FIELD_LINE, highlightthickness=1)
    tk.Label(box, text="🔍", bg=WHITE, fg=MUTED, font=("Segoe UI Emoji", 9)).pack(side="left", padx=(6, 0))
    entry = tk.Entry(box, textvariable=var, width=width, relief="flat", bd=0, bg=WHITE, fg=NAVY,
                     insertbackground=NAVY, font=FONT)
    entry.pack(side="left", padx=(4, 4), pady=4, fill="x", expand=True)
    clear = tk.Label(box, text="✕", bg=WHITE, fg=MUTED, cursor="hand2", font=FONT_SMALL)
    clear.pack(side="left", padx=(0, 6))
    clear.bind("<Button-1>", lambda e: (var.set(""), entry.focus_set()))
    box.entry = entry
    return box


class Segmented(tk.Frame):
    """A few options side by side (one chosen), e.g. “Aktīvie | Atgrieztie | Visi”."""

    def __init__(self, master, options, var, command=None, bg=WHITE):
        super().__init__(master, bg=FIELD_LINE)
        self.var, self.command, self.labels = var, command, {}
        for i, (value, text) in enumerate(options):
            lbl = tk.Label(self, text=text, font=FONT, bg=WHITE, fg=NAVY, padx=12, pady=4, cursor="hand2")
            lbl.pack(side="left", padx=(1 if i == 0 else 0, 1), pady=1)
            lbl.bind("<Button-1>", lambda e, v=value: self.choose(v))
            self.labels[value] = lbl
        var.trace_add("write", lambda *a: self.paint())
        self.paint()

    def choose(self, value):
        if self.var.get() != value:
            self.var.set(value)
            if self.command:
                self.command()

    def paint(self):
        for value, lbl in self.labels.items():
            on = value == self.var.get()
            lbl.configure(bg=NAVY if on else WHITE, fg=WHITE if on else NAVY, font=FONT_BOLD if on else FONT)


def dialog_header(win, title, subtitle="", colour=GOLD, wrap=640):
    """White title strip of a pop-up window (title, grey explanation, line in the module colour)."""
    bar = tk.Frame(win, bg=WHITE)
    bar.pack(fill="x", side="top")
    bar.title = tk.Label(bar, text=title, font=("Georgia", 15, "bold"), bg=WHITE, fg=NAVY, anchor="w",
                         justify="left")
    bar.title.pack(fill="x", padx=20, pady=(14, 0 if subtitle else 12))
    bar.subtitle = None
    if subtitle:
        bar.subtitle = tk.Label(bar, text=subtitle, font=FONT_SMALL, bg=WHITE, fg=MUTED, anchor="w",
                                justify="left", wraplength=wrap)
        bar.subtitle.pack(fill="x", padx=20, pady=(2, 12))
    tk.Frame(win, bg=LINE, height=1).pack(fill="x", side="top")
    tk.Frame(win, bg=colour, height=3).pack(fill="x", side="top")
    return bar


def dialog_footer(win):
    """White button bar at the bottom of a pop-up window; create it BEFORE the expanding body so that it is
    never cut off. Returns the inner frame (pack buttons with side="right")."""
    foot = tk.Frame(win, bg=WHITE)
    foot.pack(side="bottom", fill="x")
    tk.Frame(win, bg=LINE, height=1).pack(side="bottom", fill="x")
    inner = tk.Frame(foot, bg=WHITE)
    inner.pack(fill="x", padx=20, pady=10)
    return inner


def note(parent, text, bg=CREAM, wrap=0):
    """Grey explanation text (instead of blue italics)."""
    return tk.Label(parent, text=text, bg=bg, fg=MUTED, font=FONT_SMALL, anchor="w", justify="left",
                    wraplength=wrap)

