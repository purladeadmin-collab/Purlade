"""
Pūrlāde — Izstrādes darbi (opened from the "✎ Izstrādes darbi" button on the start page)

A to-do list for the development of the program: for each task the module, what has to be
done, the creation date (filled in automatically), an optional deadline and the date it was done.
The "Kļūdu žurnāls" button shows the errors written to kludas.log; double-clicking an error adds
it to the task list.
The button is hidden while Administrēšana is locked.
"""

import os
import re
import sqlite3
from datetime import date, datetime
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from moduli.kopeja import DB_PATH, connect_db, ERROR_LOG, parse_date, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY
except ImportError:
    from kopeja import DB_PATH, connect_db, ERROR_LOG, parse_date, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY

GENERAL = "Pūrlāde (vispārīgi)"
SHOW_OPEN = "Neizpildītie"
SHOW_DONE = "Izpildītie"
SHOW_ALL = "Visi"
ALL = "Visi"
AMBER = "#B07D00"

COLUMNS = [
    ("module", "Modulis", 140),
    ("text", "Darbs", 360),
    ("created", "Izveidots", 95),
    ("deadline", "Termiņš", 95),
    ("done", "Izpildīts", 95),
]


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Tasks:
    def __init__(self):
        self.con = connect_db(DB_PATH)
        self.con.execute("""CREATE TABLE IF NOT EXISTS dev_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module TEXT NOT NULL,
            description TEXT NOT NULL,
            created TEXT NOT NULL,
            deadline TEXT DEFAULT '',
            done_date TEXT DEFAULT '')""")
        cols = {r[1] for r in self.con.execute("PRAGMA table_info(dev_tasks)")}
        if "error_key" not in cols:  # an error from the error log this task was made from
            self.con.execute("ALTER TABLE dev_tasks ADD COLUMN error_key TEXT DEFAULT ''")
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass


def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (empty stays empty)."""
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or ""


def today_text():
    return date.today().strftime("%d.%m.%Y")


# --------------------------------------------------------------------------
# Error log (kludas.log)
# --------------------------------------------------------------------------
# which module a program file belongs to
FILE_MODULES = {
    "terpu_purs": "Tērpu pūrs", "deju_purs": "Deju pūrs", "kopas_purs": "Kopas pūrs",
    "notikumu_purs": "Notikumu pūrs", "citibas_purs": "Cītības pūrs", "zelta_purs": "Zelta pūrs",
}
TIME_LINE = re.compile(r"^(\d{2}\.\d{2}\.\d{4}|\d{4}-\d{2}-\d{2}) \d{2}:\d{2}:\d{2}$")
FILE_LINE = re.compile(r'File "([^"]+)", line (\d+), in (\S+)')


def show_time(text):
    """'2026-10-21 21:05:33' or '21.10.2026 21:05:33' -> '21.10.2026 21:05'."""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%d.%m.%Y %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).strftime("%d.%m.%Y %H:%M")
        except ValueError:
            pass
    return text


def read_error_log(module_names):
    """Errors from kludas.log, newest first: dicts with time, module, summary, place, text, key."""
    if not os.path.exists(ERROR_LOG):
        return []
    try:
        with open(ERROR_LOG, encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []
    entries, current = [], None
    for line in lines:
        if TIME_LINE.match(line.strip()):
            current = {"time": line.strip(), "lines": []}
            entries.append(current)
        elif current is not None:
            current["lines"].append(line)
    errors = []
    for e in entries:
        body = [ln for ln in e["lines"] if ln.strip()]
        if not body:
            continue
        summary = body[-1].strip()
        module, place = GENERAL, ""
        for ln in body:
            m = FILE_LINE.search(ln)
            if not m:
                continue
            path, line_no, func = m.groups()
            parts = path.replace("\\", "/").split("/")  # works for Windows and other paths alike
            file_name = parts[-1]
            stem = os.path.splitext(file_name)[0]
            if "moduli" in parts or stem.startswith("Pūrlāde"):
                place = f"{file_name}, rinda {line_no}, funkcija {func}"
                name = FILE_MODULES.get(stem)
                module = name if name in module_names else GENERAL
        errors.append({"time": e["time"], "module": module, "summary": summary, "place": place,
                       "text": "\n".join(e["lines"]).strip(), "key": e["time"] + " | " + summary})
    errors.reverse()
    return errors


class ErrorLogWindow(tk.Toplevel):
    """Kļūdu žurnāls: the errors of kludas.log; double-click adds an error to the task list."""

    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.title("Kļūdu žurnāls")
        self.geometry("920x600")
        self.minsize(700, 420)
        self.configure(bg=CREAM)
        self.transient(owner)
        head = tk.Frame(self, bg=NAVY)
        head.pack(fill="x")
        tk.Label(head, text="Kļūdu žurnāls", font=("Georgia", 17, "bold"), bg=NAVY, fg=CREAM).pack(
            side="left", padx=18, pady=10)
        tk.Label(head, text="dubultklikšķis uz kļūdas — pievienot izstrādes darbu sarakstam",
                 font=("Segoe UI", 9, "italic"), bg=NAVY, fg=GOLD).pack(side="left", pady=(14, 8))
        tk.Frame(self, bg=GOLD, height=3).pack(fill="x")

        bottom = tk.Frame(self, bg=CREAM)
        bottom.pack(side="bottom", fill="x", padx=14, pady=10)
        ttk.Button(bottom, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        ttk.Button(bottom, text="↻ Atjaunot", command=self.refresh).pack(side="right", padx=6)
        tk.Label(bottom, text="Fails: " + ERROR_LOG, bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).pack(side="left")

        panes = ttk.PanedWindow(self, orient="vertical")
        panes.pack(fill="both", expand=True, padx=14, pady=(10, 4))
        top = tk.Frame(panes, bg=CREAM)
        self.tree = ttk.Treeview(top, columns=("time", "module", "summary", "added"), show="headings")
        for key, title, width, stretch in (("time", "Laiks", 125, False), ("module", "Modulis", 130, False),
                                           ("summary", "Kļūda", 440, True), ("added", "Darbu sarakstā", 110, False)):
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, minwidth=60, anchor="w", stretch=stretch)
        self.tree.tag_configure("added", foreground=GREY)
        vsb = ttk.Scrollbar(top, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        panes.add(top, weight=3)
        details = tk.Frame(panes, bg=CREAM)
        tk.Label(details, text="Kļūdas detaļas", bg=CREAM, fg=RED, font=("Georgia", 11, "bold")).pack(
            anchor="w", pady=(6, 2))
        self.details = tk.Text(details, height=8, wrap="none", bg=WHITE, fg=NAVY, relief="flat",
                               highlightthickness=1, highlightbackground=GOLD, font=("Consolas", 9))
        self.details.pack(fill="both", expand=True)
        panes.add(details, weight=2)

        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_details())
        self.tree.bind("<Double-1>", self.add_task)
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Destroy>", self._give_back_grab)
        self.refresh()
        self.grab_set()

    def _give_back_grab(self, event):
        if event.widget is self:
            try:
                self.owner.grab_set()
            except tk.TclError:
                pass

    def refresh(self):
        self.errors = read_error_log(self.owner.module_names)
        added = {k for (k,) in self.owner.db.q("SELECT error_key FROM dev_tasks WHERE error_key != ''")}
        self.tree.delete(*self.tree.get_children())
        for i, e in enumerate(self.errors):
            is_added = e["key"] in added
            self.tree.insert("", "end", iid=str(i), tags=("added",) if is_added else (), values=(
                show_time(e["time"]), e["module"], e["summary"], "✔ pievienota" if is_added else ""))
        self.show_details()

    def show_details(self):
        self.details.configure(state="normal")
        self.details.delete("1.0", "end")
        sel = self.tree.selection()
        if sel:
            self.details.insert("1.0", self.errors[int(sel[0])]["text"])
        elif not self.errors:
            self.details.insert("1.0", "Kļūdu žurnāls ir tukšs — programmā nav reģistrēta neviena kļūda.")
        else:
            self.details.insert("1.0", "Izvēlieties kļūdu, lai redzētu tās detaļas.")
        self.details.configure(state="disabled")

    def add_task(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        e = self.errors[int(iid)]
        db = self.owner.db
        if db.q("SELECT 1 FROM dev_tasks WHERE error_key=?", (e["key"],)):
            messagebox.showinfo("Kļūdu žurnāls", "Šī kļūda jau ir izstrādes darbu sarakstā.", parent=self)
            return
        text = f"Novērst kļūdu ({show_time(e['time'])}): {e['summary']}"
        if e["place"]:
            text += f"\nVieta: {e['place']}"
        new_id = db.x("INSERT INTO dev_tasks (module, description, created, deadline, done_date, error_key) "
                      "VALUES (?,?,?,?,?,?)", (e["module"], text, date.today().isoformat(), "", "", e["key"]))
        self.refresh()
        self.tree.selection_set(iid)
        self.owner.refresh(select=new_id)
        messagebox.showinfo("Kļūdu žurnāls", f"Kļūda pievienota izstrādes darbu sarakstam (modulis: "
                                             f"{e['module']}).", parent=self)


# --------------------------------------------------------------------------
# One task (new or edit)
# --------------------------------------------------------------------------
class TaskForm(tk.Toplevel):
    def __init__(self, owner, task_id=None):
        super().__init__(owner)
        self.owner, self.task_id = owner, task_id
        self.title("Jauns darbs" if task_id is None else "Darbs")
        self.configure(bg=CREAM, padx=18, pady=14)
        self.transient(owner)
        self.resizable(False, False)
        tk.Label(self, text="Jauns izstrādes darbs" if task_id is None else "Izstrādes darbs",
                 font=("Georgia", 14, "bold"), bg=CREAM, fg=RED).grid(row=0, column=0, columnspan=4,
                                                                    sticky="w", pady=(0, 10))
        self.module = tk.StringVar(value=owner.default_module())
        self.deadline = tk.StringVar()
        self.done = tk.StringVar()
        created = today_text()

        def label(text, r, c=0):
            tk.Label(self, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 8))

        label("Modulis", 1)
        ttk.Combobox(self, textvariable=self.module, values=owner.module_names, state="readonly",
                     width=24).grid(row=1, column=1, sticky="w")
        label("Izveidots", 1, 2)
        self.created_lbl = tk.Label(self, text=created, bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold"))
        self.created_lbl.grid(row=1, column=3, sticky="w")
        label("Kas jādara *", 2)
        self.text = tk.Text(self, width=58, height=5, wrap="word", relief="solid", bd=1, font=("Segoe UI", 10))
        self.text.grid(row=2, column=1, columnspan=3, sticky="ew", pady=4)
        label("Termiņš", 3)
        ttk.Entry(self, textvariable=self.deadline, width=14).grid(row=3, column=1, sticky="w")
        label("Izpildīts", 3, 2)
        done_box = tk.Frame(self, bg=CREAM)
        done_box.grid(row=3, column=3, sticky="w")
        ttk.Entry(done_box, textvariable=self.done, width=14).pack(side="left")
        ttk.Button(done_box, text="Šodien", command=lambda: self.done.set(today_text())).pack(side="left", padx=4)
        tk.Label(self, text="Datumus raksta formā dd.mm.gggg. Termiņš un izpildes datums nav obligāti.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(row=4, column=0, columnspan=4,
                                                                       sticky="w", pady=(4, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(14, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if task_id is not None:
            ttk.Button(btns, text="✖ Dzēst darbu", command=self.delete).pack(side="left")
            module, text, created_iso, deadline, done = owner.db.q(
                "SELECT module, description, created, deadline, done_date FROM dev_tasks WHERE id=?",
                (task_id,))[0]
            self.module.set(module)
            self.text.insert("1.0", text)
            self.created_lbl.configure(text=show_date(created_iso))
            self.deadline.set(show_date(deadline))
            self.done.set(show_date(done))
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Destroy>", self._give_back_grab)
        self.text.focus_set()
        self.grab_set()

    def _give_back_grab(self, event):
        # the task list stays modal after this form closes
        if event.widget is self:
            try:
                self.owner.grab_set()
            except tk.TclError:
                pass

    def save(self):
        text = self.text.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("Trūkst datu", "Uzrakstiet, kas jādara.", parent=self)
            return
        dates = {}
        for key, var, title in (("deadline", self.deadline, "Termiņš"), ("done", self.done, "Izpildīts")):
            value = parse_date(var.get())
            if value is None:
                messagebox.showwarning("Datums", f"{title}: nepareizs datums. Rakstiet formā dd.mm.gggg.",
                                       parent=self)
                return
            dates[key] = value
        db = self.owner.db
        if self.task_id is None:
            new_id = db.x("INSERT INTO dev_tasks (module, description, created, deadline, done_date) "
                          "VALUES (?,?,?,?,?)", (self.module.get(), text, date.today().isoformat(),
                                                 dates["deadline"], dates["done"]))
        else:
            new_id = self.task_id
            db.x("UPDATE dev_tasks SET module=?, description=?, deadline=?, done_date=? WHERE id=?",
                 (self.module.get(), text, dates["deadline"], dates["done"], self.task_id))
        self.owner.refresh(select=new_id)
        self.destroy()

    def delete(self):
        if messagebox.askyesno("Dzēst", "Dzēst šo darbu?", parent=self):
            self.owner.db.x("DELETE FROM dev_tasks WHERE id=?", (self.task_id,))
            self.owner.refresh()
            self.destroy()


# --------------------------------------------------------------------------
# List of tasks
# --------------------------------------------------------------------------
class DevTasksWindow(tk.Toplevel):
    def __init__(self, root, module_names):
        super().__init__(root)
        self.db = Tasks()
        self.module_names = [GENERAL] + list(module_names)
        self.title("Izstrādes darbi")
        self.geometry("900x560")
        self.minsize(720, 400)
        self.configure(bg=CREAM)
        self.transient(root)
        self.protocol("WM_DELETE_WINDOW", self.close)

        head = tk.Frame(self, bg=NAVY)
        head.pack(fill="x")
        tk.Label(head, text="Izstrādes darbi", font=("Georgia", 17, "bold"), bg=NAVY, fg=CREAM).pack(
            side="left", padx=18, pady=10)
        self.summary = tk.Label(head, text="", font=("Segoe UI", 9, "italic"), bg=NAVY, fg=GOLD)
        self.summary.pack(side="left", pady=(14, 8))
        tk.Frame(self, bg=GOLD, height=3).pack(fill="x")

        bottom = tk.Frame(self, bg=CREAM)
        bottom.pack(side="bottom", fill="x", padx=14, pady=10)
        ttk.Button(bottom, text="Aizvērt", style="Accent.TButton", command=self.close).pack(side="right")
        tk.Label(bottom, text="Dubultklikšķis uz darba — rediģēt, ielikt izpildes datumu vai dzēst.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(side="left")

        bar = tk.Frame(self, bg=CREAM)
        bar.pack(fill="x", padx=14, pady=(10, 4))
        ttk.Button(bar, text="＋ Jauns darbs", style="Accent.TButton",
                   command=lambda: TaskForm(self)).pack(side="left")
        ttk.Button(bar, text="✔ Atzīmēt kā izpildītu", command=self.mark_done).pack(side="left", padx=6)
        self.log_btn = ttk.Button(bar, text="⚠ Kļūdu žurnāls", command=lambda: ErrorLogWindow(self))
        self.log_btn.pack(side="left")
        self.f_show = tk.StringVar(value=SHOW_OPEN)
        self.f_module = tk.StringVar(value=ALL)
        mcb = ttk.Combobox(bar, textvariable=self.f_module, values=[ALL] + self.module_names,
                           state="readonly", width=20)
        mcb.pack(side="right")
        tk.Label(bar, text="Modulis:", bg=CREAM, fg=NAVY).pack(side="right", padx=(14, 4))
        scb = ttk.Combobox(bar, textvariable=self.f_show, values=[SHOW_OPEN, SHOW_DONE, SHOW_ALL],
                           state="readonly", width=13)
        scb.pack(side="right")
        tk.Label(bar, text="Rādīt:", bg=CREAM, fg=NAVY).pack(side="right", padx=(0, 4))
        for cb in (mcb, scb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        holder = tk.Frame(self, bg=CREAM)
        holder.pack(fill="both", expand=True, padx=14, pady=4)
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in COLUMNS], show="headings")
        for key, title, width in COLUMNS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, minwidth=60, anchor="w", stretch=key == "text")
        self.tree.tag_configure("late", foreground=RED)
        self.tree.tag_configure("soon", foreground=AMBER)
        self.tree.tag_configure("done", foreground=GREY)
        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self.open_task)
        self.bind("<Escape>", lambda e: self.close())
        self.refresh()
        self.grab_set()

    def default_module(self):
        m = self.f_module.get()
        return m if m in self.module_names else GENERAL

    def refresh(self, select=None):
        today = date.today().isoformat()
        rows = self.db.q("SELECT id, module, description, created, deadline, done_date FROM dev_tasks")
        open_count = sum(1 for r in rows if not r[5])
        late_count = sum(1 for r in rows if not r[5] and r[4] and r[4] < today)
        added = {r[0] for r in self.db.q("SELECT error_key FROM dev_tasks WHERE error_key != ''")}
        new_errors = sum(1 for e in read_error_log(self.module_names) if e["key"] not in added)
        self.log_btn.configure(text="⚠ Kļūdu žurnāls" + (f" ({new_errors})" if new_errors else ""))
        self.summary.configure(text=f"neizpildīti: {open_count}" + (f"  ·  nokavēti: {late_count}"
                                                                    if late_count else ""))
        show, module = self.f_show.get(), self.f_module.get()
        shown = []
        for r in rows:
            done = bool(r[5])
            if (show == SHOW_OPEN and done) or (show == SHOW_DONE and not done):
                continue
            if module != ALL and r[1] != module:
                continue
            shown.append(r)
        # open tasks first, nearest deadline first (no deadline last), then newest
        shown.sort(key=lambda r: (bool(r[5]), r[4] == "", r[4] or "", r[5] or ""), reverse=False)
        if show == SHOW_DONE:
            shown.sort(key=lambda r: r[5], reverse=True)
        self.tree.delete(*self.tree.get_children())
        for tid, mod, text, created, deadline, done in shown:
            if done:
                tag = "done"
            elif deadline and deadline < today:
                tag = "late"
            elif deadline and deadline == today:
                tag = "soon"
            else:
                tag = ""
            self.tree.insert("", "end", iid=str(tid), tags=(tag,), values=(
                mod, " ".join(text.split()), show_date(created), show_date(deadline), show_date(done)))
        if select is not None and self.tree.exists(str(select)):
            self.tree.selection_set(str(select))
            self.tree.see(str(select))

    def open_task(self, event):
        iid = self.tree.identify_row(event.y)
        if iid:
            TaskForm(self, int(iid))

    def mark_done(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties darbu sarakstā.", parent=self)
            return
        tid = int(sel[0])
        if self.db.q("SELECT done_date FROM dev_tasks WHERE id=?", (tid,))[0][0]:
            messagebox.showinfo("Izpildīts", "Šis darbs jau ir atzīmēts kā izpildīts. Izpildes datumu var "
                                            "mainīt, atverot darbu ar dubultklikšķi.", parent=self)
            return
        self.db.x("UPDATE dev_tasks SET done_date=? WHERE id=?", (date.today().isoformat(), tid))
        self.refresh(select=tid)

    def close(self):
        self.db.close()
        self.destroy()


def show(root, module_names):
    return DevTasksWindow(root, module_names)
