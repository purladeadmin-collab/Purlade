#!/usr/bin/env python3
"""
Pūrlāde — modulis "Jaunrades pūrs" (deju apraksti un dejas zīmējumi)

Šeit raksta jaunrades deju aprakstus tādā izskatā, kā tos publicē deju krājumos:
  * galvene — dejas nosaukums, sastāvs (“Deja 8 pāriem”), horeogrāfs / apraksta autors, mūzika;
  * ievadteksts — dejas raksturs, sižets, izmantotie soļi, pirmais iestudējums, gājienu skaits, taktsmērs;
  * gājieni — virsraksts, variants, mūzikas daļas un taktis “(I, II / 16 t. x 2)”, tad rindas “1. – 4. t. | darbības”;
    starp rindām var būt skaitījums (“Viens”, “Divi” …), piezīme vidū un dejas zīmējums;
  * kustību apraksts — katra kustība ar mūzikas daļu, taktsmēru, kas to izpilda un cik taktīs, sākuma stāvokli
    un rindām pa taktīm;
  * zīmējumi — skatuves plāns ar dejotājiem pēc “Latviešu dejas pamatu” (LNKC, 2016) apzīmējumiem: meita — pusloks
    (U), puisis — ķīlītis (V), apaļā / smailā puse ir seja; kustības virziens — bulta, tālāka virzīšanās —
    pārtraukta bulta, kustība turp un atpakaļ, griešanās uz vietas un griežoties pa ceļam, dejas ceļš (DCV),
    satvērieni starp dejotājiem, gatavi grupējumi (aplis, dārziņš, rinda, kolonna, gatve, četrstūris …).
Aprakstu var eksportēt PDF failā (to izveido datorā esošā Microsoft Edge vai Google Chrome; ja to nav — apraksts
atveras pārlūkā, kur to saglabā kā PDF ar Ctrl+P).

Ar Deju pūru apraksti pagaidām nav saistīti.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/jaunrades_purs.py
"""

import copy
import html
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import traceback
import webbrowser
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, console_is_own,
                               set_console_visible, _norm, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, console_is_own,
                        set_console_visible, _norm, CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE)

PROGRAM_NAME = "Jaunrades pūrs"
APP_VERSION = "0.1.7"
MODULE_KEY = "jaunrades_purs"
MODULE_COLOUR = "#2F7A9A"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Jaunrades deju apraksti ar dejas zīmējumiem; eksports PDF failā",
    "letter": "J",
    "color": MODULE_COLOUR,
}

LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = (izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED,
                                                izskats.SELECTED)
OK_BG, OK_FG, WARN_BG, WARN_FG = izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL

STATUS_DRAFT = "Melnraksts"
STATUS_READY = "Gatavs"
STATUSES = [STATUS_DRAFT, STATUS_READY]
STATUS_COLOURS = {STATUS_DRAFT: (WARN_BG, WARN_FG), STATUS_READY: (OK_BG, OK_FG)}

TAB_ALL, TAB_DRAFT, TAB_READY = "all", "draft", "ready"
TAB_STATUSES = {TAB_ALL: tuple(STATUSES), TAB_DRAFT: (STATUS_DRAFT,), TAB_READY: (STATUS_READY,)}

ORDINALS = ["Pirmais", "Otrais", "Trešais", "Ceturtais", "Piektais", "Sestais", "Septītais", "Astotais", "Devītais",
            "Desmitais", "Vienpadsmitais", "Divpadsmitais", "Trīspadsmitais", "Četrpadsmitais", "Piecpadsmitais",
            "Sešpadsmitais", "Septiņpadsmitais", "Astoņpadsmitais", "Deviņpadsmitais", "Divdesmitais"]
PART_TITLES = ["Ievads"] + [f"{o} gājiens" for o in ORDINALS] + ["Nobeigums"]
METERS = ["2/4", "3/4", "4/4", "3/8", "6/8", "5/4", "5/8", "7/8"]
PERFORMERS = ["", "puiši", "meitas", "pāri", "visi dejotāji"]

ROW_TAKTS, ROW_COUNT, ROW_NOTE, ROW_DRAWING = "t", "s", "p", "z"
ROW_KINDS = {ROW_TAKTS: "Taktis", ROW_COUNT: "Skaitījums", ROW_NOTE: "Piezīme", ROW_DRAWING: "Zīmējums"}


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS creative_works (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT '',
    status TEXT DEFAULT '',
    data TEXT DEFAULT '',
    created_at TEXT DEFAULT '',
    updated_at TEXT DEFAULT '',
    updated_by TEXT DEFAULT ''
);
"""


class Database:
    def __init__(self, path):
        self.path = path
        self.con = connect_db(path)
        self.con.executescript(SCHEMA)
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur

    # ---- works -----------------------------------------------------------------
    def works(self):
        """[dict(id, title, status, updated_at, updated_by, data)] — newest change first."""
        out = []
        for row in self.q("SELECT id, title, status, data, created_at, updated_at, updated_by FROM creative_works"):
            r = dict(zip(("id", "title", "status", "data", "created_at", "updated_at", "updated_by"), row))
            for k in ("title", "status", "data", "created_at", "updated_at", "updated_by"):
                r[k] = r[k] or ""
            if r["status"] not in STATUSES:
                r["status"] = STATUS_DRAFT
            r["work"] = parse_work(r["data"], r["title"])
            out.append(r)
        out.sort(key=lambda r: r["updated_at"], reverse=True)
        return out

    def load(self, wid):
        rows = self.q("SELECT title, status, data, updated_at, updated_by FROM creative_works WHERE id=?", (wid,))
        if not rows:
            return None
        title, status, data, updated_at, updated_by = rows[0]
        work = parse_work(data or "", title or "")
        work["status"] = status if status in STATUSES else STATUS_DRAFT
        return {"work": work, "updated_at": updated_at or "", "updated_by": updated_by or ""}

    def stamp(self, wid):
        rows = self.q("SELECT updated_at, updated_by FROM creative_works WHERE id=?", (wid,))
        return (rows[0][0] or "", rows[0][1] or "") if rows else None

    def create(self, work):
        now, who = now_text(), current_user_name()
        cur = self.x("INSERT INTO creative_works (title, status, data, created_at, updated_at, updated_by) "
                     "VALUES (?, ?, ?, ?, ?, ?)",
                     (work.get("title", ""), work.get("status", STATUS_DRAFT), dump_work(work), now, now, who))
        return cur.lastrowid, now

    def save(self, wid, work):
        now = now_text()
        self.x("UPDATE creative_works SET title=?, status=?, data=?, updated_at=?, updated_by=? WHERE id=?",
               (work.get("title", ""), work.get("status", STATUS_DRAFT), dump_work(work), now, current_user_name(),
                wid))
        return now

    def delete(self, wid):
        self.x("DELETE FROM creative_works WHERE id=?", (wid,))


def now_text():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def show_stamp(text):
    """'2026-11-07 14:05:33' -> '07.11.2026 14:05'."""
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M:%S").strftime("%d.%m.%Y %H:%M")
    except (ValueError, TypeError):
        return text or ""


def current_user_name():
    try:
        user = piekluve.current().user
        return user.name or user.email or ""
    except Exception:
        return ""


def can_edit():
    try:
        return piekluve.current().can_edit(MODULE_KEY)
    except Exception:
        return True


# --------------------------------------------------------------------------
# The description (one JSON document per dance)
# --------------------------------------------------------------------------
def new_work(title=""):
    return {"title": title, "status": STATUS_DRAFT, "lineup": "", "author": "", "music": "", "intro": "",
            "notes": "", "parts": [], "moves": [], "drawings": [], "seq": 0}


def parse_work(data, title=""):
    work = new_work(title)
    try:
        stored = json.loads(data) if data else {}
    except ValueError:
        stored = {}
    if isinstance(stored, dict):
        work.update(stored)
    if title and not work.get("title"):
        work["title"] = title
    for key in ("parts", "moves", "drawings"):
        if not isinstance(work.get(key), list):
            work[key] = []
    seq = int(work.get("seq") or 0)
    for item in work["parts"] + work["moves"] + work["drawings"]:
        if not isinstance(item.get("id"), int):
            seq += 1
            item["id"] = seq
        seq = max(seq, item["id"])
        if "rows" in item or item in work["parts"] or item in work["moves"]:
            item.setdefault("rows", [])
    for d in work["drawings"]:
        d.setdefault("els", [])
        d.setdefault("no", "")
        d.setdefault("caption", "")
        d.setdefault("frame", True)
    work["seq"] = seq
    return work


def dump_work(work):
    return json.dumps(work, ensure_ascii=False, sort_keys=True)


def next_id(work):
    work["seq"] = int(work.get("seq") or 0) + 1
    return work["seq"]


def new_part(work):
    used = len([p for p in work["parts"] if _norm(p.get("title", "")) != "ievads"])
    if not work["parts"]:
        title = "Ievads"
    else:
        title = f"{ORDINALS[used]} gājiens" if used < len(ORDINALS) else f"{used + 1}. gājiens"
    return {"id": next_id(work), "title": title, "variant": "", "music": "", "rows": [
        {"k": ROW_TAKTS, "takts": "1. – 4. t.", "text": ""}]}


def new_move(work):
    return {"id": next_id(work), "music": "I", "meter": "2/4", "who": "", "bars": "", "start": "",
            "rows": [{"k": ROW_TAKTS, "takts": "1. t.", "text": ""}]}


def move_title(work, move):
    try:
        return f"{work['moves'].index(move) + 1}. kustība"
    except ValueError:
        return "kustība"


def next_drawing_no(work):
    best = 0
    for d in work["drawings"]:
        m = re.match(r"\s*(\d+)", str(d.get("no", "")))
        if m:
            best = max(best, int(m.group(1)))
    return str(best + 1)


def new_drawing(work, els=None, frame=True):
    return {"id": next_id(work), "no": next_drawing_no(work), "caption": "", "frame": frame,
            "els": copy.deepcopy(els) if els else []}


def drawing_label(d):
    no = str(d.get("no", "")).strip()
    text = f"{no}. zīm." if no else "zīm."
    return text + (f" {d['caption'].strip()}" if (d.get("caption") or "").strip() else "")


def drawing_by_id(work, did):
    return next((d for d in work["drawings"] if d.get("id") == did), None)


def placed_drawings(work):
    """Ids of the drawings that stand in the text (rows of the kind “Zīmējums”)."""
    ids = set()
    for item in work["parts"] + work["moves"]:
        for row in item.get("rows", []):
            if row.get("k") == ROW_DRAWING and row.get("zid") is not None:
                ids.add(row.get("zid"))
    return ids


TAKTS_ONE = re.compile(r"^\s*(\d+)\s*\.?\s*(?:t\.?)?\s*$", re.I)
TAKTS_RANGE = re.compile(r"^\s*(\d+)\s*\.?\s*[-–—]\s*(\d+)\s*\.?\s*(?:t\.?)?\s*$", re.I)


def normalize_takts(text):
    """'1-4' -> '1. – 4. t.', '9' -> '9. t.'; anything else (Viens, “Divi” …) stays as written."""
    m = TAKTS_RANGE.match(text or "")
    if m:
        return f"{int(m.group(1))}. – {int(m.group(2))}. t."
    m = TAKTS_ONE.match(text or "")
    if m:
        return f"{int(m.group(1))}. t."
    return (text or "").strip()


def suggest_next_takts(previous):
    """After '1. – 4. t.' -> '5. – 8. t.'; after '9. t.' -> '10. t.'; otherwise ''."""
    m = TAKTS_RANGE.match(previous or "")
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        return f"{b + 1}. – {b + 1 + (b - a)}. t."
    m = TAKTS_ONE.match(previous or "")
    if m:
        return f"{int(m.group(1)) + 1}. t."
    return ""


def move_lines(move):
    """The centred lines under a movement's title."""
    lines = []
    music = (move.get("music") or "").strip()
    if music:
        lines.append(music if music.lower().startswith("mūzikas") else f"Mūzikas {music} daļa")
    meter = (move.get("meter") or "").strip()
    if meter:
        lines.append(f"Mūzikas taktsmērs {meter}")
    who = (move.get("who") or "").strip()
    bars = (move.get("bars") or "").strip()
    if bars and bars.isdigit():
        bars = f"{bars} t."
    if who or bars:
        lines.append(" ".join(x for x in ("Kustību izpilda", who, bars) if x))
    return lines


def start_text(move):
    text = (move.get("start") or "").strip()
    if text and not _norm(text).startswith("sakuma stavoklis"):
        text = "Sākuma stāvoklis – " + text
    return text


# --------------------------------------------------------------------------
# Drawings — the elements and their geometry
# --------------------------------------------------------------------------
# Model coordinates: the stage is STAGE_W x STAGE_H, the audience is at the bottom (priekšplāns).
# Elements (dicts with an "id"):
#   fig   — g "F" (meita, U) / "M" (puisis, V), x, y, a (the face looks: 0 down to the audience, 90 to the left,
#           180 to the back, 270 to the right — degrees clockwise on the screen), n (number shown at the back)
#   arrow — pts [[x, y], …], style solid / dashed / twoway, heads end / both / none, curve (bool),
#           turns "" / R / L (small circles along the way: turning while moving)
#   turn  — x, y, r, dir R / L (turning on the spot)
#   ring  — x, y, r, dir DCV / PRET (dejas ceļš)
#   grip  — a, b (ids of two figures), kind (GRIP_TYPES), flip (the sign on the other side)
#   fig.h — "sanos": the free hands on the hips (dots at both sides of the figure)
#   text  — x, y, s, size
STAGE_W, STAGE_H = 1000, 640
FIG_R = 16
FIG_W = 3.0
LINE_W = 1.7

ARROW_STYLES = [("solid", "Nepārtraukta — kustības virziens"), ("dashed", "Pārtraukta — tālākā virzīšanās"),
                ("twoway", "Turp un atpakaļ")]
ARROW_HEADS = [("end", "Bulta galā"), ("both", "Bultas abos galos"), ("none", "Bez bultas (līnija)")]
ARROW_TURNS = [("", "Negriežas"), ("R", "Griežoties pa labi"), ("L", "Griežoties pa kreisi")]
TURN_DIRS = [("R", "Pa labi"), ("L", "Pa kreisi")]
RING_DIRS = [("DCV", "Pa dejas ceļu (DCV)"), ("PRET", "Pret dejas ceļu")]
# Satvērieni un aptvērieni (Latviešu dejas pamati, 24.–52. zīm.): key, name, group, pose for the legend
#   pose: side — blakus, seja vienā virzienā; back — blakus, ar muguru pret skatītājiem; opp — blakus, sejas pretējos
#         virzienos; face — viens otram pretī; follow — viens aiz otra
GRIP_GROUPS = ["Vaļējie satvērieni", "Slēgtie satvērieni", "Slēgtie aptvērieni", "Vaļējie aptvērieni"]
GRIP_TYPES = [
    ("vajejais", "Vaļējais satvēriens", 0, "side"),
    ("vartini", "Vaļējais, rokas paceltas (vārtiņi)", 0, "side"),
    ("sasveicinasanas", "Sasveicināšanās satvēriens", 0, "face"),
    ("vija", "Vijas satvēriens (ar sadotām plaukstām)", 0, "opp"),
    ("elkonu", "Elkoņu satvēriens", 0, "opp"),
    ("pastaigas", "Pastaigas satvēriens", 0, "side"),
    ("slegtais", "Slēgtais satvēriens", 1, "face"),
    ("slegtais_vartini", "Slēgtais, rokas paceltas (vārtiņi)", 1, "face"),
    ("sajugsanas", "Sajūgšanās (slēgtais aiz muguras)", 1, "follow"),
    ("galopa", "Sānis stieptu roku (galopa) satvēriens", 1, "face"),
    ("krustiskais", "Krustiskais satvēriens", 1, "side"),
    ("krustiskais_aiz", "Krustiskais satvēriens aiz muguras", 1, "back"),
    ("augsupceltu", "Augšupceltu roku satvēriens", 1, "side"),
    ("virs_elkoniem", "Satvēriens virs elkoņiem", 1, "face"),
    ("virs_elkoniem_sanis", "Virs elkoņiem ar sānis sadotām rokām", 1, "face"),
    ("aptv_slegtais", "Slēgtais (vidukļa un plecu) aptvēriens", 2, "face"),
    ("aptv_sanis", "Slēgtais aptvēriens ar sānis sadotām rokām", 2, "face"),
    ("aptv_kreiso_sanos", "Slēgtais aptvēriens ar kreiso roku sānos", 2, "face"),
    ("aptv_vidukla", "Slēgtais vidukļa aptvēriens", 2, "face"),
    ("aptv_vidukla_sanos", "Slēgtais vidukļa aptvēriens ar kreisajām rokām sānos", 2, "face"),
    ("aptv_valejais", "Vaļējais (vidukļa un plecu) aptvēriens", 3, "back"),
    ("aptv_valejais_vidukla", "Vaļējais vidukļa aptvēriens", 3, "back"),
    ("aptv_kreisajam", "Aptvēriens ar sadotām kreisajām rokām", 3, "side"),
    ("aptv_plecu", "Plecu aptvēriens", 3, "opp"),
]
GRIP_NAMES = {k: n for k, n, _g, _p in GRIP_TYPES}
OLD_GRIPS = {"single": "vajejais", "double": "slegtais"}   # Jaunrades pūrs v0.1.0
GRIP_KINDS = [(k, n) for k, n, _g, _p in GRIP_TYPES]
# Roku stāvokļi (Latviešu dejas pamati, 20.–23. zīm. un apraksti): key, name. Zīmes ar grāmatā dotām zīmēm: roka
# pacelta (21.), rokas sakrustotas pret krūtīm (22.), rokas sānos (23.); pārējām — tādā pašā stilā.
HANDS = [("", "Rokas gar sāniem"), ("prieksa", "Rokas priekšā (I pozīcija)"), ("sanis", "Rokas sānis (II pozīcija)"),
         ("augsa", "Rokas augšā (III pozīcija)"), ("pacelta_l", "Labā roka pacelta"),
         ("pacelta_k", "Kreisā roka pacelta"), ("krutis", "Rokas sakrustotas pret krūtīm"),
         ("sanos", "Rokas sānos"), ("dures", "Rokas sānos dūrēs"), ("aiz", "Rokas aiz muguras"),
         ("svarki", "Rokas pie svārkiem")]
HAND_NAMES = {k: n for k, n in HANDS}
HAND_W = 1.7
PALETTE_GROUPS = [(f"g{i}", g) for i, g in enumerate(GRIP_GROUPS)] + [("hands", "Roku stāvokļi")]
FACINGS = [(135, "↖"), (180, "↑"), (225, "↗"), (90, "←"), (None, ""), (270, "→"), (45, "↙"), (0, "↓"), (315, "↘")]


def rot(px, py, a):
    r = math.radians(a)
    c, s = math.cos(r), math.sin(r)
    return px * c - py * s, px * s + py * c


def facing_to(dx, dy):
    """Angle that makes a figure look along (dx, dy)."""
    if abs(dx) < 1e-9 and abs(dy) < 1e-9:
        return 0
    return math.degrees(math.atan2(-dx, dy)) % 360


def snap_angle(a, step=45):
    return (round(a / step) * step) % 360


def catmull(points, steps=10):
    """A smooth line through the points."""
    if len(points) < 3:
        return [tuple(p) for p in points]
    pts = [points[0]] + list(points) + [points[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for k in range(steps):
            t = k / steps
            t2, t3 = t * t, t * t * t
            x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                       + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                       + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            out.append((x, y))
    out.append(tuple(points[-1]))
    return out


def _unit(dx, dy):
    d = math.hypot(dx, dy)
    return (dx / d, dy / d) if d > 1e-9 else (0.0, 1.0)


def _head(tip, direction, length=13.0, width=5.0):
    ux, uy = _unit(*direction)
    bx, by = tip[0] - ux * length, tip[1] - uy * length
    return ("poly", [tip, (bx - uy * width, by + ux * width), (bx + uy * width, by - ux * width)],
            {"fill": True, "w": 1.0})


def _end_direction(line, from_end=True):
    """Direction of the line at its end (or start), looked over a few units for a steady head."""
    pts = line if from_end else list(reversed(line))
    tip = pts[-1]
    for p in reversed(pts[:-1]):
        if math.hypot(tip[0] - p[0], tip[1] - p[1]) >= 6:
            return tip[0] - p[0], tip[1] - p[1]
    if len(pts) >= 2:
        return tip[0] - pts[-2][0], tip[1] - pts[-2][1]
    return 0.0, 1.0


def _offset(line, dist):
    """The line moved sideways by dist (to the left of the way when dist > 0, on the screen)."""
    out = []
    n = len(line)
    for i, (x, y) in enumerate(line):
        ax, ay = line[max(0, i - 1)]
        bx, by = line[min(n - 1, i + 1)]
        ux, uy = _unit(bx - ax, by - ay)
        out.append((x + uy * dist, y - ux * dist))
    return out


def _trim(line, start=0.0, end=0.0):
    """The line shortened at the start and the end (so that heads do not touch figures)."""
    def cut(pts, amount):
        while amount > 0 and len(pts) >= 2:
            (x0, y0), (x1, y1) = pts[0], pts[1]
            seg = math.hypot(x1 - x0, y1 - y0)
            if seg > amount:
                f = amount / seg
                pts = [(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f)] + pts[1:]
                break
            amount -= seg
            pts = pts[1:]
        return pts
    pts = cut(list(line), start)
    return list(reversed(cut(list(reversed(pts)), end)))


def _circle(cx, cy, r, n=18):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def fig_shape(g, x, y, a, r=FIG_R):
    """Polyline of the figure: U (meita) or V (puisis); the round / pointed side is the face."""
    if g == "F":
        local = [(-r, -0.75 * r), (-r, 0.0)]
        local += [(r * math.cos(t), r * math.sin(t)) for t in [math.pi - i * math.pi / 14 for i in range(15)]]
        local += [(r, -0.75 * r)]
    else:
        local = [(-0.95 * r, -0.85 * r), (0.0, 0.95 * r), (0.95 * r, -0.85 * r)]
    return [(x + px, y + py) for px, py in (rot(lx, ly, a) for lx, ly in local)]


def pair_partner(fig, figs):
    """The other dancer of the pair (figures with the same "pg"), or None."""
    pg = fig.get("pg")
    if pg is None:
        return None
    return next((f for f in figs.values() if f is not fig and f.get("pg") == pg and f.get("id") != fig.get("id")),
                None)


def pair_label_xy(f1, f2):
    """Where the pair's number stands: in the middle between the two, behind their backs (above when they face
    each other)."""
    mx, my = (float(f1["x"]) + float(f2["x"])) / 2, (float(f1["y"]) + float(f2["y"])) / 2
    bx = by = 0.0
    for f in (f1, f2):
        r = math.radians(float(f.get("a", 0)))
        bx += math.sin(r)
        by += -math.cos(r)
    d = math.hypot(bx, by)
    if d < 0.6:
        bx, by, d = 0.0, -1.0, 1.0
    return mx + bx / d * 2.05 * FIG_R, my + by / d * 2.05 * FIG_R


def element_prims(el, figs):
    """Primitives of one element in model units: ("poly", points, opts) and ("text", x, y, text, size)."""
    t = el.get("t")
    out = []
    if t == "fig":
        x, y, a = float(el.get("x", 0)), float(el.get("y", 0)), float(el.get("a", 0))
        out.append(("poly", fig_shape(el.get("g", "F"), x, y, a), {"w": FIG_W}))
        out += hand_prims(el.get("h", ""), x, y, a)
        label = str(el.get("n", "") or "").strip()
        partner = pair_partner(el, figs)
        if label and partner is not None and str(partner.get("n", "") or "").strip() == label:
            if el.get("id", 0) < partner.get("id", 0):      # the pair's number — once, in the middle above it
                out.append(("text",) + pair_label_xy(el, partner) + (label, 18))
        elif label:
            lx, ly = rot(0, -2.05 * FIG_R, a)
            out.append(("text", x + lx, y + ly, label, 18))
    elif t == "arrow":
        pts = [tuple(p) for p in el.get("pts", [])]
        if len(pts) < 2:
            return out
        line = catmull(pts) if el.get("curve") and len(pts) >= 3 else pts
        style, heads = el.get("style", "solid"), el.get("heads", "end")
        if style == "twoway":
            a_line, b_line = _offset(line, 4.5), _offset(line, -4.5)
            out.append(("poly", a_line, {"w": LINE_W, "dash": True}))
            out.append(_head(a_line[-1], _end_direction(a_line)))
            out.append(("poly", b_line, {"w": LINE_W}))
            out.append(_head(b_line[0], _end_direction(b_line, from_end=False)))
        else:
            out.append(("poly", line, {"w": LINE_W, "dash": style == "dashed"}))
            if heads in ("end", "both"):
                out.append(_head(line[-1], _end_direction(line)))
            if heads == "both":
                out.append(_head(line[0], _end_direction(line, from_end=False)))
        turns = el.get("turns", "")
        if turns in ("R", "L"):
            side = 1 if turns == "R" else -1   # pa labi — circles on the left of the way (on the screen)
            walked, mark = 0.0, 22.0
            for (x0, y0), (x1, y1) in zip(line, line[1:]):
                seg = math.hypot(x1 - x0, y1 - y0)
                while seg > 0 and walked + seg >= mark:
                    f = (mark - walked) / seg
                    px, py = x0 + (x1 - x0) * f, y0 + (y1 - y0) * f
                    ux, uy = _unit(x1 - x0, y1 - y0)
                    cx, cy = px + uy * 11 * side, py - ux * 11 * side
                    out.append(("poly", _circle(cx, cy, 6.0, 14), {"w": 1.3}))
                    mark += 34.0
                walked += seg
    elif t == "turn":
        cx, cy, r = float(el.get("x", 0)), float(el.get("y", 0)), float(el.get("r", 24))
        sign = 1 if el.get("dir", "R") == "R" else -1   # R: clockwise on the screen (seen from above)
        start = -150.0
        arc = [(cx + r * math.cos(math.radians(start + sign * i * 290 / 24)),
                cy + r * math.sin(math.radians(start + sign * i * 290 / 24))) for i in range(25)]
        out.append(("poly", arc, {"w": LINE_W}))
        out.append(_head(arc[-1], _end_direction(arc), 10, 4.5))
    elif t == "ring":
        cx, cy, r = float(el.get("x", 0)), float(el.get("y", 0)), float(el.get("r", 80))
        out.append(("poly", _circle(cx, cy, r, 48), {"w": LINE_W}))
        dcv = el.get("dir", "DCV") == "DCV"   # pa dejas ceļu = pretēji pulksteņa rādītājam
        for ang in (-135, 45):
            th = math.radians(ang)
            px, py = cx + r * math.cos(th), cy + r * math.sin(th)
            tx, ty = (math.sin(th), -math.cos(th)) if dcv else (-math.sin(th), math.cos(th))
            out.append(_head((px, py), (tx, ty), 12, 5))
    elif t == "grip":
        a, b = figs.get(el.get("a")), figs.get(el.get("b"))
        if a is None or b is None:
            return out
        out += grip_prims(el, a, b)
    elif t == "text":
        out.append(("text", float(el.get("x", 0)), float(el.get("y", 0)), str(el.get("s", "")),
                    int(el.get("size", 13) or 13)))
    return out


def _dot(x, y, r=3.4):
    return ("poly", _circle(x, y, r, 12), {"fill": True, "w": 1.0})


def hand_prims(kind, x, y, a):
    """The sign of the free hands around one figure. Local: +y — the face, -x — the dancer's right hand.
    Only straight lines along and across the figure (as in the book), dots and small rings."""
    if not kind:
        return []
    r = FIG_R
    out = []

    def P(lx, ly):
        px, py = rot(lx, ly, a)
        return x + px, y + py

    def line(*pts):
        out.append(("poly", [P(*q) for q in pts], {"w": HAND_W}))

    def dot(lx, ly):
        out.append(_dot(*P(lx, ly)))

    def ring(lx, ly, rr=3.6):
        cx, cy = P(lx, ly)
        out.append(("poly", _circle(cx, cy, rr, 16), {"w": 1.3}))
    side = 1.55 * r                      # where the hands are beside the body
    if kind == "prieksa":                # I — straight forward
        for sx in (-1, 1):
            line((sx * 0.6 * r, 0.75 * r), (sx * 0.6 * r, 1.75 * r))
            dot(sx * 0.6 * r, 1.75 * r)
    elif kind == "sanis":                # II — straight to the sides
        for sx in (-1, 1):
            line((sx * 1.15 * r, -0.3 * r), (sx * 2.15 * r, -0.3 * r))
            dot(sx * 2.15 * r, -0.3 * r)
    elif kind == "augsa":                # III — to the sides, open rings (raised)
        for sx in (-1, 1):
            line((sx * 1.15 * r, -0.3 * r), (sx * 1.85 * r, -0.3 * r))
            ring(sx * (1.85 * r + 3.6), -0.3 * r)
    elif kind in ("pacelta_l", "pacelta_k"):
        sx = -1 if kind == "pacelta_l" else 1
        dot(-sx * side, -0.1 * r)        # the other hand on the hip
        line((sx * 1.15 * r, -0.85 * r), (sx * 2.2 * r, -0.85 * r), (sx * 2.2 * r, -1.45 * r))
    elif kind == "krutis":
        cy, d = 1.6 * r, 0.32 * r
        line((-d, cy - d), (d, cy + d))
        line((d, cy - d), (-d, cy + d))
    elif kind == "sanos":
        for sx in (-1, 1):
            dot(sx * side, -0.1 * r)
    elif kind == "dures":
        for sx in (-1, 1):
            cx, cy = sx * (side + 0.5), -0.1 * r
            q = 3.3
            out.append(("poly", [P(cx - q, cy - q), P(cx + q, cy - q), P(cx + q, cy + q), P(cx - q, cy + q)],
                        {"fill": True, "w": 1.0}))
    elif kind == "aiz":
        line((-0.55 * r, -1.55 * r), (0.55 * r, -1.55 * r))
        for sx in (-1, 1):
            dot(sx * 0.55 * r, -1.55 * r)
    elif kind == "svarki":
        for sx in (-1, 1):
            line((sx * 1.15 * r, 0.35 * r), (sx * 1.75 * r, 0.35 * r))
            ring(sx * (1.75 * r + 3.6), 0.35 * r)
    return out


def hand_example(kind):
    return [{"id": 1, "t": "fig", "g": "F" if kind == "svarki" else "M", "x": 0, "y": 0, "a": 0, "h": kind}]


def grip_prims(el, a, b):
    """The sign of a grip / hold between two figures (as in “Latviešu dejas pamati”).
    Local coordinates: t — 0 at the first dancer, 1 at the second; s — units sideways, positive towards the dancers'
    backs (with the dancers facing the audience: upwards on the drawing)."""
    ax, ay, bx, by = float(a["x"]), float(a["y"]), float(b["x"]), float(b["y"])
    dist = math.hypot(bx - ax, by - ay)
    if dist < 1:
        return []
    ux, uy = (bx - ax) / dist, (by - ay) / dist
    nx, ny = -uy, ux
    back = 0.0
    for f in (a, b):   # where the backs are
        r = math.radians(float(f.get("a", 0)))
        back += (math.sin(r) * nx - math.cos(r) * ny)
    if abs(back) < 0.3:
        back = -ny          # facing each other: “above” on the drawing
    if back < 0:
        nx, ny = -nx, -ny
    if el.get("flip"):
        nx, ny = -nx, -ny
    def reach(f, cx, cy, sign):
        """How far the figure's sign reaches towards the other dancer (on the line between them)."""
        best = 0.0
        for px, py in fig_shape(f.get("g", "F"), cx, cy, float(f.get("a", 0))):
            along = ((px - cx) * ux + (py - cy) * uy) * sign
            if abs((px - cx) * nx + (py - cy) * ny) <= FIG_R * 0.55:
                best = max(best, along)
        return best or FIG_R * 0.6
    ea = min(0.45, (reach(a, ax, ay, 1) + 4) / dist)          # where the first figure ends (t)
    eb = min(0.45, (reach(b, bx, by, -1) + 4) / dist)         # … and where the second begins (from its side)
    w = 1.7

    def P(t, s):
        return (ax + ux * dist * t + nx * s, ay + uy * dist * t + ny * s)

    def line(*pts):
        return ("poly", [P(t, s) for t, s in pts], {"w": w})

    def dot(t, s):
        return _dot(*P(t, s))
    kind = OLD_GRIPS.get(el.get("kind"), el.get("kind") or "vajejais")
    m = (ea + 1 - eb) / 2                     # the middle of the free space between the two signs
    r = FIG_R
    lo, hi = ea * 0.55, 1 - eb * 0.55        # a little into the figures (holds)
    out = []

    def bridge(s1, s2, t1=None, t2=None):
        """⊓: up from both figures to s2, across, (dot in the middle added by the caller)."""
        t1 = ea if t1 is None else t1
        t2 = 1 - eb if t2 is None else t2
        return line((t1, s1), (t1, s2), (t2, s2), (t2, s1))

    def cross(cs, half_t, half_s):
        return [line((m - half_t, cs - half_s), (m + half_t, cs + half_s)),
                line((m - half_t, cs + half_s), (m + half_t, cs - half_s))]

    def bars(gap, t1=lo, t2=hi, ticks=False):
        res = []
        for sv in (gap, -gap):
            res.append(line((t1, sv), (t2, sv)))
            if ticks:   # short ends turned inwards (hands on the elbows)
                res.append(line((t1, sv), (t1, sv * 0.35)))
                res.append(line((t2, sv), (t2, sv * 0.35)))
        return res
    tick = 6.0 / dist                         # 6 units along the pair, as t
    if kind == "vajejais":
        out += [line((ea, 0), (1 - eb, 0)), dot(m, 0)]
    elif kind == "vartini":
        out += [bridge(0, 15), dot(m, 15)]
    elif kind == "sasveicinasanas":
        out += [line((ea, 0), (1 - eb, 0)), line((m, -7), (m, 7)), dot(m, 0)]
    elif kind == "vija":
        out += [line((m, -11), (m, 11)), dot(m, 11)]
    elif kind == "elkonu":
        out += cross(0, 6.5 / dist, 6.5)
    elif kind == "pastaigas":
        out += [line((m - tick, 0), (m - tick, 7), (m + tick, 7), (m + tick, 0))]
    elif kind in ("slegtais", "sajugsanas"):
        out += [line((ea, 6), (1 - eb, 6)), line((ea, -6), (1 - eb, -6)), dot(m, 6), dot(m, -6)]
    elif kind == "slegtais_vartini":
        out += [bridge(4, 16), bridge(-4, -16), dot(m, 16), dot(m, -16)]
    elif kind == "galopa":
        out += [bridge(r * 0.6, 21, ea * 0.7, 1 - eb * 0.7), bridge(-r * 0.6, -21, ea * 0.7, 1 - eb * 0.7),
                dot(m, 21), dot(m, -21)]
    elif kind == "krustiskais":
        out += cross(0, (1 - eb - ea) / 2, 8)
    elif kind == "krustiskais_aiz":
        out += cross(r + 7, 0.18, 6) + [dot(m - 0.18, r + 13), dot(m + 0.18, r + 13)]
    elif kind == "augsupceltu":
        out += [bridge(r * 0.4, r + 9, 0.25, 0.62), dot(0.25, r + 9), line((ea, -6), (1 - eb, -6)), dot(m, -6)]
    elif kind == "virs_elkoniem":
        out += bars(7, ticks=True)
    elif kind == "virs_elkoniem_sanis":
        out += [line((lo, -7), (hi, -7)), line((lo, -7), (lo, -2.5)), line((hi, -7), (hi, -2.5)),
                bridge(2, 16), dot(m, 16)]
    elif kind == "aptv_slegtais":
        out += bars(5)
    elif kind == "aptv_sanis":
        out += [line((lo, -5), (hi, -5)), bridge(2, 16), dot(m, 16)]
    elif kind == "aptv_kreiso_sanos":
        out += bars(5) + [dot(1, -r - 7)]
    elif kind == "aptv_vidukla":
        out += bars(7, ea * 0.3, 1 - eb * 0.3) + [line((m, 7), (m, -7))]
    elif kind == "aptv_vidukla_sanos":
        out += bars(5) + [dot(0, r + 7), dot(1, -r - 7)]
    elif kind == "aptv_valejais":
        out += [line((0.15, r * 0.75), (0.85, r * 0.75), (0.85, r * 0.3))]
    elif kind == "aptv_valejais_vidukla":
        out += cross(r * 0.75, 0.3, 4.5)
    elif kind == "aptv_kreisajam":
        out += [line((0.15, 7), (0.85, 7)), line((0.85, -r * 0.65), (0.85, -r - 6), (0.55, -r - 6)),
                dot(0.55, -r - 6)]
    elif kind == "aptv_plecu":
        out += [line((m, -11), (m, 11))]
    else:
        out += [line((ea, 0), (1 - eb, 0))]
    return out


def grip_example(kind):
    """Two dancers with the grip — for the legend and the choice list."""
    pose = next((p for k, _n, _g, p in GRIP_TYPES if k == kind), "side")
    gap = 26 if pose in ("side", "back", "opp") else 30
    if pose == "side":
        f, m = (0, 0, 0), (2 * gap, 0, 0)
    elif pose == "back":
        f, m = (2 * gap, 0, 180), (0, 0, 180)
    elif pose == "opp":
        f, m = (0, 0, 0), (2 * gap, 0, 180)
    elif pose == "follow":
        f, m = (2 * gap, 0, 90), (0, 0, 90)
    else:
        f, m = (0, 0, 270), (2 * gap, 0, 90)
    return [{"id": 1, "t": "fig", "g": "F", "x": f[0], "y": f[1], "a": f[2]},
            {"id": 2, "t": "fig", "g": "M", "x": m[0], "y": m[1], "a": m[2]},
            {"id": 3, "t": "grip", "a": 1, "b": 2, "kind": kind}]


def drawing_prims(drawing):
    figs = {e["id"]: e for e in drawing.get("els", []) if e.get("t") == "fig"}
    out = []
    for el in drawing.get("els", []):
        for p in element_prims(el, figs):
            out.append((el.get("id"), p))
    return out


def prims_bbox(prims):
    xs, ys = [], []
    for _eid, p in prims:
        if p[0] == "poly":
            xs += [q[0] for q in p[1]]
            ys += [q[1] for q in p[1]]
        else:
            _k, x, y, s, size = p
            w = max(1, len(s)) * size * 0.32
            xs += [x - w, x + w]
            ys += [y - size * 0.6, y + size * 0.6]
    if not xs:
        return 0.0, 0.0, 200.0, 100.0
    return min(xs), min(ys), max(xs), max(ys)


def dist_to_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def element_distance(el, figs, x, y):
    """How far (model units) the point is from the element."""
    if el.get("t") == "fig":
        return max(0.0, math.hypot(x - float(el["x"]), y - float(el["y"])) - FIG_R)
    best = 1e9
    for p in element_prims(el, figs):
        if p[0] == "poly":
            pts = p[1]
            for (ax, ay), (bx, by) in zip(pts, pts[1:]):
                best = min(best, dist_to_segment(x, y, ax, ay, bx, by))
        else:
            _k, tx, ty, s, size = p
            w = max(1, len(s)) * size * 0.32
            if abs(x - tx) <= w and abs(y - ty) <= size * 0.7:
                return 0.0
            best = min(best, math.hypot(x - tx, y - ty))
    return best


def move_element(el, dx, dy):
    if el.get("t") == "arrow":
        el["pts"] = [[p[0] + dx, p[1] + dy] for p in el.get("pts", [])]
    elif "x" in el:
        el["x"] = float(el["x"]) + dx
        el["y"] = float(el["y"]) + dy


def element_center(el, figs):
    if "x" in el:
        return float(el["x"]), float(el["y"])
    x0, y0, x1, y1 = prims_bbox([(None, p) for p in element_prims(el, figs)])
    return (x0 + x1) / 2, (y0 + y1) / 2


# ---- ready-made groupings (Latviešu dejas pamati: “Grupējumi”) ------------------------
LAYOUTS = ["Aplis / dārziņš", "Dubultaplis", "Pusaplis", "Rinda", "Divas rindas", "Kolonna (virkne)", "Gatve",
           "Četrstūris", "Ķīlis"]
COMPOSITIONS = ["Pāri (meita un puisis)", "Tikai meitas", "Tikai puiši", "Pamīšus meita un puisis"]
GROUP_FACINGS = ["Uz skatītājiem", "Uz dibenplānu", "Uz centru", "No centra", "Pa dejas ceļu (DCV)",
                 "Pret dejas ceļu", "Pāri viens pret otru"]


def make_group(layout, composition, count, facing, number=True, cx=STAGE_W / 2, cy=STAGE_H / 2):
    """Figures (dicts without ids) for a grouping. count — pairs (Pāri) or dancers (the others)."""
    count = max(1, min(40, int(count)))
    pairs = composition.startswith("Pāri")
    units = count                                  # pairs or single dancers
    pair_gap = 19.0

    def gender(i):
        if composition.startswith("Tikai meitas"):
            return "F"
        if composition.startswith("Tikai puiši"):
            return "M"
        return "F" if i % 2 == 0 else "M"

    # centres of the units and the direction "outwards" (for facing to / from the centre and the ring)
    places = []   # (x, y, angle on a circle or None)
    if layout in ("Aplis / dārziņš", "Dubultaplis", "Pusaplis"):
        spacing = 118 if pairs else 64
        if layout == "Pusaplis":
            radius = max(140.0, min(380.0, spacing * units / math.pi))
            for i in range(units):
                th = math.pi + math.pi * (i + 0.5) / units
                places.append((cx + radius * math.cos(th), cy + 0.55 * radius + radius * math.sin(th), th))
        else:
            radius = max(120.0, min(290.0, spacing * units / (2 * math.pi)))
            for i in range(units):
                th = -math.pi / 2 + 2 * math.pi * i / units
                places.append((cx + radius * math.cos(th), cy + radius * math.sin(th), th))
    elif layout == "Rinda":
        step = 84 if pairs else 52
        for i in range(units):
            places.append((cx + (i - (units - 1) / 2) * step, cy, None))
    elif layout == "Divas rindas":
        step = 84 if pairs else 52
        back = (units + 1) // 2
        for i in range(units):
            row, j, m = (0, i, back) if i < back else (1, i - back, units - back)
            places.append((cx + (j - (m - 1) / 2) * step, cy - 70 + row * 140, None))
    elif layout == "Kolonna (virkne)":
        step = 56 if pairs else 50
        for i in range(units):
            places.append((cx, cy + (i - (units - 1) / 2) * step, None))
    elif layout == "Gatve":
        step = 56
        if pairs:
            for i in range(units):
                places.append((cx, cy + (i - (units - 1) / 2) * step, None))
        else:
            half = (units + 1) // 2
            for i in range(units):
                side, j, m = (-1, i, half) if i < half else (1, i - half, units - half)
                places.append((cx + side * 90, cy + (j - (m - 1) / 2) * step, None))
    elif layout == "Četrstūris":
        per = [units // 4 + (1 if k < units % 4 else 0) for k in range(4)]
        side = 300.0
        k_unit = 0
        for s_i, n in enumerate(per):        # back, right, front, left — facing the centre
            for j in range(n):
                f = (j + 1) / (n + 1)
                pos = [(cx - side / 2 + side * f, cy - side / 2), (cx + side / 2, cy - side / 2 + side * f),
                       (cx + side / 2 - side * f, cy + side / 2), (cx - side / 2, cy + side / 2 - side * f)][s_i]
                places.append((pos[0], pos[1], None))
                k_unit += 1
    else:   # Ķīlis — the point to the audience
        step = 60 if pairs else 46
        depth = max(1, (units - 1) // 2 + 1)
        for i in range(units):
            s = -1 if i % 2 else 1
            k = (i + 1) // 2
            places.append((cx + s * k * step * 1.2, cy + 120 - 240 * k / depth * 0.6, None))

    def face_for(x, y, th):
        if facing == "Uz dibenplānu":
            return 180.0
        if facing == "Uz centru":
            return facing_to(cx - x, cy - y)
        if facing == "No centra":
            return facing_to(x - cx, y - cy)
        if facing in ("Pa dejas ceļu (DCV)", "Pret dejas ceļu"):
            if th is None:
                return 90.0 if facing.startswith("Pa") else 270.0
            tx, ty = math.sin(th), -math.cos(th)            # counter-clockwise on the screen
            if not facing.startswith("Pa"):
                tx, ty = -tx, -ty
            return facing_to(tx, ty)
        return 0.0

    figs = []
    for i, (x, y, th) in enumerate(places):
        no = str(i + 1) if number else ""
        if not pairs:
            a = face_for(x, y, th)
            if facing == "Pāri viens pret otru":
                a = 90.0 if (layout == "Gatve" and x < cx) else (270.0 if layout == "Gatve" else 0.0)
                if layout in ("Divas rindas",):
                    a = 0.0 if y < cy else 180.0
            figs.append({"t": "fig", "g": gender(i), "x": x, "y": y, "a": snap_angle(a, 15), "n": no})
            continue
        if facing == "Pāri viens pret otru":
            # partners face each other: the girl on one side, the boy on the other
            if th is not None:
                rx, ry = math.cos(th), math.sin(th)
            elif layout == "Gatve":
                rx, ry = -1.0, 0.0
            elif layout == "Kolonna (virkne)":
                rx, ry = -1.0, 0.0
            else:
                rx, ry = 0.0, -1.0
            gap = 90.0 if layout == "Gatve" else 24.0
            g_xy = (x + rx * gap, y + ry * gap)
            b_xy = (x - rx * gap, y - ry * gap)
            figs.append({"t": "fig", "g": "F", "x": g_xy[0], "y": g_xy[1],
                         "a": snap_angle(facing_to(b_xy[0] - g_xy[0], b_xy[1] - g_xy[1]), 15), "n": no, "pg": i + 1})
            figs.append({"t": "fig", "g": "M", "x": b_xy[0], "y": b_xy[1],
                         "a": snap_angle(facing_to(g_xy[0] - b_xy[0], g_xy[1] - b_xy[1]), 15), "n": no, "pg": i + 1})
            continue
        a = face_for(x, y, th)
        if layout == "Dubultaplis" and th is not None:
            # the girls in the inner circle, the boys in the outer one
            ux, uy = math.cos(th), math.sin(th)
            g_xy = (x - ux * 24, y - uy * 24)
            b_xy = (x + ux * 24, y + uy * 24)
        else:
            # the girl stands on the boy's right hand
            ox, oy = rot(pair_gap, 0, a)
            g_xy = (x - ox, y - oy)
            b_xy = (x + ox, y + oy)
        figs.append({"t": "fig", "g": "F", "x": g_xy[0], "y": g_xy[1], "a": snap_angle(a, 15), "n": no, "pg": i + 1})
        figs.append({"t": "fig", "g": "M", "x": b_xy[0], "y": b_xy[1], "a": snap_angle(a, 15), "n": no, "pg": i + 1})
    return figs


# --------------------------------------------------------------------------
# SVG, HTML and PDF
# --------------------------------------------------------------------------
SVG_MM = 0.125          # one model unit on paper, mm (the whole stage: 125 mm wide)


def _fmt(v):
    return f"{v:.1f}".rstrip("0").rstrip(".")


def drawing_svg(drawing, max_width_mm=160.0):
    prims = drawing_prims(drawing)
    if drawing.get("frame", True):
        x0, y0, x1, y1 = 0.0, 0.0, float(STAGE_W), float(STAGE_H)
        bx0, by0, bx1, by1 = prims_bbox(prims)
        x0, y0, x1, y1 = min(x0, bx0 - 8), min(y0, by0 - 8), max(x1, bx1 + 8), max(y1, by1 + 8)
    else:
        x0, y0, x1, y1 = prims_bbox(prims)
        x0, y0, x1, y1 = x0 - 12, y0 - 12, x1 + 12, y1 + 12
    w, h = max(40.0, x1 - x0), max(30.0, y1 - y0)
    width_mm = min(max_width_mm, w * SVG_MM)
    height_mm = width_mm * h / w
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{_fmt(x0)} {_fmt(y0)} {_fmt(w)} {_fmt(h)}" '
             f'width="{_fmt(width_mm)}mm" height="{_fmt(height_mm)}mm">']
    if drawing.get("frame", True):
        parts.append(f'<rect x="0" y="0" width="{STAGE_W}" height="{STAGE_H}" fill="none" stroke="#000" '
                     f'stroke-width="1.6"/>')
    for _eid, p in prims:
        if p[0] == "poly":
            pts = " ".join(f"{_fmt(x)},{_fmt(y)}" for x, y in p[1])
            o = p[2]
            if o.get("fill"):
                parts.append(f'<polygon points="{pts}" fill="#000" stroke="#000" stroke-width="1" '
                             f'stroke-linejoin="round"/>')
            else:
                dash = ' stroke-dasharray="7 5"' if o.get("dash") else ""
                parts.append(f'<polyline points="{pts}" fill="none" stroke="#000" stroke-width="{_fmt(o["w"])}" '
                             f'stroke-linecap="round" stroke-linejoin="round"{dash}/>')
        else:
            _k, x, y, s, size = p
            parts.append(f'<text x="{_fmt(x)}" y="{_fmt(y)}" font-size="{size}" text-anchor="middle" '
                         f'dominant-baseline="central" font-family="Arial, Helvetica, sans-serif">'
                         f'{html.escape(s)}</text>')
    parts.append("</svg>")
    return "".join(parts)


HTML_CSS = """
@page { size: A4; margin: 20mm 20mm 22mm 22mm;
        @bottom-center { content: counter(page); font-family: "Times New Roman", Times, serif; font-size: 10pt; } }
body { font-family: "Times New Roman", Times, serif; font-size: 11.5pt; line-height: 1.32; color: #000;
       margin: 0; }
.page { max-width: 170mm; margin: 0 auto; }
h1 { text-align: center; font-size: 17pt; letter-spacing: 0.04em; margin: 0 0 4pt 0; text-transform: uppercase; }
.sub { text-align: center; margin: 0; }
.intro { margin-top: 12pt; }
.intro p, p.start { text-align: justify; text-indent: 10mm; margin: 0 0 3pt 0; }
h2 { text-align: center; font-size: 12pt; margin: 14pt 0 0 0; page-break-after: avoid; }
h2.big { font-size: 13pt; margin-top: 20pt; }
h3 { text-align: center; font-size: 11.5pt; margin: 12pt 0 0 0; page-break-after: avoid; }
.variant { text-align: center; font-style: italic; page-break-after: avoid; }
.music, .mline { text-align: center; page-break-after: avoid; }
.music { margin-bottom: 4pt; }
.mline:last-of-type { margin-bottom: 4pt; }
.row { display: flex; align-items: flex-start; margin: 0 0 2pt 0; page-break-inside: avoid; }
.tk { flex: 0 0 27mm; white-space: nowrap; }
.tx { flex: 1; text-align: justify; }
.row.count .tk { font-style: normal; padding-left: 0; }
.row.count .tx { padding-left: 0; }
.note { text-align: center; font-style: italic; margin: 6pt 6mm; page-break-inside: avoid; }
.figs { display: flex; justify-content: center; align-items: flex-end; gap: 10mm; flex-wrap: wrap;
        margin: 8pt 0 8pt 0; page-break-inside: avoid; }
figure { margin: 0; text-align: center; page-break-inside: avoid; }
figcaption { font-style: italic; font-size: 10.5pt; margin-top: 2pt; }
.grid { display: flex; flex-wrap: wrap; justify-content: space-around; gap: 8mm 6mm; margin-top: 8pt; }
.grid figure { flex: 0 0 auto; }
.muted { color: #555; }
"""


def _text_html(text):
    return "<br>".join(html.escape(line) for line in (text or "").strip().split("\n"))


def _paragraphs(text):
    blocks = [b.strip() for b in re.split(r"\n\s*\n|\n", (text or "").strip()) if b.strip()]
    return "".join(f"<p>{html.escape(b)}</p>" for b in blocks)


def _figure(drawing, max_w):
    return (f'<figure>{drawing_svg(drawing, max_w)}<figcaption>{html.escape(drawing_label(drawing))}</figcaption>'
            f'</figure>')


def _rows_html(work, rows):
    out = []
    pending = []    # drawings standing next to each other

    def flush():
        if pending:
            width = 160.0 if len(pending) == 1 else (78.0 if len(pending) == 2 else 52.0)
            out.append('<div class="figs">' + "".join(_figure(d, width) for d in pending) + "</div>")
            pending.clear()
    for row in rows:
        kind = row.get("k", ROW_TAKTS)
        if kind == ROW_DRAWING:
            d = drawing_by_id(work, row.get("zid"))
            if d is not None:
                pending.append(d)
            continue
        flush()
        if kind == ROW_NOTE:
            if (row.get("text") or "").strip():
                out.append(f'<div class="note">{_text_html(row.get("text"))}</div>')
        else:
            cls = "row count" if kind == ROW_COUNT else "row"
            out.append(f'<div class="{cls}"><div class="tk">{html.escape(row.get("takts", "") or "")}</div>'
                       f'<div class="tx">{_text_html(row.get("text"))}</div></div>')
    flush()
    return "".join(out)


def work_html(work):
    """The whole description as an HTML page (the same layout as in the dance collections)."""
    b = ['<!DOCTYPE html><html lang="lv"><head><meta charset="utf-8">',
         f"<title>{html.escape(work.get('title') or 'Dejas apraksts')}</title>",
         f"<style>{HTML_CSS}</style></head><body><div class=\"page\">"]
    b.append(f"<h1>{html.escape(work.get('title') or 'Bez nosaukuma')}</h1>")
    for key in ("lineup", "author", "music"):
        if (work.get(key) or "").strip():
            b.append(f'<p class="sub">{_text_html(work[key])}</p>')
    if (work.get("intro") or "").strip():
        b.append(f'<div class="intro">{_paragraphs(work["intro"])}</div>')
    for part in work.get("parts", []):
        b.append(f"<h2>{html.escape(part.get('title') or '')}</h2>")
        if (part.get("variant") or "").strip():
            b.append(f'<div class="variant">({html.escape(part["variant"].strip().strip("()"))})</div>')
        if (part.get("music") or "").strip():
            b.append(f'<div class="music">({html.escape(part["music"].strip().strip("()"))})</div>')
        b.append(_rows_html(work, part.get("rows", [])))
    if work.get("moves"):
        b.append('<h2 class="big">Kustību apraksts</h2>')
        for move in work["moves"]:
            b.append(f"<h3>{html.escape(move_title(work, move))}</h3>")
            for line in move_lines(move):
                b.append(f'<div class="mline">{html.escape(line)}</div>')
            if start_text(move):
                b.append(f'<p class="start">{_text_html(start_text(move))}</p>')
            b.append(_rows_html(work, move.get("rows", [])))
    placed = placed_drawings(work)
    rest = [d for d in work.get("drawings", []) if d.get("id") not in placed]
    if rest:
        b.append('<h2 class="big">Zīmējumi</h2><div class="grid">')
        width = 160.0 if len(rest) == 1 else 78.0
        b.append("".join(_figure(d, width) for d in rest))
        b.append("</div>")
    b.append("</div></body></html>")
    return "".join(b)


def find_browser():
    """Microsoft Edge or Google Chrome (they can print a page to PDF without opening a window)."""
    candidates = []
    if os.name == "nt":
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if base:
                candidates += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                               os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    for name in ("msedge", "microsoft-edge", "google-chrome", "chrome", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    return next((c for c in candidates if c and os.path.exists(c)), None)


def html_to_pdf(html_text, pdf_path, timeout=90):
    """Prints the page to a PDF file with Edge / Chrome. Returns '' when done, otherwise why not."""
    browser = find_browser()
    if browser is None:
        return "Datorā nav atrasts Microsoft Edge vai Google Chrome."
    work_dir = tempfile.mkdtemp(prefix="jaunrades_pdf_")
    try:
        page = os.path.join(work_dir, "apraksts.html")
        with open(page, "w", encoding="utf-8") as fh:
            fh.write(html_text)
        target = os.path.join(work_dir, "apraksts.pdf")
        url = "file:///" + page.replace("\\", "/").lstrip("/")
        cmd = [browser, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
               "--disable-extensions", f"--user-data-dir={os.path.join(work_dir, 'profils')}",
               "--no-pdf-header-footer", "--print-to-pdf-no-header", f"--print-to-pdf={target}", url]
        flags = 0x08000000 if os.name == "nt" else 0   # CREATE_NO_WINDOW
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout,
                           creationflags=flags)
        except subprocess.TimeoutExpired:
            return "PDF izveide aizņēma pārāk ilgu laiku."
        except OSError as exc:
            return f"Pārlūku neizdevās palaist: {exc}"
        if not os.path.exists(target) or os.path.getsize(target) < 200:
            return "Pārlūks PDF failu neizveidoja."
        shutil.copyfile(target, pdf_path)
        return ""
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def open_file(path):
    try:
        if os.name == "nt":
            os.startfile(path)   # type: ignore[attr-defined]
        else:
            webbrowser.open("file://" + os.path.abspath(path))
    except Exception:
        log_error(traceback.format_exc())


def safe_file_name(text):
    name = re.sub(r'[\\/:*?"<>|]+', " ", text or "").strip()
    return re.sub(r"\s+", " ", name) or "Dejas apraksts"


# --------------------------------------------------------------------------
# Small helpers for the windows
# --------------------------------------------------------------------------
def ask_text(parent, title, label, initial=""):
    """A small window asking for one line of text; returns it or None."""
    win = tk.Toplevel(parent)
    win.title(title)
    win.configure(bg=WHITE)
    win.transient(parent.winfo_toplevel())
    win.resizable(False, False)
    result = {"value": None}
    tk.Label(win, text=label, bg=WHITE, fg=NAVY, font=FONT).pack(anchor="w", padx=20, pady=(16, 4))
    var = tk.StringVar(value=initial)
    entry = ttk.Entry(win, textvariable=var, width=46)
    entry.pack(padx=20, fill="x")
    foot = tk.Frame(win, bg=WHITE)
    foot.pack(fill="x", padx=20, pady=14)

    def ok(*_):
        result["value"] = var.get().strip()
        win.destroy()
    ttk.Button(foot, text="Labi", style="Accent.TButton", command=ok).pack(side="right")
    ttk.Button(foot, text="Atcelt", command=win.destroy).pack(side="right", padx=(0, 8))
    entry.bind("<Return>", ok)
    win.bind("<Escape>", lambda e: win.destroy())
    win.update_idletasks()
    try:
        top = parent.winfo_toplevel()
        x = top.winfo_rootx() + (top.winfo_width() - win.winfo_width()) // 2
        y = top.winfo_rooty() + (top.winfo_height() - win.winfo_height()) // 3
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
    except tk.TclError:
        pass
    entry.focus_set()
    entry.select_range(0, "end")
    try:
        win.grab_set()
    except tk.TclError:
        pass
    win.wait_window()
    return result["value"]


def text_lines(widget):
    """How many lines a Text widget shows (wrapped lines counted)."""
    try:
        res = widget.count("1.0", "end", "displaylines")
    except tk.TclError:
        return 1
    if isinstance(res, tuple):
        res = res[0] if res else 1
    try:
        return max(1, int(res or 1))
    except (TypeError, ValueError):
        return 1


def render_on_canvas(canvas, drawing, x0, y0, w, h, frame=None, colour="#000000", tag="pic", max_scale=1.0):
    """A small picture of the drawing inside the box (thumbnails, the legend)."""
    prims = drawing_prims(drawing)
    use_frame = drawing.get("frame", True) if frame is None else frame
    if use_frame:
        bx0, by0, bx1, by1 = 0.0, 0.0, float(STAGE_W), float(STAGE_H)
    else:
        bx0, by0, bx1, by1 = prims_bbox(prims)
        bx0, by0, bx1, by1 = bx0 - 10, by0 - 10, bx1 + 10, by1 + 10
    bw, bh = max(1.0, bx1 - bx0), max(1.0, by1 - by0)
    s = min(w / bw, h / bh, max_scale)
    ox, oy = x0 + (w - bw * s) / 2 - bx0 * s, y0 + (h - bh * s) / 2 - by0 * s
    if use_frame:
        canvas.create_rectangle(ox, oy, ox + STAGE_W * s, oy + STAGE_H * s, outline="#9A9A9A", tags=tag)
    for _eid, p in prims:
        if p[0] == "poly":
            flat = [round(v) for q in p[1] for v in (ox + q[0] * s, oy + q[1] * s)]
            if len(flat) < 4:
                continue
            if p[2].get("fill"):
                canvas.create_polygon(*flat, fill=colour, outline=colour, tags=tag)
            else:
                extra = {"dash": (4, 3)} if p[2].get("dash") else {}
                canvas.create_line(*flat, fill=colour, width=max(1.0, p[2]["w"] * s * 1.1), capstyle="round",
                                   joinstyle="round", tags=tag, **extra)
        else:
            _k, x, y, text, size = p
            canvas.create_text(ox + x * s, oy + y * s, text=text, fill=colour,
                               font=("Segoe UI", max(6, int(size * s * 0.8))), tags=tag)


# --------------------------------------------------------------------------
# The drawing editor (skatuves plāns ar dejotājiem)
# --------------------------------------------------------------------------
TOOLS = [("select", "↖", "Izvēlēties / pārvietot"), ("F", "U", "Meita"), ("M", "V", "Puisis"),
         ("pair", "UV", "Pāris"), ("arrow", "→", "Bulta / līnija"), ("turn", "↻", "Griešanās uz vietas"),
         ("ring", "◯", "Dejas ceļš (aplis)"), ("grip", "⌣", "Satvēriens"), ("text", "T", "Teksts")]
RIGHT_CLICK = " Peles labā poga uz elementa — tā iespējas (virziens, rokas, numurs, veids …); tukšā vietā — rīka " \
              "iestatījumi."
TOOL_HINTS = {
    "select": "Klikšķis — izvēlēties (Shift — vairākus), vilkt — pārvietot; vilkt tukšā vietā — izvēlēties "
              "apgabalu. Peles ritenis vai R — pagriezt dejotājus par 45°. Delete — dzēst, Ctrl+Z — atsaukt." +
              RIGHT_CLICK,
    "F": "Klikšķis uz skatuves — ielikt meitu. Peles ritenis — kurp skatīsies nākamie dejotāji." + RIGHT_CLICK,
    "M": "Klikšķis uz skatuves — ielikt puisi. Peles ritenis — kurp skatīsies nākamie dejotāji." + RIGHT_CLICK,
    "pair": "Klikšķis — ielikt pāri: meita stāv puisim pa labi roku. Peles ritenis — virziens." + RIGHT_CLICK,
    "arrow": "Klikšķini punktus pa ceļam; beidz ar dubultklikšķi vai Enter. Esc — atcelt. Bultas veidu izvēlas ar "
             "peles labo pogu tukšā vietā.",
    "turn": "Klikšķis uz dejotāja vai vietas — griešanās uz vietas." + RIGHT_CLICK,
    "ring": "Nospied apļa centrā un velc līdz vajadzīgajam lielumam." + RIGHT_CLICK,
    "grip": "Klikšķini uz pirmā un otrā dejotāja (parasti — meita, tad puisis). Vieglāk — ievelc zīmi no kolonnas "
            "“Ievilkt laukumā”." + RIGHT_CLICK,
    "text": "Klikšķis — ierakstīt tekstu (piem., DCV, 1., “kulises”)." + RIGHT_CLICK,
}
FACING_NAMES = [(0, "↓  uz skatītājiem"), (180, "↑  uz dibenplānu"), (90, "←  pa kreisi"), (270, "→  pa labi"),
                (45, "↙  pa kreisi uz priekšu"), (315, "↘  pa labi uz priekšu"), (135, "↖  pa kreisi uz aizmuguri"),
                (225, "↗  pa labi uz aizmuguri")]


class DrawingEditor(tk.Frame):
    """Stage with dancers drawn with the conventional signs. Changes go straight into the drawing dict;
    on_change() is called after each of them."""

    def __init__(self, master, drawing, on_change, readonly=False):
        super().__init__(master, bg=CREAM)
        self.d = drawing
        self.on_change = on_change
        self.readonly = readonly
        self.tool = "select"
        self.sel = set()
        self.undo_stack = []
        self.drag = None
        self.pending = []          # arrow points being clicked
        self.grip_first = None
        self.mouse = None
        self.s, self.ox, self.oy = 1.0, 0.0, 0.0
        self.defaults = {"a": 0.0, "style": "solid", "heads": "end", "curve": False, "turns": "", "tdir": "R",
                         "rdir": "DCV", "grip": "vajejais", "autonum": False, "next_no": 1, "size": 13}
        self.tool_buttons = {}

        if not readonly:
            bar = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
            bar.pack(side="left", fill="y", padx=(0, 8))
            tk.Label(bar, text="RĪKI", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=8,
                                                                                         pady=(8, 2))
            for key, icon, name in TOOLS:
                b = tk.Label(bar, text=f"{icon}  {name}", bg=WHITE, fg=NAVY, font=FONT, anchor="w", padx=8, pady=4,
                             cursor="hand2", width=19)
                b.pack(fill="x", padx=4, pady=1)
                b.bind("<Button-1>", lambda e, k=key: self.set_tool(k))
                self.tool_buttons[key] = b
            tk.Frame(bar, bg=LINE_SOFT, height=1).pack(fill="x", pady=6)
            for text, cmd in (("▦  Gatavs grupējums…", self.insert_group), ("⟲  Pagriezt pa kreisi", lambda: self.rotate_selected(45)),
                              ("⟳  Pagriezt pa labi", lambda: self.rotate_selected(-45)),
                              ("⧉  Dublēt atlasītos", self.duplicate_selected), ("✕  Dzēst atlasītos", self.delete_selected),
                              ("↶  Atsaukt (Ctrl+Z)", self.undo), ("⌫  Notīrīt zīmējumu", self.clear_all)):
                b = tk.Label(bar, text=text, bg=WHITE, fg=NAVY, font=FONT_SMALL, anchor="w", padx=8, pady=3,
                             cursor="hand2")
                b.pack(fill="x", padx=4)
                b.bind("<Button-1>", lambda e, c=cmd: c())
                b.bind("<Enter>", lambda e, w=b: w.configure(bg=SELECTED))
                b.bind("<Leave>", lambda e, w=b: w.configure(bg=WHITE))
            self.props = None   # v0.1.6: no properties column — everything is in the right-click menu
        else:
            self.props = None

        self.ghost = None          # what is being dragged from the palette (elements at the pointer)
        self.pal_drag = None
        if not readonly:
            self.build_palette(self)   # to the right of the stage (left of the properties)
        mid = tk.Frame(self, bg=CREAM)
        mid.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(mid, bg=WHITE, highlightthickness=1, highlightbackground=LINE, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.hint = tk.Label(mid, text="", bg=CREAM, fg=MUTED, font=FONT_SMALL, anchor="w", justify="left",
                             wraplength=560)
        self.hint.pack(fill="x", pady=(4, 0))
        c = self.canvas
        c.bind("<Configure>", lambda e: self.redraw())
        if not readonly:
            c.bind("<ButtonPress-1>", self.press)
            c.bind("<B1-Motion>", self.motion)
            c.bind("<ButtonRelease-1>", self.release)
            c.bind("<Double-Button-1>", self.double)
            c.bind("<Button-3>", self.right_click)
            c.bind("<Motion>", self.hover)
            c.bind("<MouseWheel>", self.wheel)
            c.bind("<Button-4>", lambda e: self.rotate_selected(45))
            c.bind("<Button-5>", lambda e: self.rotate_selected(-45))
            for seq in ("<Delete>", "<BackSpace>"):
                c.bind(seq, lambda e: self.delete_selected())
            c.bind("<Escape>", self.escape)
            c.bind("<Return>", lambda e: self.finish_arrow())
            c.bind("<Control-z>", lambda e: self.undo())
            c.bind("<Control-Z>", lambda e: self.undo())
            c.bind("<r>", lambda e: self.rotate_selected(-45))
            c.bind("<R>", lambda e: self.rotate_selected(45))
            self.set_tool("select")
        else:
            self.hint.configure(text="Tikai skatīšanai.")

    # ---- the palette: grips, holds and hand positions to drag onto the stage -------------
    TILE_W, TILE_H = 150, 92

    def build_palette(self, parent):
        """A column to the right of the stage: choose the group, below — all its signs to drag onto the stage."""
        pal = tk.Frame(parent, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        pal.pack(side="right", fill="y", padx=(8, 0))
        tk.Label(pal, text="IEVILKT LAUKUMĀ", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold"), anchor="w").pack(
            fill="x", padx=8, pady=(8, 2))
        self.pal_group = tk.StringVar(value=PALETTE_GROUPS[0][1])
        cb = ttk.Combobox(pal, textvariable=self.pal_group, values=[n for _k, n in PALETTE_GROUPS],
                          state="readonly", width=20, height=6)
        cb.pack(fill="x", padx=8)
        cb.bind("<<ComboboxSelected>>", lambda e: self.fill_palette())
        tk.Label(pal, text="Velc uz dejotāju (pāri) vai tukšā vietā", bg=WHITE, fg=MUTED, font=("Segoe UI", 8),
                 anchor="w", justify="left", wraplength=self.TILE_W + 10).pack(fill="x", padx=8, pady=(3, 4))
        holder = tk.Frame(pal, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.pal = tk.Canvas(holder, width=self.TILE_W + 8, bg=WHITE, highlightthickness=0, cursor="hand2")
        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.pal.yview)
        self.pal.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.pal.pack(side="left", fill="y", expand=True, padx=(4, 0))
        self.pal.bind("<ButtonPress-1>", self.pal_press)
        self.pal.bind("<B1-Motion>", self.pal_motion)
        self.pal.bind("<ButtonRelease-1>", self.pal_release)
        self.pal.bind("<MouseWheel>", lambda e: self.pal.yview_scroll(-1 * int(e.delta / 120) * 2 if e.delta else 0,
                                                                     "units"))
        self.pal.bind("<Button-4>", lambda e: self.pal.yview_scroll(-2, "units"))
        self.pal.bind("<Button-5>", lambda e: self.pal.yview_scroll(2, "units"))
        self.pal_items = []
        self.fill_palette()

    def fill_palette(self):
        name = self.pal_group.get()
        key = next((k for k, n in PALETTE_GROUPS if n == name), "g0")
        if key == "hands":
            items = [("hands", k, n, hand_example(k)) for k, n in HANDS]
        else:
            gi = int(key[1:])
            items = [("grip", k, n, grip_example(k)) for k, n, g, _p in GRIP_TYPES if g == gi]
        self.pal_items = items
        c = self.pal
        c.delete("all")
        w, h = self.TILE_W, self.TILE_H
        for i, (_t, _k, label, els) in enumerate(items):
            x0, y0 = 2, 4 + i * (h + 6)
            c.create_rectangle(x0, y0, x0 + w, y0 + h, fill=CREAM, outline=LINE)
            render_on_canvas(c, {"els": els, "frame": False}, x0 + 6, y0 + 4, w - 12, 48, colour=NAVY,
                             max_scale=1.25)
            c.create_text(x0 + w / 2, y0 + 70, text=label, fill=NAVY, font=("Segoe UI", 8), width=w - 8,
                          justify="center")
        c.configure(scrollregion=(0, 0, w + 4, 8 + len(items) * (h + 6)))
        c.yview_moveto(0)

    def pal_press(self, event):
        y = self.pal.canvasy(event.y)
        i = int((y - 4) // (self.TILE_H + 6))
        self.pal_drag = self.pal_items[i] if 0 <= i < len(self.pal_items) else None
        if self.pal_drag is not None:
            self.hint.configure(text=f"“{self.pal_drag[2]}” — atlaid uz dejotāja (satvērienam — uz viena no pāra) "
                                     "vai tukšā vietā (tiks ielikti jauni dejotāji).")

    def pointer_on_stage(self, event):
        """Model coordinates of the pointer when it is over the stage, otherwise None."""
        c = self.canvas
        X, Y = event.x_root - c.winfo_rootx(), event.y_root - c.winfo_rooty()
        if 0 <= X <= c.winfo_width() and 0 <= Y <= c.winfo_height():
            return self.to_model(X, Y)
        return None

    def pal_motion(self, event):
        if self.pal_drag is None:
            return
        pos = self.pointer_on_stage(event)
        self.ghost = self.drop_result(self.pal_drag, *pos)[0] if pos else None
        self.redraw()

    def pal_release(self, event):
        item, self.pal_drag = self.pal_drag, None
        self.ghost = None
        self.hint.configure(text=TOOL_HINTS.get(self.tool, ""))
        if item is None:
            return
        pos = self.pointer_on_stage(event)
        if pos is None:
            self.redraw()
            return
        self.drop(item, *pos)

    def grip_target(self, x, y):
        """(first, second) figure for a grip dropped at the point: the dancer under it and the nearest other one."""
        figs = list(self.figs().values())
        near = [f for f in figs if math.hypot(float(f["x"]) - x, float(f["y"]) - y) <= FIG_R * 1.8]
        if not near:
            return None
        one = min(near, key=lambda f: math.hypot(float(f["x"]) - x, float(f["y"]) - y))
        others = [f for f in figs if f is not one and math.hypot(float(f["x"]) - float(one["x"]),
                                                               float(f["y"]) - float(one["y"])) <= 140]
        if not others:
            return None
        two = min(others, key=lambda f: math.hypot(float(f["x"]) - float(one["x"]), float(f["y"]) - float(one["y"])))
        if one.get("g") == "M" and two.get("g") == "F":   # the girl first, as in the book
            one, two = two, one
        return one, two

    def drop_result(self, item, x, y):
        """(elements to show at the pointer, description of what happens)."""
        kind, key = item[0], item[1]
        if kind == "hands":
            hit = self.hit(x, y)
            fig = self.figs().get(hit) if hit is not None else None
            if fig is not None:
                return [dict(fig, h=key)], ("hands", fig["id"])
            return [{"id": -1, "t": "fig", "g": "M", "x": x, "y": y, "a": self.defaults["a"], "h": key}], ("new", None)
        target = self.grip_target(x, y)
        if target is not None:
            one, two = target
            return [dict(one), dict(two), {"id": -9, "t": "grip", "a": one["id"], "b": two["id"], "kind": key}], \
                ("grip", (one["id"], two["id"]))
        els = grip_example(key)
        xs = [e["x"] for e in els if e.get("t") == "fig"]
        dx, dy = x - (min(xs) + max(xs)) / 2, y
        out = []
        for e in els:
            e = dict(e)
            if e.get("t") == "fig":
                e["x"], e["y"] = e["x"] + dx, e["y"] + dy
            out.append(e)
        return out, ("new", None)

    def drop(self, item, x, y):
        els, (what, target) = self.drop_result(item, x, y)
        self.push_undo()
        if what == "hands":
            fig = self.figs().get(target)
            if fig is not None:
                fig["h"] = item[1]
                self.sel = {target}
        elif what == "grip":
            a, b = target
            self.d["els"] = [e for e in self.els() if not (e.get("t") == "grip" and {e.get("a"), e.get("b")} == {a, b})]
            self.add({"t": "grip", "a": a, "b": b, "kind": item[1]})
        else:
            mapping = {}
            new_sel = set()
            pg = self.new_pg() if item[0] == "grip" else None
            for e in els:
                if e.get("t") == "fig":
                    old = e.get("id")
                    e = {k: v for k, v in e.items() if k != "id"}
                    if item[0] == "grip":
                        e["n"] = ""
                        e["pg"] = pg
                    mapping[old] = self.add(e, select=False)["id"]
                    new_sel.add(mapping[old])
            for e in els:
                if e.get("t") == "grip":
                    g = self.add({"t": "grip", "a": mapping.get(e["a"]), "b": mapping.get(e["b"]), "kind": e["kind"]},
                                 select=False)
                    new_sel.add(g["id"])
            self.sel = new_sel
        self.changed()
        self.build_props()

    # ---- coordinates ------------------------------------------------------------
    def to_model(self, X, Y):
        return (X - self.ox) / self.s, (Y - self.oy) / self.s

    def to_screen(self, x, y):
        return self.ox + x * self.s, self.oy + y * self.s

    def els(self):
        return self.d.setdefault("els", [])

    def figs(self):
        return {e["id"]: e for e in self.els() if e.get("t") == "fig"}

    def new_pg(self):
        """A pair id not used in this drawing yet."""
        return max([int(e.get("pg", 0) or 0) for e in self.els() if e.get("t") == "fig"] + [0]) + 1

    def renumber_pairs(self, figs):
        """New figures (a grouping, a dropped pair) get pair ids that do not clash with the drawing."""
        mapping = {}
        base = self.new_pg()
        for f in figs:
            if f.get("pg") is not None:
                if f["pg"] not in mapping:
                    mapping[f["pg"]] = base + len(mapping)
                f["pg"] = mapping[f["pg"]]
        return figs

    def partner(self, fig):
        return pair_partner(fig, self.figs())

    def pair_number(self, f1, f2=None):
        """Ask the pair's number; both dancers get it and become a pair (the number is shown once, above them)."""
        f2 = f2 or self.partner(f1)
        if f2 is None:
            return self.ask_number(f1)
        text = ask_text(self, "Pāra numurs", "Pāra numurs (rādās vienreiz, pa vidu virs pāra; tukšs — bez numura):",
                        str(f1.get("n", "") or f2.get("n", "")))
        if text is None:
            return
        self.push_undo()
        pg = f1.get("pg") if f1.get("pg") is not None and f1.get("pg") == f2.get("pg") else self.new_pg()
        for f in (f1, f2):
            f["pg"] = pg
            f["n"] = text
        self.changed()

    def unpair(self, fig):
        mate = self.partner(fig)
        self.push_undo()
        for f in (fig, mate):
            if f is not None:
                f.pop("pg", None)
        self.changed()

    def new_id(self):
        return max([int(e.get("id", 0)) for e in self.els() if isinstance(e.get("id"), int)] + [0]) + 1

    # ---- drawing ------------------------------------------------------------------
    def redraw(self):
        c = self.canvas
        c.delete("all")
        W, H = max(50, c.winfo_width()), max(50, c.winfo_height())
        m = 26
        self.s = max(0.05, min((W - 2 * m) / STAGE_W, (H - 2 * m) / STAGE_H))
        self.ox = (W - STAGE_W * self.s) / 2
        self.oy = (H - STAGE_H * self.s) / 2
        x0, y0 = self.to_screen(0, 0)
        x1, y1 = self.to_screen(STAGE_W, STAGE_H)
        if self.d.get("frame", True):
            c.create_rectangle(x0, y0, x1, y1, outline="#3A3A3A", width=1.5)
        else:
            c.create_rectangle(x0, y0, x1, y1, outline="#D8CCB0", dash=(3, 4))
        cx, cy = self.to_screen(STAGE_W / 2, STAGE_H / 2)
        # palīglīnijas (tikai ekrānā, PDF failā nav): krusts un diagonāles
        guide = "#D9CDB0"
        for gx0, gy0, gx1, gy1 in ((cx, y0, cx, y1), (x0, cy, x1, cy), (x0, y0, x1, y1), (x0, y1, x1, y0)):
            c.create_line(round(gx0), round(gy0), round(gx1), round(gy1), fill=guide, dash=(6, 5))
        c.create_text(cx, y0 - 12, text="dibenplāns", fill="#B3A687", font=("Segoe UI", 8))
        c.create_text(cx, y1 + 12, text="priekšplāns — skatītāji", fill="#B3A687", font=("Segoe UI", 8))
        c.create_text(x0 - 12, cy, text="kreisā puse", fill="#B3A687", font=("Segoe UI", 8), angle=90)
        c.create_text(x1 + 12, cy, text="labā puse", fill="#B3A687", font=("Segoe UI", 8), angle=270)
        s = self.s
        for eid, p in drawing_prims(self.d):
            col = "#1F5FA8" if eid in self.sel else "#000000"
            if p[0] == "poly":
                flat = [round(v) for q in p[1] for v in self.to_screen(*q)]
                if len(flat) < 4:
                    continue
                if p[2].get("fill"):
                    c.create_polygon(*flat, fill=col, outline=col)
                else:
                    extra = {"dash": (6, 4)} if p[2].get("dash") else {}
                    c.create_line(*flat, fill=col, width=max(1.0, p[2]["w"] * s * 1.2), capstyle="round",
                                  joinstyle="round", **extra)
            else:
                _k, x, y, text, size = p
                X, Y = self.to_screen(x, y)
                c.create_text(X, Y, text=text, fill=col, font=("Segoe UI", max(7, int(size * s * 0.85))))
        # handles of one selected arrow / the selection boxes
        figs = self.figs()
        for el in self.els():
            if el.get("id") not in self.sel:
                continue
            if el.get("t") == "arrow" and len(self.sel) == 1:
                for px, py in el.get("pts", []):
                    X, Y = self.to_screen(px, py)
                    c.create_rectangle(X - 4, Y - 4, X + 4, Y + 4, outline="#1F5FA8", fill=WHITE)
            elif el.get("t") == "fig":
                X, Y = self.to_screen(el["x"], el["y"])
                r = FIG_R * s * 1.5
                c.create_oval(X - r, Y - r, X + r, Y + r, outline="#9DBCE0", dash=(2, 2))
            elif el.get("t") in ("turn", "ring", "text"):
                X, Y = self.to_screen(*element_center(el, figs))
                c.create_rectangle(X - 3, Y - 3, X + 3, Y + 3, outline="#1F5FA8")
        if self.grip_first in figs:
            f = figs[self.grip_first]
            X, Y = self.to_screen(f["x"], f["y"])
            r = FIG_R * s * 1.7
            c.create_oval(X - r, Y - r, X + r, Y + r, outline=GOLD, width=2)
        if self.pending:
            pts = [self.to_screen(*p) for p in self.pending]
            if self.mouse is not None:
                pts.append(self.to_screen(*self.mouse))
            if len(pts) >= 2:
                c.create_line(*[v for q in pts for v in q], fill="#1F5FA8", dash=(4, 3), width=1.5)
            for X, Y in pts[:len(self.pending)]:
                c.create_oval(X - 3, Y - 3, X + 3, Y + 3, outline="#1F5FA8")
        if self.ghost:
            for _eid, p in drawing_prims({"els": self.ghost}):
                if p[0] == "poly":
                    flat = [v for q in p[1] for v in self.to_screen(*q)]
                    if len(flat) < 4:
                        continue
                    if p[2].get("fill"):
                        c.create_polygon(*flat, fill="#6C93C4", outline="#6C93C4")
                    else:
                        c.create_line(*flat, fill="#6C93C4", width=max(1.0, p[2]["w"] * s * 1.2), capstyle="round",
                                      joinstyle="round")
        if self.drag and self.drag[0] == "band":
            _k, ax, ay, bx, by = self.drag
            A, B = self.to_screen(ax, ay), self.to_screen(bx, by)
            c.create_rectangle(A[0], A[1], B[0], B[1], outline="#1F5FA8", dash=(3, 3))
        if self.drag and self.drag[0] == "ring":
            _k, rx, ry, rr = self.drag
            X, Y = self.to_screen(rx, ry)
            c.create_oval(X - rr * s, Y - rr * s, X + rr * s, Y + rr * s, outline="#1F5FA8", dash=(4, 3))

    # ---- tools ----------------------------------------------------------------------
    def set_tool(self, key):
        self.tool = key
        self.pending = []
        self.grip_first = None
        for k, b in self.tool_buttons.items():
            on = k == key
            b.configure(bg=NAVY if on else WHITE, fg=WHITE if on else NAVY, font=FONT_BOLD if on else FONT)
        self.hint.configure(text=TOOL_HINTS.get(key, ""))
        self.canvas.configure(cursor="arrow" if key == "select" else "crosshair")
        self.build_props()
        self.redraw()

    def push_undo(self):
        self.undo_stack.append(copy.deepcopy(self.els()))
        del self.undo_stack[:-80]

    def changed(self):
        self.redraw()
        try:
            self.on_change()
        except Exception:
            log_error(traceback.format_exc())

    def undo(self):
        if not self.undo_stack:
            return
        self.d["els"] = self.undo_stack.pop()
        self.sel = set()
        self.build_props()
        self.changed()

    def hit(self, x, y):
        """Id of the element under the point (dancers first)."""
        figs = self.figs()
        limit = 9 / self.s
        best, best_d = None, limit
        for el in reversed(self.els()):
            if el.get("t") != "fig":
                continue
            d = element_distance(el, figs, x, y)
            if d <= best_d:
                best, best_d = el["id"], d
        if best is not None:
            return best
        for el in reversed(self.els()):
            d = element_distance(el, figs, x, y)
            if d <= best_d:
                best, best_d = el.get("id"), d
        return best

    def add(self, el, select=True):
        el["id"] = self.new_id()
        self.els().append(el)
        if select:
            self.sel = {el["id"]}
        return el

    def next_number(self):
        if not self.defaults["autonum"]:
            return ""
        no = self.defaults["next_no"]
        self.defaults["next_no"] = no + 1
        if self.props is not None and hasattr(self, "next_no_var"):
            try:
                self.next_no_var.set(str(no + 1))
            except tk.TclError:
                pass
        return str(no)

    # ---- mouse --------------------------------------------------------------------------
    def press(self, event):
        self.canvas.focus_set()
        x, y = self.to_model(event.x, event.y)
        shift = bool(event.state & 0x0001)
        tool = self.tool
        if tool == "select":
            if len(self.sel) == 1:
                el = next((e for e in self.els() if e.get("id") in self.sel), None)
                if el is not None and el.get("t") == "arrow":
                    for i, (px, py) in enumerate(el.get("pts", [])):
                        if math.hypot(px - x, py - y) <= 8 / self.s:
                            self.drag = ["point", el["id"], i, False]
                            return
            hit = self.hit(x, y)
            if hit is not None:
                if shift:
                    self.sel ^= {hit}
                elif hit not in self.sel:
                    self.sel = {hit}
                self.drag = ["move", x, y, False]
            else:
                if not shift:
                    self.sel = set()
                self.drag = ["band", x, y, x, y]
            self.build_props()
            self.redraw()
        elif tool in ("F", "M"):
            self.push_undo()
            self.add({"t": "fig", "g": tool, "x": x, "y": y, "a": self.defaults["a"], "n": self.next_number()})
            self.changed()
            self.build_props()
        elif tool == "pair":
            self.push_undo()
            a = self.defaults["a"]
            ox, oy = rot(19.0, 0, a)
            no = self.next_number()
            pg = self.new_pg()
            g = self.add({"t": "fig", "g": "F", "x": x - ox, "y": y - oy, "a": a, "n": no, "pg": pg}, select=False)
            b = self.add({"t": "fig", "g": "M", "x": x + ox, "y": y + oy, "a": a, "n": no, "pg": pg}, select=False)
            self.sel = {g["id"], b["id"]}
            self.changed()
            self.build_props()
        elif tool == "arrow":
            if self.pending and math.hypot(self.pending[-1][0] - x, self.pending[-1][1] - y) < 3 / self.s:
                return
            self.pending.append([x, y])
            self.redraw()
        elif tool == "turn":
            hit = self.hit(x, y)
            figs = self.figs()
            if hit in figs:
                x, y = float(figs[hit]["x"]), float(figs[hit]["y"])
            self.push_undo()
            self.add({"t": "turn", "x": x, "y": y, "r": FIG_R + 13, "dir": self.defaults["tdir"]})
            self.changed()
            self.build_props()
        elif tool == "ring":
            self.drag = ["ring", x, y, 0.0]
        elif tool == "grip":
            hit = self.hit(x, y)
            if hit not in self.figs():
                return
            if self.grip_first is None or self.grip_first == hit:
                self.grip_first = hit
                self.redraw()
                return
            self.push_undo()
            self.add({"t": "grip", "a": self.grip_first, "b": hit, "kind": self.defaults["grip"]})
            self.grip_first = None
            self.changed()
            self.build_props()
        elif tool == "text":
            text = ask_text(self, "Teksts", "Teksts zīmējumā:")
            if text:
                self.push_undo()
                self.add({"t": "text", "x": x, "y": y, "s": text, "size": self.defaults["size"]})
                self.changed()
                self.build_props()

    def motion(self, event):
        if not self.drag:
            return
        x, y = self.to_model(event.x, event.y)
        kind = self.drag[0]
        if kind == "move":
            _k, lx, ly, moved = self.drag
            dx, dy = x - lx, y - ly
            if not moved:
                if math.hypot(dx, dy) * self.s < 2:
                    return
                self.push_undo()
            for el in self.els():
                if el.get("id") in self.sel:
                    move_element(el, dx, dy)
            self.drag = ["move", x, y, True]
            self.redraw()
        elif kind == "point":
            _k, eid, i, moved = self.drag
            el = next((e for e in self.els() if e.get("id") == eid), None)
            if el is None:
                return
            if not moved:
                self.push_undo()
            el["pts"][i] = [x, y]
            self.drag = ["point", eid, i, True]
            self.redraw()
        elif kind == "band":
            self.drag[3], self.drag[4] = x, y
            self.redraw()
        elif kind == "ring":
            self.drag[3] = math.hypot(x - self.drag[1], y - self.drag[2])
            self.redraw()

    def release(self, event):
        drag, self.drag = self.drag, None
        if not drag:
            return
        kind = drag[0]
        if kind in ("move", "point") and drag[-1]:
            self.changed()
        elif kind == "band":
            _k, ax, ay, bx, by = drag
            if abs(bx - ax) * self.s > 3 or abs(by - ay) * self.s > 3:
                x0, x1, y0, y1 = min(ax, bx), max(ax, bx), min(ay, by), max(ay, by)
                figs = self.figs()
                found = set()
                for el in self.els():
                    if el.get("t") == "grip":
                        continue
                    cx, cy = element_center(el, figs)
                    if x0 <= cx <= x1 and y0 <= cy <= y1:
                        found.add(el["id"])
                self.sel |= found
                self.build_props()
            self.redraw()
        elif kind == "ring":
            _k, rx, ry, rr = drag
            if rr >= 25:
                self.push_undo()
                self.add({"t": "ring", "x": rx, "y": ry, "r": rr, "dir": self.defaults["rdir"]})
                self.changed()
                self.build_props()
            else:
                self.redraw()

    def double(self, event):
        if self.tool == "arrow":
            self.finish_arrow()
            return
        if self.tool != "select":
            return
        x, y = self.to_model(event.x, event.y)
        hit = self.hit(x, y)
        el = next((e for e in self.els() if e.get("id") == hit), None)
        if el is None:
            return
        if el.get("t") == "fig":
            if self.partner(el) is not None:
                self.pair_number(el)
                self.build_props()
                return
            text = ask_text(self, "Numurs", "Dejotāja numurs (tukšs — bez numura):", str(el.get("n", "")))
            if text is not None:
                self.push_undo()
                el["n"] = text
                self.changed()
                self.build_props()
        elif el.get("t") == "text":
            text = ask_text(self, "Teksts", "Teksts zīmējumā:", str(el.get("s", "")))
            if text:
                self.push_undo()
                el["s"] = text
                self.changed()
                self.build_props()

    def right_click(self, event):
        if self.tool == "arrow" and self.pending:
            self.finish_arrow()
            return
        x, y = self.to_model(event.x, event.y)
        hit = self.hit(x, y)
        if hit is not None and hit not in self.sel:
            self.sel = {hit}
        elif hit is None:
            self.sel = set()
        self.redraw()
        menu = self.context_menu()
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    # ---- the right-click menu (instead of a properties column) ------------------------
    def context_menu(self):
        menu = tk.Menu(self, tearoff=0, font=FONT)
        chosen = self.selected()
        kinds = {e.get("t") for e in chosen}

        def mark(on, text):
            return ("●  " if on else "     ") + text

        def set_all(types, key, value):
            self.push_undo()
            for e in chosen:
                if e.get("t") in types:
                    e[key] = value
            self.changed()

        def set_default(key, value):
            self.defaults[key] = value
            self.hint.configure(text=TOOL_HINTS.get(self.tool, "") + "  ✓ Iestatīts.")

        def facing_menu(parent, current, apply):
            sub = tk.Menu(parent, tearoff=0, font=FONT)
            for a, text in FACING_NAMES:
                on = current is not None and abs(((current - a) + 180) % 360 - 180) < 1
                sub.add_command(label=mark(on, text), command=lambda v=a: apply(v))
            return sub

        def grip_menu(parent, current, apply):
            sub = tk.Menu(parent, tearoff=0, font=FONT)
            for gi, group in enumerate(GRIP_GROUPS):
                part = tk.Menu(sub, tearoff=0, font=FONT)
                for k, n, g, _p in GRIP_TYPES:
                    if g == gi:
                        part.add_command(label=mark(k == current, n), command=lambda v=k: apply(v))
                sub.add_cascade(label=group, menu=part)
            return sub

        def choice_menu(parent, options, current, apply):
            sub = tk.Menu(parent, tearoff=0, font=FONT)
            for value, text in options:
                sub.add_command(label=mark(value == current, text), command=lambda v=value: apply(v))
            return sub

        if chosen and kinds == {"fig"}:
            one = chosen[0] if len(chosen) == 1 else None
            if one is not None:
                menu.add_command(label=("Meita (U)" if one.get("g") == "F" else "Puisis (V)") +
                                 (f" — {one['n']}" if str(one.get("n", "")).strip() else ""), state="disabled")
                menu.add_command(label="⇄  Mainīt: " + ("par puisi" if one.get("g") == "F" else "par meitu"),
                                 command=lambda: set_all({"fig"}, "g", "M" if one.get("g") == "F" else "F"))
                mate = self.partner(one)
                if mate is not None:
                    menu.add_command(label="#  Pāra numurs (abiem)…", command=lambda: self.pair_number(one, mate))
                    menu.add_command(label="▣  Atlasīt abus pāra dejotājus",
                                     command=lambda: (self.sel.update({one["id"], mate["id"]}), self.redraw()))
                    menu.add_command(label="✂  Atdalīt pāri", command=lambda: self.unpair(one))
                else:
                    menu.add_command(label="#  Numurs…", command=lambda: self.ask_number(one))
            else:
                menu.add_command(label=f"Atlasīti {len(chosen)} dejotāji", state="disabled")
                if len(chosen) == 2:
                    f1, f2 = sorted(chosen, key=lambda f: 0 if f.get("g") == "F" else 1)
                    paired = f1.get("pg") is not None and f1.get("pg") == f2.get("pg")
                    menu.add_command(label="#  Pāra numurs (abiem)…" if paired else "⚭  Savienot pārī un dot numuru…",
                                     command=lambda: self.pair_number(f1, f2))
                    if paired:
                        menu.add_command(label="✂  Atdalīt pāri", command=lambda: self.unpair(f1))
            angles = {round(float(e.get("a", 0))) % 360 for e in chosen}
            menu.add_cascade(label="Skatās uz", menu=facing_menu(menu, float(angles.pop()) if len(angles) == 1 else None,
                                                                   self.set_facing))
            hands = {e.get("h", "") for e in chosen}
            menu.add_cascade(label="Rokas", menu=choice_menu(menu, HANDS, hands.pop() if len(hands) == 1 else None,
                                                            lambda v: set_all({"fig"}, "h", v)))
            menu.add_command(label="⟲  Pagriezt pa kreisi", command=lambda: self.rotate_selected(45))
            menu.add_command(label="⟳  Pagriezt pa labi", command=lambda: self.rotate_selected(-45))
        elif len(chosen) == 1 and kinds == {"arrow"}:
            a = chosen[0]
            menu.add_command(label="Bulta / līnija", state="disabled")
            menu.add_cascade(label="Līnija", menu=choice_menu(menu, ARROW_STYLES, a.get("style", "solid"),
                                                             lambda v: set_all({"arrow"}, "style", v)))
            menu.add_cascade(label="Gali", menu=choice_menu(menu, ARROW_HEADS, a.get("heads", "end"),
                                                           lambda v: set_all({"arrow"}, "heads", v)))
            menu.add_cascade(label="Ceļā", menu=choice_menu(menu, ARROW_TURNS, a.get("turns", ""),
                                                           lambda v: set_all({"arrow"}, "turns", v)))
            menu.add_cascade(label="Forma", menu=choice_menu(
                menu, [(False, "Taisnas līnijas"), (True, "Līkne caur punktiem")], bool(a.get("curve")),
                lambda v: set_all({"arrow"}, "curve", v)))
        elif len(chosen) == 1 and kinds == {"turn"}:
            t = chosen[0]
            menu.add_command(label="Griešanās uz vietas", state="disabled")
            menu.add_cascade(label="Virziens", menu=choice_menu(menu, TURN_DIRS, t.get("dir", "R"),
                                                               lambda v: set_all({"turn"}, "dir", v)))
            menu.add_cascade(label="Lielums", menu=choice_menu(
                menu, [(FIG_R + 13, "Ap vienu dejotāju"), (FIG_R + 32, "Ap pāri"), (FIG_R + 60, "Liels")],
                t.get("r"), lambda v: set_all({"turn"}, "r", v)))
        elif len(chosen) == 1 and kinds == {"ring"}:
            menu.add_command(label="Dejas ceļš", state="disabled")
            menu.add_cascade(label="Virziens", menu=choice_menu(menu, RING_DIRS, chosen[0].get("dir", "DCV"),
                                                               lambda v: set_all({"ring"}, "dir", v)))
        elif len(chosen) == 1 and kinds == {"grip"}:
            g = chosen[0]
            current = OLD_GRIPS.get(g.get("kind"), g.get("kind") or "vajejais")
            menu.add_command(label=GRIP_NAMES.get(current, "Satvēriens"), state="disabled")
            menu.add_cascade(label="Veids", menu=grip_menu(menu, current, lambda v: set_all({"grip"}, "kind", v)))
            menu.add_command(label="⇅  Apmest uz otru pusi",
                             command=lambda: set_all({"grip"}, "flip", not g.get("flip", False)))
            menu.add_command(label="⇄  Samainīt dejotājus", command=lambda: self.swap_grip(g))
        elif len(chosen) == 1 and kinds == {"text"}:
            t = chosen[0]
            menu.add_command(label="Mainīt tekstu…", command=lambda: self.edit_text(t))
            menu.add_cascade(label="Lielums", menu=choice_menu(
                menu, [(11, "Mazs"), (13, "Vidējs"), (17, "Liels"), (22, "Ļoti liels")], t.get("size", 13),
                lambda v: set_all({"text"}, "size", v)))
        elif chosen:
            menu.add_command(label=f"Atlasīti {len(chosen)} elementi", state="disabled")
            if "fig" in kinds:
                menu.add_cascade(label="Dejotāji skatās uz", menu=facing_menu(menu, None, self.set_facing))
        if chosen:
            menu.add_separator()
            menu.add_command(label="⧉  Dublēt", command=self.duplicate_selected)
            menu.add_command(label="✕  Dzēst", command=self.delete_selected)
            return menu

        # nothing under the pointer: the settings of the tool (for the next elements)
        name = next((n for k, _i, n in TOOLS if k == self.tool), "")
        menu.add_command(label=f"{name} — iestatījumi", state="disabled")
        d = self.defaults
        if self.tool in ("F", "M", "pair", "select"):
            menu.add_cascade(label="Jaunie dejotāji skatās uz",
                             menu=facing_menu(menu, d["a"], lambda v: set_default("a", float(v))))
            menu.add_command(label=mark(d["autonum"], "Numurēt pēc kārtas"),
                             command=lambda: set_default("autonum", not d["autonum"]))
            menu.add_command(label=f"     Nākamais numurs: {d['next_no']}…", command=self.ask_next_number)
        elif self.tool == "arrow":
            menu.add_cascade(label="Līnija", menu=choice_menu(menu, ARROW_STYLES, d["style"],
                                                             lambda v: set_default("style", v)))
            menu.add_cascade(label="Gali", menu=choice_menu(menu, ARROW_HEADS, d["heads"],
                                                           lambda v: set_default("heads", v)))
            menu.add_cascade(label="Ceļā", menu=choice_menu(menu, ARROW_TURNS, d["turns"],
                                                           lambda v: set_default("turns", v)))
            menu.add_cascade(label="Forma", menu=choice_menu(
                menu, [(False, "Taisnas līnijas"), (True, "Līkne caur punktiem")], d["curve"],
                lambda v: set_default("curve", v)))
        elif self.tool == "turn":
            menu.add_cascade(label="Virziens", menu=choice_menu(menu, TURN_DIRS, d["tdir"],
                                                               lambda v: set_default("tdir", v)))
        elif self.tool == "ring":
            menu.add_cascade(label="Virziens", menu=choice_menu(menu, RING_DIRS, d["rdir"],
                                                               lambda v: set_default("rdir", v)))
        elif self.tool == "grip":
            menu.add_cascade(label="Veids", menu=grip_menu(menu, d["grip"], lambda v: set_default("grip", v)))
        elif self.tool == "text":
            menu.add_cascade(label="Lielums", menu=choice_menu(
                menu, [(11, "Mazs"), (13, "Vidējs"), (17, "Liels"), (22, "Ļoti liels")], d["size"],
                lambda v: set_default("size", v)))
        menu.add_separator()
        menu.add_command(label="▦  Gatavs grupējums…", command=self.insert_group)
        menu.add_command(label="↶  Atsaukt", command=self.undo)
        return menu

    def ask_number(self, fig):
        text = ask_text(self, "Numurs", "Dejotāja numurs (tukšs — bez numura):", str(fig.get("n", "")))
        if text is not None:
            self.push_undo()
            fig["n"] = text
            self.changed()

    def edit_text(self, el):
        text = ask_text(self, "Teksts", "Teksts zīmējumā:", str(el.get("s", "")))
        if text:
            self.push_undo()
            el["s"] = text
            self.changed()

    def ask_next_number(self):
        text = ask_text(self, "Numurēšana", "Ar kuru numuru turpināt numurēt jaunos dejotājus:",
                        str(self.defaults["next_no"]))
        try:
            self.defaults["next_no"] = int(text or "")
            self.defaults["autonum"] = True
        except ValueError:
            pass

    def hover(self, event):
        if self.pending:
            self.mouse = self.to_model(event.x, event.y)
            self.redraw()

    def wheel(self, event):
        if not any(e.get("t") == "fig" and e.get("id") in self.sel for e in self.els()):
            if self.tool in ("F", "M", "pair"):   # the way the next dancers will look
                self.defaults["a"] = (self.defaults["a"] + (45 if event.delta > 0 else -45)) % 360
                name = next((n for a, n in FACING_NAMES if abs(a - self.defaults["a"]) < 1), "")
                self.hint.configure(text=f"Nākamie dejotāji skatīsies: {name.strip()}")
            return
        self.rotate_selected(45 if event.delta > 0 else -45)

    def escape(self, event=None):
        if self.pending or self.grip_first is not None:
            self.pending = []
            self.grip_first = None
        else:
            self.sel = set()
            self.build_props()
        self.redraw()

    def finish_arrow(self):
        pts = []
        for p in self.pending:
            if not pts or math.hypot(pts[-1][0] - p[0], pts[-1][1] - p[1]) >= 3 / self.s:
                pts.append(p)
        self.pending = []
        self.mouse = None
        if len(pts) >= 2:
            self.push_undo()
            curve = self.defaults["curve"] and len(pts) >= 3
            self.add({"t": "arrow", "pts": pts, "style": self.defaults["style"], "heads": self.defaults["heads"],
                      "curve": curve, "turns": self.defaults["turns"]})
            self.changed()
            self.build_props()
        else:
            self.redraw()

    # ---- actions on the selection ----------------------------------------------------
    def selected(self):
        return [e for e in self.els() if e.get("id") in self.sel]

    def rotate_selected(self, step):
        figs = [e for e in self.selected() if e.get("t") == "fig"]
        if not figs:
            return
        self.push_undo()
        for f in figs:
            f["a"] = (float(f.get("a", 0)) + step) % 360
        self.changed()
        self.build_props()

    def set_facing(self, a):
        figs = [e for e in self.selected() if e.get("t") == "fig"]
        if self.tool in ("F", "M", "pair"):
            self.defaults["a"] = float(a)   # the next dancers placed look the same way
        if figs:
            self.push_undo()
            for f in figs:
                f["a"] = float(a)
            self.changed()
        else:
            self.defaults["a"] = float(a)
        self.build_props()

    def delete_selected(self):
        if not self.sel:
            return
        self.push_undo()
        gone = set(self.sel)
        self.d["els"] = [e for e in self.els() if e.get("id") not in gone and not (
            e.get("t") == "grip" and (e.get("a") in gone or e.get("b") in gone))]
        self.sel = set()
        self.changed()
        self.build_props()

    def duplicate_selected(self):
        chosen = self.selected()
        if not chosen:
            return
        self.push_undo()
        mapping = {}
        new_sel = set()
        pg_map = {}
        for el in chosen:
            if el.get("t") == "grip":
                continue
            twin = copy.deepcopy(el)
            if twin.get("pg") is not None:     # a copied pair stays a pair, but a new one
                if twin["pg"] not in pg_map:
                    pg_map[twin["pg"]] = self.new_pg() + len(pg_map)
                twin["pg"] = pg_map[twin["pg"]]
            move_element(twin, 30, 30)
            self.add(twin, select=False)
            mapping[el["id"]] = twin["id"]
            new_sel.add(twin["id"])
        for el in chosen:
            if el.get("t") == "grip" and el.get("a") in mapping and el.get("b") in mapping:
                twin = self.add({"t": "grip", "a": mapping[el["a"]], "b": mapping[el["b"]],
                                 "kind": el.get("kind", "vajejais"), "flip": el.get("flip", False)}, select=False)
                new_sel.add(twin["id"])
        self.sel = new_sel
        self.changed()
        self.build_props()

    def swap_grip(self, grip):
        self.push_undo()
        grip["a"], grip["b"] = grip.get("b"), grip.get("a")
        self.changed()
        self.build_props()

    def clear_all(self):
        if not self.els():
            return
        if not messagebox.askyesno("Notīrīt zīmējumu", "Dzēst visu šī zīmējuma saturu?\n\n(To var atsaukt ar "
                                                        "Ctrl+Z, kamēr zīmējums ir atvērts.)", parent=self):
            return
        self.push_undo()
        self.d["els"] = []
        self.sel = set()
        self.changed()
        self.build_props()

    def insert_group(self):
        dlg = GroupDialog(self)
        figs = dlg.result
        if not figs:
            return
        self.push_undo()
        new_sel = set()
        for f in self.renumber_pairs(figs):
            new_sel.add(self.add(f, select=False)["id"])
        self.sel = new_sel
        self.set_tool("select")
        self.changed()
        self.build_props()

    # ---- the panel on the right -----------------------------------------------------
    def build_props(self):
        panel = self.props
        if panel is None:
            return
        for w in panel.winfo_children():
            w.destroy()
        chosen = self.selected()
        kinds = {e.get("t") for e in chosen}

        def title(text):
            tk.Label(panel, text=text, bg=WHITE, fg=NAVY, font=("Georgia", 11, "bold"), anchor="w",
                     justify="left", wraplength=200).pack(fill="x", padx=12, pady=(10, 4))

        def label(text):
            tk.Label(panel, text=text, bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold"), anchor="w").pack(
                fill="x", padx=12, pady=(8, 2))

        def choices(options, current, setter):
            box = tk.Frame(panel, bg=WHITE)
            box.pack(fill="x", padx=12)
            for value, text in options:
                on = value == current
                lbl = tk.Label(box, text=("● " if on else "○ ") + text, bg=WHITE, fg=NAVY,
                               font=FONT_BOLD if on else FONT_SMALL, anchor="w", cursor="hand2")
                lbl.pack(fill="x")
                lbl.bind("<Button-1>", lambda e, v=value: setter(v))

        def facing_picker(current):
            label("SKATĀS UZ")
            grid = tk.Frame(panel, bg=WHITE)
            grid.pack(anchor="w", padx=12)
            for i, (a, arrow) in enumerate(FACINGS):
                if a is None:
                    tk.Label(grid, text="•", bg=WHITE, fg=MUTED, width=3, height=1).grid(row=i // 3, column=i % 3)
                    continue
                on = current is not None and abs(((current - a) + 180) % 360 - 180) < 1
                lbl = tk.Label(grid, text=arrow, bg=NAVY if on else CREAM, fg=WHITE if on else NAVY,
                               font=("Segoe UI", 11, "bold"), width=3, cursor="hand2")
                lbl.grid(row=i // 3, column=i % 3, padx=1, pady=1)
                lbl.bind("<Button-1>", lambda e, v=a: self.set_facing(v))
            tk.Label(panel, text="↓ — uz skatītājiem (priekšplānu)", bg=WHITE, fg=MUTED, font=("Segoe UI", 8),
                     anchor="w").pack(fill="x", padx=12, pady=(2, 0))

        def grip_picker(current, setter):
            """Grouped list of the grips with a picture of the chosen one."""
            label("VEIDS")
            names = [n for _k, n, _g, _p in GRIP_TYPES]
            var = tk.StringVar(value=GRIP_NAMES.get(current, names[0]))
            cb = ttk.Combobox(panel, textvariable=var, values=names, state="readonly", width=30, height=26)
            cb.pack(anchor="w", padx=12)
            group = next((GRIP_GROUPS[g] for k, _n, g, _p in GRIP_TYPES if k == current), "")
            tk.Label(panel, text=group, bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "italic"), anchor="w").pack(
                fill="x", padx=12, pady=(2, 0))
            pic = tk.Canvas(panel, width=196, height=86, bg=CREAM, highlightthickness=0)
            pic.pack(anchor="w", padx=12, pady=(6, 0))
            render_on_canvas(pic, {"els": grip_example(current), "frame": False}, 4, 4, 188, 78, max_scale=1.6)

            def chosen_name(_e=None):
                key = next((k for k, n, _g, _p in GRIP_TYPES if n == var.get()), None)
                if key:
                    setter(key)
            cb.bind("<<ComboboxSelected>>", chosen_name)

        def hands_picker(current):
            label("ROKAS")
            names = [n for _k, n in HANDS]
            var = tk.StringVar(value=HAND_NAMES.get(current, "") if current is not None else "")
            cb = ttk.Combobox(panel, textvariable=var, values=names, state="readonly", width=30, height=12)
            cb.pack(anchor="w", padx=12)

            def chosen_hands(_e=None):
                key = next((k for k, n in HANDS if n == var.get()), None)
                if key is not None:
                    set_on({"fig"}, "h", key)
            cb.bind("<<ComboboxSelected>>", chosen_hands)

        def set_on(els_or_defaults, key, value, dkey=None):
            if chosen:
                self.push_undo()
                for e in chosen:
                    if e.get("t") in els_or_defaults:
                        e[key] = value
                self.changed()
            else:
                self.defaults[dkey or key] = value
            self.build_props()

        if len(chosen) == 1 and "fig" in kinds:
            f = chosen[0]
            title("Meita" if f.get("g") == "F" else "Puisis")
            choices([("F", "Meita (U)"), ("M", "Puisis (V)")], f.get("g"), lambda v: set_on({"fig"}, "g", v))
            label("NUMURS")
            var = tk.StringVar(value=str(f.get("n", "")))
            ent = ttk.Entry(panel, textvariable=var, width=8)
            ent.pack(anchor="w", padx=12)

            def number_changed(*_):
                f["n"] = var.get().strip()
                self.changed()
            var.trace_add("write", number_changed)
            facing_picker(float(f.get("a", 0)))
            hands_picker(f.get("h", ""))
        elif chosen and kinds == {"fig"}:
            title(f"Atlasīti {len(chosen)} dejotāji")
            angles = {round(float(e.get("a", 0))) % 360 for e in chosen}
            facing_picker(float(angles.pop()) if len(angles) == 1 else None)
            hands = {e.get("h", "") for e in chosen}
            hands_picker(hands.pop() if len(hands) == 1 else None)
            tk.Label(panel, text="Vilkt — pārvietot visus kopā. Peles ritenis — pagriezt katru.", bg=WHITE,
                     fg=MUTED, font=FONT_SMALL, wraplength=200, justify="left").pack(fill="x", padx=12, pady=8)
        elif len(chosen) == 1 and "arrow" in kinds:
            a = chosen[0]
            title("Bulta / līnija")
            label("LĪNIJA")
            choices(ARROW_STYLES, a.get("style", "solid"), lambda v: set_on({"arrow"}, "style", v))
            label("GALI")
            choices(ARROW_HEADS, a.get("heads", "end"), lambda v: set_on({"arrow"}, "heads", v))
            label("CEĻĀ")
            choices(ARROW_TURNS, a.get("turns", ""), lambda v: set_on({"arrow"}, "turns", v))
            label("FORMA")
            choices([(False, "Taisnas līnijas"), (True, "Līkne caur punktiem")], bool(a.get("curve")),
                    lambda v: set_on({"arrow"}, "curve", v))
            tk.Label(panel, text="Punktus var pārvilkt ar peli (kvadrātiņi).", bg=WHITE, fg=MUTED, font=FONT_SMALL,
                     wraplength=200, justify="left").pack(fill="x", padx=12, pady=8)
        elif len(chosen) == 1 and "turn" in kinds:
            title("Griešanās uz vietas")
            choices(TURN_DIRS, chosen[0].get("dir", "R"), lambda v: set_on({"turn"}, "dir", v))
            label("LIELUMS")
            choices([(FIG_R + 13, "Ap vienu dejotāju"), (FIG_R + 32, "Ap pāri"), (FIG_R + 60, "Liels")],
                    chosen[0].get("r"), lambda v: set_on({"turn"}, "r", v))
        elif len(chosen) == 1 and "ring" in kinds:
            title("Dejas ceļš")
            choices(RING_DIRS, chosen[0].get("dir", "DCV"), lambda v: set_on({"ring"}, "dir", v))
            tk.Label(panel, text="Pa dejas ceļu — pretēji pulksteņa rādītājam (pret sauli).", bg=WHITE, fg=MUTED,
                     font=FONT_SMALL, wraplength=200, justify="left").pack(fill="x", padx=12, pady=8)
        elif len(chosen) == 1 and "grip" in kinds:
            g = chosen[0]
            title("Satvēriens / aptvēriens")
            grip_picker(OLD_GRIPS.get(g.get("kind"), g.get("kind") or "vajejais"),
                        lambda v: set_on({"grip"}, "kind", v))
            box = tk.Frame(panel, bg=WHITE)
            box.pack(fill="x", padx=12, pady=(8, 0))
            ttk.Button(box, text="⇅ Apmest uz otru pusi",
                       command=lambda: set_on({"grip"}, "flip", not g.get("flip", False))).pack(anchor="w")
            ttk.Button(box, text="⇄ Samainīt dejotājus",
                       command=lambda: self.swap_grip(g)).pack(anchor="w", pady=(4, 0))
        elif len(chosen) == 1 and "text" in kinds:
            t = chosen[0]
            title("Teksts")
            var = tk.StringVar(value=str(t.get("s", "")))
            ttk.Entry(panel, textvariable=var, width=24).pack(anchor="w", padx=12)

            def text_changed(*_):
                if var.get().strip():
                    t["s"] = var.get()
                    self.changed()
            var.trace_add("write", text_changed)
            label("LIELUMS")
            choices([(11, "Mazs"), (13, "Vidējs"), (17, "Liels"), (22, "Ļoti liels")], t.get("size", 13),
                    lambda v: set_on({"text"}, "size", v))
        elif chosen:
            title(f"Atlasīti {len(chosen)} elementi")
            if "fig" in kinds:
                facing_picker(None)
        else:
            tool = self.tool
            name = next((n for k, _i, n in TOOLS if k == tool), "")
            title(name)
            if tool in ("F", "M", "pair"):
                facing_picker(self.defaults["a"])
                label("NUMURI")
                box = tk.Frame(panel, bg=WHITE)
                box.pack(fill="x", padx=12)
                auto = tk.BooleanVar(value=self.defaults["autonum"])

                def auto_changed():
                    self.defaults["autonum"] = auto.get()
                ttk.Checkbutton(box, text="Numurēt pēc kārtas, sākot ar", variable=auto,
                                command=auto_changed, style="White.TCheckbutton").pack(anchor="w")
                self.next_no_var = tk.StringVar(value=str(self.defaults["next_no"]))
                ttk.Entry(box, textvariable=self.next_no_var, width=6).pack(anchor="w", pady=(2, 0))

                def no_changed(*_):
                    try:
                        self.defaults["next_no"] = int(self.next_no_var.get())
                    except ValueError:
                        pass
                self.next_no_var.trace_add("write", no_changed)
            elif tool == "arrow":
                label("LĪNIJA")
                choices(ARROW_STYLES, self.defaults["style"], lambda v: set_on(set(), "style", v))
                label("GALI")
                choices(ARROW_HEADS, self.defaults["heads"], lambda v: set_on(set(), "heads", v))
                label("CEĻĀ")
                choices(ARROW_TURNS, self.defaults["turns"], lambda v: set_on(set(), "turns", v))
                label("FORMA")
                choices([(False, "Taisnas līnijas"), (True, "Līkne caur punktiem")], self.defaults["curve"],
                        lambda v: set_on(set(), "curve", v))
            elif tool == "turn":
                choices(TURN_DIRS, self.defaults["tdir"], lambda v: set_on(set(), "dir", v, "tdir"))
            elif tool == "ring":
                choices(RING_DIRS, self.defaults["rdir"], lambda v: set_on(set(), "dir", v, "rdir"))
            elif tool == "grip":
                grip_picker(self.defaults["grip"], lambda v: set_on(set(), "kind", v, "grip"))
            elif tool == "text":
                label("LIELUMS")
                choices([(11, "Mazs"), (13, "Vidējs"), (17, "Liels"), (22, "Ļoti liels")], self.defaults["size"],
                        lambda v: set_on(set(), "size", v))
            else:
                tk.Label(panel, text="Izvēlieties rīku kreisajā pusē vai uzklikšķiniet uz zīmējuma elementa, lai "
                                     "mainītu tā īpašības.\n\nApzīmējumi — kā “Latviešu dejas pamatos”: meita — "
                                     "pusloks U, puisis — ķīlītis V; apaļā / smailā puse ir seja.",
                         bg=WHITE, fg=MUTED, font=FONT_SMALL, wraplength=200, justify="left").pack(
                    fill="x", padx=12, pady=6)


class GroupDialog(tk.Toplevel):
    """Ready-made groupings (aplis, dārziņš, rinda, kolonna, gatve …). .result — the figures or None."""

    def __init__(self, parent):
        master = getattr(parent, "root", parent)
        super().__init__(master)
        self.result = None
        self.title("Gatavs grupējums")
        self.configure(bg=WHITE)
        self.transient(master.winfo_toplevel())
        self.resizable(False, False)
        izskats.dialog_header(self, "Gatavs grupējums", "Dejotāji tiks ielikti skatuves vidū un būs atlasīti — "
                              "tos var uzreiz pārvilkt vajadzīgajā vietā.", colour=MODULE_COLOUR, wrap=420)
        foot = izskats.dialog_footer(self)
        body = tk.Frame(self, bg=WHITE)
        body.pack(fill="both", expand=True, padx=20, pady=12)
        self.layout = tk.StringVar(value=LAYOUTS[0])
        self.comp = tk.StringVar(value=COMPOSITIONS[0])
        self.count = tk.StringVar(value="8")
        self.facing = tk.StringVar(value=GROUP_FACINGS[4])
        self.number = tk.BooleanVar(value=True)
        rows = [("Grupējums", ttk.Combobox(body, textvariable=self.layout, values=LAYOUTS, state="readonly",
                                           width=28)),
                ("Sastāvs", ttk.Combobox(body, textvariable=self.comp, values=COMPOSITIONS, state="readonly",
                                         width=28)),
                ("Skaits", ttk.Spinbox(body, from_=1, to=40, textvariable=self.count, width=6)),
                ("Skatās", ttk.Combobox(body, textvariable=self.facing, values=GROUP_FACINGS, state="readonly",
                                        width=28))]
        for i, (text, widget) in enumerate(rows):
            tk.Label(body, text=text, bg=WHITE, fg=NAVY, font=FONT).grid(row=i, column=0, sticky="w", pady=4,
                                                                          padx=(0, 12))
            widget.grid(row=i, column=1, sticky="w", pady=4)
        self.count_note = tk.Label(body, text="", bg=WHITE, fg=MUTED, font=FONT_SMALL)
        self.count_note.grid(row=2, column=1, sticky="e")
        ttk.Checkbutton(body, text="Numurēt (pāriem — pāra numurs abiem)", variable=self.number,
                        style="White.TCheckbutton").grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.preview = tk.Canvas(body, width=380, height=220, bg=CREAM, highlightthickness=0)
        self.preview.grid(row=5, column=0, columnspan=2, pady=(10, 0))
        for var in (self.layout, self.comp, self.count, self.facing, self.number):
            var.trace_add("write", lambda *a: self.show())
        ttk.Button(foot, text="Ielikt zīmējumā", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(foot, text="Atcelt", command=self.destroy).pack(side="right", padx=(0, 8))
        self.bind("<Escape>", lambda e: self.destroy())
        self.show()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.wait_window()

    def figures(self):
        try:
            count = int(self.count.get())
        except ValueError:
            return []
        return make_group(self.layout.get(), self.comp.get(), count, self.facing.get(), self.number.get())

    def show(self):
        pairs = self.comp.get().startswith("Pāri")
        self.count_note.configure(text="pāri" if pairs else "dejotāji")
        c = self.preview
        c.delete("all")
        figs = self.figures()
        if figs:
            els = [dict(f, id=i + 1) for i, f in enumerate(figs)]
            render_on_canvas(c, {"els": els, "frame": True}, 6, 6, 368, 208, colour=NAVY)

    def ok(self):
        self.result = self.figures() or None
        self.destroy()


class LegendWindow(tk.Toplevel):
    """The conventional signs used in the drawings (Latviešu dejas pamati, LNKC 2016)."""

    def __init__(self, parent):
        master = getattr(parent, "root", parent)
        super().__init__(master)
        self.title("Apzīmējumi")
        self.configure(bg=WHITE)
        self.transient(master.winfo_toplevel())
        izskats.dialog_header(self, "Dejas zīmējumu apzīmējumi", "Pēc krājuma “Latviešu dejas pamati” (Latvijas "
                              "Nacionālais kultūras centrs, 2016). Tieši tā tie izskatās arī PDF failā.",
                              colour=MODULE_COLOUR, wrap=700)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.destroy).pack(side="right")
        book = ttk.Notebook(self)
        book.pack(fill="both", expand=True, padx=16, pady=10)

        # -- the basic signs -------------------------------------------------------------
        page1 = tk.Frame(book, bg=WHITE)
        book.add(page1, text="Pamatzīmes")
        c = tk.Canvas(page1, width=880, height=400, bg=WHITE, highlightthickness=0)
        c.pack(padx=8, pady=8)
        items = [
            ("Meita — pusloks (apaļā puse — seja)", [{"id": 1, "t": "fig", "g": "F", "x": 0, "y": 0, "a": 0}]),
            ("Puisis — ķīlītis (smailā puse — seja)", [{"id": 1, "t": "fig", "g": "M", "x": 0, "y": 0, "a": 0}]),
            ("Pāris ar numuru (meita puisim pa labi)",
             [{"id": 1, "t": "fig", "g": "F", "x": -19, "y": 0, "a": 0, "n": "1", "pg": 1},
              {"id": 2, "t": "fig", "g": "M", "x": 19, "y": 0, "a": 0, "n": "1", "pg": 1}]),
            ("Rokas sānos (brīvās rokas)", [{"id": 1, "t": "fig", "g": "F", "x": 0, "y": 0, "a": 0, "h": "sanos"}]),
            ("Kustības virziens", [{"id": 1, "t": "arrow", "pts": [[90, 0], [0, 0]], "style": "solid"}]),
            ("Tālākā virzīšanās", [{"id": 1, "t": "arrow", "pts": [[0, 0], [90, 0]], "style": "dashed"}]),
            ("Kustība uz vienu un otru pusi", [{"id": 1, "t": "arrow", "pts": [[0, 0], [90, 0]],
                                                "style": "twoway"}]),
            ("Virzīšanās, griežoties pa labi", [{"id": 1, "t": "arrow", "pts": [[0, 0], [0, 110]], "turns": "R"}]),
            ("Griešanās uz vietas pa labi / pa kreisi",
             [{"id": 1, "t": "fig", "g": "F", "x": 0, "y": 0, "a": 0},
              {"id": 2, "t": "turn", "x": 0, "y": 0, "r": 29, "dir": "R"},
              {"id": 3, "t": "fig", "g": "M", "x": 80, "y": 0, "a": 0},
              {"id": 4, "t": "turn", "x": 80, "y": 0, "r": 29, "dir": "L"}]),
            ("Pa dejas ceļu (DCV) / pret dejas ceļu",
             [{"id": 1, "t": "ring", "x": 0, "y": 0, "r": 32, "dir": "DCV"},
              {"id": 2, "t": "ring", "x": 95, "y": 0, "r": 32, "dir": "PRET"}]),
        ]
        for i, (text, els) in enumerate(items):
            col, row = i % 2, i // 2
            x0, y0 = 10 + col * 440, 8 + row * 78
            render_on_canvas(c, {"els": els, "frame": False}, x0, y0, 110, 66)
            c.create_text(x0 + 126, y0 + 33, text=text, anchor="w", fill=NAVY, font=FONT, width=290)

        # -- grips and holds --------------------------------------------------------------
        page2 = tk.Frame(book, bg=WHITE)
        book.add(page2, text="Satvērieni un aptvērieni")
        holder = tk.Frame(page2, bg=WHITE)
        holder.pack(fill="both", expand=True)
        g = tk.Canvas(holder, width=880, height=400, bg=WHITE, highlightthickness=0)
        vsb = ttk.Scrollbar(holder, orient="vertical", command=g.yview)
        g.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        g.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        y = 6
        cols, cell_w, cell_h = 4, 218, 108
        for gi, group in enumerate(GRIP_GROUPS):
            g.create_text(10, y + 10, text=group.upper(), anchor="w", fill=MUTED, font=("Segoe UI", 9, "bold"))
            y += 26
            kinds = [(k, n) for k, n, grp, _p in GRIP_TYPES if grp == gi]
            for i, (kind, name) in enumerate(kinds):
                x0, y0 = 6 + (i % cols) * cell_w, y + (i // cols) * cell_h
                g.create_rectangle(x0, y0, x0 + cell_w - 8, y0 + cell_h - 8, outline=LINE_SOFT, fill=CREAM)
                render_on_canvas(g, {"els": grip_example(kind), "frame": False}, x0 + 8, y0 + 6, cell_w - 24, 56,
                                 max_scale=1.5)
                g.create_text(x0 + (cell_w - 8) / 2, y0 + 80, text=name, fill=NAVY, font=FONT_SMALL,
                              width=cell_w - 20, justify="center")
            y += ((len(kinds) + cols - 1) // cols) * cell_h + 6
        g.configure(scrollregion=(0, 0, 880, y))
        tk.Label(page2, text="Zīmējumā: rīks “⌣ Satvēriens” → labajā pusē izvēlas veidu → klikšķis uz meitas, tad uz "
                             "puiša. Zīme pielāgojas tam, kā dejotāji stāv.", bg=WHITE, fg=MUTED, font=FONT_SMALL,
                 anchor="w").pack(fill="x", padx=10, pady=(0, 6))

        def wheel(event):
            g.yview_scroll(-1 * int(event.delta / 120) * 2 if event.delta else 0, "units")
        g.bind("<MouseWheel>", wheel)

        # -- hand positions ---------------------------------------------------------------
        page3 = tk.Frame(book, bg=WHITE)
        book.add(page3, text="Roku stāvokļi")
        h = tk.Canvas(page3, width=880, height=400, bg=WHITE, highlightthickness=0)
        h.pack(padx=8, pady=8)
        for i, (kind, name) in enumerate(HANDS):
            x0, y0 = 6 + (i % 4) * 218, 6 + (i // 4) * 118
            h.create_rectangle(x0, y0, x0 + 210, y0 + 110, outline=LINE_SOFT, fill=CREAM)
            render_on_canvas(h, {"els": hand_example(kind), "frame": False}, x0 + 8, y0 + 6, 194, 64, max_scale=1.6)
            h.create_text(x0 + 105, y0 + 88, text=name, fill=NAVY, font=FONT_SMALL, width=196, justify="center")
        tk.Label(page3, text="Roka pacelta, rokas sakrustotas un rokas sānos — kā grāmatā; pārējām zīmēm tāds pats "
                             "stils. Dejotājam rokas izvēlas labajā pusē vai ievelk no apakšējās joslas.", bg=WHITE,
                 fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x", padx=10, pady=(0, 6))


# --------------------------------------------------------------------------
# PDF and the browser (shared by the list and the editor)
# --------------------------------------------------------------------------
def documents_dir():
    for path in (os.path.join(os.path.expanduser("~"), "Documents"), os.path.expanduser("~")):
        if os.path.isdir(path):
            return path
    return os.getcwd()


def preview_in_browser(work):
    """The description as a page in the browser (there: Ctrl+P — print or save as PDF)."""
    path = os.path.join(tempfile.gettempdir(), f"Jaunrades pūrs — {safe_file_name(work.get('title'))}.html")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(work_html(work))
    open_file(path)


def export_pdf(parent, work, busy=None):
    """Asks where to save, makes the PDF in the background and opens it."""
    path = filedialog.asksaveasfilename(
        parent=parent, title="Saglabāt aprakstu PDF failā", defaultextension=".pdf",
        filetypes=[("PDF fails", "*.pdf")], initialdir=documents_dir(),
        initialfile=safe_file_name(work.get("title")) + ".pdf")
    if not path:
        return
    page = work_html(copy.deepcopy(work))
    result = {}

    def worker():
        try:
            result["error"] = html_to_pdf(page, path)
        except Exception as exc:
            log_error(traceback.format_exc())
            result["error"] = str(exc)
    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    if busy:
        busy(True)

    def poll():
        if thread.is_alive():
            try:
                parent.after(250, poll)
            except tk.TclError:
                pass
            return
        if busy:
            try:
                busy(False)
            except tk.TclError:
                pass
        error = result.get("error")
        if not error:
            open_file(path)
            return
        try:
            if messagebox.askyesno("PDF", f"PDF failu neizdevās izveidot automātiski:\n{error}\n\nAtvērt aprakstu "
                                          "pārlūkā? Tur to var saglabāt kā PDF: Ctrl+P → “Saglabāt kā PDF”.",
                                   parent=parent):
                preview_in_browser(work)
        except tk.TclError:
            pass
    parent.after(250, poll)


# --------------------------------------------------------------------------
# Rows of a part / movement:  “1. – 4. t. | darbības”
# --------------------------------------------------------------------------
class RowsEditor(tk.Frame):
    def __init__(self, master, owner, rows, readonly=False):
        super().__init__(master, bg=CREAM)
        self.owner, self.rows, self.readonly = owner, rows, readonly
        self.current = None
        self.last_text = None
        self.focus_after = None
        self.thumbs = []

        if not readonly:
            tools = tk.Frame(self, bg=CREAM)
            tools.pack(fill="x", pady=(0, 6))
            tk.Label(tools, text="Ievietot tekstā:", bg=CREAM, fg=MUTED, font=FONT_SMALL).pack(side="left")
            self.draw_var = tk.StringVar()
            self.draw_cb = ttk.Combobox(tools, textvariable=self.draw_var, state="readonly", width=12)
            self.draw_cb.pack(side="left", padx=(6, 2))
            ttk.Button(tools, text="(… zīm.)", command=self.insert_drawing_ref).pack(side="left")
            self.move_var = tk.StringVar()
            self.move_cb = ttk.Combobox(tools, textvariable=self.move_var, state="readonly", width=12)
            self.move_cb.pack(side="left", padx=(12, 2))
            ttk.Button(tools, text="… kustību", command=self.insert_move_ref).pack(side="left")
            for text in ("DCV", "pret DCV", "–"):
                ttk.Button(tools, text=text, width=len(text) + 2,
                           command=lambda t=text: self.insert_text(t if t != "–" else " – ")).pack(side="left",
                                                                                                 padx=(6, 0))
            self.fill_ref_lists()

        box = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        box.pack(fill="both", expand=True)
        head = tk.Frame(box, bg=CREAM_DARK)
        head.pack(fill="x")
        tk.Label(head, text="Taktis", bg=CREAM_DARK, fg=NAVY, font=FONT_BOLD, width=14, anchor="w").pack(
            side="left", padx=(10, 0), pady=4)
        tk.Label(head, text="Darbības", bg=CREAM_DARK, fg=NAVY, font=FONT_BOLD, anchor="w").pack(side="left",
                                                                                             pady=4)
        holder = tk.Frame(box, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(holder, bg=WHITE, highlightthickness=0)
        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=WHITE)
        self.window = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window, width=e.width))
        for w in (self.canvas, self.inner):
            self.bind_wheel(w)

        if not readonly:
            foot = tk.Frame(self, bg=CREAM)
            foot.pack(fill="x", pady=(6, 0))
            for kind, text in ((ROW_TAKTS, "＋ Taktis"), (ROW_COUNT, "＋ Skaitījums"), (ROW_NOTE, "＋ Piezīme"),
                               (ROW_DRAWING, "＋ Zīmējums")):
                ttk.Button(foot, text=text, command=lambda k=kind: self.add_row(k)).pack(side="left", padx=(0, 6))
            izskats.note(foot, "Jaunā rinda nāk aiz tās, kurā ir kursors. Taktis: “1-4” → “1. – 4. t.”; "
                               "skaitījumam raksta, piem., “Viens”, “un”, “Divi”.").pack(side="left", padx=(8, 0))
        self.build()

    # ---- scrolling ----------------------------------------------------------------
    def bind_wheel(self, widget):
        widget.bind("<MouseWheel>", self.on_wheel)
        widget.bind("<Button-4>", lambda e: self.scroll(-3))
        widget.bind("<Button-5>", lambda e: self.scroll(3))

    def on_wheel(self, event):
        self.scroll(-1 * int(event.delta / 120) * 3 if event.delta else 0)
        return "break"

    def scroll(self, units):
        try:
            first, last = self.canvas.yview()
            if first <= 0 and last >= 1:
                return "break"
            self.canvas.yview_scroll(units, "units")
        except tk.TclError:
            pass
        return "break"

    def wheel_all(self, widget):
        self.bind_wheel(widget)
        for child in widget.winfo_children():
            self.wheel_all(child)

    # ---- references --------------------------------------------------------------
    def fill_ref_lists(self):
        if self.readonly:
            return
        work = self.owner.work
        labels = [f"{d.get('no', '')}. zīm." for d in work["drawings"]]
        self.draw_cb.configure(values=labels)
        if labels and self.draw_var.get() not in labels:
            self.draw_var.set(labels[-1])
        moves = [f"{i + 1}. kustība" for i in range(len(work["moves"]))]
        self.move_cb.configure(values=moves)
        if moves and self.move_var.get() not in moves:
            self.move_var.set(moves[0])

    def insert_drawing_ref(self):
        label = self.draw_var.get()
        if label:
            self.insert_text(f"({label})")

    def insert_move_ref(self):
        label = self.move_var.get()
        m = re.match(r"(\d+)", label)
        if m:
            self.insert_text(f"{m.group(1)}. kustību")

    def insert_text(self, text):
        widget = self.last_text
        try:
            if widget is None or not widget.winfo_exists() or str(widget.cget("state")) == "disabled":
                messagebox.showinfo("Ievietot", "Vispirms uzklikšķiniet rindas tekstā vietā, kur ievietot.",
                                    parent=self)
                return
        except tk.TclError:
            return
        widget.insert("insert", text)
        widget.event_generate("<KeyRelease>")
        widget.focus_set()

    # ---- the rows -----------------------------------------------------------------
    def build(self):
        for child in self.inner.winfo_children():
            child.destroy()
        self.thumbs = []
        self.focus_targets = []
        if not self.rows:
            izskats.note(self.inner, "Šim gājienam vēl nav nevienas rindas. Pievienojiet ar pogām zemāk.",
                         bg=WHITE).pack(anchor="w", padx=12, pady=14)
        for i, row in enumerate(self.rows):
            self.make_row(i, row)
        self.wheel_all(self.inner)
        if self.focus_after is not None:
            idx, self.focus_after = self.focus_after, None
            if 0 <= idx < len(self.focus_targets) and self.focus_targets[idx] is not None:
                target = self.focus_targets[idx]
                self.after(60, lambda: self.focus_and_show(target))

    def focus_and_show(self, widget):
        try:
            widget.focus_set()
            self.update_idletasks()
            y = widget.winfo_rooty() - self.inner.winfo_rooty()
            height = max(1, self.inner.winfo_height())
            self.canvas.yview_moveto(max(0.0, (y - 60) / height))
        except tk.TclError:
            pass

    def make_row(self, i, row):
        kind = row.get("k", ROW_TAKTS)
        fr = tk.Frame(self.inner, bg=WHITE)
        fr.pack(fill="x", padx=8, pady=(4, 0))
        if i:
            tk.Frame(self.inner, bg=LINE_SOFT, height=1).pack(fill="x", padx=8, before=fr)
        left = tk.Frame(fr, bg=WHITE)
        left.pack(side="left", fill="y", padx=(2, 8))
        if not self.readonly:
            btns = tk.Frame(fr, bg=WHITE)
            btns.pack(side="right", fill="y", padx=(6, 0))
            for text, cmd, _tip in (("▲", lambda: self.move_row(i, -1), "uz augšu"),
                                   ("▼", lambda: self.move_row(i, 1), "uz leju"),
                                   ("✕", lambda: self.delete_row(i), "dzēst")):
                b = tk.Label(btns, text=text, bg=WHITE, fg=RED if text == "✕" else MUTED, font=FONT_SMALL,
                             cursor="hand2", padx=3)
                b.pack(side="left")
                b.bind("<Button-1>", lambda e, c=cmd: c())
        if kind in (ROW_TAKTS, ROW_COUNT):
            var = tk.StringVar(value=row.get("takts", ""))
            entry = ttk.Entry(left, textvariable=var, width=13,
                              font=("Segoe UI", 10, "italic") if kind == ROW_COUNT else FONT)
            entry.pack(anchor="nw")
            if kind == ROW_COUNT:
                tk.Label(left, text="skaitījums", bg=WHITE, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w")

            def takts_changed(*_a, r=row, v=var):
                r["takts"] = v.get()
                self.owner.touch()
            var.trace_add("write", takts_changed)
            if kind == ROW_TAKTS:
                entry.bind("<FocusOut>", lambda e, v=var: v.set(normalize_takts(v.get())))
            entry.bind("<FocusIn>", lambda e, n=i: self.set_current(n))
            if self.readonly:
                entry.state(["readonly"])
        elif kind == ROW_NOTE:
            izskats.chip(left, "piezīme", WARN_BG, WARN_FG).pack(anchor="nw", pady=(4, 0))
        else:
            izskats.chip(left, "zīmējums", "#E3EEF4", MODULE_COLOUR).pack(anchor="nw", pady=(4, 0))
        if kind == ROW_DRAWING:
            self.make_drawing_row(fr, i, row)
            self.focus_targets.append(None)
            return
        text = tk.Text(fr, height=2, wrap="word", font=("Segoe UI", 10, "italic") if kind == ROW_NOTE else FONT,
                       relief="flat", bd=0, highlightthickness=1, highlightbackground=FIELD_LINE,
                       highlightcolor=NAVY, padx=6, pady=4, undo=True, fg=NAVY, insertbackground=NAVY)
        text.pack(side="left", fill="x", expand=True)
        text.insert("1.0", row.get("text", ""))
        if kind == ROW_NOTE:
            text.tag_configure("c", justify="center")
            text.tag_add("c", "1.0", "end")

        def changed(_e=None, r=row, t=text, note=(kind == ROW_NOTE)):
            new = t.get("1.0", "end-1c")
            if note:
                t.tag_add("c", "1.0", "end")
            if new != r.get("text", ""):
                r["text"] = new
                self.owner.touch()
            self.fit(t)
        text.bind("<KeyRelease>", changed)
        text.bind("<<Paste>>", lambda e: self.after(10, changed))
        text.bind("<FocusIn>", lambda e, n=i, t=text: self.set_current(n, t))
        text.bind("<Configure>", lambda e, t=text: self.fit(t))
        if self.readonly:
            text.configure(state="disabled")
        self.focus_targets.append(text)
        self.after_idle(lambda t=text: self.fit(t))

    def make_drawing_row(self, fr, i, row):
        work = self.owner.work
        box = tk.Frame(fr, bg=WHITE)
        box.pack(side="left", fill="x", expand=True)
        labels = [drawing_label(d) for d in work["drawings"]]
        ids = [d["id"] for d in work["drawings"]]
        var = tk.StringVar()
        if row.get("zid") in ids:
            var.set(labels[ids.index(row.get("zid"))])
        cb = ttk.Combobox(box, textvariable=var, values=labels, state="readonly" if not self.readonly else "disabled",
                          width=24)
        cb.pack(side="left", anchor="n")
        thumb = tk.Canvas(box, width=170, height=104, bg=WHITE, highlightthickness=1, highlightbackground=LINE_SOFT)
        thumb.pack(side="left", padx=(12, 0), pady=2)
        hint = izskats.note(box, "", bg=WHITE, wrap=260)
        hint.pack(side="left", padx=(12, 0), anchor="n")

        def show():
            thumb.delete("all")
            d = drawing_by_id(work, row.get("zid"))
            if d is None:
                thumb.create_text(85, 52, text="izvēlieties zīmējumu", fill=MUTED, font=FONT_SMALL)
                hint.configure(text="Vēl nav neviena zīmējuma — tos veido sadaļā “Zīmējumi” kreisajā pusē."
                               if not ids else "")
            else:
                render_on_canvas(thumb, d, 4, 4, 162, 96)
                hint.configure(text="Vairāki zīmējumi pēc kārtas PDF failā stāv blakus.")

        def chosen(_e=None):
            label = var.get()
            if label in labels:
                row["zid"] = ids[labels.index(label)]
                self.owner.touch()
                show()
        cb.bind("<<ComboboxSelected>>", chosen)
        cb.bind("<FocusIn>", lambda e, n=i: self.set_current(n))
        show()

    def set_current(self, index, text=None):
        self.current = index
        if text is not None:
            self.last_text = text

    def fit(self, text):
        try:
            if not text.winfo_exists():
                return
            lines = text_lines(text)
            want = max(1, min(24, lines))
            if int(text.cget("height")) != want:
                text.configure(height=want)
        except tk.TclError:
            pass

    def add_row(self, kind):
        index = self.current + 1 if self.current is not None and self.current < len(self.rows) else len(self.rows)
        row = {"k": kind, "takts": "", "text": ""}
        if kind == ROW_TAKTS:
            prev = next((r.get("takts", "") for r in reversed(self.rows[:index]) if r.get("k") == ROW_TAKTS), "")
            row["takts"] = suggest_next_takts(prev) if prev else "1. – 4. t."
        elif kind == ROW_DRAWING:
            drawings = self.owner.work["drawings"]
            used = placed_drawings(self.owner.work)
            free = [d for d in drawings if d["id"] not in used]
            row = {"k": kind, "zid": (free[0] if free else drawings[-1])["id"] if drawings else None}
        self.rows.insert(index, row)
        self.current = index
        self.focus_after = index
        self.owner.touch()
        self.build()

    def move_row(self, i, d):
        j = i + d
        if not (0 <= j < len(self.rows)):
            return
        self.rows[i], self.rows[j] = self.rows[j], self.rows[i]
        self.current = j
        self.owner.touch()
        self.build()

    def delete_row(self, i):
        row = self.rows[i]
        if (row.get("text") or "").strip() and not messagebox.askyesno(
                "Dzēst rindu", "Dzēst šo rindu kopā ar tās tekstu?", parent=self):
            return
        del self.rows[i]
        self.current = min(i, len(self.rows) - 1) if self.rows else None
        self.last_text = None
        self.owner.touch()
        self.build()


# --------------------------------------------------------------------------
# The description editor
# --------------------------------------------------------------------------
HEAD, GROUP_PARTS, GROUP_MOVES, GROUP_DRAWINGS = "head", "g:parts", "g:moves", "g:drawings"


class WorkEditor(tk.Frame):
    def __init__(self, app, parent, wid, loaded):
        super().__init__(parent, bg=CREAM)
        self.app, self.wid = app, wid
        self.work = loaded["work"]
        self.stamp = (loaded["updated_at"], loaded["updated_by"])
        self.saved_json = dump_work(self.work)
        self.readonly = not can_edit()
        self.current = None
        self.rows_editor = None
        self.drawing_editor = None

        # -- top bar ---------------------------------------------------------------------------
        top = tk.Frame(self, bg=CREAM)
        top.pack(fill="x", padx=20, pady=(12, 8))
        ttk.Button(top, text="◂ Visi apraksti", command=self.app.close_editor).pack(side="left")
        self.outline_button = ttk.Button(top, text="", command=self.toggle_outline)
        self.outline_button.pack(side="left", padx=(8, 0))
        self.title_label = tk.Label(top, text="", bg=CREAM, fg=NAVY, font=("Georgia", 16, "bold"), anchor="w")
        self.title_label.pack(side="left", padx=(14, 8))
        self.status_holder = tk.Frame(top, bg=CREAM)
        self.status_holder.pack(side="left")
        right = tk.Frame(top, bg=CREAM)
        right.pack(side="right")
        self.pdf_button = ttk.Button(right, text="⎙ PDF…", command=self.export)
        if not self.readonly:
            self.save_button = ttk.Button(right, text="💾 Saglabāt", style="Accent.TButton", command=self.save)
            self.save_button.pack(side="right")
        else:
            self.save_button = None
            tk.Label(right, text="🔒 tikai skatīšanai", bg=CREAM, fg=RED, font=("Segoe UI", 9, "bold")).pack(
                side="right", padx=(8, 0))
        self.pdf_button.pack(side="right", padx=(0, 8))
        ttk.Button(right, text="👁 Skatīt pārlūkā", command=lambda: preview_in_browser(self.work)).pack(
            side="right", padx=(0, 8))
        ttk.Button(right, text="📖 Apzīmējumi", command=lambda: LegendWindow(self)).pack(side="right", padx=(0, 8))
        self.state_label = tk.Label(self, text="", bg=CREAM, fg=MUTED, font=FONT_SMALL, anchor="e")
        self.state_label.pack(fill="x", padx=22)

        # -- body: outline + pane ---------------------------------------------------------------
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=(4, 14))
        left = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightthickness=1, width=270)
        left.pack(side="left", fill="y", padx=(0, 14))
        left.pack_propagate(False)
        self.outline = left
        tk.Label(left, text="Apraksta daļas", bg=WHITE, fg=NAVY, font=("Georgia", 12, "bold"), anchor="w").pack(
            fill="x", padx=12, pady=(10, 6))
        tk.Frame(left, bg=LINE_SOFT, height=1).pack(fill="x")
        if not self.readonly:
            btns = tk.Frame(left, bg=WHITE)
            btns.pack(side="bottom", fill="x", padx=8, pady=8)
            row1 = tk.Frame(btns, bg=WHITE)
            row1.pack(fill="x")
            for text, cmd in (("＋ Gājiens", self.add_part), ("＋ Kustība", self.add_move),
                              ("＋ Zīmējums", self.add_drawing)):
                ttk.Button(row1, text=text, command=cmd).pack(side="left", padx=(0, 4), fill="x", expand=True)
            row2 = tk.Frame(btns, bg=WHITE)
            row2.pack(fill="x", pady=(6, 0))
            for text, cmd in (("▲", lambda: self.move_item(-1)), ("▼", lambda: self.move_item(1)),
                              ("⧉ Kopēt", self.copy_item)):
                ttk.Button(row2, text=text, command=cmd, width=4 if len(text) == 1 else 8).pack(side="left",
                                                                                               padx=(0, 4))
            ttk.Button(row2, text="✕ Dzēst", style="Danger.TButton", command=self.delete_item).pack(side="right")
        self.tree = ttk.Treeview(left, show="tree", selectmode="browse")
        self.tree.pack(fill="both", expand=True, padx=4, pady=4)
        self.tree.tag_configure("group", font=("Segoe UI", 9, "bold"), foreground=MUTED)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.pane = tk.Frame(body, bg=CREAM)
        self.pane.pack(side="left", fill="both", expand=True)
        self.show_outline(not getattr(self.app, "outline_hidden", False))

        top_win = self.winfo_toplevel()
        self._save_key = top_win.bind("<Control-s>", lambda e: self.save() if self.winfo_exists() else None, add="+")
        self.bind("<Destroy>", self.on_destroy)
        self.build_tree(HEAD)
        self.touch()

    # ---- the outline can be hidden (more room for the drawing) -------------------------------
    def show_outline(self, visible):
        if visible:
            if not self.outline.winfo_manager():
                self.outline.pack(side="left", fill="y", padx=(0, 14), before=self.pane)
            self.outline_button.configure(text="◧ Paslēpt daļu sarakstu")
        else:
            self.outline.pack_forget()
            self.outline_button.configure(text="☰ Rādīt daļu sarakstu")
        self.app.outline_hidden = not visible

    def toggle_outline(self):
        self.show_outline(getattr(self.app, "outline_hidden", False))

    def step_drawing(self, delta):
        """◂ / ▸ in a drawing: the previous / next drawing (also when the outline is hidden)."""
        lst, obj = self.item(self.current or "")
        if obj is None or not (self.current or "").startswith("d:"):
            return
        i = lst.index(obj) + delta
        if 0 <= i < len(lst):
            iid = f"d:{lst[i]['id']}"
            self.tree.selection_set(iid)
            self.tree.see(iid)
            self.show_pane(iid)

    def on_destroy(self, event):
        if event.widget is self:
            try:
                self.winfo_toplevel().unbind("<Control-s>", self._save_key)
            except tk.TclError:
                pass

    # ---- outline -------------------------------------------------------------------------
    def part_text(self, p):
        title = (p.get("title") or "").strip() or "Bez nosaukuma"
        return title + (f" ({p['variant'].strip()})" if (p.get("variant") or "").strip() else "")

    def build_tree(self, select=None):
        t = self.tree
        t.delete(*t.get_children())
        t.insert("", "end", iid=HEAD, text="  Galvene un ievads")
        t.insert("", "end", iid=GROUP_PARTS, text="GĀJIENI", open=True, tags=("group",))
        for p in self.work["parts"]:
            t.insert(GROUP_PARTS, "end", iid=f"p:{p['id']}", text=self.part_text(p))
        t.insert("", "end", iid=GROUP_MOVES, text="KUSTĪBU APRAKSTS", open=True, tags=("group",))
        for m in self.work["moves"]:
            t.insert(GROUP_MOVES, "end", iid=f"m:{m['id']}", text=move_title(self.work, m))
        t.insert("", "end", iid=GROUP_DRAWINGS, text="ZĪMĒJUMI", open=True, tags=("group",))
        for d in self.work["drawings"]:
            t.insert(GROUP_DRAWINGS, "end", iid=f"d:{d['id']}", text=drawing_label(d))
        if select is None or not t.exists(select):
            select = HEAD
        self.current = None
        t.selection_set(select)
        t.see(select)
        self.show_pane(select)

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if sel and sel[0] != self.current:
            self.show_pane(sel[0])

    def item(self, iid):
        """(list, dict) for an outline id, or (None, None)."""
        if not iid or ":" not in iid or iid.startswith("g:"):
            return None, None
        kind, num = iid.split(":", 1)
        lst = {"p": self.work["parts"], "m": self.work["moves"], "d": self.work["drawings"]}[kind]
        try:
            num = int(num)
        except ValueError:
            return None, None
        return lst, next((x for x in lst if x.get("id") == num), None)

    # ---- panes ----------------------------------------------------------------------------
    def show_pane(self, iid):
        for child in self.pane.winfo_children():
            child.destroy()
        self.current = iid
        self.rows_editor = None
        self.drawing_editor = None
        try:
            if iid == HEAD:
                self.head_pane()
            elif iid.startswith("g:"):
                self.group_pane(iid)
            elif iid.startswith("p:"):
                self.part_pane(self.item(iid)[1])
            elif iid.startswith("m:"):
                self.move_pane(self.item(iid)[1])
            elif iid.startswith("d:"):
                self.drawing_pane(self.item(iid)[1])
        except Exception:
            log_error(traceback.format_exc())
            tk.Label(self.pane, text=f"Šo daļu neizdevās parādīt. Detaļas: {ERROR_LOG}", bg=CREAM, fg=RED).pack(
                pady=30)

    def entry_field(self, parent, row, label, obj, key, hint="", width=48, values=None):
        tk.Label(parent, text=label, bg=WHITE, fg=NAVY, font=FONT).grid(row=row, column=0, sticky="nw", pady=4,
                                                                       padx=(0, 12))
        var = tk.StringVar(value=str(obj.get(key, "") or ""))
        if values is not None:
            widget = ttk.Combobox(parent, textvariable=var, values=values, width=width - 2)
        else:
            widget = ttk.Entry(parent, textvariable=var, width=width)
        widget.grid(row=row, column=1, sticky="w", pady=4)
        if self.readonly:
            widget.state(["disabled"])
        if hint:
            izskats.note(parent, hint, bg=WHITE).grid(row=row, column=2, sticky="w", padx=(10, 0))

        def changed(*_):
            obj[key] = var.get()
            self.touch()
        var.trace_add("write", changed)
        return widget

    def text_field(self, parent, obj, key, height=4, italic=False):
        text = tk.Text(parent, height=height, wrap="word", font=("Segoe UI", 10, "italic") if italic else FONT,
                       relief="flat", bd=0, highlightthickness=1, highlightbackground=FIELD_LINE,
                       highlightcolor=NAVY, padx=8, pady=6, undo=True, fg=NAVY, insertbackground=NAVY)
        text.insert("1.0", obj.get(key, "") or "")

        def changed(_e=None):
            new = text.get("1.0", "end-1c")
            if new != obj.get(key, ""):
                obj[key] = new
                self.touch()
        text.bind("<KeyRelease>", changed)
        text.bind("<<Paste>>", lambda e: self.after(10, changed))
        if self.readonly:
            text.configure(state="disabled")
        return text

    def card(self, title, subtitle=""):
        outer = tk.Frame(self.pane, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        outer.pack(fill="x")
        inner = tk.Frame(outer, bg=WHITE)
        inner.pack(fill="x", padx=18, pady=12)
        tk.Label(inner, text=title, bg=WHITE, fg=NAVY, font=("Georgia", 14, "bold"), anchor="w").pack(fill="x")
        if subtitle:
            izskats.note(inner, subtitle, bg=WHITE, wrap=820).pack(fill="x", pady=(2, 6))
        grid = tk.Frame(inner, bg=WHITE)
        grid.pack(fill="x", pady=(4, 0))
        return outer, grid

    def head_pane(self):
        w = self.work
        outer, grid = self.card("Galvene un ievads", "Tā sākas apraksts: nosaukums lieliem burtiem un zem tā "
                                "rindas vidū. Ievadā — dejas raksturs un sižets, izmantotie soļi, pirmais "
                                "iestudējums, gājienu skaits, mūzikas daļas un taktsmērs, sākuma nostāšanās.")
        self.entry_field(grid, 0, "Dejas nosaukums", w, "title")
        self.entry_field(grid, 1, "Sastāvs", w, "lineup", "piem., Deja 8 pāriem")
        self.entry_field(grid, 2, "Horeogrāfs, apraksts", w, "author", "piem., Gunas Trukšānes horeogrāfija un "
                                                                        "apraksts")
        self.entry_field(grid, 3, "Mūzika", w, "music", "piem., Tautas mūzika Valda Muktupāvela apdarē")
        tk.Label(grid, text="Statuss", bg=WHITE, fg=NAVY, font=FONT).grid(row=4, column=0, sticky="w", pady=4)
        status = tk.StringVar(value=w.get("status", STATUS_DRAFT))

        def status_changed():
            w["status"] = status.get()
            self.touch()
        seg = izskats.Segmented(grid, [(s, s) for s in STATUSES], status, command=status_changed)
        seg.grid(row=4, column=1, sticky="w", pady=4)
        if self.readonly:
            for lbl in seg.labels.values():
                lbl.unbind("<Button-1>")
        box = tk.Frame(self.pane, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        box.pack(fill="both", expand=True, pady=(12, 0))
        tk.Label(box, text="Ievads", bg=WHITE, fg=NAVY, font=("Georgia", 12, "bold"), anchor="w").pack(
            fill="x", padx=14, pady=(10, 0))
        izskats.note(box, "Katra rindkopa — jaunā rindā (PDF failā tā sāksies ar atkāpi).", bg=WHITE).pack(
            fill="x", padx=14)
        intro = self.text_field(box, w, "intro", height=10)
        intro.pack(fill="both", expand=True, padx=14, pady=(6, 8))
        tk.Label(box, text="Piezīmes sev (PDF failā netiek iekļautas)", bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 8, "bold"), anchor="w").pack(fill="x", padx=14)
        notes = self.text_field(box, w, "notes", height=3)
        notes.pack(fill="x", padx=14, pady=(2, 12))

    def group_pane(self, iid):
        texts = {
            GROUP_PARTS: ("Gājieni", "Gājieni ir apraksta galvenā daļa: virsraksts (Ievads, Pirmais gājiens …), "
                          "variants, mūzikas daļas un taktis, tad rindas pa taktīm.", "＋ Pievienot gājienu",
                          self.add_part),
            GROUP_MOVES: ("Kustību apraksts", "Kustības, uz kurām gājienos atsaucas (“izpilda 2. kustību”). PDF "
                          "failā tās ir aiz gājieniem, sadaļā “Kustību apraksts”; numurē pēc kārtas.",
                          "＋ Pievienot kustību", self.add_move),
            GROUP_DRAWINGS: ("Zīmējumi", "Dejas zīmējumi uz skatuves plāna. Zīmējumu ievieto gājiena rindās ar "
                             "“＋ Zīmējums”; tie, kas nav ievietoti tekstā, PDF failā būs beigās sadaļā "
                             "“Zīmējumi”.", "＋ Jauns zīmējums", self.add_drawing)}
        title, text, button, cmd = texts[iid]
        outer, grid = self.card(title, text)
        if not self.readonly:
            ttk.Button(grid, text=button, style="Accent.TButton", command=cmd).pack(anchor="w", pady=(4, 6))

    def part_pane(self, part):
        if part is None:
            return
        outer, grid = self.card(self.part_text(part))
        title_cb = self.entry_field(grid, 0, "Virsraksts", part, "title", width=30, values=PART_TITLES)
        self.entry_field(grid, 1, "Variants", part, "variant", "piem., 4 pāru variants (nav obligāts)", width=30)
        self.entry_field(grid, 2, "Mūzika un taktis", part, "music", "piem., I, II / 16 t. x 2  — PDF failā "
                                                                     "iekavās", width=30)
        title_cb.bind("<<ComboboxSelected>>", lambda e: self.touch())
        tk.Frame(self.pane, bg=CREAM, height=10).pack(fill="x")
        self.rows_editor = RowsEditor(self.pane, self, part.setdefault("rows", []), self.readonly)
        self.rows_editor.pack(fill="both", expand=True)

    def move_pane(self, move):
        if move is None:
            return
        outer, grid = self.card(move_title(self.work, move), "Zem virsraksta PDF failā: “Mūzikas I daļa”, "
                                "“Mūzikas taktsmērs 2/4”, “Kustību izpilda puiši 4 t.”, tad sākuma stāvoklis.")
        self.entry_field(grid, 0, "Mūzikas daļa", move, "music", "piem., I vai II (tukšs — nerāda)", width=12)
        self.entry_field(grid, 1, "Taktsmērs", move, "meter", width=12, values=METERS)
        self.entry_field(grid, 2, "Izpilda", move, "who", "tukšs — “Kustību izpilda 4 t.”", width=20,
                         values=PERFORMERS)
        self.entry_field(grid, 3, "Taktis (skaits)", move, "bars", "piem., 4", width=12)
        tk.Label(grid, text="Sākuma stāvoklis", bg=WHITE, fg=NAVY, font=FONT).grid(row=4, column=0, sticky="nw",
                                                                                  pady=4)
        start = self.text_field(grid, move, "start", height=3)
        start.grid(row=4, column=1, columnspan=2, sticky="we", pady=4)
        grid.columnconfigure(2, weight=1)
        tk.Frame(self.pane, bg=CREAM, height=10).pack(fill="x")
        self.rows_editor = RowsEditor(self.pane, self, move.setdefault("rows", []), self.readonly)
        self.rows_editor.pack(fill="both", expand=True)

    def drawing_pane(self, drawing):
        if drawing is None:
            return
        top = tk.Frame(self.pane, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        top.pack(fill="x", pady=(0, 8))
        inner = tk.Frame(top, bg=WHITE)
        inner.pack(fill="x", padx=14, pady=8)
        drawings = self.work["drawings"]
        pos = drawings.index(drawing) if drawing in drawings else 0
        prev_b = ttk.Button(inner, text="◂", width=3, command=lambda: self.step_drawing(-1))
        prev_b.pack(side="left")
        tk.Label(inner, text=f"{pos + 1} / {len(drawings)}", bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="left",
                                                                                                padx=4)
        next_b = ttk.Button(inner, text="▸", width=3, command=lambda: self.step_drawing(1))
        next_b.pack(side="left", padx=(0, 14))
        if pos == 0:
            prev_b.state(["disabled"])
        if pos >= len(drawings) - 1:
            next_b.state(["disabled"])
        tk.Label(inner, text="Numurs", bg=WHITE, fg=NAVY, font=FONT).pack(side="left")
        no_var = tk.StringVar(value=str(drawing.get("no", "")))
        no = ttk.Entry(inner, textvariable=no_var, width=6)
        no.pack(side="left", padx=(6, 4))
        tk.Label(inner, text=". zīm.", bg=WHITE, fg=NAVY, font=FONT).pack(side="left")
        tk.Label(inner, text="Paraksts", bg=WHITE, fg=NAVY, font=FONT).pack(side="left", padx=(18, 6))
        cap_var = tk.StringVar(value=str(drawing.get("caption", "")))
        cap = ttk.Entry(inner, textvariable=cap_var, width=26)
        cap.pack(side="left")
        frame_var = tk.BooleanVar(value=bool(drawing.get("frame", True)))
        fr = ttk.Checkbutton(inner, text="Skatuves rāmis", variable=frame_var, style="White.TCheckbutton")
        fr.pack(side="left", padx=(18, 0))
        used = [self.part_text(p) for p in self.work["parts"]
                if any(r.get("k") == ROW_DRAWING and r.get("zid") == drawing["id"] for r in p.get("rows", []))]
        used += [move_title(self.work, m) for m in self.work["moves"]
                 if any(r.get("k") == ROW_DRAWING and r.get("zid") == drawing["id"] for r in m.get("rows", []))]
        izskats.note(inner, ("Ievietots: " + ", ".join(used)) if used else
                     "Nav ievietots tekstā — PDF failā būs beigās, sadaļā “Zīmējumi”.", bg=WHITE).pack(
            side="right")
        if self.readonly:
            for wdg in (no, cap, fr):
                wdg.state(["disabled"])

        def no_changed(*_):
            drawing["no"] = no_var.get().strip().rstrip(".")
            self.touch()

        def cap_changed(*_):
            drawing["caption"] = cap_var.get()
            self.touch()

        def frame_changed(*_):
            drawing["frame"] = bool(frame_var.get())
            self.touch()
            if self.drawing_editor is not None:
                self.drawing_editor.redraw()
        no_var.trace_add("write", no_changed)
        cap_var.trace_add("write", cap_changed)
        frame_var.trace_add("write", frame_changed)
        self.drawing_editor = DrawingEditor(self.pane, drawing, self.touch, readonly=self.readonly)
        self.drawing_editor.pack(fill="both", expand=True)

    # ---- changes ------------------------------------------------------------------------
    def dirty(self):
        return dump_work(self.work) != self.saved_json

    def touch(self):
        """After any change: titles in the outline, the save button, the state line."""
        try:
            self.title_label.configure(text=self.work.get("title") or "Bez nosaukuma")
            for child in self.status_holder.winfo_children():
                child.destroy()
            status = self.work.get("status", STATUS_DRAFT)
            bg, fg = STATUS_COLOURS.get(status, (SELECTED, NAVY))
            izskats.chip(self.status_holder, status, bg, fg).pack(side="left")
            cur = self.current or ""
            lst, obj = self.item(cur)
            if obj is not None and self.tree.exists(cur):
                if cur.startswith("p:"):
                    self.tree.item(cur, text=self.part_text(obj))
                elif cur.startswith("d:"):
                    self.tree.item(cur, text=drawing_label(obj))
            dirty = self.dirty()
            if self.save_button is not None:
                self.save_button.state(["!disabled"] if dirty else ["disabled"])
            when, who = self.stamp
            if dirty:
                text = "● Ir nesaglabātas izmaiņas (Ctrl+S — saglabāt)"
            else:
                text = f"Saglabāts {show_stamp(when)}" + (f" · {who}" if who else "")
            self.state_label.configure(text=text, fg=RED if dirty else MUTED)
        except tk.TclError:
            pass

    def save(self):
        """True when saved (or nothing to save)."""
        if self.readonly or not self.dirty():
            return True
        db = self.app.db
        try:
            current = db.stamp(self.wid)
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāšana", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return False
        if current is None:
            if not messagebox.askyesno("Saglabāšana", "Šis apraksts pa to laiku ir izdzēsts (cits lietotājs). "
                                                      "Saglabāt to no jauna?", parent=self):
                return False
            try:
                self.wid, when = db.create(self.work)
            except sqlite3.Error as exc:
                messagebox.showerror("Saglabāšana", f"Neizdevās saglabāt:\n{exc}", parent=self)
                return False
        else:
            if current[0] != self.stamp[0]:
                who = current[1] or "cits lietotājs"
                if not messagebox.askyesno(
                        "Saglabāšana", f"Kopš atvēršanas šo aprakstu ir saglabājis {who} ({show_stamp(current[0])})."
                                       "\n\nSaglabājot jūsu versija aizstās viņa izmaiņas. Saglabāt?", parent=self):
                    return False
            try:
                when = db.save(self.wid, self.work)
            except sqlite3.Error as exc:
                messagebox.showerror("Saglabāšana", f"Neizdevās saglabāt:\n{exc}", parent=self)
                return False
        self.stamp = (when, current_user_name())
        self.saved_json = dump_work(self.work)
        self.touch()
        return True

    def leave(self):
        """May the editor be closed? Asks about unsaved changes."""
        if self.readonly or not self.dirty():
            return True
        answer = messagebox.askyesnocancel("Nesaglabātas izmaiņas", f"Aprakstā “{self.work.get('title')}” ir "
                                           "nesaglabātas izmaiņas.\n\nSaglabāt tās?", parent=self)
        if answer is None:
            return False
        if answer:
            return self.save()
        return True

    def export(self):
        def busy(on):
            self.pdf_button.state(["disabled"] if on else ["!disabled"])
            self.pdf_button.configure(text="⏳ Gatavo PDF…" if on else "⎙ PDF…")
        export_pdf(self, self.work, busy)

    # ---- outline buttons ---------------------------------------------------------------
    def insert_after_current(self, lst, obj, prefix):
        cur_list, cur = self.item(self.current or "")
        if cur_list is lst and cur is not None:
            lst.insert(lst.index(cur) + 1, obj)
        else:
            lst.append(obj)
        self.build_tree(f"{prefix}:{obj['id']}")
        self.touch()

    def add_part(self):
        self.insert_after_current(self.work["parts"], new_part(self.work), "p")

    def add_move(self):
        self.insert_after_current(self.work["moves"], new_move(self.work), "m")

    def add_drawing(self):
        drawings = self.work["drawings"]
        if not drawings:
            self.insert_after_current(drawings, new_drawing(self.work), "d")
            return
        _lst, cur = self.item(self.current or "")
        base = cur if (self.current or "").startswith("d:") and cur is not None else drawings[-1]
        menu = tk.Menu(self, tearoff=0, font=FONT)
        menu.add_command(label=f"Turpināt no {drawing_label(base)} (kopija, ko pārveidot)",
                         command=lambda: self.insert_after_current(
                             drawings, new_drawing(self.work, base.get("els"), base.get("frame", True)), "d"))
        menu.add_command(label="Tukšs zīmējums", command=lambda: self.insert_after_current(
            drawings, new_drawing(self.work), "d"))
        try:
            menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            menu.grab_release()

    def move_item(self, d):
        lst, obj = self.item(self.current or "")
        if obj is None:
            return
        i = lst.index(obj)
        j = i + d
        if not (0 <= j < len(lst)):
            return
        lst[i], lst[j] = lst[j], lst[i]
        self.build_tree(self.current)
        self.touch()

    def copy_item(self):
        cur = self.current or ""
        lst, obj = self.item(cur)
        if obj is None:
            return
        twin = copy.deepcopy(obj)
        twin["id"] = next_id(self.work)
        if cur.startswith("d:"):
            twin["no"] = next_drawing_no(self.work)
        elif cur.startswith("p:"):
            twin["title"] = (twin.get("title") or "") + " (kopija)"
        lst.insert(lst.index(obj) + 1, twin)
        self.build_tree(f"{cur[0]}:{twin['id']}")
        self.touch()

    def delete_item(self):
        cur = self.current or ""
        lst, obj = self.item(cur)
        if obj is None:
            return
        if cur.startswith("d:"):
            refs = sum(1 for item in self.work["parts"] + self.work["moves"] for r in item.get("rows", [])
                       if r.get("k") == ROW_DRAWING and r.get("zid") == obj["id"])
            extra = f"\n\nTas ir ievietots tekstā ({refs} vietās) — arī šīs vietas tiks izņemtas." if refs else ""
            if not messagebox.askyesno("Dzēst zīmējumu", f"Dzēst {drawing_label(obj)}?{extra}", parent=self):
                return
            for item in self.work["parts"] + self.work["moves"]:
                item["rows"] = [r for r in item.get("rows", []) if not (r.get("k") == ROW_DRAWING
                                                                       and r.get("zid") == obj["id"])]
        else:
            name = self.part_text(obj) if cur.startswith("p:") else move_title(self.work, obj)
            if not messagebox.askyesno("Dzēst", f"Dzēst “{name}” ar visām tā rindām?", parent=self):
                return
        i = lst.index(obj)
        lst.remove(obj)
        prefix = cur[0]
        nxt = f"{prefix}:{lst[min(i, len(lst) - 1)]['id']}" if lst else {"p": GROUP_PARTS, "m": GROUP_MOVES,
                                                                          "d": GROUP_DRAWINGS}[prefix]
        self.build_tree(nxt)
        self.touch()


# --------------------------------------------------------------------------
# The list of descriptions
# --------------------------------------------------------------------------
class WorksView(tk.Frame):
    def __init__(self, app, parent, tab):
        super().__init__(parent, bg=CREAM)
        self.app, self.tab = app, tab
        self.records = []
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=14)
        body.columnconfigure(0, weight=0, minsize=430)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        bar = tk.Frame(left, bg=WHITE)
        bar.pack(fill="x", padx=12, pady=10)
        izskats.search_box(bar, app.search, width=30).pack(side="left", fill="x", expand=True)
        tk.Frame(left, bg=LINE_SOFT, height=1).pack(fill="x")
        foot = tk.Frame(left, bg=WHITE)
        foot.pack(side="bottom", fill="x")
        self.count_var = tk.StringVar()
        tk.Label(foot, textvariable=self.count_var, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w").pack(
            fill="x", padx=12, pady=5)
        cols = ("title", "lineup", "status", "updated")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        for key, text, width in (("title", "Deja", 150), ("lineup", "Sastāvs", 100), ("status", "Statuss", 80),
                                 ("updated", "Mainīts", 90)):
            self.tree.heading(key, text=text, anchor="w")
            self.tree.column(key, width=width, anchor="w", stretch=key == "title")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        izskats.zebra(self.tree)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show(self.selected_id()))
        self.tree.bind("<Double-1>", lambda e: self.open())
        self.tree.bind("<Return>", lambda e: self.open())

        self.right = tk.Frame(body, bg=CREAM)
        self.right.grid(row=0, column=1, sticky="nsew")
        self.refresh()

    def selected_id(self):
        sel = self.tree.selection()
        try:
            return int(sel[0]) if sel else None
        except ValueError:
            return None

    def refresh(self, select=None):
        app = self.app
        try:
            records = app.db.works()
        except sqlite3.Error as exc:
            records = []
            messagebox.showerror("Datubāze", f"Aprakstus neizdevās nolasīt:\n{exc}", parent=self)
        app.update_header(records)
        wanted = TAB_STATUSES[self.tab]
        term = _norm(app.search.get())
        shown = []
        for r in records:
            if r["status"] not in wanted:
                continue
            w = r["work"]
            if term and term not in _norm(" ".join(str(w.get(k, "")) for k in ("title", "lineup", "author", "music",
                                                                               "intro"))):
                continue
            shown.append(r)
        self.records = shown
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(shown):
            w = r["work"]
            self.tree.insert("", "end", iid=str(r["id"]), values=(
                w.get("title") or "Bez nosaukuma", w.get("lineup", ""), r["status"],
                show_stamp(r["updated_at"])[:10]), tags=izskats.row_tags(i))
        ids = [r["id"] for r in shown]
        current = select if select in ids else (app.selected_id if app.selected_id in ids else
                                                (ids[0] if ids else None))
        app.selected_id = current
        word = "apraksts" if len(shown) % 10 == 1 and len(shown) % 100 != 11 else "apraksti"
        self.count_var.set(f"{len(shown)} {word}" + ("  ·  dubultklikšķis — atvērt" if shown else ""))
        if current is not None:
            self.tree.selection_set(str(current))
            self.tree.see(str(current))
        self.show(current)

    def show(self, wid):
        self.app.selected_id = wid
        for child in self.right.winfo_children():
            child.destroy()
        r = next((x for x in self.records if x["id"] == wid), None)
        if r is None:
            box = tk.Frame(self.right, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
            box.pack(fill="both", expand=True)
            text = ("Vēl nav neviena apraksta. Spiediet “＋ Jauns apraksts” augšā." if not self.records
                    else "Izvēlieties aprakstu sarakstā kreisajā pusē.")
            if not self.records and self.app.search.get():
                text = "Neviens apraksts neatbilst meklētajam."
            izskats.note(box, text, bg=WHITE).pack(padx=20, pady=30)
            return
        w = r["work"]
        acc_edit = can_edit()
        card = tk.Frame(self.right, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        card.pack(fill="both", expand=True)
        inner = tk.Frame(card, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=20, pady=16)
        top = tk.Frame(inner, bg=WHITE)
        top.pack(fill="x")
        tk.Label(top, text=(w.get("title") or "Bez nosaukuma").upper(), bg=WHITE, fg=NAVY,
                 font=("Georgia", 17, "bold"), anchor="w").pack(side="left")
        bg, fg = STATUS_COLOURS.get(r["status"], (SELECTED, NAVY))
        izskats.chip(top, r["status"], bg, fg).pack(side="left", padx=(12, 0))
        for key in ("lineup", "author", "music"):
            if (w.get(key) or "").strip():
                tk.Label(inner, text=w[key], bg=WHITE, fg=NAVY, font=FONT, anchor="w").pack(fill="x")
        facts = tk.Frame(inner, bg=WHITE)
        facts.pack(fill="x", pady=(12, 0))
        items = [("Gājieni", str(len(w["parts"]))), ("Kustības", str(len(w["moves"]))),
                 ("Zīmējumi", str(len(w["drawings"]))),
                 ("Pēdējās izmaiņas", show_stamp(r["updated_at"]) + (f" · {r['updated_by']}" if r["updated_by"]
                                                                       else ""))]
        for i, (k, v) in enumerate(items):
            facts.columnconfigure(i, weight=1, uniform="f")
            cell = tk.Frame(facts, bg=WHITE)
            cell.grid(row=0, column=i, sticky="nw")
            tk.Label(cell, text=k, bg=WHITE, fg=MUTED, font=("Segoe UI", 8), anchor="w").pack(anchor="w")
            tk.Label(cell, text=v, bg=WHITE, fg=NAVY, font=FONT, anchor="w").pack(anchor="w")
        if (w.get("intro") or "").strip():
            intro = w["intro"].strip()
            tk.Label(inner, text=intro[:420] + ("…" if len(intro) > 420 else ""), bg=WHITE, fg="#4A4535",
                     font=FONT_SMALL, anchor="w", justify="left", wraplength=640).pack(fill="x", pady=(12, 0))
        btns = tk.Frame(inner, bg=WHITE)
        btns.pack(fill="x", pady=(14, 0))
        ttk.Button(btns, text="Atvērt / labot" if acc_edit else "Atvērt", style="Accent.TButton",
                   command=self.open).pack(side="left")
        pdf = ttk.Button(btns, text="⎙ PDF…")
        pdf.configure(command=lambda: export_pdf(self, w, lambda on: pdf.state(["disabled"] if on else
                                                                            ["!disabled"])))
        pdf.pack(side="left", padx=(8, 0))
        ttk.Button(btns, text="👁 Skatīt pārlūkā", command=lambda: preview_in_browser(w)).pack(side="left",
                                                                                            padx=(8, 0))
        if acc_edit:
            ttk.Button(btns, text="Dzēst", style="Danger.TButton",
                       command=lambda: self.app.delete_work(r["id"])).pack(side="right")
            ttk.Button(btns, text="⧉ Kopēt", command=lambda: self.app.copy_work(r["id"])).pack(side="right",
                                                                                             padx=(0, 8))
        if w["drawings"]:
            tk.Label(inner, text="ZĪMĒJUMI", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold"), anchor="w").pack(
                fill="x", pady=(16, 4))
            grid = tk.Frame(inner, bg=WHITE)
            grid.pack(fill="x")
            for i, d in enumerate(w["drawings"][:8]):
                cell = tk.Frame(grid, bg=WHITE)
                cell.grid(row=i // 4, column=i % 4, padx=(0, 10), pady=(0, 8), sticky="n")
                cv = tk.Canvas(cell, width=150, height=96, bg=WHITE, highlightthickness=1,
                               highlightbackground=LINE_SOFT)
                cv.pack()
                render_on_canvas(cv, d, 4, 4, 142, 88)
                tk.Label(cell, text=drawing_label(d), bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "italic")).pack()
            if len(w["drawings"]) > 8:
                izskats.note(inner, f"… un vēl {len(w['drawings']) - 8}", bg=WHITE).pack(anchor="w")

    def open(self):
        wid = self.selected_id()
        if wid is not None:
            self.app.open_editor(wid)


# --------------------------------------------------------------------------
# The module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1280x840")
        root.minsize(1100, 700)
        root.configure(bg=CREAM)
        izskats.apply_style()
        self.editor = None
        self.view = None
        self.current_tab = None
        self.selected_id = None
        self.build_ui()

    @property
    def view_widget(self):
        """The open description (Pūrlāde asks it about unsaved changes before leaving the module)."""
        ed = self.editor
        try:
            return ed if ed is not None and ed.winfo_exists() else None
        except tk.TclError:
            return None

    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *a: self.refresh())
        self.header_right = izskats.module_header(
            self.root, MODULE_KEY, PROGRAM_NAME, f"Deju apraksti un zīmējumi · v{APP_VERSION}",
            on_logo=self.show_main, on_exit=None if self.on_exit is not None else self.root.destroy, tabs=True)
        if can_edit():
            izskats.header_button(self.header_right, "＋ Jauns apraksts", self.new_work, primary=True).pack(
                side="right", padx=(8, 0))
        else:
            tk.Label(self.header_right, text="🔒 tikai skatīšanai", bg=WHITE, fg=RED,
                     font=("Segoe UI", 9, "bold")).pack(side="right", padx=(0, 8))
        izskats.header_button(self.header_right, "📖 Apzīmējumi", lambda: LegendWindow(self)).pack(side="right")
        self.full_button = izskats.header_button(self.header_right, "⛶ Pa visu ekrānu", self.toggle_full_screen)
        self.full_button.pack(side="right", padx=(0, 8))
        self.full_screen = False
        self.hidden_side = None
        top = self.root.winfo_toplevel()
        self._esc_key = top.bind("<Escape>", lambda e: self.set_full_screen(False) if self.full_screen else None,
                                 add="+")
        self._f11_key = top.bind("<F11>", lambda e: self.toggle_full_screen(), add="+")
        self.header_right.bind("<Destroy>", self.on_content_destroy)
        self.tabs = self.header_right.tabs
        self.tab_labels = {}
        for key, text in ((TAB_ALL, "Visi apraksti"), (TAB_DRAFT, "Melnraksti"), (TAB_READY, "Gatavie")):
            self.tab_labels[key] = self.tabs.add(key, text, lambda k=key: self.open_tab(k))
        self.content = tk.Frame(self.root, bg=CREAM)
        self.content.pack(fill="both", expand=True)
        self.open_tab(TAB_ALL)

    # ---- views -------------------------------------------------------------------------
    # ---- pa visu ekrānu: Pūrlādes logs bez sānu joslas, pāri visam ekrānam --------------------
    def toggle_full_screen(self):
        self.set_full_screen(not self.full_screen)

    def set_full_screen(self, on):
        top = self.root.winfo_toplevel()
        if on == self.full_screen:
            return
        self.full_screen = on
        try:
            if on:
                for w in top.winfo_children():          # Pūrlādes sānu josla (ja modulis atvērts Pūrlādē)
                    if isinstance(w, izskats.Sidebar) and w.winfo_manager():
                        self.hidden_side = (w, w.pack_info())
                        w.pack_forget()
                top.attributes("-fullscreen", True)
            else:
                top.attributes("-fullscreen", False)
                if self.hidden_side is not None:
                    side, info = self.hidden_side
                    self.hidden_side = None
                    if side.winfo_exists():
                        others = [w for w in top.pack_slaves() if w is not side]
                        opts = {k: v for k, v in info.items() if k in ("side", "fill", "expand", "padx", "pady")}
                        side.pack(before=others[0], **opts) if others else side.pack(**opts)
        except tk.TclError:
            log_error(traceback.format_exc())
        try:
            self.full_button.configure(text="🗗 Iziet no pilnekrāna (Esc)" if on else "⛶ Pa visu ekrānu")
        except tk.TclError:
            pass

    def on_content_destroy(self, event):
        """Leaving the module (another module, the start page): back to the normal window."""
        if event.widget is self.header_right and self.full_screen:
            top = self.root.winfo_toplevel()
            self.full_screen = False
            try:
                top.attributes("-fullscreen", False)
                if self.hidden_side is not None and self.hidden_side[0].winfo_exists():
                    side, info = self.hidden_side
                    others = [w for w in top.pack_slaves() if w is not side]
                    opts = {k: v for k, v in info.items() if k in ("side", "fill", "expand", "padx", "pady")}
                    side.pack(before=others[0], **opts) if others else side.pack(**opts)
                self.hidden_side = None
            except tk.TclError:
                pass
        if event.widget is self.header_right:
            top = self.root.winfo_toplevel()
            for seq, fid in (("<Escape>", getattr(self, "_esc_key", None)), ("<F11>", getattr(self, "_f11_key", None))):
                if fid:
                    try:
                        top.unbind(seq, fid)
                    except tk.TclError:
                        pass

    def leave_editor(self):
        ed = self.view_widget
        if ed is None:
            self.editor = None
            return True
        if not ed.leave():
            return False
        self.editor = None
        return True

    def open_tab(self, key, select=None):
        if self.view_widget is None and key == self.current_tab and self.view is not None:
            return self.view
        if not self.leave_editor():
            return None
        for child in self.content.winfo_children():
            child.destroy()
        self.current_tab = key
        self.tabs.set_active(key)
        if select is not None:
            self.selected_id = select
        self.view = WorksView(self, self.content, key)
        self.view.pack(fill="both", expand=True)
        return self.view

    def show_main(self):
        if not self.leave_editor():
            return
        self.search.set("")
        self.current_tab = None
        self.open_tab(TAB_ALL)

    def refresh(self, select=None):
        if self.view is None or self.view_widget is not None:
            return
        try:
            self.view.refresh(select=select)
        except tk.TclError:
            pass

    def update_header(self, records):
        drafts = sum(1 for r in records if r["status"] == STATUS_DRAFT)
        word = "apraksts" if len(records) % 10 == 1 and len(records) % 100 != 11 else "apraksti"
        sub = self.header_right.subtitle
        if sub is not None:
            sub.configure(text=f"{len(records)} {word} · {drafts} melnrakstos · v{APP_VERSION}")
        self.tab_labels[TAB_DRAFT].configure(text=f"Melnraksti ({drafts})")

    def open_editor(self, wid):
        if not self.leave_editor():
            return
        try:
            loaded = self.db.load(wid)
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Aprakstu neizdevās nolasīt:\n{exc}", parent=self.root)
            return
        if loaded is None:
            messagebox.showinfo("Apraksts", "Šis apraksts vairs nav atrodams (iespējams, izdzēsts).",
                                parent=self.root)
            self.refresh()
            return
        for child in self.content.winfo_children():
            child.destroy()
        self.view = None
        self.tabs.set_active(None)
        self.selected_id = wid
        self.editor = WorkEditor(self, self.content, wid, loaded)
        self.editor.pack(fill="both", expand=True)

    def close_editor(self):
        ed = self.view_widget
        wid = ed.wid if ed is not None else self.selected_id
        if not self.leave_editor():
            return
        tab = self.current_tab or TAB_ALL
        self.current_tab = None
        self.open_tab(tab, select=wid)

    # ---- actions ------------------------------------------------------------------------
    def new_work(self):
        if not can_edit():
            return piekluve.deny(self.root, "Jūsu loma Jaunrades pūrā var tikai skatīties.")
        title = ask_text(self.root, "Jauns apraksts", "Dejas nosaukums:")
        if not title:
            return
        work = new_work(title)
        work["parts"].append(new_part(work))
        try:
            wid, _when = self.db.create(work)
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Aprakstu neizdevās izveidot:\n{exc}", parent=self.root)
            return
        if wid is None:
            self.refresh()
            return
        self.open_editor(wid)

    def copy_work(self, wid):
        loaded = self.db.load(wid)
        if loaded is None:
            return
        work = loaded["work"]
        title = ask_text(self.root, "Kopēt aprakstu", "Jaunā apraksta nosaukums:",
                         (work.get("title") or "") + " (kopija)")
        if not title:
            return
        work["title"] = title
        work["status"] = STATUS_DRAFT
        try:
            new_wid, _when = self.db.create(work)
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Aprakstu neizdevās nokopēt:\n{exc}", parent=self.root)
            return
        self.refresh(select=new_wid)

    def delete_work(self, wid):
        if not can_edit():
            return piekluve.deny(self.root, "Jūsu loma Jaunrades pūrā var tikai skatīties.")
        loaded = self.db.load(wid)
        if loaded is None:
            return
        title = loaded["work"].get("title") or "Bez nosaukuma"
        if not messagebox.askyesno("Dzēst aprakstu", f"Dzēst aprakstu “{title}” ar visiem tā zīmējumiem?\n\n"
                                                     "To nevarēs atjaunot (izņemot no rezerves kopijas).",
                                   parent=self.root):
            return
        try:
            self.db.delete(wid)
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Neizdevās dzēst:\n{exc}", parent=self.root)
            return
        if self.selected_id == wid:
            self.selected_id = None
        self.refresh()


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
