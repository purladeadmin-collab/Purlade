"""
Pūrlāde — Kolektīva vēsture (poga “Kolektīva vēsture” sākuma lapā)

Kolektīva hronoloģiskā vēsture no visiem moduļiem vienuviet:
    Dejas            – iestudētās dejas (Deju pūrs, lauks “Iestudēta”), pirmā reize koncertā vai skatē
    Koncerti, Skates – notikušie koncerti un skates ar programmu (Notikumu pūrs; atceltie netiek rādīti)
    Pasākumi         – kolektīva pasākumi (arī publicitātes pasākumi)
    Lomas            – kurš kad bijis vadītājs, repetitors un katrā lietotnes lomā (kopeja.HISTORY_ROLES — visas
                       lietotnes lomas, arī jaunas; tabula role_history; Kopas pūrā / lietotnē piešķirtās lomas
                       ierakstās automātiski, agrākos periodus ievada šeit; bez datuma — grupā “Datums nav zināms”)
    Dejotāji         – kad kurš pievienojies kolektīvam un kad izstājies (Kopas pūrs: “Iestājās (datums)” un
                       “Izstājās (datums)” — īstie datumi, nevis diena, kad tie ievadīti Pūrlādē; bez datuma — netiek rādīts)
    Mēģinājumi       – katras sezonas (1. septembris – 31. augusts) kopsavilkums no Cītības pūra: mēģinājumu skaits,
                       vidējais apmeklējums, koncertu un skašu skaits
    Citi notikumi    – pašu ievadīti ieraksti (dibināšana, jubilejas, braucieni, apbalvojumi …)
"""

import sqlite3
import tkinter as tk
from datetime import date
from tkinter import ttk, messagebox

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve
try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats


def may_edit_history():
    """Kolektīva vēsture is changed by the leaders, repetitors and the system administrator."""
    return piekluve.current().full


NO_HISTORY_RIGHTS = "Kolektīva vēsturi labo vadītājs, repetitors vai sistēmas administrators."

try:
    from moduli import kopeja
    from moduli.kopeja import CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY
except ImportError:
    import kopeja
    from kopeja import CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY

AMBER = "#B07D00"
PURPLE = "#7A5C99"
TEAL = "#2E7D7A"

KIND_CONCERT = "Koncerts"
KIND_REVIEW = "Skate"
KIND_EVENT = kopeja.EVENT_KIND_GROUP
REHEARSAL_KINDS = ("Mēģinājums", "Papildmēģinājums")
CAME = ("Ieradās", "Nokavēja")
ST_CANCELLED = "Atcelts"

CAT_DANCE = "Dejas"
CAT_CONCERT = "Koncerti"
CAT_REVIEW = "Skates"
CAT_EVENT = "Pasākumi"
CAT_ROLE = "Lomas"
CAT_PEOPLE = "Dejotāji"
CAT_SEASON = "Mēģinājumi"
CAT_OTHER = "Citi notikumi"
CATEGORIES = [CAT_DANCE, CAT_CONCERT, CAT_REVIEW, CAT_EVENT, CAT_ROLE, CAT_PEOPLE, CAT_SEASON, CAT_OTHER]
CAT_COLOUR = {CAT_DANCE: "#2B6CB0", CAT_CONCERT: RED, CAT_REVIEW: AMBER, CAT_EVENT: GREEN, CAT_ROLE: PURPLE,
              CAT_PEOPLE: TEAL, CAT_SEASON: "#C4703A", CAT_OTHER: NAVY}
CAT_LABEL = {CAT_DANCE: "Deja", CAT_CONCERT: "Koncerts", CAT_REVIEW: "Skate", CAT_EVENT: "Pasākums",
             CAT_ROLE: "Loma", CAT_PEOPLE: "Dejotāji", CAT_SEASON: "Sezona", CAT_OTHER: "Notikums"}
UNDATED = "Datums nav zināms"   # timeline group of entries without a date (shown with “Visi gadi”)
EVENT_CAT = {KIND_CONCERT: CAT_CONCERT, KIND_REVIEW: CAT_REVIEW, KIND_EVENT: CAT_EVENT}

ALL_GROUPS = "Visas grupas"
ALL_YEARS = "Visi gadi"
NO_DATE = "nav zināms"
STILL = "joprojām"


def show_date(iso):
    """'2026-10-31' -> '31.10.2026' (empty / unknown -> '')."""
    try:
        y, m, d = (iso or "").split("-")
        return f"{int(d):02d}.{int(m):02d}.{int(y):04d}"
    except ValueError:
        return ""


def valid_iso(text):
    return bool(show_date(text))


def years_months(start, end):
    """Length of a period: '3 g. 2 mēn.' (empty when the start is unknown)."""
    if not valid_iso(start):
        return ""
    s = date.fromisoformat(start)
    e = date.fromisoformat(end) if valid_iso(end) else date.today()
    months = (e.year - s.year) * 12 + e.month - s.month - (1 if e.day < s.day else 0)
    if months < 0:
        return ""
    if months == 0:
        return "< 1 mēn."
    y, m = divmod(months, 12)
    parts = ([f"{y} g."] if y else []) + ([f"{m} mēn."] if m or not y else [])
    return " ".join(parts)


def count_text(n, one, many):
    """count_text(1, 'koncerts', 'koncerti') -> '1 koncerts'; 21 -> '21 koncerts'; 11 -> '11 koncerti'"""
    return f"{n} {one}" if n % 10 == 1 and n % 100 != 11 else f"{n} {many}"


def dancers_text(n):
    """1 dejotājs, 2 dejotāji, 21 dejotājs, 11 dejotāji"""
    return f"{n} dejotājs" if n % 10 == 1 and n % 100 != 11 else f"{n} dejotāji"


def _has_table(con, name):
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def _columns(con, table):
    return {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}


# --------------------------------------------------------------------------
# Data: every entry of the timeline
# --------------------------------------------------------------------------
class Entry:
    def __init__(self, day, cat, title, details="", groups=None, source=None, sort=0):
        self.day = day            # ISO date
        self.cat = cat
        self.title = title
        self.details = details    # longer text for the detail panel
        self.groups = groups      # None = all groups / not group related; else set of groups
        self.source = source      # ("entry", id) / ("role", id) — what can be edited
        self.sort = sort          # order inside one day


def collect(con, include_planned=False, today=None):
    """All timeline entries (unsorted). Events after today only when include_planned."""
    today = today or date.today().isoformat()
    entries = []
    dances = {}
    if _has_table(con, "dances"):
        cols = _columns(con, "dances")
        group_col = "dance_group" if "dance_group" in cols else "''"
        for did, title, choreo, dtype, prod, learned, status, group in con.execute(
                f"SELECT id, title, choreographer, dance_type, production, learned_date, status, {group_col} "
                "FROM dances").fetchall():
            dances[did] = {"title": title or "", "choreo": choreo or "", "type": dtype or "", "prod": prod or "",
                           "learned": learned or "", "status": status or "", "group": (group or "").strip()}

    # ---- events (Notikumu pūrs) ----
    first_show = {}   # dance id -> (date, event label) of the first concert / review
    if _has_table(con, "attendance_sessions"):
        details_cols = _columns(con, "event_details") if _has_table(con, "event_details") else set()
        sel = {c: (f"ed.{c}" if c in details_cols else "''") for c in ("status", "place", "subkind", "for_groups")}
        rows = con.execute(
            f"SELECT s.id, s.session_date, s.kind, s.title, s.start_time, {sel['status']}, {sel['place']}, "
            f"{sel['subkind']}, {sel['for_groups']} FROM attendance_sessions s "
            "LEFT JOIN event_details ed ON ed.session_id = s.id WHERE s.kind IN (?, ?, ?) ORDER BY s.session_date",
            (KIND_CONCERT, KIND_REVIEW, KIND_EVENT)).fetchall()
        programme = {}
        if _has_table(con, "event_program"):
            for sid, did in con.execute("SELECT session_id, dance_id FROM event_program ORDER BY session_id, "
                                        "position, id").fetchall():
                programme.setdefault(sid, []).append(did)
        came = {}
        if _has_table(con, "attendance"):
            for sid, n in con.execute("SELECT session_id, COUNT(*) FROM attendance WHERE mark IN ('Ieradās', "
                                      "'Nokavēja') GROUP BY session_id").fetchall():
                came[sid] = n
        coming = {}
        if _has_table(con, "event_participants"):
            for sid, n in con.execute("SELECT session_id, COUNT(*) FROM event_participants WHERE answer='Būs' "
                                      "GROUP BY session_id").fetchall():
                coming[sid] = n
        for sid, day, kind, title, start, status, place, subkind, groups in rows:
            if not valid_iso(day) or (status or "") == ST_CANCELLED:
                continue
            planned = day > today
            if planned and not include_planned:
                continue
            cat = EVENT_CAT[kind]
            name = (title or "").strip() or kind
            label = name if kind == KIND_EVENT else f"{kind} “{name}”" if title else kind
            if kind == KIND_EVENT and (subkind or "").strip():
                label = f"{subkind}: {name}" if name != kind else subkind
            text = label + (f" — {place.strip()}" if (place or "").strip() else "")
            if planned:
                text += "  (plānots)"
            lines = [f"{kind}" + (f" · {subkind}" if (subkind or "").strip() else ""),
                     f"Datums: {show_date(day)}" + (f", plkst. {start}" if (start or "").strip() else "")]
            if (place or "").strip():
                lines.append(f"Vieta: {place.strip()}")
            lines.append(f"Grupas: {kopeja.groups_label(groups)}")
            if (status or "").strip():
                lines.append(f"Statuss: {'Noticis' if not planned else status}")
            if sid in came:
                lines.append(f"Piedalījās: {dancers_text(came[sid])}")
            elif sid in coming:
                lines.append(f"Pieteikušies (Būs): {dancers_text(coming[sid])}")
            prog = [dances[d]["title"] for d in programme.get(sid, []) if d in dances]
            if prog:
                lines.append("")
                lines.append("Programma:")
                lines.extend(f"  {i}. {t}" for i, t in enumerate(prog, 1))
            if not planned and kind in (KIND_CONCERT, KIND_REVIEW):
                for d in programme.get(sid, []):
                    if d in dances and d not in first_show:
                        first_show[d] = (day, label)
            group_set = set(kopeja.event_groups(groups)) or None
            entries.append(Entry(day, cat, text, "\n".join(lines), group_set, ("event", sid), sort=2))

    # ---- dances (Deju pūrs) ----
    for did, d in dances.items():
        if not valid_iso(d["learned"]):
            # no “Iestudēta” date: the dance enters the history on its first concert / review, else undated
            what = d["type"] + (f": {d['prod']}" if d["prod"] else "")
            lines = [f"Deja “{d['title']}”", "Iestudēšanas datums Deju pūrā nav norādīts."]
            if d["choreo"]:
                lines.append(f"Horeogrāfs: {d['choreo']}")
            if what:
                lines.append(f"Veids: {what}")
            if d["group"]:
                lines.append(f"Grupa: {d['group']}")
            if d["status"]:
                lines.append(f"Statuss tagad: {d['status']}")
            groups = {d["group"]} if d["group"] else None
            if did in first_show:
                day, label = first_show[did]
                lines.append(f"Pirmo reizi dejota: {show_date(day)}, {label}")
                entries.append(Entry(day, CAT_DANCE, f"Pirmo reizi uz skatuves: deja “{d['title']}” ({label})",
                                     "\n".join(lines), groups, ("dance", did), sort=1))
            else:
                entries.append(Entry("", CAT_DANCE, f"Deja “{d['title']}”"
                                     + (f" (horeogrāfs {d['choreo']})" if d["choreo"] else ""),
                                     "\n".join(lines), groups, ("dance", did), sort=1))
            continue
        what = d["type"] + (f": {d['prod']}" if d["prod"] else "")
        lines = [f"Deja “{d['title']}”", f"Iestudēta: {show_date(d['learned'])}"]
        if d["choreo"]:
            lines.append(f"Horeogrāfs: {d['choreo']}")
        if what:
            lines.append(f"Veids: {what}")
        if d["group"]:
            lines.append(f"Grupa: {d['group']}")
        if d["status"]:
            lines.append(f"Statuss tagad: {d['status']}")
        if did in first_show:
            day, label = first_show[did]
            lines.append(f"Pirmo reizi dejota: {show_date(day)}, {label}")
        title = f"Iestudēta deja “{d['title']}”" + (f" (horeogrāfs {d['choreo']})" if d["choreo"] else "")
        entries.append(Entry(d["learned"], CAT_DANCE, title, "\n".join(lines),
                             {d["group"]} if d["group"] else None, ("dance", did), sort=1))

    # ---- roles ----
    for period in role_periods(con):
        rid, role, name, start, end, notes = (period[k] for k in ("id", "role", "name", "start", "end", "notes"))
        lines = [f"{role}: {name}", f"No: {show_date(start) or NO_DATE}", f"Līdz: {show_date(end) or STILL}"]
        length = years_months(start, end)
        if length:
            lines.append(f"Ilgums: {length}")
        if notes:
            lines.append(f"Piezīmes: {notes}")
        detail = "\n".join(lines)
        if valid_iso(start) and (include_planned or start <= today):
            entries.append(Entry(start, CAT_ROLE, f"{role} — {name}: sāk pildīt lomu"
                                 + (f" (līdz {show_date(end)})" if valid_iso(end) else ""), detail,
                                 None, ("role", rid), sort=0))
        if valid_iso(end) and (include_planned or end <= today):
            entries.append(Entry(end, CAT_ROLE, f"{role} — {name}: beidz pildīt lomu"
                                 + (f" (no {show_date(start)})" if valid_iso(start) else ""), detail,
                                 None, ("role", rid), sort=0))
        if not valid_iso(start) and not valid_iso(end):   # e.g. present role holders written down the first time
            entries.append(Entry("", CAT_ROLE, f"{role} — {name}: pilda lomu (kopš kura laika — nav zināms)",
                                 detail, None, ("role", rid), sort=0))

    # ---- seasons (Cītības pūrs): rehearsals and attendance, 1 September – 31 August ----
    entries.extend(season_entries(con, today))

    # ---- dancers who joined (one entry per day) ----
    joined = {}
    for first, last, join, group in con.execute(
            "SELECT first_name, last_name, join_date, dancer_group FROM dancers WHERE "
            + kopeja.dancer_role_sql("dancers") + " ORDER BY last_name, first_name").fetchall():
        if valid_iso(join) and join <= today:
            joined.setdefault(join, []).append((kopeja.full_name(first, last), (group or "").strip()))
    for day, people in joined.items():
        names = [n for n, _g in people]
        title = (f"Kolektīvam pievienojas {names[0]}" if len(names) == 1 else
                 f"Kolektīvam pievienojas {len(names)} dejotāji: " + ", ".join(names[:4])
                 + (" …" if len(names) > 4 else ""))
        detail = f"Pievienojās {show_date(day)}:\n" + "\n".join(
            f"  • {n}" + (f" (grupa {g})" if g else "") for n, g in people)
        groups = {g or kopeja.DEFAULT_DANCER_GROUP for _n, g in people}
        entries.append(Entry(day, CAT_PEOPLE, title, detail, groups, ("people", day), sort=3))

    # ---- dancers who left (Kopas pūrs → “Izstājās (datums)”; Pūrlāde v0.9.13) ----
    left = {}
    if "left_date" in {r[1] for r in con.execute("PRAGMA table_info(dancers)")}:
        for first, last, day, group in con.execute(
                "SELECT first_name, last_name, left_date, dancer_group FROM dancers WHERE status=? AND "
                + kopeja.dancer_role_sql("dancers") + " ORDER BY last_name, first_name",
                (kopeja.STATUS_LEFT,)).fetchall():
            if valid_iso(day) and day <= today:
                left.setdefault(day, []).append((kopeja.full_name(first, last), (group or "").strip()))
    for day, people in left.items():
        names = [n for n, _g in people]
        title = (f"Kolektīvu atstāj {names[0]}" if len(names) == 1 else
                 f"Kolektīvu atstāj {len(names)} dejotāji: " + ", ".join(names[:4]) + (" …" if len(names) > 4 else ""))
        detail = f"Izstājās {show_date(day)}:\n" + "\n".join(
            f"  • {n}" + (f" (grupa {g})" if g else "") for n, g in people)
        groups = {g or kopeja.DEFAULT_DANCER_GROUP for _n, g in people}
        entries.append(Entry(day, CAT_PEOPLE, title, detail, groups, ("people_left", day), sort=3))

    # ---- entered by hand ----
    if _has_table(con, "history_entries"):
        for eid, day, title, desc in con.execute(
                "SELECT id, entry_date, title, description FROM history_entries").fetchall():
            if not valid_iso(day) or (day > today and not include_planned):
                continue
            entries.append(Entry(day, CAT_OTHER, title, f"{title}\n{show_date(day)}"
                                 + (f"\n\n{desc}" if (desc or "").strip() else ""), None, ("entry", eid), sort=0))
    return entries


def season_of(day):
    """'2026-10-31' -> 2026 (season 2026/2027); January–August belong to the season that began the year before."""
    y, m = int(day[:4]), int(day[5:7])
    return y if m >= 9 else y - 1


def season_entries(con, today):
    """One entry per season: number of rehearsals (Mēģinājums, Papildmēģinājums), average attendance, concerts and
    reviews. Only days up to today; the running season says “līdz šim”."""
    if not _has_table(con, "attendance_sessions"):
        return []
    came = {}
    if _has_table(con, "attendance"):
        for sid, n in con.execute("SELECT session_id, COUNT(*) FROM attendance WHERE mark IN (?, ?) "
                                  "GROUP BY session_id", CAME).fetchall():
            came[sid] = n
    cancelled = set()
    if _has_table(con, "event_details"):
        cancelled = {sid for (sid,) in con.execute("SELECT session_id FROM event_details WHERE status=?",
                                                  (ST_CANCELLED,)).fetchall()}
    seasons = {}
    for sid, day, kind in con.execute("SELECT id, session_date, kind FROM attendance_sessions").fetchall():
        if not valid_iso(day) or day > today or sid in cancelled:
            continue
        info = seasons.setdefault(season_of(day), {"rehearsals": 0, "extra": 0, "marked": [], "concerts": 0,
                                                    "reviews": 0, "events": 0, "first": day, "last": day})
        info["first"], info["last"] = min(info["first"], day), max(info["last"], day)
        if kind in REHEARSAL_KINDS:
            info["rehearsals"] += 1
            if kind == REHEARSAL_KINDS[1]:
                info["extra"] += 1
            if sid in came:
                info["marked"].append(came[sid])
        elif kind == KIND_CONCERT:
            info["concerts"] += 1
        elif kind == KIND_REVIEW:
            info["reviews"] += 1
        elif kind == KIND_EVENT:
            info["events"] += 1
    result = []
    for year, info in seasons.items():
        if not (info["rehearsals"] or info["concerts"] or info["reviews"]):
            continue
        running = season_of(today) == year
        name = f"Sezona {year}/{year + 1}" + (" (līdz šim)" if running else "")
        parts = [count_text(info["rehearsals"], "mēģinājums", "mēģinājumi")] if info["rehearsals"] else []
        if info["marked"]:
            avg = round(sum(info["marked"]) / len(info["marked"]))
            parts.append(f"vidēji {count_text(avg, 'dejotājs', 'dejotāji')} mēģinājumā")
        if info["concerts"]:
            parts.append(count_text(info["concerts"], "koncerts", "koncerti"))
        if info["reviews"]:
            parts.append(count_text(info["reviews"], "skate", "skates"))
        lines = [name, f"Laiks: {show_date(info['first'])} – {show_date(info['last'])}",
                 f"Mēģinājumi: {info['rehearsals']}" + (f" (t. sk. papildmēģinājumi: {info['extra']})"
                                                         if info["extra"] else "")]
        if info["marked"]:
            lines.append(f"Apmeklējums atzīmēts {len(info['marked'])} mēģinājumos; vidēji ieradās "
                         f"{sum(info['marked']) / len(info['marked']):.1f}, visvairāk {max(info['marked'])}, "
                         f"vismazāk {min(info['marked'])}")
        lines.append(f"Koncerti: {info['concerts']}, skates: {info['reviews']}, kolektīva pasākumi: {info['events']}")
        lines.append("(no Cītības pūra un Notikumu pūra; atceltie notikumi netiek skaitīti)")
        result.append(Entry(info["last"], CAT_SEASON, name + ": " + ", ".join(parts), "\n".join(lines),
                            None, ("season", year), sort=4))
    return result


def role_periods(con):
    """All role periods: [{id, dancer_id, role, name, start, end, notes, auto}] (name from Kopas pūrs when linked)."""
    if not _has_table(con, "role_history"):
        return []
    result = []
    for rid, did, person, role, start, end, notes, auto, first, last in con.execute(
            "SELECT r.id, r.dancer_id, r.person, r.role, r.start_date, r.end_date, r.notes, r.auto, "
            "d.first_name, d.last_name FROM role_history r LEFT JOIN dancers d ON d.id = r.dancer_id").fetchall():
        name = kopeja.full_name(first, last) if did is not None and (first or last) else (person or "").strip()
        result.append({"id": rid, "dancer_id": did, "role": role, "name": name or "—", "start": start or "",
                       "end": end or "", "notes": (notes or "").strip(), "auto": auto})
    return result


# --------------------------------------------------------------------------
# Timeline at the top of the window (Pūrlāde v0.9)
# --------------------------------------------------------------------------
MONTHS_SHORT = ["janv.", "febr.", "marts", "apr.", "maijs", "jūn.", "jūl.", "aug.", "sept.", "okt.", "nov.", "dec."]
LINE, LINE_SOFT, MUTED = izskats.LINE, izskats.LINE_SOFT, izskats.MUTED


class TimelineStrip(tk.Frame):
    """A horizontal time axis with one row (lane) per kind of entry; every dated entry of the timeline below is a
    coloured dot. Pointing at a dot shows what it is, a click selects it in the list below. With “Visi gadi” the
    axis shows all years, with one year chosen — that year by months."""
    LEFT, RIGHT, TOP, LANE, AXIS = 100, 18, 18, 15, 24

    def __init__(self, master, window):
        super().__init__(master, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        self.window = window
        self.entries, self.year, self.selected = [], None, None
        self.dots = {}   # canvas item -> Entry
        head = tk.Frame(self, bg=WHITE)
        head.pack(fill="x", padx=14, pady=(8, 0))
        tk.Label(head, text="Laika līnija", font=("Georgia", 12, "bold"), bg=WHITE, fg=NAVY).pack(side="left")
        self.range_lbl = tk.Label(head, text="", font=("Segoe UI", 9), bg=WHITE, fg=MUTED)
        self.range_lbl.pack(side="left", padx=(10, 0))
        self.info = tk.Label(head, text="", font=("Segoe UI", 9, "bold"), bg=WHITE, fg=NAVY, anchor="e")
        self.info.pack(side="right")
        height = self.TOP + self.LANE * len(CATEGORIES) + self.AXIS
        self.canvas = tk.Canvas(self, height=height, bg=WHITE, highlightthickness=0)
        self.canvas.pack(fill="x", padx=6, pady=(4, 6))
        self.canvas.bind("<Configure>", lambda e: self.draw())
        self.canvas.bind("<Leave>", lambda e: self.show_info(None))

    def set_entries(self, entries, year=None):
        self.entries = [e for e in entries if e.day]
        self.year = year
        self.draw()

    # ---- drawing --------------------------------------------------------------------
    def span(self):
        """(first day, last day) of the axis."""
        if self.year:
            y = int(self.year)
            return date(y, 1, 1), date(y, 12, 31)
        years = [int(e.day[:4]) for e in self.entries] + [date.today().year]
        return date(min(years), 1, 1), date(max(years), 12, 31)

    def x_of(self, day, start, end, width):
        total = (end - start).days or 1
        return self.LEFT + (day - start).days / total * width

    def draw(self):
        c = self.canvas
        c.delete("all")
        self.dots = {}
        w = c.winfo_width()
        if w < 200:
            return
        width = w - self.LEFT - self.RIGHT
        start, end = self.span()
        bottom = self.TOP + self.LANE * len(CATEGORIES)
        # lanes
        for i, cat in enumerate(CATEGORIES):
            y = self.TOP + i * self.LANE + self.LANE / 2
            if i % 2:
                c.create_rectangle(self.LEFT, y - self.LANE / 2, w - self.RIGHT, y + self.LANE / 2,
                                   fill="#FBF8F0", outline="")
            c.create_text(self.LEFT - 10, y, text=cat, anchor="e", fill=CAT_COLOUR[cat], font=("Segoe UI", 8, "bold"))
        # ticks: years (all years) or months (one year)
        if self.year:
            ticks = [(date(start.year, m, 1), MONTHS_SHORT[m - 1], m == 1) for m in range(1, 13)]
            step = 1
        else:
            ticks = [(date(y, 1, 1), str(y), True) for y in range(start.year, end.year + 1)]
            per_year = width / max(1, len(ticks))
            step = next(s for s in (1, 2, 5, 10, 20, 50, 100) if per_year * s >= 38)
        for n, (day, label, strong) in enumerate(ticks):
            x = self.x_of(day, start, end, width)
            c.create_line(x, self.TOP, x, bottom + 4, fill=LINE if strong else LINE_SOFT)
            if n % step == 0:
                item = c.create_text(x + 3, bottom + 6, text=label, anchor="nw", fill=MUTED, font=("Segoe UI", 8))
                if not self.year:   # a click on a year: that year by months
                    c.tag_bind(item, "<Button-1>", lambda ev, y=label: self.window.zoom_year(y))
                    c.tag_bind(item, "<Enter>", lambda ev, i=item: c.itemconfigure(i, fill=NAVY))
                    c.tag_bind(item, "<Leave>", lambda ev, i=item: c.itemconfigure(i, fill=MUTED))
        if self.year:
            item = c.create_text(self.LEFT - 10, bottom + 6, text="← visi gadi", anchor="ne", fill=NAVY,
                                 font=("Segoe UI", 8, "bold"))
            c.tag_bind(item, "<Button-1>", lambda ev: self.window.zoom_year(None))
        c.create_line(self.LEFT, bottom, w - self.RIGHT, bottom, fill=LINE)
        # today
        today = date.today()
        if start <= today <= end:
            x = self.x_of(today, start, end, width)
            c.create_line(x, self.TOP - 2, x, bottom + 4, fill=GOLD, width=2)
            c.create_text(x, self.TOP - 9, text="šodien", fill="#A8841A", font=("Segoe UI", 8, "bold"))
        # dots (selected one last, so that it is on top)
        lane = {cat: i for i, cat in enumerate(CATEGORIES)}
        for e in sorted(self.entries, key=lambda e: e is self.selected):
            try:
                day = date.fromisoformat(e.day)
            except ValueError:
                continue
            if not start <= day <= end:
                continue
            x = self.x_of(day, start, end, width)
            y = self.TOP + lane.get(e.cat, len(CATEGORIES) - 1) * self.LANE + self.LANE / 2
            r = 6 if e is self.selected else 4
            item = c.create_oval(x - r, y - r, x + r, y + r, fill=CAT_COLOUR.get(e.cat, NAVY),
                                 outline=NAVY if e is self.selected else WHITE, width=2 if e is self.selected else 1)
            self.dots[item] = e
            c.tag_bind(item, "<Enter>", lambda ev, e=e: self.show_info(e))
            c.tag_bind(item, "<Button-1>", lambda ev, e=e: self.window.select_entry(e))
            c.tag_bind(item, "<Double-1>", lambda ev, e=e: self.window.edit_entry())
        c.configure(cursor="hand2" if self.dots else "")
        shown = sum(1 for e in self.dots.values())
        self.range_lbl.configure(text=(f"{self.year}. gads pa mēnešiem" if self.year else
                                       f"{start.year}–{end.year}") + f" · {shown} ieraksti ar datumu")

    def mark(self, entry):
        if entry is not self.selected:
            self.selected = entry
            self.draw()
        self.show_info(entry)

    def show_info(self, entry):
        entry = entry or self.selected
        if entry is None:
            self.info.configure(text="Norādiet uz punktu — redzēsiet, kas tas ir; klikšķis atrod to sarakstā; "
                                     "klikšķis uz gada — tā mēneši" if not self.year else
                                "Norādiet uz punktu — redzēsiet, kas tas ir; klikšķis atrod to sarakstā",
                                fg=MUTED, font=("Segoe UI", 9))
            return
        title = entry.title if len(entry.title) <= 90 else entry.title[:88] + "…"
        self.info.configure(text=f"{show_date(entry.day)} · {CAT_LABEL[entry.cat]} · {title}",
                            fg=CAT_COLOUR.get(entry.cat, NAVY), font=("Segoe UI", 9, "bold"))


# --------------------------------------------------------------------------
# Window
# --------------------------------------------------------------------------
class HistoryWindow(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Kolektīva vēsture")
        self.geometry("1200x860")
        self.minsize(960, 660)
        self.configure(bg=CREAM)
        self.transient(root)
        self.con = kopeja.connect_db()
        try:
            self.con.execute("PRAGMA foreign_keys = ON")
        except sqlite3.Error:
            pass
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        kopeja.ensure_dancer_schema(self.con)
        try:
            kopeja.sync_role_history(self.con)
        except Exception:
            import traceback
            kopeja.log_error(traceback.format_exc())
        self.entries = []
        self.items = {}       # tree item -> Entry
        self.role_items = {}  # tree item -> role period dict
        self.build()
        self.refresh()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda e: self.close())
        self.focus_set()

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass
        self.destroy()

    # ---- layout -------------------------------------------------------------
    def build(self):
        # Pūrlāde v0.9: baltā virsraksta josla, augšā laika līnija, apakšā — hronoloģija un lomas kā līdz šim
        izskats.dialog_header(self, "Kolektīva vēsture",
                              kopeja.read_setting("app.group_name", "Tautas deju kolektīvs")
                              + " · dejas, koncerti, skates, pasākumi, lomas un dejotāji no visiem moduļiem",
                              colour=GOLD, wrap=1000)
        bottom = izskats.dialog_footer(self)
        ttk.Button(bottom, text="Aizvērt", style="Accent.TButton", command=self.close).pack(side="right")
        self.summary = tk.Label(bottom, text="", font=("Segoe UI", 9), bg=WHITE, fg=MUTED, anchor="w")
        self.summary.pack(side="left", fill="x", expand=True)

        self.strip = TimelineStrip(self, self)
        self.strip.pack(fill="x", padx=14, pady=(12, 0))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=14, pady=(10, 0))
        self.build_timeline(self.tabs)
        self.build_roles(self.tabs)

    def build_timeline(self, tabs):
        page = tk.Frame(tabs, bg=CREAM)
        tabs.add(page, text="  Hronoloģija  ")

        filters = tk.Frame(page, bg=CREAM)
        filters.pack(fill="x", pady=(8, 4))
        self.cat_vars = {}
        for cat in CATEGORIES:
            var = tk.BooleanVar(value=True)
            self.cat_vars[cat] = var
            tk.Checkbutton(filters, text=cat, variable=var, command=self.fill_timeline, bg=CREAM, fg=CAT_COLOUR[cat],
                           activebackground=CREAM, selectcolor=WHITE, font=("Segoe UI", 10, "bold"),
                           cursor="hand2").pack(side="left", padx=(0, 6))

        row2 = tk.Frame(page, bg=CREAM)
        row2.pack(fill="x", pady=(0, 6))
        tk.Label(row2, text="Grupa:", bg=CREAM, fg=NAVY).pack(side="left")
        self.group_var = tk.StringVar(value=ALL_GROUPS)
        cb = ttk.Combobox(row2, textvariable=self.group_var, values=[ALL_GROUPS] + kopeja.DANCER_GROUPS,
                          state="readonly", width=13)
        cb.pack(side="left", padx=(4, 12))
        cb.bind("<<ComboboxSelected>>", lambda e: self.fill_timeline())
        tk.Label(row2, text="Gads:", bg=CREAM, fg=NAVY).pack(side="left")
        self.year_var = tk.StringVar(value=ALL_YEARS)
        self.year_cb = ttk.Combobox(row2, textvariable=self.year_var, values=[ALL_YEARS], state="readonly", width=10)
        self.year_cb.pack(side="left", padx=(4, 12))
        self.year_cb.bind("<<ComboboxSelected>>", lambda e: self.fill_timeline())
        tk.Label(row2, text="Meklēt:", bg=CREAM, fg=NAVY).pack(side="left")
        self.search_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.search_var, width=24).pack(side="left", padx=(4, 12))
        self.search_var.trace_add("write", lambda *a: self.fill_timeline())
        self.newest_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row2, text="Jaunākie augšā", variable=self.newest_var, command=self.fill_timeline, bg=CREAM,
                       fg=NAVY, activebackground=CREAM, selectcolor=WHITE).pack(side="left")
        self.planned_var = tk.BooleanVar(value=False)
        tk.Checkbutton(row2, text="Rādīt arī plānotos", variable=self.planned_var, command=self.refresh, bg=CREAM,
                       fg=NAVY, activebackground=CREAM, selectcolor=WHITE).pack(side="left", padx=(8, 0))
        b1 = ttk.Button(row2, text="Dzēst", command=self.delete_entry)
        b1.pack(side="right")
        b2 = ttk.Button(row2, text="Labot", command=self.edit_entry)
        b2.pack(side="right", padx=(0, 6))
        b3 = ttk.Button(row2, text="+ Pievienot notikumu", style="Accent.TButton",
                        command=lambda: self.entry_dialog(None))
        b3.pack(side="right", padx=(0, 6))
        if not may_edit_history():
            for b in (b1, b2, b3):
                b.configure(state="disabled")

        pane = tk.PanedWindow(page, orient="vertical", bg=CREAM, sashwidth=6, bd=0)
        pane.pack(fill="both", expand=True)
        top = tk.Frame(pane, bg=CREAM)
        self.tree = ttk.Treeview(top, columns=("date", "cat", "title"), show="tree headings", selectmode="browse")
        self.tree.heading("#0", text="Gads")
        self.tree.heading("date", text="Datums")
        self.tree.heading("cat", text="Veids")
        self.tree.heading("title", text="Notikums")
        self.tree.column("#0", width=150, stretch=False)
        self.tree.column("date", width=100, stretch=False, anchor="center")
        self.tree.column("cat", width=100, stretch=False)
        self.tree.column("title", width=700)
        sb = ttk.Scrollbar(top, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("year", font=("Georgia", 12, "bold"), foreground=RED, background=CREAM_DARK)
        for cat in CATEGORIES:
            self.tree.tag_configure(cat, foreground=CAT_COLOUR[cat])
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_details())
        self.tree.bind("<Double-1>", lambda e: self.edit_entry())
        pane.add(top, stretch="always", minsize=200)

        box = tk.Frame(pane, bg=CREAM)
        self.detail = tk.Text(box, wrap="word", bg=WHITE, fg=NAVY, relief="flat", bd=0, padx=14, pady=10,
                              highlightthickness=1, highlightbackground=LINE, font=("Segoe UI", 10), height=8,
                              cursor="arrow")
        self.detail.tag_configure("head", font=("Georgia", 12, "bold"), foreground=RED)
        self.detail.pack(fill="both", expand=True, pady=(6, 0))
        pane.add(box, stretch="never", minsize=90)
        self.empty_note = tk.Label(page, text="", font=("Segoe UI", 9, "italic"), bg=CREAM, fg=GREY, anchor="w")
        self.empty_note.pack(fill="x")

    def build_roles(self, tabs):
        page = tk.Frame(tabs, bg=CREAM)
        tabs.add(page, text="  Lomas  ")
        roles = ", ".join(r.lower() for r in kopeja.HISTORY_ROLES)
        tk.Label(page, text=f"Kurš kad bijis {roles} (kolektīva lomas un visas lietotnes lomas no Kopas pūra). "
                            "Lomas, ko piešķir Kopas pūrā (vai Kabatas Pūrlādē), "
                            "ierakstās automātiski: periods sākas dienā, kad loma piešķirta, un beidzas, kad tā "
                            "noņemta vai cilvēks izstājies. Agrākos periodus (arī cilvēkiem, kuru nav Kopas pūrā) "
                            "pievienojiet ar pogu “+ Pievienot lomas periodu”.",
                 font=("Segoe UI", 9, "italic"), bg=CREAM, fg=NAVY, justify="left", anchor="w",
                 wraplength=1080).pack(fill="x", pady=(8, 6))
        bar = tk.Frame(page, bg=CREAM)
        bar.pack(fill="x", pady=(0, 6))
        r1 = ttk.Button(bar, text="+ Pievienot lomas periodu", style="Accent.TButton",
                        command=lambda: self.role_dialog(None))
        r1.pack(side="left")
        r2 = ttk.Button(bar, text="Labot", command=self.edit_role)
        r2.pack(side="left", padx=6)
        r3 = ttk.Button(bar, text="Dzēst", command=self.delete_role)
        r3.pack(side="left")
        if not may_edit_history():
            for b in (r1, r2, r3):
                b.configure(state="disabled")
            tk.Label(bar, text="🔒 tikai skatīšanai", bg=CREAM, fg=RED,
                     font=("Segoe UI", 9, "bold")).pack(side="left", padx=(12, 0))

        frame = tk.Frame(page, bg=CREAM)
        frame.pack(fill="both", expand=True)
        self.role_tree = ttk.Treeview(frame, columns=("name", "start", "end", "length", "notes"),
                                      show="tree headings", selectmode="browse")
        for col, text, width, stretch in (("#0", "Loma", 230, False), ("name", "Vārds, uzvārds", 220, False),
                                          ("start", "No", 100, False), ("end", "Līdz", 100, False),
                                          ("length", "Ilgums", 110, False), ("notes", "Piezīmes", 300, True)):
            self.role_tree.heading(col, text=text)
            self.role_tree.column(col, width=width, stretch=stretch,
                                  anchor="center" if col in ("start", "end", "length") else "w")
        sb = ttk.Scrollbar(frame, orient="vertical", command=self.role_tree.yview)
        self.role_tree.configure(yscrollcommand=sb.set)
        self.role_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.role_tree.tag_configure("role", font=("Georgia", 12, "bold"), foreground=PURPLE, background=CREAM_DARK)
        self.role_tree.tag_configure("current", font=("Segoe UI", 10, "bold"))
        self.role_tree.bind("<Double-1>", lambda e: self.edit_role())

    # ---- data -----------------------------------------------------------------
    def refresh(self):
        try:
            self.entries = collect(self.con, include_planned=self.planned_var.get())
            self.periods = role_periods(self.con)
        except Exception:
            import traceback
            kopeja.log_error(traceback.format_exc())
            messagebox.showerror("Kolektīva vēsture", "Vēsturi neizdevās nolasīt.\n\nDetaļas saglabātas failā:\n"
                                 + kopeja.ERROR_LOG, parent=self)
            self.entries, self.periods = [], []
        years = sorted({e.day[:4] for e in self.entries if e.day}, reverse=True)
        self.year_cb.configure(values=[ALL_YEARS] + years)
        if self.year_var.get() not in [ALL_YEARS] + years:
            self.year_var.set(ALL_YEARS)
        self.fill_timeline()
        self.fill_roles()

    def visible_entries(self):
        cats = {c for c, v in self.cat_vars.items() if v.get()}
        group = self.group_var.get()
        year = self.year_var.get()
        words = [w for w in self.search_var.get().lower().split() if w]
        result = []
        for e in self.entries:
            if e.cat not in cats:
                continue
            if group != ALL_GROUPS and e.groups is not None and group not in e.groups:
                continue
            if year != ALL_YEARS and e.day[:4] != year:   # undated entries only with “Visi gadi”
                continue
            if words:
                text = (e.title + " " + e.details).lower()
                if not all(w in text for w in words):
                    continue
            result.append(e)
        newest = self.newest_var.get()
        result.sort(key=lambda e: (e.day, e.sort if not newest else -e.sort, e.title), reverse=newest)
        # entries without a date always at the end, in a group of their own
        return [e for e in result if e.day] + sorted((e for e in result if not e.day),
                                                     key=lambda e: (CATEGORIES.index(e.cat), e.title))

    def fill_timeline(self):
        self.tree.delete(*self.tree.get_children())
        self.items = {}
        shown = self.visible_entries()
        by_year = {}
        for e in shown:
            by_year.setdefault(e.day[:4] or UNDATED, []).append(e)
        for year, items in by_year.items():
            counts = {}
            for e in items:
                counts[e.cat] = counts.get(e.cat, 0) + 1
            label = ", ".join(f"{CAT_LABEL[c].lower()}: {n}" for c, n in
                              sorted(counts.items(), key=lambda x: CATEGORIES.index(x[0])))
            parent = self.tree.insert("", "end", text=year, values=("", "", label), open=True, tags=("year",))
            for e in items:
                iid = self.tree.insert(parent, "end", text="", values=(show_date(e.day), CAT_LABEL[e.cat], e.title),
                                       tags=(e.cat,))
                self.items[iid] = e
        year = self.year_var.get()
        self.strip.set_entries(shown, None if year == ALL_YEARS else year)
        totals = {c: sum(1 for e in shown if e.cat == c) for c in CATEGORIES}
        dances = totals[CAT_DANCE]
        self.summary.configure(text=f"Rādīti {len(shown)} ieraksti  ·  dejas: {dances}  ·  koncerti: "
                                    f"{totals[CAT_CONCERT]}  ·  skates: {totals[CAT_REVIEW]}  ·  pasākumi: "
                                    f"{totals[CAT_EVENT]}")
        missing = self.dances_without_date()
        self.empty_note.configure(
            text=(f"{missing} dejām Deju pūrā nav norādīts iestudēšanas datums (lauks “Iestudēta”) — tās rādītas "
                  f"pēc pirmās uzstāšanās koncertā vai skatē, citādi grupā “{UNDATED}”." if missing else "") if self.cat_vars[CAT_DANCE].get() else "")
        self.show_details()

    def zoom_year(self, year):
        """A year on the timeline was clicked (None — back to all years)."""
        self.year_var.set(year or ALL_YEARS)
        self.fill_timeline()

    def select_entry(self, entry):
        """A dot on the timeline was clicked: the same entry in the list below."""
        for iid, e in self.items.items():
            if e is entry:
                self.tabs.select(0)
                self.tree.selection_set(iid)
                self.tree.see(iid)
                self.tree.focus(iid)
                return

    def dances_without_date(self):
        if not _has_table(self.con, "dances"):
            return 0
        return sum(1 for (d,) in self.con.execute("SELECT learned_date FROM dances").fetchall() if not valid_iso(d))

    def show_details(self):
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        sel = self.tree.selection()
        e = self.items.get(sel[0]) if sel else None
        self.strip.mark(e)
        if e is None:
            self.detail.insert("end", "Izvēlieties ierakstu, lai redzētu sīkāku informāciju.")
        else:
            first, _, rest = e.details.partition("\n")
            self.detail.insert("end", first + "\n", "head")
            self.detail.insert("end", rest)
            if e.source and e.source[0] == "entry":
                self.detail.insert("end", "\n\n(pašu ievadīts ieraksts — to var labot vai dzēst)")
            elif e.source and e.source[0] == "role":
                self.detail.insert("end", "\n\n(lomas periodu var labot cilnē “Lomas”)")
        self.detail.configure(state="disabled")

    def fill_roles(self):
        self.role_tree.delete(*self.role_tree.get_children())
        self.role_items = {}
        by_role = {}
        for p in self.periods:
            by_role.setdefault(p["role"], []).append(p)
        order = kopeja.HISTORY_ROLES + sorted(set(by_role) - set(kopeja.HISTORY_ROLES))
        for role in order:
            periods = by_role.get(role, [])
            now = [p["name"] for p in periods if not p["end"]]
            parent = self.role_tree.insert("", "end", text=role, open=True, tags=("role",),
                                           values=(("tagad: " + ", ".join(now)) if now else "", "", "", "", ""))
            periods.sort(key=lambda p: (p["end"] == "", p["end"], p["start"]), reverse=True)
            for p in periods:
                iid = self.role_tree.insert(parent, "end", text="", tags=("current",) if not p["end"] else (),
                                            values=(p["name"], show_date(p["start"]) or NO_DATE,
                                                    show_date(p["end"]) or STILL, years_months(p["start"], p["end"]),
                                                    p["notes"]))
                self.role_items[iid] = p

    # ---- hand-entered events ----------------------------------------------------
    def selected_entry(self):
        sel = self.tree.selection()
        return self.items.get(sel[0]) if sel else None

    def edit_entry(self):
        e = self.selected_entry()
        if e is None:
            return
        kind = e.source[0] if e.source else ""
        if kind == "entry":
            self.entry_dialog(e.source[1])
        elif kind == "role":
            self.tabs.select(1)
            for iid, p in self.role_items.items():
                if p["id"] == e.source[1]:
                    self.role_tree.selection_set(iid)
                    self.role_tree.see(iid)
                    self.role_dialog(p)
                    break
        else:
            where = {"event": "Notikumu pūrā", "dance": "Deju pūrā", "people": "Kopas pūrā (dejotāja logā — “Iestājās (datums)”)",
                     "people_left": "Kopas pūrā (dejotāja logā — “Izstājās (datums)”)",
                     "season": "Cītības pūrā un Notikumu pūrā"}.get(kind, "")
            messagebox.showinfo("Kolektīva vēsture", f"Šis ieraksts ņemts no moduļa — to var mainīt {where}.",
                                parent=self)

    def delete_entry(self):
        if not may_edit_history():
            return piekluve.deny(self, NO_HISTORY_RIGHTS)
        e = self.selected_entry()
        if e is None:
            return
        if not e.source or e.source[0] != "entry":
            if e.source and e.source[0] == "role":
                messagebox.showinfo("Kolektīva vēsture", "Lomas periodu var dzēst cilnē “Lomas”.", parent=self)
            else:
                self.edit_entry()   # tells in which module it can be changed
            return
        if messagebox.askyesno("Dzēst", f"Dzēst ierakstu “{e.title}”?", parent=self):
            self.con.execute("DELETE FROM history_entries WHERE id=?", (e.source[1],))
            self.con.commit()
            self.refresh()

    def entry_dialog(self, entry_id):
        if not may_edit_history():
            return piekluve.deny(self, NO_HISTORY_RIGHTS)
        row = None
        if entry_id is not None:
            row = self.con.execute("SELECT entry_date, title, description FROM history_entries WHERE id=?",
                                   (entry_id,)).fetchone()
        dlg = Dialog(self, "Labot notikumu" if row else "Pievienot notikumu")
        day = dlg.entry("Datums (DD.MM.GGGG):", show_date(row[0]) if row else "", width=14)
        title = dlg.entry("Nosaukums:", row[1] if row else "", width=60)
        desc = dlg.text("Apraksts:", row[2] if row else "")
        dlg.hint("Piemēram: kolektīva dibināšana, jubileja, brauciens, apbalvojums, jauna grupa.")

        def save():
            parsed = kopeja.parse_date(day.get())
            if not parsed:
                messagebox.showwarning("Datums", "Norādiet datumu formātā DD.MM.GGGG, piemēram, 05.03.2001.",
                                       parent=dlg)
                return
            if not title.get().strip():
                messagebox.showwarning("Nosaukums", "Norādiet notikuma nosaukumu.", parent=dlg)
                return
            text = desc.get("1.0", "end").strip()
            if row:
                self.con.execute("UPDATE history_entries SET entry_date=?, title=?, description=? WHERE id=?",
                                 (parsed, title.get().strip(), text, entry_id))
            else:
                self.con.execute("INSERT INTO history_entries (entry_date, title, description, created) "
                                 "VALUES (?, ?, ?, ?)", (parsed, title.get().strip(), text, date.today().isoformat()))
            self.con.commit()
            dlg.destroy()
            self.refresh()
        dlg.buttons(save)

    # ---- role periods -------------------------------------------------------------
    def selected_role(self):
        sel = self.role_tree.selection()
        return self.role_items.get(sel[0]) if sel else None

    def edit_role(self):
        if not may_edit_history():
            return piekluve.deny(self, NO_HISTORY_RIGHTS)
        p = self.selected_role()
        if p is not None:
            self.role_dialog(p)

    def delete_role(self):
        if not may_edit_history():
            return piekluve.deny(self, NO_HISTORY_RIGHTS)
        p = self.selected_role()
        if p is None:
            return
        holders = kopeja.current_role_holders(self.con)
        if not p["end"] and p["dancer_id"] is not None and (p["dancer_id"], p["role"]) in holders:
            messagebox.showinfo("Dzēst", f"{p['name']} joprojām ir loma “{p['role']}” (Kopas pūrā), tāpēc šo "
                                         "periodu nevar dzēst — tas tiktu izveidots no jauna. Lai lomu beigtu, "
                                         "noņemiet to Kopas pūrā; datumus var labot ar pogu “Labot”.", parent=self)
            return
        if messagebox.askyesno("Dzēst", f"Dzēst periodu: {p['role']} — {p['name']}?", parent=self):
            self.con.execute("DELETE FROM role_history WHERE id=?", (p["id"],))
            self.con.commit()
            self.refresh()

    def people(self):
        """[(label, dancer id)] — everyone in Kopas pūrs (same names get the birth year)."""
        rows = self.con.execute("SELECT id, first_name, last_name, birth_date, status FROM dancers "
                                "ORDER BY first_name, last_name").fetchall()
        names = [kopeja.full_name(f, l) for _i, f, l, _b, _s in rows]
        result = []
        for (did, _f, _l, birth, _s), name in zip(rows, names):
            if names.count(name) > 1:
                name += f" ({(birth or '')[:4] or did})"
            result.append((name, did))
        return result

    def role_dialog(self, period):
        if not may_edit_history():
            return piekluve.deny(self, NO_HISTORY_RIGHTS)
        people = self.people()
        by_name = {n.lower(): did for n, did in people}
        name_of = {did: n for n, did in people}
        dlg = Dialog(self, "Labot lomas periodu" if period else "Pievienot lomas periodu")
        role = dlg.combo("Loma:", kopeja.HISTORY_ROLES, period["role"] if period else kopeja.APP_ROLE_PRESIDENT)
        start_name = (name_of.get(period["dancer_id"], period["name"]) if period else "")
        person = dlg.combo("Vārds, uzvārds:", [n for n, _d in people], start_name, editable=True)
        start = dlg.entry("No (DD.MM.GGGG):", show_date(period["start"]) if period else "", width=14)
        end = dlg.entry("Līdz (DD.MM.GGGG):", show_date(period["end"]) if period else "", width=14)
        notes = dlg.entry("Piezīmes:", period["notes"] if period else "", width=60)
        dlg.hint("Izvēlieties cilvēku no Kopas pūra vai ierakstiet vārdu (ja viņa Kopas pūrā nav). Tukšs “No” — "
                 "datums nav zināms; tukšs “Līdz” — lomu pilda joprojām.")

        def save():
            name = person.get().strip()
            if not name:
                messagebox.showwarning("Vārds", "Norādiet, kurš pildīja šo lomu.", parent=dlg)
                return
            s, e = kopeja.parse_date(start.get()), kopeja.parse_date(end.get())
            if s is None or e is None:
                messagebox.showwarning("Datums", "Datumus norādiet formātā DD.MM.GGGG, piemēram, 01.09.2019.",
                                       parent=dlg)
                return
            if s and e and e < s:
                messagebox.showwarning("Datums", "Beigu datums nevar būt agrāks par sākuma datumu.", parent=dlg)
                return
            r = role.get()
            did = by_name.get(name.lower())
            if not e and did is not None and (did, r) not in kopeja.current_role_holders(self.con):
                messagebox.showwarning(
                    "Līdz", f"Kopas pūrā cilvēkam {name} tagad nav lomas “{r}”. Norādiet, līdz kuram datumam viņš "
                            "to pildīja (vai vispirms piešķiriet lomu Kopas pūrā).", parent=dlg)
                return
            values = (did, name, r, s, e, notes.get().strip())
            if period:
                self.con.execute("UPDATE role_history SET dancer_id=?, person=?, role=?, start_date=?, end_date=?, "
                                 "notes=? WHERE id=?", values + (period["id"],))
            else:
                self.con.execute("INSERT INTO role_history (dancer_id, person, role, start_date, end_date, notes, "
                                 "auto) VALUES (?, ?, ?, ?, ?, ?, 0)", values)
            self.con.commit()
            dlg.destroy()
            self.refresh()
        dlg.buttons(save)


class Dialog(tk.Toplevel):
    """Small form window: label + field rows, then Saglabāt / Atcelt."""
    def __init__(self, parent, title):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=CREAM)
        self.transient(parent)
        self.resizable(False, False)
        izskats.dialog_header(self, title, colour=GOLD)   # Pūrlāde v0.9: jaunais izskats
        box = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        box.pack(fill="both", expand=True, padx=18, pady=14)
        self.form = tk.Frame(box, bg=WHITE)
        self.form.pack(fill="both", expand=True, padx=14, pady=10)
        self.row = 1
        self.first = None
        self.bind("<Escape>", lambda e: self.destroy())

    def _label(self, text):
        tk.Label(self.form, text=text, bg=WHITE, fg=NAVY).grid(row=self.row, column=0, sticky="nw", padx=(0, 8),
                                                               pady=4)

    def _place(self, widget):
        widget.grid(in_=self.form, row=self.row, column=1, sticky="w", pady=4)
        widget.lift()
        self.row += 1
        if self.first is None:
            self.first = widget

    def entry(self, label, value="", width=30):
        self._label(label)
        var = tk.StringVar(value=value)
        self._place(ttk.Entry(self, textvariable=var, width=width))
        return var

    def combo(self, label, values, value="", editable=False):
        self._label(label)
        var = tk.StringVar(value=value)
        self._place(ttk.Combobox(self, textvariable=var, values=values, width=40,
                                 state="normal" if editable else "readonly"))
        return var

    def text(self, label, value=""):
        self._label(label)
        widget = tk.Text(self, width=60, height=6, wrap="word", font=("Segoe UI", 10), bg=WHITE, fg=NAVY,
                         relief="flat", highlightthickness=1, highlightbackground=izskats.FIELD_LINE,
                         highlightcolor=NAVY, padx=6, pady=4)
        widget.insert("1.0", value or "")
        self._place(widget)
        return widget

    def hint(self, text):
        tk.Label(self.form, text=text, font=("Segoe UI", 9), bg=WHITE, fg=MUTED, justify="left",
                 wraplength=520).grid(row=self.row, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.row += 1

    def buttons(self, on_save):
        bar = izskats.dialog_footer(self)
        ttk.Button(bar, text="Atcelt", command=self.destroy).pack(side="right")
        ttk.Button(bar, text="Saglabāt", style="Accent.TButton", command=on_save).pack(side="right", padx=(0, 8))
        self.bind("<Return>", lambda e: on_save() if not isinstance(e.widget, tk.Text) else None)
        if self.first is not None:
            self.first.focus_set()
        self.grab_set()


def show(root):
    return HistoryWindow(root)
