"""
Pūrlāde — kolonnu izvēle visās tabulās

Ar labo peles taustiņu uzspiežot uz jebkuras tabulas kolonnas nosaukuma, atveras mazs logs, kurā var atzīmēt,
kuras kolonnas redzēt. Izvēle tiek atcerēta šajā datorā (fails kolonnas.json Pūrlādes iestatījumu mapē, blakus
datubāzes iestatījumiem) atsevišķi katrai tabulai, tāpēc nākamreiz tabula atveras ar tām pašām kolonnām.

Darbojas visos moduļos bez izmaiņām tajos: install() (to izsauc moduli/kopeja.py) papildina ttk.Treeview —
  * jaunai tabulai un katru reizi, kad modulis maina kolonnas (columns / displaycolumns), tiek pielietotas
    paslēptās kolonnas;
  * klases piesaiste <Button-3> visām tabulām atver izvēles logu, ja klikšķis ir uz kolonnu nosaukumiem.
Tabulas atslēga: loga virsraksts bez versiju numuriem + kolonnu identifikatori bez cipariem (lai tabulām ar
mainīgām kolonnām, piem., datumiem Cītības pūrā, izvēle saglabātos) + moduļa paša rādītās kolonnas, ja tās
atšķiras no visām (Tērpu pūrā divas tabulas ar vienādām kolonnām). Paslēptās kolonnas tiek glabātas kā
“paslēptās”, tāpēc jaunas kolonnas vienmēr parādās.
"""

import json
import os
import re
import tkinter as tk
from tkinter import ttk

try:
    from moduli import datubaze
except ImportError:
    import datubaze

CREAM = "#FFF8E7"
NAVY = "#1F2A44"
RED = "#9E1B32"
GOLD = "#C9A227"
WHITE = "#FFFFFF"
GREY = "#8C8C8C"

_installed = False
_saved = None          # {table key: [hidden column ids]}
_orig_init = ttk.Treeview.__init__
_orig_configure = ttk.Treeview.configure


def settings_path():
    return os.path.join(datubaze.config_dir(), "kolonnas.json")


def _load():
    global _saved
    if _saved is None:
        try:
            with open(settings_path(), encoding="utf-8") as fh:
                data = json.load(fh)
            _saved = data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            _saved = {}
    return _saved


def _store():
    try:
        os.makedirs(os.path.dirname(settings_path()), exist_ok=True)
        tmp = settings_path() + ".jauns"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(_saved or {}, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, settings_path())
    except OSError:
        pass   # the choice is then kept only until the program is closed


def _columns(tree):
    try:
        return [str(c) for c in tree.tk.splitlist(_orig_configure(tree, "columns")[4] or ())]
    except (tk.TclError, IndexError, TypeError):
        return []


def _display(tree):
    try:
        value = tree.tk.splitlist(_orig_configure(tree, "displaycolumns")[4] or ())
    except (tk.TclError, IndexError, TypeError):
        return []
    value = [str(c) for c in value]
    return _columns(tree) if not value or value == ["#all"] else value


def table_key(tree):
    """Window title without version numbers + column ids that have no digits."""
    try:
        title = tree.winfo_toplevel().title()
    except tk.TclError:
        title = ""
    title = re.sub(r"\s*v\d+(\.\d+)*", "", title).strip()
    all_cols = _columns(tree)
    cols = [c for c in all_cols if not re.search(r"\d", c)]
    key = f"{title}|{','.join(cols)}"
    default = getattr(tree, "_pur_default", None)
    if default and list(default) != all_cols:   # two tables with the same columns shown differently (Tērpu pūrs)
        key += "|" + ",".join(c for c in default if not re.search(r"\d", c))
    return key


def _base_order(tree):
    """The module's own column order: its displaycolumns (remembered), then the other columns."""
    cols = _columns(tree)
    default = [c for c in (getattr(tree, "_pur_default", None) or cols) if c in cols]
    return default, default + [c for c in cols if c not in default]


def apply(tree):
    """Show the module's columns minus the ones hidden for this table."""
    cols = _columns(tree)
    if not cols:
        return
    hidden = set(_load().get(table_key(tree), []))
    default, _all = _base_order(tree)
    shown_extra = set(_load().get(table_key(tree) + "|+", []))   # hidden by the module, shown by the person
    show = [c for c in _all if (c in default or c in shown_extra) and c not in hidden]
    if not show:
        show = default or cols
    tree._pur_applying = True
    try:
        _orig_configure(tree, displaycolumns=show)
    except tk.TclError:
        pass
    finally:
        tree._pur_applying = False


def _remember_default(tree, display_given):
    if display_given:
        tree._pur_default = _display(tree)
    else:   # new columns: Tk shows all of them
        tree._pur_default = _columns(tree)


def _patched_init(self, master=None, **kw):
    _orig_init(self, master, **kw)
    _remember_default(self, "displaycolumns" in kw)
    _bind_class(self)
    self.bind("<Map>", lambda e, t=self: _first_map(t), add="+")


def _first_map(tree):
    if not getattr(tree, "_pur_mapped", False):
        tree._pur_mapped = True   # the window title is known by now
        apply(tree)


def _patched_configure(self, cnf=None, **kw):
    result = _orig_configure(self, cnf, **kw)
    keys = set(kw)
    if isinstance(cnf, dict):
        keys |= set(cnf)
    if keys & {"columns", "displaycolumns"} and not getattr(self, "_pur_applying", False):
        _remember_default(self, "displaycolumns" in keys)
        apply(self)
    return result


def _bind_class(widget):
    root = widget._root()
    if getattr(root, "_pur_column_chooser", False):
        return
    root._pur_column_chooser = True
    root.bind_class("Treeview", "<Button-3>", _on_right_click, add="+")


def _on_right_click(event):
    tree = event.widget
    if not isinstance(tree, ttk.Treeview):
        return None
    try:
        region = tree.identify_region(event.x, event.y)
    except tk.TclError:
        return None
    if region not in ("heading", "separator"):
        return None
    open_chooser(tree, event.x_root, event.y_root)
    return "break"


def open_chooser(tree, x, y):
    """Small window at the mouse: a check box for every column (its heading text)."""
    cols = [c for c in _base_order(tree)[1]]
    names = {}
    for c in cols:
        try:
            names[c] = (tree.heading(c, "text") or "").strip()
        except tk.TclError:
            names[c] = ""
    cols = [c for c in cols if names[c]]   # columns without a heading (buttons, markers) are not offered
    if not cols:
        return
    key = table_key(tree)
    top = tree.winfo_toplevel()
    previous_grab = top.grab_current()
    win = tk.Toplevel(top)
    win.withdraw()
    win.overrideredirect(True)
    win.configure(bg=GOLD, padx=2, pady=2)
    body = tk.Frame(win, bg=WHITE, padx=10, pady=8)
    body.pack(fill="both", expand=True)
    tk.Label(body, text="Rādīt kolonnas", font=("Georgia", 11, "bold"), bg=WHITE, fg=RED).pack(anchor="w")
    shown = set(_display(tree))
    variables = {}

    def changed():
        visible = [c for c in cols if variables[c].get()]
        if not visible:   # at least one column stays
            variables[changed.last].set(True)
            return
        saved = _load()
        default = set(_base_order(tree)[0])
        saved[key] = [c for c in cols if not variables[c].get()]
        saved[key + "|+"] = [c for c in cols if variables[c].get() and c not in default]
        if not saved[key]:
            saved.pop(key, None)
        if not saved[key + "|+"]:
            saved.pop(key + "|+", None)
        _store()
        apply(tree)

    def toggle(c):
        changed.last = c
        changed()

    box = tk.Frame(body, bg=WHITE)
    box.pack(fill="both", expand=True, pady=(4, 6))
    per_column = 14   # long lists in several columns
    for i, c in enumerate(cols):
        variables[c] = tk.BooleanVar(value=c in shown)
        tk.Checkbutton(box, text=names[c], variable=variables[c], command=lambda c=c: toggle(c), bg=WHITE, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, anchor="w", font=("Segoe UI", 9),
                       cursor="hand2").grid(row=i % per_column, column=i // per_column, sticky="w", padx=(0, 10))

    def show_all():
        for c in cols:
            variables[c].set(True)
        saved = _load()
        saved.pop(key, None)
        saved[key + "|+"] = [c for c in cols if c not in set(_base_order(tree)[0])]
        if not saved[key + "|+"]:
            saved.pop(key + "|+", None)
        _store()
        apply(tree)

    def close(_e=None):
        if not win.winfo_exists():
            return
        try:
            win.grab_release()
        except tk.TclError:
            pass
        win.destroy()
        if previous_grab is not None:
            try:
                previous_grab.grab_set()
            except tk.TclError:
                pass

    bar = tk.Frame(body, bg=WHITE)
    bar.pack(fill="x")
    for text, cmd in (("Rādīt visas", show_all), ("Aizvērt", close)):
        tk.Button(bar, text=text, command=cmd, font=("Segoe UI", 9), bg=CREAM, fg=NAVY, activebackground=GOLD,
                  relief="flat", bd=0, highlightthickness=1, highlightbackground=GOLD, cursor="hand2",
                  padx=8, pady=1).pack(side="left", padx=(0, 6))
    tk.Label(body, text="Izvēle tiek atcerēta šajā datorā.", font=("Segoe UI", 8, "italic"), bg=WHITE,
             fg=GREY).pack(anchor="w", pady=(6, 0))

    def outside(event):
        wx, wy = win.winfo_rootx(), win.winfo_rooty()
        if not (wx <= event.x_root < wx + win.winfo_width() and wy <= event.y_root < wy + win.winfo_height()):
            close()

    win.update_idletasks()
    w, h = win.winfo_reqwidth(), win.winfo_reqheight()
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    win.geometry(f"+{max(0, min(x, sw - w - 4))}+{max(0, min(y, sh - h - 40))}")
    win.deiconify()
    win.lift()
    win.bind("<Escape>", close)
    win.bind("<Button-1>", outside, add="+")
    win.bind("<Button-3>", outside, add="+")
    try:
        win.grab_set()
    except tk.TclError:
        pass
    win.focus_set()


def install():
    """Extend ttk.Treeview once (called from moduli/kopeja.py)."""
    global _installed
    if _installed:
        return
    _installed = True
    ttk.Treeview.__init__ = _patched_init
    ttk.Treeview.configure = _patched_configure
    ttk.Treeview.config = _patched_configure
