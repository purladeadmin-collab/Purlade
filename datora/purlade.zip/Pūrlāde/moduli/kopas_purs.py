#!/usr/bin/env python3
"""
Pūrlāde — modulis "Kopas pūrs" (dejotāju uzskaitei un statistikai)

Šeit tiek ievadīti un uzturēti visi kolektīva dejotāji. Pārējie moduļi
(piemēram, Tērpu pūrs) dejotāju informāciju ņem no šejienes.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/kopas_purs.py
"""

import os
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox, filedialog

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo,
                               console_is_own, set_console_visible, ensure_dancer_schema, full_name,
                               parse_date, years_between, read_table, normalize_gender, _norm,
                               app_emails, app_email, check_app_email, set_app_email,
                               GENDERS, GENDER_MALE, GENDER_FEMALE, DANCER_STATUSES, STATUS_ACTIVE,
                               STATUS_INACTIVE, STATUS_LEFT, CLOTHING_SIZES, POWER_ICON_B64, PERSON_ROLES, ROLE_DANCER,
                               EXTRA_APP_ROLES, APP_ROLE_DANCER, DANCER_GROUPS, DEFAULT_DANCER_GROUP, app_roles_of, app_roles_text, parse_app_roles,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo,
                        console_is_own, set_console_visible, ensure_dancer_schema, full_name,
                        parse_date, years_between, read_table, normalize_gender, _norm,
                               app_emails, app_email, check_app_email, set_app_email,
                        GENDERS, GENDER_MALE, GENDER_FEMALE, DANCER_STATUSES, STATUS_ACTIVE,
                        STATUS_INACTIVE, STATUS_LEFT, CLOTHING_SIZES, POWER_ICON_B64, PERSON_ROLES, ROLE_DANCER,
                               EXTRA_APP_ROLES, APP_ROLE_DANCER, DANCER_GROUPS, DEFAULT_DANCER_GROUP, app_roles_of, app_roles_text, parse_app_roles,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

try:
    from moduli.vardadienas import name_day_text, name_day_sort_key, MONTHS
except ImportError:
    from vardadienas import name_day_text, name_day_sort_key, MONTHS

PROGRAM_NAME = "Kopas pūrs"
APP_VERSION = "0.1.12"
TEAL = "#2E7D6B"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Dejotāju uzskaite un statistika: sastāvs, stāžs, dalība",
    "letter": "K",
    "color": TEAL,
}

# table columns: key, heading, width
COLUMNS = [
    ("first_name", "Vārds", 110),
    ("last_name", "Uzvārds", 130),
    ("dancer_group", "Grupa", 70),
    ("gender", "Dzimums", 80),
    ("birth_date", "Dzimšanas datums", 120),
    ("birthday", "Dzimšanas diena", 120),
    ("name_day", "Vārda diena", 150),
    ("age", "Vecums", 60),
    ("join_date", "Iestājies", 100),
    ("tenure", "Stāžs (gadi)", 85),
    ("status", "Statuss", 85),
    ("role", "Loma", 90),
    ("app_roles", "Lietotnes lomas", 190),
    ("app_email", "E-pasts (Kabatas Pūrlāde)", 200),
    ("height", "Augums (cm)", 85),
    ("clothing_size", "Izmērs", 60),
    ("issued", "Izsniegti tērpi", 100),
    ("contact", "Kontakti", 200),
]


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        ensure_dancer_schema(self.con)

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def has_checkouts(self):
        # the checkouts table belongs to Tērpu pūrs and exists only once that module has been used
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='checkouts'"))

    def active_checkouts(self, dancer_id):
        if not self.has_checkouts():
            return 0
        return self.q("SELECT COUNT(*) FROM checkouts WHERE dancer_id=? AND "
                      "TRIM(COALESCE(return_date,'')) = ''", (dancer_id,))[0][0]


FIELDS = ("first_name", "last_name", "gender", "birth_date", "join_date", "status",
          "height", "clothing_size", "contact", "role", "dancer_group")
LEADERS = "Vadītāji un repetitori"   # filter value: everyone who is not a dancer


def save_dancer(db, values, dancer_id=None):
    """values: dict with FIELDS. Keeps the full name column (used by the other modules) up to date."""
    data = [values.get(f, "") for f in FIELDS] + [full_name(values["first_name"], values["last_name"])]
    if dancer_id is None:
        return db.x("INSERT INTO dancers (" + ", ".join(FIELDS) + ", name) VALUES ("
                    + ",".join("?" * (len(FIELDS) + 1)) + ")", data)
    db.x("UPDATE dancers SET " + ", ".join(f + "=?" for f in FIELDS) + ", name=? WHERE id=?",
         data + [dancer_id])
    return dancer_id


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def normalize_role(text):
    """'vadītāja', 'repetitore', 'dejotājs' … -> role; empty -> dancer; unknown -> None."""
    s = _norm(text)
    if not s or s.startswith(("dejot", "dancer")):
        return ROLE_DANCER
    if s.startswith(("vad", "leader", "director", "maksl")):
        return PERSON_ROLES[1]
    if s.startswith(("repet", "rehears")):
        return PERSON_ROLES[2]
    return None


def is_dancer(role):
    return (role or ROLE_DANCER) == ROLE_DANCER


def normalize_status(text):
    s = _norm(text)
    if not s:
        return STATUS_ACTIVE
    if s.startswith(("neakt", "pauz", "uz pauz", "inact")):
        return STATUS_INACTIVE
    if s.startswith(("izst", "aizg", "left", "bijis")):
        return STATUS_LEFT
    if s.startswith(("akt", "activ", "ja", "dejo")):
        return STATUS_ACTIVE
    return None


def show_date(iso):
    """Stored date GGGG-MM-DD -> DD.MM.GGGG (anything else is shown as it is)."""
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or ""


def birthday_text(iso):
    """Birth date GGGG-MM-DD -> '25. oktobris' (day and month only)."""
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
    except (TypeError, ValueError):
        return ""
    return f"{d.day}. {MONTHS[d.month - 1]}"


def birthday_sort_key(iso):
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
    except (TypeError, ValueError):
        return None
    return (d.month, d.day)


def normalize_height(text):
    m = re.search(r"\d{2,3}", str(text or ""))
    if not m:
        return ""
    value = int(m.group(0))
    return str(value) if 50 <= value <= 250 else ""


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


class CardTooltip:
    """Small window next to the mouse while it is over a summary card: the card's figure for every group."""

    def __init__(self, card, colour, title, rows_getter):
        self.card, self.colour, self.title, self.rows_getter = card, colour, title, rows_getter
        self.win = None
        for w in [card] + card.winfo_children():
            w.bind("<Enter>", self.show, add="+")
            w.bind("<Leave>", self.leave, add="+")
            w.bind("<Motion>", self.move, add="+")

    def show(self, event):
        if self.win is not None:
            return
        rows = self.rows_getter()
        if not rows:
            return
        self.win = tk.Toplevel(self.card)
        self.win.overrideredirect(True)
        try:
            self.win.attributes("-topmost", True)
        except tk.TclError:
            pass
        box = tk.Frame(self.win, bg=WHITE, highlightbackground=self.colour, highlightthickness=2, padx=12, pady=8)
        box.pack()
        tk.Label(box, text=self.title + " pa grupām", font=("Segoe UI", 9, "bold"), bg=WHITE, fg=NAVY).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        for i, (name, value) in enumerate(rows, start=1):
            tk.Label(box, text=name, font=("Segoe UI", 10), bg=WHITE, fg=NAVY).grid(row=i, column=0, sticky="w")
            tk.Label(box, text=value, font=("Segoe UI", 10, "bold"), bg=WHITE, fg=self.colour).grid(
                row=i, column=1, sticky="e", padx=(18, 0))
        self.move(event)

    def move(self, event):
        if self.win is not None:
            self.win.geometry(f"+{event.x_root + 14}+{event.y_root + 16}")

    def leave(self, _event):
        # moving between the card and its labels also gives <Leave>: hide only when the mouse is really out
        self.card.after(30, self._hide_if_outside)

    def _hide_if_outside(self):
        if self.win is None:
            return
        x, y = self.card.winfo_pointerxy()
        cx, cy = self.card.winfo_rootx(), self.card.winfo_rooty()
        if not (cx <= x < cx + self.card.winfo_width() and cy <= y < cy + self.card.winfo_height()):
            self.win.destroy()
            self.win = None


def dancer_stats(records):
    """The summary card figures for these dancers (records = dancers only)."""
    active = [r for r in records if r["status"] == STATUS_ACTIVE]
    women = sum(1 for r in active if r["gender"] == GENDER_FEMALE)
    men = sum(1 for r in active if r["gender"] == GENDER_MALE)
    ages = [r["age"] for r in active if r["age"] is not None]
    tenures = [r["tenure"] for r in active if r["tenure"] is not None]
    avg = lambda xs: f"{sum(xs) / len(xs):.1f}".replace(".", ",") if xs else "—"
    return {"total": str(len(records)), "active": str(len(active)), "gender": f"{women} / {men}",
            "age": avg(ages), "tenure": avg(tenures)}


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


# --------------------------------------------------------------------------
# Dancer form
# --------------------------------------------------------------------------
class DancerForm(tk.Toplevel):
    """Add or edit one dancer."""

    def __init__(self, app, dancer_id=None):
        super().__init__(app.root)
        self.app, self.dancer_id = app, dancer_id
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Jauns dejotājs" if dancer_id is None else "Rediģēt dejotāju")
        self.transient(app.root)
        self.grab_set()
        tk.Label(self, text="Jauns dejotājs" if dancer_id is None else "Dejotājs",
                 font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))

        self.vars = {f: tk.StringVar() for f in FIELDS if f != "contact"}
        self.vars["status"].set(STATUS_ACTIVE)
        self.vars["role"].set(ROLE_DANCER)
        self.vars["dancer_group"].set(DEFAULT_DANCER_GROUP)

        def label(text, r, c):
            tk.Label(self, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))

        def entry(key, r, c, width=24):
            w = ttk.Entry(self, textvariable=self.vars[key], width=width)
            w.grid(row=r, column=c + 1, sticky="ew", pady=4, padx=(8, 0))
            return w

        def combo(key, values, r, c, readonly=True):
            ttk.Combobox(self, textvariable=self.vars[key], values=values, width=22,
                         state="readonly" if readonly else "normal").grid(
                row=r, column=c + 1, sticky="ew", pady=4, padx=(8, 0))

        label("Vārds *", 1, 0)
        first = entry("first_name", 1, 0)
        label("Uzvārds", 1, 2)
        entry("last_name", 1, 2)
        label("Dzimums *", 2, 0)
        combo("gender", GENDERS, 2, 0)
        label("Statuss", 2, 2)
        combo("status", DANCER_STATUSES, 2, 2)
        label("Dzimšanas datums", 3, 0)
        entry("birth_date", 3, 0)
        label("Iestāšanās datums", 3, 2)
        entry("join_date", 3, 2)
        label("Augums (cm)", 4, 0)
        entry("height", 4, 0)
        label("Apģērba izmērs", 4, 2)
        combo("clothing_size", CLOTHING_SIZES, 4, 2, readonly=False)
        label("Loma kolektīvā", 5, 0)
        combo("role", PERSON_ROLES, 5, 0)
        tk.Label(self, text="Vadītāji un repetitori netiek skaitīti dejotāju skaitā\nun netiek piedāvāti "
                            "deju sastāvos, tērpu izsniegšanā un apmeklējumā.",
                 bg=CREAM, fg=NAVY, justify="left", font=("Segoe UI", 8, "italic")).grid(
            row=5, column=2, columnspan=2, sticky="w", padx=(18, 0))
        label("Grupa *", 6, 0)
        self.group_cb = ttk.Combobox(self, textvariable=self.vars["dancer_group"], values=DANCER_GROUPS, width=22,
                                     state="readonly")
        self.group_cb.grid(row=6, column=1, sticky="ew", pady=4, padx=(8, 0))
        tk.Label(self, text="Datumus raksta formā DD.MM.GGGG (piemēram, 05.03.2001).", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=6, column=2, columnspan=2, sticky="w", padx=(18, 0))

        # Lietotnes lomas (app roles) — extra app roles only for dancers
        box = tk.LabelFrame(self, text=" Lietotnes lomas ", bg=CREAM, fg=RED, font=("Georgia", 11, "bold"),
                            padx=10, pady=6)
        box.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(8, 4))
        self.app_role_vars = {r: tk.BooleanVar(value=False) for r in EXTRA_APP_ROLES}
        self.base_role_var = tk.BooleanVar(value=True)
        self.base_role_cb = tk.Checkbutton(box, text=APP_ROLE_DANCER, variable=self.base_role_var,
                                           state="disabled", bg=CREAM, activebackground=CREAM)
        self.base_role_cb.grid(row=0, column=0, sticky="w", padx=(0, 14))
        self.app_role_cbs = []
        for i, r in enumerate(EXTRA_APP_ROLES, start=1):
            cb = tk.Checkbutton(box, text=r, variable=self.app_role_vars[r], bg=CREAM, fg=NAVY,
                                activebackground=CREAM, selectcolor=WHITE)
            cb.grid(row=0, column=i, sticky="w", padx=(0, 14))
            self.app_role_cbs.append(cb)
        self.app_role_note = tk.Label(box, bg=CREAM, fg=NAVY, justify="left", font=("Segoe UI", 8, "italic"))
        self.app_role_note.grid(row=1, column=0, columnspan=4, sticky="w", pady=(4, 0))
        email_row = tk.Frame(box, bg=CREAM)
        email_row.grid(row=2, column=0, columnspan=len(EXTRA_APP_ROLES) + 1, sticky="ew", pady=(8, 0))
        tk.Label(email_row, text="E-pasts Kabatas Pūrlādei", bg=CREAM, fg=NAVY).pack(side="left")
        self.email_var = tk.StringVar()
        ttk.Entry(email_row, textvariable=self.email_var, width=36).pack(side="left", padx=(8, 0))
        tk.Label(box, text="Ar šo e-pastu cilvēks piesakās Kabatas Pūrlādē (uz to tiek sūtīts pieteikšanās kods). "
                           "Ja lauks ir tukšs, lietotnē pieteikties nevar.",
                 bg=CREAM, fg=NAVY, justify="left", font=("Segoe UI", 8, "italic")).grid(
            row=3, column=0, columnspan=len(EXTRA_APP_ROLES) + 1, sticky="w", pady=(2, 0))
        self.vars["role"].trace_add("write", lambda *a: self.update_app_roles())

        label("Kontaktinformācija", 8, 0)
        self.contact = tk.Text(self, width=60, height=3, wrap="word", relief="solid", bd=1)
        self.contact.grid(row=8, column=1, columnspan=3, sticky="ew", pady=4, padx=(8, 0))

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=9, column=0, columnspan=4, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())

        if dancer_id is not None:
            row = app.db.q("SELECT " + ", ".join(FIELDS) + " FROM dancers WHERE id=?", (dancer_id,))[0]
            for f, v in zip(FIELDS, row):
                if f == "contact":
                    self.contact.insert("1.0", v or "")
                elif f in ("birth_date", "join_date"):
                    self.vars[f].set(show_date(v))
                else:
                    self.vars[f].set(v or "")
            if self.vars["status"].get() not in DANCER_STATUSES:
                self.vars["status"].set(STATUS_ACTIVE)
            if self.vars["role"].get() not in PERSON_ROLES:
                self.vars["role"].set(ROLE_DANCER)
            stored = app.db.q("SELECT app_roles FROM dancers WHERE id=?", (dancer_id,))[0][0]
            for r in parse_app_roles(stored):
                self.app_role_vars[r].set(True)
            self.email_var.set(app_email(app.db.con, dancer_id))
        self.update_app_roles()
        first.focus_set()
        self.after(100, lambda: fit_min_size(self))

    def update_app_roles(self):
        """Extra app roles can be given only to dancers; leaders and rehearsal directors get theirs automatically."""
        role = self.vars["role"].get() or ROLE_DANCER
        dancer = role == ROLE_DANCER
        self.base_role_cb.configure(text=APP_ROLE_DANCER if dancer else f"{role} (automātiski)")
        for cb in self.app_role_cbs:
            cb.configure(state="normal" if dancer else "disabled")
        # a group only for dancers
        if dancer:
            self.group_cb.configure(state="readonly")
            if self.vars["dancer_group"].get() not in DANCER_GROUPS:
                self.vars["dancer_group"].set(DEFAULT_DANCER_GROUP)
        else:
            self.vars["dancer_group"].set("")
            self.group_cb.configure(state="disabled")
        self.app_role_note.configure(text=(
            "Visiem dejotājiem ir lietotnes loma “Dejotājs”; pārējās lomas piešķir kolektīva vadītājs vai "
            "sistēmas administrators. Tās nosaka, ko cilvēks redz un drīkst mobilajā lietotnē."
            if dancer else
            f"Vadītājiem un repetitoriem lietotnes loma “{role}” tiek piešķirta automātiski; "
            "papildu lomas ir tikai dejotājiem."))

    def save(self):
        v = {f: var.get().strip() for f, var in self.vars.items()}
        v["contact"] = self.contact.get("1.0", tk.END).strip()
        if not v["first_name"]:
            messagebox.showwarning("Trūkst datu", "Lūdzu, norādiet dejotāja vārdu.", parent=self)
            return
        if v["gender"] not in GENDERS:
            messagebox.showwarning("Dzimums", "Izvēlieties dzimumu: vīrietis vai sieviete.", parent=self)
            return
        for key, title in (("birth_date", "Dzimšanas datums"), ("join_date", "Iestāšanās datums")):
            parsed = parse_date(v[key])
            if parsed is None:
                messagebox.showwarning("Datums", f"{title}: nepareizs datums. Izmantojiet formātu DD.MM.GGGG, "
                                                 "piemēram, 05.03.2001.", parent=self)
                return
            v[key] = parsed
        if v["height"]:
            h = normalize_height(v["height"])
            if not h:
                messagebox.showwarning("Augums", "Augumu norādiet centimetros (piemēram, 172).", parent=self)
                return
            v["height"] = h
        email = self.email_var.get().strip().lower()
        problem = check_app_email(self.app.db.con, self.dancer_id, email)
        if problem:
            messagebox.showwarning("E-pasts", problem, parent=self)
            return
        db = self.app.db
        if self.dancer_id is None:
            same = db.q("SELECT COUNT(*) FROM dancers WHERE LOWER(name)=LOWER(?) AND "
                        "COALESCE(birth_date,'')=?", (full_name(v["first_name"], v["last_name"]),
                                                       v["birth_date"]))[0][0]
            if same and not messagebox.askyesno(
                    "Dublikāts", "Šāds dejotājs jau ir sarakstā. Vai tomēr pievienot vēl vienu?", parent=self):
                return
        new_id = save_dancer(db, v, self.dancer_id)
        extra = [r for r, var in self.app_role_vars.items() if var.get()] if v["role"] in ("", ROLE_DANCER) else []
        db.x("UPDATE dancers SET app_roles=? WHERE id=?", (app_roles_text(extra), new_id))
        try:
            set_app_email(db.con, new_id, email)
        except ValueError as exc:
            messagebox.showwarning("E-pasts", f"Dejotājs saglabāts, bet e-pastu neizdevās saglabāt:\n{exc}",
                                   parent=self)
        self.app.refresh(select=new_id)
        self.destroy()


# --------------------------------------------------------------------------
# Import from Excel / CSV
# --------------------------------------------------------------------------
IMPORT_ALIASES = {
    "first_name": ["vards", "first name", "firstname"],
    "last_name": ["uzvards", "last name", "surname", "lastname"],
    "full_name": ["vards uzvards", "vards un uzvards", "dejotajs", "dejotaja vards", "dejotaja vards uzvards",
                  "full name", "name"],
    "gender": ["dzimums", "gender", "sex"],
    "birth_date": ["dzimsanas datums", "dzim datums", "dzimis", "dzimusi", "birth date", "date of birth", "dob"],
    "join_date": ["iestasanas datums", "iestajies", "iestajas", "kolektiva kops", "dejo kops", "join date"],
    "status": ["statuss", "status"],
    "role": ["loma", "loma kolektiva", "amats", "role"],
    "dancer_group": ["grupa", "dejotaju grupa", "group"],
    "height": ["augums", "augums cm", "garums", "height"],
    "clothing_size": ["izmers", "apgerba izmers", "size"],
    "contact": ["kontakti", "kontakts", "kontaktinformacija", "telefons", "talrunis", "contact", "phone"],
    "app_email": ["e pasts", "epasts", "e mail", "email", "e pasts kabatas purladei", "kabatas purlades e pasts",
                  "e pasts kabatas purlade", "lietotnes e pasts"],
}


def import_dancers(db, rows):
    aliases = {k: {_norm(a) for a in v} for k, v in IMPORT_ALIASES.items()}
    header, mp, found = None, {}, []
    for i, row in enumerate(rows):
        if any(c for c in row):
            header = i
            for col, cell in enumerate(row):
                n = _norm(cell)
                for field, names in aliases.items():
                    if field not in mp and n in names:
                        mp[field] = col
            found = [c for c in row if c]
            break
    if header is None or not ({"first_name", "full_name"} & set(mp)):
        return {"error": "Failā nav atrasta kolonna “Vārds” (vai “Vārds uzvārds”).\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}
    split_first = "first_name" in mp and "last_name" not in mp and "full_name" not in mp

    def cell(row, field):
        col = mp.get(field)
        return row[col].strip() if col is not None and col < len(row) else ""

    existing = {(_norm(n), b or ""): did for did, n, b in db.q("SELECT id, name, birth_date FROM dancers")}
    added, emails_added, skipped = 0, 0, []

    def give_email(row_no, dancer_id, name):
        """The e-mail column: Kabatas Pūrlāde login. Returns True when it was saved."""
        email = cell(rows[row_no - 1], "app_email").lower()
        if not email or email == app_email(db.con, dancer_id):
            return False
        try:
            set_app_email(db.con, dancer_id, email)
            return True
        except ValueError as exc:
            skipped.append((row_no, f"{name}: e-pasts “{email}” nav saglabāts — {exc}"))
            return False

    for i in range(header + 1, len(rows)):
        row = rows[i]
        if not any(row):
            continue
        first, last = cell(row, "first_name"), cell(row, "last_name")
        if split_first or (not first and cell(row, "full_name")):
            parts = (first or cell(row, "full_name")).split(None, 1)
            first, last = (parts[0] if parts else ""), (parts[1] if len(parts) > 1 else last)
        if not first:
            skipped.append((i + 1, "nav vārda"))
            continue
        gender = normalize_gender(cell(row, "gender"))
        if gender is None:
            skipped.append((i + 1, f"nezināms dzimums “{cell(row, 'gender')}”"))
            continue
        role = normalize_role(cell(row, "role"))
        if role is None:
            skipped.append((i + 1, f"nezināma loma “{cell(row, 'role')}”"))
            continue
        group = next((g for g in DANCER_GROUPS if _norm(g) == _norm(cell(row, "dancer_group"))), None)
        if cell(row, "dancer_group") and group is None:
            skipped.append((i + 1, f"nezināma grupa “{cell(row, 'dancer_group')}” (der: {', '.join(DANCER_GROUPS)})"))
            continue
        if role == ROLE_DANCER:
            group = group or DEFAULT_DANCER_GROUP
        else:
            group = ""
        status = normalize_status(cell(row, "status"))
        if status is None:
            skipped.append((i + 1, f"nezināms statuss “{cell(row, 'status')}”"))
            continue
        dates = {}
        bad = None
        for key in ("birth_date", "join_date"):
            dates[key] = parse_date(cell(row, key))
            if dates[key] is None:
                bad = f"nepareizs datums “{cell(row, key)}”"
        if bad:
            skipped.append((i + 1, bad))
            continue
        key = (_norm(full_name(first, last)), dates["birth_date"])
        if key in existing:
            # an existing dancer: only the Kabatas Pūrlāde e-mail is taken from the file
            if cell(row, "app_email"):
                emails_added += give_email(i + 1, existing[key], full_name(first, last))
            else:
                skipped.append((i + 1, f"dejotājs “{full_name(first, last)}” jau ir sarakstā"))
            continue
        new_id = save_dancer(db, {"first_name": first, "last_name": last, "gender": gender,
                         "birth_date": dates["birth_date"], "join_date": dates["join_date"], "status": status,
                         "height": normalize_height(cell(row, "height")),
                         "clothing_size": cell(row, "clothing_size").upper(), "contact": cell(row, "contact"),
                         "role": role, "dancer_group": group})
        existing[key] = new_id
        added += 1
        give_email(i + 1, new_id, full_name(first, last))
    return {"error": None, "added": added, "emails": emails_added, "skipped": skipped}


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
        s.configure("TFrame", background=CREAM)
        s.configure("TLabel", background=CREAM, foreground=NAVY)
        s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
        s.map("TButton", background=[("active", GOLD)])
        s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                    bordercolor=GOLD)
        s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                    padding=6)
        s.map("Treeview.Heading", background=[("active", RED)])
        s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        header = tk.Frame(self.root, bg=NAVY)
        header.pack(fill="x")
        header.columnconfigure(0, weight=1, uniform="h")
        header.columnconfigure(2, weight=1, uniform="h")
        left = tk.Frame(header, bg=NAVY)
        left.grid(row=0, column=0, sticky="w")
        logo = module_logo(left, "kopas_purs", on_click=self.show_main)
        if logo is not None:
            logo.pack(side="left", padx=(16, 0), pady=6)
        title_box = tk.Frame(left, bg=NAVY)
        title_box.pack(side="left", padx=(12 if logo is not None else 20, 12), pady=12)
        tk.Label(title_box, text=PROGRAM_NAME, font=("Georgia", 20, "bold"), bg=NAVY, fg=CREAM).pack(anchor="w")
        centre = tk.Frame(header, bg=NAVY)
        centre.place(relx=0.5, rely=0.5, anchor="center")
        # collective name with the collective logo underneath
        self.group_logo = group_logo(150, 40)
        tk.Label(centre, text=read_setting("app.group_name", "Tautas deju kolektīvs"),
                 font=("Georgia", 14, "italic"), bg=NAVY, fg=GOLD).pack(
            side="top", pady=(4, 2) if self.group_logo is not None else 12)
        if self.group_logo is not None:
            tk.Label(centre, image=self.group_logo, bg=NAVY).pack(side="top", pady=(0, 4))
        right = tk.Frame(header, bg=NAVY)
        right.grid(row=0, column=2, sticky="e", padx=14, pady=10)
        try:
            self.power_icon = tk.PhotoImage(data=POWER_ICON_B64)
        except Exception:
            self.power_icon = None
        embedded = self.on_exit is not None
        tk.Button(right, text=" Atgriezties moduļu izvēlē" if embedded else " Beigt darbu",
                  image=self.power_icon or "", compound="left",
                  command=self.on_exit if embedded else self.root.destroy, font=("Segoe UI", 11, "bold"),
                  bg=NAVY, fg=GOLD, activebackground=RED, activeforeground=CREAM, relief="flat", bd=0,
                  highlightthickness=2, highlightbackground=GOLD, highlightcolor=GOLD, cursor="hand2",
                  padx=12, pady=3).pack()
        tk.Frame(self.root, bg=GOLD, height=4).pack(fill="x")
        copyright_footer(self.root)

        # summary cards
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=18, pady=(14, 6))
        self.card_vars = {}
        for i, (key, title, colour) in enumerate([
                ("total", "Kopā dejotāju", NAVY),
                ("active", "Aktīvie", TEAL),
                ("gender", "Sievietes / vīrieši (aktīvie)", RED),
                ("age", "Vidējais vecums (aktīvie)", GOLD),
                ("tenure", "Vidējais stāžs, gadi (aktīvie)", NAVY)]):
            card = tk.Frame(cards, bg=WHITE, highlightbackground=colour, highlightthickness=3)
            card.grid(row=0, column=i, padx=6, sticky="ew")
            cards.columnconfigure(i, weight=1, uniform="card")
            var = tk.StringVar(value="—")
            self.card_vars[key] = var
            tk.Label(card, textvariable=var, font=("Georgia", 24, "bold"), bg=WHITE, fg=colour).pack(pady=(6, 0))
            tk.Label(card, text=title, font=("Segoe UI", 9), bg=WHITE, fg=NAVY).pack(pady=(0, 6))
            CardTooltip(card, colour, title, lambda k=key: [(g, st[k]) for g, st in self.group_stats])
        self.group_stats = []   # [(group, figures)] — filled by update_cards, shown when hovering a card

        # filters
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=18, pady=(8, 4))
        self.search = tk.StringVar()
        self.f_gender = tk.StringVar(value=ALL)
        self.f_status = tk.StringVar(value=ALL)
        self.f_role = tk.StringVar(value=ALL)
        self.f_group = tk.StringVar(value=ALL)
        ttk.Label(bar, text="Meklēt:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=24).pack(side="left", padx=(4, 16))
        self.search.trace_add("write", lambda *a: self.refresh())
        ttk.Label(bar, text="Dzimums:").pack(side="left")
        gcb = ttk.Combobox(bar, textvariable=self.f_gender, values=[ALL] + GENDERS, state="readonly", width=11)
        gcb.pack(side="left", padx=(4, 16))
        ttk.Label(bar, text="Statuss:").pack(side="left")
        scb = ttk.Combobox(bar, textvariable=self.f_status, values=[ALL] + DANCER_STATUSES, state="readonly",
                           width=11)
        scb.pack(side="left", padx=(4, 16))
        ttk.Label(bar, text="Loma:").pack(side="left")
        rcb = ttk.Combobox(bar, textvariable=self.f_role, values=[ALL, ROLE_DANCER + "i", LEADERS] + PERSON_ROLES[1:],
                           state="readonly", width=20)
        rcb.pack(side="left", padx=(4, 16))
        ttk.Label(bar, text="Grupa:").pack(side="left")
        grcb = ttk.Combobox(bar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=9)
        grcb.pack(side="left", padx=4)
        for cb in (gcb, scb, rcb, grcb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Button(bar, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")

        btns = ttk.Frame(self.root)
        btns.pack(fill="x", padx=18, pady=4)
        ttk.Button(btns, text="＋ Jauns dejotājs", style="Accent.TButton",
                   command=lambda: DancerForm(self)).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="Rediģēt", command=self.edit).pack(side="left", padx=3)
        ttk.Button(btns, text="Dzēst", command=self.delete).pack(side="left", padx=3)
        ttk.Button(btns, text="⇪ Importēt no Excel", command=self.run_import).pack(side="left", padx=3)
        self.count_var = tk.StringVar()
        tk.Label(btns, textvariable=self.count_var, bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(side="right")

        holder = ttk.Frame(self.root)
        holder.pack(fill="both", expand=True, padx=18, pady=(4, 6))
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in COLUMNS], show="headings")
        for key, title, width in COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=50, anchor="w", stretch=key == "contact")
        self.tree.tag_configure(STATUS_ACTIVE, foreground=NAVY)
        self.tree.tag_configure(STATUS_INACTIVE, foreground=AMBER)
        self.tree.tag_configure(STATUS_LEFT, foreground=GREY)
        self.tree.tag_configure("leader", foreground=TEAL, font=("Segoe UI", 10, "bold"))
        self.tree.bind("<Double-1>", lambda e: self.edit())
        make_tree_with_scroll(holder, self.tree)
        self.sort_key, self.sort_desc = "last_name", False
        self.refresh()

    # ---- data -------------------------------------------------------------
    def show_main(self):
        """Module logo: back to the main view — all dancers, no filters, top of the list."""
        self.clear_filters()
        self.tree.selection_remove(self.tree.selection())
        self.tree.yview_moveto(0)

    def clear_filters(self):
        self.search.set("")
        self.f_gender.set(ALL)
        self.f_status.set(ALL)
        self.f_role.set(ALL)
        self.f_group.set(ALL)
        self.refresh()

    def sort_by(self, key):
        self.sort_desc = not self.sort_desc if key == self.sort_key else False
        self.sort_key = key
        self.refresh()

    def refresh(self, select=None):
        db = self.db
        issued_sql = ("(SELECT COUNT(*) FROM checkouts c WHERE c.dancer_id = d.id AND "
                      "TRIM(COALESCE(c.return_date,'')) = '')") if db.has_checkouts() else "0"
        rows = db.q("SELECT d.id, d.first_name, d.last_name, d.gender, d.birth_date, d.join_date, d.status, "
                    "d.height, d.clothing_size, d.contact, d.role, d.app_roles, d.dancer_group, " + issued_sql + " FROM dancers d")
        emails = app_emails(db.con)
        records = []
        for did, first, last, gender, birth, join, status, height, size, contact, role, app_roles, group, issued in rows:
            records.append({
                "id": did, "first_name": first or "", "last_name": last or "", "gender": gender or "",
                "birth_date": birth or "", "birthday": birthday_text(birth),
                "name_day": name_day_text(first or ""), "age": years_between(birth), "join_date": join or "",
                "tenure": years_between(join), "status": status or STATUS_ACTIVE, "height": height or "",
                "clothing_size": size or "", "issued": issued or 0, "contact": contact or "",
                "role": role if role in PERSON_ROLES else ROLE_DANCER,
                "app_roles": ", ".join(app_roles_of(role, app_roles)), "dancer_group": group or "",
                "app_email": emails.get(did, "")})
        self.update_cards(records)

        term = _norm(self.search.get())
        shown = []
        for r in records:
            if self.f_gender.get() != ALL and r["gender"] != self.f_gender.get():
                continue
            if self.f_status.get() != ALL and r["status"] != self.f_status.get():
                continue
            if self.f_group.get() != ALL and r["dancer_group"] != self.f_group.get():
                continue
            role_filter = self.f_role.get()
            if role_filter == ROLE_DANCER + "i" and not is_dancer(r["role"]):
                continue
            if role_filter == LEADERS and is_dancer(r["role"]):
                continue
            if role_filter in PERSON_ROLES[1:] and r["role"] != role_filter:
                continue
            if term and term not in _norm(" ".join(str(r[k]) for k in
                                                   ("first_name", "last_name", "contact", "clothing_size", "app_roles",
                                                    "dancer_group", "app_email"))):
                continue
            shown.append(r)

        def sort_value(r):
            if self.sort_key in ("birthday", "name_day"):  # by calendar day, not alphabetically
                k = (birthday_sort_key(r["birth_date"]) if self.sort_key == "birthday"
                     else name_day_sort_key(r["first_name"]))
                return (k is None, k or (0, 0))
            v = r[self.sort_key]
            if self.sort_key == "height":
                v = int(v) if str(v).isdigit() else None
            if isinstance(v, int) or v is None:
                return (v is None, v or 0)
            return (v == "", _norm(v))
        shown.sort(key=lambda r: (_norm(r["first_name"]),))
        shown.sort(key=sort_value, reverse=self.sort_desc)

        keep = select or (self.tree.selection()[0] if self.tree.selection() else None)
        self.tree.delete(*self.tree.get_children())
        for r in shown:
            values = []
            for key, _t, _w in COLUMNS:
                v = r[key]
                if key in ("age", "tenure"):
                    v = "" if v is None else v
                elif key == "issued":
                    v = v if v else "—"
                elif key == "contact":
                    v = " ".join(str(v).split())
                elif key in ("birth_date", "join_date"):
                    v = show_date(v)
                values.append(v)
            self.tree.insert("", "end", iid=str(r["id"]), values=values,
                             tags=(r["status"],) + (() if is_dancer(r["role"]) else ("leader",)))
        if keep is not None and self.tree.exists(str(keep)):
            self.tree.selection_set(str(keep))
            self.tree.see(str(keep))
        n_dancers = sum(1 for r in records if is_dancer(r["role"]))
        self.count_var.set(f"Rādīti {len(shown)} no {len(records)} (dejotāji: {n_dancers}, vadītāji un repetitori: "
                           f"{len(records) - n_dancers}). "
                           "Dubultklikšķis — rediģēt; klikšķis uz virsraksta — kārtot.")

    def update_cards(self, records):
        records = [r for r in records if is_dancer(r["role"])]   # the figures are about dancers only
        for key, value in dancer_stats(records).items():
            self.card_vars[key].set(value)
        groups = list(DANCER_GROUPS)
        if any(r["dancer_group"] not in DANCER_GROUPS for r in records):
            groups.append("")
        self.group_stats = [(g or "Bez grupas", dancer_stats([r for r in records if (r["dancer_group"] or "") == g
                                                              or (not g and r["dancer_group"] not in DANCER_GROUPS)]))
                            for g in groups]

    def selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sarakstā.", parent=self.root)
            return None
        return int(sel[0])

    def edit(self):
        did = self.selected()
        if did is not None:
            DancerForm(self, did)

    def delete(self):
        did = self.selected()
        if did is None:
            return
        name = self.db.q("SELECT name FROM dancers WHERE id=?", (did,))[0][0]
        issued = self.db.active_checkouts(did)
        if issued:
            messagebox.showwarning(
                "Nevar dzēst", f"Dejotājam “{name}” ir izsniegti tērpi ({issued}). "
                               "Vispirms atgrieziet tos Tērpu pūrā.", parent=self.root)
            return
        if messagebox.askyesno(
                "Dzēst", f"Dzēst dejotāju “{name}”?\n\nTiks dzēsta arī viņa tērpu izsniegumu un apmeklējuma vēsture. "
                         f"Ja dejotājs vienkārši vairs nedejo, labāk nomainiet statusu uz “{STATUS_LEFT}”.",
                parent=self.root):
            self.db.x("DELETE FROM dancers WHERE id=?", (did,))
            self.refresh()

    def run_import(self):
        cols = ["Vārds", "Uzvārds", "Dzimums (sieviete / vīrietis)", "Dzimšanas datums", "Iestāšanās datums",
                "Statuss (aktīvs / uz pauzes / izstājies)", "Loma (dejotājs / vadītājs / repetitors)",
                "Grupa (" + " / ".join(DANCER_GROUPS) + ")", "Augums",
                "Izmērs", "Kontakti", "E-pasts (Kabatas Pūrlādei)"]
        info = ("Excel faila pirmajā rindā jābūt kolonnu nosaukumiem:\n\n  • " + "\n  • ".join(cols) +
                "\n\nObligāta ir tikai kolonna “Vārds” (der arī viena kolonna “Vārds uzvārds”). "
                "Jau esošie dejotāji (tas pats vārds un dzimšanas datums) tiks izlaisti. "
                "Ja statuss nav norādīts, dejotājs būs aktīvs; ja loma nav norādīta — dejotājs; ja grupa nav norādīta — " + DEFAULT_DANCER_GROUP + ".\n\n"
                "Kolonna “E-pasts” ir e-pasts, ar kuru dejotājs piesakās Kabatas Pūrlādē. Jau esošiem dejotājiem "
                "no faila tiek ņemts tikai e-pasts — tā var vienā reizē ievadīt e-pastus visiem.")
        if not messagebox.askokcancel("Importēt no Excel", info, parent=self.root):
            return
        path = filedialog.askopenfilename(parent=self.root, title="Izvēlieties Excel failu",
                                          filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            result = import_dancers(self.db, read_table(path))
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self.root)
            return
        if result["error"]:
            messagebox.showerror("Importa kļūda", result["error"], parent=self.root)
            return
        self.refresh()
        text = (f"Pievienoti dejotāji: {result['added']}\n"
                f"E-pasti pievienoti jau esošiem dejotājiem: {result['emails']}\n"
                f"Izlaistas rindas / brīdinājumi: {len(result['skipped'])}")
        if result["skipped"]:
            text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
            if len(result["skipped"]) > 12:
                text += f"\n… un vēl {len(result['skipped']) - 12}"
        (messagebox.showwarning if result["skipped"] else messagebox.showinfo)("Imports pabeigts", text,
                                                                              parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
