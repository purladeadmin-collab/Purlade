#!/usr/bin/env python3
"""
Pūrlāde — modulis "Kopas pūrs" (dejotāju uzskaitei un statistikai)

Šeit tiek ievadīti un uzturēti visi kolektīva dejotāji. Pārējie moduļi
(piemēram, Tērpu pūrs) dejotāju informāciju ņem no šejienes.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/kopas_purs.py
"""

import os
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import datetime, date
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo,
                               console_is_own, set_console_visible, ensure_dancer_schema, full_name,
                               parse_date, years_between, read_table, normalize_gender, _norm,
                               app_emails, app_email, check_app_email, set_app_email, sync_role_history,
                               GENDERS, GENDER_MALE, GENDER_FEMALE, DANCER_STATUSES, STATUS_ACTIVE,
                               STATUS_INACTIVE, STATUS_LEFT, CLOTHING_SIZES, POWER_ICON_B64, HOME_ICON_B64, PERSON_ROLES, ROLE_DANCER,
                               EXTRA_APP_ROLES, APP_ROLE_DANCER, DANCER_GROUPS, DEFAULT_DANCER_GROUP, app_roles_of, app_roles_text, parse_app_roles,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo,
                        console_is_own, set_console_visible, ensure_dancer_schema, full_name,
                        parse_date, years_between, read_table, normalize_gender, _norm,
                               app_emails, app_email, check_app_email, set_app_email, sync_role_history,
                        GENDERS, GENDER_MALE, GENDER_FEMALE, DANCER_STATUSES, STATUS_ACTIVE,
                        STATUS_INACTIVE, STATUS_LEFT, CLOTHING_SIZES, POWER_ICON_B64, HOME_ICON_B64, PERSON_ROLES, ROLE_DANCER,
                               EXTRA_APP_ROLES, APP_ROLE_DANCER, DANCER_GROUPS, DEFAULT_DANCER_GROUP, app_roles_of, app_roles_text, parse_app_roles,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

try:
    from moduli.vardadienas import name_day_text, name_day_sort_key, MONTHS, name_days
except ImportError:
    from vardadienas import name_day_text, name_day_sort_key, MONTHS, name_days

PROGRAM_NAME = "Kopas pūrs"
APP_VERSION = "0.2.6"
TEAL = "#2E7D6B"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Dejotāju uzskaite un statistika: sastāvs, stāžs, dalība",
    "letter": "K",
    "color": TEAL,
}

# table columns: key, heading, width
COLUMNS = [
    ("first_name", "Vārds", 110),
    ("last_name", "Uzvārds", 130),
    ("dancer_group", "Grupa", 70),
    ("gender", "Dzimums", 80),
    ("birth_date", "Dzimšanas datums", 120),
    ("birthday", "Dzimšanas diena", 120),
    ("name_day", "Vārda diena", 150),
    ("age", "Vecums", 60),
    ("join_date", "Iestājies", 100),
    ("tenure", "Stāžs (gadi)", 85),
    ("status", "Statuss", 85),
    ("role", "Loma", 90),
    ("app_roles", "Lietotnes lomas", 190),
    ("app_email", "E-pasts (Kabatas Pūrlāde)", 200),
    ("height", "Augums (cm)", 85),
    ("clothing_size", "Izmērs", 60),
    ("issued", "Izsniegti tērpi", 100),
    ("contact", "Kontakti", 200),
]


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        ensure_dancer_schema(self.con)

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def has_checkouts(self):
        # the checkouts table belongs to Tērpu pūrs and exists only once that module has been used
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='checkouts'"))

    def active_checkouts(self, dancer_id):
        if not self.has_checkouts():
            return 0
        return self.q("SELECT COUNT(*) FROM checkouts WHERE dancer_id=? AND "
                      "TRIM(COALESCE(return_date,'')) = ''", (dancer_id,))[0][0]


FIELDS = ("first_name", "last_name", "gender", "birth_date", "join_date", "status",
          "height", "clothing_size", "contact", "role", "dancer_group", "left_date")
LEADERS = "Vadītāji un repetitori"   # filter value: everyone who is not a dancer


def save_dancer(db, values, dancer_id=None):
    """values: dict with FIELDS. Keeps the full name column (used by the other modules) up to date."""
    data = [values.get(f, "") for f in FIELDS] + [full_name(values["first_name"], values["last_name"])]
    if dancer_id is None:
        return db.x("INSERT INTO dancers (" + ", ".join(FIELDS) + ", name) VALUES ("
                    + ",".join("?" * (len(FIELDS) + 1)) + ")", data)
    db.x("UPDATE dancers SET " + ", ".join(f + "=?" for f in FIELDS) + ", name=? WHERE id=?",
         data + [dancer_id])
    return dancer_id


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def normalize_role(text):
    """'vadītāja', 'repetitore', 'dejotājs' … -> role; empty -> dancer; unknown -> None."""
    s = _norm(text)
    if not s or s.startswith(("dejot", "dancer")):
        return ROLE_DANCER
    if s.startswith(("vad", "leader", "director", "maksl")):
        return PERSON_ROLES[1]
    if s.startswith(("repet", "rehears")):
        return PERSON_ROLES[2]
    return None


def is_dancer(role):
    return (role or ROLE_DANCER) == ROLE_DANCER


def normalize_status(text):
    s = _norm(text)
    if not s:
        return STATUS_ACTIVE
    if s.startswith(("neakt", "pauz", "uz pauz", "inact")):
        return STATUS_INACTIVE
    if s.startswith(("izst", "aizg", "left", "bijis")):
        return STATUS_LEFT
    if s.startswith(("akt", "activ", "ja", "dejo")):
        return STATUS_ACTIVE
    return None


def show_date(iso):
    """Stored date GGGG-MM-DD -> DD.MM.GGGG (anything else is shown as it is)."""
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or ""


def birthday_text(iso):
    """Birth date GGGG-MM-DD -> '25. oktobris' (day and month only)."""
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
    except (TypeError, ValueError):
        return ""
    return f"{d.day}. {MONTHS[d.month - 1]}"


def birthday_sort_key(iso):
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
    except (TypeError, ValueError):
        return None
    return (d.month, d.day)


def normalize_height(text):
    m = re.search(r"\d{2,3}", str(text or ""))
    if not m:
        return ""
    value = int(m.group(0))
    return str(value) if 50 <= value <= 250 else ""


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


class CardTooltip:
    """Small window next to the mouse while it is over a summary card: the card's figure for every group."""

    def __init__(self, card, colour, title, rows_getter):
        self.card, self.colour, self.title, self.rows_getter = card, colour, title, rows_getter
        self.win = None
        for w in [card] + card.winfo_children():
            w.bind("<Enter>", self.show, add="+")
            w.bind("<Leave>", self.leave, add="+")
            w.bind("<Motion>", self.move, add="+")

    def show(self, event):
        if self.win is not None:
            return
        rows = self.rows_getter()
        if not rows:
            return
        self.win = tk.Toplevel(self.card)
        self.win.overrideredirect(True)
        try:
            self.win.attributes("-topmost", True)
        except tk.TclError:
            pass
        box = tk.Frame(self.win, bg=WHITE, highlightbackground=self.colour, highlightthickness=2, padx=12, pady=8)
        box.pack()
        tk.Label(box, text=self.title + " pa grupām", font=("Segoe UI", 9, "bold"), bg=WHITE, fg=NAVY).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        for i, (name, value) in enumerate(rows, start=1):
            tk.Label(box, text=name, font=("Segoe UI", 10), bg=WHITE, fg=NAVY).grid(row=i, column=0, sticky="w")
            tk.Label(box, text=value, font=("Segoe UI", 10, "bold"), bg=WHITE, fg=self.colour).grid(
                row=i, column=1, sticky="e", padx=(18, 0))
        self.move(event)

    def move(self, event):
        if self.win is not None:
            self.win.geometry(f"+{event.x_root + 14}+{event.y_root + 16}")

    def leave(self, _event):
        # moving between the card and its labels also gives <Leave>: hide only when the mouse is really out
        self.card.after(30, self._hide_if_outside)

    def _hide_if_outside(self):
        if self.win is None:
            return
        x, y = self.card.winfo_pointerxy()
        cx, cy = self.card.winfo_rootx(), self.card.winfo_rooty()
        if not (cx <= x < cx + self.card.winfo_width() and cy <= y < cy + self.card.winfo_height()):
            self.win.destroy()
            self.win = None


def dancer_stats(records):
    """The summary card figures for these dancers (records = dancers only)."""
    active = [r for r in records if r["status"] == STATUS_ACTIVE]
    women = sum(1 for r in active if r["gender"] == GENDER_FEMALE)
    men = sum(1 for r in active if r["gender"] == GENDER_MALE)
    ages = [r["age"] for r in active if r["age"] is not None]
    tenures = [r["tenure"] for r in active if r["tenure"] is not None]
    avg = lambda xs: f"{sum(xs) / len(xs):.1f}".replace(".", ",") if xs else "—"
    return {"total": str(len(records)), "active": str(len(active)), "gender": f"{women} / {men}",
            "age": avg(ages), "tenure": avg(tenures)}


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


# --------------------------------------------------------------------------
# Dancer form
# --------------------------------------------------------------------------
def may_edit_person(group, role):
    """Lietotāju lomas: may this person's record be changed? Leaders / repetitors (no group) — only by those
    who may change every group."""
    acc = piekluve.current()
    if (role or ROLE_DANCER) != ROLE_DANCER:
        return acc.edits_all("kopas_purs")
    return acc.can_edit("kopas_purs", group=group)

# --------------------------------------------------------------------------
# The common look (Pūrlāde v0.8 — moduli/izskats.py)
# --------------------------------------------------------------------------
LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED, \
    izskats.SELECTED
OK_BG, OK_FG, WARN_BG, WARN_FG, BAD_BG, BAD_FG = (izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG,
                                                  izskats.BAD_BG, izskats.BAD_FG)
ZEBRA = izskats.ZEBRA
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL
MODULE_COLOUR = TEAL
GROUP_BG = "#E8EEF7"
STATUS_COLOURS = {STATUS_ACTIVE: (OK_BG, OK_FG), STATUS_INACTIVE: (WARN_BG, WARN_FG), STATUS_LEFT: ("#F3F1EC", MUTED)}
CAME_MARKS = ("Ieradās", "Nokavēja")          # Cītības pūrs: marks counted as attended
DANCES_COUNTED = ("Repertuārā", "Procesā")    # Deju pūrs: dances counted for a dancer


zebra = izskats.zebra   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


row_tags = izskats.row_tags   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


def small_label(parent, text, bg=WHITE):
    return tk.Label(parent, text=text, bg=bg, fg=MUTED, font=("Segoe UI", 8, "bold"))


def years_word(n):
    return "gads" if n % 10 == 1 and n % 100 != 11 else "gadi"


def status_chip(parent, status):
    bg, fg = STATUS_COLOURS.get(status, (SELECTED, NAVY))
    return izskats.chip(parent, status, bg, fg)


def initials(first, last):
    return ((first or " ")[:1] + (last or " ")[:1]).strip().upper() or "?"


def avatar(parent, text, colour=MODULE_COLOUR, size=44, bg=WHITE):
    """Round badge with the initials."""
    c = tk.Canvas(parent, width=size, height=size, bg=bg, highlightthickness=0)
    c.create_oval(1, 1, size - 1, size - 1, fill=colour, outline="")
    c.create_text(size / 2, size / 2, text=text, fill=WHITE, font=("Segoe UI", int(size / 3.2), "bold"))
    return c


# --------------------------------------------------------------------------
# Dancer form
# --------------------------------------------------------------------------
class DancerForm(tk.Toplevel):
    """Add or edit one dancer."""

    def __init__(self, app, dancer_id=None):
        super().__init__(app.root)
        self.app, self.dancer_id = app, dancer_id
        self.configure(bg=CREAM)
        self.title("Jauns dejotājs" if dancer_id is None else "Rediģēt dejotāju")
        self.transient(app.root)
        self.grab_set()
        db = app.db

        self.vars = {f: tk.StringVar() for f in FIELDS if f != "contact"}
        self.vars["status"].set(STATUS_ACTIVE)
        self.vars["role"].set(ROLE_DANCER)
        self.vars["dancer_group"].set(DEFAULT_DANCER_GROUP)
        row = db.q("SELECT " + ", ".join(FIELDS) + " FROM dancers WHERE id=?", (dancer_id,))[0] \
            if dancer_id is not None else None
        data = dict(zip(FIELDS, row)) if row else {}

        # -- header: initials, name, group and status --------------------------------------
        head = izskats.dialog_header(self, "Jauns dejotājs" if row is None else
                                     full_name(data.get("first_name"), data.get("last_name")),
                                     "Kopas pūrs · " + ("ar * atzīmētie lauki ir obligāti" if row is None else
                                                        (data.get("role") or ROLE_DANCER).lower()),
                                     colour=MODULE_COLOUR)
        if row is not None:
            av = avatar(head, initials(data.get("first_name"), data.get("last_name")))
            av.place(relx=1.0, x=-24, y=12, anchor="ne")
            chips = tk.Frame(head, bg=WHITE)
            chips.pack(anchor="w", padx=20, pady=(0, 12))
            if data.get("dancer_group"):
                izskats.chip(chips, data["dancer_group"], GROUP_BG, NAVY).pack(side="left", padx=(0, 6))
            status_chip(chips, data.get("status") or STATUS_ACTIVE).pack(side="left")

        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        izskats.note(btns, "Datumus raksta formā DD.MM.GGGG (piemēram, 05.03.2001).", bg=WHITE).pack(side="left")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.columnconfigure(0, weight=1, uniform="col")
        body.columnconfigure(1, weight=1, uniform="col")
        body.rowconfigure(1, weight=1)

        def grid_panel(title, r, c):
            outer, _h, inner = izskats.panel(body, title)
            outer.grid(row=r, column=c, sticky="nsew", padx=(0, 7) if c == 0 else (7, 0), pady=(0, 12) if r == 0 else 0)
            g = tk.Frame(inner, bg=WHITE)
            g.pack(fill="both", expand=True, padx=14, pady=(6, 12))
            g.columnconfigure(0, weight=1, uniform="f")
            g.columnconfigure(1, weight=1, uniform="f")
            return g

        def field(g, text, r, c, widget):
            small_label(g, text.upper()).grid(row=r, column=c, sticky="w", padx=(0 if c == 0 else 10, 0), pady=(6, 0))
            widget.grid(row=r + 1, column=c, sticky="ew", padx=(0 if c == 0 else 10, 0))
            return widget

        # -- personal data -------------------------------------------------------------
        g = grid_panel("Personas dati", 0, 0)
        first = field(g, "Vārds *", 0, 0, ttk.Entry(g, textvariable=self.vars["first_name"], width=20))
        field(g, "Uzvārds", 0, 1, ttk.Entry(g, textvariable=self.vars["last_name"], width=20))
        field(g, "Dzimums *", 2, 0, ttk.Combobox(g, textvariable=self.vars["gender"], values=GENDERS,
                                                 state="readonly", width=18))
        field(g, "Dzimšanas datums", 2, 1, ttk.Entry(g, textvariable=self.vars["birth_date"], width=20))
        field(g, "Augums (cm)", 4, 0, ttk.Entry(g, textvariable=self.vars["height"], width=20))
        field(g, "Apģērba izmērs", 4, 1, ttk.Combobox(g, textvariable=self.vars["clothing_size"],
                                                      values=CLOTHING_SIZES, width=18))

        # -- in the collective ----------------------------------------------------------
        g = grid_panel("Kolektīvā", 1, 0)
        self.group_cb = field(g, "Grupa *", 0, 0, ttk.Combobox(g, textvariable=self.vars["dancer_group"],
                                                                values=DANCER_GROUPS, width=18, state="readonly"))
        self.role_cb = field(g, "Loma kolektīvā", 0, 1, ttk.Combobox(g, textvariable=self.vars["role"],
                                                                      values=PERSON_ROLES, width=18, state="readonly"))
        field(g, "Statuss", 2, 0, ttk.Combobox(g, textvariable=self.vars["status"], values=DANCER_STATUSES,
                                               state="readonly", width=18))
        field(g, "Iestājās (datums)", 2, 1, ttk.Entry(g, textvariable=self.vars["join_date"], width=20))
        # Pūrlāde v0.9.13: kad izstājās — Kolektīva vēsturē tas parādās šajā datumā, nevis statusa maiņas dienā
        self.left_entry = field(g, "Izstājās (datums)", 4, 1, ttk.Entry(g, textvariable=self.vars["left_date"],
                                                                          width=20))
        self.left_note = izskats.note(g, "", bg=WHITE, wrap=330)
        self.left_note.grid(row=6, column=0, columnspan=2, sticky="w", pady=(4, 0))
        izskats.note(g, "Vadītāji un repetitori netiek skaitīti dejotāju skaitā un netiek piedāvāti deju sastāvos, "
                        "tērpu izsniegšanā un apmeklējumā.", bg=WHITE, wrap=330).grid(row=7, column=0, columnspan=2,
                                                                                       sticky="w", pady=(10, 0))
        self._loading = True
        self.vars["status"].trace_add("write", lambda *a: self.status_changed(fill=not self._loading))

        # -- app roles (extra app roles only for dancers) ---------------------------------
        outer, self.roles_head, inner = izskats.panel(body, "Lietotnes lomas", subtitle="")
        outer.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 12))
        box = tk.Frame(inner, bg=WHITE)
        box.pack(fill="both", expand=True, padx=14, pady=(6, 12))
        self.app_role_vars = {r: tk.BooleanVar(value=False) for r in EXTRA_APP_ROLES}
        self.base_role_var = tk.BooleanVar(value=True)
        cb_opts = dict(bg=WHITE, fg=NAVY, activebackground=WHITE, selectcolor=WHITE, font=FONT, anchor="w")
        self.base_role_cb = tk.Checkbutton(box, text=APP_ROLE_DANCER, variable=self.base_role_var,
                                           state="disabled", **cb_opts)
        self.base_role_cb.grid(row=0, column=0, sticky="w", padx=(0, 10))
        self.app_role_cbs = []
        per_row = 2   # many app roles: several rows of check boxes
        for i, r in enumerate(EXTRA_APP_ROLES, start=1):
            cb = tk.Checkbutton(box, text=r, variable=self.app_role_vars[r], **cb_opts)
            cb.grid(row=i // per_row, column=i % per_row, sticky="w", padx=(0, 10))
            self.app_role_cbs.append(cb)
        role_rows = len(EXTRA_APP_ROLES) // per_row + 1
        self.app_role_note = tk.Label(box, bg=WHITE, fg=MUTED, justify="left", font=FONT_SMALL, wraplength=380,
                                      anchor="w")
        self.app_role_note.grid(row=role_rows, column=0, columnspan=per_row, sticky="ew", pady=(6, 0))
        small_label(box, "E-PASTS KABATAS PŪRLĀDEI").grid(row=role_rows + 1, column=0, columnspan=per_row,
                                                          sticky="w", pady=(10, 0))
        self.email_var = tk.StringVar()
        self.email_entry = ttk.Entry(box, textvariable=self.email_var, width=36)
        self.email_entry.grid(row=role_rows + 2, column=0, columnspan=per_row, sticky="ew")
        izskats.note(box, "Ar šo e-pastu cilvēks piesakās Kabatas Pūrlādē (uz to tiek sūtīts pieteikšanās kods). "
                          "Ja lauks ir tukšs, lietotnē pieteikties nevar.", bg=WHITE, wrap=380).grid(
            row=role_rows + 3, column=0, columnspan=per_row, sticky="w", pady=(4, 0))
        self.vars["role"].trace_add("write", lambda *a: self.update_app_roles())

        # -- contacts ------------------------------------------------------------------
        outer, _h, inner = izskats.panel(body, "Kontakti")
        outer.grid(row=1, column=1, sticky="nsew", padx=(7, 0))
        self.contact = tk.Text(inner, width=40, height=4, wrap="word", relief="flat", bd=0, highlightthickness=1,
                               highlightbackground=FIELD_LINE, highlightcolor=NAVY, fg=NAVY, font=FONT, padx=6, pady=4)
        self.contact.pack(fill="both", expand=True, padx=14, pady=(8, 12))
        self.bind("<Escape>", lambda e: self.destroy())

        self.after_idle(self.loaded)
        if row is not None:
            for f, v in data.items():
                if f == "contact":
                    self.contact.insert("1.0", v or "")
                elif f in ("birth_date", "join_date", "left_date"):
                    self.vars[f].set(show_date(v))
                else:
                    self.vars[f].set(v or "")
            if self.vars["status"].get() not in DANCER_STATUSES:
                self.vars["status"].set(STATUS_ACTIVE)
            if self.vars["role"].get() not in PERSON_ROLES:
                self.vars["role"].set(ROLE_DANCER)
            stored = db.q("SELECT app_roles FROM dancers WHERE id=?", (dancer_id,))[0][0]
            for r in parse_app_roles(stored):
                self.app_role_vars[r].set(True)
            self.email_var.set(app_email(db.con, dancer_id))
        self.update_app_roles()
        # lietotāju lomas: what may be changed here
        acc = piekluve.current()
        self.assign_roles = acc.assign_roles
        self.old = {"group": self.vars["dancer_group"].get(), "role": self.vars["role"].get() or ROLE_DANCER,
                    "app_roles": [r for r, var in self.app_role_vars.items() if var.get()],
                    "email": self.email_var.get().strip().lower()}
        if not self.assign_roles:
            # roles and the login e-mail give rights — only for those who assign the app roles
            self.role_cb.configure(state="disabled")
            for cb in self.app_role_cbs:
                cb.configure(state="disabled")
            self.email_entry.configure(state="readonly")
            self.roles_head.subtitle.configure(text="maina vadītājs vai sistēmas administrators")
            self.app_role_note.configure(text="Lomas, lomu kolektīvā un e-pastu maina vadītājs vai sistēmas "
                                              "administrators.")
        if dancer_id is None:
            allowed = acc.groups("kopas_purs")
            self.group_cb.configure(values=allowed)
            if self.vars["dancer_group"].get() not in allowed and allowed:
                self.vars["dancer_group"].set(allowed[0])
        elif not may_edit_person(self.old["group"], self.old["role"]):
            piekluve.make_readonly(self, note=("Tikai skatīšanai — " +
                                   ("jūsu lomai Kopas pūrā nav labošanas tiesību." if acc.view_only("kopas_purs")
                                    else f"labot var tikai {acc.scope_text('kopas_purs')}s dejotājus.")))
        first.focus_set()
        self.after(100, lambda: fit_min_size(self))

    def update_app_roles(self):
        """Extra app roles can be given only to dancers; leaders and rehearsal directors get theirs automatically."""
        role = self.vars["role"].get() or ROLE_DANCER
        dancer = role == ROLE_DANCER
        self.base_role_cb.configure(text=APP_ROLE_DANCER if dancer else f"{role} (automātiski)")
        for cb in self.app_role_cbs:
            cb.configure(state="normal" if dancer and getattr(self, "assign_roles", True) else "disabled")
        # a group only for dancers
        if dancer:
            self.group_cb.configure(state="readonly")
            if self.vars["dancer_group"].get() not in DANCER_GROUPS:
                self.vars["dancer_group"].set(DEFAULT_DANCER_GROUP)
        else:
            self.vars["dancer_group"].set("")
            self.group_cb.configure(state="disabled")
        if getattr(self, "assign_roles", True):
            self.app_role_note.configure(text=(
                "Visiem dejotājiem ir lietotnes loma “Dejotājs”; pārējās lomas piešķir kolektīva vadītājs vai "
                "sistēmas administrators. Tās nosaka, ko cilvēks redz un drīkst mobilajā lietotnē un datorā."
                if dancer else
                f"Vadītājiem un repetitoriem lietotnes loma “{role}” tiek piešķirta automātiski; "
                "papildu lomas ir tikai dejotājiem."))

    def loaded(self):
        self._loading = False
        self.status_changed(fill=False)

    def status_changed(self, fill=True):
        """“Izstājās (datums)” only for somebody who has left; when the status is changed to “Izstājies” now, today
        is offered — it can be changed to the real day."""
        left = self.vars["status"].get() == STATUS_LEFT
        try:
            self.left_entry.configure(state="normal" if left else "disabled")
        except (tk.TclError, AttributeError):
            return
        if fill and left and not self.vars["left_date"].get().strip():
            self.vars["left_date"].set(date.today().strftime("%d.%m.%Y"))
        self.left_note.configure(text="Ierakstiet īsto dienu — Kolektīva vēsturē tā būs izstāšanās diena."
                                 if left else "")

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        v = {f: var.get().strip() for f, var in self.vars.items()}
        v["contact"] = self.contact.get("1.0", tk.END).strip()
        if not self.assign_roles:   # these fields give rights: never changed by others (also not by mistake)
            v["role"] = self.old["role"]
        if not may_edit_person(v["dancer_group"], v["role"]) or (
                self.dancer_id is not None and not may_edit_person(self.old["group"], self.old["role"])):
            acc = piekluve.current()
            return piekluve.deny(self, f"Labot var tikai {acc.scope_text('kopas_purs')}s dejotājus.")
        if not v["first_name"]:
            messagebox.showwarning("Trūkst datu", "Lūdzu, norādiet dejotāja vārdu.", parent=self)
            return
        if v["gender"] not in GENDERS:
            messagebox.showwarning("Dzimums", "Izvēlieties dzimumu: vīrietis vai sieviete.", parent=self)
            return
        if v["status"] != STATUS_LEFT:
            v["left_date"] = ""       # only somebody who has left has a leaving date (empty — not known)
        for key, title in (("birth_date", "Dzimšanas datums"), ("join_date", "Iestāšanās datums"),
                           ("left_date", "Izstāšanās datums")):
            parsed = parse_date(v[key])
            if parsed is None:
                messagebox.showwarning("Datums", f"{title}: nepareizs datums. Izmantojiet formātu DD.MM.GGGG, "
                                                 "piemēram, 05.03.2001.", parent=self)
                return
            v[key] = parsed
        if v["height"]:
            h = normalize_height(v["height"])
            if not h:
                messagebox.showwarning("Augums", "Augumu norādiet centimetros (piemēram, 172).", parent=self)
                return
            v["height"] = h
        email = self.email_var.get().strip().lower()
        if not self.assign_roles:
            email = self.old["email"]
        problem = check_app_email(self.app.db.con, self.dancer_id, email)
        if problem:
            messagebox.showwarning("E-pasts", problem, parent=self)
            return
        db = self.app.db
        if self.dancer_id is None:
            same = db.q("SELECT COUNT(*) FROM dancers WHERE LOWER(name)=LOWER(?) AND "
                        "COALESCE(birth_date,'')=?", (full_name(v["first_name"], v["last_name"]),
                                                       v["birth_date"]))[0][0]
            if same and not messagebox.askyesno(
                    "Dublikāts", "Šāds dejotājs jau ir sarakstā. Vai tomēr pievienot vēl vienu?", parent=self):
                return
        new_id = save_dancer(db, v, self.dancer_id)
        extra = [r for r, var in self.app_role_vars.items() if var.get()] if v["role"] in ("", ROLE_DANCER) else []
        if not self.assign_roles:
            extra = self.old["app_roles"] if v["role"] in ("", ROLE_DANCER) else []
        db.x("UPDATE dancers SET app_roles=? WHERE id=?", (app_roles_text(extra), new_id))
        self.app.sync_roles()   # Kolektīva vēsture: a role given / taken away today
        try:
            set_app_email(db.con, new_id, email)
        except ValueError as exc:
            messagebox.showwarning("E-pasts", f"Dejotājs saglabāts, bet e-pastu neizdevās saglabāt:\n{exc}",
                                   parent=self)
        self.app.refresh(select=new_id)
        self.destroy()


# --------------------------------------------------------------------------
# Import from Excel / CSV
# --------------------------------------------------------------------------
IMPORT_ALIASES = {
    "first_name": ["vards", "first name", "firstname"],
    "last_name": ["uzvards", "last name", "surname", "lastname"],
    "full_name": ["vards uzvards", "vards un uzvards", "dejotajs", "dejotaja vards", "dejotaja vards uzvards",
                  "full name", "name"],
    "gender": ["dzimums", "gender", "sex"],
    "birth_date": ["dzimsanas datums", "dzim datums", "dzimis", "dzimusi", "birth date", "date of birth", "dob"],
    "join_date": ["iestasanas datums", "iestajies", "iestajas", "kolektiva kops", "dejo kops", "join date"],
    "status": ["statuss", "status"],
    "role": ["loma", "loma kolektiva", "amats", "role"],
    "dancer_group": ["grupa", "dejotaju grupa", "group"],
    "height": ["augums", "augums cm", "garums", "height"],
    "clothing_size": ["izmers", "apgerba izmers", "size"],
    "contact": ["kontakti", "kontakts", "kontaktinformacija", "telefons", "talrunis", "contact", "phone"],
    "app_email": ["e pasts", "epasts", "e mail", "email", "e pasts kabatas purladei", "kabatas purlades e pasts",
                  "e pasts kabatas purlade", "lietotnes e pasts"],
}


def import_dancers(db, rows):
    aliases = {k: {_norm(a) for a in v} for k, v in IMPORT_ALIASES.items()}
    header, mp, found = None, {}, []
    for i, row in enumerate(rows):
        if any(c for c in row):
            header = i
            for col, cell in enumerate(row):
                n = _norm(cell)
                for field, names in aliases.items():
                    if field not in mp and n in names:
                        mp[field] = col
            found = [c for c in row if c]
            break
    if header is None or not ({"first_name", "full_name"} & set(mp)):
        return {"error": "Failā nav atrasta kolonna “Vārds” (vai “Vārds uzvārds”).\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}
    split_first = "first_name" in mp and "last_name" not in mp and "full_name" not in mp

    def cell(row, field):
        col = mp.get(field)
        return row[col].strip() if col is not None and col < len(row) else ""

    existing = {(_norm(n), b or ""): did for did, n, b in db.q("SELECT id, name, birth_date FROM dancers")}
    added, emails_added, skipped = 0, 0, []

    def give_email(row_no, dancer_id, name):
        """The e-mail column: Kabatas Pūrlāde login. Returns True when it was saved."""
        email = cell(rows[row_no - 1], "app_email").lower()
        if not email or email == app_email(db.con, dancer_id):
            return False
        try:
            set_app_email(db.con, dancer_id, email)
            return True
        except ValueError as exc:
            skipped.append((row_no, f"{name}: e-pasts “{email}” nav saglabāts — {exc}"))
            return False

    for i in range(header + 1, len(rows)):
        row = rows[i]
        if not any(row):
            continue
        first, last = cell(row, "first_name"), cell(row, "last_name")
        if split_first or (not first and cell(row, "full_name")):
            parts = (first or cell(row, "full_name")).split(None, 1)
            first, last = (parts[0] if parts else ""), (parts[1] if len(parts) > 1 else last)
        if not first:
            skipped.append((i + 1, "nav vārda"))
            continue
        gender = normalize_gender(cell(row, "gender"))
        if gender is None:
            skipped.append((i + 1, f"nezināms dzimums “{cell(row, 'gender')}”"))
            continue
        role = normalize_role(cell(row, "role"))
        if role is None:
            skipped.append((i + 1, f"nezināma loma “{cell(row, 'role')}”"))
            continue
        group = next((g for g in DANCER_GROUPS if _norm(g) == _norm(cell(row, "dancer_group"))), None)
        if cell(row, "dancer_group") and group is None:
            skipped.append((i + 1, f"nezināma grupa “{cell(row, 'dancer_group')}” (der: {', '.join(DANCER_GROUPS)})"))
            continue
        if role == ROLE_DANCER:
            group = group or DEFAULT_DANCER_GROUP
        else:
            group = ""
        status = normalize_status(cell(row, "status"))
        if status is None:
            skipped.append((i + 1, f"nezināms statuss “{cell(row, 'status')}”"))
            continue
        dates = {}
        bad = None
        for key in ("birth_date", "join_date"):
            dates[key] = parse_date(cell(row, key))
            if dates[key] is None:
                bad = f"nepareizs datums “{cell(row, key)}”"
        if bad:
            skipped.append((i + 1, bad))
            continue
        key = (_norm(full_name(first, last)), dates["birth_date"])
        if key in existing:
            # an existing dancer: only the Kabatas Pūrlāde e-mail is taken from the file
            if cell(row, "app_email"):
                emails_added += give_email(i + 1, existing[key], full_name(first, last))
            else:
                skipped.append((i + 1, f"dejotājs “{full_name(first, last)}” jau ir sarakstā"))
            continue
        new_id = save_dancer(db, {"first_name": first, "last_name": last, "gender": gender,
                         "birth_date": dates["birth_date"], "join_date": dates["join_date"], "status": status,
                         "height": normalize_height(cell(row, "height")),
                         "clothing_size": cell(row, "clothing_size").upper(), "contact": cell(row, "contact"),
                         "role": role, "dancer_group": group})
        existing[key] = new_id
        added += 1
        give_email(i + 1, new_id, full_name(first, last))
    return {"error": None, "added": added, "emails": emails_added, "skipped": skipped}


# --------------------------------------------------------------------------
# Views of the module
# --------------------------------------------------------------------------
TABLE_COLUMNS = [
    ("name", "Vārds, uzvārds", 190), ("dancer_group", "Grupa", 65), ("status", "Statuss", 90),
    ("gender", "Dzimums", 80), ("age", "Vecums", 60), ("tenure", "Stāžs", 60), ("roles", "Lomas", 200),
    ("issued", "Tērpi", 55), ("birth_date", "Dzimšanas datums", 115), ("birthday", "Dzimšanas diena", 115),
    ("name_day", "Vārda diena", 140), ("join_date", "Iestājies", 95), ("app_email", "E-pasts (Kabatas Pūrlāde)", 200),
    ("height", "Augums", 65), ("clothing_size", "Izmērs", 60), ("contact", "Kontakti", 220),
]
COLUMN_SETS = {
    "Pamata": ["name", "dancer_group", "status", "age", "tenure", "roles", "issued"],
    "Kontakti un lietotne": ["name", "dancer_group", "status", "app_email", "roles", "contact"],
    "Dzimšanas un vārda dienas": ["name", "dancer_group", "birth_date", "age", "birthday", "name_day"],
    "Augums un izmēri": ["name", "dancer_group", "gender", "height", "clothing_size", "issued"],
    "Visas kolonnas": [c[0] for c in TABLE_COLUMNS],
}
NO_EMAIL = "Bez e-pasta"


def load_people(db):
    """All people of Kopas pūrs as dicts (dancers, leaders and rehearsal directors)."""
    issued_sql = ("(SELECT COUNT(*) FROM checkouts c WHERE c.dancer_id = d.id AND "
                  "TRIM(COALESCE(c.return_date,'')) = '')") if db.has_checkouts() else "0"
    rows = db.q("SELECT d.id, d.first_name, d.last_name, d.gender, d.birth_date, d.join_date, d.status, "
                "d.height, d.clothing_size, d.contact, d.role, d.app_roles, d.dancer_group, " + issued_sql +
                ", COALESCE(d.left_date, '') FROM dancers d")
    emails = app_emails(db.con)
    records = []
    for did, first, last, gender, birth, join, status, height, size, contact, role, app_roles, group, issued, left \
            in rows:
        role = role if role in PERSON_ROLES else ROLE_DANCER
        extra = parse_app_roles(app_roles) if role == ROLE_DANCER else []
        records.append({
            "id": did, "first_name": first or "", "last_name": last or "", "name": full_name(first, last),
            "gender": gender or "", "birth_date": birth or "", "birthday": birthday_text(birth),
            "name_day": name_day_text(first or ""), "age": years_between(birth), "join_date": join or "",
            "tenure": years_between(join), "status": status or STATUS_ACTIVE, "height": height or "",
            "clothing_size": size or "", "issued": issued or 0, "contact": contact or "", "role": role,
            "app_roles": ", ".join(app_roles_of(role, app_roles)), "extra_roles": extra,
            "roles": role if role != ROLE_DANCER else (", ".join(extra) or "—"),
            "dancer_group": group or "", "app_email": emails.get(did, ""), "left_date": left or ""})
    return records


def group_figures(records):
    """Card figures for these dancers (dancers only): {key: (value, sub)}."""
    dancers = [r for r in records if is_dancer(r["role"])]
    st = dancer_stats(dancers)
    active = [r for r in dancers if r["status"] == STATUS_ACTIVE]
    pause = sum(1 for r in dancers if r["status"] == STATUS_INACTIVE)
    no_mail = sum(1 for r in active if not r["app_email"])
    return {"total": (st["total"], f"{st['active']} aktīvi, {pause} uz pauzes"),
            "gender": (st["gender"], "aktīvie"),
            "age": (st["age"], "aktīvie, gadi"),
            "tenure": (st["tenure"] + (" g." if st["tenure"] != "—" else ""), "aktīvie"),
            "noemail": (str(no_mail), "nevar pieslēgties lietotnei" if no_mail else "visiem aktīvajiem ir")}


def bar_chart(canvas, items, colour):
    """items: [(label, value)] — vertical bars with the value on top."""
    c = canvas
    c.delete("all")
    w, h = c.winfo_width(), c.winfo_height()
    if w < 60 or h < 60:
        return
    if not items or not any(v for _l, v in items):
        c.create_text(w / 2, h / 2, text="Nav datu", fill=MUTED, font=FONT)
        return
    top, bottom, left = 18, 26, 6
    slot = (w - 2 * left) / len(items)
    bar = min(46, slot * 0.6)
    peak = max(v for _l, v in items)
    base = h - bottom
    for i, (label, value) in enumerate(items):
        cx = left + slot * (i + 0.5)
        y = base - (base - top) * value / peak if peak else base
        if value:
            c.create_rectangle(cx - bar / 2, y, cx + bar / 2, base, fill=colour, outline="")
        c.create_text(cx, y - 8, text=str(value), fill=NAVY, font=FONT_BOLD)
        c.create_text(cx, base + 6, text=label, anchor="n", fill="#4A4535", font=FONT_SMALL)
    c.create_line(left, base, w - left, base, fill=LINE)


class DancersView(tk.Frame):
    """Dejotāji: cards, filters, the table and a panel with the chosen person."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        self.records = []
        self.sort_key, self.sort_desc = "name", False

        cards = tk.Frame(self, bg=CREAM)
        cards.pack(fill="x", padx=20, pady=(14, 0))
        self.card_vars, self.card_titles = {}, {}
        specs = [("total", "Kopā dejotāju", NAVY), ("gender", "Sievietes / vīrieši", RED),
                 ("age", "Vidējais vecums", "#8A6400"), ("tenure", "Vidējais stāžs", TEAL),
                 ("noemail", NO_EMAIL, RED)]
        for i, (key, title, colour) in enumerate(specs):
            cards.columnconfigure(i, weight=1, uniform="k")
            card = tk.Frame(cards, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0 if i == len(specs) - 1 else 5))
            tk.Frame(card, bg=colour, width=4).pack(side="left", fill="y")
            inner = tk.Frame(card, bg=WHITE)
            inner.pack(side="left", fill="both", expand=True, padx=14, pady=9)
            tvar, value, sub = tk.StringVar(value=title), tk.StringVar(value="—"), tk.StringVar()
            self.card_vars[key], self.card_titles[key] = (value, sub), tvar
            tk.Label(inner, textvariable=tvar, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x")
            tk.Label(inner, textvariable=value, bg=WHITE, fg=colour, font=("Georgia", 20, "bold"), anchor="w").pack(
                fill="x")
            tk.Label(inner, textvariable=sub, bg=WHITE, fg="#4A4535", font=("Segoe UI", 8), anchor="w").pack(fill="x")
            if key == "noemail":   # click: show only active dancers without the app e-mail
                for w in [card, inner] + list(inner.winfo_children()):
                    w.configure(cursor="hand2")
                    w.bind("<Button-1>", lambda e: self.toggle_no_email())
            else:
                CardTooltip(card, colour, title, lambda k=key: self.group_rows(k))

        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=20, pady=(12, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        izskats.search_box(bar, app.search, width=18).grid(row=1, column=0, sticky="w", padx=(0, 12))
        small_label(bar, "MEKLĒT").grid(row=0, column=0, sticky="w")
        combos = [("GRUPA", app.f_group, [ALL] + DANCER_GROUPS, 9),
                  ("STATUSS", app.f_status, [ALL] + DANCER_STATUSES + [NO_EMAIL], 12),
                  ("LOMA", app.f_role, [ALL, ROLE_DANCER + "i", LEADERS] + PERSON_ROLES[1:] + EXTRA_APP_ROLES, 18),
                  ("DZIMUMS", app.f_gender, [ALL] + GENDERS, 10),
                  ("KOLONNAS", app.f_columns, list(COLUMN_SETS), 20)]
        for i, (title, var, values, width) in enumerate(combos, start=1):
            small_label(bar, title).grid(row=0, column=i, sticky="w")
            cb = ttk.Combobox(bar, textvariable=var, values=values, state="readonly", width=width)
            cb.grid(row=1, column=i, sticky="w", padx=(0, 10))
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        clear = tk.Label(bar, text="Notīrīt filtrus", bg=WHITE, fg=NAVY, font=("Segoe UI", 9, "underline"),
                         cursor="hand2")
        clear.grid(row=1, column=len(combos) + 1, sticky="w")
        clear.bind("<Button-1>", lambda e: app.clear_filters())

        info = tk.Frame(self, bg=CREAM)
        info.pack(fill="x", padx=20, pady=(8, 0))
        self.count_var = tk.StringVar()
        tk.Label(info, textvariable=self.count_var, bg=CREAM, fg=NAVY, font=FONT_BOLD).pack(side="left")
        izskats.note(info, "Klikšķis uz virsraksta — kārtot; dubultklikšķis — atvērt dejotāju.").pack(side="right")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=(6, 14))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=0, minsize=300)
        body.rowconfigure(0, weight=1)
        table = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        table.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        holder = tk.Frame(table, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in TABLE_COLUMNS], show="headings", selectmode="browse")
        for key, title, width in TABLE_COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=45, anchor="center" if key in ("age", "tenure", "issued")
                             else "w", stretch=key in ("name", "roles", "contact", "app_email"))
        zebra(self.tree)
        self.tree.tag_configure(STATUS_INACTIVE, foreground=WARN_FG)
        self.tree.tag_configure(STATUS_LEFT, foreground=GREY)
        self.tree.tag_configure("leader", foreground=TEAL, font=FONT_BOLD)
        self.tree.bind("<Double-1>", lambda e: self.app.edit())
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_person())
        make_tree_with_scroll(holder, self.tree)
        self.side = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1,
                             width=300)
        self.side.grid(row=0, column=1, sticky="nsew")
        self.side.pack_propagate(False)
        self.refresh()

    # -- data --------------------------------------------------------------------------
    def toggle_no_email(self):
        self.app.f_status.set(ALL if self.app.f_status.get() == NO_EMAIL else NO_EMAIL)
        self.refresh()

    def group_rows(self, key):
        recs = self.app.load_cached()
        groups = list(DANCER_GROUPS) + (["" ] if any(r["dancer_group"] not in DANCER_GROUPS
                                                       for r in recs if is_dancer(r["role"])) else [])
        return [(g or "Bez grupas", group_figures([r for r in recs if (r["dancer_group"] or "") == g or
                                                   (not g and r["dancer_group"] not in DANCER_GROUPS)])[key][0])
                for g in groups]

    def sort_by(self, key):
        self.sort_desc = not self.sort_desc if key == self.sort_key else False
        self.sort_key = key
        self.refresh()

    def refresh(self, select=None):
        app = self.app
        records = app.load_cached(reload=True)
        group = app.f_group.get()
        base = [r for r in records if group == ALL or r["dancer_group"] == group]
        figures = group_figures(base)
        for key, (value, sub) in figures.items():
            self.card_vars[key][0].set(value)
            self.card_vars[key][1].set(sub)
        self.card_titles["total"].set("Kopā dejotāju" if group == ALL else f"{group} grupā")
        term = _norm(app.search.get())
        shown = []
        for r in records:
            if app.f_gender.get() != ALL and r["gender"] != app.f_gender.get():
                continue
            status = app.f_status.get()
            if status == NO_EMAIL:
                if not (is_dancer(r["role"]) and r["status"] == STATUS_ACTIVE and not r["app_email"]):
                    continue
            elif status != ALL and r["status"] != status:
                continue
            if group != ALL and r["dancer_group"] != group:
                continue
            role_filter = app.f_role.get()
            if role_filter == ROLE_DANCER + "i" and not is_dancer(r["role"]):
                continue
            if role_filter == LEADERS and is_dancer(r["role"]):
                continue
            if role_filter in PERSON_ROLES[1:] and r["role"] != role_filter:
                continue
            if role_filter in EXTRA_APP_ROLES and role_filter not in r["extra_roles"]:
                continue
            if term and term not in _norm(" ".join(str(r[k]) for k in
                                                   ("name", "contact", "clothing_size", "app_roles", "dancer_group",
                                                    "app_email"))):
                continue
            shown.append(r)

        def sort_value(r):
            if self.sort_key in ("birthday", "name_day"):  # by calendar day, not alphabetically
                k = (birthday_sort_key(r["birth_date"]) if self.sort_key == "birthday"
                     else name_day_sort_key(r["first_name"]))
                return (k is None, k or (0, 0))
            v = r[self.sort_key]
            if self.sort_key == "height":
                v = int(v) if str(v).isdigit() else None
            if isinstance(v, int) or v is None:
                return (v is None, v or 0)
            return (v in ("", "—"), _norm(v))
        shown.sort(key=lambda r: (_norm(r["first_name"]), _norm(r["last_name"])))
        shown.sort(key=sort_value, reverse=self.sort_desc)
        for key, title, _w in TABLE_COLUMNS:
            arrow = (" ▼" if self.sort_desc else " ▲") if key == self.sort_key else ""
            self.tree.heading(key, text=title + arrow)
        self.tree["displaycolumns"] = COLUMN_SETS.get(app.f_columns.get(), COLUMN_SETS["Pamata"])

        keep = select or (self.tree.selection()[0] if self.tree.selection() else None)
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(shown):
            values = []
            for key, _t, _w in TABLE_COLUMNS:
                v = r[key]
                if key in ("age", "tenure"):
                    v = "" if v is None else v
                elif key == "issued":
                    v = v if v else "—"
                elif key == "contact":
                    v = " ".join(str(v).split())
                elif key in ("birth_date", "join_date"):
                    v = show_date(v)
                values.append(v)
            tag = r["status"] if r["status"] != STATUS_ACTIVE else ""
            self.tree.insert("", "end", iid=str(r["id"]), values=values,
                             tags=row_tags(i, tag, "" if is_dancer(r["role"]) else "leader"))
        if keep is not None and self.tree.exists(str(keep)):
            self.tree.selection_set(str(keep))
            self.tree.see(str(keep))
        n_dancers = sum(1 for r in records if is_dancer(r["role"]))
        self.count_var.set(f"Rādīti {len(shown)} no {len(records)}  ·  dejotāji {n_dancers}, vadītāji un "
                           f"repetitori {len(records) - n_dancers}")
        self.show_person()

    # -- the chosen person --------------------------------------------------------------
    def show_person(self):
        side = self.side
        for w in side.winfo_children():
            w.destroy()
        sel = self.tree.selection()
        r = next((x for x in self.app.load_cached() if sel and str(x["id"]) == sel[0]), None)
        if r is None:
            izskats.note(side, "Izvēlieties dejotāju sarakstā — šeit būs redzami viņa dati, lomas, tērpi, cītība "
                               "un dejas.\n\nDubultklikšķis atver dejotāja logu.", bg=WHITE, wrap=260).pack(
                fill="x", padx=16, pady=16)
            return
        db = self.app.db
        band = tk.Frame(side, bg=TEAL)
        band.pack(fill="x")
        top = tk.Frame(band, bg=TEAL)
        top.pack(fill="x", padx=16, pady=12)
        avatar(top, initials(r["first_name"], r["last_name"]), colour="#24675A", size=40, bg=TEAL).pack(
            side="left", padx=(0, 10))
        txt = tk.Frame(top, bg=TEAL)
        txt.pack(side="left", fill="x", expand=True)
        tk.Label(txt, text=r["name"], bg=TEAL, fg=WHITE, font=("Georgia", 14, "bold"), anchor="w", justify="left",
                 wraplength=210).pack(fill="x")
        parts = [f"{r['dancer_group']} grupa" if r["dancer_group"] else r["role"], r["status"]]
        if r["tenure"] is not None:
            parts.append(f"{r['tenure']} {years_word(r['tenure'])}")
        tk.Label(txt, text=" · ".join(parts), bg=TEAL, fg=WHITE, font=FONT_SMALL, anchor="w").pack(fill="x")

        facts = tk.Frame(side, bg=WHITE)
        facts.pack(fill="x", padx=16, pady=(12, 0))
        facts.columnconfigure(1, weight=1)
        attend = self.attendance(r["id"])
        dances = self.dance_count(r["id"])
        rows = [
            ("Dzimšanas d.", show_date(r["birth_date"]) + (f" ({r['age']} g.)" if r["age"] is not None else "") or "—"),
            ("Vārda diena", r["name_day"] or "—"),
            ("Iestājās", show_date(r["join_date"]) or "—"),
            ("Izstājās", (show_date(r.get("left_date", "")) or "datums nav zināms")
             if r["status"] == STATUS_LEFT else None),
            ("Loma", r["role"] if not is_dancer(r["role"]) else None),
            ("Lietotnē", r["app_roles"] or "—"),
            ("E-pasts", r["app_email"] or "nav — lietotnē pieteikties nevar"),
            ("Augums · izmērs", " · ".join(x for x in (f"{r['height']} cm" if r["height"] else "",
                                                       r["clothing_size"]) if x) or "—"),
            ("Tērpi", f"{r['issued']} izsniegti" if r["issued"] else "nav izsniegtu"),
            ("Cītība", attend),
            ("Dejas", dances),
        ]
        i = 0
        for k, v in rows:
            if v is None:
                continue
            tk.Label(facts, text=k, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="nw").grid(row=i, column=0,
                                                                                         sticky="nw", pady=2)
            colour = RED if (k == "E-pasts" and not r["app_email"]) else NAVY
            tk.Label(facts, text=v, bg=WHITE, fg=colour, font=FONT_SMALL, anchor="w", justify="left",
                     wraplength=170).grid(row=i, column=1, sticky="w", padx=(10, 0), pady=2)
            i += 1
        if r["contact"].strip():
            tk.Frame(side, bg=LINE_SOFT, height=1).pack(fill="x", pady=(10, 0))
            small_label(side, "KONTAKTI").pack(anchor="w", padx=16, pady=(8, 2))
            tk.Label(side, text=r["contact"].strip(), bg=WHITE, fg=NAVY, font=FONT_SMALL, anchor="w", justify="left",
                     wraplength=260).pack(fill="x", padx=16)
        acts = tk.Frame(side, bg=WHITE)
        acts.pack(side="bottom", fill="x", padx=16, pady=14)
        editable = may_edit_person(r["dancer_group"], r["role"])
        ttk.Button(acts, text="Rediģēt" if editable else "Atvērt", style="Accent.TButton",
                   command=lambda: DancerForm(self.app, r["id"])).pack(side="left", fill="x", expand=True)
        if editable:
            ttk.Button(acts, text="Dzēst", style="Danger.TButton",
                       command=lambda: self.app.delete(r["id"])).pack(side="left", padx=(8, 0))

    def attendance(self, did):
        """'92 % (šosezon, 25 atzīmes)' from Cītības pūrs; '—' when nothing is marked."""
        db = self.app.db
        try:
            if not db.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attendance'"):
                return "—"
            today = date.today()
            season = date(today.year if today.month >= 9 else today.year - 1, 9, 1).isoformat()
            marks = [m for (m,) in db.q("SELECT a.mark FROM attendance a JOIN attendance_sessions s ON "
                                        "s.id = a.session_id WHERE a.dancer_id=? AND s.session_date >= ? AND "
                                        "TRIM(COALESCE(a.mark,'')) <> ''", (did, season))]
        except sqlite3.Error:
            return "—"
        if not marks:
            return "šosezon vēl nav atzīmju"
        came = sum(1 for m in marks if m in CAME_MARKS)
        return f"{round(100 * came / len(marks))} % (šosezon, {len(marks)} atzīmes)"

    def dance_count(self, did):
        db = self.app.db
        try:
            if not db.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dance_cast'"):
                return "—"
            rows = db.q("SELECT x.title, c.role FROM dance_cast c JOIN dances x ON x.id = c.dance_id "
                        "WHERE c.dancer_id=? AND x.status IN (?, ?)", (did,) + DANCES_COUNTED)
        except sqlite3.Error:
            return "—"
        if not rows:
            return "nevienā dejā"
        reserve = sum(1 for _t, role in rows if role == "Rezerve")
        return f"{len(rows) - reserve} pamatsastāvā" + (f", {reserve} rezervē" if reserve else "")


class StatsView(tk.Frame):
    """Statistika: figures for every group and three charts for the chosen group (active dancers)."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        self.group = tk.StringVar(value=ALL)
        outer, _h, body = izskats.panel(self, "Grupas", subtitle="tikai dejotāji (bez vadītājiem un repetitoriem)")
        outer.pack(fill="x", padx=20, pady=(14, 0))
        holder = tk.Frame(body, bg=WHITE)
        holder.pack(fill="x")
        cols = (("group", "Grupa", 110), ("total", "Kopā", 60), ("active", "Aktīvi", 60), ("pause", "Uz pauzes", 75),
                ("left", "Izstājušies", 80), ("gender", "Sievietes / vīrieši", 120), ("age", "Vid. vecums", 85),
                ("tenure", "Vid. stāžs", 80), ("noemail", "Bez e-pasta", 85))
        self.table = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings", height=5, selectmode="none")
        for key, text, width in cols:
            self.table.heading(key, text=text)
            self.table.column(key, width=width, anchor="w" if key == "group" else "center")
        zebra(self.table)
        self.table.tag_configure("sum", font=FONT_BOLD, background=SELECTED)
        self.table.pack(fill="x")
        self.leaders_var = tk.StringVar()
        tk.Label(body, textvariable=self.leaders_var, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w").pack(
            fill="x", padx=14, pady=6)

        row = tk.Frame(self, bg=CREAM)
        row.pack(fill="x", padx=20, pady=(14, 0))
        small_label(row, "DIAGRAMMAS GRUPAI", bg=CREAM).pack(side="left", padx=(0, 8))
        izskats.Segmented(row, [(ALL, "Visas grupas")] + [(g, g) for g in DANCER_GROUPS], self.group,
                          command=self.draw).pack(side="left")
        charts = tk.Frame(self, bg=CREAM)
        charts.pack(fill="both", expand=True, padx=20, pady=(10, 14))
        self.canvases = {}
        for i, (key, title) in enumerate((("age", "Vecums (aktīvie)"), ("tenure", "Stāžs, gadi (aktīvie)"),
                                          ("joined", "Iestājušies pa gadiem"))):
            charts.columnconfigure(i, weight=1, uniform="c")
            charts.rowconfigure(0, weight=1)
            o, _h, b = izskats.panel(charts, title)
            o.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 2 else 6))
            c = tk.Canvas(b, bg=WHITE, highlightthickness=0, height=220)
            c.pack(fill="both", expand=True, padx=10, pady=10)
            c.bind("<Configure>", lambda e: self.draw())
            self.canvases[key] = c
        self.refresh()

    def refresh(self, select=None):
        recs = self.app.load_cached(reload=True)
        dancers = [r for r in recs if is_dancer(r["role"])]
        self.table.delete(*self.table.get_children())
        groups = list(DANCER_GROUPS) + ([""] if any(r["dancer_group"] not in DANCER_GROUPS for r in dancers) else [])
        for i, g in enumerate(groups + [None]):
            part = dancers if g is None else [r for r in dancers if (r["dancer_group"] or "") == g or
                                              (not g and r["dancer_group"] not in DANCER_GROUPS)]
            st = dancer_stats(part)
            noemail = sum(1 for r in part if r["status"] == STATUS_ACTIVE and not r["app_email"])
            self.table.insert("", "end", values=(
                "Kopā" if g is None else (g or "Bez grupas"), st["total"], st["active"],
                sum(1 for r in part if r["status"] == STATUS_INACTIVE),
                sum(1 for r in part if r["status"] == STATUS_LEFT), st["gender"], st["age"], st["tenure"], noemail),
                tags=("sum",) if g is None else row_tags(i))
        self.table.configure(height=len(groups) + 1)
        leaders = [r for r in recs if not is_dancer(r["role"])]
        self.leaders_var.set(f"Vadītāji un repetitori: {len(leaders)}" +
                             (" — " + ", ".join(r["name"] for r in leaders) if leaders else ""))
        self.draw()

    def draw(self):
        recs = [r for r in self.app.load_cached() if is_dancer(r["role"]) and
                (self.group.get() == ALL or r["dancer_group"] == self.group.get())]
        active = [r for r in recs if r["status"] == STATUS_ACTIVE]

        def bins(values, edges):
            out = []
            for label, lo, hi in edges:
                out.append((label, sum(1 for v in values if v is not None and lo <= v <= hi)))
            return out
        ages = bins([r["age"] for r in active], [("<18", 0, 17), ("18–24", 18, 24), ("25–29", 25, 29),
                                                 ("30–39", 30, 39), ("40+", 40, 200)])
        tenure = bins([r["tenure"] for r in active], [("<1", 0, 0), ("1–2", 1, 2), ("3–4", 3, 4), ("5–9", 5, 9),
                                                      ("10+", 10, 200)])
        this_year = date.today().year
        joined = [(str(y)[2:] if y != this_year else "šogad",
                   sum(1 for r in recs if (r["join_date"] or "")[:4] == str(y))) for y in range(this_year - 7, this_year + 1)]
        for key, items, colour in (("age", ages, "#8A6400"), ("tenure", tenure, TEAL), ("joined", joined, NAVY)):
            bar_chart(self.canvases[key], items, colour)


class DaysView(tk.Frame):
    """Dzimšanas un vārda dienas: the coming days, nearest first."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        self.period = tk.StringVar(value="30")
        self.with_left = tk.BooleanVar(value=False)
        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=20, pady=(14, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        small_label(bar, "PERIODS").pack(side="left", padx=(0, 8))
        izskats.Segmented(bar, [("7", "7 dienas"), ("30", "30 dienas"), ("90", "3 mēneši"), ("366", "Viss gads")],
                          self.period, command=self.refresh).pack(side="left")
        small_label(bar, "GRUPA").pack(side="left", padx=(18, 4))
        gcb = ttk.Combobox(bar, textvariable=app.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=9)
        gcb.pack(side="left")
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        tk.Checkbutton(bar, text="arī izstājušies", variable=self.with_left, command=self.refresh, bg=WHITE, fg=NAVY,
                       activebackground=WHITE, selectcolor=WHITE, font=FONT).pack(side="left", padx=(16, 0))
        info = tk.Frame(self, bg=CREAM)
        info.pack(fill="x", padx=20, pady=(8, 0))
        self.count_var = tk.StringVar()
        tk.Label(info, textvariable=self.count_var, bg=CREAM, fg=NAVY, font=FONT_BOLD).pack(side="left")
        izskats.note(info, "Zaļā — šodien. Vārda dienas pēc Latvijas (arī paplašinātā) kalendāra.").pack(side="right")
        outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=(6, 14))
        holder = tk.Frame(outer, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = (("date", "Datums", 95), ("weekday", "Diena", 100), ("when", "Pēc", 90), ("what", "Svētki", 130),
                ("name", "Dejotājs", 220), ("group", "Grupa", 70), ("age", "Paliek (gadi)", 95))
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, text, width in cols:
            self.tree.heading(key, text=text)
            self.tree.column(key, width=width, anchor="center" if key == "age" else "w", stretch=key == "name")
        zebra(self.tree)
        self.tree.tag_configure("today", background=OK_BG, foreground=OK_FG, font=FONT_BOLD)
        self.tree.tag_configure("birthday", foreground=NAVY)
        self.tree.tag_configure("nameday", foreground=TEAL)
        self.tree.bind("<Double-1>", self.open_person)
        make_tree_with_scroll(holder, self.tree)
        self.refresh()

    def refresh(self, select=None):
        days = int(self.period.get())
        today = date.today()
        group = self.app.f_group.get()
        rows = []
        for r in self.app.load_cached(reload=True):
            if r["status"] == STATUS_LEFT and not self.with_left.get():
                continue
            if group != ALL and r["dancer_group"] != group:
                continue
            marks = []
            if len(r["birth_date"]) >= 10:
                marks.append(("Dzimšanas diena", r["birth_date"][5:10], r["birth_date"][:4]))
            for mmdd in name_days(r["first_name"] or ""):
                marks.append(("Vārda diena", mmdd, None))
            for what, mmdd, year in marks:
                try:
                    d = date(today.year, int(mmdd[:2]), int(mmdd[3:5]))
                except ValueError:   # 29.02 in a common year
                    d = date(today.year, 3, 1)
                if d < today:
                    try:
                        d = d.replace(year=today.year + 1)
                    except ValueError:
                        d = date(today.year + 1, 3, 1)
                delta = (d - today).days
                if delta > days:
                    continue
                age = (d.year - int(year)) if year and year.isdigit() else ""
                rows.append((delta, d, what, r, age))
        rows.sort(key=lambda x: (x[0], x[2] != "Dzimšanas diena", _norm(x[3]["name"])))
        weekdays = ["pirmdiena", "otrdiena", "trešdiena", "ceturtdiena", "piektdiena", "sestdiena", "svētdiena"]
        self.tree.delete(*self.tree.get_children())
        for i, (delta, d, what, r, age) in enumerate(rows):
            when = "šodien" if delta == 0 else ("rīt" if delta == 1 else f"{delta} dienām")
            tag = "today" if delta == 0 else ("birthday" if what == "Dzimšanas diena" else "nameday")
            self.tree.insert("", "end", iid=f"{r['id']}:{i}", values=(
                d.strftime("%d.%m.%Y"), weekdays[d.weekday()], when, what, r["name"], r["dancer_group"], age),
                tags=row_tags(i, tag))
        self.count_var.set(f"{len(rows)} svētki tuvākajās {days} dienās" if days < 366 else f"{len(rows)} svētki gadā")

    def open_person(self, event):
        iid = self.tree.identify_row(event.y)
        if iid:
            DancerForm(self.app, int(iid.split(":")[0]))


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
TAB_DANCERS, TAB_STATS, TAB_DAYS = "dancers", "stats", "days"


class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1240x820")
        root.minsize(1000, 680)
        root.configure(bg=CREAM)
        self._records = None
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        izskats.apply_style()   # kopīgais izskats (Pūrlāde v0.8)

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")
        self.search = tk.StringVar()
        self.f_gender = tk.StringVar(value=ALL)
        self.f_status = tk.StringVar(value=ALL)
        self.f_role = tk.StringVar(value=ALL)
        self.f_group = tk.StringVar(value=ALL)
        self.f_columns = tk.StringVar(value="Pamata")
        self.view, self.current_tab = None, None
        self.search.trace_add("write", lambda *a: self.refresh())

        # Pūrlāde v0.8: baltā moduļa galvene ar cilnēm (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = izskats.module_header(
            self.root, "kopas_purs", PROGRAM_NAME, f"Dejotāji un kolektīva sastāvs · v{APP_VERSION}",
            on_logo=self.show_main, on_exit=None if self.on_exit is not None else self.root.destroy, tabs=True)
        acc = piekluve.current()
        if acc.can_edit("kopas_purs"):
            izskats.header_button(self.header_right, "＋ Jauns dejotājs", lambda: DancerForm(self), primary=True).pack(
                side="right", padx=(8, 0))
        if acc.edits_all("kopas_purs"):
            izskats.header_button(self.header_right, "⇪ Importēt no Excel", self.run_import).pack(side="right")
        else:
            note = ("tikai skatīšanai" if not acc.can_edit("kopas_purs")
                    else "labot var " + acc.scope_text("kopas_purs") + "s dejotājus")
            tk.Label(self.header_right, text="🔒 " + note, bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold")).pack(
                side="right", padx=(0, 8))
        self.tabs = self.header_right.tabs
        for key, text in ((TAB_DANCERS, "Dejotāji"), (TAB_STATS, "Statistika"),
                          (TAB_DAYS, "Dzimšanas un vārda dienas")):
            self.tabs.add(key, text, lambda k=key: self.open_tab(k))
        self.content = tk.Frame(self.root, bg=CREAM)
        self.content.pack(fill="both", expand=True)
        self.open_tab(TAB_DANCERS)

    def open_tab(self, key):
        if key == self.current_tab and self.view is not None:
            return self.view
        for child in self.content.winfo_children():
            child.destroy()
        self.current_tab = key
        self.tabs.set_active(key)
        self.view = {TAB_DANCERS: DancersView, TAB_STATS: StatsView, TAB_DAYS: DaysView}[key](self, self.content)
        self.view.pack(fill="both", expand=True)
        return self.view

    # ---- data -------------------------------------------------------------
    def load_cached(self, reload=False):
        if reload or self._records is None:
            self._records = load_people(self.db)
        return self._records

    def show_main(self):
        """Module logo: back to the main view — all dancers, no filters, top of the list."""
        self.current_tab = None
        self.clear_filters(refresh=False)
        self.open_tab(TAB_DANCERS)

    def clear_filters(self, refresh=True):
        self.f_gender.set(ALL)
        self.f_status.set(ALL)
        self.f_role.set(ALL)
        self.f_group.set(ALL)
        self.search.set("")   # (refreshes)
        if refresh:
            self.refresh()

    def sync_roles(self):
        """Kolektīva vēsture: write down the roles given / taken away (who is president, leader ... since when)."""
        try:
            sync_role_history(self.db.con)
        except Exception:
            log_error(traceback.format_exc())

    def refresh(self, select=None):
        if self.view is None:
            return
        try:
            self.view.refresh(select=select)
        except tk.TclError:
            pass

    def selected(self):
        view = self.view if isinstance(self.view, DancersView) else None
        sel = view.tree.selection() if view is not None else ()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sarakstā.", parent=self.root)
            return None
        return int(sel[0])

    def edit(self):
        did = self.selected()
        if did is not None:
            DancerForm(self, did)

    def delete(self, did=None):
        did = did if did is not None else self.selected()
        if did is None:
            return
        name, group, role = self.db.q("SELECT name, dancer_group, role FROM dancers WHERE id=?", (did,))[0]
        if not may_edit_person(group, role):
            return piekluve.deny(self.root, "Šo dejotāju jūsu loma nevar dzēst.")
        issued = self.db.active_checkouts(did)
        if issued:
            messagebox.showwarning(
                "Nevar dzēst", f"Dejotājam “{name}” ir izsniegti tērpi ({issued}). "
                               "Vispirms atgrieziet tos Tērpu pūrā.", parent=self.root)
            return
        if messagebox.askyesno(
                "Dzēst", f"Dzēst dejotāju “{name}”?\n\nTiks dzēsta arī viņa tērpu izsniegumu un apmeklējuma vēsture. "
                         f"Ja dejotājs vienkārši vairs nedejo, labāk nomainiet statusu uz “{STATUS_LEFT}”.",
                parent=self.root):
            self.db.x("DELETE FROM dancers WHERE id=?", (did,))
            self.sync_roles()
            self.refresh()


    def run_import(self):
        if not piekluve.current().edits_all("kopas_purs"):
            return piekluve.deny(self.root, "Importēt dejotājus var tikai lietotāji, kas drīkst labot visas grupas.")
        cols = ["Vārds", "Uzvārds", "Dzimums (sieviete / vīrietis)", "Dzimšanas datums", "Iestāšanās datums",
                "Statuss (aktīvs / uz pauzes / izstājies)", "Loma (dejotājs / vadītājs / repetitors)",
                "Grupa (" + " / ".join(DANCER_GROUPS) + ")", "Augums",
                "Izmērs", "Kontakti", "E-pasts (Kabatas Pūrlādei)"]
        info = ("Excel faila pirmajā rindā jābūt kolonnu nosaukumiem:\n\n  • " + "\n  • ".join(cols) +
                "\n\nObligāta ir tikai kolonna “Vārds” (der arī viena kolonna “Vārds uzvārds”). "
                "Jau esošie dejotāji (tas pats vārds un dzimšanas datums) tiks izlaisti. "
                "Ja statuss nav norādīts, dejotājs būs aktīvs; ja loma nav norādīta — dejotājs; ja grupa nav norādīta — " + DEFAULT_DANCER_GROUP + ".\n\n"
                "Kolonna “E-pasts” ir e-pasts, ar kuru dejotājs piesakās Kabatas Pūrlādē. Jau esošiem dejotājiem "
                "no faila tiek ņemts tikai e-pasts — tā var vienā reizē ievadīt e-pastus visiem.")
        if not messagebox.askokcancel("Importēt no Excel", info, parent=self.root):
            return
        path = filedialog.askopenfilename(parent=self.root, title="Izvēlieties Excel failu",
                                          filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            result = import_dancers(self.db, read_table(path))
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self.root)
            return
        if result["error"]:
            messagebox.showerror("Importa kļūda", result["error"], parent=self.root)
            return
        self.sync_roles()
        self.refresh()
        text = (f"Pievienoti dejotāji: {result['added']}\n"
                f"E-pasti pievienoti jau esošiem dejotājiem: {result['emails']}\n"
                f"Izlaistas rindas / brīdinājumi: {len(result['skipped'])}")
        if result["skipped"]:
            text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
            if len(result["skipped"]) > 12:
                text += f"\n… un vēl {len(result['skipped']) - 12}"
        (messagebox.showwarning if result["skipped"] else messagebox.showinfo)("Imports pabeigts", text,
                                                                              parent=self.root)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
