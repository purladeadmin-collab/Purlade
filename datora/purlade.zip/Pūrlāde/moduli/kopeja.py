"""
Pūrlāde — kopīgās lietas visiem moduļiem
(shared paths, the common database, colours, console and error log)

All modules keep their data in ONE database: the file purlade.db next to the Pūrlāde program
file, or — when this computer is connected to it — the shared online database (see datubaze.py).
Modules get their connection with connect_db(); they never open purlade.db themselves.
"""

import csv
import os
import re
import shutil
import sqlite3
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))   # .../moduli
DATA_DIR = os.path.dirname(PACKAGE_DIR)                     # folder of the Pūrlāde program
DB_PATH = os.path.join(DATA_DIR, "purlade.db")
OLD_DB_PATH = os.path.join(DATA_DIR, "costume_inventory.db")  # database of the stand-alone Tērpu pūrs
ERROR_LOG = os.path.join(DATA_DIR, "kludas.log")

# --------------------------------------------------------------------------
# Design (cream / red / navy / gold)
# --------------------------------------------------------------------------
CREAM = "#FFF8E7"
CREAM_DARK = "#F3E8CC"
RED = "#9E1B32"
NAVY = "#1F2A44"
GOLD = "#C9A227"
WHITE = "#FFFFFF"
GREEN = "#1B6B3A"
GREY = "#8C8C8C"


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
try:
    from moduli import datubaze
except ImportError:  # started from inside the moduli folder
    import datubaze


def connect_db(path=None):
    """The shared database connection for a module.
    Online mode: the ONE shared PostgreSQL connection (its close() keeps it open for the others).
    Local mode: a new connection to purlade.db (or `path`), exactly as before."""
    if datubaze.is_online():
        return datubaze.shared_connection()
    return sqlite3.connect(path or DB_PATH)


def database_is_online():
    return datubaze.is_online()


def database_label():
    """Short text for the start page: which database this computer uses."""
    return "tiešsaistes datubāze" if datubaze.online_config() else "lokālā datubāze"


def prepare_database():
    """On the first start of Pūrlāde the data of the stand-alone Tērpu pūrs is taken over:
    costume_inventory.db is COPIED to purlade.db (the old file stays as a backup)."""
    if datubaze.is_online():
        datubaze.shared_connection()   # connects (and creates the online tables on the first use)
        return None
    if not os.path.exists(DB_PATH) and os.path.exists(OLD_DB_PATH):
        shutil.copy2(OLD_DB_PATH, DB_PATH)
    return DB_PATH


def read_setting(key, default=None):
    """Read one value from the settings table (None/default when it is not there)."""
    if not datubaze.is_online() and not os.path.exists(DB_PATH):
        return default
    try:
        con = connect_db()
        try:
            row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return default
    return row[0] if row and row[0] else default


COPYRIGHT = "© Adrians Gūtšmits 2026"


def copyright_footer(parent, bg=None):
    """Copyright line at the bottom centre of a module page. Call it right after the header,
    before the page content, so the content cannot push it out of the window."""
    import tkinter as tk
    label = tk.Label(parent, text=COPYRIGHT, font=("Segoe UI", 8), bg=bg or CREAM, fg=NAVY)
    label.pack(side="bottom", pady=(0, 4))
    return label


def load_image(path, max_w, max_h):
    """PNG/GIF work out of the box; JPG needs the optional Pillow package."""
    import tkinter as tk
    try:
        from PIL import Image, ImageTk
    except ImportError:
        img = tk.PhotoImage(file=path)
        f = max(-(-img.width() // max_w), -(-img.height() // max_h), 1)
        return img.subsample(f) if f > 1 else img
    img = Image.open(path)
    img.thumbnail((max_w, max_h))
    return ImageTk.PhotoImage(img)


MODULE_LOGO_DIR = os.path.join(PACKAGE_DIR, "logo")


def module_logo(parent, file_name, on_click=None, size=64, bg=None):
    """The module's round logo (moduli/logo/<file_name>.png) for the left corner of its header.
    Clicking it calls on_click (back to the module's main view). Returns None when there is no file."""
    import tkinter as tk
    path = os.path.join(MODULE_LOGO_DIR, file_name + ".png")
    if not os.path.exists(path):
        return None
    try:
        image = load_image(path, size, size)
    except Exception:
        return None
    label = tk.Label(parent, image=image, bg=bg or NAVY, bd=0, cursor="hand2" if on_click else "")
    label.image = image  # keep a reference, otherwise Tk forgets the picture
    if on_click is not None:
        label.bind("<Button-1>", lambda e: on_click())
    return label


def load_trimmed_image(path, max_w, max_h):
    """Like load_image, but the empty (transparent) margins around the picture are cut off first,
    so a logo with a lot of empty space around it is shown as large as possible."""
    import tkinter as tk
    try:
        from PIL import Image, ImageTk
    except ImportError:
        img = tk.PhotoImage(file=path)
        w, h = img.width(), img.height()
        step = max(1, max(w, h) // 200)  # look at every n-th pixel: fast enough for big pictures
        xs, ys = [], []
        for y in range(0, h, step):
            for x in range(0, w, step):
                if not img.transparency_get(x, y):
                    xs.append(x)
                    ys.append(y)
        if xs:
            x0, y0 = max(min(xs) - step, 0), max(min(ys) - step, 0)
            x1, y1 = min(max(xs) + step + 1, w), min(max(ys) + step + 1, h)
            part = tk.PhotoImage(width=x1 - x0, height=y1 - y0)
            part.tk.call(part, "copy", img, "-from", x0, y0, x1, y1)
            img = part
        f = max(-(-img.width() // max_w), -(-img.height() // max_h), 1)
        return img.subsample(f) if f > 1 else img
    img = Image.open(path)
    if img.mode in ("RGBA", "LA", "P"):
        box = img.convert("RGBA").getchannel("A").getbbox()
        if box:
            img = img.crop(box)
    img.thumbnail((max_w, max_h))
    return ImageTk.PhotoImage(img)


def group_logo(max_w, max_h):
    """The collective's logo chosen in Administrēšana (or None); empty margins are cut off."""
    name = read_setting("logo.file")
    if not name:
        return None
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return None
    try:
        return load_trimmed_image(path, max_w, max_h)
    except Exception:
        try:
            return load_image(path, max_w, max_h)
        except Exception:
            return None


# --------------------------------------------------------------------------
# Error log
# --------------------------------------------------------------------------
def log_error(text):
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as fh:
            fh.write(datetime.now().strftime("%d.%m.%Y %H:%M:%S") + "\n" + text + "\n")
    except Exception:
        pass


# --------------------------------------------------------------------------
# Console window (Windows): hidden at start, can be shown again from Administrēšana
# --------------------------------------------------------------------------
def _console_hwnd():
    if os.name != "nt":
        return 0
    try:
        import ctypes
        return ctypes.windll.kernel32.GetConsoleWindow()
    except Exception:
        return 0


def console_available():
    return bool(_console_hwnd())


def console_visible():
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        return bool(ctypes.windll.user32.IsWindowVisible(hwnd))
    except Exception:
        return False


def set_console_visible(show):
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        ctypes.windll.user32.ShowWindow(hwnd, 5 if show else 0)  # SW_SHOW / SW_HIDE
        return True
    except Exception:
        return False


def console_is_own():
    # True when the console window belongs only to this program (double-clicked), not to a
    # terminal the program was started from - such a terminal must not be hidden.
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        procs = (ctypes.c_uint * 8)()
        return ctypes.windll.kernel32.GetConsoleProcessList(procs, 8) <= 1
    except Exception:
        return False


# --------------------------------------------------------------------------
# Dancers (kept by Kopas pūrs, read by the other modules)
# --------------------------------------------------------------------------
GENDER_MALE = "Vīrietis"
GENDER_FEMALE = "Sieviete"
GENDERS = [GENDER_MALE, GENDER_FEMALE]

STATUS_ACTIVE = "Aktīvs"
STATUS_INACTIVE = "Uz pauzes"
OLD_STATUS_INACTIVE = "Neaktīvs"   # name used before Kopas pūrs v0.1.4
STATUS_LEFT = "Izstājies"
DANCER_STATUSES = [STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT]

# Role in the collective. Leaders and rehearsal directors are kept in the same list (Kopas pūrs),
# but they are not dancers: they are not counted as dancers and the other modules do not offer them
# as dancers. An empty role (older records) means a dancer.
ROLE_DANCER = "Dejotājs"
ROLE_LEADER = "Vadītājs"
ROLE_REPETITOR = "Repetitors"
PERSON_ROLES = [ROLE_DANCER, ROLE_LEADER, ROLE_REPETITOR]

# --------------------------------------------------------------------------
# Lietotnes lomas (app roles): what a person may see and change in the mobile app and — once the
# desktop Pūrlāde has sign-in — in the program. Every dancer has the app role "Dejotājs"; the other
# app roles are given to dancers separately (Kopas pūrs → dancer window, or the mobile app) by a
# leader or a system administrator. Leaders and rehearsal directors get "Vadītājs" / "Repetitors"
# automatically from their role in the collective (they cannot get the dancers' extra app roles).
# Stored in dancers.app_roles as a comma separated list of the extra app roles.
# --------------------------------------------------------------------------
APP_ROLE_DANCER = "Dejotājs"
APP_ROLE_COSTUMES = "Tērpu pārzinis"
APP_ROLE_ADMIN = "Sistēmas administrators"
APP_ROLE_PRESIDENT = "Prezidents"
APP_ROLE_SOCIAL = "Sociālo tīklu administrators"
APP_ROLE_LEADER = ROLE_LEADER          # automatic for leaders
APP_ROLE_REPETITOR = ROLE_REPETITOR    # automatic for rehearsal directors
EXTRA_APP_ROLES = [APP_ROLE_COSTUMES, APP_ROLE_ADMIN, APP_ROLE_PRESIDENT, APP_ROLE_SOCIAL]

# Dancer groups (Kopas pūrs → "Grupa"; only for dancers). Stored in dancers.dancer_group.
DANCER_GROUPS = ["A", "Studija", "VPDK"]
DEFAULT_DANCER_GROUP = "A"
INITIAL_GROUP_KEY = "dancer_group.initial"   # one-time: every dancer who existed then got group A

# right -> app roles that have it. The system administrator has every right.
RIGHT_OVERVIEW = "overview"                  # app: overview of all dancers' answers, every event
RIGHT_CHANGE_ANSWERS = "change_answers"      # app: change other dancers' answers (also after the deadline)
RIGHT_COSTUME_SUMMARY = "costume_summary"    # app: costume summary of an event (who needs which costume)
RIGHT_ALL_NOTIFICATIONS = "all_notifications"  # app: every notification meant for the leaders
RIGHT_ABSENCE_NOTIFICATIONS = "absence_notifications"  # app: "Nebūs" notifications
RIGHT_ASSIGN_APP_ROLES = "assign_app_roles"  # give / take away app roles
RIGHT_EDIT_COSTUMES = "edit_costumes"        # program: edit Tērpu pūrs (checked once the program has sign-in)
RIGHT_ALL_EVENTS = "all_events"              # app: the plan shows every event (all groups, publicity events)
RIGHT_NEW_EVENT_NOTIFICATIONS = "new_event_notifications"  # app: notice when a concert / review / publicity event
#                                                            is created or confirmed
RIGHT_EDIT_SITE = "edit_site"                # website: add events, gallery and dancers' pictures
RIGHT_DESKTOP = "desktop"                    # website: download the desktop Pūrlāde
APP_RIGHTS = {
    RIGHT_OVERVIEW: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT},
    RIGHT_CHANGE_ANSWERS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR},
    RIGHT_COSTUME_SUMMARY: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_COSTUMES},
    RIGHT_ALL_NOTIFICATIONS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT},
    RIGHT_ABSENCE_NOTIFICATIONS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_COSTUMES},
    RIGHT_ASSIGN_APP_ROLES: {APP_ROLE_LEADER},
    RIGHT_EDIT_COSTUMES: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_COSTUMES},
    RIGHT_ALL_EVENTS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_SOCIAL},
    RIGHT_NEW_EVENT_NOTIFICATIONS: {APP_ROLE_SOCIAL},
    RIGHT_EDIT_SITE: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_COSTUMES, APP_ROLE_SOCIAL},
    RIGHT_DESKTOP: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_COSTUMES},
}

# one-time: the first system administrator (Pūrlāde v0.6)
INITIAL_ADMIN = ("Adrians", "Gūtšmits")
INITIAL_ADMIN_KEY = "app_roles.initial_admin"


def parse_app_roles(text):
    """'Prezidents, Tērpu pārzinis' -> the extra app roles in the standard order (unknown names dropped)."""
    given = {_norm(p) for p in (text or "").split(",") if p.strip()}
    return [r for r in EXTRA_APP_ROLES if _norm(r) in given]


def app_roles_text(roles):
    """Extra app roles -> text stored in dancers.app_roles."""
    return ", ".join(r for r in EXTRA_APP_ROLES if r in roles)


def app_roles_of(role, stored):
    """All app roles of a person: role in the collective (dancers.role) + stored extra app roles."""
    role = (role or "").strip() or ROLE_DANCER
    if role == ROLE_LEADER:
        return [APP_ROLE_LEADER]
    if role == ROLE_REPETITOR:
        return [APP_ROLE_REPETITOR]
    return [APP_ROLE_DANCER] + parse_app_roles(stored)


def has_right(app_roles, right):
    """True when one of the app roles gives the right (the system administrator has all rights)."""
    roles = set(app_roles or ())
    return APP_ROLE_ADMIN in roles or bool(roles & APP_RIGHTS.get(right, set()))


def _seed_initial_group(con):
    """Once: every dancer already in Kopas pūrs gets group "A" (Kopas pūrs v0.1.8). Done one time only, so later
    changes of a group are never overwritten."""
    try:
        if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_GROUP_KEY,)).fetchone():
            return
    except sqlite3.Error:
        return   # no settings table yet: try again next time
    con.execute("UPDATE dancers SET dancer_group=? WHERE TRIM(COALESCE(dancer_group,'')) = '' AND "
                f"TRIM(COALESCE(role,'')) IN ('', '{ROLE_DANCER}')", (DEFAULT_DANCER_GROUP,))
    con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (INITIAL_GROUP_KEY, DEFAULT_DANCER_GROUP))


def _seed_initial_admin(con):
    """Gives Adrians Gūtšmits the app role "Sistēmas administrators" once (when he is in Kopas pūrs as a
    dancer). Done only one time, so the role can later be taken away like any other."""
    try:
        if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_ADMIN_KEY,)).fetchone():
            return
    except sqlite3.Error:
        return   # no settings table yet: try again next time
    first, last = (_norm(x) for x in INITIAL_ADMIN)
    for did, f, l, role, stored in con.execute(
            "SELECT id, first_name, last_name, role, app_roles FROM dancers").fetchall():
        if _norm(f) == first and _norm(l) == last and (role or ROLE_DANCER).strip() in ("", ROLE_DANCER):
            roles = set(parse_app_roles(stored)) | {APP_ROLE_ADMIN}
            con.execute("UPDATE dancers SET app_roles=? WHERE id=?", (app_roles_text(roles), did))
            con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (INITIAL_ADMIN_KEY, str(did)))
            return

CLOTHING_SIZES = ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]

# column -> SQL declaration; "name" (full name) is kept up to date for the other modules
DANCER_COLUMNS = [
    ("gender", "TEXT DEFAULT ''"),
    ("contact", "TEXT DEFAULT ''"),
    ("first_name", "TEXT DEFAULT ''"),
    ("last_name", "TEXT DEFAULT ''"),
    ("birth_date", "TEXT DEFAULT ''"),
    ("join_date", "TEXT DEFAULT ''"),
    ("status", "TEXT DEFAULT ''"),
    ("height", "TEXT DEFAULT ''"),
    ("clothing_size", "TEXT DEFAULT ''"),
    ("role", "TEXT DEFAULT ''"),
    ("app_roles", "TEXT DEFAULT ''"),
    ("dancer_group", "TEXT DEFAULT ''"),
]


def ensure_dancer_schema(con):
    """Create / extend the dancers table. Older databases had one name field: it is split
    into first name and last name (first word = first name)."""
    con.execute("CREATE TABLE IF NOT EXISTS dancers (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "name TEXT NOT NULL, gender TEXT DEFAULT '', contact TEXT DEFAULT '')")
    have = {r[1] for r in con.execute("PRAGMA table_info(dancers)")}
    for column, decl in DANCER_COLUMNS:
        if column not in have:
            con.execute(f"ALTER TABLE dancers ADD COLUMN {column} {decl}")
    rows = con.execute("SELECT id, name FROM dancers WHERE TRIM(COALESCE(first_name,'')) = '' "
                       "AND TRIM(COALESCE(last_name,'')) = ''").fetchall()
    for did, name in rows:
        parts = (name or "").split(None, 1)
        con.execute("UPDATE dancers SET first_name=?, last_name=? WHERE id=?",
                    (parts[0] if parts else "", parts[1] if len(parts) > 1 else "", did))
    con.execute("UPDATE dancers SET status=? WHERE TRIM(COALESCE(status,'')) = ''", (STATUS_ACTIVE,))
    con.execute("UPDATE dancers SET status=? WHERE status=?", (STATUS_INACTIVE, OLD_STATUS_INACTIVE))
    _seed_initial_admin(con)
    _seed_initial_group(con)
    con.commit()


# --------------------------------------------------------------------------
# Kabatas Pūrlāde: e-pasti, ar kuriem dejotāji piesakās lietotnē (ievada Kopas pūrā)
# --------------------------------------------------------------------------
# The same app_users table that the Kabatas Pūrlāde server creates (mobila/serveris.py, APP_SCHEMA);
# the server reads the e-mails from it when a dancer logs in.
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
APP_USERS_SCHEMA = """CREATE TABLE IF NOT EXISTS app_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dancer_id INTEGER NOT NULL UNIQUE REFERENCES dancers(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    active INTEGER DEFAULT 1,
    created TEXT DEFAULT ''
)"""


def _has_table(con, name):
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def ensure_app_users(con):
    """Create the app_users table when the Kabatas Pūrlāde server has not done it yet."""
    if _has_table(con, "app_users"):
        return
    con.execute(APP_USERS_SCHEMA)
    con.commit()
    if datubaze.is_online():
        # the online database keeps every table closed to the Supabase web API (row level security)
        try:
            datubaze.ensure_schema(datubaze.shared_connection())
        except Exception as exc:
            log_error(f"app_users drošības iestatījumi: {exc}")


def app_emails(con):
    """{dancer id: e-mail} of everyone who can log in to Kabatas Pūrlāde."""
    if not _has_table(con, "app_users"):
        return {}
    return {d: e for d, e in con.execute("SELECT dancer_id, email FROM app_users WHERE active=1").fetchall()}


def app_email(con, dancer_id):
    return app_emails(con).get(dancer_id, "")


def check_app_email(con, dancer_id, email):
    """Error text for an e-mail that cannot be used (None when it is fine). Empty = no app access."""
    email = (email or "").strip().lower()
    if not email:
        return None
    if not EMAIL_RE.match(email):
        return "Nederīga e-pasta adrese."
    if _has_table(con, "app_users"):
        other = con.execute("SELECT dancer_id FROM app_users WHERE email=?", (email,)).fetchone()
        if other and other[0] != dancer_id:
            row = con.execute("SELECT name FROM dancers WHERE id=?", (other[0],)).fetchone()
            who = f" ({row[0]})" if row and row[0] else ""
            return f"Šis e-pasts jau piešķirts citam cilvēkam{who}."
    return None


def set_app_email(con, dancer_id, email):
    """Give (or change, or with an empty e-mail take away) the dancer's Kabatas Pūrlāde login.
    Same rules as the server's own set_email: a new address ends the old logins."""
    email = (email or "").strip().lower()
    problem = check_app_email(con, dancer_id, email)
    if problem:
        raise ValueError(problem)
    if not email and not _has_table(con, "app_users"):
        return
    ensure_app_users(con)
    row = con.execute("SELECT id, email FROM app_users WHERE dancer_id=?", (dancer_id,)).fetchone()
    if not email:
        if row:
            for table in ("app_sessions", "app_push_subscriptions", "app_notification_reads"):
                if _has_table(con, table):
                    con.execute(f"DELETE FROM {table} WHERE user_id=?", (row[0],))
            con.execute("DELETE FROM app_users WHERE id=?", (row[0],))
    elif row:
        if row[1] != email and _has_table(con, "app_sessions"):   # new address: the old logins end
            con.execute("DELETE FROM app_sessions WHERE user_id=?", (row[0],))
        con.execute("UPDATE app_users SET email=?, active=1 WHERE id=?", (email, row[0]))
    else:
        con.execute("INSERT INTO app_users (dancer_id, email, active, created) VALUES (?,?,1,?)",
                    (dancer_id, email, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    con.commit()


# --------------------------------------------------------------------------
# Kolektīva pasākuma apakšveidi (Notikumu pūrs, Kabatas Pūrlāde)
# --------------------------------------------------------------------------
EVENT_KIND_GROUP = "Kolektīva pasākums"          # the event kind that has sub-kinds and no dances
SUBKIND_TEAM = "Saliedēšanās pasākums"
SUBKIND_BOYS = "Puišu pasākums"
SUBKIND_GIRLS = "Meiteņu pasākums"
SUBKIND_PUBLICITY = "Publicitātes pasākums"     # only the invited dancers see it and get notifications
EVENT_SUBKINDS = [SUBKIND_TEAM, SUBKIND_BOYS, SUBKIND_GIRLS, SUBKIND_PUBLICITY]


EVENT_COSTUMES_SCHEMA = """
CREATE TABLE IF NOT EXISTS event_costumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    gender TEXT NOT NULL,
    type_name TEXT NOT NULL,
    UNIQUE (session_id, gender, type_name)
);
"""


def ensure_event_detail_columns(con):
    """event_details.subkind (apakšveids), event_details.invited (uzaicināto dejotāju id, '3,7,12'),
    event_details.for_groups (kurām grupām notikums: 'A,Studija'; tukšs — visām) and the table event_costumes
    (publicitātes pasākuma tērpu veidi katram dzimumam, tāpat kā dance_costumes dejām)."""
    have = {r[1] for r in con.execute("PRAGMA table_info(event_details)")}
    if have:
        for column in ("subkind", "invited", "for_groups"):
            if column not in have:
                con.execute(f"ALTER TABLE event_details ADD COLUMN {column} TEXT DEFAULT ''")
    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attendance_sessions'").fetchone():
        con.executescript(EVENT_COSTUMES_SCHEMA)
        if have:
            _seed_initial_event_groups(con)
    con.commit()


INITIAL_EVENT_GROUP_KEY = "event_groups.initial"   # one-time: every event that existed then got group A


def _seed_initial_event_groups(con):
    """Once (Notikumu pūrs v0.1.7 / Cītības pūrs v0.1.10): every event already entered gets group "A" —
    they were all made before there were other groups. Later changes are never overwritten."""
    if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_EVENT_GROUP_KEY,)).fetchone():
        return
    con.execute("INSERT INTO event_details (session_id, for_groups) SELECT id, ? FROM attendance_sessions "
                "WHERE id NOT IN (SELECT session_id FROM event_details)", (DEFAULT_DANCER_GROUP,))
    con.execute("UPDATE event_details SET for_groups=? WHERE TRIM(COALESCE(for_groups,'')) = ''",
                (DEFAULT_DANCER_GROUP,))
    con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (INITIAL_EVENT_GROUP_KEY, DEFAULT_DANCER_GROUP))


# ---- event groups (A / Studija / VPDK): which groups an event is for ----
def event_groups(text):
    """'A,Studija' -> ['A', 'Studija'] (in DANCER_GROUPS order; empty = all groups)."""
    chosen = {g.strip() for g in (text or "").split(",") if g.strip()}
    return [g for g in DANCER_GROUPS if g in chosen] + sorted(chosen - set(DANCER_GROUPS))


def event_groups_text(groups):
    return ",".join(event_groups(",".join(groups)))


def groups_label(text):
    """'A, Studija' — or 'visas grupas' when the event is for every group."""
    groups = event_groups(text)
    return ", ".join(groups) if groups and set(groups) != set(DANCER_GROUPS) else "visas grupas"


def in_event_groups(dancer_group, groups_text):
    """Is a dancer of this group meant by the event? (empty group of an event = all; empty group of a dancer = A)"""
    groups = event_groups(groups_text)
    return not groups or ((dancer_group or "").strip() or DEFAULT_DANCER_GROUP) in groups


def event_costume_types(con, session_ids):
    """{session id: {gender: [costume types]}} — costume types chosen for publicity events (Notikumu pūrs)."""
    ids = list(session_ids)
    if not ids or not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_costumes'").fetchone():
        return {}
    result = {}
    for sid, gender, name in con.execute("SELECT session_id, gender, type_name FROM event_costumes WHERE session_id IN ("
                                         + ",".join("?" * len(ids)) + ") ORDER BY id", ids).fetchall():
        result.setdefault(sid, {}).setdefault(gender, []).append(name)
    return result


def invited_ids(text):
    """'3,7,12' -> {3, 7, 12}"""
    return {int(x) for x in re.findall(r"\d+", text or "")}


def invited_text(ids):
    return ",".join(str(i) for i in sorted(set(ids)))


def is_publicity(kind, subkind):
    return kind == EVENT_KIND_GROUP and subkind == SUBKIND_PUBLICITY


def full_name(first, last):
    return " ".join(p for p in ((first or "").strip(), (last or "").strip()) if p)


def dancer_role_sql(alias="dancers"):
    """SQL condition: the person is a dancer, not a leader or rehearsal director (empty role = dancer)."""
    return f"(TRIM(COALESCE({alias}.role,'')) IN ('', '{ROLE_DANCER}'))"


def active_dancer_sql(alias="dancers"):
    """SQL condition: an active dancer (an empty status counts as active); leaders and rehearsal
    directors are never included."""
    return f"(TRIM(COALESCE({alias}.status,'')) IN ('', '{STATUS_ACTIVE}') AND {dancer_role_sql(alias)})"


# --------------------------------------------------------------------------
# Dance casts (kept by Deju pūrs, read by Notikumu pūrs and Tērpu pūrs)
# --------------------------------------------------------------------------
CAST_MAIN = "Pamatsastāvs"
CAST_RESERVE = "Rezerve"


def ensure_cast_substitutes(con):
    """dance_cast.substitute_id: the dancer who replaces this main-cast dancer in this dance."""
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dance_cast'").fetchone():
        return False
    cols = {r[1] for r in con.execute("PRAGMA table_info(dance_cast)")}
    if "substitute_id" not in cols:
        con.execute("ALTER TABLE dance_cast ADD COLUMN substitute_id INTEGER "
                    "REFERENCES dancers(id) ON DELETE SET NULL")
        con.commit()
    return True


def dance_lineup(con, dance_id, declined=()):
    """Who dances `dance_id` at an event where the dancers in `declined` answered "Nebūs".
    Main-cast dancers who come dance themselves; for a main-cast dancer who does not come, his
    assigned reserve dancer (substitute) is taken automatically, if that one has not declined too.
    Returns (lineup, uncovered): lineup = [(dancer id, id of the dancer he replaces or None)],
    uncovered = main-cast dancers who do not come and have no available substitute."""
    if not ensure_cast_substitutes(con):
        return [], []
    declined = set(declined)
    rows = con.execute("SELECT dancer_id, role, substitute_id FROM dance_cast WHERE dance_id=? ORDER BY id",
                       (dance_id,)).fetchall()
    main = [(d, sub) for d, role, sub in rows if (role or CAST_MAIN) != CAST_RESERVE]
    lineup, used, uncovered = [], set(), []
    for d, _sub in main:
        if d not in declined:
            lineup.append((d, None))
            used.add(d)
    for d, sub in main:
        if d in declined:
            if sub and sub not in declined and sub not in used:
                lineup.append((sub, d))
                used.add(sub)
            else:
                uncovered.append(d)
    return lineup, uncovered


def dancer_size_text(con, dancer_id):
    """'Augums: 172 cm, izmērs: M' for the costume fitting (empty when nothing is known)."""
    try:
        row = con.execute("SELECT height, clothing_size FROM dancers WHERE id=?", (dancer_id,)).fetchone()
    except sqlite3.Error:
        return ""
    if not row:
        return ""
    parts = []
    if (row[0] or "").strip():
        parts.append(f"augums: {row[0].strip()} cm")
    if (row[1] or "").strip():
        parts.append(f"izmērs: {row[1].strip()}")
    return ("Dejotāja " + ", ".join(parts)) if parts else ""


def parse_date(text):
    """'2026-10-21', '21.10.2026', '21/10/2026' or an Excel day number -> '2026-10-21'.
    Empty text -> ''. Anything else -> None."""
    text = str(text or "").strip()
    if not text:
        return ""
    if re.fullmatch(r"\d{4,6}(\.0+)?", text):  # Excel stores dates as day numbers
        n = int(float(text))
        if 1 <= n < 80000:
            return (date(1899, 12, 30) + timedelta(days=n)).isoformat()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%d.%m.%y", "%Y.%m.%d"):
        try:
            return datetime.strptime(text.rstrip("."), fmt).date().isoformat()
        except ValueError:
            pass
    return None


def years_between(start, end=None):
    """Whole years from start (ISO date) to end/today; None when start is unknown."""
    try:
        s = datetime.strptime(start, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None
    e = end or date.today()
    return e.year - s.year - ((e.month, e.day) < (s.month, s.day))


# --------------------------------------------------------------------------
# Reading Excel (.xlsx) / CSV -- standard library only
# --------------------------------------------------------------------------
def _norm(text):
    """Lower-case, strip diacritics and punctuation: 'Dejotāja vārds' -> 'dejotaja vards'."""
    text = unicodedata.normalize("NFKD", str(text or ""))
    text = "".join(ch for ch in text if not unicodedata.combining(ch)).lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def _col_index(ref):
    letters = re.match(r"[A-Za-z]+", ref).group(0).upper()
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def read_xlsx(path):
    """Return the first worksheet as a list of rows (lists of strings)."""
    rel_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root:
                if _local(si.tag) != "si":
                    continue
                parts = []
                for el in si:
                    kind = _local(el.tag)
                    if kind == "t":
                        parts.append(el.text or "")
                    elif kind == "r":
                        parts.extend((s.text or "") for s in el if _local(s.tag) == "t")
                shared.append("".join(parts))
        sheet_path = None
        try:
            wb = ET.fromstring(z.read("xl/workbook.xml"))
            rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            first = next(el for el in wb.iter() if _local(el.tag) == "sheet")
            rid = first.attrib.get(rel_ns)
            for rel in rels:
                if rel.attrib.get("Id") == rid:
                    target = rel.attrib["Target"]
                    sheet_path = target.lstrip("/") if target.startswith("/") else "xl/" + target
        except Exception:
            sheet_path = None
        if sheet_path not in names:
            candidates = sorted(n for n in names if n.startswith("xl/worksheets/") and n.endswith(".xml"))
            if not candidates:
                raise ValueError("Failā nav atrasta neviena darblapa.")
            sheet_path = candidates[0]
        root = ET.fromstring(z.read(sheet_path))
        rows = []
        for row in root.iter():
            if _local(row.tag) != "row":
                continue
            rnum = int(row.attrib.get("r", len(rows) + 1))
            while len(rows) < rnum - 1:
                rows.append([])
            cells = []
            for c in row:
                if _local(c.tag) != "c":
                    continue
                idx = _col_index(c.attrib["r"]) if "r" in c.attrib else len(cells)
                while len(cells) <= idx:
                    cells.append("")
                kind, val = c.attrib.get("t"), ""
                if kind == "inlineStr":
                    val = "".join((x.text or "") for x in c.iter() if _local(x.tag) == "t")
                else:
                    v = next((x.text for x in c if _local(x.tag) == "v"), None)
                    if v is not None:
                        if kind == "s":
                            val = shared[int(v)]
                        elif kind in ("str", "e"):
                            val = v
                        elif kind == "b":
                            val = "1" if v == "1" else "0"
                        else:
                            try:
                                f = float(v)
                                val = str(int(f)) if f == int(f) else str(f)
                            except ValueError:
                                val = v
                cells[idx] = val.strip()
            rows.append(cells)
        return rows


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        text = fh.read()
    first = text.splitlines()[0] if text.strip() else ""
    delim = max(";,\t", key=first.count) if first else ";"
    return [[c.strip() for c in row] for row in csv.reader(text.splitlines(), delimiter=delim)]


def read_table(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return read_xlsx(path)
    if ext in (".csv", ".txt"):
        return read_csv(path)
    if ext == ".xls":
        raise ValueError("Vecais .xls formāts netiek atbalstīts. Saglabājiet failu kā .xlsx un mēģiniet vēlreiz.")
    raise ValueError("Neatbalstīts faila formāts. Izmantojiet .xlsx vai .csv.")


def normalize_gender(text):
    g = _norm(text)
    if not g:
        return ""
    if g in ("s", "f", "w") or g.startswith(("siev", "fem", "meit", "girl", "woman", "sieviesu")):
        return GENDER_FEMALE
    if g in ("v", "m") or g.startswith(("viri", "mal", "puis", "boy", "man", "zen")):
        return GENDER_MALE
    return None  # unrecognised



# Power icon used on the 'Atgriezties moduļu izvēlē' / 'Beigt darbu' buttons
POWER_ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAEYElEQVR4nJ1VXW8UZRR+znlnZ3e7xWKxEBQEobawTdQgKiDScqGJQoSgM5pUKxgjFybgD8Ds1ntj0CtDAhHB6EwQb4wXXNjeCAKNSqD2Q6garR/VtkC7sx/zvseLnV1Ll1LiezUz7zznOR/POYcwzxGAIECfv+oOk7dOsuLGYklv27h7eBQCEEFuhef5CHwPTAQJc7F1dQm1tSHFDxLzkwRIT7ZdzYe35vvhP1eESqEYottGlGG3uhTPme0hz8aI5ygRzEl7U4IIQOT6+lYODP0+ReT6mggyF0kNgQgoKpyc/6jFbZpeEZuLYHRpn/7maGun56VtIkgmU2vvxnAFhCzo/AcP150/3urd1Wh/WsfJlwFAwNV0EUQBwNPNa15outM6tqqkT53++L4l2e5akhtefN9h6oYJE1NH6pPKmcppCMy+shqNriZBSCKP9haKgmSct3Bon/C9dKytDTQzXVUC8Rzlur4+82Hrqw31yp0OjAQF029bahcBQoSq4kXKT6TVi9OB6SkUBQ316vF7c/qA60LDd7iGAK5vhg42xwF5K9RiBDKZy8n2dZ0/DM80GqEEAB7b0/8Hpos7tZGRYskYYnnzu6MPLCbX15UoGAA8D4oAGW+02uM2r2QCl0p4v/31oZGRIysSAABDIigblihFX3vLkuv3XrkaGrxNRJxKqAUFDnYAQKUJGQCamtopin1zwmbJ5Y0mNp+JgM6lUiYqbYwAAmAIsAHAnlgSioBSVuzLqcBcsywSaNpcW+SeyITIMqVAWjBBon4lgjho0wDAjFFjAMsiBuEnALg+Wi9EkBODF8eY8JtiEIjuBoAO9JoaFUEgUk4Cx8KwfOf4RgT0aNfAxYJGx8RkafvGroFTAtDW7l4NANk2h8RASWSjNoKOyhuNaANYihaGNq/MZMC+Xx52AGjTKwO9G/YMfwEABEgmU5bkhcLAUiK5xxgIgF/KSWnnKsHYWG+ZnExvkDdIxplDg87ubhhcSlcaTDwPSjxUG64NaYsIMh0Wnk/VqVQxFALhq5kRVBtCBOT7Di8Pvr+QSqi1oTbBdJG2PLF7oM/z0rbj9IeIVIQsyEfacrv7i2cPr15OttVnx2hRkJdxK1lqXu9euVoZOVUCz4NyXehzx1p2JOPq83zRGAL+NDA7H+kcPoubnNOH195vx81JAaVTSabJKb1/Y9fge+I5qjIob5iAXrWbWw4uWhjbN3k9BBNyRuSQGPK0FbtcCvImbqkVSuFZAG8QUeOCFGP8mj65oWtwV8VGTYrKAgD5nsOXLvmyrbnl3bqE2mcMwAwEBQOtZQIEQ6BFqSQjki1ygf7kHxN/7anLFwJkITPX6M1mOEm0a88ebX3OitEBCB5KxhnMZYA2QL5oAGBQa7yz/qWBQ5U6zt7Rc26iSk0EoG+Pr9kCwqZQy2qCsFL8sxE589ffuueZ/T8WMhlwdpbnt3W8GZL8v//czgonzwM7Te3UE33oAICxxQLHN/N5/S+AzQ3thXwyfQAAAABJRU5ErkJggg=="

