"""
Pūrlāde — kopīgās lietas visiem moduļiem
(shared paths, the common database, colours, console and error log)

All modules keep their data in ONE database: the file purlade.db next to the Pūrlāde program
file, or — when this computer is connected to it — the shared online database (see datubaze.py).
Modules get their connection with connect_db(); they never open purlade.db themselves.
"""

import csv
import os
import re
import shutil
import sqlite3
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))   # .../moduli
DATA_DIR = os.path.dirname(PACKAGE_DIR)                     # folder of the Pūrlāde program
DB_PATH = os.path.join(DATA_DIR, "purlade.db")
OLD_DB_PATH = os.path.join(DATA_DIR, "costume_inventory.db")  # database of the stand-alone Tērpu pūrs
ERROR_LOG = os.path.join(DATA_DIR, "kludas.log")

# --------------------------------------------------------------------------
# Design (cream / red / navy / gold)
# --------------------------------------------------------------------------
CREAM = "#FFF8E7"
CREAM_DARK = "#F3E8CC"
RED = "#9E1B32"
NAVY = "#1F2A44"
GOLD = "#C9A227"
WHITE = "#FFFFFF"
GREEN = "#1B6B3A"
GREY = "#8C8C8C"


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
try:
    from moduli import datubaze
except ImportError:  # started from inside the moduli folder
    import datubaze


class _LocalConnection(sqlite3.Connection):
    """purlade.db connection; while the system administrator looks as another role (“Skatīt kā”,
    datubaze.PREVIEW) commit() rolls the changes back instead of saving them."""

    def commit(self):
        if datubaze.PREVIEW["on"]:
            pending = self.in_transaction
            self.rollback()
            if pending:
                datubaze.preview_blocked()
            return
        super().commit()


def connect_db(path=None):
    """The shared database connection for a module.
    Online mode: the ONE shared PostgreSQL connection (its close() keeps it open for the others).
    Local mode: a new connection to purlade.db (or `path`), exactly as before."""
    if datubaze.is_online():
        return datubaze.shared_connection()
    return sqlite3.connect(path or DB_PATH, factory=_LocalConnection)


def database_is_online():
    return datubaze.is_online()


def database_label():
    """Short text for the start page: which database this computer uses."""
    return "tiešsaistes datubāze" if datubaze.online_config() else "lokālā datubāze"


def prepare_database():
    """On the first start of Pūrlāde the data of the stand-alone Tērpu pūrs is taken over:
    costume_inventory.db is COPIED to purlade.db (the old file stays as a backup)."""
    if datubaze.is_online():
        datubaze.shared_connection()   # connects (and creates the online tables on the first use)
        return None
    if not os.path.exists(DB_PATH) and os.path.exists(OLD_DB_PATH):
        shutil.copy2(OLD_DB_PATH, DB_PATH)
    return DB_PATH


def read_setting(key, default=None):
    """Read one value from the settings table (None/default when it is not there)."""
    if not datubaze.is_online() and not os.path.exists(DB_PATH):
        return default
    try:
        con = connect_db()
        try:
            row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return default
    return row[0] if row and row[0] else default


COPYRIGHT = "© Adrians Gūtšmits 2026"


def copyright_footer(parent, bg=None):
    """Copyright line at the bottom centre of a module page. Call it right after the header,
    before the page content, so the content cannot push it out of the window."""
    import tkinter as tk
    label = tk.Label(parent, text=COPYRIGHT, font=("Segoe UI", 8), bg=bg or CREAM, fg=NAVY)
    label.pack(side="bottom", pady=(0, 4))
    return label


def load_image(path, max_w, max_h):
    """PNG/GIF work out of the box; JPG needs the optional Pillow package."""
    import tkinter as tk
    try:
        from PIL import Image, ImageTk
    except ImportError:
        img = tk.PhotoImage(file=path)
        f = max(-(-img.width() // max_w), -(-img.height() // max_h), 1)
        return img.subsample(f) if f > 1 else img
    img = Image.open(path)
    img.thumbnail((max_w, max_h))
    return ImageTk.PhotoImage(img)


MODULE_LOGO_DIR = os.path.join(PACKAGE_DIR, "logo")


def module_logo(parent, file_name, on_click=None, size=64, bg=None):
    """The module's round logo (moduli/logo/<file_name>.png) for the left corner of its header.
    Clicking it calls on_click (back to the module's main view). Returns None when there is no file."""
    import tkinter as tk
    path = os.path.join(MODULE_LOGO_DIR, file_name + ".png")
    if not os.path.exists(path):
        return None
    try:
        image = load_image(path, size, size)
    except Exception:
        return None
    label = tk.Label(parent, image=image, bg=bg or NAVY, bd=0, cursor="hand2" if on_click else "")
    label.image = image  # keep a reference, otherwise Tk forgets the picture
    if on_click is not None:
        label.bind("<Button-1>", lambda e: on_click())
    return label


def load_trimmed_image(path, max_w, max_h):
    """Like load_image, but the empty (transparent) margins around the picture are cut off first,
    so a logo with a lot of empty space around it is shown as large as possible."""
    import tkinter as tk
    try:
        from PIL import Image, ImageTk
    except ImportError:
        img = tk.PhotoImage(file=path)
        w, h = img.width(), img.height()
        step = max(1, max(w, h) // 200)  # look at every n-th pixel: fast enough for big pictures
        xs, ys = [], []
        for y in range(0, h, step):
            for x in range(0, w, step):
                if not img.transparency_get(x, y):
                    xs.append(x)
                    ys.append(y)
        if xs:
            x0, y0 = max(min(xs) - step, 0), max(min(ys) - step, 0)
            x1, y1 = min(max(xs) + step + 1, w), min(max(ys) + step + 1, h)
            part = tk.PhotoImage(width=x1 - x0, height=y1 - y0)
            part.tk.call(part, "copy", img, "-from", x0, y0, x1, y1)
            img = part
        f = max(-(-img.width() // max_w), -(-img.height() // max_h), 1)
        return img.subsample(f) if f > 1 else img
    img = Image.open(path)
    if img.mode in ("RGBA", "LA", "P"):
        box = img.convert("RGBA").getchannel("A").getbbox()
        if box:
            img = img.crop(box)
    img.thumbnail((max_w, max_h))
    return ImageTk.PhotoImage(img)


def group_logo(max_w, max_h):
    """The collective's logo chosen in Administrēšana (or None); empty margins are cut off."""
    name = read_setting("logo.file")
    if not name:
        return None
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return None
    try:
        return load_trimmed_image(path, max_w, max_h)
    except Exception:
        try:
            return load_image(path, max_w, max_h)
        except Exception:
            return None


# --------------------------------------------------------------------------
# Error log
# --------------------------------------------------------------------------
def log_error(text):
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as fh:
            fh.write(datetime.now().strftime("%d.%m.%Y %H:%M:%S") + "\n" + text + "\n")
    except Exception:
        pass


# --------------------------------------------------------------------------
# Console window (Windows): hidden at start, can be shown again from Administrēšana
# --------------------------------------------------------------------------
def _console_hwnd():
    if os.name != "nt":
        return 0
    try:
        import ctypes
        return ctypes.windll.kernel32.GetConsoleWindow()
    except Exception:
        return 0


def console_available():
    return bool(_console_hwnd())


def console_visible():
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        return bool(ctypes.windll.user32.IsWindowVisible(hwnd))
    except Exception:
        return False


def set_console_visible(show):
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        ctypes.windll.user32.ShowWindow(hwnd, 5 if show else 0)  # SW_SHOW / SW_HIDE
        return True
    except Exception:
        return False


def console_is_own():
    # True when the console window belongs only to this program (double-clicked), not to a
    # terminal the program was started from - such a terminal must not be hidden.
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes
        procs = (ctypes.c_uint * 8)()
        return ctypes.windll.kernel32.GetConsoleProcessList(procs, 8) <= 1
    except Exception:
        return False


# --------------------------------------------------------------------------
# Dancers (kept by Kopas pūrs, read by the other modules)
# --------------------------------------------------------------------------
GENDER_MALE = "Vīrietis"
GENDER_FEMALE = "Sieviete"
GENDERS = [GENDER_MALE, GENDER_FEMALE]

STATUS_ACTIVE = "Aktīvs"
STATUS_INACTIVE = "Uz pauzes"
OLD_STATUS_INACTIVE = "Neaktīvs"   # name used before Kopas pūrs v0.1.4
STATUS_LEFT = "Izstājies"
DANCER_STATUSES = [STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT]

# Role in the collective. Leaders and rehearsal directors are kept in the same list (Kopas pūrs),
# but they are not dancers: they are not counted as dancers and the other modules do not offer them
# as dancers. An empty role (older records) means a dancer.
ROLE_DANCER = "Dejotājs"
ROLE_LEADER = "Vadītājs"
ROLE_REPETITOR = "Repetitors"
PERSON_ROLES = [ROLE_DANCER, ROLE_LEADER, ROLE_REPETITOR]

# --------------------------------------------------------------------------
# Lietotnes lomas (app roles): what a person may see and change in the mobile app and — once the
# desktop Pūrlāde has sign-in — in the program. Every dancer has the app role "Dejotājs"; the other
# app roles are given to dancers separately (Kopas pūrs → dancer window, or the mobile app) by a
# leader or a system administrator. Leaders and rehearsal directors get "Vadītājs" / "Repetitors"
# automatically from their role in the collective (they cannot get the dancers' extra app roles).
# Stored in dancers.app_roles as a comma separated list of the extra app roles.
# --------------------------------------------------------------------------
APP_ROLE_DANCER = "Dejotājs"
APP_ROLE_COSTUMES = "Tērpu pārzinis"
APP_ROLE_ADMIN = "Sistēmas administrators"
APP_ROLE_PRESIDENT = "Prezidents"          # like a leader, read only — for group A
APP_ROLE_STUDIO_ELDER = "Studijas vecākais"  # the same rights as the president — for group Studija
APP_ROLE_STUDIO_REPETITOR = "Studijas repetitors"  # the same rights as a repetitor — only for group Studija
APP_ROLE_SOCIAL = "Sociālo tīklu administrators"
APP_ROLE_GREETER = "Sveicējs"            # greets the dancers on their birthdays and name days
APP_ROLE_CASHIER_A = "A grupas kasieris"          # Zelta pūrs (finances) of group A — once that module is made
APP_ROLE_CASHIER_STUDIO = "Studijas kasieris"     # Zelta pūrs (finances) of group Studija
APP_ROLE_LEADER = ROLE_LEADER          # automatic for leaders
APP_ROLE_REPETITOR = ROLE_REPETITOR    # automatic for rehearsal directors
EXTRA_APP_ROLES = [APP_ROLE_COSTUMES, APP_ROLE_ADMIN, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER,
                   APP_ROLE_STUDIO_REPETITOR, APP_ROLE_SOCIAL,
                   APP_ROLE_GREETER, APP_ROLE_CASHIER_A, APP_ROLE_CASHIER_STUDIO]

# Dancer groups (Kopas pūrs → "Grupa"; only for dancers). Stored in dancers.dancer_group.
DANCER_GROUPS = ["A", "Studija", "VPDK"]
DEFAULT_DANCER_GROUP = "A"
INITIAL_GROUP_KEY = "dancer_group.initial"   # one-time: every dancer who existed then got group A

# right -> app roles that have it. The system administrator has every right.
RIGHT_OVERVIEW = "overview"                  # app: overview of all dancers' answers, every event
RIGHT_CHANGE_ANSWERS = "change_answers"      # app: change other dancers' answers (also after the deadline)
RIGHT_COSTUME_SUMMARY = "costume_summary"    # app: costume summary of an event (who needs which costume)
RIGHT_ALL_NOTIFICATIONS = "all_notifications"  # app: every notification meant for the leaders
RIGHT_ABSENCE_NOTIFICATIONS = "absence_notifications"  # app: "Nebūs" notifications
RIGHT_ASSIGN_APP_ROLES = "assign_app_roles"  # give / take away app roles
RIGHT_EDIT_COSTUMES = "edit_costumes"        # program: edit Tērpu pūrs (checked once the program has sign-in)
RIGHT_ALL_EVENTS = "all_events"              # app: the plan shows every event (all groups, publicity events)
RIGHT_NEW_EVENT_NOTIFICATIONS = "new_event_notifications"  # app: notice when a concert / review / publicity event
#                                                            is created or confirmed
RIGHT_EDIT_SITE = "edit_site"                # website: add events, gallery and dancers' pictures
RIGHT_DESKTOP = "desktop"                    # website: download the desktop Pūrlāde
RIGHT_GREETINGS = "greetings"                # app: list of birthdays and name days + notice 3 days before
RIGHT_INVITE = "invite"                      # app: invite dancers to a publicity event
RIGHT_FINANCE = "finance"                    # program: Zelta pūrs (finanšu pārvaldība) — checked by that module;
#                                              which group's finances: right_scope(roles, RIGHT_FINANCE)
APP_RIGHTS = {
    RIGHT_OVERVIEW: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER},
    RIGHT_CHANGE_ANSWERS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR},
    RIGHT_COSTUME_SUMMARY: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER, APP_ROLE_COSTUMES},
    RIGHT_ALL_NOTIFICATIONS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER},
    RIGHT_ABSENCE_NOTIFICATIONS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER, APP_ROLE_COSTUMES},
    RIGHT_ASSIGN_APP_ROLES: {APP_ROLE_LEADER},
    RIGHT_EDIT_COSTUMES: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_COSTUMES},
    RIGHT_ALL_EVENTS: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER, APP_ROLE_SOCIAL},
    RIGHT_NEW_EVENT_NOTIFICATIONS: {APP_ROLE_SOCIAL},
    RIGHT_EDIT_SITE: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER, APP_ROLE_COSTUMES, APP_ROLE_SOCIAL},
    RIGHT_DESKTOP: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER,
                    APP_ROLE_COSTUMES, APP_ROLE_CASHIER_A, APP_ROLE_CASHIER_STUDIO},   # = moduli/piekluve.py
    #                 (sociālo tīklu administrators — tikai Kabatas Pūrlāde, ne datora versija)
    RIGHT_GREETINGS: {APP_ROLE_GREETER},
    RIGHT_FINANCE: {APP_ROLE_CASHIER_A, APP_ROLE_CASHIER_STUDIO},
    RIGHT_INVITE: {APP_ROLE_LEADER, APP_ROLE_REPETITOR, APP_ROLE_STUDIO_REPETITOR, APP_ROLE_SOCIAL},
}

# App roles whose rights cover only one dancer group: the overview, the leaders' notifications, the costume summary
# and the plan of all events show only the events and dancers of that group. Desktop Pūrlāde and the website are
# not limited by group.
GROUP_SCOPED_ROLES = {APP_ROLE_PRESIDENT: "A", APP_ROLE_STUDIO_ELDER: "Studija", APP_ROLE_STUDIO_REPETITOR: "Studija",
                      APP_ROLE_CASHIER_A: "A", APP_ROLE_CASHIER_STUDIO: "Studija"}


def right_scope(app_roles, right):
    """Which dancer groups a right covers for this person: None = every group (leaders, repetitors, system
    administrator, or the right comes from a role that is not limited by group); a set of groups when the right
    comes only from group roles (Prezidents → {"A"}, Studijas vecākais → {"Studija"}); empty set = no such right."""
    roles = set(app_roles or ())
    if APP_ROLE_ADMIN in roles:
        return None
    givers = roles & APP_RIGHTS.get(right, set())
    if not givers:
        return set()
    if any(r not in GROUP_SCOPED_ROLES for r in givers):
        return None
    return {GROUP_SCOPED_ROLES[r] for r in givers}


def in_scope(group, scope):
    """Is a dancer of this group inside the scope? (None = all; an empty group of a dancer = A)"""
    return scope is None or ((group or "").strip() or DEFAULT_DANCER_GROUP) in scope


def event_in_scope(groups_text, scope):
    """Is an event (its groups, Notikumu pūrs → Grupa; empty = all groups) inside the scope?"""
    if scope is None:
        return True
    groups = event_groups(groups_text)
    return not groups or bool(set(groups) & scope)


# one-time: the first system administrator (Pūrlāde v0.6)
INITIAL_ADMIN = ("Adrians", "Gūtšmits")
INITIAL_ADMIN_KEY = "app_roles.initial_admin"


def parse_app_roles(text):
    """'Prezidents, Tērpu pārzinis' -> the extra app roles in the standard order (unknown names dropped)."""
    given = {_norm(p) for p in (text or "").split(",") if p.strip()}
    return [r for r in EXTRA_APP_ROLES if _norm(r) in given]


def app_roles_text(roles):
    """Extra app roles -> text stored in dancers.app_roles."""
    return ", ".join(r for r in EXTRA_APP_ROLES if r in roles)


def app_roles_of(role, stored):
    """All app roles of a person: role in the collective (dancers.role) + stored extra app roles."""
    role = (role or "").strip() or ROLE_DANCER
    if role == ROLE_LEADER:
        return [APP_ROLE_LEADER]
    if role == ROLE_REPETITOR:
        return [APP_ROLE_REPETITOR]
    return [APP_ROLE_DANCER] + parse_app_roles(stored)


def has_right(app_roles, right):
    """True when one of the app roles gives the right (the system administrator has all rights)."""
    roles = set(app_roles or ())
    return APP_ROLE_ADMIN in roles or bool(roles & APP_RIGHTS.get(right, set()))


def _seed_initial_group(con):
    """Once: every dancer already in Kopas pūrs gets group "A" (Kopas pūrs v0.1.8). Done one time only, so later
    changes of a group are never overwritten."""
    try:
        if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_GROUP_KEY,)).fetchone():
            return
    except sqlite3.Error:
        return   # no settings table yet: try again next time
    con.execute("UPDATE dancers SET dancer_group=? WHERE TRIM(COALESCE(dancer_group,'')) = '' AND "
                f"TRIM(COALESCE(role,'')) IN ('', '{ROLE_DANCER}')", (DEFAULT_DANCER_GROUP,))
    con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (INITIAL_GROUP_KEY, DEFAULT_DANCER_GROUP))


def _seed_initial_admin(con):
    """Gives Adrians Gūtšmits the app role "Sistēmas administrators" once (when he is in Kopas pūrs as a
    dancer). Done only one time, so the role can later be taken away like any other."""
    try:
        if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_ADMIN_KEY,)).fetchone():
            return
    except sqlite3.Error:
        return   # no settings table yet: try again next time
    first, last = (_norm(x) for x in INITIAL_ADMIN)
    for did, f, l, role, stored in con.execute(
            "SELECT id, first_name, last_name, role, app_roles FROM dancers").fetchall():
        if _norm(f) == first and _norm(l) == last and (role or ROLE_DANCER).strip() in ("", ROLE_DANCER):
            roles = set(parse_app_roles(stored)) | {APP_ROLE_ADMIN}
            con.execute("UPDATE dancers SET app_roles=? WHERE id=?", (app_roles_text(roles), did))
            con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (INITIAL_ADMIN_KEY, str(did)))
            return

CLOTHING_SIZES = ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]

# column -> SQL declaration; "name" (full name) is kept up to date for the other modules
DANCER_COLUMNS = [
    ("gender", "TEXT DEFAULT ''"),
    ("contact", "TEXT DEFAULT ''"),
    ("first_name", "TEXT DEFAULT ''"),
    ("last_name", "TEXT DEFAULT ''"),
    ("birth_date", "TEXT DEFAULT ''"),
    ("join_date", "TEXT DEFAULT ''"),
    ("status", "TEXT DEFAULT ''"),
    ("height", "TEXT DEFAULT ''"),
    ("clothing_size", "TEXT DEFAULT ''"),
    ("role", "TEXT DEFAULT ''"),
    ("app_roles", "TEXT DEFAULT ''"),
    ("dancer_group", "TEXT DEFAULT ''"),
]


def ensure_dancer_schema(con):
    """Create / extend the dancers table. Older databases had one name field: it is split
    into first name and last name (first word = first name)."""
    con.execute("CREATE TABLE IF NOT EXISTS dancers (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "name TEXT NOT NULL, gender TEXT DEFAULT '', contact TEXT DEFAULT '')")
    have = {r[1] for r in con.execute("PRAGMA table_info(dancers)")}
    for column, decl in DANCER_COLUMNS:
        if column not in have:
            con.execute(f"ALTER TABLE dancers ADD COLUMN {column} {decl}")
    rows = con.execute("SELECT id, name FROM dancers WHERE TRIM(COALESCE(first_name,'')) = '' "
                       "AND TRIM(COALESCE(last_name,'')) = ''").fetchall()
    for did, name in rows:
        parts = (name or "").split(None, 1)
        con.execute("UPDATE dancers SET first_name=?, last_name=? WHERE id=?",
                    (parts[0] if parts else "", parts[1] if len(parts) > 1 else "", did))
    con.execute("UPDATE dancers SET status=? WHERE TRIM(COALESCE(status,'')) = ''", (STATUS_ACTIVE,))
    con.execute("UPDATE dancers SET status=? WHERE status=?", (STATUS_INACTIVE, OLD_STATUS_INACTIVE))
    _seed_initial_admin(con)
    _seed_initial_group(con)
    con.commit()


# --------------------------------------------------------------------------
# Kabatas Pūrlāde: e-pasti, ar kuriem dejotāji piesakās lietotnē (ievada Kopas pūrā)
# --------------------------------------------------------------------------
# The same app_users table that the Kabatas Pūrlāde server creates (mobila/serveris.py, APP_SCHEMA);
# the server reads the e-mails from it when a dancer logs in.
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
APP_USERS_SCHEMA = """CREATE TABLE IF NOT EXISTS app_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dancer_id INTEGER NOT NULL UNIQUE REFERENCES dancers(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    active INTEGER DEFAULT 1,
    created TEXT DEFAULT ''
)"""


def _has_table(con, name):
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def ensure_app_users(con):
    """Create the app_users table when the Kabatas Pūrlāde server has not done it yet."""
    if _has_table(con, "app_users"):
        return
    con.execute(APP_USERS_SCHEMA)
    con.commit()
    if datubaze.is_online():
        # the online database keeps every table closed to the Supabase web API (row level security)
        try:
            datubaze.ensure_schema(datubaze.shared_connection())
        except Exception as exc:
            log_error(f"app_users drošības iestatījumi: {exc}")


def app_emails(con):
    """{dancer id: e-mail} of everyone who can log in to Kabatas Pūrlāde."""
    if not _has_table(con, "app_users"):
        return {}
    return {d: e for d, e in con.execute("SELECT dancer_id, email FROM app_users WHERE active=1").fetchall()}


def app_email(con, dancer_id):
    return app_emails(con).get(dancer_id, "")


def check_app_email(con, dancer_id, email):
    """Error text for an e-mail that cannot be used (None when it is fine). Empty = no app access."""
    email = (email or "").strip().lower()
    if not email:
        return None
    if not EMAIL_RE.match(email):
        return "Nederīga e-pasta adrese."
    if _has_table(con, "app_users"):
        other = con.execute("SELECT dancer_id FROM app_users WHERE email=?", (email,)).fetchone()
        if other and other[0] != dancer_id:
            row = con.execute("SELECT name FROM dancers WHERE id=?", (other[0],)).fetchone()
            who = f" ({row[0]})" if row and row[0] else ""
            return f"Šis e-pasts jau piešķirts citam cilvēkam{who}."
    return None


def set_app_email(con, dancer_id, email):
    """Give (or change, or with an empty e-mail take away) the dancer's Kabatas Pūrlāde login.
    Same rules as the server's own set_email: a new address ends the old logins."""
    email = (email or "").strip().lower()
    problem = check_app_email(con, dancer_id, email)
    if problem:
        raise ValueError(problem)
    if not email and not _has_table(con, "app_users"):
        return
    ensure_app_users(con)
    row = con.execute("SELECT id, email FROM app_users WHERE dancer_id=?", (dancer_id,)).fetchone()
    if not email:
        if row:
            for table in ("app_sessions", "app_push_subscriptions", "app_notification_reads"):
                if _has_table(con, table):
                    con.execute(f"DELETE FROM {table} WHERE user_id=?", (row[0],))
            con.execute("DELETE FROM app_users WHERE id=?", (row[0],))
    elif row:
        if row[1] != email and _has_table(con, "app_sessions"):   # new address: the old logins end
            con.execute("DELETE FROM app_sessions WHERE user_id=?", (row[0],))
        con.execute("UPDATE app_users SET email=?, active=1 WHERE id=?", (email, row[0]))
    else:
        con.execute("INSERT INTO app_users (dancer_id, email, active, created) VALUES (?,?,1,?)",
                    (dancer_id, email, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    con.commit()


# --------------------------------------------------------------------------
# Kolektīva pasākuma apakšveidi (Notikumu pūrs, Kabatas Pūrlāde)
# --------------------------------------------------------------------------
EVENT_KIND_GROUP = "Kolektīva pasākums"          # the event kind that has sub-kinds and no dances
SUBKIND_TEAM = "Saliedēšanās pasākums"
SUBKIND_BOYS = "Puišu pasākums"
SUBKIND_GIRLS = "Meiteņu pasākums"
SUBKIND_PUBLICITY = "Publicitātes pasākums"     # only the invited dancers see it and get notifications
EVENT_SUBKINDS = [SUBKIND_TEAM, SUBKIND_BOYS, SUBKIND_GIRLS, SUBKIND_PUBLICITY]


EVENT_COSTUMES_SCHEMA = """
CREATE TABLE IF NOT EXISTS event_costumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    gender TEXT NOT NULL,
    type_name TEXT NOT NULL,
    UNIQUE (session_id, gender, type_name)
);
"""


def ensure_event_detail_columns(con):
    """event_details.subkind (apakšveids), event_details.invited (uzaicināto dejotāju id, '3,7,12'),
    event_details.for_groups (kurām grupām notikums: 'A,Studija'; tukšs — visām) and the table event_costumes
    (publicitātes pasākuma tērpu veidi katram dzimumam, tāpat kā dance_costumes dejām).
    Notikumu pūrs v0.2.2: event_details.transport_kind (Autobuss / Savs transports …), event_details.bus_price
    (autobusa cena vienam dejotājam, centos) un event_participants.bus (brauks ar autobusu)."""
    have = {r[1] for r in con.execute("PRAGMA table_info(event_details)")}
    if have:
        for column in ("subkind", "invited", "for_groups", "transport_kind", "bus_price", "costume_issue_date",
                       "costume_return_date"):
            if column not in have:
                con.execute(f"ALTER TABLE event_details ADD COLUMN {column} TEXT DEFAULT ''")
    have = {r[1] for r in con.execute("PRAGMA table_info(event_participants)")}
    if have and "bus" not in have:   # Notikumu pūrs v0.2.2: '1' — brauks ar autobusu, '0' — nebrauks
        con.execute("ALTER TABLE event_participants ADD COLUMN bus TEXT DEFAULT ''")
    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attendance_sessions'").fetchone():
        con.executescript(EVENT_COSTUMES_SCHEMA)
        if have:
            _seed_initial_event_groups(con)
    con.commit()


INITIAL_EVENT_GROUP_KEY = "event_groups.initial"   # one-time: every event that existed then got group A


def _seed_initial_event_groups(con):
    """Once (Notikumu pūrs v0.1.7 / Cītības pūrs v0.1.10): every event already entered gets group "A" —
    they were all made before there were other groups. Later changes are never overwritten."""
    if con.execute("SELECT value FROM settings WHERE key=?", (INITIAL_EVENT_GROUP_KEY,)).fetchone():
        return
    con.execute("INSERT INTO event_details (session_id, for_groups) SELECT id, ? FROM attendance_sessions "
                "WHERE id NOT IN (SELECT session_id FROM event_details)", (DEFAULT_DANCER_GROUP,))
    con.execute("UPDATE event_details SET for_groups=? WHERE TRIM(COALESCE(for_groups,'')) = ''",
                (DEFAULT_DANCER_GROUP,))
    con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (INITIAL_EVENT_GROUP_KEY, DEFAULT_DANCER_GROUP))


# ---- event groups (A / Studija / VPDK): which groups an event is for ----
def event_groups(text):
    """'A,Studija' -> ['A', 'Studija'] (in DANCER_GROUPS order; empty = all groups)."""
    chosen = {g.strip() for g in (text or "").split(",") if g.strip()}
    return [g for g in DANCER_GROUPS if g in chosen] + sorted(chosen - set(DANCER_GROUPS))


def event_groups_text(groups):
    return ",".join(event_groups(",".join(groups)))


def groups_label(text):
    """'A, Studija' — or 'visas grupas' when the event is for every group."""
    groups = event_groups(text)
    return ", ".join(groups) if groups and set(groups) != set(DANCER_GROUPS) else "visas grupas"


def in_event_groups(dancer_group, groups_text):
    """Is a dancer of this group meant by the event? (empty group of an event = all; empty group of a dancer = A)"""
    groups = event_groups(groups_text)
    return not groups or ((dancer_group or "").strip() or DEFAULT_DANCER_GROUP) in groups


def event_costume_types(con, session_ids):
    """{session id: {gender: [costume types]}} — costume types chosen for publicity events (Notikumu pūrs)."""
    ids = list(session_ids)
    if not ids or not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='event_costumes'").fetchone():
        return {}
    result = {}
    for sid, gender, name in con.execute("SELECT session_id, gender, type_name FROM event_costumes WHERE session_id IN ("
                                         + ",".join("?" * len(ids)) + ") ORDER BY id", ids).fetchall():
        result.setdefault(sid, {}).setdefault(gender, []).append(name)
    return result


def invited_ids(text):
    """'3,7,12' -> {3, 7, 12}"""
    return {int(x) for x in re.findall(r"\d+", text or "")}


def invited_text(ids):
    return ",".join(str(i) for i in sorted(set(ids)))


def is_publicity(kind, subkind):
    return kind == EVENT_KIND_GROUP and subkind == SUBKIND_PUBLICITY


def full_name(first, last):
    return " ".join(p for p in ((first or "").strip(), (last or "").strip()) if p)


def dancer_role_sql(alias="dancers"):
    """SQL condition: the person is a dancer, not a leader or rehearsal director (empty role = dancer)."""
    return f"(TRIM(COALESCE({alias}.role,'')) IN ('', '{ROLE_DANCER}'))"


def active_dancer_sql(alias="dancers"):
    """SQL condition: an active dancer (an empty status counts as active); leaders and rehearsal
    directors are never included."""
    return f"(TRIM(COALESCE({alias}.status,'')) IN ('', '{STATUS_ACTIVE}') AND {dancer_role_sql(alias)})"


# --------------------------------------------------------------------------
# Dance casts (kept by Deju pūrs, read by Notikumu pūrs and Tērpu pūrs)
# --------------------------------------------------------------------------
CAST_MAIN = "Pamatsastāvs"
CAST_RESERVE = "Rezerve"


def ensure_cast_substitutes(con):
    """dance_cast.substitute_id: the dancer who replaces this main-cast dancer in this dance."""
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dance_cast'").fetchone():
        return False
    cols = {r[1] for r in con.execute("PRAGMA table_info(dance_cast)")}
    if "substitute_id" not in cols:
        con.execute("ALTER TABLE dance_cast ADD COLUMN substitute_id INTEGER "
                    "REFERENCES dancers(id) ON DELETE SET NULL")
        con.commit()
    return True


def dance_lineup(con, dance_id, declined=()):
    """Who dances `dance_id` at an event where the dancers in `declined` answered "Nebūs".
    Main-cast dancers who come dance themselves; for a main-cast dancer who does not come, his
    assigned reserve dancer (substitute) is taken automatically, if that one has not declined too.
    Returns (lineup, uncovered): lineup = [(dancer id, id of the dancer he replaces or None)],
    uncovered = main-cast dancers who do not come and have no available substitute."""
    if not ensure_cast_substitutes(con):
        return [], []
    declined = set(declined)
    rows = con.execute("SELECT dancer_id, role, substitute_id FROM dance_cast WHERE dance_id=? ORDER BY id",
                       (dance_id,)).fetchall()
    main = [(d, sub) for d, role, sub in rows if (role or CAST_MAIN) != CAST_RESERVE]
    lineup, used, uncovered = [], set(), []
    for d, _sub in main:
        if d not in declined:
            lineup.append((d, None))
            used.add(d)
    for d, sub in main:
        if d in declined:
            if sub and sub not in declined and sub not in used:
                lineup.append((sub, d))
                used.add(sub)
            else:
                uncovered.append(d)
    return lineup, uncovered


# --------------------------------------------------------------------------
# Autobuss (Notikumu pūrs → Kabatas Pūrlāde → Zelta pūrs)
# --------------------------------------------------------------------------
TRANSPORT_BUS = "Autobuss"
TRANSPORT_KINDS = [TRANSPORT_BUS, "Savs transports", "Sabiedriskais transports", "Cits"]
BUS_CATEGORY = "Iemaksas par autobusiem un pasākumiem"   # Zelta pūrs → Ienākumi (tā pati kā Excel importā)
BUS_YES, BUS_NO = "1", "0"          # event_participants.bus: brauks / nebrauks ('' — nav atzīmēts)
BUS_REASON_DANCES = "dejo"
BUS_REASON_MARKED = "brauks ar autobusu"


def guess_transport_kind(kind, text):
    """Older events have only the free text: 'autobuss no kultūras nama 15:00' -> Autobuss."""
    if kind:
        return kind
    return TRANSPORT_BUS if "autobus" in (text or "").lower() else ""


def bus_cents(text):
    """event_details.bus_price ('1250' = 12,50 €) -> 1250; empty / wrong -> 0."""
    try:
        return max(0, int(str(text or "").strip() or 0))
    except ValueError:
        return 0


def euro_text(cents):
    """1250 -> '12,50 €'"""
    cents = int(cents or 0)
    whole, part = divmod(abs(cents), 100)
    return ("−" if cents < 0 else "") + f"{whole:,}".replace(",", " ") + f",{part:02d} €"


def parse_euro(text):
    """'12,50' / '12.5' / '12 €' -> 1250; empty -> 0; wrong -> None."""
    t = str(text or "").replace("€", "").replace(" ", "").replace("\u00a0", "").replace(",", ".").strip()
    if not t:
        return 0
    if not re.fullmatch(r"\d+(\.\d{1,2})?", t):
        return None
    whole, _, part = t.partition(".")
    return int(whole) * 100 + int((part + "00")[:2])


def bus_payers_from(dancing, answers, marks):
    """{dancer id: reason} — who has to pay for the bus: everyone who dances in the event (`dancing`: the
    line-ups of its dances, reserve dancers who replace someone included) and everyone marked “brauks ar
    autobusu”. Not: those who answered “Nebūs” and those marked “nebrauks” (e.g. comes by his own car).
    answers: {dancer id: answer}, marks: {dancer id: '1' / '0' / ''}."""
    result = {}
    for d in dancing:
        result[d] = BUS_REASON_DANCES
    for d, mark in marks.items():
        if mark == BUS_YES and d not in result:
            result[d] = BUS_REASON_MARKED
    return {d: why for d, why in result.items()
            if answers.get(d) != "Nebūs" and marks.get(d) != BUS_NO}


def _table(con, name):
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def bus_events(con, session_ids=None):
    """{session id: dict(date, kind, title, groups, price, status, subkind)} — events with the transport
    “Autobuss” and a price (not cancelled)."""
    if not _table(con, "event_details") or "bus_price" not in {r[1] for r in con.execute(
            "PRAGMA table_info(event_details)")}:
        return {}
    rows = con.execute("SELECT s.id, s.session_date, COALESCE(s.kind,''), COALESCE(s.title,''), "
                       "COALESCE(e.for_groups,''), COALESCE(e.bus_price,''), COALESCE(e.status,''), "
                       "COALESCE(e.subkind,''), COALESCE(e.transport_kind,''), COALESCE(e.transport,'') "
                       "FROM attendance_sessions s JOIN event_details e ON e.session_id = s.id "
                       "WHERE COALESCE(e.bus_price,'') <> ''").fetchall()
    wanted = set(session_ids) if session_ids is not None else None
    result = {}
    for sid, d, kind, title, groups, price, status, subkind, tkind, ttext in rows:
        if wanted is not None and sid not in wanted:
            continue
        if guess_transport_kind(tkind, ttext) != TRANSPORT_BUS or not bus_cents(price) or status == "Atcelts":
            continue
        result[sid] = {"id": sid, "date": d or "", "kind": kind, "title": title, "groups": groups,
                       "price": bus_cents(price), "status": status, "subkind": subkind}
    return result


def bus_payers(con, sid, with_dancing=False):
    """{dancer id: reason} for one event, from the database (programme, casts, answers, bus marks).
    with_dancing=True -> (payers, set of the dancers who dance in the event)."""
    answers, marks = {}, {}
    cols = {r[1] for r in con.execute("PRAGMA table_info(event_participants)")}
    if cols:
        bus_col = "COALESCE(bus,'')" if "bus" in cols else "''"
        for did, ans, mark in con.execute(f"SELECT dancer_id, COALESCE(answer,''), {bus_col} FROM event_participants "
                                          "WHERE session_id=?", (sid,)).fetchall():
            answers[did], marks[did] = ans, mark
    dancing = set()
    if _table(con, "session_dances"):
        declined = {d for d, a in answers.items() if a == "Nebūs"}
        for (dance_id,) in con.execute("SELECT dance_id FROM session_dances WHERE session_id=?", (sid,)).fetchall():
            lineup, _uncovered = dance_lineup(con, dance_id, declined)
            dancing.update(d for d, _r in lineup)
    payers = bus_payers_from(dancing, answers, marks)
    return (payers, dancing) if with_dancing else payers


def bus_paid(con, session_ids=None):
    """{(session id, dancer id): cents} — bus payments registered in Zelta pūrs (Ienākumi, category
    “Iemaksas par autobusiem un pasākumiem”, with the event and the dancer)."""
    if not _table(con, "fin_entries"):
        return {}
    result = {}
    for sid, did, cents in con.execute(
            "SELECT session_id, dancer_id, amount_cents FROM fin_entries WHERE kind='Ienākumi' AND category=? "
            "AND session_id IS NOT NULL AND dancer_id IS NOT NULL", (BUS_CATEGORY,)).fetchall():
        if session_ids is None or sid in session_ids:
            result[(sid, did)] = result.get((sid, did), 0) + int(cents or 0)
    return result


def bus_dues(con, dancer_id=None, session_ids=None):
    """[dict(session_id, dancer_id, reason, price, paid, due)] — everyone who has to pay for a bus (due > 0:
    not paid yet). With dancer_id — only that dancer."""
    events = bus_events(con, session_ids)
    paid = bus_paid(con, set(events))
    result = []
    for sid, ev in sorted(events.items(), key=lambda kv: (kv[1]["date"], kv[0])):
        payers = bus_payers(con, sid)
        if dancer_id is not None:
            payers = {d: w for d, w in payers.items() if d == dancer_id}
        for did, why in payers.items():
            got = paid.get((sid, did), 0)
            result.append({"session_id": sid, "dancer_id": did, "reason": why, "price": ev["price"], "paid": got,
                           "due": max(0, ev["price"] - got), "event": ev})
    return result


def dancer_size_text(con, dancer_id):
    """'Augums: 172 cm, izmērs: M' for the costume fitting (empty when nothing is known)."""
    try:
        row = con.execute("SELECT height, clothing_size FROM dancers WHERE id=?", (dancer_id,)).fetchone()
    except sqlite3.Error:
        return ""
    if not row:
        return ""
    parts = []
    if (row[0] or "").strip():
        parts.append(f"augums: {row[0].strip()} cm")
    if (row[1] or "").strip():
        parts.append(f"izmērs: {row[1].strip()}")
    return ("Dejotāja " + ", ".join(parts)) if parts else ""


def parse_date(text):
    """'2026-10-21', '21.10.2026', '21/10/2026' or an Excel day number -> '2026-10-21'.
    Empty text -> ''. Anything else -> None."""
    text = str(text or "").strip()
    if not text:
        return ""
    if re.fullmatch(r"\d{4,6}(\.0+)?", text):  # Excel stores dates as day numbers
        n = int(float(text))
        if 1 <= n < 80000:
            return (date(1899, 12, 30) + timedelta(days=n)).isoformat()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%d.%m.%y", "%Y.%m.%d"):
        try:
            return datetime.strptime(text.rstrip("."), fmt).date().isoformat()
        except ValueError:
            pass
    return None


def years_between(start, end=None):
    """Whole years from start (ISO date) to end/today; None when start is unknown."""
    try:
        s = datetime.strptime(start, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None
    e = end or date.today()
    return e.year - s.year - ((e.month, e.day) < (s.month, s.day))


# --------------------------------------------------------------------------
# Reading Excel (.xlsx) / CSV -- standard library only
# --------------------------------------------------------------------------
def _norm(text):
    """Lower-case, strip diacritics and punctuation: 'Dejotāja vārds' -> 'dejotaja vards'."""
    text = unicodedata.normalize("NFKD", str(text or ""))
    text = "".join(ch for ch in text if not unicodedata.combining(ch)).lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def _col_index(ref):
    letters = re.match(r"[A-Za-z]+", ref).group(0).upper()
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def read_xlsx(path):
    """Return the first worksheet as a list of rows (lists of strings)."""
    rel_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root:
                if _local(si.tag) != "si":
                    continue
                parts = []
                for el in si:
                    kind = _local(el.tag)
                    if kind == "t":
                        parts.append(el.text or "")
                    elif kind == "r":
                        parts.extend((s.text or "") for s in el if _local(s.tag) == "t")
                shared.append("".join(parts))
        sheet_path = None
        try:
            wb = ET.fromstring(z.read("xl/workbook.xml"))
            rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            first = next(el for el in wb.iter() if _local(el.tag) == "sheet")
            rid = first.attrib.get(rel_ns)
            for rel in rels:
                if rel.attrib.get("Id") == rid:
                    target = rel.attrib["Target"]
                    sheet_path = target.lstrip("/") if target.startswith("/") else "xl/" + target
        except Exception:
            sheet_path = None
        if sheet_path not in names:
            candidates = sorted(n for n in names if n.startswith("xl/worksheets/") and n.endswith(".xml"))
            if not candidates:
                raise ValueError("Failā nav atrasta neviena darblapa.")
            sheet_path = candidates[0]
        root = ET.fromstring(z.read(sheet_path))
        rows = []
        for row in root.iter():
            if _local(row.tag) != "row":
                continue
            rnum = int(row.attrib.get("r", len(rows) + 1))
            while len(rows) < rnum - 1:
                rows.append([])
            cells = []
            for c in row:
                if _local(c.tag) != "c":
                    continue
                idx = _col_index(c.attrib["r"]) if "r" in c.attrib else len(cells)
                while len(cells) <= idx:
                    cells.append("")
                kind, val = c.attrib.get("t"), ""
                if kind == "inlineStr":
                    val = "".join((x.text or "") for x in c.iter() if _local(x.tag) == "t")
                else:
                    v = next((x.text for x in c if _local(x.tag) == "v"), None)
                    if v is not None:
                        if kind == "s":
                            val = shared[int(v)]
                        elif kind in ("str", "e"):
                            val = v
                        elif kind == "b":
                            val = "1" if v == "1" else "0"
                        else:
                            try:
                                f = float(v)
                                val = str(int(f)) if f == int(f) else str(f)
                            except ValueError:
                                val = v
                cells[idx] = val.strip()
            rows.append(cells)
        return rows


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        text = fh.read()
    first = text.splitlines()[0] if text.strip() else ""
    delim = max(";,\t", key=first.count) if first else ";"
    return [[c.strip() for c in row] for row in csv.reader(text.splitlines(), delimiter=delim)]


def read_table(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return read_xlsx(path)
    if ext in (".csv", ".txt"):
        return read_csv(path)
    if ext == ".xls":
        raise ValueError("Vecais .xls formāts netiek atbalstīts. Saglabājiet failu kā .xlsx un mēģiniet vēlreiz.")
    raise ValueError("Neatbalstīts faila formāts. Izmantojiet .xlsx vai .csv.")


def normalize_gender(text):
    g = _norm(text)
    if not g:
        return ""
    if g in ("s", "f", "w") or g.startswith(("siev", "fem", "meit", "girl", "woman", "sieviesu")):
        return GENDER_FEMALE
    if g in ("v", "m") or g.startswith(("viri", "mal", "puis", "boy", "man", "zen")):
        return GENDER_MALE
    return None  # unrecognised



# --------------------------------------------------------------------------
# Kolektīva vēsture: kurš kad bijis vadītājs, repetitors, prezidents, tērpu pārzinis u. c.
# --------------------------------------------------------------------------
# role_history: one row = one period of one person in one role. Rows of people in Kopas pūrs (dancer_id set)
# are kept up to date by sync_role_history(): when a role is given (Kopas pūrs, Kabatas Pūrlāde) a period starts,
# when it is taken away (or the person has left the collective) the period ends. Earlier periods are entered by
# hand in the "Kolektīva vēsture" window; a person who is not in Kopas pūrs is stored only by name (person).
# history_entries: other events of the collective entered by hand (founded, anniversaries, tours, awards...).
ROLE_HISTORY_SCHEMA = """CREATE TABLE IF NOT EXISTS role_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dancer_id INTEGER REFERENCES dancers(id) ON DELETE SET NULL,
    person TEXT DEFAULT '',
    role TEXT NOT NULL,
    start_date TEXT DEFAULT '',
    end_date TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    auto INTEGER DEFAULT 0
)"""
HISTORY_ENTRIES_SCHEMA = """CREATE TABLE IF NOT EXISTS history_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    created TEXT DEFAULT ''
)"""
# every role of the collective and every extra app role (Kopas pūrs → Lietotnes lomas) — a new app role is
# written down in the history automatically
HISTORY_ROLES = ([ROLE_LEADER, ROLE_REPETITOR, APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER]
                 + [r for r in EXTRA_APP_ROLES if r not in (APP_ROLE_PRESIDENT, APP_ROLE_STUDIO_ELDER)])
ROLE_HISTORY_INITIAL_KEY = "role_history.initial"   # one-time: the role holders of that day were written down


def ensure_history_schema(con):
    """Create the tables role_history and history_entries (safe to run again)."""
    new = not (_has_table(con, "role_history") and _has_table(con, "history_entries"))
    if not new:
        return
    con.execute(ROLE_HISTORY_SCHEMA)
    con.execute(HISTORY_ENTRIES_SCHEMA)
    con.commit()
    if datubaze.is_online():
        # the online database keeps every table closed to the Supabase web API (row level security)
        try:
            datubaze.ensure_schema(datubaze.shared_connection())
        except Exception as exc:
            log_error(f"Kolektīva vēstures tabulu drošības iestatījumi: {exc}")


def current_role_holders(con):
    """{(dancer id, role): (full name, join date)} — who holds which role of HISTORY_ROLES now
    (people who have left the collective hold no role)."""
    holders = {}
    for did, first, last, role, stored, status, join in con.execute(
            "SELECT id, first_name, last_name, role, app_roles, status, join_date FROM dancers").fetchall():
        if (status or "").strip() == STATUS_LEFT:
            continue
        for r in app_roles_of(role, stored):
            if r in HISTORY_ROLES:
                holders[(did, r)] = (full_name(first, last), join or "")
    return holders


def sync_role_history(con, today=None):
    """Bring role_history in line with the roles in Kopas pūrs: a new role holder gets a period from today,
    a period of somebody who no longer has the role ends today. The very first time the present holders get
    a period with an unknown start (leaders and rehearsal directors: from their join date).
    Returns True when something was written."""
    ensure_history_schema(con)
    today = today or date.today().isoformat()
    first = not con.execute("SELECT 1 FROM settings WHERE key=?", (ROLE_HISTORY_INITIAL_KEY,)).fetchone()
    holders = current_role_holders(con)
    covered, changed = set(), False
    for rid, did, role, auto in con.execute(
            "SELECT id, dancer_id, role, auto FROM role_history WHERE TRIM(COALESCE(end_date,'')) = ''").fetchall():
        if did is not None and (did, role) in holders:
            covered.add((did, role))
        elif did is not None or auto:   # role taken away / person left or deleted; hand-entered names stay open
            con.execute("UPDATE role_history SET end_date=? WHERE id=?", (today, rid))
            changed = True
    for (did, role), (name, join) in sorted(holders.items()):
        if (did, role) in covered:
            continue
        if first:
            start = join if role in (ROLE_LEADER, ROLE_REPETITOR) else ""
        else:
            start = today
        con.execute("INSERT INTO role_history (dancer_id, person, role, start_date, end_date, notes, auto) "
                    "VALUES (?, ?, ?, ?, '', '', 1)", (did, name, role, start))
        changed = True
    if first:
        con.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (ROLE_HISTORY_INITIAL_KEY, today))
        changed = True
    if changed:
        con.commit()
    return changed


# Power icon used on the 'Atgriezties moduļu izvēlē' / 'Beigt darbu' buttons
POWER_ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAEYElEQVR4nJ1VXW8UZRR+znlnZ3e7xWKxEBQEobawTdQgKiDScqGJQoSgM5pUKxgjFybgD8Ds1ntj0CtDAhHB6EwQb4wXXNjeCAKNSqD2Q6garR/VtkC7sx/zvseLnV1Ll1LiezUz7zznOR/POYcwzxGAIECfv+oOk7dOsuLGYklv27h7eBQCEEFuhef5CHwPTAQJc7F1dQm1tSHFDxLzkwRIT7ZdzYe35vvhP1eESqEYottGlGG3uhTPme0hz8aI5ygRzEl7U4IIQOT6+lYODP0+ReT6mggyF0kNgQgoKpyc/6jFbZpeEZuLYHRpn/7maGun56VtIkgmU2vvxnAFhCzo/AcP150/3urd1Wh/WsfJlwFAwNV0EUQBwNPNa15outM6tqqkT53++L4l2e5akhtefN9h6oYJE1NH6pPKmcppCMy+shqNriZBSCKP9haKgmSct3Bon/C9dKytDTQzXVUC8Rzlur4+82Hrqw31yp0OjAQF029bahcBQoSq4kXKT6TVi9OB6SkUBQ316vF7c/qA60LDd7iGAK5vhg42xwF5K9RiBDKZy8n2dZ0/DM80GqEEAB7b0/8Hpos7tZGRYskYYnnzu6MPLCbX15UoGAA8D4oAGW+02uM2r2QCl0p4v/31oZGRIysSAABDIigblihFX3vLkuv3XrkaGrxNRJxKqAUFDnYAQKUJGQCamtopin1zwmbJ5Y0mNp+JgM6lUiYqbYwAAmAIsAHAnlgSioBSVuzLqcBcsywSaNpcW+SeyITIMqVAWjBBon4lgjho0wDAjFFjAMsiBuEnALg+Wi9EkBODF8eY8JtiEIjuBoAO9JoaFUEgUk4Cx8KwfOf4RgT0aNfAxYJGx8RkafvGroFTAtDW7l4NANk2h8RASWSjNoKOyhuNaANYihaGNq/MZMC+Xx52AGjTKwO9G/YMfwEABEgmU5bkhcLAUiK5xxgIgF/KSWnnKsHYWG+ZnExvkDdIxplDg87ubhhcSlcaTDwPSjxUG64NaYsIMh0Wnk/VqVQxFALhq5kRVBtCBOT7Di8Pvr+QSqi1oTbBdJG2PLF7oM/z0rbj9IeIVIQsyEfacrv7i2cPr15OttVnx2hRkJdxK1lqXu9euVoZOVUCz4NyXehzx1p2JOPq83zRGAL+NDA7H+kcPoubnNOH195vx81JAaVTSabJKb1/Y9fge+I5qjIob5iAXrWbWw4uWhjbN3k9BBNyRuSQGPK0FbtcCvImbqkVSuFZAG8QUeOCFGP8mj65oWtwV8VGTYrKAgD5nsOXLvmyrbnl3bqE2mcMwAwEBQOtZQIEQ6BFqSQjki1ygf7kHxN/7anLFwJkITPX6M1mOEm0a88ebX3OitEBCB5KxhnMZYA2QL5oAGBQa7yz/qWBQ5U6zt7Rc26iSk0EoG+Pr9kCwqZQy2qCsFL8sxE589ffuueZ/T8WMhlwdpbnt3W8GZL8v//czgonzwM7Te3UE33oAICxxQLHN/N5/S+AzQ3thXwyfQAAAABJRU5ErkJggg=="

# Home icon (gold house) on the 'Atgriezties moduļu izvēlē' buttons of the modules inside Pūrlāde
HOME_ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAEWUlEQVR42q1WX4hUVRj/fefce/fOzs7okFFib5E7f1rC7C1svfUggfS0a+qL0osvPYS+9BBMA/aoEPSQDxJEqzKz2JJIacQ0RESgSe3sPxcKepCKdF3n/8w959fDnV1dXdcKDxz4zr3f+f7/vu8A/3IxD7VK8y79WFaxCL1C5/Nwom/j+rEIZ3nUAYBrZzK5hfPZnxansgvTpeHdAHDl1E73UfflUcIlqITTZ4d3+74uua5ssRYwZKvb5uHcm3PFFZ6HyXhoLK+c2ulKUAl/Ppt5zY+pC1rLlnrLmmbb9ASIeQNytlocPihBJdzIE9nQ8mJ6v++pTwG4IrDdrh1XYv/Ujr4kInERQadrjmXH5k+Wy6NOEFQMAG7kgawIrxaHDw+4agKAK0Cz2eaB7Pj8+fTY9e/bLbuXFn9bS/iePjE7mX43CCphuTyqybVG33uQcnlUB0ElnJ1MHx309YkwJEg22qHdOzK+8O1KwiWohNfOZHLxmHyttWz1HEG9YU5mxueO9UuYIvd4QkLYL8WZUub93y7keP3zLBensjemz21/+d5qAoByn/5lYnt6cSo7uziV5e8Xc5ydzHy8gpl8HzcCQEhABJwpZU6kkvroct0YrXCn0cKuHQfnZtarlHIeTlBA+GMx+3TKwQ8En0nEtbNcM+cyY3MHVgwX5qFKOciIypweGtSH7jTCru8pr9mxsyP75nMkVN9dPlgMcCRAWC2mv0rE9Z5a07aTce23WvbLnsG+0sxsU0kBNoPMh6mkc6jWNCDEJQARcZiHEoHN5yHMQ63ZhGA3LAkRgcdIvVtvGiSG1OuEnSgUYKOkgZtSSY2by+ElESwlBvX+TrcXSgGWgEgBtnC/+YWoJ4nAVoswQzGFRtN+Y4ibqYRz4NYdswlA1FdSfvzIUr1zyW33vuj5+gNHAyT6qQHLH2WHnntWb7tZ68J1hMlNrtz6A3+JTC8h8pYS1WO3szR4aDnVueixd3lVwbY3rjYBfAYAM8X0UGQ2BASuTb2w2Qu737XaJueIhDRA/bZxXJ83FiZHXhkem/6VpCIBgrGXjlztAZhYAzQSUi6P+iSEgI0yKEoE9E17R3JIP9/qEEMx7SbijmuMNamEs83Y3qtRiEX1PbEEpFrNeiuA6/8AAYRrwNFfIYBuz1rfE9Ra5nitbt6BiHRD0kKZdXoPc7nZVVkPbXaMkO0QVoNQrivSNWay1ul9QkIpgQio+qCT/9RNJdomCCohHHVbojCu5YmYakEEwJ4IoNaJgPOAcBHphDQEnqoW06fRxdaOphUQnnKOez7qINhoWZJ8u1pM7yGQaXWsIakeqQCAjg0o3XTtE5uTzluhARqtKNSbE3qvEqDWNCCBVNLZ5bmya7lu4bkKgPEAoFS6GzK5b5BzvpR+0fPVSdPjk11DK4AiRPcBaSAgKQ4kOpOwWokaGJB6o23fGxmfv0zmlUjBbjyLufE4/b+8WO0z//VxQMh6z5l/ALYAPJMQFmjoAAAAAElFTkSuQmCC"



# --------------------------------------------------------------------------
# Datuma izvēle no kalendāra (poga 📅 blakus datuma laukam) — Notikumu pūrs, Cītības pūrs
# --------------------------------------------------------------------------
PICKER_MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts",
                 "Septembris", "Oktobris", "Novembris", "Decembris"]
PICKER_WEEKDAYS = ["P", "O", "T", "C", "Pk", "S", "Sv"]


def open_date_picker(anchor, var, on_pick=None, fallback_var=None):
    """A small month calendar under `anchor`; clicking a day writes it into `var` as DD.MM.GGGG.
    The month shown is the one of the date already in the field (else the date in `fallback_var`, else today).
    Esc / click elsewhere closes it."""
    import calendar as _cal
    import tkinter as tk

    top = anchor.winfo_toplevel()
    previous_grab = top.grab_current()
    current = parse_date(var.get() if var is not None else "") or ""
    try:
        chosen = date.fromisoformat(current) if current else None
    except ValueError:
        chosen = None
    today = date.today()
    start = chosen
    if start is None and fallback_var is not None:   # e.g. "repeat until": start at the event's own month
        try:
            start = date.fromisoformat(parse_date(fallback_var.get()) or "")
        except ValueError:
            start = None
    start = start or today
    shown = [start.year, start.month]

    win = tk.Toplevel(top)
    win.withdraw()
    win.overrideredirect(True)
    win.configure(bg=GOLD, padx=2, pady=2)
    body = tk.Frame(win, bg=WHITE, padx=8, pady=6)
    body.pack(fill="both", expand=True)

    def close(_e=None):
        if not win.winfo_exists():
            return
        try:
            win.grab_release()
        except tk.TclError:
            pass
        win.destroy()
        if previous_grab is not None:
            try:
                previous_grab.grab_set()
            except tk.TclError:
                pass
        try:
            anchor.focus_set()
        except tk.TclError:
            pass

    def pick(day):
        if var is not None:
            var.set(day.strftime("%d.%m.%Y"))
        close()
        if on_pick:
            on_pick()

    head = tk.Frame(body, bg=WHITE)
    head.pack(fill="x")
    title = tk.Label(head, text="", bg=WHITE, fg=RED, font=("Georgia", 11, "bold"), width=15)
    grid = tk.Frame(body, bg=WHITE)
    grid.pack(pady=(4, 2))

    def nav(text, months):
        def go():
            y, m = shown
            m += months
            y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
            shown[:] = [y, m]
            draw()
        return tk.Button(head, text=text, command=go, bg=WHITE, fg=NAVY, relief="flat", bd=0, cursor="hand2",
                         activebackground=CREAM_DARK, font=("Segoe UI", 10, "bold"), padx=4)
    nav("«", -12).pack(side="left")
    nav("‹", -1).pack(side="left")
    nav("»", 12).pack(side="right")
    nav("›", 1).pack(side="right")
    title.pack(side="left", expand=True)

    def draw():
        for w in grid.winfo_children():
            w.destroy()
        y, m = shown
        title.configure(text=f"{PICKER_MONTHS[m - 1]} {y}")
        for c, name in enumerate(PICKER_WEEKDAYS):
            tk.Label(grid, text=name, bg=WHITE, fg=RED if c >= 5 else NAVY, font=("Segoe UI", 8, "bold"),
                     width=3).grid(row=0, column=c, pady=(0, 2))
        for r, week in enumerate(_cal.monthcalendar(y, m), 1):
            for c, d in enumerate(week):
                if not d:
                    tk.Label(grid, text="", bg=WHITE, width=3).grid(row=r, column=c)
                    continue
                day = date(y, m, d)
                selected, is_today = day == chosen, day == today
                b = tk.Button(grid, text=str(d), width=3, relief="flat", bd=0, cursor="hand2",
                              bg=RED if selected else (CREAM_DARK if is_today else WHITE),
                              fg=WHITE if selected else (RED if c >= 5 else NAVY),
                              activebackground=GOLD, activeforeground=NAVY,
                              font=("Segoe UI", 9, "bold" if (selected or is_today) else "normal"),
                              highlightthickness=1 if is_today else 0, highlightbackground=GOLD,
                              command=lambda dd=day: pick(dd))
                b.grid(row=r, column=c, padx=1, pady=1)

    foot = tk.Frame(body, bg=WHITE)
    foot.pack(fill="x", pady=(4, 0))
    tk.Button(foot, text="Šodien", command=lambda: pick(today), bg=CREAM_DARK, fg=NAVY, relief="flat", bd=0,
              cursor="hand2", activebackground=GOLD, font=("Segoe UI", 9), padx=8).pack(side="left")
    tk.Button(foot, text="Aizvērt", command=close, bg=WHITE, fg=GREY, relief="flat", bd=0, cursor="hand2",
              activebackground=CREAM_DARK, font=("Segoe UI", 9), padx=8).pack(side="right")
    draw()

    win.update_idletasks()
    x = anchor.winfo_rootx()
    y = anchor.winfo_rooty() + anchor.winfo_height() + 2
    w, h = win.winfo_reqwidth(), win.winfo_reqheight()
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    if y + h > sh - 40:   # not enough room below: open above the field
        y = max(0, anchor.winfo_rooty() - h - 2)
    win.geometry(f"+{max(0, min(x, sw - w - 4))}+{y}")
    win.deiconify()
    win.lift()
    win.bind("<Escape>", close)
    body.bind("<Escape>", close)

    def click_outside(e):
        if not (win.winfo_rootx() <= e.x_root < win.winfo_rootx() + win.winfo_width()
                and win.winfo_rooty() <= e.y_root < win.winfo_rooty() + win.winfo_height()):
            close()
    win.bind("<Button-1>", click_outside, add="+")
    try:
        win.grab_set()   # clicks elsewhere come here and close the calendar
    except tk.TclError:
        pass
    win.focus_force()
    return win


def date_picker_button(parent, var, on_pick=None, bg=None, fallback_var=None):
    """The 📅 button next to a date field: opens open_date_picker() under itself."""
    import tkinter as tk
    btn = tk.Button(parent, text="📅", bg=bg or CREAM, fg=NAVY, relief="flat", bd=0, cursor="hand2",
                    activebackground=GOLD, font=("Segoe UI Emoji", 10), padx=3, pady=0)
    btn.configure(command=lambda: open_date_picker(btn, var, on_pick, fallback_var))
    return btn


# --------------------------------------------------------------------------
# Dzimšanas un vārda dienas (lietotnes loma “Sveicējs”)
# --------------------------------------------------------------------------
CELEBRATE_BIRTHDAY = "Dzimšanas diena"
CELEBRATE_NAME_DAY = "Vārda diena"


def _birthday_in(birth, year):
    """The birthday in `year` (29 February -> 28 February in other years); None when the date is unknown."""
    try:
        b = date.fromisoformat(birth or "")
    except ValueError:
        return None
    try:
        return b.replace(year=year)
    except ValueError:
        return date(year, 2, 28)


def celebrations(con, start, days):
    """Birthdays and name days of everyone in the collective who has not left (dancers, leaders, repetitors)
    from `start` (date) for `days` days: [{date, kind, dancer_id, name, age, group, role, contact, note}],
    sorted by date and name. A first name that is in no calendar gets the day of unusual names (22 May)."""
    try:
        from moduli import vardadienas
    except ImportError:
        try:
            import vardadienas
        except ImportError:
            vardadienas = None
    end = start + timedelta(days=days - 1)
    result = []
    rows = con.execute("SELECT id, first_name, last_name, birth_date, role, dancer_group, contact, status "
                       "FROM dancers").fetchall()
    for did, first, last, birth, role, group, contact, status in rows:
        if (status or "").strip() == STATUS_LEFT:
            continue
        person = {"dancer_id": did, "name": full_name(first, last), "group": (group or "").strip(),
                  "role": (role or "").strip() or ROLE_DANCER, "contact": (contact or "").strip()}
        for year in range(start.year, end.year + 1):
            day = _birthday_in(birth, year)
            if day and start <= day <= end:
                result.append(dict(person, date=day, kind=CELEBRATE_BIRTHDAY,
                                   age=year - date.fromisoformat(birth).year, note=""))
        if vardadienas is None or not (first or "").strip():
            continue
        name_days = vardadienas.name_days(first)
        unusual = not name_days
        for mm_dd in (name_days or [vardadienas.UNUSUAL_DAY]):
            month, dd = (int(x) for x in mm_dd.split("-"))
            for year in range(start.year, end.year + 1):
                day = date(year, month, dd)
                if start <= day <= end:
                    result.append(dict(person, date=day, kind=CELEBRATE_NAME_DAY, age=None,
                                       note="neparasto vārdu diena (vārds nav kalendārā)" if unusual else ""))
    result.sort(key=lambda c: (c["date"], c["kind"], _norm(c["name"])))
    return result


# --------------------------------------------------------------------------
# Kolonnu izvēle visās tabulās (labais peles taustiņš uz kolonnas nosaukuma) — moduli/kolonnas.py
# --------------------------------------------------------------------------
try:
    import tkinter as _tk  # noqa: F401  (the Kabatas Pūrlāde server may run without tkinter)
    try:
        from moduli import kolonnas as _kolonnas
    except ImportError:
        import kolonnas as _kolonnas
    _kolonnas.install()
except Exception:   # no tkinter / no file (cloud server): nothing to do
    pass
