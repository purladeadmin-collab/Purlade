#!/usr/bin/env python3
"""
Pūrlāde — modulis "Notikumu pūrs" (koncertu, skašu un citu pasākumu plānošana un uzskaite)

Notikumu pūrs izmanto TOS PAŠUS notikumus, ko Cītības pūrs (tabula attendance_sessions):
koncerts, kas izveidots šeit, uzreiz redzams Cītības pūrā apmeklējuma atzīmēšanai, un
koncerts vai skate, kas ievadīta Cītības pūrā, redzama šeit. Notikumu pūrs katram notikumam
pievieno plānošanas informāciju:
    statuss (Iecerēts / Apstiprināts / Atcelts), vieta, adrese, ierašanās un beigu laiks,
    organizators, kontaktpersona, transports, honorārs, tērpu piezīmes,
    autobusa cena (ja transports — autobuss: to maksā dejotāji, kuri dejo, un tie, kas atzīmēti “brauks”;
    Kabatas Pūrlādē redzams līdz samaksai, samaksu reģistrē Zelta pūrā),
    programma (dejas no Deju pūra noteiktā secībā) un dejotāju dalība (Būs / Varbūt / Nebūs).
Programmas dejas tiek ierakstītas arī Cītības pūra notikuma dejās, tāpēc Deju pūrs redz,
cik reižu deja dejota koncertos un skatēs.
Kolektīva pasākumam ir apakšveids (Saliedēšanās, Puišu, Meiteņu, Publicitātes pasākums) un nav deju;
publicitātes pasākumam izvēlas uzaicinātos dejotājus — tikai viņi to redz Kabatas Pūrlādē un saņem paziņojumus.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/notikumu_purs.py
"""

import calendar
import csv
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import date, timedelta
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible,
                               ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                               STATUS_ACTIVE, GENDERS, POWER_ICON_B64, HOME_ICON_B64,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
    from moduli.kopeja import (EVENT_SUBKINDS, SUBKIND_PUBLICITY, ensure_event_detail_columns, invited_ids,
                               invited_text, DANCER_GROUPS, DEFAULT_DANCER_GROUP, event_groups, event_groups_text,
                               groups_label, in_event_groups, event_costume_types)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible,
                        ensure_dancer_schema, full_name, parse_date, active_dancer_sql, dancer_role_sql, _norm,
                        STATUS_ACTIVE, GENDERS, POWER_ICON_B64, HOME_ICON_B64,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
    from kopeja import EVENT_SUBKINDS, SUBKIND_PUBLICITY, ensure_event_detail_columns, invited_ids, invited_text
    from kopeja import (DANCER_GROUPS, DEFAULT_DANCER_GROUP, event_groups, event_groups_text, groups_label,
                        in_event_groups, event_costume_types)

try:  # started from Pūrlāde
    from moduli.kopeja import dance_lineup, date_picker_button
    from moduli.kopeja import (TRANSPORT_BUS, TRANSPORT_KINDS, BUS_YES, BUS_NO, BUS_REASON_DANCES, guess_transport_kind,
                               bus_cents, euro_text, parse_euro, bus_payers_from, bus_paid)
except ImportError:  # started directly from the moduli folder
    from kopeja import dance_lineup, date_picker_button
    from kopeja import (TRANSPORT_BUS, TRANSPORT_KINDS, BUS_YES, BUS_NO, BUS_REASON_DANCES, guess_transport_kind,
                        bus_cents, euro_text, parse_euro, bus_payers_from, bus_paid)

PROGRAM_NAME = "Notikumu pūrs"
APP_VERSION = "0.2.6"
PURPLE = "#7A5C99"
AMBER = "#B07D00"
ALL = "Visi"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Koncertu, skašu un citu pasākumu uzskaite un plānošana",
    "letter": "N",
    "color": PURPLE,
}

# ---- choices --------------------------------------------------------------
# event kinds shared with Cītības pūrs (rehearsals stay in Cītības pūrs)
KIND_REHEARSAL = "Mēģinājums"
KIND_EXTRA = "Papildmēģinājums"
KIND_CONCERT = "Koncerts"
KIND_REVIEW = "Skate"
KIND_EVENT = "Kolektīva pasākums"
EVENT_KINDS = [KIND_CONCERT, KIND_REVIEW, KIND_EVENT]
REHEARSAL_KINDS = (KIND_REHEARSAL, KIND_EXTRA)
KIND_COLOUR = {KIND_CONCERT: RED, KIND_REVIEW: AMBER, KIND_EVENT: GREEN, KIND_REHEARSAL: GREY, KIND_EXTRA: GREY}
KIND_TINT = {KIND_CONCERT: "#F6D5DA", KIND_REVIEW: "#F6E3B0", KIND_EVENT: "#CDE8D5",
             KIND_REHEARSAL: "#ECECEC", KIND_EXTRA: "#ECECEC"}

# statuses kept in the database
ST_PLANNED = "Iecerēts"
ST_CONFIRMED = "Apstiprināts"
ST_CANCELLED = "Atcelts"
STATUSES = [ST_PLANNED, ST_CONFIRMED, ST_CANCELLED]
# shown instead of Iecerēts / Apstiprināts once the day has passed
ST_DONE = "Noticis"
SHOWN_STATUSES = [ST_PLANNED, ST_CONFIRMED, ST_DONE, ST_CANCELLED]
STATUS_TAG = {ST_PLANNED: "planned", ST_CONFIRMED: "confirmed", ST_DONE: "done", ST_CANCELLED: "cancelled"}

# dancer answers
ANS_YES = "Būs"
ANS_MAYBE = "Varbūt"
ANS_NO = "Nebūs"
ANSWERS = [ANS_YES, ANS_MAYBE, ANS_NO]
ANS_CYCLE = ["", ANS_YES, ANS_MAYBE, ANS_NO]
ANS_TAG = {ANS_YES: "yes", ANS_MAYBE: "maybe", ANS_NO: "no", "": "unknown"}

# attendance marks of Cītības pūrs
CAME = ("Ieradās", "Nokavēja")

# dance statuses of Deju pūrs (in the order they are offered when choosing dances)
DANCE_LEARNING = "Procesā"
DANCE_IN_REPERTOIRE = "Repertuārā"
DANCE_RESTING = "Atpūtā"
DANCE_ARCHIVED = "Arhīvā"
DANCE_GROUPS = [DANCE_IN_REPERTOIRE, DANCE_LEARNING, DANCE_RESTING, DANCE_ARCHIVED]

MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts",
          "Septembris", "Oktobris", "Novembris", "Decembris"]
WEEKDAYS = ["Pirmd.", "Otrd.", "Trešd.", "Ceturtd.", "Piektd.", "Sestd.", "Svētd."]
WEEKDAYS_FULL = ["Pirmdiena", "Otrdiena", "Trešdiena", "Ceturtdiena", "Piektdiena", "Sestdiena", "Svētdiena"]

# repeating events (only when a new event is created)
REPEAT_WEEKDAYS = "weekdays"
REPEAT_DATES = "dates"
EVERY_WEEK = "katru nedēļu"
EVERY_2_WEEKS = "katru otro nedēļu"
EVERY_CHOICES = [EVERY_WEEK, EVERY_2_WEEKS]
MAX_REPEATS = 200

PERIOD_UPCOMING = "Gaidāmie"
PERIOD_SEASON = "Šī sezona"
PERIOD_LAST_SEASON = "Iepriekšējā sezona"
PERIOD_MONTH = "Šis mēnesis"
PERIOD_YEAR = "Šis gads"
PERIOD_ALL = "Viss laiks"
PERIOD_CUSTOM = "Cits periods"
PERIODS = [PERIOD_UPCOMING, PERIOD_SEASON, PERIOD_LAST_SEASON, PERIOD_MONTH, PERIOD_YEAR, PERIOD_ALL,
           PERIOD_CUSTOM]

EVENT_COLUMNS = [
    ("date", "Datums", 95),
    ("weekday", "Diena", 65),
    ("time", "Laiks", 55),
    ("kind", "Veids", 130),
    ("groups", "Grupa", 80),
    ("title", "Nosaukums", 190),
    ("place", "Vieta", 160),
    ("status", "Statuss", 105),
    ("program", "Programma", 120),
    ("people", "Dalībnieki", 120),
]

PEOPLE_COLUMNS = [
    ("first_name", "Vārds", 110),
    ("last_name", "Uzvārds", 130),
    ("status", "Statuss", 85),
    ("concerts", "Koncertos", 85),
    ("reviews", "Skatēs", 70),
    ("events", "Pasākumos", 85),
    ("total", "Kopā piedalījās", 115),
    ("upcoming", "Gaidāmie", 85),
    ("declined", "Atteikumi", 85),
]

# costume type categories in Tērpu pūrs (as in Deju pūrs): which types are offered for each gender
COSTUME_CATEGORY = {GENDERS[0]: "Puišu tērpi", GENDERS[1]: "Meiteņu tērpi"}
COSTUME_TITLE = {GENDERS[0]: "Vīriešiem (puišu tērpu veidi)", GENDERS[1]: "Sievietēm (meiteņu tērpu veidi)"}

# participants of a publicity event: sorting (Dalībnieki tab)
PEOPLE_SORT_LAST = "Uzvārds"
PEOPLE_SORT_FIRST = "Vārds"
PEOPLE_SORT_GROUP = "Grupa"
PEOPLE_SORT_INVITED = "Uzaicinātie vispirms"
PEOPLE_SORT_ANSWER = "Atbilde"
PEOPLE_SORTS = [PEOPLE_SORT_LAST, PEOPLE_SORT_FIRST, PEOPLE_SORT_GROUP, PEOPLE_SORT_INVITED, PEOPLE_SORT_ANSWER]
# which sort a click on a column heading chooses
PEOPLE_HEADING_SORT = {"name": PEOPLE_SORT_LAST, "group": PEOPLE_SORT_GROUP, "dances": PEOPLE_SORT_INVITED,
                       "answer": PEOPLE_SORT_ANSWER}

DETAIL_FIELDS = ["status", "place", "address", "arrival_time", "end_time", "organizer", "contact", "transport",
                 "fee", "costume_notes", "subkind", "invited", "for_groups", "transport_kind", "bus_price",
                 "costume_issue_date", "costume_return_date"]
# costume_issue_date / costume_return_date: kad tērpus izsniedz un kad tie jāatgriež ('GGGG-MM-DD')
DATE_FIELDS = ("costume_issue_date", "costume_return_date")
# transport_kind: Autobuss / Savs transports / …; bus_price: autobusa cena vienam dejotājam centos ('1250')
# for_groups: which dancer groups (A, Studija, VPDK) the event is for, 'A,Studija'; empty — all groups
# subkind: apakšveids (only for "Kolektīva pasākums"; such events have no dances);
# invited: '3,7,12' — the dancers invited to a "Publicitātes pasākums" (only they see it and get notifications)


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attendance_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_date TEXT NOT NULL,
    kind TEXT DEFAULT '',
    title TEXT DEFAULT '',
    start_time TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    mark TEXT NOT NULL,
    note TEXT DEFAULT '',
    UNIQUE (session_id, dancer_id)
);
CREATE TABLE IF NOT EXISTS session_dances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dance_id INTEGER NOT NULL REFERENCES dances(id) ON DELETE CASCADE,
    UNIQUE (session_id, dance_id)
);
CREATE TABLE IF NOT EXISTS event_details (
    session_id INTEGER PRIMARY KEY REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    status TEXT DEFAULT '',
    place TEXT DEFAULT '',
    address TEXT DEFAULT '',
    arrival_time TEXT DEFAULT '',
    end_time TEXT DEFAULT '',
    organizer TEXT DEFAULT '',
    contact TEXT DEFAULT '',
    transport TEXT DEFAULT '',
    fee TEXT DEFAULT '',
    costume_notes TEXT DEFAULT '',
    subkind TEXT DEFAULT '',
    invited TEXT DEFAULT '',
    for_groups TEXT DEFAULT '',
    transport_kind TEXT DEFAULT '',
    bus_price TEXT DEFAULT '',
    costume_issue_date TEXT DEFAULT '',
    costume_return_date TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS event_program (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dance_id INTEGER NOT NULL,
    position INTEGER DEFAULT 0,
    UNIQUE (session_id, dance_id)
);
CREATE TABLE IF NOT EXISTS event_participants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    answer TEXT DEFAULT '',
    note TEXT DEFAULT '',
    UNIQUE (session_id, dancer_id)
);
CREATE INDEX IF NOT EXISTS idx_sessions_date ON attendance_sessions(session_date);
"""


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        ensure_dancer_schema(self.con)
        self.con.executescript(SCHEMA)
        ensure_event_detail_columns(self.con)   # older databases: subkind, invited
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def has_table(self, name):
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)))

    # ---- events -------------------------------------------------------------
    def events(self, start="0000-01-01", end="9999-12-31", kinds=EVENT_KINDS):
        """[dict] events (sessions of the given kinds) with their details."""
        kinds = list(kinds)
        rows = self.q("SELECT s.id, s.session_date, s.kind, s.title, s.start_time, s.notes, "
                      + ", ".join(f"COALESCE(e.{f}, '')" for f in DETAIL_FIELDS) +
                      " FROM attendance_sessions s LEFT JOIN event_details e ON e.session_id = s.id "
                      "WHERE s.session_date BETWEEN ? AND ? AND s.kind IN (" + ",".join("?" * len(kinds)) + ")",
                      [start, end] + kinds)
        result = []
        for r in rows:
            ev = {"id": r[0], "date": r[1], "kind": r[2] or "", "title": r[3] or "", "time": r[4] or "",
                  "notes": r[5] or ""}
            ev.update(zip(DETAIL_FIELDS, r[6:]))
            if ev["status"] not in STATUSES:
                ev["status"] = ST_CONFIRMED  # entered in Cītības pūrs, no details yet
            ev["shown_status"] = shown_status(ev["status"], ev["date"])
            result.append(ev)
        return result

    def programs(self, session_ids):
        """{session id: [(dance id, title, duration seconds text)]} in programme order."""
        ids = list(session_ids)
        if not ids or not self.has_table("dances"):
            return {}
        rows = self.q("SELECT sd.session_id, d.id, d.title, d.duration, p.position FROM session_dances sd "
                      "JOIN dances d ON d.id = sd.dance_id "
                      "LEFT JOIN event_program p ON p.session_id = sd.session_id AND p.dance_id = sd.dance_id "
                      "WHERE sd.session_id IN (" + ",".join("?" * len(ids)) + ")", ids)
        result = {}
        for sid, did, title, duration, position in rows:
            result.setdefault(sid, []).append((10 ** 6 if position is None else position, _norm(title),
                                               did, title or "", duration or ""))
        return {sid: [(r[2], r[3], r[4]) for r in sorted(items)] for sid, items in result.items()}

    def answers(self, session_ids):
        """{session id: {dancer id: (answer, note)}}."""
        ids = list(session_ids)
        if not ids:
            return {}
        result = {}
        for sid, did, ans, note in self.q("SELECT session_id, dancer_id, answer, note FROM event_participants "
                                          "WHERE session_id IN (" + ",".join("?" * len(ids)) + ")", ids):
            result.setdefault(sid, {})[did] = (ans or "", note or "")
        return result

    def bus_marks(self, session_id):
        """{dancer id: '1' (brauks ar autobusu) / '0' (nebrauks)}."""
        return {did: m for did, m in self.q("SELECT dancer_id, COALESCE(bus,'') FROM event_participants "
                                             "WHERE session_id=?", (session_id,)) if m}

    def marks(self, session_ids):
        """{session id: {dancer id: mark}} from Cītības pūrs."""
        ids = list(session_ids)
        if not ids:
            return {}
        result = {}
        for sid, did, mark in self.q("SELECT session_id, dancer_id, mark FROM attendance WHERE session_id IN ("
                                     + ",".join("?" * len(ids)) + ")", ids):
            result.setdefault(sid, {})[did] = mark
        return result

    # ---- dances (Deju pūrs) --------------------------------------------------
    def all_dances(self):
        """{id: dict(title, status, duration, type, costume_set)} from Deju pūrs."""
        if not self.has_table("dances"):
            return {}
        result = {}
        for i, t, st, dur, typ, cs in self.q("SELECT id, title, status, duration, dance_type, costume_set "
                                             "FROM dances"):
            result[i] = {"title": t or "", "status": st or DANCE_IN_REPERTOIRE, "duration": dur or "",
                         "type": typ or "", "costume_set": cs or ""}
        return result

    def cast_map(self, dance_ids=None):
        """{dance id: set(dancer ids)} — dance casts from Deju pūrs."""
        if not self.has_table("dance_cast"):
            return {}
        sql, params = "SELECT dance_id, dancer_id FROM dance_cast", []
        if dance_ids is not None:
            ids = list(dance_ids)
            if not ids:
                return {}
            sql += " WHERE dance_id IN (" + ",".join("?" * len(ids)) + ")"
            params = ids
        result = {}
        for did, dancer in self.q(sql, params):
            result.setdefault(did, set()).add(dancer)
        return result

    def costume_map(self, dance_ids):
        """{dance id: {gender: [costume types]}} from Deju pūrs."""
        ids = list(dance_ids)
        if not ids or not self.has_table("dance_costumes"):
            return {}
        result = {}
        for did, gender, name in self.q("SELECT dance_id, gender, type_name FROM dance_costumes WHERE dance_id IN ("
                                        + ",".join("?" * len(ids)) + ") ORDER BY id", ids):
            result.setdefault(did, {}).setdefault(gender, []).append(name)
        return result

    def dancer_groups(self):
        """{dancer id: group (A, Studija, VPDK)} from Kopas pūrs."""
        if "dancer_group" not in {c[1] for c in self.q("PRAGMA table_info(dancers)")}:
            return {}
        return {i: (g or "") for i, g in self.q("SELECT id, dancer_group FROM dancers")}

    def costume_types_for(self, gender):
        """Costume types offered for a gender: types of Tērpu pūrs with the category "Puišu tērpi" /
        "Meiteņu tērpi" (an older database without categories: all types)."""
        try:
            rows = self.q("SELECT name FROM piece_types WHERE category=?", (COSTUME_CATEGORY[gender],))
        except sqlite3.Error:
            rows = []
            for sql in ("SELECT name FROM piece_types", "SELECT DISTINCT type FROM costume_pieces"):
                try:
                    rows += self.q(sql)
                except sqlite3.Error:
                    pass
        return sorted({r[0] for r in rows if (r[0] or "").strip()}, key=_norm)

    # ---- dancers (Kopas pūrs) ------------------------------------------------
    def dancers(self, include_ids=()):
        """[(id, first, last, gender, status)] active dancers + the given ones, sorted by name."""
        ids = list(include_ids)
        extra = (" OR id IN (" + ",".join("?" * len(ids)) + ")") if ids else ""
        rows = self.q("SELECT id, first_name, last_name, gender, status FROM dancers WHERE "
                      + active_dancer_sql("dancers") + extra, ids)
        rows.sort(key=lambda r: (_norm(r[2]), _norm(r[1])))
        return rows


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def weekday(iso, full=False):
    try:
        return (WEEKDAYS_FULL if full else WEEKDAYS)[date.fromisoformat(iso).weekday()]
    except (TypeError, ValueError):
        return ""


def parse_time(text):
    """'18', '18:30', '18.30', '1830' -> '18:30'; '' when empty; None when bad."""
    text = (text or "").strip()
    if not text:
        return ""
    m = re.fullmatch(r"(\d{1,2})(?:[:.\s]?(\d{2}))?", text)
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2) or 0)
    return f"{h:02d}:{mi:02d}" if h < 24 and mi < 60 else None


def show_duration(seconds):
    try:
        s = int(seconds)
    except (TypeError, ValueError):
        return ""
    return f"{s // 60}:{s % 60:02d}"


def show_total(seconds):
    if not seconds:
        return "0 min"
    h, rest = divmod(int(seconds), 3600)
    m = round(rest / 60)
    if m == 60:
        h, m = h + 1, 0
    return f"{h} h {m} min" if h else f"{m} min"


def program_seconds(program):
    """(total seconds, number of dances without a duration)."""
    total, missing = 0, 0
    for _did, _title, dur in program:
        if str(dur).isdigit():
            total += int(dur)
        else:
            missing += 1
    return total, missing


def shown_status(status, iso):
    if status == ST_CANCELLED:
        return ST_CANCELLED
    if iso and iso < date.today().isoformat():
        return ST_DONE
    return status or ST_CONFIRMED


def days_until_text(iso):
    try:
        n = (date.fromisoformat(iso) - date.today()).days
    except (TypeError, ValueError):
        return ""
    if n == 0:
        return "šodien"
    if n == 1:
        return "rīt"
    if n == 2:
        return "parīt"
    return f"pēc {n} d."


def season_of(day):
    """Dance season runs from 1 September to 31 August."""
    start_year = day.year if day.month >= 9 else day.year - 1
    return date(start_year, 9, 1), date(start_year + 1, 8, 31)


def period_dates(name, today=None):
    today = today or date.today()
    if name == PERIOD_UPCOMING:
        return today, None
    if name == PERIOD_SEASON:
        return season_of(today)
    if name == PERIOD_LAST_SEASON:
        s, _e = season_of(today)
        return date(s.year - 1, 9, 1), date(s.year, 8, 31)
    if name == PERIOD_MONTH:
        return today.replace(day=1), today.replace(day=calendar.monthrange(today.year, today.month)[1])
    if name == PERIOD_YEAR:
        return date(today.year, 1, 1), date(today.year, 12, 31)
    return None, None  # Viss laiks


def sort_rows(rows, key, desc):
    """Stable sort by one column; empty values (None, '') always stay at the bottom."""
    filled = [r for r in rows if r[key] not in (None, "")]
    empty = [r for r in rows if r[key] in (None, "")]
    filled.sort(key=lambda r: r[key] if isinstance(r[key], int) else _norm(r[key]), reverse=desc)
    return filled + empty


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def status_colours(tree):
    tree.tag_configure("planned", foreground=AMBER)
    tree.tag_configure("confirmed", foreground=GREEN)
    tree.tag_configure("done", foreground=GREY)
    tree.tag_configure("cancelled", foreground=RED)


def answer_colours(tree):
    tree.tag_configure("yes", background="#CDE8D5")
    tree.tag_configure("maybe", background="#F6E3B0")
    tree.tag_configure("no", background="#F2C4CB")
    tree.tag_configure("unknown", background=WHITE)


def scrollable(parent):
    """(canvas, inner frame) — a vertically scrolling area."""
    box = tk.Frame(parent, bg=WHITE, highlightthickness=1, highlightbackground=GOLD)
    canvas = tk.Canvas(box, bg=WHITE, highlightthickness=0)
    sb = ttk.Scrollbar(box, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    inner = tk.Frame(canvas, bg=WHITE)
    win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
    inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))
    return box, canvas, inner


def bind_wheel(win, canvas):
    win.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                           "units"))
    win.bind("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))
    win.bind("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))


def is_group_event(ev):
    """Kolektīva pasākums: has a sub-kind and no dances."""
    return ev.get("kind") == KIND_EVENT


def is_publicity_event(ev):
    return is_group_event(ev) and ev.get("subkind") == SUBKIND_PUBLICITY


def kind_text(ev):
    """'Puišu pasākums' instead of 'Kolektīva pasākums' when the sub-kind is known."""
    return (ev.get("subkind") or ev.get("kind") or "") if is_group_event(ev) else (ev.get("kind") or "")


def event_audience(ev, cast, active_ids, group_of=None):
    """Dancers the event is meant for: publicity — the invited ones; other collective events — the active
    dancers of the event's groups; concerts, reviews — the cast of the programme."""
    if is_publicity_event(ev):
        return invited_ids(ev.get("invited"))
    if is_group_event(ev):
        group_of = group_of or {}
        return {d for d in active_ids if in_event_groups(group_of.get(d, ""), ev.get("for_groups", ""))}
    return set(cast)


def groups_short(text):
    label = groups_label(text)
    return "visas" if label == "visas grupas" else label


def info_text(ev, program, costumes, event_costumes=None):
    """A message for the dancers (to paste into WhatsApp, e-mail …). event_costumes: {gender: [types]} of a
    publicity event (it has no dances)."""
    lines = []
    head = kind_text(ev) + (f" “{ev['title']}”" if ev["title"] else "")
    if ev["status"] == ST_CANCELLED:
        head = "ATCELTS: " + head
    lines.append(head)
    when = f"{weekday(ev['date'], full=True)}, {show_date(ev['date'])}"
    if ev["time"]:
        when += f", sākums {ev['time']}"
    if ev["end_time"]:
        when += f", beigas ~{ev['end_time']}"
    lines.append("📅 " + when)
    if ev["arrival_time"]:
        lines.append(f"⏰ Ierašanās: {ev['arrival_time']}")
    place = ", ".join(p for p in (ev["place"], ev["address"]) if p)
    if place:
        lines.append(f"📍 Vieta: {place}")
    tkind = guess_transport_kind(ev.get("transport_kind", ""), ev["transport"])
    text = ev["transport"] or ""
    transport = text if tkind and tkind.lower() in text.lower() else " — ".join(t for t in (tkind, text) if t)
    if transport:
        lines.append(f"🚌 Transports: {transport}")
    if tkind == TRANSPORT_BUS and bus_cents(ev.get("bus_price")):
        lines.append(f"💶 Autobuss: {euro_text(bus_cents(ev['bus_price']))} no dejotāja (samaksa — kasierim)")
    costume_lines = []
    for gender in GENDERS:
        names = list((event_costumes or {}).get(gender, []))
        for did, _t, _d in program:
            for n in costumes.get(did, {}).get(gender, []):
                if n not in names:
                    names.append(n)
        if names:
            costume_lines.append(f"{'Vīriešiem' if gender == GENDERS[0] else 'Sievietēm'}: {', '.join(names)}")
    if costume_lines or ev["costume_notes"]:
        lines.append("👗 Tērpi: " + "; ".join(costume_lines + ([ev["costume_notes"]] if ev["costume_notes"] else [])))
    issue, back = ev.get("costume_issue_date", ""), ev.get("costume_return_date", "")
    if issue or back:
        lines.append("👗 " + "; ".join(t for t in (
            f"tērpu izsniegšana: {weekday(issue, full=True).lower()}, {show_date(issue)}" if issue else "",
            f"tērpi jāatgriež līdz: {weekday(back, full=True).lower()}, {show_date(back)}" if back else "") if t))
    if program:
        lines.append("")
        lines.append("Programma:")
        for i, (_did, title, dur) in enumerate(program, 1):
            lines.append(f"{i}. {title}" + (f" ({show_duration(dur)})" if str(dur).isdigit() else ""))
    if ev["notes"]:
        lines.append("")
        lines.append(ev["notes"])
    if ev["contact"]:
        lines.append("")
        lines.append(f"Kontaktpersona: {ev['contact']}")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# One event: details, programme and participants
# --------------------------------------------------------------------------
class EventWindow(tk.Toplevel):
    def __init__(self, app, session_id=None, day=None, on_saved=None):
        super().__init__(app.root)
        self.app, self.db, self.session_id, self.on_saved = app, app.db, session_id, on_saved
        acc = piekluve.current()
        self.locked = False   # lietotāju lomas: answers / invitations cannot be changed
        if session_id is None and not (acc.can_edit("notikumu_purs") or acc.social):
            self.withdraw()
            piekluve.deny(app.root, "Jūsu loma nevar izveidot notikumus.")
            self.destroy()
            return
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title("Jauns notikums" if session_id is None else "Notikums")
        self.geometry("1000x760")
        self.transient(app.root)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.changed = False
        self.loading = True
        self.dance_info = self.db.all_dances()
        self.program = []        # dance ids in order
        self.answers = {}        # dancer id -> [answer, note]
        self.invited = set()     # Publicitātes pasākums: invited dancer ids
        self.event_costumes = {g: [] for g in GENDERS}   # Publicitātes pasākums: costume types per gender
        self.marks = {}
        self.dancer_rows = {r[0]: r for r in self.db.q("SELECT id, first_name, last_name, gender, status "
                                                        "FROM dancers")}
        # Kopas pūrs "Grupa" (A, Studija, VPDK) — for searching and sorting the participants
        self.dancer_group = {r[0]: (r[1] or "") for r in self.db.q("SELECT id, dancer_group FROM dancers")} \
            if "dancer_group" in {c[1] for c in self.db.q("PRAGMA table_info(dancers)")} else {}
        self.people_sort, self.people_desc = PEOPLE_SORT_LAST, False

        self.heading = tk.Label(self, text="Jauns notikums" if session_id is None else "Notikums",
                                font=("Georgia", 15, "bold"), bg=CREAM, fg=RED)
        self.heading.pack(anchor="w", pady=(0, 8))

        # ---- buttons (packed first so they never leave the window) ----
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.cancel).pack(side="right", padx=6)
        ttk.Button(btns, text="✉ Informācija dejotājiem…", command=self.show_info_text).pack(side="right", padx=6)
        if session_id is not None:
            ttk.Button(btns, text="Dzēst notikumu", style="Danger.TButton", command=self.delete).pack(side="left")

        # ---- main details ----
        self.v = {k: tk.StringVar() for k in ["date", "time", "kind", "title", "notes"] + DETAIL_FIELDS}
        self.bus_price_text = tk.StringVar()   # autobusa cena eiro (v["bus_price"] — centos datubāzē)
        self.bus = {}            # dancer id -> '1' brauks ar autobusu / '0' nebrauks
        self.bus_paid = {}       # dancer id -> cents paid (Zelta pūrs)
        form = tk.Frame(self, bg=CREAM)
        form.pack(fill="x")

        def label(parent, text, r, c):
            tk.Label(parent, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                                 padx=(0 if c == 0 else 18, 0))
        label(form, "Datums *", 0, 0)
        date_box = tk.Frame(form, bg=CREAM)
        date_box.grid(row=0, column=1, sticky="w", padx=(8, 0))
        date_entry = ttk.Entry(date_box, textvariable=self.v["date"], width=13)
        date_entry.pack(side="left")
        date_picker_button(date_box, self.v["date"]).pack(side="left", padx=(2, 0))   # izvēle no kalendāra
        self.weekday_lbl = tk.Label(form, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), width=11,
                                    anchor="w")
        self.weekday_lbl.grid(row=0, column=2, sticky="w", padx=(4, 0))
        label(form, "Sākuma laiks", 0, 3)
        ttk.Entry(form, textvariable=self.v["time"], width=8).grid(row=0, column=4, sticky="w", padx=(8, 0))
        label(form, "Veids", 0, 5)
        self.kind_cb = ttk.Combobox(form, textvariable=self.v["kind"], values=EVENT_KINDS, state="readonly", width=18)
        self.kind_cb.grid(row=0, column=6, sticky="w", padx=(8, 0))
        label(form, "Statuss", 0, 7)
        ttk.Combobox(form, textvariable=self.v["status"], values=STATUSES, state="readonly", width=13).grid(
            row=0, column=8, sticky="w", padx=(8, 0))
        label(form, "Nosaukums", 1, 0)
        ttk.Entry(form, textvariable=self.v["title"]).grid(row=1, column=1, columnspan=8, sticky="ew", padx=(8, 0),
                                                           pady=4)
        # Kolektīva pasākums: apakšveids (shown only for that kind)
        self.subkind_lbl = tk.Label(form, text="Apakšveids *", bg=CREAM, fg=NAVY)
        self.subkind_lbl.grid(row=2, column=5, sticky="w", pady=4, padx=(18, 0))
        self.subkind_cb = ttk.Combobox(form, textvariable=self.v["subkind"], values=EVENT_SUBKINDS, state="readonly",
                                       width=22)
        self.subkind_cb.grid(row=2, column=6, columnspan=3, sticky="w", padx=(8, 0))
        # which groups the event is for (Kopas pūrs → Grupa)
        tk.Label(form, text="Grupa *", bg=CREAM, fg=NAVY).grid(row=3, column=0, sticky="w", pady=4)
        gbox = tk.Frame(form, bg=CREAM)
        gbox.grid(row=3, column=1, columnspan=8, sticky="w", padx=(8, 0))
        self.group_vars, self.group_cbs = {}, {}
        for g in DANCER_GROUPS:
            var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(gbox, text=g, variable=var, command=self.on_groups)
            cb.pack(side="left", padx=(0, 10))
            self.group_vars[g] = var
            self.group_cbs[g] = cb
        tk.Label(gbox, text="kurām grupām notikums domāts — tikai šo grupu dejotāji to redz Kabatas Pūrlādē un saņem "
                            "paziņojumus (koncertā un skatē — arī programmas deju sastāvs)",
                 bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).pack(side="left", padx=(6, 0))
        form.columnconfigure(8, weight=1)
        self.form = form
        self.repeat = None
        if session_id is None:  # a series of events can be created only for a new event
            self.repeat = tk.BooleanVar(value=False)
            ttk.Checkbutton(form, text="↻ Atkārtojas", variable=self.repeat, command=self.toggle_repeat).grid(
                row=2, column=1, columnspan=4, sticky="w", padx=(8, 0), pady=(2, 0))
            self.build_repeat()

        # ---- tabs ----
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, pady=(8, 0))
        self.build_info_tab()
        self.build_program_tab()
        self.build_people_tab()
        self.build_costume_tab()

        # ---- load ----
        if session_id is not None:
            ev = self.db.events(kinds=EVENT_KINDS + list(REHEARSAL_KINDS))
            ev = next(e for e in ev if e["id"] == session_id)
            for k in ["date", "time", "kind", "title", "notes"] + DETAIL_FIELDS:
                self.v[k].set(show_date(ev[k]) if k == "date" or k in DATE_FIELDS else ev[k])
            if ev["kind"] not in EVENT_KINDS:
                self.v["kind"].set(KIND_EVENT)
            self.invited = invited_ids(ev["invited"])
            chosen = event_groups(ev["for_groups"]) or DANCER_GROUPS   # earlier events: all groups
            for g, var in self.group_vars.items():
                var.set(g in chosen)
            self.event_costumes = event_costume_types(self.db.con, [session_id]).get(session_id, {})
            self.program = [did for did, _t, _d in self.db.programs([session_id]).get(session_id, [])]
            self.answers = {did: [a, n] for did, (a, n) in self.db.answers([session_id]).get(session_id, {}).items()}
            self.bus = self.db.bus_marks(session_id)
            self.bus_paid = {d: c for (_s, d), c in bus_paid(self.db.con, {session_id}).items()}
            self.v["transport_kind"].set(guess_transport_kind(ev["transport_kind"], ev["transport"]))
            cents = bus_cents(ev["bus_price"])
            self.bus_price_text.set(euro_text(cents).replace(" €", "").replace(" ", "") if cents else "")
            self.marks = self.db.marks([session_id]).get(session_id, {})
        else:
            self.v["date"].set(show_date((day or date.today()).isoformat()))
            self.v["kind"].set(KIND_CONCERT)
            self.v["status"].set(ST_PLANNED)
            self.group_vars[DEFAULT_DANCER_GROUP].set(True)

        for var in self.v.values():
            var.trace_add("write", lambda *a: self.set_changed())
        self.v["date"].trace_add("write", lambda *a: self.show_weekday())
        if self.repeat is not None:
            self.v["date"].trace_add("write", lambda *a: self.update_repeat())
        self.v["kind"].trace_add("write", lambda *a: self.update_kind_ui())
        self.v["transport_kind"].trace_add("write", lambda *a: self.update_bus_ui())
        self.bus_price_text.trace_add("write", lambda *a: (self.set_changed(), self.refresh_people()))
        self.v["subkind"].trace_add("write", lambda *a: self.update_kind_ui())
        self.show_weekday()
        self.refresh_program()
        self.refresh_costumes()
        self.update_bus_ui()
        self.update_kind_ui()   # also fills the participants
        self.loading = False
        self.bind("<Escape>", lambda e: self.cancel())
        date_entry.focus_set()
        self.apply_rights()
        self.after(100, lambda: fit_min_size(self))

    # ---- lietotāju lomas -----------------------------------------------------------
    def apply_rights(self):
        acc = piekluve.current()
        self.costumes_only = False
        self.publicity_only = False
        self.old_groups = event_groups_text(self.chosen_groups()) if self.session_id is not None else ""
        self.old_publicity = self.session_id is not None and self.is_publicity()
        if self.session_id is not None and not acc.can_edit_event(self.old_groups, self.old_publicity):
            self.locked = True
            if acc.costumes and self.old_publicity:
                self.costumes_only = True
                piekluve.make_readonly(self, keep=("saglabāt",), skip=(self.costume_tab,),
                                       note="Var mainīt tikai pasākuma tērpus (tērpu pārzinis).")
                self.nb.select(self.costume_tab)
            else:
                piekluve.make_readonly(self, note=(
                    "Tikai skatīšanai — " + ("jūsu lomai Notikumu pūrā nav labošanas tiesību."
                                             if acc.view_only("notikumu_purs") and not acc.social else
                                             "šo notikumu jūsu loma nevar labot.")))
            return
        if acc.social and not acc.can_edit("notikumu_purs"):
            # Sociālo tīklu administrators: only publicity events
            self.publicity_only = True
            self.v["kind"].set(KIND_EVENT)
            self.v["subkind"].set(SUBKIND_PUBLICITY)
            for w in (self.kind_cb, self.subkind_cb):
                w.configure(state="disabled")
        elif not acc.edits_all("notikumu_purs"):
            allowed = acc.groups("notikumu_purs")
            for g, cb in self.group_cbs.items():
                if g not in allowed:
                    cb.configure(state="disabled")
            if self.session_id is None:
                for g, var in self.group_vars.items():
                    var.set(g == (allowed[0] if allowed else DEFAULT_DANCER_GROUP))
                self.on_groups()
        self.changed = False

    # ---- tabs ----------------------------------------------------------------
    def build_info_tab(self):
        tab = ttk.Frame(self.nb, padding=(4, 10, 4, 4))
        self.nb.add(tab, text="  Informācija  ")
        rows = [
            ("place", "Vieta", "piem., Kultūras nams, Lielā zāle"),
            ("address", "Adrese", ""),
            ("arrival_time", "Ierašanās laiks", "kad dejotājiem jābūt uz vietas, piem., 16:30"),
            ("end_time", "Beigu laiks", "aptuvenais beigu laiks"),
            ("organizer", "Organizators", "kas rīko pasākumu"),
            ("contact", "Kontaktpersona", "vārds, tālrunis, e-pasts"),
            ("transport", "Transports", ""),
            ("bus_price_text", "Autobusa cena", ""),
            ("fee", "Honorārs / maksa", "honorārs kolektīvam vai dalības maksa"),
            ("costume_notes", "Tērpu piezīmes", "piem., līdzi ņemt baltās zeķes, vainagi"),
            ("costume_dates", "Tērpi", ""),
            ("notes", "Piezīmes", "redzamas arī Cītības pūrā"),
        ]
        for i, (key, text, hint) in enumerate(rows):
            lbl = tk.Label(tab, text=text, bg=CREAM, fg=NAVY)
            lbl.grid(row=i, column=0, sticky="w", pady=5)
            if key == "transport":   # kind (Autobuss …) + free text
                box = tk.Frame(tab, bg=CREAM)
                box.grid(row=i, column=1, columnspan=2, sticky="ew", padx=(10, 10))
                self.transport_cb = ttk.Combobox(box, textvariable=self.v["transport_kind"], state="readonly",
                                                 values=[""] + TRANSPORT_KINDS, width=22)
                self.transport_cb.pack(side="left")
                ttk.Entry(box, textvariable=self.v["transport"], width=44).pack(side="left", padx=(8, 0), fill="x",
                                                                                 expand=True)
                tk.Label(box, text="piem., izbraukšana no kultūras nama 15:00", bg=CREAM, fg=GREY,
                         font=("Segoe UI", 8, "italic")).pack(side="left", padx=(8, 0))
                continue
            if key == "bus_price_text":   # only when the transport is a bus
                self.bus_row = [lbl]
                box = tk.Frame(tab, bg=CREAM)
                box.grid(row=i, column=1, columnspan=2, sticky="ew", padx=(10, 10))
                self.bus_row.append(box)
                ttk.Entry(box, textvariable=self.bus_price_text, width=10).pack(side="left")
                tk.Label(box, text="€ vienam dejotājam", bg=CREAM, fg=NAVY).pack(side="left", padx=(4, 0))
                tk.Label(box, text="maksā dejotāji, kuri dejo šajā notikumā, un tie, kas cilnē “Dalībnieki” "
                                   "atzīmēti “brauks ar autobusu”; Kabatas Pūrlādē redzams, līdz samaksāts "
                                   "(samaksu reģistrē Zelta pūrā)", bg=CREAM, fg=GREY, wraplength=560, justify="left",
                         font=("Segoe UI", 8, "italic")).pack(side="left", padx=(10, 0))
                continue
            if key == "costume_dates":   # kad tērpus izsniedz un kad tie jāatgriež
                box = tk.Frame(tab, bg=CREAM)
                box.grid(row=i, column=1, columnspan=2, sticky="ew", padx=(10, 10))
                for field, text_ in (("costume_issue_date", "izsniedz"), ("costume_return_date", "jāatgriež")):
                    tk.Label(box, text=text_, bg=CREAM, fg=NAVY).pack(side="left", padx=(0 if field ==
                                                                                       "costume_issue_date" else 16, 4))
                    ttk.Entry(box, textvariable=self.v[field], width=12).pack(side="left")
                    fallback = self.v["costume_issue_date"] if field == "costume_return_date" else self.v["date"]
                    date_picker_button(box, self.v[field], fallback_var=fallback).pack(side="left", padx=(2, 0))
                tk.Label(box, text="DD.MM.GGGG — redzams arī Kabatas Pūrlādē un tekstā dejotājiem", bg=CREAM,
                         fg=GREY, font=("Segoe UI", 8, "italic")).pack(side="left", padx=(12, 0))
                continue
            width = 10 if key in ("arrival_time", "end_time") else 60
            ttk.Entry(tab, textvariable=self.v[key], width=width).grid(
                row=i, column=1, sticky="w" if width == 10 else "ew", padx=(10, 10))
            if hint:
                tk.Label(tab, text=hint, bg=CREAM, fg=GREY, font=("Segoe UI", 8, "italic")).grid(
                    row=i, column=2, sticky="w")
        tab.columnconfigure(1, weight=1)
        tk.Label(tab, text="Datumu raksta formā DD.MM.GGGG, laiku — 18:30. Notikums uzreiz redzams arī Cītības pūrā, "
                           "kur pēc tam var atzīmēt dejotāju apmeklējumu.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(row=len(rows), column=0, columnspan=3,
                                                                        sticky="w", pady=(10, 0))

    def build_program_tab(self):
        tab = ttk.Frame(self.nb, padding=(0, 8, 0, 0))
        self.nb.add(tab, text="  Programma  ")
        self.program_tab = tab
        tools = tk.Frame(tab, bg=CREAM)
        tools.pack(fill="x", pady=(0, 6))
        ttk.Button(tools, text="＋ Pievienot dejas…", style="Accent.TButton", command=self.pick_dances).pack(
            side="left")
        ttk.Button(tools, text="▲", width=3, command=lambda: self.move(-1)).pack(side="left", padx=(10, 2))
        ttk.Button(tools, text="▼", width=3, command=lambda: self.move(1)).pack(side="left", padx=2)
        ttk.Button(tools, text="Noņemt", command=self.remove_dance).pack(side="left", padx=(8, 2))
        ttk.Button(tools, text="Kā iepriekšējā reizē", command=self.program_like_last).pack(side="left", padx=(8, 0))
        self.total_lbl = tk.Label(tools, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold"))
        self.total_lbl.pack(side="right")

        holder = ttk.Frame(tab)
        holder.pack(fill="both", expand=True)
        cols = [("nr", "Nr.", 40), ("title", "Deja", 220), ("type", "Veids", 170), ("duration", "Ilgums", 65),
                ("cast", "Sastāvs", 70), ("costumes", "Tērpi", 300)]
        self.p_tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings", selectmode="browse")
        for key, title, width in cols:
            self.p_tree.heading(key, text=title)
            self.p_tree.column(key, width=width, minwidth=35, anchor="center" if key in ("nr", "duration", "cast")
                               else "w", stretch=key in ("title", "costumes"))
        self.p_tree.tag_configure("warn", foreground=RED)
        make_tree_with_scroll(holder, self.p_tree)
        self.p_tree.bind("<Delete>", lambda e: self.remove_dance())
        self.costume_lbl = tk.Label(tab, text="", bg=CREAM, fg=NAVY, justify="left", anchor="w", wraplength=900,
                                    font=("Segoe UI", 9))
        self.costume_lbl.pack(fill="x", pady=(6, 0))
        tk.Label(tab, text="Dejas — no Deju pūra. Secību maina ar ▲ ▼. Sastāvs un tērpi tiek ņemti no Deju pūra; "
                           "sarkanā krāsā — dejas, kurās kāds dejotājs atbildējis “Nebūs” un viņam nav rezerves dejotāja "
                           "(ja ir, rezerve tiek ielikta automātiski).",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).pack(anchor="w")

    def build_people_tab(self):
        tab = ttk.Frame(self.nb, padding=(0, 8, 0, 0))
        self.nb.add(tab, text="  Dalībnieki  ")
        top = tk.Frame(tab, bg=CREAM)
        top.pack(fill="x", pady=(0, 6))
        for ans in ANSWERS:
            ttk.Button(top, text=ans, command=lambda a=ans: self.set_answer(a)).pack(side="left", padx=(0, 4))
        ttk.Button(top, text="Nav zināms", command=lambda: self.set_answer("")).pack(side="left", padx=(0, 4))
        ttk.Button(top, text="✓ Pārējie būs", command=self.rest_yes).pack(side="left", padx=(10, 0))
        self.show_all = tk.BooleanVar(value=False)
        self.show_all_cb = ttk.Checkbutton(top, text="Rādīt visus aktīvos dejotājus", variable=self.show_all,
                                           command=self.refresh_people)
        self.show_all_cb.pack(side="right")

        # Publicitātes pasākums: who is invited (only they see the event and get notifications)
        self.invite_bar = tk.Frame(tab, bg=CREAM_DARK, padx=8, pady=6, highlightthickness=1,
                                   highlightbackground=GOLD)
        tk.Label(self.invite_bar, text="Uzaicinātie:", bg=CREAM_DARK, fg=NAVY,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 8))
        ttk.Button(self.invite_bar, text="＋ Uzaicināt izvēlētos", style="Accent.TButton",
                   command=lambda: self.set_invited(True)).pack(side="left", padx=(0, 4))
        ttk.Button(self.invite_bar, text="− Noņemt izvēlētos",
                   command=lambda: self.set_invited(False)).pack(side="left", padx=(0, 4))
        row1 = tk.Frame(self.invite_bar, bg=CREAM_DARK)
        row1.pack(fill="x")
        for child in list(self.invite_bar.winfo_children())[:-1]:   # the label and the first two buttons
            child.pack_forget()
            child.pack(in_=row1, side="left", padx=(0, 4))
            child.lift(row1)   # created before row1: without this they would stay hidden behind it
        ttk.Button(row1, text="Uzaicināt visus redzamos", command=lambda: self.set_invited(True, visible=True)).pack(
            side="left", padx=(10, 4))
        ttk.Button(row1, text="Noņemt visus", command=lambda: self.set_invited(False, every=True)).pack(
            side="left", padx=(0, 4))
        self.only_invited = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="Rādīt tikai uzaicinātos", variable=self.only_invited,
                        command=self.refresh_people).pack(side="right")

        row2 = tk.Frame(self.invite_bar, bg=CREAM_DARK)
        row2.pack(fill="x", pady=(6, 0))
        tk.Label(row2, text="Meklēt:", bg=CREAM_DARK, fg=NAVY).pack(side="left")
        self.people_search = tk.StringVar()
        self.people_search_entry = ttk.Entry(row2, textvariable=self.people_search, width=22)
        self.people_search_entry.pack(side="left", padx=(4, 4))
        ttk.Button(row2, text="✕", width=3, command=lambda: self.people_search.set("")).pack(side="left",
                                                                                            padx=(0, 12))
        self.people_search.trace_add("write", lambda *a: self.refresh_people())
        tk.Label(row2, text="Grupa:", bg=CREAM_DARK, fg=NAVY).pack(side="left")
        self.people_group = tk.StringVar(value=ALL)
        gcb = ttk.Combobox(row2, textvariable=self.people_group, state="readonly", width=10,
                           values=[ALL] + sorted({g for g in self.dancer_group.values() if g}, key=_norm))
        gcb.pack(side="left", padx=(4, 12))
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh_people())
        tk.Label(row2, text="Kārtot:", bg=CREAM_DARK, fg=NAVY).pack(side="left")
        self.people_sort_var = tk.StringVar(value=PEOPLE_SORT_LAST)
        scb = ttk.Combobox(row2, textvariable=self.people_sort_var, values=PEOPLE_SORTS, state="readonly", width=20)
        scb.pack(side="left", padx=(4, 4))
        scb.bind("<<ComboboxSelected>>", lambda e: self.sort_people(self.people_sort_var.get(), toggle=False))
        self.people_dir_btn = ttk.Button(row2, text="↑ augošā", width=10,
                                         command=lambda: self.sort_people(self.people_sort, toggle=True))
        self.people_dir_btn.pack(side="left")
        self.people_found = tk.Label(row2, text="", bg=CREAM_DARK, fg=NAVY, font=("Segoe UI", 9, "italic"))
        self.people_found.pack(side="right")
        self.people_top = top

        # Autobuss: who rides (and pays) — shown only when the transport is a bus
        self.bus_bar = tk.Frame(tab, bg=CREAM_DARK, padx=8, pady=6, highlightthickness=1, highlightbackground=GOLD)
        tk.Label(self.bus_bar, text="🚌 Autobuss:", bg=CREAM_DARK, fg=NAVY, font=("Segoe UI", 10, "bold")).pack(
            side="left", padx=(0, 8))
        ttk.Button(self.bus_bar, text="Brauks", command=lambda: self.set_bus(BUS_YES)).pack(side="left", padx=(0, 4))
        ttk.Button(self.bus_bar, text="Nebrauks", command=lambda: self.set_bus(BUS_NO)).pack(side="left", padx=(0, 4))
        ttk.Button(self.bus_bar, text="Nav atzīmēts", command=lambda: self.set_bus("")).pack(side="left", padx=(0, 4))
        self.bus_lbl = tk.Label(self.bus_bar, text="", bg=CREAM_DARK, fg=NAVY, font=("Segoe UI", 9), anchor="w",
                                justify="left", wraplength=560)
        self.bus_lbl.pack(side="left", padx=(10, 0), fill="x", expand=True)

        holder = ttk.Frame(tab)
        holder.pack(fill="both", expand=True)
        cols = [("name", "Dejotājs", 190), ("group", "Grupa", 70), ("dances", "Dejas programmā", 280),
                ("answer", "Atbilde", 90), ("mark", "Cītības pūrā", 100), ("bus", "Autobuss", 150),
                ("note", "Piezīme", 170)]
        self.d_tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings", selectmode="extended")
        self.people_titles = {key: title for key, title, _w in cols}
        for key, title, width in cols:
            self.d_tree.heading(key, text=title, command=(lambda k=key: self.sort_people(
                PEOPLE_HEADING_SORT[k], toggle=True)) if key in PEOPLE_HEADING_SORT else "")
            self.d_tree.column(key, width=width, minwidth=45, anchor="w", stretch=key in ("dances", "note"))
        answer_colours(self.d_tree)
        self.d_tree.tag_configure("uninvited", foreground=GREY)
        self.d_tree.bind("<Double-1>", self.cycle_answer)
        self.d_tree.bind("<<TreeviewSelect>>", lambda e: self.load_note())
        make_tree_with_scroll(holder, self.d_tree)

        bottom = tk.Frame(tab, bg=CREAM)
        bottom.pack(fill="x", pady=(6, 0))
        tk.Label(bottom, text="Piezīme izvēlētajam:", bg=CREAM, fg=NAVY).pack(side="left")
        self.note_var = tk.StringVar()
        self.note_entry = ttk.Entry(bottom, textvariable=self.note_var, width=50)
        self.note_entry.pack(side="left", padx=(6, 0), fill="x", expand=True)
        self.note_var.trace_add("write", lambda *a: self.store_note())
        self._note_loading = False
        self.people_lbl = tk.Label(tab, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold"), anchor="w")
        self.people_lbl.pack(fill="x", pady=(6, 0))
        self.warn_lbl = tk.Label(tab, text="", bg=CREAM, fg=RED, font=("Segoe UI", 9), anchor="w", justify="left",
                                 wraplength=900)
        self.warn_lbl.pack(fill="x")
        self.people_help = tk.Label(tab, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), anchor="w",
                                    justify="left", wraplength=900)
        self.people_help.pack(fill="x")

    # ---- common --------------------------------------------------------------
    def set_changed(self):
        if not self.loading and not (getattr(self, "readonly", False) and not getattr(self, "costumes_only", False)):
            self.changed = True

    # ---- kind / sub-kind ---------------------------------------------------------
    def is_group(self):
        return self.v["kind"].get() == KIND_EVENT

    def is_publicity(self):
        return self.is_group() and self.v["subkind"].get() == SUBKIND_PUBLICITY

    def update_kind_ui(self):
        """Kolektīva pasākums: sub-kind shown, no programme tab; Publicitātes pasākums: invitation bar."""
        group = self.is_group()
        if group:
            self.subkind_lbl.grid()
            self.subkind_cb.grid()
            self.nb.hide(self.program_tab)
        else:
            self.subkind_lbl.grid_remove()
            self.subkind_cb.grid_remove()
            self.nb.add(self.program_tab)   # a hidden tab comes back at its old place
        if self.is_publicity():
            self.invite_bar.pack(fill="x", pady=(0, 6), after=self.people_top)
            self.nb.add(self.costume_tab)
        else:
            self.invite_bar.pack_forget()
            self.nb.hide(self.costume_tab)
        if group:
            self.show_all_cb.pack_forget()
        elif not self.show_all_cb.winfo_ismapped():
            self.show_all_cb.pack(side="right")
        self.people_titles["dances"] = "Uzaicināts" if self.is_publicity() else (
            "Dalība" if group else "Dejas programmā")
        self.show_sort_arrows()
        if self.is_publicity():
            help_text = ("Publicitātes pasākumu Kabatas Pūrlādē redz un paziņojumus par to saņem tikai uzaicinātie "
                         "dejotāji. Izvēlieties dejotājus (Ctrl vai Shift — vairākus) un spiediet “Uzaicināt "
                         "izvēlētos”. Meklēšana atrod pēc vārda, uzvārda, grupas un piezīmes; kārtot var arī, "
                         "uzklikšķinot uz kolonnas virsraksta. Dubultklikšķis maina atbildi.")
        elif group:
            help_text = ("Kolektīva pasākumam nav deju; tas domāts visiem aktīvajiem dejotājiem, un paziņojumus "
                         "Kabatas Pūrlādē saņem visi. Dubultklikšķis maina atbildi.")
        else:
            help_text = ("Sarakstā — izvēlēto deju sastāvs (no Deju pūra). Dubultklikšķis maina atbildi; var "
                         "izvēlēties vairākus ar Ctrl vai Shift. Apmeklējumu pēc notikuma atzīmē Cītības pūrā.")
        self.people_help.configure(text=help_text)
        self.refresh_people()

    def chosen_groups(self):
        return [g for g, var in self.group_vars.items() if var.get()]

    def on_groups(self):
        self.set_changed()
        self.refresh_people()

    def in_groups(self, did):
        g = self.dancer_group.get(did, "")
        return ((g or "").strip() or DEFAULT_DANCER_GROUP) in self.chosen_groups()

    # ---- costumes of a publicity event -------------------------------------------
    def build_costume_tab(self):
        tab = ttk.Frame(self.nb, padding=(4, 10, 4, 4))
        self.nb.add(tab, text="  Tērpi  ")
        self.costume_tab = tab
        tk.Label(tab, text="Kādi tērpi vajadzīgi publicitātes pasākumā", font=("Georgia", 12, "bold"), bg=CREAM,
                 fg=NAVY).pack(anchor="w")
        tk.Label(tab, text="Publicitātes pasākumam nav deju, tāpēc tērpu veidus norāda šeit — katram dzimumam atsevišķi. "
                           "Tie redzami Tērpu pūrā (izsniegšana, kopsavilkums), Kabatas Pūrlādē un tekstā “Informācija "
                           "dejotājiem”.", bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic"), wraplength=900,
                 justify="left").pack(anchor="w", pady=(2, 8))
        box = tk.Frame(tab, bg=CREAM)
        box.pack(fill="both", expand=True)
        box.columnconfigure(0, weight=1, uniform="cost")
        box.columnconfigure(1, weight=1, uniform="cost")
        box.rowconfigure(0, weight=1)
        self.types_for = {g: self.db.costume_types_for(g) for g in GENDERS}
        self.costume_lists, self.costume_choice, self.costume_combos = {}, {}, {}
        for i, gender in enumerate((GENDERS[1], GENDERS[0])):   # women left, men right (as in Deju pūrs)
            col = tk.Frame(box, bg=WHITE, highlightbackground=GOLD, highlightthickness=1, padx=10, pady=8)
            col.grid(row=0, column=i, sticky="nsew", padx=(0, 6) if i == 0 else (6, 0))
            tk.Label(col, text=COSTUME_TITLE[gender], font=("Segoe UI", 10, "bold"), bg=WHITE, fg=NAVY).pack(
                anchor="w")
            lb = tk.Listbox(col, height=8, relief="flat", bg=WHITE, fg=NAVY, selectbackground=GOLD,
                            selectforeground=NAVY, activestyle="none", highlightthickness=0, font=("Segoe UI", 10))
            lb.pack(fill="both", expand=True, pady=(4, 6))
            lb.bind("<Double-1>", lambda e, g=gender: self.remove_costume(g, e))
            lb.bind("<Delete>", lambda e, g=gender: self.remove_costume(g))
            self.costume_lists[gender] = lb
            row = tk.Frame(col, bg=WHITE)
            row.pack(fill="x")
            var = tk.StringVar()
            self.costume_choice[gender] = var
            cb = ttk.Combobox(row, textvariable=var, state="readonly", width=24)
            cb.pack(side="left", fill="x", expand=True)
            cb.bind("<<ComboboxSelected>>", lambda e, g=gender: self.add_costume(g))
            self.costume_combos[gender] = cb
            ttk.Button(row, text="Izņemt", command=lambda g=gender: self.remove_costume(g)).pack(side="left",
                                                                                               padx=(6, 0))
        any_types = any(self.types_for.values())
        tk.Label(tab, text=("Izvēlieties tērpa veidu sarakstā — tas tiek pievienots. Dubultklikšķis uz pievienotā vai "
                            "“Izņemt” — izņemt." if any_types else
                            "Tērpu veidu ar kategoriju “Meiteņu tērpi” vai “Puišu tērpi” vēl nav. Tos izveido Tērpu "
                            "pūrā → Noliktavas pārvaldība → Administrēšana (tērpu veidi)."),
                 bg=CREAM, fg=NAVY if any_types else RED, font=("Segoe UI", 8, "italic")).pack(anchor="w", pady=(6, 0))

    def refresh_costumes(self):
        for gender, lb in self.costume_lists.items():
            lb.delete(0, tk.END)
            for name in self.event_costumes.get(gender, []):
                lb.insert(tk.END, name)
            chosen = {_norm(n) for n in self.event_costumes.get(gender, [])}
            self.costume_combos[gender].configure(
                values=[n for n in self.types_for.get(gender, []) if _norm(n) not in chosen])
            self.costume_choice[gender].set("＋ pievienot tērpa veidu…" if self.types_for.get(gender) else
                                            "(nav šīs kategorijas veidu)")
        n = sum(len(v) for v in self.event_costumes.values())
        self.nb.tab(self.costume_tab, text=f"  Tērpi ({n})  " if n else "  Tērpi  ")

    def add_costume(self, gender):
        name = self.costume_choice[gender].get()
        if name in self.types_for.get(gender, []) and name not in self.event_costumes.setdefault(gender, []):
            self.event_costumes[gender].append(name)
            self.set_changed()
        self.refresh_costumes()

    def remove_costume(self, gender, event=None):
        lb = self.costume_lists[gender]
        if event is not None and event.type == tk.EventType.ButtonPress:
            index = lb.nearest(event.y)
            bbox = lb.bbox(index)
            if not bbox or not (bbox[1] <= event.y <= bbox[1] + bbox[3]):
                return
        else:
            sel = lb.curselection()
            if not sel:
                return
            index = sel[0]
        if 0 <= index < len(self.event_costumes.get(gender, [])):
            del self.event_costumes[gender][index]
            self.set_changed()
            self.refresh_costumes()

    def set_invited(self, invite, every=False, visible=False):
        if self.locked:
            return
        if visible:
            ids = {int(i) for i in self.d_tree.get_children()}
            if not ids:
                return
        elif every:
            ids = {r[0] for r in self.db.dancers() if self.in_groups(r[0])} if invite else set(self.invited)
        else:
            ids = {int(i) for i in self.d_tree.selection()}
            if not ids:
                messagebox.showinfo("Uzaicinātie", "Vispirms izvēlieties vienu vai vairākus dejotājus sarakstā.",
                                    parent=self)
                return
        before = set(self.invited)
        if invite:
            self.invited |= ids
        else:
            self.invited -= ids
        if self.invited != before:
            self.set_changed()
        self.refresh_people()

    def sort_people(self, sort, toggle=True):
        """Choose the sort of the participants; the same sort again (heading / arrow button) reverses it."""
        if toggle and sort == self.people_sort:
            self.people_desc = not self.people_desc
        elif sort != self.people_sort:
            self.people_sort, self.people_desc = sort, False
        self.people_sort_var.set(self.people_sort)
        self.refresh_people()

    def show_sort_arrows(self):
        arrow = " ▼" if self.people_desc else " ▲"
        for key, title in self.people_titles.items():
            self.d_tree.heading(key, text=title + (arrow if PEOPLE_HEADING_SORT.get(key) == self.people_sort
                                                   and key != "name" else ""))
        if self.people_sort in (PEOPLE_SORT_LAST, PEOPLE_SORT_FIRST):
            self.d_tree.heading("name", text=f"{self.people_titles['name']} ({self.people_sort.lower()}){arrow}")
        self.people_dir_btn.configure(text="↓ dilstošā" if self.people_desc else "↑ augošā")

    def people_sort_key(self, did):
        _i, first, last, _g, _st = self.dancer_rows[did]
        name = (_norm(last), _norm(first))
        sort = self.people_sort
        if sort == PEOPLE_SORT_FIRST:
            return (_norm(first), _norm(last))
        if sort == PEOPLE_SORT_GROUP:
            return (_norm(self.dancer_group.get(did, "")) or "\uffff",) + name
        if sort == PEOPLE_SORT_INVITED:
            return (0 if did in self.invited else 1,) + name
        if sort == PEOPLE_SORT_ANSWER:
            order = {ANS_YES: 0, ANS_MAYBE: 1, ANS_NO: 2, "": 3}
            return (order.get(self.answers.get(did, ["", ""])[0], 3),) + name
        return name

    def people_match(self, did):
        """Search and group filter (only shown for a publicity event)."""
        if not self.is_publicity():
            return True
        group = self.people_group.get()
        if group != ALL and self.dancer_group.get(did, "") != group:
            return False
        term = _norm(self.people_search.get())
        if not term:
            return True
        _i, first, last, _g, _st = self.dancer_rows[did]
        note = self.answers.get(did, ["", ""])[1]
        return all(part in _norm(f"{first} {last} {self.dancer_group.get(did, '')} {note}") for part in term.split())

    # ---- repeating ------------------------------------------------------------
    def build_repeat(self):
        f = self.repeat_frame = tk.Frame(self, bg=CREAM_DARK, padx=12, pady=8, highlightthickness=1,
                                         highlightbackground=GOLD)
        self.repeat_mode = tk.StringVar(value=REPEAT_WEEKDAYS)
        self.repeat_days = [tk.BooleanVar(value=False) for _ in WEEKDAYS]
        self.repeat_every = tk.StringVar(value=EVERY_WEEK)
        self.repeat_until = tk.StringVar()
        self.repeat_dates = tk.StringVar()
        opts = dict(bg=CREAM_DARK, fg=NAVY, activebackground=CREAM_DARK, selectcolor=WHITE, cursor="hand2",
                    command=self.update_repeat)

        row1 = tk.Frame(f, bg=CREAM_DARK)
        row1.pack(fill="x")
        tk.Radiobutton(row1, text="Nedēļas dienās:", variable=self.repeat_mode, value=REPEAT_WEEKDAYS,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        for i, name in enumerate(WEEKDAYS):
            tk.Checkbutton(row1, text=name, variable=self.repeat_days[i], **opts).pack(side="left", padx=(0, 2))
        every = ttk.Combobox(row1, textvariable=self.repeat_every, values=EVERY_CHOICES, state="readonly", width=17)
        every.pack(side="left", padx=(10, 0))
        every.bind("<<ComboboxSelected>>", lambda e: self.update_repeat())
        tk.Label(row1, text="līdz", bg=CREAM_DARK, fg=NAVY).pack(side="left", padx=(10, 4))
        ttk.Entry(row1, textvariable=self.repeat_until, width=12).pack(side="left")
        date_picker_button(row1, self.repeat_until, bg=CREAM_DARK, fallback_var=self.v["date"]).pack(side="left", padx=(2, 0))
        tk.Label(row1, text="(ieskaitot)", bg=CREAM_DARK, fg=GREY, font=("Segoe UI", 8, "italic")).pack(
            side="left", padx=(4, 0))

        row2 = tk.Frame(f, bg=CREAM_DARK)
        row2.pack(fill="x", pady=(6, 0))
        tk.Radiobutton(row2, text="Konkrētos datumos:", variable=self.repeat_mode, value=REPEAT_DATES,
                       font=("Segoe UI", 10, "bold"), width=17, anchor="w", **opts).pack(side="left")
        ttk.Entry(row2, textvariable=self.repeat_dates).pack(side="left", fill="x", expand=True)
        tk.Label(row2, text="atdala ar komatu, piem., 07.11.2026, 21.11.2026", bg=CREAM_DARK, fg=GREY,
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(6, 0))

        self.repeat_lbl = tk.Label(f, text="", bg=CREAM_DARK, fg=NAVY, font=("Segoe UI", 9), anchor="w",
                                   justify="left", wraplength=920)
        self.repeat_lbl.pack(fill="x", pady=(6, 0))
        for var in (self.repeat_until, self.repeat_dates):
            var.trace_add("write", lambda *a: self.update_repeat())

    def toggle_repeat(self):
        if self.repeat.get():
            first = parse_date(self.v["date"].get())
            if first and not any(v.get() for v in self.repeat_days):
                self.repeat_days[date.fromisoformat(first).weekday()].set(True)
            self.repeat_frame.pack(fill="x", pady=(6, 0), after=self.form)
        else:
            self.repeat_frame.pack_forget()
        self.update_repeat()

    def repeat_list(self):
        """(sorted ISO dates of all events to create, error text or None)."""
        first = parse_date(self.v["date"].get())
        if not first:
            return None, "Norādiet pareizu datumu formā DD.MM.GGGG."
        if self.repeat is None or not self.repeat.get():
            return [first], None
        dates = {first}
        if self.repeat_mode.get() == REPEAT_WEEKDAYS:
            days = {i for i, v in enumerate(self.repeat_days) if v.get()}
            if not days:
                return None, "Izvēlieties vismaz vienu nedēļas dienu."
            until = parse_date(self.repeat_until.get())
            if not until:
                return None, "Norādiet, līdz kuram datumam notikums atkārtojas (DD.MM.GGGG)."
            if until < first:
                return None, "Datums “līdz” ir agrāks par notikuma datumu."
            step = 2 if self.repeat_every.get() == EVERY_2_WEEKS else 1
            d0 = date.fromisoformat(first)
            monday0 = d0 - timedelta(days=d0.weekday())
            d, end = d0, date.fromisoformat(until)
            while d <= end:
                week = ((d - timedelta(days=d.weekday())) - monday0).days // 7
                if d.weekday() in days and week % step == 0:
                    dates.add(d.isoformat())
                d += timedelta(days=1)
        else:
            parts = [p for p in re.split(r"[,;\s]+", self.repeat_dates.get()) if p]
            if not parts:
                return None, "Ierakstiet datumus, kuros notikums atkārtojas, atdalot tos ar komatu."
            for part in parts:
                d = parse_date(part)
                if not d:
                    return None, f"Nesaprotams datums “{part}”. Datumu raksta formā DD.MM.GGGG."
                dates.add(d)
        if len(dates) > MAX_REPEATS:
            return None, f"Pārāk daudz notikumu ({len(dates)}). Vienā reizē var izveidot līdz {MAX_REPEATS}."
        return sorted(dates), None

    def update_repeat(self):
        if self.repeat is None or not self.repeat.get():
            return
        dates, error = self.repeat_list()
        if error:
            self.repeat_lbl.configure(text="⚠ " + error, fg=RED)
            return
        shown = ", ".join(f"{show_date(d)} ({weekday(d)})" for d in dates[:14])
        more = f" … un vēl {len(dates) - 14}" if len(dates) > 14 else ""
        self.repeat_lbl.configure(text=f"Tiks izveidoti {len(dates)} notikumi ar vienādu informāciju un programmu: "
                                       f"{shown}{more}.\nDalībnieku atbildes katram notikumam ir savas — šajā logā "
                                       f"ievadītās attiecas tikai uz {show_date(parse_date(self.v['date'].get()))}.",
                                  fg=NAVY)

    def show_weekday(self):
        d = parse_date(self.v["date"].get())
        self.weekday_lbl.configure(text=weekday(d, full=True) if d else "")

    # ---- programme -----------------------------------------------------------
    def program_rows(self):
        return [(did, self.dance_info[did]["title"], self.dance_info[did]["duration"])
                for did in self.program if did in self.dance_info]

    def lineups(self):
        """{dance id: (lineup, uncovered)} for the programme with the current answers: a main-cast dancer who
        answered "Nebūs" is replaced by his reserve dancer (Deju pūrs) automatically."""
        declined = {did for did, (a, _n) in self.answers.items() if a == ANS_NO}
        return {did: dance_lineup(self.db.con, did, declined) for did in self.program}

    def refresh_program(self, select=None):
        self.program = [d for d in self.program if d in self.dance_info]
        lineups = self.lineups()
        costumes = self.db.costume_map(self.program)
        self.p_tree.delete(*self.p_tree.get_children())
        for i, did in enumerate(self.program, 1):
            d = self.dance_info[did]
            parts = []
            for gender in GENDERS:
                names = costumes.get(did, {}).get(gender, [])
                if names:
                    parts.append(f"{'V' if gender == GENDERS[0] else 'S'}: {', '.join(names)}")
            costume_text = "; ".join(parts) or d["costume_set"]
            lineup, uncovered = lineups.get(did, ([], []))
            self.p_tree.insert("", "end", iid=str(did), tags=("warn",) if uncovered else (), values=(
                i, d["title"], d["type"], show_duration(d["duration"]), len(lineup) or "—", costume_text))
        if select is not None and self.p_tree.exists(str(select)):
            self.p_tree.selection_set(str(select))
            self.p_tree.see(str(select))
        total, missing = program_seconds(self.program_rows())
        if self.program:
            text = f"{len(self.program)} dejas · kopā {show_total(total)}"
            if missing:
                text += f" (bez ilguma: {missing})"
        else:
            text = "Programmā vēl nav deju" if self.dance_info else "Deju pūrā vēl nav nevienas dejas"
        self.total_lbl.configure(text=text)
        needed = []
        for gender in GENDERS:
            names = []
            for did in self.program:
                for n in costumes.get(did, {}).get(gender, []):
                    if n not in names:
                        names.append(n)
            if names:
                needed.append(f"{'Vīriešiem' if gender == GENDERS[0] else 'Sievietēm'}: {', '.join(names)}")
        self.costume_lbl.configure(text=("Nepieciešamie tērpi — " + "   ·   ".join(needed)) if needed else "")
        self.nb.tab(1, text=f"  Programma ({len(self.program)})  ")

    def set_program(self, ids):
        ids = list(ids)
        if ids != self.program:
            self.program = ids
            self.set_changed()
        self.refresh_program()
        self.refresh_people()

    def pick_dances(self):
        if not self.dance_info:
            messagebox.showinfo("Dejas", "Deju pūrā vēl nav nevienas dejas. Vispirms pievienojiet dejas Deju pūrā.",
                                parent=self)
            return

        def done(chosen):
            chosen = set(chosen)
            kept = [d for d in self.program if d in chosen]
            new = sorted((d for d in chosen if d not in kept), key=lambda d: _norm(self.dance_info[d]["title"]))
            self.set_program(kept + new)
        DancePicker(self, self.dance_info, set(self.program), done)

    def selected_dance(self):
        sel = self.p_tree.selection()
        return int(sel[0]) if sel else None

    def move(self, step):
        did = self.selected_dance()
        if did is None:
            return
        i = self.program.index(did)
        j = i + step
        if 0 <= j < len(self.program):
            self.program[i], self.program[j] = self.program[j], self.program[i]
            self.set_changed()
            self.refresh_program(select=did)

    def remove_dance(self):
        did = self.selected_dance()
        if did is None:
            return
        i = self.program.index(did)
        self.program.remove(did)
        self.set_changed()
        nxt = self.program[min(i, len(self.program) - 1)] if self.program else None
        self.refresh_program(select=nxt)
        self.refresh_people()

    def program_like_last(self):
        kind = self.v["kind"].get()
        rows = self.db.q("SELECT s.id, s.session_date, s.title FROM attendance_sessions s WHERE s.id<>? AND s.kind=? "
                         "AND EXISTS (SELECT 1 FROM session_dances sd WHERE sd.session_id = s.id) "
                         "ORDER BY s.session_date DESC, s.start_time DESC, s.id DESC LIMIT 1",
                         (self.session_id or -1, kind)) if self.dance_info else []
        if not rows:
            messagebox.showinfo("Programma", f"Nevienam citam notikumam ar veidu “{kind}” vēl nav programmas.",
                                parent=self)
            return
        sid, d, title = rows[0]
        if self.program and not messagebox.askyesno(
                "Programma", f"Aizstāt programmu ar {show_date(d)} {title or kind} programmu?", parent=self):
            return
        self.set_program(did for did, _t, _d in self.db.programs([sid]).get(sid, []))

    # ---- participants ----------------------------------------------------------
    def dancer_name(self, did):
        row = self.dancer_rows.get(did)
        return full_name(row[1], row[2]) if row else ""

    def refresh_people(self):
        casts = self.db.cast_map(self.program)
        lineups = self.lineups()
        in_dances = {}
        for did in self.program:
            title = self.dance_info[did]["title"]
            lineup, uncovered = lineups.get(did, ([], []))
            replaced = {}
            for dancer, replaces in lineup:
                if replaces:
                    replaced[replaces] = dancer
                    in_dances.setdefault(dancer, []).append(f"{title} (aizvieto {self.dancer_name(replaces)})")
                else:
                    in_dances.setdefault(dancer, []).append(title)
            for dancer, sub in replaced.items():
                in_dances.setdefault(dancer, []).append(f"{title} (aizvietos {self.dancer_name(sub)})")
            for dancer in uncovered:
                in_dances.setdefault(dancer, []).append(f"{title} (nav aizvietotāja)")
        group, publicity = self.is_group(), self.is_publicity()
        active = {r[0] for r in self.db.dancers() if self.in_groups(r[0])}   # only the event's groups
        audience = (set(self.invited) if publicity else active) if group else set(in_dances)
        shown = set(in_dances) | {d for d, (a, n) in self.answers.items() if a or n} | set(self.marks)
        bus = self.is_bus()
        payers = self.bus_payers(lineups) if bus else {}
        price = self.bus_price() if bus else 0
        if bus:
            shown |= set(self.bus) | {d for d in self.bus_paid if self.bus_paid[d]}
        if group:
            shown |= set(self.invited) if publicity and self.only_invited.get() else active | set(self.invited)
        elif self.show_all.get():
            shown |= active
        shown &= set(self.dancer_rows)
        keep = self.d_tree.selection()
        self.d_tree.delete(*self.d_tree.get_children())
        counts = {a: 0 for a in ANS_CYCLE}
        for did in shown:   # counted before the search / group filter
            ans = self.answers.get(did, ["", ""])[0]
            if did in audience or (ans and not publicity):
                counts[ans] = counts.get(ans, 0) + 1
        rows = sorted(shown, key=self.people_sort_key, reverse=self.people_desc)
        visible = [d for d in rows if self.people_match(d)]
        self.people_found.configure(text=f"Redzami {len(visible)} no {len(rows)}")
        self.show_sort_arrows()
        for did in visible:
            _i, first, last, _g, status = self.dancer_rows[did]
            ans, note = self.answers.get(did, ["", ""])
            name = full_name(first, last)
            if (status or STATUS_ACTIVE) != STATUS_ACTIVE:
                name += f"  ({status.lower()})"
            tags = [ANS_TAG.get(ans, "unknown")]
            if publicity:
                second = "✓ uzaicināts" if did in self.invited else "—"
                if did not in self.invited:
                    tags.append("uninvited")
            elif group:
                second = "visi dejotāji"
            else:
                second = ", ".join(in_dances.get(did, [])) or "—"
            self.d_tree.insert("", "end", iid=str(did), tags=tuple(tags), values=(
                name, self.dancer_group.get(did, "") or "—", second, ans or "—", self.marks.get(did, ""),
                self.bus_text(did, payers, price) if bus else "", note))
        for iid in keep:
            if self.d_tree.exists(iid):
                self.d_tree.selection_add(iid)
        total = sum(counts.values())
        self.people_lbl.configure(text=(f"Uzaicināti {len(self.invited)}  ·  " if publicity else "") +
                                  f"Būs {counts[ANS_YES]}  ·  varbūt {counts[ANS_MAYBE]}  ·  "
                                  f"nebūs {counts[ANS_NO]}  ·  nav atbildes {counts['']}  (kopā {total})")
        if bus:
            visible_payers = [d for d in payers if d in self.dancer_rows]
            paid_n = sum(1 for d in visible_payers if price and self.bus_paid.get(d, 0) >= price)
            got = sum(self.bus_paid.values())
            dancing = sum(1 for d in visible_payers if payers[d] == BUS_REASON_DANCES)
            text = (f"jāmaksā {len(visible_payers)} dejotājiem ({dancing} dejo, {len(visible_payers) - dancing} "
                    f"atzīmēti “brauks”)")
            if price:
                text += (f" · cena {euro_text(price)} · kopā {euro_text(price * len(visible_payers))} · samaksājuši "
                         f"{paid_n}, saņemts {euro_text(got)}")
            else:
                text += " · ierakstiet autobusa cenu cilnē “Informācija”"
            self.bus_lbl.configure(text=text + ".  Izvēlieties dejotājus un atzīmējiet “Brauks” / “Nebrauks”.")
        warnings = []
        for did in self.program:
            lineup, uncovered = lineups.get(did, ([], []))
            title = self.dance_info[did]["title"]
            missing = sorted((self.dancer_name(d) for d in uncovered), key=_norm)
            if missing:
                warnings.append(f"⚠ “{title}”: nebūs {', '.join(missing)} — nav rezerves dejotāja")
            swaps = [f"{self.dancer_name(r)} → {self.dancer_name(d)}" for d, r in lineup if r]
            if swaps:
                warnings.append(f"↺ “{title}”: rezerve ielikta automātiski — {', '.join(swaps)}")
        self.warn_lbl.configure(text="\n".join(warnings))
        self.nb.tab(2, text=f"  Dalībnieki ({counts[ANS_YES]}/{total})  " if total else "  Dalībnieki  ")
        self.refresh_program_tags(lineups)

    def refresh_program_tags(self, lineups):
        for did in self.program:
            if self.p_tree.exists(str(did)):
                lineup, uncovered = lineups.get(did, ([], []))
                self.p_tree.item(str(did), tags=("warn",) if uncovered else ())
                self.p_tree.set(str(did), "cast", len(lineup) or "—")

    def set_answer(self, ans, ids=None):
        if self.locked:
            return
        ids = [int(i) for i in (ids if ids is not None else self.d_tree.selection())]
        if not ids:
            messagebox.showinfo("Dalībnieki", "Vispirms izvēlieties vienu vai vairākus dejotājus sarakstā.",
                                parent=self)
            return
        for did in ids:
            self.answers.setdefault(did, ["", ""])[0] = ans
        self.set_changed()
        self.refresh_people()

    # ---- autobuss ------------------------------------------------------------------
    def is_bus(self):
        return self.v["transport_kind"].get() == TRANSPORT_BUS

    def bus_price(self):
        """Price per dancer in cents (0 — not given / wrong)."""
        return parse_euro(self.bus_price_text.get()) or 0

    def update_bus_ui(self):
        if self.is_bus():
            for w in self.bus_row:
                w.grid()
            self.bus_bar.pack(fill="x", pady=(0, 6), after=self.people_top)
        else:
            for w in self.bus_row:
                w.grid_remove()
            self.bus_bar.pack_forget()
        self.refresh_people()

    def set_bus(self, mark, ids=None):
        if self.locked:
            return
        ids = [int(i) for i in (ids if ids is not None else self.d_tree.selection())]
        if not ids:
            messagebox.showinfo("Autobuss", "Vispirms izvēlieties vienu vai vairākus dejotājus sarakstā.", parent=self)
            return
        for did in ids:
            if mark:
                self.bus[did] = mark
            else:
                self.bus.pop(did, None)
        self.set_changed()
        self.refresh_people()

    def bus_payers(self, lineups=None):
        """{dancer id: reason} with the current programme, answers and marks of this window."""
        lineups = self.lineups() if lineups is None else lineups
        dancing = {d for lineup, _u in lineups.values() for d, _r in lineup} if not self.is_group() else set()
        return bus_payers_from(dancing, {d: a for d, (a, _n) in self.answers.items()}, self.bus)

    def bus_text(self, did, payers, price):
        mark = self.bus.get(did, "")
        if did not in payers:
            return "nebrauks" if mark == BUS_NO else ("— (nebūs)" if mark == BUS_YES else "—")
        paid = self.bus_paid.get(did, 0)
        who = "dejo" if payers[did] == BUS_REASON_DANCES else "brauks"
        if not price:
            return who
        if paid >= price:
            return f"{who} · ✓ samaksāts"
        return f"{who} · jāmaksā {euro_text(price - paid)}"

    def rest_yes(self):
        ids = [int(i) for i in self.d_tree.get_children() if not self.answers.get(int(i), ["", ""])[0]]
        if ids:
            self.set_answer(ANS_YES, ids)

    def cycle_answer(self, event):
        row = self.d_tree.identify_row(event.y)
        if not row:
            return
        cur = self.answers.get(int(row), ["", ""])[0]
        nxt = ANS_CYCLE[(ANS_CYCLE.index(cur) + 1) % len(ANS_CYCLE)] if cur in ANS_CYCLE else ""
        self.set_answer(nxt, [row])
        self.d_tree.selection_set(row)

    def load_note(self):
        sel = self.d_tree.selection()
        self._note_loading = True
        self.note_var.set(self.answers.get(int(sel[0]), ["", ""])[1] if len(sel) == 1 else "")
        self._note_loading = False
        self.note_entry.configure(state="normal" if len(sel) == 1 else "disabled")

    def store_note(self):
        if self._note_loading:
            return
        sel = self.d_tree.selection()
        if len(sel) != 1:
            return
        did = int(sel[0])
        self.answers.setdefault(did, ["", ""])[1] = self.note_var.get()
        self.d_tree.set(sel[0], "note", self.note_var.get())
        self.set_changed()

    # ---- info text -------------------------------------------------------------
    def current_event(self):
        ev = {k: var.get().strip() for k, var in self.v.items()}
        ev["date"] = parse_date(ev["date"]) or ""
        for k in DATE_FIELDS:
            ev[k] = parse_date(ev[k]) or ""
        for k in ("time", "arrival_time", "end_time"):
            ev[k] = parse_time(ev[k]) or ev[k]
        return ev

    def show_info_text(self):
        ev = self.current_event()
        if not ev["date"]:
            messagebox.showwarning("Datums", "Norādiet pareizu datumu formā DD.MM.GGGG.", parent=self)
            return
        TextWindow(self, "Informācija dejotājiem",
                   info_text(ev, self.program_rows(), self.db.costume_map(self.program),
                             self.event_costumes if self.is_publicity() else None))

    # ---- save / delete ---------------------------------------------------------
    def save(self):
        acc = piekluve.current()
        if self.costumes_only:   # Tērpu pārzinis: only the costume types of the publicity event
            if not acc.costumes:
                return piekluve.deny(self)
            con = self.db.con
            con.execute("DELETE FROM event_costumes WHERE session_id=?", (self.session_id,))
            con.executemany("INSERT INTO event_costumes (session_id, gender, type_name) VALUES (?,?,?)",
                            [(self.session_id, g, n) for g, names in self.event_costumes.items() for n in names])
            con.commit()
            self.changed = False
            self.app.refresh(select_event=self.session_id)
            if self.on_saved:
                self.on_saved()
            self.destroy()
            return
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        new_groups = event_groups_text(self.chosen_groups())
        if self.publicity_only and not self.is_publicity():
            return piekluve.deny(self, "Jūsu loma var veidot un labot tikai publicitātes pasākumus.")
        if not acc.can_edit_event(new_groups, self.is_publicity()) or (
                self.session_id is not None and not acc.can_edit_event(self.old_groups, self.old_publicity)):
            return piekluve.deny(self, "Notikumu var labot tikai tad, ja tas ir tikai " +
                                 acc.scope_text("notikumu_purs") + "i.")
        dates, error = self.repeat_list()
        if error:
            messagebox.showwarning("Datums", error, parent=self)
            return
        times = {}
        for key, name in (("time", "Sākuma laiku"), ("arrival_time", "Ierašanās laiku"), ("end_time", "Beigu laiku")):
            t = parse_time(self.v[key].get())
            if t is None:
                messagebox.showwarning("Laiks", f"{name} norādiet formā 18:30.", parent=self)
                self.nb.select(0)
                return
            times[key] = t
        kind = self.v["kind"].get() or KIND_CONCERT
        if not self.chosen_groups():
            messagebox.showwarning("Grupa", "Atzīmējiet, kurai grupai (vai kurām grupām) ir šis notikums.", parent=self)
            return
        if kind == KIND_EVENT:
            if not self.v["subkind"].get():
                messagebox.showwarning("Apakšveids", "Izvēlieties kolektīva pasākuma apakšveidu.", parent=self)
                self.subkind_cb.focus_set()
                return
            if self.program and self.dance_info:
                if not messagebox.askyesno(
                        "Programma", f"Kolektīva pasākumiem nav deju — programma ({len(self.program)} "
                                     f"{'deja' if len(self.program) == 1 else 'dejas'}) tiks noņemta. Turpināt?",
                        parent=self):
                    return
                self.program = []
            if self.is_publicity() and not self.invited and not messagebox.askyesno(
                    "Uzaicinātie", "Uz publicitātes pasākumu nav uzaicināts neviens dejotājs — Kabatas Pūrlādē to "
                                   "neviens neredzēs un paziņojumus nesaņems.\n\nVai tomēr saglabāt?", parent=self):
                self.nb.select(2)
                return
        same = [d for d in dates if self.db.q(
            "SELECT COUNT(*) FROM attendance_sessions WHERE session_date=? AND kind=? AND id<>?",
            (d, kind, self.session_id or -1))[0][0]]
        if same:
            listed = ", ".join(show_date(d) for d in same[:10]) + (" …" if len(same) > 10 else "")
            if not messagebox.askyesno("Dublikāts", f"{listed} jau ir notikums ar veidu “{kind}”. "
                                                    "Vai tomēr saglabāt vēl vienu?", parent=self):
                return
        if len(dates) > 1 and not messagebox.askyesno(
                "Atkārtots notikums", f"Tiks izveidoti {len(dates)} notikumi — no {show_date(dates[0])} līdz "
                                      f"{show_date(dates[-1])}. Turpināt?", parent=self):
            return
        bus_price = parse_euro(self.bus_price_text.get()) if self.is_bus() else 0
        if bus_price is None:
            messagebox.showwarning("Autobusa cena", "Autobusa cenu ierakstiet eiro, piemēram, 12 vai 12,50.",
                                   parent=self)
            self.nb.select(0)
            return
        costume_dates = {}
        for k, name in (("costume_issue_date", "Tērpu izsniegšanas"), ("costume_return_date", "Tērpu atgriešanas")):
            text = self.v[k].get().strip()
            costume_dates[k] = parse_date(text) if text else ""
            if costume_dates[k] is None:
                messagebox.showwarning("Datums", f"{name} datumu ierakstiet formā DD.MM.GGGG.", parent=self)
                self.nb.select(0)
                return
        if costume_dates["costume_issue_date"] and costume_dates["costume_return_date"] and \
                costume_dates["costume_return_date"] < costume_dates["costume_issue_date"]:
            messagebox.showwarning("Datums", "Tērpu atgriešanas datums ir agrāks par izsniegšanas datumu.", parent=self)
            self.nb.select(0)
            return
        details = {k: self.v[k].get().strip() for k in DETAIL_FIELDS}
        details.update(costume_dates)
        details["bus_price"] = str(bus_price) if bus_price else ""
        if not self.is_bus():
            self.bus = {}
        details.update({k: times[k] for k in ("arrival_time", "end_time")})
        details["status"] = details["status"] or ST_PLANNED
        details["subkind"] = self.v["subkind"].get() if kind == KIND_EVENT else ""
        details["invited"] = invited_text(self.invited) if self.is_publicity() else ""
        details["for_groups"] = event_groups_text(self.chosen_groups())
        if self.is_publicity():   # answers only from the invited dancers
            self.answers = {d: v for d, v in self.answers.items() if d in self.invited}
        rest = (kind, self.v["title"].get().strip(), times["time"], self.v["notes"].get().strip())
        con = self.db.con
        try:
            # the answers in this window belong to the event on the "Datums" date only;
            # every other event of a series starts with its own, empty answers
            first = parse_date(self.v["date"].get())
            ids = [self.write_event(con, self.session_id if len(dates) == 1 else None, (d,) + rest,
                                    self.details_for(details, first, d), with_answers=d == first)
                   for d in dates]
            con.commit()
        except sqlite3.Error:
            con.rollback()
            raise
        self.session_id = ids[dates.index(first)]   # the "Datums" event is selected in the list afterwards
        self.changed = False
        self.app.refresh(select_event=self.session_id)
        if self.on_saved:
            self.on_saved()
        self.destroy()

    @staticmethod
    def details_for(details, first, day):
        """Repeated events: the costume issue / return dates move together with the event date."""
        if not first or day == first:
            return details
        shift = date.fromisoformat(day) - date.fromisoformat(first)
        result = dict(details)
        for k in DATE_FIELDS:
            if result.get(k):
                result[k] = (date.fromisoformat(result[k]) + shift).isoformat()
        return result

    def write_event(self, con, session_id, data, details, with_answers=True):
        """Insert (session_id None) or update one event with everything in this window; returns its id."""
        if session_id is None:
            session_id = con.execute("INSERT INTO attendance_sessions (session_date, kind, title, start_time, notes) "
                                     "VALUES (?,?,?,?,?)", data).lastrowid
        else:
            con.execute("UPDATE attendance_sessions SET session_date=?, kind=?, title=?, start_time=?, notes=? "
                        "WHERE id=?", data + (session_id,))
        con.execute("INSERT INTO event_details (session_id, " + ", ".join(DETAIL_FIELDS) + ") VALUES (?,"
                    + ",".join("?" * len(DETAIL_FIELDS)) + ") ON CONFLICT(session_id) DO UPDATE SET "
                    + ", ".join(f"{f}=excluded.{f}" for f in DETAIL_FIELDS),
                    [session_id] + [details[f] for f in DETAIL_FIELDS])
        if self.dance_info:  # without Deju pūrs there is nothing to change in the programme
            con.execute("DELETE FROM session_dances WHERE session_id=?", (session_id,))
            con.execute("DELETE FROM event_program WHERE session_id=?", (session_id,))
            con.executemany("INSERT INTO session_dances (session_id, dance_id) VALUES (?,?)",
                            [(session_id, d) for d in self.program])
            con.executemany("INSERT INTO event_program (session_id, dance_id, position) VALUES (?,?,?)",
                            [(session_id, d, i) for i, d in enumerate(self.program)])
        if self.db.has_table("event_costumes"):   # costume types of a publicity event
            con.execute("DELETE FROM event_costumes WHERE session_id=?", (session_id,))
            if details.get("subkind") == SUBKIND_PUBLICITY:
                con.executemany("INSERT INTO event_costumes (session_id, gender, type_name) VALUES (?,?,?)",
                                [(session_id, g, n) for g, names in self.event_costumes.items() for n in names])
        con.execute("DELETE FROM event_participants WHERE session_id=?", (session_id,))
        if not with_answers:
            return session_id
        rows = {d: [a, n.strip(), ""] for d, (a, n) in self.answers.items() if (a or n.strip())}
        for d, mark in self.bus.items():   # autobuss: brauks / nebrauks
            rows.setdefault(d, ["", "", ""])[2] = mark
        con.executemany("INSERT INTO event_participants (session_id, dancer_id, answer, note, bus) VALUES (?,?,?,?,?)",
                        [(session_id, d, a, n, b) for d, (a, n, b) in rows.items() if d in self.dancer_rows])
        return session_id

    def delete(self):
        if getattr(self, "readonly", False) or not piekluve.current().can_edit_event(self.old_groups,
                                                                                     self.old_publicity):
            return piekluve.deny(self, "Šo notikumu jūsu loma nevar dzēst.")
        d = show_date(self.db.q("SELECT session_date FROM attendance_sessions WHERE id=?", (self.session_id,))[0][0])
        marks = self.db.q("SELECT COUNT(*) FROM attendance WHERE session_id=?", (self.session_id,))[0][0]
        text = f"Dzēst notikumu ({d})?"
        if marks:
            text += f"\n\nTiks dzēstas arī {marks} dejotāju apmeklējuma atzīmes Cītības pūrā."
        text += "\n\nJa notikums nenotiks, to var arī neizdzēst, bet mainīt statusu uz “Atcelts”."
        if not messagebox.askyesno("Dzēst", text, parent=self):
            return
        con = self.db.con
        for table in ("attendance", "session_dances", "event_program", "event_participants", "event_details"):
            con.execute(f"DELETE FROM {table} WHERE session_id=?", (self.session_id,))
        con.execute("DELETE FROM attendance_sessions WHERE id=?", (self.session_id,))
        con.commit()
        self.app.refresh()
        if self.on_saved:
            self.on_saved()
        self.destroy()

    def cancel(self):
        if self.changed and not messagebox.askyesno("Nesaglabātas izmaiņas",
                                                    "Aizvērt, nesaglabājot izmaiņas?", parent=self):
            return
        self.destroy()


# --------------------------------------------------------------------------
# Choosing the dances of the programme
# --------------------------------------------------------------------------
class DancePicker(tk.Toplevel):
    def __init__(self, parent, dance_info, selected, on_ok):
        super().__init__(parent)
        self.on_ok = on_ok
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title("Programmas dejas")
        self.geometry("460x560")
        self.transient(parent)
        self.grab_set()
        tk.Label(self, text="Kuras dejas būs programmā?", font=("Georgia", 13, "bold"), bg=CREAM,
                 fg=RED).pack(anchor="w", pady=(0, 6))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Button(btns, text="Gatavs", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        ttk.Button(btns, text="Noņemt visas", command=lambda: [v.set(False) for v in self.vars.values()]).pack(
            side="left")
        box, canvas, inner = scrollable(self)
        box.pack(fill="both", expand=True)
        bind_wheel(self, canvas)

        self.vars = {}
        groups = {g: [] for g in DANCE_GROUPS}
        for did, d in dance_info.items():
            groups.setdefault(d["status"] if d["status"] in groups else DANCE_IN_REPERTOIRE, []).append(
                (did, d["title"], d["duration"]))
        for group, dances in groups.items():
            if not dances:
                continue
            tk.Label(inner, text=group, font=("Segoe UI", 10, "bold"), bg=WHITE,
                     fg=GREY if group in (DANCE_RESTING, DANCE_ARCHIVED) else RED).pack(anchor="w", padx=10,
                                                                                       pady=(8, 2))
            for did, title, dur in sorted(dances, key=lambda r: _norm(r[1])):
                var = tk.BooleanVar(value=did in selected)
                text = title + (f"   ({show_duration(dur)})" if str(dur).isdigit() else "")
                tk.Checkbutton(inner, text=text, variable=var, bg=WHITE, fg=NAVY, activebackground=CREAM,
                               selectcolor=WHITE, anchor="w", font=("Segoe UI", 10), cursor="hand2").pack(
                    fill="x", padx=(22, 10))
                self.vars[did] = var
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.ok())

    def ok(self):
        self.on_ok([did for did, var in self.vars.items() if var.get()])
        self.destroy()


# --------------------------------------------------------------------------
# Text to copy (message for the dancers)
# --------------------------------------------------------------------------
class TextWindow(tk.Toplevel):
    def __init__(self, parent, title, text):
        super().__init__(parent)
        self.configure(bg=CREAM, padx=16, pady=12)
        self.title(title)
        self.geometry("620x560")
        self.transient(parent)
        tk.Label(self, text=title, font=("Georgia", 14, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text="Tekstu var labot. “Kopēt” ieliek to starpliktuvē — ielīmējiet ziņā (Ctrl+V).",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 6))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Button(btns, text="Aizvērt", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="Kopēt", style="Accent.TButton", command=self.copy).pack(side="right", padx=6)
        self.done_lbl = tk.Label(btns, text="", bg=CREAM, fg=GREEN, font=("Segoe UI", 9, "bold"))
        self.done_lbl.pack(side="left")
        self.text = tk.Text(self, wrap="word", bg=WHITE, fg=NAVY, relief="flat", padx=12, pady=10,
                            highlightthickness=1, highlightbackground=GOLD, font=("Segoe UI", 10))
        self.text.pack(fill="both", expand=True)
        self.text.insert("1.0", text)
        self.bind("<Escape>", lambda e: self.destroy())

    def copy(self):
        self.clipboard_clear()
        self.clipboard_append(self.text.get("1.0", "end-1c"))
        self.done_lbl.configure(text="✓ Nokopēts")


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        today = date.today()
        self.cal_month = (today.year, today.month)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
        s.configure("TFrame", background=CREAM)
        s.configure("TLabel", background=CREAM, foreground=NAVY)
        s.configure("TCheckbutton", background=CREAM, foreground=NAVY)
        s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
        s.map("TButton", background=[("active", GOLD)])
        s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Danger.TButton", background=CREAM_DARK, foreground=RED, font=("Segoe UI", 10, "bold"))
        s.map("Danger.TButton", background=[("active", RED)], foreground=[("active", CREAM)])
        s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                    bordercolor=GOLD)
        s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                    padding=6)
        s.map("Treeview.Heading", background=[("active", RED)])
        s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])
        s.configure("TNotebook", background=CREAM, borderwidth=0)
        s.configure("TNotebook.Tab", background=CREAM_DARK, foreground=NAVY, padding=(14, 5),
                    font=("Segoe UI", 10, "bold"))
        s.map("TNotebook.Tab", background=[("selected", NAVY)], foreground=[("selected", CREAM)])
        izskats.apply_style()   # kopīgais izskats (v0.8)

    # ---- layout -----------------------------------------------------------

    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        # Pūrlāde v0.8: baltā moduļa galvene (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = izskats.module_header(
            self.root, "notikumu_purs", PROGRAM_NAME, f"Koncerti, skates, mēģinājumi un pasākumi · v{APP_VERSION}", on_logo=self.show_main,
            on_exit=None if self.on_exit is not None else self.root.destroy)

        # summary cards (always for today / this season, independent of the filters)
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=18, pady=(14, 6))
        self.card_vars, self.card_titles = {}, {}
        for i, (key, title, colour) in enumerate([
                ("next", "Nākamais notikums", PURPLE),
                ("upcoming", "Gaidāmie notikumi", NAVY),
                ("planned", "Vēl neapstiprināti", AMBER),
                ("concerts", "Koncerti šajā sezonā", RED),
                ("reviews", "Skates šajā sezonā", GREEN)]):
            card = tk.Frame(cards, bg=WHITE, highlightbackground=colour, highlightthickness=3)
            card.grid(row=0, column=i, padx=6, sticky="nsew")
            cards.columnconfigure(i, weight=1, uniform="card")
            var, tvar = tk.StringVar(value="—"), tk.StringVar(value=title)
            self.card_vars[key], self.card_titles[key] = var, tvar
            tk.Label(card, textvariable=var, font=("Georgia", 22, "bold"), bg=WHITE, fg=colour).pack(pady=(6, 0))
            tk.Label(card, textvariable=tvar, font=("Segoe UI", 9), bg=WHITE, fg=NAVY, wraplength=190,
                     justify="center").pack(pady=(0, 6), padx=4)

        # filters
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=18, pady=(8, 4))
        self.search = tk.StringVar()
        self.f_period = tk.StringVar(value=PERIOD_UPCOMING)
        self.f_from, self.f_to = tk.StringVar(), tk.StringVar()
        self.f_kind = tk.StringVar(value=ALL)
        self.f_status = tk.StringVar(value=ALL)
        ttk.Label(bar, text="Meklēt:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=16).pack(side="left", padx=(4, 10))
        self.search.trace_add("write", lambda *a: self.refresh())
        ttk.Label(bar, text="Periods:").pack(side="left")
        pcb = ttk.Combobox(bar, textvariable=self.f_period, values=PERIODS, state="readonly", width=17)
        pcb.pack(side="left", padx=(4, 6))
        pcb.bind("<<ComboboxSelected>>", lambda e: self.apply_period_preset())
        ttk.Label(bar, text="no").pack(side="left")
        e_from = ttk.Entry(bar, textvariable=self.f_from, width=11)
        e_from.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_from, on_pick=self.custom_period).pack(side="left", padx=(1, 4))
        ttk.Label(bar, text="līdz").pack(side="left")
        e_to = ttk.Entry(bar, textvariable=self.f_to, width=11)
        e_to.pack(side="left", padx=(4, 0))
        date_picker_button(bar, self.f_to, on_pick=self.custom_period).pack(side="left", padx=(1, 10))
        for e in (e_from, e_to):
            e.bind("<Return>", lambda ev: self.custom_period())
            e.bind("<FocusOut>", lambda ev: self.custom_period())
        ttk.Label(bar, text="Veids:").pack(side="left")
        kcb = ttk.Combobox(bar, textvariable=self.f_kind, values=[ALL] + EVENT_KINDS, state="readonly", width=17)
        kcb.pack(side="left", padx=(4, 10))
        kcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Label(bar, text="Statuss:").pack(side="left")
        scb = ttk.Combobox(bar, textvariable=self.f_status, values=[ALL] + SHOWN_STATUSES, state="readonly",
                           width=12)
        scb.pack(side="left", padx=(4, 10))
        scb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Label(bar, text="Grupa:").pack(side="left")
        self.f_group = tk.StringVar(value=ALL)
        gcb = ttk.Combobox(bar, textvariable=self.f_group, values=[ALL] + DANCER_GROUPS, state="readonly", width=8)
        gcb.pack(side="left", padx=4)
        gcb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        ttk.Button(bar, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")
        self._period_dates_text = ("", "")
        self.apply_period_preset(refresh=False)

        btns = ttk.Frame(self.root)
        btns.pack(fill="x", padx=18, pady=4)
        acc = piekluve.current()
        new_btn = ttk.Button(btns, text="＋ Jauns publicitātes pasākums" if acc.social and not
                             acc.can_edit("notikumu_purs") else "＋ Jauns notikums", style="Accent.TButton",
                             command=lambda: EventWindow(self))
        new_btn.pack(side="left", padx=(0, 6))
        if not (acc.can_edit("notikumu_purs") or acc.social):
            new_btn.configure(state="disabled")
        ttk.Button(btns, text="⇩ Eksportēt notikumus (Excel)", command=self.export).pack(side="left", padx=3)
        if not acc.edits_all("notikumu_purs"):
            if acc.social and not acc.can_edit("notikumu_purs"):
                note = "var veidot un labot tikai publicitātes pasākumus"
            elif acc.view_only("notikumu_purs"):
                note = "tikai skatīšanai" + (" (publicitātes pasākuma tērpus var mainīt)" if acc.costumes else "")
            else:
                note = "labot var " + acc.scope_text("notikumu_purs") + "s notikumus"
            tk.Label(btns, text="🔒 " + note, bg=CREAM, fg=RED,
                     font=("Segoe UI", 9, "bold")).pack(side="left", padx=(12, 0))
        self.count_var = tk.StringVar()
        tk.Label(btns, textvariable=self.count_var, bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(side="right")

        # tabs
        self.n_events, self.n_people, self.event_rows, self.people_rows = (0, 0), 0, [], []
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=18, pady=(6, 6))
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.update_count())

        # 1) events
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Notikumi  ")
        self.e_tree = ttk.Treeview(tab, columns=[c[0] for c in EVENT_COLUMNS], show="headings")
        for key, title, width in EVENT_COLUMNS:
            self.e_tree.heading(key, text=title, command=lambda k=key: self.sort_events(k))
            self.e_tree.column(key, width=width, minwidth=45, anchor="w", stretch=key in ("title", "place"))
        status_colours(self.e_tree)
        self.e_tree.bind("<Double-1>", self.open_event)
        self.e_tree.bind("<Return>", self.open_event)
        make_tree_with_scroll(tab, self.e_tree)
        self.e_sort, self.e_desc = "date", False

        # 2) calendar
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Kalendārs  ")
        nav = ttk.Frame(tab)
        nav.pack(fill="x", pady=(0, 4))
        ttk.Button(nav, text="◀", width=3, command=lambda: self.move_month(-1)).pack(side="left")
        self.month_lbl = tk.Label(nav, text="", font=("Georgia", 13, "bold"), bg=CREAM, fg=RED, width=16)
        self.month_lbl.pack(side="left", padx=6)
        ttk.Button(nav, text="▶", width=3, command=lambda: self.move_month(1)).pack(side="left")
        ttk.Button(nav, text="Šis mēnesis", command=self.this_month).pack(side="left", padx=(10, 0))
        self.show_rehearsals = tk.BooleanVar(value=False)
        ttk.Checkbutton(nav, text="Rādīt arī mēģinājumus", variable=self.show_rehearsals,
                        command=self.fill_calendar).pack(side="left", padx=(14, 0))
        tk.Label(nav, text="Dubultklikšķis uz notikuma — atvērt, uz tukšas dienas — jauns notikums.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(side="right")
        self.cal_grid = tk.Frame(tab, bg=CREAM_DARK)
        self.cal_grid.pack(fill="both", expand=True)

        # 3) dancers
        tab = ttk.Frame(self.nb, padding=(0, 6, 0, 0))
        self.nb.add(tab, text="  Dejotāju dalība  ")
        top = ttk.Frame(tab)
        top.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        self.show_inactive = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Rādīt arī dejotājus uz pauzes un izstājušos", variable=self.show_inactive,
                        command=self.refresh).pack(side="left")
        tk.Label(top, text="Piedalījās = atzīmēts Cītības pūrā (ieradās / nokavēja). Gaidāmie — dejotājs ir "
                           "programmas deju sastāvā vai atbildējis “Būs” / “Varbūt”.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(side="right")
        holder = ttk.Frame(tab)
        holder.grid(row=1, column=0, sticky="nsew")
        tab.rowconfigure(1, weight=1)
        tab.columnconfigure(0, weight=1)
        self.p_tree = ttk.Treeview(holder, columns=[c[0] for c in PEOPLE_COLUMNS], show="headings")
        for key, title, width in PEOPLE_COLUMNS:
            self.p_tree.heading(key, text=title, command=lambda k=key: self.sort_people(k))
            self.p_tree.column(key, width=width, minwidth=45,
                               anchor="w" if key in ("first_name", "last_name", "status") else "center",
                               stretch=False)
        self.p_tree.tag_configure("inactive", foreground=GREY)
        self.p_tree.bind("<Double-1>", self.open_dancer)
        self.p_tree.bind("<Return>", self.open_dancer)
        make_tree_with_scroll(holder, self.p_tree)
        self.p_sort, self.p_desc = "last_name", False

        self.refresh()

    # ---- filters ------------------------------------------------------------
    def apply_period_preset(self, refresh=True):
        name = self.f_period.get()
        if name == PERIOD_CUSTOM:
            return
        start, end = period_dates(name)
        self.f_from.set(show_date(start.isoformat()) if start else "")
        self.f_to.set(show_date(end.isoformat()) if end else "")
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        self.e_sort_default()
        if refresh:
            self.refresh()

    def e_sort_default(self):
        """Upcoming events: nearest first; other periods: newest first."""
        self.e_sort = "date"
        self.e_desc = self.f_period.get() != PERIOD_UPCOMING

    def custom_period(self):
        if (self.f_from.get(), self.f_to.get()) == self._period_dates_text:
            return
        for var in (self.f_from, self.f_to):
            if parse_date(var.get()) is None:
                messagebox.showwarning("Periods", "Datumu raksta formā DD.MM.GGGG.", parent=self.root)
                var.set(self._period_dates_text[0 if var is self.f_from else 1])
                return
        self._period_dates_text = (self.f_from.get(), self.f_to.get())
        self.f_period.set(PERIOD_CUSTOM)
        self.refresh()

    def group_filter(self, events):
        """Events for the group chosen in the filter "Grupa" (an event without groups is for all)."""
        group = self.f_group.get() if hasattr(self, "f_group") else ALL
        if group == ALL:
            return events
        return [e for e in events if in_event_groups(group, e.get("for_groups", ""))]

    def filters(self):
        start = parse_date(self.f_from.get()) or "0000-01-01"
        end = parse_date(self.f_to.get()) or "9999-12-31"
        kind = self.f_kind.get()
        status = self.f_status.get()
        return start, end, (None if kind == ALL else kind), (None if status == ALL else status)

    def period_text(self):
        a, b = self.f_from.get().strip(), self.f_to.get().strip()
        if not a and not b:
            return PERIOD_ALL.lower()
        return f"{a or '…'} – {b or '…'}"

    def clear_filters(self):
        self.search.set("")
        self.f_kind.set(ALL)
        self.f_status.set(ALL)
        self.f_group.set(ALL)
        self.f_period.set(PERIOD_UPCOMING)
        self.show_inactive.set(False)
        self.apply_period_preset()

    def show_main(self):
        """Module logo: back to the main view — upcoming events, no filters, first tab."""
        self.clear_filters()
        self.nb.select(0)
        self.e_tree.selection_remove(self.e_tree.selection())
        self.e_tree.yview_moveto(0)

    # ---- data -------------------------------------------------------------
    def refresh(self, select_event=None):
        start, end, kind, status = self.filters()
        events = self.db.events(start, end, [kind] if kind else EVENT_KINDS)
        if status:
            events = [e for e in events if e["shown_status"] == status]
        events = self.group_filter(events)
        ids = [e["id"] for e in events]
        programs = self.db.programs(ids)
        answers = self.db.answers(ids)
        marks = self.db.marks(ids)
        casts = self.db.cast_map()
        self.fill_events(events, programs, answers, marks, casts, select_event)
        self.fill_people(events, programs, answers, marks, casts)
        self.update_cards()
        self.fill_calendar()
        self.update_count()

    def fill_events(self, events, programs, answers, marks, casts, select=None):
        term = _norm(self.search.get())
        today = date.today().isoformat()
        active = {r[0] for r in self.db.dancers()}
        group_of = self.db.dancer_groups()
        rows = []
        for ev in events:
            program = programs.get(ev["id"], [])
            prog_titles = " ".join(t for _d, t, _du in program)
            if term and term not in _norm(f"{ev['kind']} {ev['subkind']} {ev['title']} {ev['place']} {ev['address']} "
                                          f"{ev['organizer']} {show_date(ev['date'])} {prog_titles}"):
                continue
            total, _missing = program_seconds(program)
            prog_text = (f"{len(program)} dejas, {show_total(total)}" if total else f"{len(program)} dejas") \
                if program else "—"
            ev_marks = marks.get(ev["id"], {})
            ans = answers.get(ev["id"], {})
            if ev["date"] <= today and ev_marks:
                came = sum(1 for m in ev_marks.values() if m in CAME)
                people = f"ieradās {came}"
                people_n = came
            else:
                cast = set()
                for did, _t, _du in program:
                    cast |= casts.get(did, set())
                involved = event_audience(ev, cast, active, group_of)
                if not is_publicity_event(ev):
                    involved |= {d for d, (a, _n) in ans.items() if a}
                yes = sum(1 for d in involved if ans.get(d, ("", ""))[0] == ANS_YES)
                people = f"būs {yes} / {len(involved)}" if involved else "—"
                people_n = yes
            r = dict(ev)
            r.update({"weekday": weekday(ev["date"]), "program": prog_text, "program_n": len(program),
                      "people": people, "people_n": people_n, "status": ev["shown_status"]})
            rows.append(r)

        rows.sort(key=lambda r: (r["date"], r["time"], r["id"]), reverse=self.e_desc if self.e_sort == "date"
                  else False)
        if self.e_sort != "date":
            key = {"program": "program_n", "people": "people_n"}.get(self.e_sort, self.e_sort)
            rows = sort_rows(rows, key, self.e_desc)
        keep = select or (self.e_tree.selection()[0] if self.e_tree.selection() else None)
        self.e_tree.delete(*self.e_tree.get_children())
        for r in rows:
            self.e_tree.insert("", "end", iid=str(r["id"]), tags=(STATUS_TAG.get(r["status"], "confirmed"),), values=(
                show_date(r["date"]), r["weekday"], r["time"], kind_text(r), groups_short(r["for_groups"]),
                r["title"], r["place"], r["status"],
                r["program"], r["people"]))
        if keep is not None and self.e_tree.exists(str(keep)):
            self.e_tree.selection_set(str(keep))
            self.e_tree.see(str(keep))
        self.event_rows = rows
        self.n_events = (len(rows), len(events))

    def fill_people(self, events, programs, answers, marks, casts):
        today = date.today().isoformat()
        active = {r[0] for r in self.db.dancers()}
        group_of = self.db.dancer_groups()
        stats = {}

        def st(did):
            return stats.setdefault(did, {"concerts": 0, "reviews": 0, "events": 0, "upcoming": 0, "declined": 0})
        for ev in events:
            if ev["status"] == ST_CANCELLED:
                continue
            sid = ev["id"]
            if ev["date"] < today or (ev["date"] == today and marks.get(sid)):
                for did, mark in marks.get(sid, {}).items():
                    if mark in CAME:
                        key = {KIND_CONCERT: "concerts", KIND_REVIEW: "reviews"}.get(ev["kind"], "events")
                        st(did)[key] += 1
            else:
                cast = set()
                for dance_id, _t, _d in programs.get(sid, []):
                    cast |= casts.get(dance_id, set())
                cast = event_audience(ev, cast, active, group_of)
                ans = answers.get(sid, {})
                for did in cast | (set() if is_publicity_event(ev) else set(ans)):
                    a = ans.get(did, ("", ""))[0]
                    if a == ANS_NO:
                        st(did)["declined"] += 1
                    elif did in cast or a in (ANS_YES, ANS_MAYBE):
                        st(did)["upcoming"] += 1
        show_all = self.show_inactive.get()
        term = _norm(self.search.get())
        rows = []
        for did, first, last, status in self.db.q("SELECT id, first_name, last_name, status FROM dancers WHERE "
                                                  + dancer_role_sql("dancers")):
            status = status or STATUS_ACTIVE
            s = stats.get(did, {"concerts": 0, "reviews": 0, "events": 0, "upcoming": 0, "declined": 0})
            if status != STATUS_ACTIVE and not show_all:
                continue
            if term and term not in _norm(f"{first} {last}"):
                continue
            r = {"id": did, "first_name": first or "", "last_name": last or "", "status": status}
            r.update(s)
            r["total"] = s["concerts"] + s["reviews"] + s["events"]
            rows.append(r)
        rows.sort(key=lambda r: (_norm(r["last_name"]), _norm(r["first_name"])))
        rows = sort_rows(rows, self.p_sort, self.p_desc)
        keep = self.p_tree.selection()[0] if self.p_tree.selection() else None
        self.p_tree.delete(*self.p_tree.get_children())
        for r in rows:
            self.p_tree.insert("", "end", iid=str(r["id"]), tags=("inactive",) if r["status"] != STATUS_ACTIVE else (),
                               values=[r[k] if r[k] != 0 else "—" for k, _t, _w in PEOPLE_COLUMNS])
        if keep is not None and self.p_tree.exists(keep):
            self.p_tree.selection_set(keep)
        self.people_rows = rows
        self.n_people = len(rows)

    def update_cards(self):
        today = date.today()
        iso = today.isoformat()
        s_start, s_end = season_of(today)
        upcoming = [e for e in self.db.events(iso) if e["status"] != ST_CANCELLED]
        upcoming.sort(key=lambda e: (e["date"], e["time"] or "99:99", e["id"]))
        if upcoming:
            nxt = upcoming[0]
            self.card_vars["next"].set(show_date(nxt["date"])[:6] + (f" {nxt['time']}" if nxt["time"] else ""))
            name = nxt["title"] or kind_text(nxt)
            self.card_titles["next"].set(f"{name} · {days_until_text(nxt['date'])}")
        else:
            self.card_vars["next"].set("—")
            self.card_titles["next"].set("Nākamais notikums")
        self.card_vars["upcoming"].set(str(len(upcoming)))
        self.card_vars["planned"].set(str(sum(1 for e in upcoming if e["status"] == ST_PLANNED)))
        season = [e for e in self.db.events(s_start.isoformat(), iso) if e["status"] != ST_CANCELLED]
        self.card_vars["concerts"].set(str(sum(1 for e in season if e["kind"] == KIND_CONCERT)))
        self.card_vars["reviews"].set(str(sum(1 for e in season if e["kind"] == KIND_REVIEW)))

    def update_count(self):
        try:
            tab = self.nb.index(self.nb.select())
        except tk.TclError:
            tab = 0
        if tab == 0:
            text = (f"Rādīti {self.n_events[0]} no {self.n_events[1]} notikumiem. "
                    "Dubultklikšķis — atvērt; klikšķis uz virsraksta — kārtot.")
        elif tab == 1:
            text = "Kalendārā redzami koncerti, skates un kolektīva pasākumi."
        else:
            text = (f"Rādīti {self.n_people} dejotāji, periods: {self.period_text()}. "
                    "Dubultklikšķis — dejotāja notikumi.")
        self.count_var.set(text)

    def sort_events(self, key):
        self.e_desc = not self.e_desc if key == self.e_sort else key in ("program", "people")
        self.e_sort = key
        self.refresh()

    def sort_people(self, key):
        numeric = key in ("concerts", "reviews", "events", "total", "upcoming", "declined")
        self.p_desc = not self.p_desc if key == self.p_sort else numeric
        self.p_sort = key
        self.refresh()

    # ---- calendar -------------------------------------------------------------
    def move_month(self, step):
        y, m = self.cal_month
        m += step
        y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
        self.cal_month = (y, m)
        self.fill_calendar()

    def this_month(self):
        today = date.today()
        self.cal_month = (today.year, today.month)
        self.fill_calendar()

    def fill_calendar(self):
        for child in self.cal_grid.winfo_children():
            child.destroy()
        y, m = self.cal_month
        self.month_lbl.configure(text=f"{MONTHS[m - 1]} {y}")
        start = f"{y:04d}-{m:02d}-01"
        end = f"{y:04d}-{m:02d}-{calendar.monthrange(y, m)[1]:02d}"
        _s, _e, kind, _status = self.filters()
        kinds = [kind] if kind else list(EVENT_KINDS)
        if self.show_rehearsals.get():
            kinds += list(REHEARSAL_KINDS)
        by_day = {}
        for ev in self.group_filter(self.db.events(start, end, kinds)):
            by_day.setdefault(ev["date"], []).append(ev)
        for evs in by_day.values():
            evs.sort(key=lambda e: (e["time"] or "99:99", e["id"]))
        today = date.today().isoformat()

        for c, name in enumerate(WEEKDAYS_FULL):
            tk.Label(self.cal_grid, text=name, bg=NAVY, fg=CREAM, font=("Segoe UI", 9, "bold"), pady=4).grid(
                row=0, column=c, sticky="nsew", padx=1, pady=(0, 1))
            self.cal_grid.columnconfigure(c, weight=1, uniform="cal")
        weeks = calendar.monthcalendar(y, m)
        for r in range(6):
            self.cal_grid.rowconfigure(r + 1, weight=1 if r < len(weeks) else 0, uniform="calrow"
                                       if r < len(weeks) else "")
        for r, week in enumerate(weeks, 1):
            for c, d in enumerate(week):
                if not d:
                    tk.Frame(self.cal_grid, bg=CREAM).grid(row=r, column=c, sticky="nsew", padx=1, pady=1)
                    continue
                iso = f"{y:04d}-{m:02d}-{d:02d}"
                is_today = iso == today
                cell = tk.Frame(self.cal_grid, bg=WHITE, highlightthickness=2 if is_today else 0,
                                highlightbackground=GOLD)
                cell.grid(row=r, column=c, sticky="nsew", padx=1, pady=1)
                num = tk.Label(cell, text=str(d), bg=GOLD if is_today else WHITE,
                               fg=RED if c >= 5 else NAVY, font=("Segoe UI", 10, "bold"), anchor="w", padx=4)
                num.pack(fill="x")
                for w in (cell, num):
                    w.bind("<Double-1>", lambda e, day=iso: EventWindow(self, day=date.fromisoformat(day)))
                for ev in by_day.get(iso, []):
                    rehearsal = ev["kind"] in REHEARSAL_KINDS
                    cancelled = ev["status"] == ST_CANCELLED
                    text = (f"{ev['time']} " if ev["time"] else "") + (ev["title"] or kind_text(ev))
                    if cancelled:
                        text = "✗ " + text
                    elif ev["status"] == ST_PLANNED and not rehearsal:
                        text = "? " + text
                    lbl = tk.Label(cell, text=text, bg=KIND_TINT.get(ev["kind"], CREAM_DARK),
                                   fg=GREY if (cancelled or rehearsal) else KIND_COLOUR.get(ev["kind"], NAVY),
                                   font=("Segoe UI", 8, "overstrike" if cancelled else "bold"), anchor="w",
                                   justify="left", padx=3, cursor="hand2")
                    lbl.pack(fill="x", padx=2, pady=1)
                    lbl.bind("<Configure>", lambda e, w=lbl: w.configure(wraplength=max(40, e.width - 6)))
                    if rehearsal:
                        lbl.bind("<Double-1>", lambda e: messagebox.showinfo(
                            "Mēģinājums", "Mēģinājumi tiek ievadīti un laboti Cītības pūrā.", parent=self.root))
                    else:
                        lbl.bind("<Double-1>", lambda e, sid=ev["id"]: EventWindow(self, sid))
        legend = tk.Frame(self.cal_grid, bg=CREAM)
        legend.grid(row=7, column=0, columnspan=7, sticky="ew", pady=(4, 0))
        for k in EVENT_KINDS:
            tk.Label(legend, text=f"  {k}  ", bg=KIND_TINT[k], fg=KIND_COLOUR[k],
                     font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))
        tk.Label(legend, text="?  iecerēts (neapstiprināts)    ✗  atcelts", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(8, 0))

    # ---- actions ------------------------------------------------------------
    def open_event(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.e_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.e_tree.selection()
        if sel:
            EventWindow(self, int(sel[0]))

    def open_dancer(self, event=None):
        if event is not None and event.type == tk.EventType.ButtonPress and \
                self.p_tree.identify_region(event.x, event.y) == "heading":
            return
        sel = self.p_tree.selection()
        if sel:
            DancerEvents(self, int(sel[0]))

    def export(self):
        if not self.event_rows:
            messagebox.showinfo("Eksports", "Nav notikumu, ko eksportēt.", parent=self.root)
            return
        today = show_date(date.today().isoformat())
        path = filedialog.asksaveasfilename(parent=self.root, title="Saglabāt notikumu sarakstu",
                                            defaultextension=".csv", initialfile=f"Notikumi {today}.csv",
                                            filetypes=[("Excel / CSV", "*.csv")])
        if not path:
            return
        programs = self.db.programs(r["id"] for r in self.event_rows)
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as fh:
                w = csv.writer(fh, delimiter=";")
                w.writerow([f"{PROGRAM_NAME} — notikumi", f"Periods: {self.period_text()}", f"Sagatavots: {today}"])
                w.writerow([])
                w.writerow(["Datums", "Diena", "Sākums", "Ierašanās", "Beigas", "Veids", "Grupa", "Nosaukums", "Statuss",
                            "Vieta", "Adrese", "Organizators", "Kontaktpersona", "Transports", "Honorārs / maksa",
                            "Programma", "Programmas ilgums", "Dalībnieki", "Tērpu piezīmes", "Tērpu izsniegšana",
                            "Tērpi jāatgriež", "Piezīmes"])
                for r in self.event_rows:
                    program = programs.get(r["id"], [])
                    total, _m = program_seconds(program)
                    w.writerow([show_date(r["date"]), weekday(r["date"], full=True), r["time"], r["arrival_time"],
                                r["end_time"], kind_text(r), groups_label(r["for_groups"]), r["title"], r["status"],
                                r["place"], r["address"],
                                r["organizer"], r["contact"], r["transport"], r["fee"],
                                ", ".join(t for _d, t, _du in program), show_total(total) if total else "",
                                r["people"] if r["people"] != "—" else "", r["costume_notes"],
                                show_date(r["costume_issue_date"]), show_date(r["costume_return_date"]), r["notes"]])
        except OSError as exc:
            messagebox.showerror("Eksports", f"Neizdevās saglabāt failu:\n{exc}", parent=self.root)
            return
        messagebox.showinfo("Eksports", f"Saraksts saglabāts:\n{path}\n\nFailu var atvērt ar Excel.",
                            parent=self.root)


# --------------------------------------------------------------------------
# One dancer: events in the chosen period
# --------------------------------------------------------------------------
class DancerEvents(tk.Toplevel):
    def __init__(self, app, dancer_id):
        super().__init__(app.root)
        self.app, self.dancer_id = app, dancer_id
        self.configure(bg=CREAM, padx=16, pady=12)
        self.geometry("820x520")
        self.transient(app.root)
        name = app.db.q("SELECT name FROM dancers WHERE id=?", (dancer_id,))[0][0]
        self.title(f"Notikumi — {name}")
        tk.Label(self, text=name, font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        self.summary = tk.Label(self, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 10), justify="left")
        self.summary.pack(anchor="w", pady=(2, 8))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(side="bottom", fill="x", pady=(8, 0))
        ttk.Button(btns, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        tk.Label(btns, text="Dubultklikšķis uz rindas atver notikumu.", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 9, "italic")).pack(side="left")
        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        cols = [("date", "Datums", 95), ("kind", "Veids", 130), ("title", "Nosaukums", 200),
                ("dances", "Dejas", 220), ("answer", "Atbilde", 80), ("mark", "Cītības pūrā", 100)]
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=key in ("title", "dances"))
        status_colours(self.tree)
        self.tree.bind("<Double-1>", self.open_event)
        make_tree_with_scroll(holder, self.tree)
        self.bind("<Escape>", lambda e: self.destroy())
        self.fill()

    def fill(self):
        if not self.winfo_exists():
            return
        start, end, kind, _status = self.app.filters()
        db = self.app.db
        events = db.events(start, end, [kind] if kind else EVENT_KINDS)
        ids = [e["id"] for e in events]
        programs, answers, marks = db.programs(ids), db.answers(ids), db.marks(ids)
        casts = db.cast_map()
        self.tree.delete(*self.tree.get_children())
        n = came = 0
        for ev in sorted(events, key=lambda e: (e["date"], e["time"]), reverse=True):
            sid = ev["id"]
            dances = [t for d, t, _du in programs.get(sid, []) if self.dancer_id in casts.get(d, set())]
            ans = answers.get(sid, {}).get(self.dancer_id, ("", ""))[0]
            mark = marks.get(sid, {}).get(self.dancer_id, "")
            invited = is_publicity_event(ev) and self.dancer_id in invited_ids(ev["invited"])
            if not (dances or ans or mark or invited):
                continue
            n += 1
            came += mark in CAME
            self.tree.insert("", "end", iid=str(sid), tags=(STATUS_TAG.get(ev["shown_status"], "confirmed"),),
                             values=(show_date(ev["date"]), kind_text(ev), ev["title"], ", ".join(dances), ans, mark))
        self.summary.configure(text=f"Periods: {self.app.period_text()}\n"
                                    f"Notikumi, kuros dejotājs ir iesaistīts: {n}  ·  piedalījās (Cītības pūrā): {came}")

    def open_event(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            EventWindow(self.app, int(row), on_saved=self.fill)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
