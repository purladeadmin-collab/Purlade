"""
Pūrlāde — “Pārbaudīt programmu” (Izstrādes darbi → “▶ Pārbaudīt programmu”, Pūrlāde v0.9.6)

Automātiska pārbaude pirms jaunas versijas izlaišanas. Katrai lomai (pašu skats un katra “Skatīt kā” loma) tā:
    * atver katru moduli, ko loma drīkst atvērt, un katru tā cilni;
    * atver galvenos logus (notikums, dejotājs, deja, tērps, maksājums …) — esošam ierakstam un jaunam;
    * atver Kolektīva vēsturi, Sezonas pārskatu (un pilnām tiesībām — Administrēšanu, Rezerves kopijas);
    * pārbauda, vai nerodas kļūdas un vai logu apakšējās pogas ir redzamas — arī mazā ekrānā (1366×768,
      klēpjdators), ja tas atzīmēts.
Pārbaudes laikā NEKAS netiek saglabāts (datubaze.PREVIEW — kā “Skatīt kā”), jautājumi tiek atbildēti ar “Nē”,
ziņojumi netiek rādīti. Beigās — saraksts: kas kārtībā, kas ne (problēmas augšā); to var nokopēt.
"""

import time
import traceback
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:
    from moduli import kopeja as K
    from moduli import datubaze as D
    from moduli import izskats, piekluve, aizversana
except ImportError:  # started from inside the moduli folder
    import kopeja as K
    import datubaze as D
    import izskats
    import piekluve
    import aizversana

SMALL_SCREEN = (0, 0, 1366, 728)   # 1366×768 without a 40 px taskbar
OK, PROBLEM, SKIPPED = "kārtībā", "PROBLĒMA", "izlaists"


# --------------------------------------------------------------------------
# Sample records and the windows to open
# --------------------------------------------------------------------------
def sample_ids():
    con = K.connect_db()

    def first(sql, params=()):
        try:
            row = con.execute(sql, params).fetchone()
            return row[0] if row else None
        except Exception:
            return None
    ids = {"dancer": first("SELECT MIN(id) FROM dancers WHERE " + K.active_dancer_sql("dancers")),
           "dance": first("SELECT MIN(id) FROM dances"),
           "piece": first("SELECT MIN(id) FROM costume_pieces"),
           "event": first("SELECT MAX(id) FROM attendance_sessions WHERE kind IN (?, ?, ?)",
                          ("Koncerts", "Skate", K.EVENT_KIND_GROUP)),
           "session": first("SELECT MAX(id) FROM attendance_sessions WHERE kind IN (?, ?)",
                            ("Mēģinājums", "Papildmēģinājums")),
           "entry": first("SELECT MAX(id) FROM fin_entries"),
           "creative": first("SELECT MIN(id) FROM creative_works")}
    try:
        con.close()
    except Exception:
        pass
    return ids


def openers(key, m, ids):
    """[(name, function)] — windows of a module (m — the module's App; its Python module is found from it)."""
    mod = __import__(type(m).__module__, fromlist=["x"])

    def cls(name):
        return getattr(mod, name, None)
    out = []

    def add(name, class_name, *args, need=None):
        c = cls(class_name)
        if c is None or (need is not None and ids.get(need) is None):
            return
        out.append((name, lambda c=c, a=args: c(m, *[ids.get(x[1:]) if isinstance(x, str) and x.startswith("@")
                                                     else x for x in a])))
    if key == "terpu_purs":
        add("Tērps", "PieceForm", "@piece", need="piece")
        add("Jauns tērps", "PieceForm")
        add("Tērpu saraksti", "CatalogAdminWindow")
        add("Pārskata iestatījumi", "MainSettingsWindow")
    elif key == "deju_purs":
        add("Deja", "DanceForm", "@dance", need="dance")
        add("Jauna deja", "DanceForm")
        add("Dejas sastāvs", "CastWindow", "@dance", need="dance")
    elif key == "kopas_purs":
        add("Dejotājs", "DancerForm", "@dancer", need="dancer")
        add("Jauns dejotājs", "DancerForm")
    elif key == "notikumu_purs":
        add("Notikums", "EventWindow", "@event", need="event")
        add("Jauns notikums", "EventWindow")
        add("Dejotāja notikumi", "DancerEvents", "@dancer", need="dancer")
    elif key == "citibas_purs":
        add("Mēģinājums ar atzīmēm", "SessionWindow", "@session", need="session")
        add("Jauns mēģinājums", "SessionWindow")
        add("Dejotāja cītība", "DancerHistory", "@dancer", need="dancer")
    elif key == "zelta_purs":
        add("Darījums", "EntryForm", "@entry", need="entry")
        add("Jauns ienākums", "EntryForm")
        add("Dalības maksa", "FeePaymentForm")
        add("Tērpu fonda maksa", "CostumePaymentForm")
        add("Dalības maksu apmēri", "FeeRatesWindow")
        add("Tērpu fonda apmēri", "CostumeRatesWindow")
        add("Sākuma atlikums", "OpeningWindow")
        add("Kategorijas", "CategoriesWindow")
    elif key == "jaunrades_purs":
        add("Apzīmējumi", "LegendWindow")
        if ids.get("creative") is not None and hasattr(m, "open_editor"):
            out.append(("Apraksta redaktors", lambda: m.open_editor(ids["creative"])))
    return out


# --------------------------------------------------------------------------
# The check
# --------------------------------------------------------------------------
class Checker:
    def __init__(self, app, small_screen=True, progress=None):
        self.app, self.root = app, app.root
        self.small = small_screen
        self.progress = progress or (lambda text: None)
        self.results = []          # (role, place, result, note)
        self.errors = []           # exceptions in Tk callbacks while one place is checked
        self.messages = []

    # ---- safety: nothing saved, no questions, no messages ------------------------------
    def patch(self):
        self.saved = {
            "mb": {n: getattr(messagebox, n) for n in ("showinfo", "showwarning", "showerror", "askyesno",
                                                       "askokcancel", "askyesnocancel", "askquestion")},
            "fd": {n: getattr(filedialog, n) for n in ("askopenfilename", "asksaveasfilename", "askdirectory",
                                                       "askopenfilenames")},
            "ask_close": aizversana.ask_close, "report": self.root.report_callback_exception,
            "preview": D.PREVIEW["on"], "notify": D.PREVIEW["notify"], "work_area": izskats.work_area,
            "role": self.app.access.preview_role}
        for n in ("showinfo", "showwarning", "showerror"):
            setattr(messagebox, n, lambda title="", message="", **k: self.messages.append(f"{title}: {message}"[:200]))
        messagebox.askyesno = lambda *a, **k: False
        messagebox.askokcancel = lambda *a, **k: False
        messagebox.askyesnocancel = lambda *a, **k: None
        messagebox.askquestion = lambda *a, **k: "no"
        for n in ("askopenfilename", "asksaveasfilename", "askdirectory"):
            setattr(filedialog, n, lambda *a, **k: "")
        filedialog.askopenfilenames = lambda *a, **k: ()
        aizversana.ask_close = lambda *a, **k: "discard"
        def report(exc, val, tb):
            self.errors.append("".join(traceback.format_exception_only(exc, val)).strip())
            self.details.append("".join(traceback.format_exception(exc, val, tb)))
        self.details = []
        self.root.report_callback_exception = report
        if self.small:
            izskats.work_area = lambda win: SMALL_SCREEN

    def unpatch(self):
        for n, f in self.saved["mb"].items():
            setattr(messagebox, n, f)
        for n, f in self.saved["fd"].items():
            setattr(filedialog, n, f)
        aizversana.ask_close = self.saved["ask_close"]
        self.root.report_callback_exception = self.saved["report"]
        izskats.work_area = self.saved["work_area"]
        D.PREVIEW["notify"] = self.saved["notify"]

    def no_saving(self):
        D.PREVIEW["on"] = True
        D.PREVIEW["notify"] = None

    # ---- helpers ------------------------------------------------------------------------
    def settle(self, rounds=6):
        for _ in range(rounds):
            try:
                self.root.update()
            except tk.TclError:
                pass
            time.sleep(0.03)

    def toplevels(self):
        out, stack = [], [self.root]
        while stack:
            w = stack.pop()
            try:
                children = w.winfo_children()
            except tk.TclError:
                continue
            for c in children:
                if isinstance(c, tk.Toplevel):
                    out.append(c)
                stack.append(c)
        return out

    def close_new(self, before):
        for w in self.toplevels():
            if w not in before and not getattr(w, "keep_open", False):
                try:
                    w.destroy()
                except tk.TclError:
                    pass
        self.settle(2)

    def bottom_limit(self):
        left, top, right, bottom = (SMALL_SCREEN if self.small else self.saved["work_area"](self.root))
        return bottom

    def buttons_hidden(self, win):
        """Footer buttons (not those in scrolled lists) that are below the visible screen."""
        limit = self.bottom_limit()
        hidden = []
        stack = [win]
        while stack:
            w = stack.pop()
            try:
                stack.extend(c for c in w.winfo_children() if not isinstance(c, (tk.Toplevel, tk.Canvas)))
                if w.winfo_class() in ("Button", "TButton") and w.winfo_viewable():
                    if w.winfo_rooty() + w.winfo_height() > limit:
                        hidden.append(str(w.cget("text")).strip() or "?")
            except tk.TclError:
                pass
        return hidden

    def record(self, role, place, note=""):
        errors, self.errors = self.errors, []
        if errors:
            self.results.append((role, place, PROBLEM, "kļūda: " + errors[0] + (f" (+{len(errors) - 1})"
                                                                                  if len(errors) > 1 else "")))
        elif note:
            self.results.append((role, place, PROBLEM, note))
        else:
            self.results.append((role, place, OK, ""))

    def check_window(self, role, place, open_fn):
        before = self.toplevels()
        try:
            open_fn()
        except Exception as exc:
            self.errors.append(f"{type(exc).__name__}: {exc}")
        self.settle(18)   # > 0.5 s: windows are fitted to the screen 60 ms and 350 ms after they appear
        note = ""
        for w in self.toplevels():
            if w in before or getattr(w, "keep_open", False):
                continue
            try:
                if not w.winfo_viewable():
                    continue
            except tk.TclError:
                continue
            hidden = self.buttons_hidden(w)
            if hidden:
                note = f"pogas zem uzdevumjoslas: {', '.join(hidden[:4])}"
        self.record(role, place, note)
        self.close_new(before)

    # ---- the run ------------------------------------------------------------------------
    def roles(self):
        out = [None]
        if piekluve.can_preview():
            out += list(piekluve.PREVIEW_ROLES)
        return out

    def run(self):
        self.patch()
        try:
            ids = sample_ids()
            for role in self.roles():
                label = role or "Mans skats"
                self.progress(f"{label}…")
                try:
                    self.app.view_as(role)
                except Exception as exc:
                    self.errors.append(f"{type(exc).__name__}: {exc}")
                self.no_saving()
                self.settle(4)
                self.record(label, "Sākuma lapa")
                acc = piekluve.current()
                for m in self.app.modules:
                    key = m.file_name
                    if not acc.can_open(key) or not m.ready:
                        continue
                    name = m.info["name"]
                    self.progress(f"{label} · {name}…")
                    try:
                        self.app.open_module_key(key)
                    except Exception as exc:
                        self.errors.append(f"{type(exc).__name__}: {exc}")
                    self.settle(6)
                    module_app = self.app.active
                    if module_app is None:
                        self.record(label, name, "modulis neatvērās")
                        continue
                    self.record(label, name)
                    tabbar = getattr(getattr(module_app, "header_right", None), "tabs", None)
                    for tab_key, tab_label, _line in list(getattr(tabbar, "tabs", []) or []):
                        try:
                            tab_label.event_generate("<Button-1>", x=2, y=2)
                        except tk.TclError as exc:
                            self.errors.append(str(exc))
                        self.settle(6)
                        self.record(label, f"{name} → {tab_label.cget('text')}")
                    for place, fn in openers(key, module_app, ids):
                        self.progress(f"{label} · {name} · {place}…")
                        self.check_window(label, f"{name} → logs “{place}”", fn)
                    self.app.show_home()
                    self.settle(3)
                self.check_window(label, "Kolektīva vēsture", self.app.open_history)
                if hasattr(self.app, "open_season_report"):
                    self.check_window(label, "Sezonas pārskats", self.app.open_season_report)
                if acc.full and role is None:
                    try:
                        from moduli import rezerves_kopijas
                    except ImportError:
                        import rezerves_kopijas
                    self.check_window(label, "Rezerves kopijas", lambda: rezerves_kopijas.show(
                        self.root, version=""))
        finally:
            try:
                self.app.view_as(self.saved["role"])
            except Exception:
                K.log_error(traceback.format_exc())
            self.unpatch()
            D.PREVIEW["on"] = piekluve.previewing()
        return self.results


# --------------------------------------------------------------------------
# Windows: “running …” and the results
# --------------------------------------------------------------------------
def run(app, small_screen=True):
    root = app.root
    wait = tk.Toplevel(root)
    wait.keep_open = True
    wait.title("Pārbaude")
    wait.configure(bg=K.WHITE, padx=24, pady=18)
    wait.transient(root)
    tk.Label(wait, text="Pūrlāde tiek pārbaudīta…", bg=K.WHITE, fg=K.NAVY, font=("Georgia", 14, "bold")).pack(
        anchor="w")
    tk.Label(wait, text="Tiek atvērti visi moduļi, cilnes un logi ar katru lomu. Nekas netiek saglabāts. "
                        "Nespiediet neko, kamēr pārbaude nav beigusies.", bg=K.WHITE, fg=izskats.MUTED,
             font=izskats.FONT_SMALL, wraplength=420, justify="left").pack(anchor="w", pady=(4, 10))
    status = tk.Label(wait, text="", bg=K.WHITE, fg=K.NAVY, font=izskats.FONT_SMALL, anchor="w", width=60)
    status.pack(anchor="w")
    wait.update()

    def progress(text):
        try:
            status.configure(text=text)
            wait.lift()
        except tk.TclError:
            pass
    started = time.time()
    try:
        results = Checker(app, small_screen, progress).run()
    except Exception:
        K.log_error(traceback.format_exc())
        results = [("—", "Pārbaude", PROBLEM, "pārbaude apstājās: " + traceback.format_exc().splitlines()[-1])]
    try:
        wait.destroy()
    except tk.TclError:
        pass
    problems = [r for r in results if r[2] == PROBLEM]
    if problems:
        K.log_error("Pārbaude: " + "; ".join(f"{r[0]} / {r[1]}: {r[3]}" for r in problems[:30]))
    return ResultsWindow(root, results, time.time() - started, small_screen)


class ResultsWindow(tk.Toplevel):
    def __init__(self, root, results, seconds, small_screen):
        super().__init__(root)
        self.results = results
        self.title("Pārbaudes rezultāti")
        self.geometry("980x640")
        self.configure(bg=K.CREAM)
        self.transient(root)
        problems = [r for r in results if r[2] == PROBLEM]
        roles = len({r[0] for r in results})
        colour = K.RED if problems else izskats.OK_FG
        izskats.dialog_header(self, "✓ Viss kārtībā" if not problems else f"⚠ Atrastas {len(problems)} problēmas",
                              f"Pārbaudītas {len(results)} vietas ar {roles} lomām {round(seconds)} sekundēs"
                              + (" · mazais ekrāns 1366×768" if small_screen else "")
                              + " · nekas netika saglabāts", colour=colour)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        ttk.Button(foot, text="⧉ Kopēt rezultātus", command=self.copy).pack(side="right", padx=6)
        self.copied = tk.Label(foot, text="", bg=K.WHITE, fg=izskats.OK_FG, font=izskats.FONT_SMALL)
        self.copied.pack(side="left")
        box = izskats.boxed(self)
        box.pack(fill="both", expand=True, padx=18, pady=14)
        tree = ttk.Treeview(box, columns=("role", "place", "result", "note"), show="headings")
        for key, title, width in (("role", "Loma", 170), ("place", "Vieta", 330), ("result", "Rezultāts", 90),
                                  ("note", "Piezīme", 340)):
            tree.heading(key, text=title)
            tree.column(key, width=width, stretch=key in ("place", "note"))
        tree.tag_configure("bad", foreground=K.RED, font=("Segoe UI", 10, "bold"))
        tree.tag_configure("odd", background=izskats.ZEBRA)
        sb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)
        ordered = problems + [r for r in results if r[2] != PROBLEM]
        for i, r in enumerate(ordered):
            tree.insert("", "end", values=r, tags=("bad",) if r[2] == PROBLEM else (("odd",) if i % 2 else ()))
        self.bind("<Escape>", lambda e: self.destroy())

    def copy(self):
        lines = [f"{r[2]}\t{r[0]}\t{r[1]}\t{r[3]}" for r in self.results]
        self.clipboard_clear()
        self.clipboard_append("\n".join(lines))
        self.copied.configure(text="✓ Nokopēts — var ielīmēt ziņā")
