"""
Pūrlāde — ko datora Pūrlādei nosaka “Pūrlādes pārvaldnieks” (kolektīvu reģistrs, moduli/registrs.py)

    gate(app)         – kolektīvs bloķēts vai notiek apkope: programmas vietā parāda paziņojumu (True — parādīts)
    show_notice(root) – pārvaldnieka paziņojums visiem lietotājiem: parāda vienu reizi katrā datorā

Grupas un ieslēgtos moduļus piemēro kopeja.load_collective() (to izsauc piekluve.current(refresh=True)).
Lokālajā datubāzē (purlade.db) reģistra nav — nekas netiek ierobežots.
"""

import json
import os
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from moduli import datubaze, registrs, piekluve
    from moduli import kopeja as K
except ImportError:  # started from inside the moduli folder
    import datubaze
    import registrs
    import piekluve
    import kopeja as K

SEEN_FILE = "pazinojums.json"   # %APPDATA%\Pūrlāde: the last notice shown on this computer
_touched = False
_maintenance_told = False


def _passes_everything(user):
    """The database administrator (connected with the address and password) is never locked out."""
    return user.source == "admin"


def gate(app):
    """Called from Purlade.build(). When the collective is blocked or Pūrlāde is in maintenance, shows that
    instead of the program and returns True."""
    global _touched
    state = K.COLLECTIVE["state"]
    if not state:
        return False
    user = piekluve.own().user
    title = text = None
    if state["blocked"] and not _passes_everything(user):
        title, text = "Piekļuve bloķēta", registrs.blocked_text(state)
    elif state["maintenance"] and not (_passes_everything(user) or K.APP_ROLE_ADMIN in user.roles):
        title, text = "Notiek apkope", registrs.maintenance_text(state)
    if title is None:
        if not _touched:
            _touched = True
            try:
                registrs.touch(datubaze.shared_connection(), "dators", user.name or user.email or user.label)
            except Exception:
                pass
        return False
    _screen(app, title, text)
    return True


def _screen(app, title, text):
    root = app.root
    box = tk.Frame(root, bg=K.CREAM)
    box.place(relx=0.5, rely=0.45, anchor="center")
    tk.Label(box, text="🔒", font=("Segoe UI Emoji", 40), bg=K.CREAM, fg=K.RED).pack()
    tk.Label(box, text=title, font=("Georgia", 20, "bold"), bg=K.CREAM, fg=K.RED).pack(pady=(4, 0))
    tk.Label(box, text=text, font=("Segoe UI", 11), bg=K.CREAM, fg=K.NAVY, wraplength=560,
             justify="center").pack(pady=(10, 16))
    btns = tk.Frame(box, bg=K.CREAM)
    btns.pack()

    def again():
        app.access = piekluve.current(refresh=True)
        app.build()

    ttk.Button(btns, text="↻ Mēģināt vēlreiz", style="Accent.TButton", command=again).pack(side="left", padx=6)
    if hasattr(app, "change_user"):
        ttk.Button(btns, text="👤 Pieslēgties ar citu e-pastu…", command=app.change_user).pack(side="left", padx=6)
    ttk.Button(btns, text="Iziet", command=root.destroy).pack(side="left", padx=6)
    tk.Label(root, text=K.COPYRIGHT, font=("Segoe UI", 8), bg=K.CREAM, fg=K.NAVY).pack(side="bottom", pady=6)


def _seen_path():
    return os.path.join(datubaze.config_dir(), SEEN_FILE)


def show_notice(root):
    """The manager's notice for everybody — once per notice on this computer. Also tells the system
    administrator that maintenance is on (the others cannot get in)."""
    state = K.COLLECTIVE["state"]
    if not state:
        return
    global _maintenance_told
    if state["maintenance"] and not _maintenance_told:
        _maintenance_told = True
        messagebox.showwarning("Apkopes režīms", "Pūrlādē ir ieslēgts apkopes režīms — citi lietotāji pašlaik "
                               "nevar ielogoties. To izslēdz Pūrlādes pārvaldniekā.", parent=root)
    if not state["notice"]:
        return
    try:
        with open(_seen_path(), encoding="utf-8") as fh:
            seen = json.load(fh).get("key")
    except (OSError, ValueError, AttributeError):
        seen = None
    if seen == state["notice_key"]:
        return
    messagebox.showinfo("Paziņojums no Pūrlādes", state["notice"], parent=root)
    try:
        os.makedirs(datubaze.config_dir(), exist_ok=True)
        with open(_seen_path(), "w", encoding="utf-8") as fh:
            json.dump({"key": state["notice_key"]}, fh)
    except OSError:
        pass
