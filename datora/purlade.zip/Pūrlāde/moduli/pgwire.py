"""
Pūrlāde — PostgreSQL savienojums tikai ar Python standarta bibliotēku
(minimal PostgreSQL client: SSL, SCRAM-SHA-256 / MD5 password, extended query protocol)

Why our own client: Pūrlāde runs on the Python installed on each computer (also through
Pūrlāde.exe), so the online database must work without "pip install". This file implements
only what Pūrlāde needs:

* SSL (Supabase requires it) — the certificate is checked only when a CA file is given;
* password login with SCRAM-SHA-256 (Supabase), MD5 or plain text;
* queries with parameters ($1, $2 …). All parameters are sent as text with an unspecified type,
  so the server reads them as it would read a quoted literal (like SQLite, '5' = 5 works);
* several statements in one network round trip (pipeline), so a slow connection stays usable.

Results are converted to Python values by column type (int, float, bool, bytes, str).
"""

import base64
import hashlib
import hmac
import os
import socket
import ssl
import struct

PROTOCOL_V3 = 196608
SSL_REQUEST = 80877103

# type OIDs converted from text
_INT_OIDS = {20, 21, 23, 26, 28}
_FLOAT_OIDS = {700, 701}
_NUMERIC_OID = 1700
_BOOL_OID = 16
_BYTEA_OID = 17


class PgError(Exception):
    """Error reported by the server. `code` is the SQLSTATE (e.g. '23505' unique violation)."""

    def __init__(self, fields):
        self.fields = fields
        self.code = fields.get("C", "")
        self.message = fields.get("M", "")
        self.detail = fields.get("D", "")
        text = self.message
        if self.detail:
            text += "\n" + self.detail
        super().__init__(text)


class PgConnectionLost(Exception):
    """The network connection broke (internet gone, server closed it, timeout)."""


class Result:
    __slots__ = ("columns", "rows", "tag", "error")

    def __init__(self):
        self.columns = None   # [(name, type oid)] or None when the statement returns no rows
        self.rows = []
        self.tag = ""         # e.g. "INSERT 0 1", "UPDATE 3"
        self.error = None     # PgError when this statement failed

    @property
    def rowcount(self):
        parts = self.tag.split()
        if parts and parts[-1].isdigit() and parts[0] in ("INSERT", "UPDATE", "DELETE", "SELECT", "MERGE", "COPY"):
            return int(parts[-1])
        return -1


def _cstr(text):
    return text.encode("utf-8") + b"\0"


def _message(kind, payload=b""):
    return kind + struct.pack("!i", len(payload) + 4) + payload


def encode_param(value):
    """Python value -> text sent to the server (None -> NULL)."""
    if value is None:
        return None
    if isinstance(value, bool):
        return b"1" if value else b"0"
    if isinstance(value, (bytes, bytearray, memoryview)):
        return b"\\x" + bytes(value).hex().encode("ascii")
    if isinstance(value, float):
        return repr(value).encode("ascii")
    if hasattr(value, "isoformat"):
        return value.isoformat().encode("ascii")
    return str(value).encode("utf-8")


def decode_value(raw, oid):
    if raw is None:
        return None
    if oid in _INT_OIDS:
        return int(raw)
    if oid == _BOOL_OID:
        return raw == b"t"
    if oid in _FLOAT_OIDS:
        return float(raw)
    if oid == _NUMERIC_OID:
        text = raw.decode("ascii")
        if text in ("NaN", "Infinity", "-Infinity"):
            return float(text)
        if "." in text or "e" in text.lower():
            f = float(text)
            return int(f) if f == int(f) and abs(f) < 2 ** 53 else f
        return int(text)
    if oid == _BYTEA_OID:
        text = raw.decode("ascii")
        if text.startswith("\\x"):
            return bytes.fromhex(text[2:])
        return raw  # old "escape" format is not used by modern servers
    return raw.decode("utf-8")


class Connection:
    """One connection to a PostgreSQL server.

    `run(statements)` sends a list of (sql, params) in one round trip and returns one Result per
    statement. When a statement fails, the following ones are skipped by the server (their Result
    has error=None and tag='' — `skipped`)."""

    def __init__(self, host, port=5432, user="postgres", password="", database="postgres",
                 ssl_mode="require", ca_file=None, connect_timeout=15, timeout=60,
                 application_name="Purlade"):
        self.host, self.port = host, int(port)
        self.timeout = timeout
        self.parameters = {}
        self.transaction_status = b"I"
        self._buf = b""
        try:
            raw = socket.create_connection((host, self.port), timeout=connect_timeout)
        except OSError as exc:
            raise PgConnectionLost(f"Neizdevās sasniegt serveri {host}:{port} ({exc})") from exc
        try:
            raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            raw.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except OSError:
            pass
        self.sock = raw
        try:
            if ssl_mode != "disable":
                self._start_ssl(ssl_mode, ca_file, connect_timeout)
            self.sock.settimeout(connect_timeout)
            self._startup(user, password, database, application_name)
            self.sock.settimeout(timeout)
        except BaseException:
            self._close_socket()
            raise

    # -- low level -------------------------------------------------------
    def _send(self, data):
        try:
            self.sock.sendall(data)
        except (OSError, AttributeError) as exc:
            self._close_socket()
            raise PgConnectionLost(f"Savienojums ar datubāzi pārtrūka ({exc})") from exc

    def _recv_exact(self, n):
        while len(self._buf) < n:
            try:
                chunk = self.sock.recv(max(65536, n - len(self._buf)))
            except (OSError, AttributeError) as exc:
                self._close_socket()
                raise PgConnectionLost(f"Savienojums ar datubāzi pārtrūka ({exc})") from exc
            if not chunk:
                self._close_socket()
                raise PgConnectionLost("Datubāzes serveris aizvēra savienojumu.")
            self._buf += chunk
        data, self._buf = self._buf[:n], self._buf[n:]
        return data

    def _read_message(self):
        head = self._recv_exact(5)
        kind = head[:1]
        length = struct.unpack("!i", head[1:])[0]
        return kind, self._recv_exact(length - 4)

    def _close_socket(self):
        sock, self.sock = getattr(self, "sock", None), None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    @property
    def closed(self):
        return self.sock is None

    def close(self):
        if self.sock is not None:
            try:
                self.sock.sendall(_message(b"X"))
            except OSError:
                pass
            self._close_socket()

    # -- connecting --------------------------------------------------------
    def _start_ssl(self, ssl_mode, ca_file, timeout):
        self.sock.settimeout(timeout)
        self._send(struct.pack("!ii", 8, SSL_REQUEST))
        answer = self._recv_exact(1)
        if answer != b"S":
            if ssl_mode == "prefer":
                return
            raise PgConnectionLost("Datubāzes serveris neatbalsta šifrētu (SSL) savienojumu.")
        if ca_file:
            ctx = ssl.create_default_context(cafile=ca_file)
            ctx.check_hostname = ssl_mode == "verify-full"
        else:  # like libpq sslmode=require: encrypted, certificate not checked
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        try:
            self.sock = ctx.wrap_socket(self.sock, server_hostname=self.host)
        except (ssl.SSLError, OSError) as exc:
            raise PgConnectionLost(f"Šifrētu savienojumu neizdevās izveidot ({exc})") from exc

    def _startup(self, user, password, database, application_name):
        body = struct.pack("!i", PROTOCOL_V3)
        for key, value in (("user", user), ("database", database), ("client_encoding", "UTF8"),
                           ("application_name", application_name), ("DateStyle", "ISO")):
            body += _cstr(key) + _cstr(value)
        body += b"\0"
        self._send(struct.pack("!i", len(body) + 4) + body)
        scram = None
        while True:
            kind, data = self._read_message()
            if kind == b"R":
                code = struct.unpack("!i", data[:4])[0]
                if code == 0:
                    continue
                if code == 3:
                    self._send(_message(b"p", _cstr(password)))
                elif code == 5:
                    salt = data[4:8]
                    inner = hashlib.md5((password + user).encode("utf-8")).hexdigest().encode("ascii")
                    outer = "md5" + hashlib.md5(inner + salt).hexdigest()
                    self._send(_message(b"p", _cstr(outer)))
                elif code == 10:
                    mechanisms = [m.decode() for m in data[4:].split(b"\0") if m]
                    if "SCRAM-SHA-256" not in mechanisms:
                        raise PgConnectionLost("Serveris prasa neatbalstītu pieteikšanās veidu: "
                                               + ", ".join(mechanisms))
                    scram = _Scram(password)
                    first = scram.client_first().encode("utf-8")
                    self._send(_message(b"p", _cstr("SCRAM-SHA-256") + struct.pack("!i", len(first)) + first))
                elif code == 11:
                    self._send(_message(b"p", scram.client_final(data[4:].decode("utf-8")).encode("utf-8")))
                elif code == 12:
                    scram.verify_server(data[4:].decode("utf-8"))
                else:
                    raise PgConnectionLost(f"Neatbalstīts pieteikšanās veids ({code}).")
            elif kind == b"S":
                key, value = data.split(b"\0")[:2]
                self.parameters[key.decode()] = value.decode()
            elif kind == b"K":
                pass
            elif kind == b"E":
                raise PgError(_error_fields(data))
            elif kind == b"N":
                pass
            elif kind == b"Z":
                self.transaction_status = data[:1]
                return

    # -- queries -------------------------------------------------------------
    def run(self, statements):
        """statements: [(sql with $1.. placeholders, params tuple)] -> [Result]"""
        out = bytearray()
        for sql, params in statements:
            values = [encode_param(p) for p in params]
            out += _message(b"P", b"\0" + _cstr(sql) + struct.pack("!h", 0))
            bind = bytearray(b"\0\0" + struct.pack("!hh", 0, len(values)))
            for v in values:
                if v is None:
                    bind += struct.pack("!i", -1)
                else:
                    bind += struct.pack("!i", len(v)) + v
            bind += struct.pack("!h", 0)
            out += _message(b"B", bytes(bind))
            out += _message(b"D", b"P\0")
            out += _message(b"E", b"\0" + struct.pack("!i", 0))
        out += _message(b"S")
        self._send(bytes(out))
        results = [Result() for _ in statements]
        i = 0
        failed = False
        while True:
            kind, data = self._read_message()
            if kind == b"T":
                results[i].columns = _row_description(data)
            elif kind == b"D":
                results[i].rows.append(_data_row(data, results[i].columns))
            elif kind == b"C":
                results[i].tag = data[:-1].decode("utf-8")
                i += 1
            elif kind == b"I":   # empty query
                i += 1
            elif kind == b"E":
                if i < len(results):
                    results[i].error = PgError(_error_fields(data))
                failed = True
            elif kind == b"Z":
                self.transaction_status = data[:1]
                break
            # '1' ParseComplete, '2' BindComplete, 'n' NoData, 'N' notice, 'S' parameter, 'A' notify: ignored
            elif kind == b"S":
                key, value = data.split(b"\0")[:2]
                self.parameters[key.decode()] = value.decode()
        if failed:
            for r in results:
                if r.error is None and not r.tag and r.columns is None:
                    r.tag = "SKIPPED"
        return results

    def simple(self, script):
        """Run a script of several statements (no parameters) with the simple query protocol."""
        self._send(_message(b"Q", _cstr(script)))
        error = None
        while True:
            kind, data = self._read_message()
            if kind == b"E":
                error = PgError(_error_fields(data))
            elif kind == b"Z":
                self.transaction_status = data[:1]
                break
        if error is not None:
            raise error


def _error_fields(data):
    fields = {}
    for part in data.split(b"\0"):
        if part:
            fields[chr(part[0])] = part[1:].decode("utf-8", "replace")
    return fields


def _row_description(data):
    count = struct.unpack("!h", data[:2])[0]
    pos, cols = 2, []
    for _ in range(count):
        end = data.index(b"\0", pos)
        name = data[pos:end].decode("utf-8")
        pos = end + 1
        oid = struct.unpack("!i", data[pos + 6:pos + 10])[0]
        pos += 18
        cols.append((name, oid))
    return cols


def _data_row(data, columns):
    count = struct.unpack("!h", data[:2])[0]
    pos, row = 2, []
    for idx in range(count):
        length = struct.unpack("!i", data[pos:pos + 4])[0]
        pos += 4
        if length < 0:
            raw = None
        else:
            raw = data[pos:pos + length]
            pos += length
        row.append(decode_value(raw, columns[idx][1] if columns else 25))
    return tuple(row)


class _Scram:
    """SCRAM-SHA-256 (RFC 5802 / 7677) without channel binding."""

    def __init__(self, password):
        self.password = password.encode("utf-8")
        self.nonce = base64.b64encode(os.urandom(18)).decode("ascii")

    def client_first(self):
        self.first_bare = "n=,r=" + self.nonce
        return "n,," + self.first_bare

    def client_final(self, server_first):
        attrs = dict(item.split("=", 1) for item in server_first.split(","))
        if not attrs["r"].startswith(self.nonce):
            raise PgConnectionLost("Serveris atbildēja ar nederīgu pieteikšanās atbildi.")
        salt = base64.b64decode(attrs["s"])
        iterations = int(attrs["i"])
        salted = hashlib.pbkdf2_hmac("sha256", self.password, salt, iterations)
        client_key = hmac.new(salted, b"Client Key", hashlib.sha256).digest()
        stored_key = hashlib.sha256(client_key).digest()
        final_bare = "c=biws,r=" + attrs["r"]
        self.auth_message = (self.first_bare + "," + server_first + "," + final_bare).encode("utf-8")
        signature = hmac.new(stored_key, self.auth_message, hashlib.sha256).digest()
        proof = bytes(a ^ b for a, b in zip(client_key, signature))
        self.server_key = hmac.new(salted, b"Server Key", hashlib.sha256).digest()
        return final_bare + ",p=" + base64.b64encode(proof).decode("ascii")

    def verify_server(self, server_final):
        attrs = dict(item.split("=", 1) for item in server_final.split(","))
        expected = hmac.new(self.server_key, self.auth_message, hashlib.sha256).digest()
        if "v" not in attrs or not hmac.compare_digest(base64.b64decode(attrs["v"]), expected):
            raise PgConnectionLost("Datubāzes servera identitāti neizdevās apstiprināt.")
