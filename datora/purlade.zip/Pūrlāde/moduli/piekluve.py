"""
Pūrlāde — lietotāju lomu piekļuve datora versijā

Kurš lieto Pūrlādi:
  * dators pieslēgts tiešsaistes datubāzei ar e-pastu un kodu (Administrēšana → Datubāze… / sākuma lapa →
    “Mainīt lietotāju”) — lietotājs ir šī e-pasta īpašnieks Kopas pūrā (tabula app_users), viņa lomas —
    “Loma kolektīvā” + lietotnes lomas (kopeja.app_roles_of);
  * dators pieslēgts tiešsaistes datubāzei ar adresi un paroli (datubāzes administrators) — visas tiesības;
  * lokālā datubāze purlade.db — visas tiesības (tā ir tikai šajā datorā).

Ko katra loma var (vairākas lomas — tiesības saskaitās):
  Vadītājs, Repetitors, Sistēmas administrators — visi moduļi, visu var labot;
  Prezidents         — visi moduļi; labot var tikai A grupas informāciju (dejotāji, dejas, notikumi, apmeklējums,
                       tērpu izsniegšana A grupas dejotājiem);
  Studijas vecākais  — tas pats, bet Studijas grupai;
  Tērpu pārzinis     — visi moduļi tikai skatīšanai, izņemot Tērpu pūru (viss), dejas tērpu veidus Deju pūrā un
                       publicitātes pasākuma tērpus Notikumu pūrā;
  Sociālo tīklu administrators — tikai Notikumu pūrs: redz visus notikumus, var izveidot, labot un dzēst
                       publicitātes pasākumus (arī uzaicināt dejotājus);
  A grupas kasieris / Studijas kasieris — Zelta pūrs (savas grupas finanses), Kopas pūrs tikai skatīšanai;
  Sveicējs, Dejotājs — datora Pūrlādei piekļuves nav.
Lomas, “Lomu kolektīvā” un Kabatas Pūrlādes e-pastu Kopas pūrā drīkst mainīt tikai tie, kas piešķir lietotnes lomas
(vadītājs, sistēmas administrators) — citādi ar tiem varētu iegūt sev citas tiesības.
Administrēšana, Izstrādes darbi un Kolektīva vēstures labošana — vadītājam, repetitoram, sistēmas administratoram.

“Skatīt kā” (Pūrlāde v0.9.1): sistēmas administrators (un lokālās datubāzes / datubāzes administratora lietotājs)
var uz laiku redzēt programmu tā, kā to redz cita loma (preview(role)); preview(None) — atpakaļ uz savu skatu.
Skatoties kā cita loma, darbojas tieši tās lomas tiesības, bet nekas netiek saglabāts (v0.9.2: datubaze.PREVIEW —
commit() atceļ izmaiņas).
"""

import sqlite3
import tkinter as tk
from tkinter import messagebox

try:
    from moduli import datubaze
    from moduli import kopeja as K
except ImportError:  # started from inside the moduli folder
    import datubaze
    import kopeja as K

MODULES = ["terpu_purs", "deju_purs", "kopas_purs", "notikumu_purs", "citibas_purs", "zelta_purs"]
MODULE_NAMES = {"terpu_purs": "Tērpu pūrs", "deju_purs": "Deju pūrs", "kopas_purs": "Kopas pūrs",
                "notikumu_purs": "Notikumu pūrs", "citibas_purs": "Cītības pūrs", "zelta_purs": "Zelta pūrs"}

VIEW = frozenset()   # a module that may be opened, but nothing changed in it
ALL = None           # every group may be changed

FULL_ROLES = {K.APP_ROLE_LEADER, K.APP_ROLE_REPETITOR, K.APP_ROLE_ADMIN}


def _role_rules(role):
    """{module: scope} for one app role: ALL (None) = may change everything, a set of groups = may change only
    the information of these groups, VIEW (empty set) = may only look. Modules not in the dict: no access."""
    if role in FULL_ROLES:
        return {m: ALL for m in MODULES}
    if role == K.APP_ROLE_PRESIDENT:
        return {m: frozenset({"A"}) for m in MODULES}
    if role == K.APP_ROLE_STUDIO_ELDER:
        return {m: frozenset({"Studija"}) for m in MODULES}
    if role == K.APP_ROLE_COSTUMES:
        rules = {m: VIEW for m in MODULES}
        rules["terpu_purs"] = ALL
        return rules
    if role == K.APP_ROLE_SOCIAL:
        return {"notikumu_purs": VIEW}
    if role == K.APP_ROLE_CASHIER_A:
        return {"zelta_purs": frozenset({"A"}), "kopas_purs": VIEW}
    if role == K.APP_ROLE_CASHIER_STUDIO:
        return {"zelta_purs": frozenset({"Studija"}), "kopas_purs": VIEW}
    return {}   # Dejotājs, Sveicējs


def _union(a, b):
    if a is ALL or b is ALL:
        return ALL
    return frozenset(a) | frozenset(b)


class User:
    def __init__(self, name="", email="", roles=(), source="email", dancer_id=None, problem=""):
        self.name, self.email, self.roles = name, email, list(roles)
        self.source = source          # "email", "local" (purlade.db), "admin" (online, address + password)
        self.dancer_id = dancer_id
        self.problem = problem        # why there is no user (e-mail not found …)

    @property
    def label(self):
        if self.source == "local":
            return "lokālā datubāze — visas tiesības"
        if self.source == "admin":
            return "datubāzes administrators — visas tiesības"
        if self.source == "preview":
            return f"{self.name} — skats kā {', '.join(self.roles)}"
        roles = ", ".join(r for r in self.roles if r != K.APP_ROLE_DANCER) or K.APP_ROLE_DANCER
        return f"{self.name or self.email} ({roles})"


class Access:
    """What the current user may open and change. Use current() to get it."""

    def __init__(self, user):
        self.user = user
        self.preview_role = user.roles[0] if user.source == "preview" and user.roles else None
        self.full = user.source in ("local", "admin") or bool(set(user.roles) & FULL_ROLES)
        self.rules = {}
        if self.full:
            self.rules = {m: ALL for m in MODULES}
        else:
            for role in user.roles:
                for module, scope in _role_rules(role).items():
                    self.rules[module] = _union(self.rules[module], scope) if module in self.rules else scope
        roles = set(user.roles)
        self.costumes = self.full or K.APP_ROLE_COSTUMES in roles      # dance / publicity event costumes
        self.social = K.APP_ROLE_SOCIAL in roles                        # publicity events
        self.assign_roles = self.full or K.has_right(user.roles, K.RIGHT_ASSIGN_APP_ROLES)

    # ---- modules ----------------------------------------------------------------
    def allowed(self):
        """May this person use the desktop Pūrlāde at all?"""
        return bool(self.rules)

    def can_open(self, module):
        return module in self.rules

    def scope(self, module):
        """ALL (None), a set of groups, or VIEW (empty set). A module without access — VIEW as well."""
        return self.rules.get(module, VIEW)

    def view_only(self, module):
        return self.scope(module) == VIEW

    def edits_all(self, module):
        return self.scope(module) is ALL

    def groups(self, module):
        """The groups whose information may be changed (all groups when not limited)."""
        scope = self.scope(module)
        return list(K.DANCER_GROUPS) if scope is ALL else [g for g in K.DANCER_GROUPS if g in scope]

    def can_edit(self, module, group=None, groups=None):
        """group: one dancer's / dance's group ('' = A); groups: an event's groups (list; empty = every group).
        Without group/groups: may anything at all be changed in the module?"""
        scope = self.scope(module)
        if scope is ALL:
            return True
        if not scope:
            return False
        if groups is not None:
            chosen = set(groups) or set(K.DANCER_GROUPS)
            return chosen <= scope
        if group is not None:
            return ((group or "").strip() or K.DEFAULT_DANCER_GROUP) in scope
        return True

    def can_edit_event(self, groups_text, publicity=False):
        """Notikumu pūrs / Cītības pūrs: an event of these groups (event_details.for_groups)."""
        if publicity and self.social:
            return True
        return self.can_edit("notikumu_purs", groups=K.event_groups(groups_text))

    def scope_text(self, module):
        scope = self.scope(module)
        if scope is ALL:
            return "visas grupas"
        if not scope:
            return "tikai skatīšanai"
        return ", ".join(self.groups(module)) + " grupa"


# --------------------------------------------------------------------------
# Who is using this computer
# --------------------------------------------------------------------------
def detect_user():
    cfg = datubaze.load_config()
    if cfg.get("mode") != datubaze.MODE_ONLINE:
        return User(name="Lokālā datubāze", source="local")
    email = (cfg.get("connected_by") or "").strip().lower()
    if not email:
        return User(name="Datubāzes administrators", source="admin")
    try:
        con = K.connect_db()
        try:
            if not K._has_table(con, "app_users"):
                return User(email=email, problem="Datubāzē vēl nav neviena lietotāja e-pasta.")
            row = con.execute(
                "SELECT d.id, d.first_name, d.last_name, d.name, d.role, d.app_roles, d.status "
                "FROM app_users u JOIN dancers d ON d.id = u.dancer_id WHERE LOWER(u.email)=? AND u.active=1",
                (email,)).fetchone()
        finally:
            con.close()
    except sqlite3.Error as exc:
        return User(email=email, problem=f"Neizdevās nolasīt lietotāju: {exc}")
    if not row:
        return User(email=email, problem=f"E-pasts {email} vairs nav piešķirts nevienam Kopas pūrā.")
    did, first, last, name, role, stored, status = row
    name = K.full_name(first, last) or name or email
    if (status or "") == K.STATUS_LEFT:
        return User(name=name, email=email, dancer_id=did, problem=f"{name} ir izstājies no kolektīva.")
    return User(name=name, email=email, roles=K.app_roles_of(role, stored), dancer_id=did)


_current = None
_real = None   # while looking at the program as another role (“Skatīt kā”): the person's own Access

# roles the system administrator can look through (roles that may use the desktop Pūrlāde, without full rights)
PREVIEW_ROLES = [K.APP_ROLE_PRESIDENT, K.APP_ROLE_STUDIO_ELDER, K.APP_ROLE_COSTUMES, K.APP_ROLE_SOCIAL,
                 K.APP_ROLE_CASHIER_A, K.APP_ROLE_CASHIER_STUDIO]


def current(refresh=False):
    """The Access of the person using this computer (worked out once; refresh=True after a new sign-in)."""
    global _current, _real
    if refresh:
        _real = None
        datubaze.PREVIEW["on"] = False
    if _current is None or refresh:
        try:
            _current = Access(detect_user())
        except Exception as exc:   # never let a problem here stop the program for the local database
            K.log_error(f"Lietotāja noteikšana: {exc}")
            _current = Access(User(problem=str(exc)))
    return _current


def set_current(access):
    global _current, _real
    _current, _real = access, None
    datubaze.PREVIEW["on"] = False


def own():
    """The person's own Access (also while looking as another role)."""
    return _real or current()


def can_preview():
    """May this person look at the program as other roles? The system administrator (and the local database /
    database administrator, who have all rights anyway)."""
    user = own().user
    return user.source in ("local", "admin") or K.APP_ROLE_ADMIN in user.roles


def previewing():
    return _real is not None


def preview(role):
    """Look at the program as `role` (None — back to one's own view). Returns the Access now in use."""
    global _current, _real
    base = own()
    if role is None:
        _current, _real = base, None
        datubaze.PREVIEW["on"] = False
        return _current
    if not can_preview() or role not in PREVIEW_ROLES:
        return current()
    name = base.user.name or base.user.email or "Sistēmas administrators"
    _real = base
    _current = Access(User(name=name, email=base.user.email, roles=[role], source="preview",
                           dancer_id=base.user.dancer_id))
    datubaze.PREVIEW["on"] = True   # look only: nothing is saved
    return _current


# --------------------------------------------------------------------------
# Messages and read-only windows
# --------------------------------------------------------------------------
def deny(parent, text=""):
    """Tells that the role does not allow this; returns False (so callers can `return deny(...)`)."""
    who = current().user.label
    messagebox.showinfo("Nav tiesību", (text or "Jūsu lomai šeit ir tikai skatīšanās tiesības.") +
                        f"\n\nLietotājs: {who}", parent=parent)
    return False


def check(parent, ok, text=""):
    """`if not piekluve.check(self, allowed, "…"): return` — shows the message when not allowed."""
    return True if ok else deny(parent, text)


KEEP_BUTTONS = ("aizvērt", "atcelt", "kopēt", "informācija", "kopsavilkums", "atvērt", "skatīt", "eksport",
                "vēsture", "‹", "›", "«", "»", "šodien", "rādīt")
INPUTS = {"Entry", "TEntry", "Spinbox", "TSpinbox", "TCombobox", "Text", "Checkbutton", "TCheckbutton",
          "Radiobutton", "TRadiobutton", "Listbox"}


def make_readonly(win, note="Tikai skatīšanai — jūsu lomai šeit nav labošanas tiesību.", keep=(), skip=()):
    """Disable every input field and hide every button that changes something (buttons whose text is not in
    KEEP_BUTTONS / keep). skip: widgets (and their children) left as they are. Adds a red note at the top."""
    keep_words = tuple(w.lower() for w in KEEP_BUTTONS + tuple(keep))
    skip = set(str(w) for w in skip)
    stack = list(win.winfo_children())
    while stack:
        w = stack.pop()
        if str(w) in skip:
            continue
        if isinstance(w, tk.Toplevel):
            continue
        stack.extend(w.winfo_children())
        cls = w.winfo_class()
        try:
            if cls in ("Button", "TButton"):
                text = str(w.cget("text")).strip().lower()
                if not any(k in text for k in keep_words):
                    w.configure(state="disabled")
                    # a disabled accent button looks the same as an active one: hide it
                    manager = w.winfo_manager()
                    if manager == "pack":
                        w.pack_forget()
                    elif manager == "grid":
                        w.grid_remove()
                    elif manager == "place":
                        w.place_forget()
            elif cls in ("Entry", "TEntry", "Spinbox", "TSpinbox"):
                w.configure(state="readonly")
            elif cls == "TCombobox":
                w.configure(state="disabled")
            elif cls in ("Text", "Checkbutton", "TCheckbutton", "Radiobutton", "TRadiobutton", "Listbox"):
                w.configure(state="disabled")
        except tk.TclError:
            pass
    try:
        title = win.title()
        if title and "tikai skatīšanai" not in title:
            win.title(title + " — tikai skatīšanai")
    except tk.TclError:
        pass
    if note:
        try:
            bar = tk.Label(win, text="🔒 " + note, bg=K.RED, fg=K.CREAM, font=("Segoe UI", 9, "bold"),
                           anchor="w", padx=8, pady=3)
            first = [w for w in win.pack_slaves() if w is not bar]
            if first:   # Pūrlāde v0.8.8: above the window's title strip, not over it
                bar.pack(side="top", fill="x", before=first[0])
            else:
                bar.place(relx=0, rely=0, relwidth=1)
            bar.lift()
        except tk.TclError:
            pass
    try:
        win.changed = False      # nothing to save — CloseGuard must not ask
    except Exception:
        pass
    win.readonly = True
