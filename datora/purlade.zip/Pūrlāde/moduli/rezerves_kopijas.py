"""
Pūrlāde — rezerves kopijas (Administrēšana → “Rezerves kopijas…”, Pūrlāde v0.9.4)

Kopija ir viens .zip fails “Pūrlāde rezerves kopija GGGG-MM-DD HH-MM.zip” ar:
    purlade.db        – visi dati (lokālā datubāze — tās precīza kopija; tiešsaistes datubāze — visas tabulas,
                        pārrakstītas SQLite failā, ko var atjaunot tiešsaistē vai atvērt kā lokālo datubāzi);
    costume_photos/   – tērpu fotogrāfijas (ja tādas ir);
    kopija.json       – kad, kura Pūrlādes versija, kura datubāze, cik rindu katrā tabulā.

Kur glabā: mapē, ko administrators izvēlas — ieteicams Google Drive mapē datorā (Google Drive datoram
sinhronizē to ar Google Drive mākoni, piem., “G:\\Mans disks\\Pūrlāde kopijas”); kamēr mape nav izvēlēta —
lietotāja datu mapē (…\\AppData\\Roaming\\Pūrlāde\\Rezerves kopijas). Iestatījumi glabājas tikai šajā datorā
(datubaze.json): backup_dir, backup_days (ik pēc cik dienām, noklusēti 7), backup_keep (cik kopijas paturēt, 10).

Automātiski (auto_backup, fona pavedienā pēc palaišanas): ja kopš pēdējās kopijas pagājis norādītais dienu skaits,
vai ja palaista cita Pūrlādes versija nekā iepriekšējās kopijas laikā. Vecākās kopijas virs “paturēt” tiek dzēstas.
Atjaunošana: lokālā datubāze tiek pārrakstīta ar kopiju (pirms tam — vēl viena kopija “pirms atjaunošanas”);
tiešsaistes datubāzei dati tiek aizvietoti visiem lietotājiem (jāieraksta “ATJAUNOT”).
Requirements: Python 3.8+ (only the standard library).
"""

import json
import os
import re
import shutil
import sqlite3
import string
import subprocess
import tempfile
import threading
import traceback
import zipfile
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import ttk, messagebox, filedialog

try:
    from moduli import kopeja as K
    from moduli import datubaze as D
    from moduli import izskats
except ImportError:  # started from inside the moduli folder
    import kopeja as K
    import datubaze as D
    import izskats

CREAM, RED, NAVY, GOLD, WHITE = K.CREAM, K.RED, K.NAVY, K.GOLD, K.WHITE
LINE, MUTED = izskats.LINE, izskats.MUTED

FILE_PREFIX = "Pūrlāde rezerves kopija "
FILE_RE = re.compile(r"^Pūrlāde rezerves kopija (\d{4}-\d{2}-\d{2} \d{2}-\d{2}(?:-\d{2})?)( [^\d].*)?\.zip$")
DEFAULT_DAYS, DEFAULT_KEEP = 7, 10
PHOTO_DIR = os.path.join(K.DATA_DIR, "costume_photos")
DRIVE_NAMES = ("Mans disks", "My Drive", "Mein Ablage", "Мой диск", "Mano diskas", "Minu ketas")
_lock = threading.Lock()   # one backup at a time


# --------------------------------------------------------------------------
# Settings of this computer
# --------------------------------------------------------------------------
def settings():
    cfg = D.load_config()
    return {"dir": cfg.get("backup_dir") or "", "days": int(cfg.get("backup_days") or DEFAULT_DAYS),
            "keep": int(cfg.get("backup_keep") or DEFAULT_KEEP), "last": cfg.get("backup_last") or "",
            "version": cfg.get("backup_version") or "", "error": cfg.get("backup_error") or ""}


def save_settings(**values):
    cfg = D.load_config()
    for key, value in values.items():
        cfg["backup_" + key] = value
    D.save_config(cfg)


def default_dir():
    return os.path.join(D.config_dir(), "Rezerves kopijas")


def backup_dir():
    """The chosen folder (made when missing) or — when there is none or it cannot be reached (e.g. Google Drive
    is not running) — the default one on this computer."""
    chosen = settings()["dir"]
    if chosen:
        try:
            os.makedirs(chosen, exist_ok=True)
            return chosen
        except OSError:
            K.log_error(f"Rezerves kopiju mape nav pieejama: {chosen} — kopija tiek saglabāta {default_dir()}")
    return default_dir()


def google_drive_dirs():
    """Folders of Google Drive datoram (Google Drive for desktop) on this computer: “G:\\Mans disks” …"""
    found = []
    roots = [f"{letter}:\\" for letter in string.ascii_uppercase] if os.name == "nt" else []
    home = os.path.expanduser("~")
    roots += [home, os.path.join(home, "Google Drive")]
    for root in roots:
        for name in DRIVE_NAMES:
            path = os.path.join(root, name)
            try:
                if os.path.isdir(path) and path not in found:
                    found.append(path)
            except OSError:
                pass
    old = os.path.join(home, "Google Drive")   # older “Backup and Sync”
    if os.path.isdir(old) and not any(f.startswith(old) for f in found):
        found.append(old)
    return found


def is_google_drive(path):
    low = (path or "").lower()
    return "google drive" in low or any(n.lower() in low for n in DRIVE_NAMES)


# --------------------------------------------------------------------------
# Making a backup
# --------------------------------------------------------------------------
def _export_local(target):
    """Exact copy of purlade.db (SQLite backup — safe while the program is using the database)."""
    src = sqlite3.connect(K.DB_PATH)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def _export_online(target):
    """All tables of the online database into a SQLite file (a separate connection — the program keeps working)."""
    cfg = D.online_config()
    con = D.PgConnection(cfg)
    dst = sqlite3.connect(target)
    try:
        raw = con._con
        res = raw.run([("SELECT table_name, column_name FROM information_schema.columns WHERE table_schema = "
                        "current_schema() AND table_name IN (SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = current_schema() AND table_type = 'BASE TABLE') "
                        "ORDER BY table_name, ordinal_position", ())])[0]
        tables = {}
        for table, column in res.rows:
            tables.setdefault(table, []).append(column)
        for table, cols in tables.items():
            q = ", ".join(f'"{c}"' for c in cols)
            key = " PRIMARY KEY" if cols and cols[0] == "id" else ""
            dst.execute(f'CREATE TABLE "{table}" (' + ", ".join(f'"{c}"' + (key if i == 0 else "")
                                                               for i, c in enumerate(cols)) + ")")
            rows = raw.run([(f'SELECT {q} FROM "{table}"', ())])[0]
            if rows.error:
                raise sqlite3.OperationalError(f"{table}: {rows.error}")
            dst.executemany(f'INSERT INTO "{table}" ({q}) VALUES ({", ".join("?" * len(cols))})',
                            [tuple(_plain(v) for v in r) for r in rows.rows])
        dst.commit()
    finally:
        dst.close()
        con.close_for_real()


def _plain(value):
    if isinstance(value, (int, float, str, bytes)) or value is None:
        return value
    if isinstance(value, bool):
        return int(value)
    return str(value)


def _counts(path):
    con = sqlite3.connect(path)
    try:
        names = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                           "AND name NOT LIKE 'sqlite_%'")]
        return {n: con.execute(f'SELECT COUNT(*) FROM "{n}"').fetchone()[0] for n in names}
    finally:
        con.close()


def make_backup(note="", version="", folder=None):
    """Make one backup now. Returns the path of the .zip file (raises on failure)."""
    with _lock:
        folder = folder or backup_dir()
        os.makedirs(folder, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
        name = FILE_PREFIX + stamp + (f" {note}" if note else "") + ".zip"
        final = os.path.join(folder, name)
        online = D.is_online()
        with tempfile.TemporaryDirectory() as tmp:
            db = os.path.join(tmp, "purlade.db")
            (_export_online if online else _export_local)(db)
            info = {"izveidota": datetime.now().strftime("%d.%m.%Y %H:%M"), "pūrlāde": version,
                    "datubāze": "tiešsaistes" if online else "lokālā", "dators": D.computer_name(),
                    "piezīme": note, "tabulas": _counts(db)}
            part = final + ".tmp"
            with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(db, "purlade.db")
                z.writestr("kopija.json", json.dumps(info, ensure_ascii=False, indent=2))
                if os.path.isdir(PHOTO_DIR):
                    for root, _dirs, files in os.walk(PHOTO_DIR):
                        for f in files:
                            full = os.path.join(root, f)
                            z.write(full, os.path.join("costume_photos", os.path.relpath(full, PHOTO_DIR)))
            os.replace(part, final)
        prune(folder)
        return final


def list_backups(folder=None):
    """[(path, when ‘GGGG-MM-DD HH-MM’, note, size)] newest first."""
    folder = folder or backup_dir()
    result = []
    try:
        names = os.listdir(folder)
    except OSError:
        return []
    for name in names:
        m = FILE_RE.match(name)
        if m:
            path = os.path.join(folder, name)
            try:
                size = os.path.getsize(path)
            except OSError:
                size = 0
            result.append((path, m.group(1), (m.group(2) or "").strip(), size))
    result.sort(key=lambda r: r[1], reverse=True)
    return result


def prune(folder=None):
    """Keep the newest `keep` regular backups (those “pirms atjaunošanas” are kept as well)."""
    keep = settings()["keep"]
    regular = [b for b in list_backups(folder) if not b[2]]
    for path, _w, _n, _s in regular[keep:]:
        try:
            os.remove(path)
        except OSError:
            pass


def due(version):
    s = settings()
    if s["version"] != version:
        return True
    try:
        last = datetime.strptime(s["last"], "%Y-%m-%d %H:%M")
    except ValueError:
        return True
    return datetime.now() - last >= timedelta(days=max(1, s["days"]))


def auto_backup(version, on_done=None):
    """Called after Pūrlāde has started: makes a backup in a background thread when one is due.
    on_done(path, error) is called in that thread (use root.after to touch the window)."""
    if not due(version):
        return False

    def work():
        path, error = None, ""
        try:
            path = make_backup(version=version)
            save_settings(last=datetime.now().strftime("%Y-%m-%d %H:%M"), version=version, error="")
        except Exception as exc:
            error = str(exc)
            K.log_error("Rezerves kopiju neizdevās izveidot:\n" + traceback.format_exc())
            try:
                save_settings(error=f"{datetime.now().strftime('%d.%m.%Y %H:%M')}: {exc}")
            except Exception:
                pass
        if on_done:
            on_done(path, error)
    threading.Thread(target=work, daemon=True).start()
    return True


# --------------------------------------------------------------------------
# Restoring
# --------------------------------------------------------------------------
def read_info(path):
    try:
        with zipfile.ZipFile(path) as z:
            return json.loads(z.read("kopija.json").decode("utf-8"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return {}


def restore(path, version="", progress=None):
    """Replace the data with the backup `path` (after making a backup “pirms atjaunošanas” of the present data)."""
    with zipfile.ZipFile(path) as z:
        if "purlade.db" not in z.namelist():
            raise ValueError("Šajā failā nav Pūrlādes datubāzes.")
        with tempfile.TemporaryDirectory() as tmp:
            z.extract("purlade.db", tmp)
            db = os.path.join(tmp, "purlade.db")
            if progress:
                progress("Saglabā pašreizējos datus (kopija “pirms atjaunošanas”)…")
            make_backup(note="pirms atjaunošanas", version=version)
            if D.is_online():
                if progress:
                    progress("Aizvieto tiešsaistes datus…")
                D.close_shared()
                D.transfer_from_sqlite(db, D.online_config(), progress=progress, replace=True)
            else:
                if progress:
                    progress("Aizvieto lokālo datubāzi…")
                src = sqlite3.connect(db)
                dst = sqlite3.connect(K.DB_PATH)
                try:
                    src.backup(dst)   # writes into the open database (other connections see the new data)
                finally:
                    dst.close()
                    src.close()
            photos = [n for n in z.namelist() if n.startswith("costume_photos/") and not n.endswith("/")]
            if photos:
                os.makedirs(PHOTO_DIR, exist_ok=True)
                for n in photos:
                    target = os.path.join(PHOTO_DIR, os.path.relpath(n, "costume_photos"))
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with z.open(n) as fh, open(target, "wb") as out:
                        shutil.copyfileobj(fh, out)


# --------------------------------------------------------------------------
# Window (Administrēšana → Rezerves kopijas…)
# --------------------------------------------------------------------------
def size_text(n):
    return f"{n / 1048576:.1f} MB" if n >= 1048576 else f"{max(1, round(n / 1024))} KB"


def when_text(stamp):
    for fmt in ("%Y-%m-%d %H-%M-%S", "%Y-%m-%d %H-%M", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(stamp, fmt).strftime("%d.%m.%Y %H:%M")
        except ValueError:
            pass
    return stamp


class BackupWindow(tk.Toplevel):
    def __init__(self, parent, version="", on_restored=None):
        super().__init__(parent)
        self.version, self.on_restored = version, on_restored
        self.title("Rezerves kopijas")
        self.geometry("880x660")
        self.minsize(760, 560)
        self.configure(bg=CREAM)
        self.transient(parent)
        izskats.dialog_header(self, "Rezerves kopijas",
                              "Visu Pūrlādes datu kopijas: automātiski ik pēc dažām dienām un pirms katras jaunas "
                              "versijas. Ieteicams tās glabāt Google Drive mapē — tad tās ir arī mākonī.",
                              colour=GOLD, wrap=820)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.destroy).pack(side="right")
        self.busy = tk.Label(foot, text="", bg=WHITE, fg=MUTED, font=izskats.FONT_SMALL)
        self.busy.pack(side="left")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=12)
        box = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        box.pack(fill="x")
        inner = tk.Frame(box, bg=WHITE)
        inner.pack(fill="x", padx=14, pady=10)
        tk.Label(inner, text="Mape", bg=WHITE, fg=NAVY, font=izskats.FONT_BOLD).grid(row=0, column=0, sticky="w")
        self.dir_var = tk.StringVar(value=settings()["dir"])
        ttk.Entry(inner, textvariable=self.dir_var, width=62).grid(row=0, column=1, sticky="ew", padx=(10, 6))
        ttk.Button(inner, text="Izvēlēties mapi…", command=self.pick_dir).grid(row=0, column=2, sticky="w")
        inner.columnconfigure(1, weight=1)
        self.drive_box = tk.Frame(inner, bg=WHITE)
        self.drive_box.grid(row=1, column=1, columnspan=2, sticky="w", padx=(10, 0), pady=(4, 0))
        self.dir_note = izskats.note(inner, "", bg=WHITE, wrap=700)
        self.dir_note.grid(row=2, column=1, columnspan=2, sticky="w", padx=(10, 0), pady=(4, 0))
        opts = tk.Frame(inner, bg=WHITE)
        opts.grid(row=3, column=0, columnspan=3, sticky="w", pady=(10, 0))
        s = settings()
        self.days_var = tk.StringVar(value=str(s["days"]))
        self.keep_var = tk.StringVar(value=str(s["keep"]))
        tk.Label(opts, text="Automātiski ik pēc", bg=WHITE, fg=NAVY).pack(side="left")
        ttk.Spinbox(opts, from_=1, to=60, textvariable=self.days_var, width=4).pack(side="left", padx=4)
        tk.Label(opts, text="dienām, paturēt pēdējās", bg=WHITE, fg=NAVY).pack(side="left")
        ttk.Spinbox(opts, from_=2, to=100, textvariable=self.keep_var, width=4).pack(side="left", padx=4)
        tk.Label(opts, text="kopijas", bg=WHITE, fg=NAVY).pack(side="left")
        ttk.Button(opts, text="Saglabāt iestatījumus", style="Accent.TButton", command=self.save).pack(
            side="left", padx=(16, 0))
        self.fill_drives()

        lst = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        lst.pack(fill="both", expand=True, pady=(12, 0))
        head = tk.Frame(lst, bg=WHITE)
        head.pack(fill="x", padx=14, pady=(10, 6))
        tk.Label(head, text="Kopijas", bg=WHITE, fg=NAVY, font=("Georgia", 12, "bold")).pack(side="left")
        self.state_lbl = tk.Label(lst, text="", bg=WHITE, fg=MUTED, font=izskats.FONT_SMALL, anchor="w",
                                  justify="left", wraplength=800)
        ttk.Button(head, text="Atvērt mapi", command=self.open_dir).pack(side="right")
        ttk.Button(head, text="↺ Atjaunot no kopijas…", style="Danger.TButton", command=self.restore).pack(
            side="right", padx=6)
        ttk.Button(head, text="＋ Izveidot kopiju tagad", style="Accent.TButton", command=self.backup_now).pack(
            side="right")
        self.state_lbl.pack(fill="x", padx=14, pady=(0, 6))
        holder = tk.Frame(lst, bg=WHITE)
        holder.pack(fill="both", expand=True, padx=1, pady=(0, 1))
        self.tree = ttk.Treeview(holder, columns=("when", "note", "size"), show="headings", selectmode="browse")
        for key, title, width in (("when", "Izveidota", 160), ("note", "Piezīme", 380), ("size", "Izmērs", 100)):
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="e" if key == "size" else "w", stretch=key == "note")
        self.tree.tag_configure("odd", background=izskats.ZEBRA)
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.paths = {}
        self.refresh()
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()

    # ---- folder ------------------------------------------------------------------
    def fill_drives(self):
        for w in self.drive_box.winfo_children():
            w.destroy()
        drives = google_drive_dirs()
        if drives:
            tk.Label(self.drive_box, text="Google Drive šajā datorā:", bg=WHITE, fg=MUTED,
                     font=izskats.FONT_SMALL).pack(side="left")
            for d in drives[:3]:
                target = os.path.join(d, "Pūrlāde rezerves kopijas")
                link = tk.Label(self.drive_box, text=target, bg=WHITE, fg=NAVY, cursor="hand2",
                                font=("Segoe UI", 9, "underline"))
                link.pack(side="left", padx=(8, 0))
                link.bind("<Button-1>", lambda e, t=target: self.dir_var.set(t))
        self.update_note()
        self.dir_var.trace_add("write", lambda *a: self.update_note())

    def update_note(self):
        path = self.dir_var.get().strip()
        if not path:
            text = ("Mape nav izvēlēta — kopijas glabājas tikai šajā datorā: " + default_dir() + ". Lai tās būtu "
                    "arī mākonī, izvēlieties mapi Google Drive (datorā jābūt uzstādītai programmai “Google Drive "
                    "datoram”, tā sinhronizē mapi ar jūsu Google Drive).")
        elif is_google_drive(path):
            text = "✓ Google Drive mape — kopijas automātiski nonāks arī jūsu Google Drive mākonī."
        elif not google_drive_dirs():
            text = ("Šajā datorā nav atrasts Google Drive. Uzstādiet “Google Drive datoram” (drive.google.com → "
                    "Lejupielādēt), pieslēdzieties ar kolektīva Google kontu un izvēlieties mapi diskā “G:”.")
        else:
            text = "Šī nav Google Drive mape — kopijas glabāsies tikai šajā datorā."
        self.dir_note.configure(text=text)

    def pick_dir(self):
        start = self.dir_var.get().strip() or (google_drive_dirs() or [os.path.expanduser("~")])[0]
        path = filedialog.askdirectory(parent=self, title="Mape rezerves kopijām", initialdir=start,
                                       mustexist=False)
        if path:
            self.dir_var.set(os.path.normpath(path))

    def save(self):
        path = self.dir_var.get().strip()
        try:
            days, keep = int(self.days_var.get()), int(self.keep_var.get())
        except ValueError:
            messagebox.showwarning("Rezerves kopijas", "Dienu un kopiju skaitam jābūt skaitlim.", parent=self)
            return False
        if path:
            try:
                os.makedirs(path, exist_ok=True)
                test = os.path.join(path, ".purlade_test")
                with open(test, "w") as fh:
                    fh.write("ok")
                os.remove(test)
            except OSError as exc:
                messagebox.showerror("Rezerves kopijas", f"Šajā mapē nevar ierakstīt:\n{path}\n\n{exc}", parent=self)
                return False
        save_settings(dir=path, days=max(1, days), keep=max(2, keep))
        self.refresh()
        self.busy.configure(text="✓ Iestatījumi saglabāti")
        return True

    def open_dir(self):
        folder = backup_dir()
        os.makedirs(folder, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(folder)   # noqa
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception:
            messagebox.showinfo("Rezerves kopijas", folder, parent=self)

    # ---- list ----------------------------------------------------------------------
    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.paths = {}
        backups = list_backups()
        for i, (path, stamp, note, size) in enumerate(backups):
            iid = self.tree.insert("", "end", values=(when_text(stamp), note or "—", size_text(size)),
                                   tags=("odd",) if i % 2 else ())
            self.paths[iid] = path
        s = settings()
        last = s["last"]
        text = f"{len(backups)} kopijas mapē {backup_dir()}"
        if last:
            text += f" · pēdējā automātiskā: {when_text(last)}"
        if s["error"]:
            text += f" · ⚠ pēdējā kļūda: {s['error']}"
        self.state_lbl.configure(text=text, fg=RED if s["error"] else MUTED)

    def run(self, work, done):
        """Run `work` in a thread (the window stays alive), then done(result, error) in the window."""
        self.busy.configure(text="Strādā… (tas var aizņemt mirkli)")
        self.configure(cursor="watch")
        box = {}

        def go():
            try:
                box["result"] = work()
            except Exception as exc:
                box["error"] = exc
                K.log_error(traceback.format_exc())

        thread = threading.Thread(target=go, daemon=True)
        thread.start()

        def wait():
            if thread.is_alive():
                self.after(200, wait)
                return
            try:
                self.configure(cursor="")
                self.busy.configure(text="")
            except tk.TclError:
                return
            done(box.get("result"), box.get("error"))
        wait()

    def backup_now(self):
        if self.dir_var.get().strip() != settings()["dir"] and not self.save():
            return

        def done(path, error):
            if error:
                messagebox.showerror("Rezerves kopijas", f"Kopiju neizdevās izveidot:\n{error}", parent=self)
            else:
                save_settings(last=datetime.now().strftime("%Y-%m-%d %H:%M"), version=self.version, error="")
                self.busy.configure(text=f"✓ Izveidota: {os.path.basename(path)}")
            self.refresh()
        self.run(lambda: make_backup(version=self.version), done)

    def restore(self):
        sel = self.tree.selection()
        path = self.paths.get(sel[0]) if sel else None
        if path is None:
            path = filedialog.askopenfilename(parent=self, title="Rezerves kopija", initialdir=backup_dir(),
                                              filetypes=[("Pūrlādes rezerves kopija", "*.zip")])
            if not path:
                return
        info = read_info(path)
        when = info.get("izveidota", "")
        online = D.is_online()
        text = (f"Atjaunot datus no kopijas{' (' + when + ')' if when else ''}?\n\n"
                + ("Tiešsaistes datubāzē VISI dati tiks aizvietoti ar kopijā esošajiem — tas attiecas uz visiem "
                   "datoriem un Kabatas Pūrlādi. " if online else
                   "Šī datora lokālā datubāze tiks aizvietota ar kopiju. ")
                + "Pēc kopijas izveidotās izmaiņas pazudīs.\n\nPirms tam pašreizējie dati tiks saglabāti kopijā "
                  "“pirms atjaunošanas”.")
        if not messagebox.askyesno("Atjaunot no kopijas", text, icon="warning", parent=self):
            return
        if online and not self.confirm_word():
            return

        def done(_result, error):
            if error:
                messagebox.showerror("Atjaunot no kopijas", f"Atjaunot neizdevās:\n{error}\n\nPašreizējie dati "
                                     "saglabāti kopijā “pirms atjaunošanas”.", parent=self)
                self.refresh()
                return
            messagebox.showinfo("Atjaunot no kopijas", "Dati atjaunoti. Pūrlādes sākuma lapa tiks atvērta no "
                                                       "jauna.", parent=self)
            self.destroy()
            if self.on_restored:
                self.on_restored()
        self.run(lambda: restore(path, version=self.version), done)

    def confirm_word(self):
        win = tk.Toplevel(self)
        win.title("Apstiprināt")
        win.configure(bg=WHITE, padx=20, pady=16)
        win.transient(self)
        word = tk.StringVar()
        tk.Label(win, text="Lai aizvietotu tiešsaistes datus, ierakstiet ATJAUNOT:", bg=WHITE, fg=NAVY).pack(
            anchor="w")
        ttk.Entry(win, textvariable=word, width=20).pack(anchor="w", pady=8)
        result = {"ok": False}

        def ok():
            result["ok"] = word.get().strip().upper() == "ATJAUNOT"
            win.destroy()
        ttk.Button(win, text="Atjaunot", style="Danger.TButton", command=ok).pack(side="right")
        ttk.Button(win, text="Atcelt", command=win.destroy).pack(side="right", padx=6)
        win.grab_set()
        self.wait_window(win)
        return result["ok"]


def show(parent, version="", on_restored=None):
    return BackupWindow(parent, version, on_restored)
