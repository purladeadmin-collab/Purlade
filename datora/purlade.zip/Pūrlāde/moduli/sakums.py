"""
Pūrlāde — sākuma lapa (v0.8): vadības panelis blakus sānu joslai.

  * augšā datums, sezona un ātrās pogas (šodienas notikums, jauns notikums);
  * rādītāji: aktīvie dejotāji (pa grupām), sezonas cītība, izsniegtie tērpi, dejas repertuārā;
  * “Tuvākie notikumi” — nākamie notikumi ar atbildēm (Būs / Nebūs / Varbūt); klikšķis atver notikumu;
  * “Jāpievērš uzmanība” — neatbildētie dejotāji, ilgi neatgriezti tērpi, dejas ar nepilnu sastāvu,
    tuvākās dzimšanas dienas.
Katra daļa tiek rādīta tikai tad, ja lietotāja lomai ir piekļuve attiecīgajam modulim (moduli/piekluve.py),
un kļūda vienā daļā neaptur pārējās (tā tiek ierakstīta kludas.log).
"""

import traceback
import tkinter as tk
from datetime import date, timedelta
from tkinter import ttk

try:
    from moduli import kopeja as K
    from moduli import izskats as I
except ImportError:
    import kopeja as K
    import izskats as I

CREAM, NAVY, RED, WHITE, GOLD = K.CREAM, K.NAVY, K.RED, K.WHITE, K.GOLD
GREEN = K.GREEN
WEEKDAYS = ["Pirmdiena", "Otrdiena", "Trešdiena", "Ceturtdiena", "Piektdiena", "Sestdiena", "Svētdiena"]
SHORT_WD = ["P", "O", "T", "C", "Pk", "S", "Sv"]

KIND_REHEARSAL, KIND_EXTRA, KIND_CONCERT = "Mēģinājums", "Papildmēģinājums", "Koncerts"
KIND_REVIEW, KIND_EVENT = "Skate", "Kolektīva pasākums"
KIND_COLOUR = {KIND_REHEARSAL: "#C4703A", KIND_EXTRA: "#C4703A", KIND_CONCERT: "#7A5C99", KIND_REVIEW: RED,
               KIND_EVENT: "#2E7D6B"}
CANCELLED = "Atcelts"
ANS_YES, ANS_NO, ANS_MAYBE = "Būs", "Nebūs", "Varbūt"
MARKS_PRESENT = ("Ieradās", "Nokavēja")
ROLE_RESERVE = "Rezerve"
REPERTOIRE, LEARNING = "Repertuārā", "Procesā"


def season_start(today):
    return date(today.year if today.month >= 9 else today.year - 1, 9, 1)


def show_date(iso):
    try:
        return f"{iso[8:10]}.{iso[5:7]}."
    except (TypeError, IndexError):
        return ""


def _q(con, sql, params=()):
    return con.execute(sql, params).fetchall()


def _has(con, table):
    try:
        return K._has_table(con, table)
    except Exception:
        return False


def _safe(parts, name, fn):
    """Run one part of the page; a problem is logged and the part left out."""
    try:
        return fn()
    except Exception:
        K.log_error(f"Sākuma lapa ({name}):\n" + traceback.format_exc())
        return None


# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
def active_dancers(con):
    rows = _q(con, "SELECT id, first_name, last_name, status, role, dancer_group, birth_date FROM dancers")
    return [r for r in rows if (r[3] or K.STATUS_ACTIVE) == K.STATUS_ACTIVE and (r[4] or K.ROLE_DANCER) == K.ROLE_DANCER]


def kpi_dancers(con):
    dancers = active_dancers(con)
    by = {}
    for r in dancers:
        g = (r[5] or K.DEFAULT_DANCER_GROUP)
        by[g] = by.get(g, 0) + 1
    sub = " · ".join(f"{g} {by[g]}" for g in K.DANCER_GROUPS if by.get(g))
    return ("Aktīvi dejotāji", str(len(dancers)), sub or "—", "#2E7D6B", "kopas_purs")


def kpi_attendance(con, today):
    if not _has(con, "attendance"):
        return None
    start = season_start(today).isoformat()
    sessions = _q(con, "SELECT id, session_date FROM attendance_sessions WHERE session_date>=? AND session_date<=? "
                       "AND kind IN (?, ?) ORDER BY session_date DESC", (start, today.isoformat(), KIND_REHEARSAL,
                                                                          KIND_EXTRA))
    if not sessions:
        return ("Cītība šosezon", "—", "vēl nav mēģinājumu ar atzīmēm", "#C4703A", "citibas_purs")
    ids = [s[0] for s in sessions]
    marks = {}
    for sid, mark in _q(con, "SELECT session_id, mark FROM attendance WHERE session_id IN (" +
                             ",".join("?" * len(ids)) + ")", ids):
        marks.setdefault(sid, []).append(mark)

    def pct(sids):
        all_m = [m for s in sids for m in marks.get(s, []) if m]
        return round(100 * sum(1 for m in all_m if m in MARKS_PRESENT) / len(all_m)) if all_m else None

    season = pct(ids)
    marked = [s for s in ids if marks.get(s)]
    last4 = pct(marked[:4])
    return ("Cītība šosezon", f"{season} %" if season is not None else "—",
            f"pēdējie {min(4, len(marked))} mēģinājumi {last4} %" if last4 is not None else "atzīmju vēl nav",
            "#C4703A", "citibas_purs")


def kpi_costumes(con, today):
    if not _has(con, "checkouts"):
        return None
    rows = _q(con, "SELECT checkout_date FROM checkouts WHERE return_date IS NULL OR return_date=''")
    old = (today - timedelta(days=30)).isoformat()
    long_out = sum(1 for (d,) in rows if d and d < old)
    return ("Izsniegti tērpi", str(len(rows)), f"{long_out} ilgāk par 30 dienām" if long_out else "visi nesen",
            RED, "terpu_purs")


def kpi_dances(con):
    if not _has(con, "dances"):
        return None
    rows = _q(con, "SELECT status FROM dances")
    rep = sum(1 for (s,) in rows if s == REPERTOIRE)
    learn = sum(1 for (s,) in rows if s == LEARNING)
    return ("Dejas repertuārā", str(rep), f"{learn} procesā", NAVY, "deju_purs")


def upcoming(con, today, limit=6):
    has_details = _has(con, "event_details")
    sql = ("SELECT s.id, s.session_date, s.kind, s.title, s.start_time" +
           (", d.status, d.for_groups, d.subkind, d.place, d.invited" if has_details else "") +
           " FROM attendance_sessions s" +
           (" LEFT JOIN event_details d ON d.session_id = s.id" if has_details else "") +
           " WHERE s.session_date>=? ORDER BY s.session_date, s.start_time, s.id")
    events = []
    for r in _q(con, sql, (today.isoformat(),)):
        r = list(r) + [""] * (10 - len(r))
        sid, day, kind, title, tm, status, groups, subkind, place, invited = r
        if (status or "") == CANCELLED:
            continue
        events.append({"id": sid, "date": day, "kind": kind or "", "title": title or "", "time": tm or "",
                       "groups": groups or "", "subkind": subkind or "", "place": place or "",
                       "invited": invited or ""})
        if len(events) >= limit:
            break
    if events and _has(con, "event_participants"):
        ids = [e["id"] for e in events]
        answers = {}
        for sid, ans in _q(con, "SELECT session_id, answer FROM event_participants WHERE session_id IN (" +
                                ",".join("?" * len(ids)) + ")", ids):
            answers.setdefault(sid, []).append(ans or "")
        for e in events:
            a = answers.get(e["id"], [])
            e["yes"] = sum(1 for x in a if x and x not in (ANS_NO, ANS_MAYBE))
            e["no"] = sum(1 for x in a if x == ANS_NO)
            e["maybe"] = sum(1 for x in a if x == ANS_MAYBE)
            e["answered"] = {x for x in a if x}
    return events


def audience_size(e, dancers):
    """Roughly how many dancers the event is for (its groups; a publicity event — the invited)."""
    if e.get("subkind") == K.SUBKIND_PUBLICITY:
        return len(K.invited_ids(e.get("invited", "")))
    groups = set(K.event_groups(e.get("groups", ""))) or set(K.DANCER_GROUPS)
    return sum(1 for r in dancers if (r[5] or K.DEFAULT_DANCER_GROUP) in groups)


def alerts(con, today, acc, events):
    out = []   # (colour, title, where, action key)
    sees_events = acc.can_open("notikumu_purs") or acc.can_open("citibas_purs")
    if sees_events and events and _has(con, "event_participants"):
        dancers = active_dancers(con)
        soon = [e for e in events if e["date"] <= (today + timedelta(days=7)).isoformat()]
        for e in soon[:2]:
            answered = _q(con, "SELECT COUNT(*) FROM event_participants WHERE session_id=? AND "
                               "COALESCE(answer,'')<>''", (e["id"],))[0][0]
            missing = max(0, audience_size(e, dancers) - answered)
            if missing:
                when = "šodien" if e["date"] == today.isoformat() else show_date(e["date"])
                out.append(("#C4703A", f"{missing} dejotāji nav atbildējuši: {event_name(e)} ({when})",
                            "Kabatas Pūrlāde / Notikumu pūrs", ("event", e)))
        for e in events:
            if e["kind"] in (KIND_CONCERT, KIND_REVIEW) and e.get("no"):
                out.append((RED, f"{e['no']} dejotāji nebūs: {event_name(e)} ({show_date(e['date'])})",
                            "Notikumu pūrs → Programma", ("event", e)))
                break
    if acc.can_open("deju_purs") and _has(con, "dance_cast"):
        rows = _q(con, "SELECT d.id, d.men_count, d.women_count, "
                       "(SELECT COUNT(*) FROM dance_cast c WHERE c.dance_id=d.id AND COALESCE(c.role,'') NOT IN (?, ?)) "
                       "FROM dances d WHERE d.status=?", (ROLE_RESERVE, "Solists", REPERTOIRE))   # solisti neskaitās
        short = 0
        for _id, men, women, have in rows:
            need = (int(men) if str(men or "").isdigit() else 0) + (int(women) if str(women or "").isdigit() else 0)
            if need and have < need:
                short += 1
        if short:
            out.append((RED, f"{short} dejām repertuārā nepilns sastāvs", "Deju pūrs", ("module", "deju_purs")))
    if acc.can_open("terpu_purs") and _has(con, "checkouts"):
        old = (today - timedelta(days=30)).isoformat()
        n = _q(con, "SELECT COUNT(*) FROM checkouts WHERE (return_date IS NULL OR return_date='') AND "
                    "checkout_date<?", (old,))[0][0]
        if n:
            out.append((GOLD, f"{n} tērpi izsniegti ilgāk par 30 dienām", "Tērpu pūrs → Izsniegtie",
                        ("terpu_overdue", None)))
    if acc.can_open("kopas_purs"):
        names = []
        for r in active_dancers(con):
            b = r[6] or ""
            if len(b) >= 10:
                for i in range(8):
                    d = today + timedelta(days=i)
                    if b[5:10] == d.isoformat()[5:10]:
                        names.append((i, K.full_name(r[1], r[2]), d))
        names.sort()
        if names:
            text = ", ".join(f"{n} ({'šodien' if i == 0 else SHORT_WD[d.weekday()] + ' ' + show_date(d.isoformat())})"
                             for i, n, d in names[:4])
            more = f" un vēl {len(names) - 4}" if len(names) > 4 else ""
            out.append((NAVY, f"Dzimšanas dienas: {text}{more}", "Kopas pūrs", ("module", "kopas_purs")))
    return out


def event_name(e):
    if e["title"]:
        return e["title"]
    if e["subkind"]:
        return e["subkind"]
    return e["kind"]


# --------------------------------------------------------------------------
# Page
# --------------------------------------------------------------------------
def build(host, app):
    acc = app.access
    today = date.today()
    con = K.connect_db()
    try:
        _build(host, app, acc, today, con)
    finally:
        try:
            con.close()
        except Exception:
            pass


def _build(host, app, acc, today, con):
    page = tk.Frame(host, bg=CREAM)
    page.pack(fill="both", expand=True, padx=28, pady=(20, 10))

    # ---- title row
    top = tk.Frame(page, bg=CREAM)
    top.pack(fill="x")
    left = tk.Frame(top, bg=CREAM)
    left.pack(side="left")
    start = season_start(today)
    tk.Label(left, text=f"{WEEKDAYS[today.weekday()]}, {today.strftime('%d.%m.%Y')} · "
                        f"{start.year}./{str(start.year + 1)[2:]}. sezona",
             font=("Segoe UI", 10), bg=CREAM, fg=I.MUTED).pack(anchor="w")
    tk.Label(left, text="Sākums", font=("Georgia", 24, "bold"), bg=CREAM, fg=NAVY).pack(anchor="w")
    actions = tk.Frame(top, bg=CREAM)
    actions.pack(side="right", anchor="s")
    if acc.can_open("notikumu_purs") and (acc.can_edit("notikumu_purs") or acc.social):
        ttk.Button(actions, text="+ Jauns notikums", style="Accent.TButton",
                   command=lambda: app.open_module_key("notikumu_purs", new_event)).pack(side="right")
    if acc.can_open("citibas_purs"):
        ttk.Button(actions, text="▶ Šodienas mēģinājums",
                   command=lambda: app.open_module_key("citibas_purs", lambda a: a.open_today())).pack(
            side="right", padx=(0, 8))

    # ---- figures
    kpis = []
    for fn, key in ((lambda: kpi_dancers(con), "kopas_purs"), (lambda: kpi_attendance(con, today), "citibas_purs"),
                    (lambda: kpi_costumes(con, today), "terpu_purs"), (lambda: kpi_dances(con), "deju_purs")):
        if acc.can_open(key):
            k = _safe(None, key, fn)
            if k:
                kpis.append(k)
    if kpis:
        row = tk.Frame(page, bg=CREAM)
        row.pack(fill="x", pady=(16, 0))
        for i, (label, value, sub, colour, key) in enumerate(kpis):
            row.columnconfigure(i, weight=1, uniform="k")
            box = tk.Frame(row, bg=WHITE, highlightbackground=I.LINE, highlightthickness=1, cursor="hand2")
            box.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == len(kpis) - 1 else 6))
            inner = tk.Frame(box, bg=WHITE, cursor="hand2")
            inner.pack(fill="both", expand=True, padx=14, pady=10)
            w = [box, inner,
                 tk.Label(inner, text=label, font=("Segoe UI", 9), bg=WHITE, fg=I.MUTED, cursor="hand2"),
                 tk.Label(inner, text=value, font=("Georgia", 22, "bold"), bg=WHITE, fg=colour, cursor="hand2"),
                 tk.Label(inner, text=sub, font=("Segoe UI", 9), bg=WHITE, fg="#4A4535", cursor="hand2")]
            for lbl in w[2:]:
                lbl.pack(anchor="w")
            for x in w:
                x.bind("<Button-1>", lambda e, k=key: app.open_module_key(k))

    # ---- events and alerts
    cols = tk.Frame(page, bg=CREAM)
    cols.pack(fill="both", expand=True, pady=(16, 0))
    cols.columnconfigure(0, weight=3, uniform="c")
    cols.columnconfigure(1, weight=2, uniform="c")
    cols.rowconfigure(0, weight=1)
    sees_events = acc.can_open("notikumu_purs") or acc.can_open("citibas_purs")
    events = (_safe(None, "notikumi", lambda: upcoming(con, today)) or []) if sees_events else []
    if sees_events:
        outer, body = I.card(cols, "Tuvākie notikumi", padx=0, pady=0)
        outer.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        if acc.can_open("notikumu_purs"):
            link = tk.Label(outer.head, text="Visi notikumi →", font=("Segoe UI", 9, "underline"), bg=WHITE,
                            fg=NAVY, cursor="hand2")
            link.pack(side="right")
            link.bind("<Button-1>", lambda e: app.open_module_key("notikumu_purs"))
        if not events:
            tk.Label(body, text="Nav ieplānotu notikumu.", font=("Segoe UI", 10), bg=WHITE, fg=I.MUTED).pack(
                anchor="w", padx=16, pady=12)
        for e in events:
            event_row(body, e, today, lambda ev=e: open_event(app, ev))
    outer2, body2 = I.card(cols, "Jāpievērš uzmanība", padx=0, pady=0)
    outer2.grid(row=0, column=1 if sees_events else 0, columnspan=1 if sees_events else 2, sticky="nsew",
                padx=(8, 0) if sees_events else 0)
    items = _safe(None, "uzmanība", lambda: alerts(con, today, acc, events)) or []
    if not items:
        tk.Label(body2, text="Viss kārtībā — nekas steidzams.", font=("Segoe UI", 10), bg=WHITE,
                 fg=GREEN).pack(anchor="w", padx=16, pady=12)
    for colour, title, where, action in items:
        alert_row(body2, colour, title, where, lambda a=action: run_action(app, a))

    # ---- footer
    foot = tk.Frame(host, bg=CREAM)
    foot.pack(side="bottom", fill="x", padx=28, pady=(0, 8))
    online = bool(K.datubaze.online_config())
    tk.Label(foot, text="■", font=("Segoe UI", 8), bg=CREAM, fg=GREEN if online else I.MUTED).pack(side="left")
    tk.Label(foot, text=f"{K.database_label().capitalize()} · dators: {K.datubaze.computer_name()}",
             font=("Segoe UI", 9), bg=CREAM, fg="#4A4535").pack(side="left", padx=(4, 0))
    tk.Label(foot, text=K.COPYRIGHT, font=("Segoe UI", 8), bg=CREAM, fg="#4A4535").pack(side="right")


def event_row(parent, e, today, on_click):
    colour = KIND_COLOUR.get(e["kind"], NAVY)
    row = tk.Frame(parent, bg=WHITE, cursor="hand2")
    row.pack(fill="x")
    inner = tk.Frame(row, bg=WHITE, cursor="hand2")
    inner.pack(fill="x", padx=16, pady=8)
    badge = I.date_badge(inner, e["date"], colour)
    badge.pack(side="left")
    text = tk.Frame(inner, bg=WHITE, cursor="hand2")
    text.pack(side="left", fill="x", expand=True, padx=12)
    d = date.fromisoformat(e["date"])
    when = "Šodien" if d == today else ("Rīt" if d == today + timedelta(days=1) else WEEKDAYS[d.weekday()])
    meta = " · ".join(x for x in (when + (f" {e['time']}" if e["time"] else ""), e["place"]) if x)
    t1 = tk.Label(text, text=event_name(e), font=("Segoe UI", 10, "bold"), bg=WHITE, fg=NAVY, anchor="w",
                  cursor="hand2")
    t1.pack(anchor="w")
    t2 = tk.Label(text, text=meta, font=("Segoe UI", 9), bg=WHITE, fg=I.MUTED, anchor="w", cursor="hand2")
    t2.pack(anchor="w")
    groups = K.event_groups(e["groups"])
    gtext = ", ".join(groups) if groups and set(groups) != set(K.DANCER_GROUPS) else "visas"
    g = tk.Label(inner, text=f" {gtext} ", font=("Segoe UI", 8, "bold"), bg="#EEF3F1", fg="#1F5E4F")
    g.pack(side="left", padx=(0, 10))
    ans = f"Būs {e.get('yes', 0)} · Nebūs {e.get('no', 0)}" + (f" · ? {e['maybe']}" if e.get("maybe") else "")
    a = tk.Label(inner, text=ans, font=("Segoe UI", 9), bg=WHITE, fg=NAVY, width=22, anchor="e", cursor="hand2")
    a.pack(side="right")
    tk.Frame(parent, bg=I.LINE_SOFT, height=1).pack(fill="x")
    for w in (row, inner, text, t1, t2, a):
        w.bind("<Button-1>", lambda ev: on_click())
    _hover(row, [row, inner, text, t1, t2, a, g], WHITE, "#FBF6EA", keep=[g])


def alert_row(parent, colour, title, where, on_click):
    row = tk.Frame(parent, bg=WHITE, cursor="hand2")
    row.pack(fill="x")
    inner = tk.Frame(row, bg=WHITE, cursor="hand2")
    inner.pack(fill="x", padx=16, pady=8)
    dot = tk.Frame(inner, bg=colour, width=10, height=10)
    dot.pack(side="left", anchor="n", pady=(5, 0))
    text = tk.Frame(inner, bg=WHITE, cursor="hand2")
    text.pack(side="left", fill="x", expand=True, padx=(10, 0))
    t1 = tk.Label(text, text=title, font=("Segoe UI", 10, "bold"), bg=WHITE, fg=NAVY, anchor="w", justify="left",
                  wraplength=360, cursor="hand2")
    t1.pack(anchor="w")
    t2 = tk.Label(text, text=where, font=("Segoe UI", 9), bg=WHITE, fg=I.MUTED, anchor="w", cursor="hand2")
    t2.pack(anchor="w")
    tk.Frame(parent, bg=I.LINE_SOFT, height=1).pack(fill="x")
    for w in (row, inner, text, t1, t2):
        w.bind("<Button-1>", lambda ev: on_click())
    t1.bind("<Configure>", lambda ev: t1.configure(wraplength=max(160, text.winfo_width() - 8)))
    _hover(row, [row, inner, text, t1, t2], WHITE, "#FBF6EA")


def _hover(row, widgets, normal, over, keep=()):
    def paint(colour):
        for w in widgets:
            if w not in keep:
                try:
                    w.configure(bg=colour)
                except tk.TclError:
                    pass
    row.bind("<Enter>", lambda e: paint(over))
    row.bind("<Leave>", lambda e: paint(normal))


# --------------------------------------------------------------------------
# Actions
# --------------------------------------------------------------------------
def new_event(module_app):
    try:
        from moduli import notikumu_purs
    except ImportError:
        import notikumu_purs
    notikumu_purs.EventWindow(module_app)


def open_event(app, e):
    """An event on the start page: Notikumu pūrs (rehearsals: Cītības pūrs when Notikumu pūrs is not allowed)."""
    acc = app.access
    rehearsal = e["kind"] in (KIND_REHEARSAL, KIND_EXTRA)
    if acc.can_open("notikumu_purs") and not (rehearsal and acc.can_open("citibas_purs")):
        def then(module_app):
            from moduli import notikumu_purs
            notikumu_purs.EventWindow(module_app, e["id"])
        app.open_module_key("notikumu_purs", then)
    elif acc.can_open("citibas_purs"):
        def then(module_app):
            from moduli import citibas_purs
            citibas_purs.SessionWindow(module_app, e["id"])
        app.open_module_key("citibas_purs", then)


def run_action(app, action):
    kind, value = action
    if kind == "event":
        open_event(app, value)
    elif kind == "module":
        app.open_module_key(value)
    elif kind == "terpu_overdue":   # Tērpu pūrs v0.5.5: the list of costumes kept longer than 30 days
        app.open_module_key("terpu_purs", lambda m: m.show_issued(overdue=True) if hasattr(m, "show_issued") else None)
