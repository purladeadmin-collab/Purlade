"""
Pūrlāde — Sezonas pārskats (sānu josla → Kolektīvs → “Sezonas pārskats”, Pūrlāde v0.9.3)

Viena sezona (1. septembris – 31. augusts) vienā dokumentā, no visiem moduļiem:
    Kolektīvs          – dejotāji pēc grupām un dzimuma, kas sezonā pievienojušies (Kopas pūrs)
    Mēģinājumi         – cik notika, vidējais apmeklējums kopā un pa mēnešiem, cītīgākie dejotāji (Cītības pūrs)
    Uzstāšanās         – koncerti, skates un kolektīva pasākumi ar vietu, dejām un dalībniekiem (Notikumu pūrs)
    Repertuārs         – deju skaits pēc statusa, sezonā iestudētās, visvairāk dejotās dejas (Deju pūrs)
    Tērpi              – cik tērpu, cik izsniegti, kādā stāvoklī (Tērpu pūrs)
    Finanses           – sezonas ienākumi un izdevumi pa kategorijām, atlikums sezonas beigās (Zelta pūrs)
Parādās tikai tās daļas, kuru moduļus lietotāja loma drīkst atvērt. Grupas izvēle (A / Studija / VPDK) attiecas uz
dejotājiem, mēģinājumiem, uzstāšanos, repertuāru un finansēm.

Pārskatu var saglabāt kā HTML failu: tas atveras pārlūkā, kur to var izdrukāt vai saglabāt kā PDF (Ctrl+P).
Requirements: Python 3.8+ (only the standard library).
"""

import calendar
import html
import os
import sqlite3
import traceback
import webbrowser
import tkinter as tk
from datetime import date
from tkinter import ttk, messagebox, filedialog

try:
    from moduli import kopeja as K
    from moduli import izskats
    from moduli import piekluve
except ImportError:  # started from inside the moduli folder
    import kopeja as K
    import izskats
    import piekluve

CREAM, RED, NAVY, GOLD, WHITE, GREEN, GREY = K.CREAM, K.RED, K.NAVY, K.GOLD, K.WHITE, K.GREEN, K.GREY
LINE, MUTED = izskats.LINE, izskats.MUTED

ALL_GROUPS = "Visas grupas"
REHEARSAL_KINDS = ("Mēģinājums", "Papildmēģinājums")
KIND_CONCERT, KIND_REVIEW = "Koncerts", "Skate"
KIND_EVENT = K.EVENT_KIND_GROUP
CAME = ("Ieradās", "Nokavēja")
ST_CANCELLED = "Atcelts"
GOOD_PCT, LOW_PCT = 90, 70
DANCE_STATUSES = ["Repertuārā", "Procesā", "Atpūtā", "Arhīvā"]
INCOME, EXPENSE = "Ienākumi", "Izdevumi"
MONTHS = ["janvāris", "februāris", "marts", "aprīlis", "maijs", "jūnijs", "jūlijs", "augusts", "septembris",
          "oktobris", "novembris", "decembris"]

# parts of the report: (key, title, module that must be open-able)
SECTIONS = [("people", "Kolektīvs", "kopas_purs"), ("rehearsals", "Mēģinājumi un apmeklējums", "citibas_purs"),
            ("shows", "Koncerti, skates un pasākumi", "notikumu_purs"), ("dances", "Repertuārs", "deju_purs"),
            ("costumes", "Tērpi", "terpu_purs"), ("money", "Finanses", "zelta_purs")]


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def show_date(iso):
    try:
        y, m, d = (iso or "").split("-")
        return f"{int(d):02d}.{int(m):02d}.{int(y):04d}"
    except ValueError:
        return ""


def season_of(day):
    start = day.year if day.month >= 9 else day.year - 1
    return date(start, 9, 1), date(start + 1, 8, 31)


def season_label(start_year):
    return f"{start_year}/{start_year + 1}"


def pct(came, marked):
    return round(100 * came / marked) if marked else None


def pct_text(value):
    return "—" if value is None else f"{value} %"


def money(cents):
    sign = "−" if cents < 0 else ""
    whole, rest = divmod(abs(int(cents)), 100)
    return f"{sign}{whole:,}".replace(",", " ") + f",{rest:02d} €"


def minutes_text(seconds):
    m = round(seconds / 60)
    return f"{m // 60} h {m % 60:02d} min" if m >= 60 else f"{m} min"


def count_word(n, one, many):
    return f"{n} {one}" if n % 10 == 1 and n % 100 != 11 else f"{n} {many}"


def has_table(con, name):
    try:
        return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())
    except sqlite3.Error:
        return False


def columns(con, table):
    try:
        return {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
    except sqlite3.Error:
        return set()


def seasons_with_data(con):
    """Start years of seasons that have events (newest first; this season always included)."""
    years = {season_of(date.today())[0].year}
    if has_table(con, "attendance_sessions"):
        for (d,) in con.execute("SELECT DISTINCT session_date FROM attendance_sessions").fetchall():
            try:
                years.add(season_of(date.fromisoformat(d))[0].year)
            except (TypeError, ValueError):
                pass
    return sorted(years, reverse=True)


# --------------------------------------------------------------------------
# The report as blocks: ("h", title) ("p", text) ("kv", [(label, value)]) ("table", header, rows, align)
# ("bars", [(label, value 0..100, text)])
# --------------------------------------------------------------------------
class Report:
    def __init__(self, con, start_year, group=None, sections=None):
        self.con = con
        self.start, self.end = date(start_year, 9, 1), date(start_year + 1, 8, 31)
        self.today = date.today()
        self.until = min(self.end, self.today)          # events that have taken place
        self.group = group                                # None — all groups
        self.sections = sections or [k for k, _t, _m in SECTIONS]
        self.blocks = []
        self.s, self.e, self.u = self.start.isoformat(), self.end.isoformat(), self.until.isoformat()
        self.dancer_group = {}
        if "dancer_group" in columns(con, "dancers"):
            self.dancer_group = {i: (g or "").strip() or K.DEFAULT_DANCER_GROUP
                                 for i, g in con.execute("SELECT id, dancer_group FROM dancers").fetchall()}
        self.event_groups = {}
        if has_table(con, "event_details"):
            self.event_groups = {sid: g or "" for sid, g in
                                 con.execute("SELECT session_id, for_groups FROM event_details").fetchall()}

    def in_group(self, dancer_id):
        return self.group is None or self.dancer_group.get(dancer_id, K.DEFAULT_DANCER_GROUP) == self.group

    def event_in_group(self, sid):
        return self.group is None or K.in_event_groups(self.group, self.event_groups.get(sid, ""))

    def add(self, *block):
        self.blocks.append(block)

    def build(self):
        builders = {"people": self.people, "rehearsals": self.rehearsals, "shows": self.shows,
                    "dances": self.dances, "costumes": self.costumes, "money": self.money}
        titles = {k: t for k, t, _m in SECTIONS}
        for key in self.sections:
            self.add("h", titles[key])
            try:
                builders[key]()
            except sqlite3.Error as exc:
                K.log_error(traceback.format_exc())
                self.add("p", f"Šo daļu neizdevās sagatavot: {exc}")
        return self.blocks

    # ---- Kolektīvs ----------------------------------------------------------------
    def people(self):
        con = self.con
        rows = con.execute("SELECT id, gender, join_date, first_name, last_name FROM dancers WHERE "
                           + K.active_dancer_sql("dancers")).fetchall()
        rows = [r for r in rows if self.in_group(r[0])]
        women = sum(1 for r in rows if r[1] == K.GENDER_FEMALE)
        men = sum(1 for r in rows if r[1] == K.GENDER_MALE)
        paused = con.execute("SELECT id FROM dancers WHERE status=? AND " + K.dancer_role_sql("dancers"),
                             (K.STATUS_INACTIVE,)).fetchall()
        paused = sum(1 for (i,) in paused if self.in_group(i))
        self.add("kv", [("Aktīvi dejotāji (tagad)", str(len(rows))), ("Sievietes / vīrieši", f"{women} / {men}"),
                        ("Uz pauzes", str(paused))])
        if self.group is None and self.dancer_group:
            per = {}
            for r in rows:
                g = self.dancer_group.get(r[0], K.DEFAULT_DANCER_GROUP)
                per.setdefault(g, [0, 0, 0])
                per[g][0] += 1
                per[g][1 if r[1] == K.GENDER_FEMALE else 2] += 1
            self.add("table", ["Grupa", "Dejotāji", "Sievietes", "Vīrieši"],
                     [[g] + [str(x) for x in per[g]] for g in K.DANCER_GROUPS if g in per], "lrrr")
        joined = [r for r in con.execute("SELECT id, gender, join_date, first_name, last_name FROM dancers WHERE "
                                         "join_date BETWEEN ? AND ? AND " + K.dancer_role_sql("dancers"),
                                         (self.s, self.e)).fetchall() if self.in_group(r[0])]
        if joined:
            joined.sort(key=lambda r: r[2])
            self.add("p", f"Sezonā pievienojušies: {len(joined)} — "
                     + ", ".join(f"{K.full_name(r[3], r[4])} ({show_date(r[2])})" for r in joined) + ".")
        else:
            self.add("p", "Sezonā pievienojušos dejotāju nav (vai Kopas pūrā nav norādīts iestāšanās datums).")

    # ---- Mēģinājumi ---------------------------------------------------------------
    def rehearsals(self):
        con = self.con
        sessions = [r for r in con.execute(
            "SELECT id, session_date FROM attendance_sessions WHERE kind IN (?, ?) AND session_date BETWEEN ? AND ?",
            REHEARSAL_KINDS + (self.s, self.u)).fetchall() if self.event_in_group(r[0])]
        planned = [r for r in con.execute(
            "SELECT id FROM attendance_sessions WHERE kind IN (?, ?) AND session_date > ? AND session_date <= ?",
            REHEARSAL_KINDS + (self.u, self.e)).fetchall() if self.event_in_group(r[0])]
        ids = {r[0] for r in sessions}
        date_of = dict(sessions)
        marks = []
        if ids:
            for sid, did, mark in con.execute("SELECT session_id, dancer_id, mark FROM attendance").fetchall():
                if sid in ids and self.in_group(did):
                    marks.append((sid, did, mark))
        came = sum(1 for m in marks if m[2] in CAME)
        marked_sessions = {m[0] for m in marks}
        avg = pct(came, len(marks))
        self.add("kv", [("Notikušie mēģinājumi", str(len(sessions))),
                        ("Ar apmeklējuma atzīmēm", str(len(marked_sessions))),
                        ("Vidējais apmeklējums", pct_text(avg)),
                        ("Vēl ieplānoti šajā sezonā", str(len(planned)))])
        if not marks:
            self.add("p", "Šajā sezonā vēl nav mēģinājumu ar apmeklējuma atzīmēm.")
            return
        # by month
        per = {}
        for sid, _did, mark in marks:
            key = date_of[sid][:7]
            per.setdefault(key, [set(), 0, 0])
            per[key][0].add(sid)
            per[key][1] += 1
            per[key][2] += mark in CAME
        bars = []
        for key in sorted(per):
            p = pct(per[key][2], per[key][1])
            bars.append((f"{MONTHS[int(key[5:7]) - 1]} {key[:4]}", p or 0,
                         f"{pct_text(p)} · {count_word(len(per[key][0]), 'mēģinājums', 'mēģinājumi')}"))
        self.add("bars", bars)
        # dancers
        by_dancer = {}
        for _sid, did, mark in marks:
            c = by_dancer.setdefault(did, [0, 0])
            c[0] += 1
            c[1] += mark in CAME
        active = {r[0]: K.full_name(r[1], r[2]) for r in con.execute(
            "SELECT id, first_name, last_name FROM dancers WHERE " + K.active_dancer_sql("dancers")).fetchall()}
        stats = [(active[d], pct(c[1], c[0]), c[0]) for d, c in by_dancer.items() if d in active]
        good = sorted((s for s in stats if s[1] >= GOOD_PCT), key=lambda s: (-s[1], -s[2], s[0]))
        low = sorted((s for s in stats if s[1] < LOW_PCT), key=lambda s: (s[1], s[0]))
        self.add("kv", [(f"Cītīgie (≥ {GOOD_PCT} %)", str(len(good))), (f"Zema cītība (< {LOW_PCT} %)", str(len(low)))])
        if good:
            self.add("p", "Cītīgākie: " + ", ".join(f"{n} ({p} %)" for n, p, _c in good[:15])
                     + (f" un vēl {len(good) - 15}" if len(good) > 15 else "") + ".")

    # ---- Uzstāšanās ---------------------------------------------------------------
    def shows(self):
        con = self.con
        detail = {}
        if has_table(con, "event_details"):
            detail = {r[0]: r[1:] for r in con.execute(
                "SELECT session_id, COALESCE(status,''), COALESCE(place,''), COALESCE(subkind,'') "
                "FROM event_details").fetchall()}
        rows = con.execute("SELECT id, session_date, kind, title FROM attendance_sessions WHERE kind IN (?, ?, ?) "
                           "AND session_date BETWEEN ? AND ? ORDER BY session_date, start_time, id",
                           (KIND_CONCERT, KIND_REVIEW, KIND_EVENT, self.s, self.e)).fetchall()
        rows = [r for r in rows if self.event_in_group(r[0]) and detail.get(r[0], ("",))[0] != ST_CANCELLED]
        held = [r for r in rows if r[1] <= self.u]
        later = [r for r in rows if r[1] > self.u]
        count = {k: sum(1 for r in held if r[2] == k) for k in (KIND_CONCERT, KIND_REVIEW, KIND_EVENT)}
        self.add("kv", [("Koncerti", str(count[KIND_CONCERT])), ("Skates", str(count[KIND_REVIEW])),
                        ("Kolektīva pasākumi", str(count[KIND_EVENT])),
                        ("Vēl ieplānoti šajā sezonā", str(len(later)))])
        if not held:
            self.add("p", "Šajā sezonā vēl nav notikušu koncertu, skašu vai pasākumu.")
            return
        dances = {}
        if has_table(con, "session_dances"):
            for sid, n in con.execute("SELECT session_id, COUNT(*) FROM session_dances GROUP BY session_id"):
                dances[sid] = n
        came = {}
        for sid, n in con.execute("SELECT session_id, SUM(CASE WHEN mark IN (?, ?) THEN 1 ELSE 0 END) "
                                  "FROM attendance GROUP BY session_id", CAME).fetchall():
            came[sid] = n or 0
        table = []
        for sid, d, kind, title in held:
            _st, place, sub = detail.get(sid, ("", "", ""))
            what = sub if kind == KIND_EVENT and sub else kind
            table.append([show_date(d), what, title or "", place, str(dances.get(sid, "")) or "",
                          str(came[sid]) if sid in came else ""])
        self.add("table", ["Datums", "Veids", "Nosaukums", "Vieta", "Dejas", "Piedalījās"], table, "llllrr")

    # ---- Repertuārs ---------------------------------------------------------------
    def dances(self):
        con = self.con
        if not has_table(con, "dances"):
            self.add("p", "Deju pūrā vēl nav deju.")
            return
        rows = con.execute("SELECT id, title, COALESCE(status,''), COALESCE(learned_date,''), "
                           "COALESCE(duration,''), COALESCE(dance_group,'') FROM dances").fetchall()
        if self.group is not None:
            rows = [r for r in rows if (r[5] or K.DEFAULT_DANCER_GROUP) == self.group]
        per = {s: 0 for s in DANCE_STATUSES}
        for r in rows:
            per[r[2] if r[2] in per else "Repertuārā"] += 1
        rep_seconds = sum(int(r[4]) for r in rows if r[2] == "Repertuārā" and str(r[4]).isdigit())
        self.add("kv", [("Repertuārā", f"{per['Repertuārā']} (kopā {minutes_text(rep_seconds)})"),
                        ("Procesā", str(per["Procesā"])), ("Atpūtā", str(per["Atpūtā"])),
                        ("Arhīvā", str(per["Arhīvā"]))])
        new = sorted((r for r in rows if self.s <= r[3] <= self.e), key=lambda r: r[3])
        self.add("p", ("Sezonā iestudētas: " + ", ".join(f"“{r[1]}” ({show_date(r[3])})" for r in new) + ".")
                 if new else "Sezonā iestudētu deju nav (vai Deju pūrā nav norādīts iestudēšanas datums).")
        if has_table(con, "session_dances"):
            ids = {r[0] for r in rows}
            title = {r[0]: r[1] for r in rows}
            counts = {}
            for sid, did, d, kind in con.execute(
                    "SELECT sd.session_id, sd.dance_id, s.session_date, s.kind FROM session_dances sd "
                    "JOIN attendance_sessions s ON s.id = sd.session_id WHERE s.session_date BETWEEN ? AND ?",
                    (self.s, self.u)).fetchall():
                if did not in ids or not self.event_in_group(sid):
                    continue
                c = counts.setdefault(did, [0, 0])
                if kind in (KIND_CONCERT, KIND_REVIEW):
                    c[0] += 1
                elif kind in REHEARSAL_KINDS:
                    c[1] += 1
            if counts:
                top = sorted(counts.items(), key=lambda x: (-x[1][0], -x[1][1], title[x[0]]))[:15]
                self.add("table", ["Deja", "Koncertos un skatēs", "Mēģinājumos"],
                         [[title[d], str(c[0]), str(c[1])] for d, c in top], "lrr")

    # ---- Tērpi ------------------------------------------------------------------------
    def costumes(self):
        con = self.con
        if not has_table(con, "costume_pieces"):
            self.add("p", "Tērpu pūrā vēl nav tērpu.")
            return
        rows = con.execute("SELECT COALESCE(category,''), COALESCE(condition_notes,''), COALESCE(status,'') "
                           "FROM costume_pieces").fetchall()
        issued = sum(1 for r in rows if r[2] == "Izsniegts")
        repair = sum(1 for r in rows if r[1] == "Jālabo")
        broken = sum(1 for r in rows if r[1] == "Nelietojams")
        self.add("kv", [("Tērpu daļas kopā", str(len(rows))), ("Izsniegtas (tagad)", str(issued)),
                        ("Jālabo", str(repair)), ("Nelietojamas", str(broken))])
        per = {}
        for cat, cond, _st in rows:
            c = per.setdefault(cat or "—", [0, 0])
            c[0] += 1
            c[1] += cond in ("Jālabo", "Nelietojams")
        self.add("table", ["Kategorija", "Daļas", "Jālabo / nelietojamas"],
                 [[k, str(v[0]), str(v[1])] for k, v in sorted(per.items())], "lrr")
        if has_table(con, "checkouts"):
            n = con.execute("SELECT COUNT(*) FROM checkouts WHERE checkout_date BETWEEN ? AND ?",
                            (self.s, self.e)).fetchone()[0]
            self.add("p", f"Sezonā izsniegtas {n} tērpu daļas (izsniegšanas reizes).")

    # ---- Finanses ---------------------------------------------------------------------
    def money(self):
        con = self.con
        if not has_table(con, "fin_entries"):
            self.add("p", "Zelta pūrā vēl nav ierakstu.")
            return

        def mine(g):
            return self.group is None or (g or K.DEFAULT_DANCER_GROUP) == self.group
        rows = [r for r in con.execute("SELECT entry_date, kind, COALESCE(category,''), amount_cents, fin_group "
                                       "FROM fin_entries").fetchall() if mine(r[4])]
        season = [r for r in rows if self.s <= (r[0] or "") <= self.e]
        income = sum(r[3] for r in season if r[1] == INCOME)
        expense = sum(r[3] for r in season if r[1] == EXPENSE)
        opening = 0
        if has_table(con, "fin_opening"):
            opening = sum(c for g, c in con.execute("SELECT fin_group, amount_cents FROM fin_opening").fetchall()
                          if mine(g))
        until = self.e
        balance = opening + sum(r[3] if r[1] == INCOME else -r[3] for r in rows if (r[0] or "") <= until)
        self.add("kv", [("Ienākumi sezonā", money(income)), ("Izdevumi sezonā", money(expense)),
                        ("Starpība", money(income - expense)),
                        ("Atlikums " + ("sezonas beigās" if self.end <= self.today else "šodien"), money(balance))])
        if not season:
            self.add("p", "Šajā sezonā vēl nav ienākumu un izdevumu ierakstu.")
            return
        for kind in (INCOME, EXPENSE):
            per = {}
            for r in season:
                if r[1] == kind:
                    per[r[2] or "—"] = per.get(r[2] or "—", 0) + r[3]
            if per:
                self.add("table", [kind + " pa kategorijām", "Summa"],
                         [[k, money(v)] for k, v in sorted(per.items(), key=lambda x: -x[1])], "lr")


# --------------------------------------------------------------------------
# HTML (print / PDF from the browser)
# --------------------------------------------------------------------------
CSS = """
@page { size: A4; margin: 16mm 14mm; }
body { font-family: "Segoe UI", Arial, sans-serif; color: #1F2A44; background: #FFFFFF; margin: 0; }
.page { max-width: 820px; margin: 0 auto; padding: 28px 24px 40px; }
.top { border-bottom: 3px solid #C9A227; padding-bottom: 12px; margin-bottom: 8px; }
.top h1 { font-family: Georgia, serif; font-size: 26px; margin: 0; }
.top .sub { color: #6B5D3F; font-size: 13px; margin-top: 4px; }
h2 { font-family: Georgia, serif; font-size: 18px; margin: 26px 0 8px; padding-bottom: 4px;
     border-bottom: 1px solid #E6DCC3; page-break-after: avoid; }
p { font-size: 13px; line-height: 1.5; margin: 8px 0; }
.kv { display: flex; flex-wrap: wrap; gap: 8px; margin: 8px 0; }
.kv div { border: 1px solid #E6DCC3; border-left: 4px solid #7A5C99; padding: 6px 12px; min-width: 130px; }
.kv span { display: block; font-size: 11px; color: #6B5D3F; }
.kv b { font-family: Georgia, serif; font-size: 17px; }
table { border-collapse: collapse; width: 100%; font-size: 12.5px; margin: 8px 0; page-break-inside: auto; }
th { background: #F3E8CC; text-align: left; padding: 6px 8px; }
td { padding: 5px 8px; border-bottom: 1px solid #F0E8D4; }
tr:nth-child(even) td { background: #FDFAF2; }
.r { text-align: right; }
.bar { display: flex; align-items: center; font-size: 12.5px; margin: 3px 0; }
.bar .l { width: 150px; }
.bar .t { flex: 1; height: 10px; background: #F1ECDF; margin: 0 10px; }
.bar .f { height: 10px; background: #1B6B3A; }
.bar .v { width: 170px; color: #6B5D3F; }
.foot { margin-top: 30px; font-size: 11px; color: #6B5D3F; border-top: 1px solid #E6DCC3; padding-top: 8px; }
@media print { .page { padding: 0; } }
"""


def to_html(blocks, title, subtitle, footer):
    e = html.escape
    out = [f"<!doctype html><html lang='lv'><head><meta charset='utf-8'><title>{e(title)}</title>"
           f"<style>{CSS}</style></head><body><div class='page'>",
           f"<div class='top'><h1>{e(title)}</h1><div class='sub'>{e(subtitle)}</div></div>"]
    for block in blocks:
        kind = block[0]
        if kind == "h":
            out.append(f"<h2>{e(block[1])}</h2>")
        elif kind == "p":
            out.append(f"<p>{e(block[1])}</p>")
        elif kind == "kv":
            out.append("<div class='kv'>" + "".join(f"<div><span>{e(k)}</span><b>{e(v)}</b></div>"
                                                     for k, v in block[1]) + "</div>")
        elif kind == "table":
            header, rows, align = block[1], block[2], block[3]
            cls = ["r" if a == "r" else "" for a in align]
            out.append("<table><tr>" + "".join(f"<th class='{c}'>{e(h)}</th>" for h, c in zip(header, cls)) + "</tr>")
            for row in rows:
                out.append("<tr>" + "".join(f"<td class='{c}'>{e(v)}</td>" for v, c in zip(row, cls)) + "</tr>")
            out.append("</table>")
        elif kind == "bars":
            for label, value, text in block[1]:
                colour = "#1B6B3A" if value >= 80 else ("#C4703A" if value >= LOW_PCT else "#9E1B32")
                out.append(f"<div class='bar'><span class='l'>{e(label)}</span><span class='t'><span class='f' "
                           f"style='display:block;width:{max(0, min(100, value))}%;background:{colour}'></span>"
                           f"</span><span class='v'>{e(text)}</span></div>")
    out.append(f"<div class='foot'>{e(footer)}</div></div></body></html>")
    return "\n".join(out)


# --------------------------------------------------------------------------
# Window
# --------------------------------------------------------------------------
class ReportWindow(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("Sezonas pārskats")
        self.geometry("980x780")
        self.minsize(820, 560)
        self.configure(bg=CREAM)
        self.transient(root)
        self.con = K.connect_db()
        self.acc = piekluve.current()
        self.group_name = K.read_setting("app.group_name", "Tautas deju kolektīvs")
        izskats.dialog_header(self, "Sezonas pārskats", f"{self.group_name} · sezona vienā dokumentā no visiem "
                              "moduļiem — to var saglabāt, izdrukāt vai saglabāt kā PDF", colour=GOLD, wrap=900)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", command=self.close).pack(side="right")
        ttk.Button(foot, text="⎙ Saglabāt un atvērt drukāšanai / PDF", style="Accent.TButton",
                   command=self.save_html).pack(side="right", padx=6)
        izskats.note(foot, "Fails atveras pārlūkā: tur Ctrl+P — izdrukāt vai “Saglabāt kā PDF”.", bg=WHITE).pack(
            side="left")

        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=18, pady=(12, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=12, pady=8)
        self.seasons = seasons_with_data(self.con)
        self.season_var = tk.StringVar(value=season_label(self.seasons[0]))
        self.group_var = tk.StringVar(value=ALL_GROUPS)
        tk.Label(bar, text="SEZONA", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 4))
        cb = ttk.Combobox(bar, textvariable=self.season_var, values=[season_label(y) for y in self.seasons],
                          state="readonly", width=11)
        cb.pack(side="left")
        tk.Label(bar, text="GRUPA", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="left", padx=(14, 4))
        gcb = ttk.Combobox(bar, textvariable=self.group_var, values=[ALL_GROUPS] + list(K.DANCER_GROUPS),
                           state="readonly", width=12)
        gcb.pack(side="left")
        for w in (cb, gcb):
            w.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        self.part_vars = {}
        parts = tk.Frame(bar_outer, bg=WHITE)
        parts.pack(fill="x", padx=12, pady=(0, 8))
        tk.Label(parts, text="DAĻAS", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))
        for key, title, module in SECTIONS:
            if not self.acc.can_open(module):
                continue   # the role does not see this module — nor this part of the report
            var = tk.BooleanVar(value=True)
            self.part_vars[key] = var
            tk.Checkbutton(parts, text=title, variable=var, command=self.refresh, bg=WHITE, fg=NAVY,
                           activebackground=WHITE, selectcolor=WHITE, highlightthickness=0, bd=0,
                           cursor="hand2").pack(side="left", padx=(0, 10))

        box = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightthickness=1)
        box.pack(fill="both", expand=True, padx=18, pady=12)
        self.text = tk.Text(box, wrap="word", bg=WHITE, fg=NAVY, relief="flat", bd=0, padx=22, pady=16,
                            font=("Segoe UI", 10), cursor="arrow", spacing1=2, spacing3=2)
        sb = ttk.Scrollbar(box, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        t = self.text
        t.tag_configure("title", font=("Georgia", 18, "bold"), foreground=NAVY, spacing3=2)
        t.tag_configure("sub", font=("Segoe UI", 9), foreground=MUTED, spacing3=10)
        t.tag_configure("h", font=("Georgia", 14, "bold"), foreground=NAVY, spacing1=16, spacing3=6)
        t.tag_configure("label", font=("Segoe UI", 9), foreground=MUTED)
        t.tag_configure("value", font=("Georgia", 12, "bold"), foreground=NAVY)
        t.tag_configure("th", font=("Segoe UI", 9, "bold"), foreground=MUTED)
        t.tag_configure("td", font=("Consolas", 10), foreground=NAVY)
        t.tag_configure("p", font=("Segoe UI", 10), foreground=NAVY, lmargin1=0, lmargin2=0)
        self.blocks = []
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda e: self.close())
        self.refresh()

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass
        self.destroy()

    def chosen(self):
        start = int(self.season_var.get().split("/")[0])
        group = None if self.group_var.get() == ALL_GROUPS else self.group_var.get()
        parts = [k for k, _t, _m in SECTIONS if k in self.part_vars and self.part_vars[k].get()]
        return start, group, parts

    def heading(self):
        start, group, _p = self.chosen()
        title = f"Sezonas pārskats {season_label(start)}"
        sub = f"{self.group_name}" + (f" · {group} grupa" if group else " · visas grupas") + \
              f" · 01.09.{start} – 31.08.{start + 1} · sagatavots {date.today().strftime('%d.%m.%Y')}"
        return title, sub

    def refresh(self):
        start, group, parts = self.chosen()
        try:
            self.blocks = Report(self.con, start, group, parts).build()
        except Exception:
            K.log_error(traceback.format_exc())
            self.blocks = [("p", "Pārskatu neizdevās sagatavot — detaļas kļūdu žurnālā.")]
        t = self.text
        t.configure(state="normal")
        t.delete("1.0", "end")
        title, sub = self.heading()
        t.insert("end", title + "\n", "title")
        t.insert("end", sub + "\n", "sub")
        if not parts:
            t.insert("end", "Atzīmējiet vismaz vienu daļu.", "p")
        for block in self.blocks:
            kind = block[0]
            if kind == "h":
                t.insert("end", block[1] + "\n", "h")
            elif kind == "p":
                t.insert("end", block[1] + "\n", "p")
            elif kind == "kv":
                for k, v in block[1]:
                    t.insert("end", f"{k}: ", "label")
                    t.insert("end", f"{v}     ", "value")
                t.insert("end", "\n", "p")
            elif kind == "table":
                header, rows, align = block[1], block[2], block[3]
                widths = [max(len(str(x)) for x in [h] + [r[i] for r in rows]) for i, h in enumerate(header)]
                widths = [min(w, 34) for w in widths]

                def cell(v, i):
                    v = str(v)
                    v = v if len(v) <= widths[i] else v[:widths[i] - 1] + "…"
                    return v.rjust(widths[i]) if align[i] == "r" else v.ljust(widths[i])
                t.insert("end", "  ".join(cell(h, i) for i, h in enumerate(header)) + "\n", "th")
                for r in rows:
                    t.insert("end", "  ".join(cell(v, i) for i, v in enumerate(r)) + "\n", "td")
            elif kind == "bars":
                for label, value, text in block[1]:
                    filled = round(value / 5)
                    t.insert("end", f"{label:<16} {'█' * filled}{'░' * (20 - filled)}  {text}\n", "td")
        t.configure(state="disabled")

    def save_html(self):
        start, group, parts = self.chosen()
        if not parts:
            messagebox.showinfo("Sezonas pārskats", "Atzīmējiet vismaz vienu daļu.", parent=self)
            return
        name = f"Sezonas pārskats {start}-{start + 1}" + (f" {group}" if group else "") + ".html"
        path = filedialog.asksaveasfilename(parent=self, title="Saglabāt sezonas pārskatu", initialfile=name,
                                            defaultextension=".html", filetypes=[("Tīmekļa lapa (HTML)", "*.html")])
        if not path:
            return
        title, sub = self.heading()
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(to_html(self.blocks, title, sub, f"Pūrlāde · {K.COPYRIGHT}"))
        except OSError as exc:
            messagebox.showerror("Sezonas pārskats", f"Neizdevās saglabāt failu:\n{exc}", parent=self)
            return
        try:
            if os.name == "nt":
                os.startfile(path)   # noqa: the default browser
            else:
                webbrowser.open("file://" + os.path.abspath(path))
        except Exception:
            messagebox.showinfo("Sezonas pārskats", f"Pārskats saglabāts:\n{path}", parent=self)


def show(root):
    return ReportWindow(root)
