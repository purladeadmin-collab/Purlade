#!/usr/bin/env python3
"""
Pūrlāde — modulis "Tērpu pūrs"
Tautas deju kolektīva tērpu inventāra pārvaldība
(Folk dance group costume inventory management)

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/terpu_purs.py

Data is stored in purlade.db in the Pūrlāde folder (shared by all modules);
attached photos are copied into the costume_photos/ folder there.
"""

import csv
import os
import re
import shutil
import sqlite3
import subprocess
import time
import traceback
import sys
import unicodedata
import uuid
import zipfile
import xml.etree.ElementTree as ET
import tkinter as tk
from datetime import date, datetime
from tkinter import ttk, messagebox, filedialog, simpledialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

# --------------------------------------------------------------------------
# Paths and design
# --------------------------------------------------------------------------
try:  # started from Pūrlāde
    from moduli.kopeja import (group_logo, DATA_DIR as APP_DIR, DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error,
                               copyright_footer, module_logo,
                               ensure_dancer_schema, active_dancer_sql, dancer_role_sql, dancer_size_text, GENDER_MALE, GENDER_FEMALE, GENDERS,
                               POWER_ICON_B64, HOME_ICON_B64, _norm, read_table, normalize_gender, date_picker_button,
                               console_available, console_visible, set_console_visible, console_is_own,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN)
except ImportError:  # started directly from the moduli folder
    from kopeja import (group_logo, DATA_DIR as APP_DIR, DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error,
                        copyright_footer, module_logo,
                        ensure_dancer_schema, active_dancer_sql, dancer_role_sql, dancer_size_text, GENDER_MALE, GENDER_FEMALE, GENDERS,
                        POWER_ICON_B64, HOME_ICON_B64, _norm, read_table, normalize_gender, date_picker_button,
                        console_available, console_visible, set_console_visible, console_is_own,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN)

try:  # started from Pūrlāde
    from moduli.kopeja import dance_lineup, EVENT_KIND_GROUP, SUBKIND_PUBLICITY, invited_ids, event_costume_types
except ImportError:  # started directly from the moduli folder
    from kopeja import dance_lineup, EVENT_KIND_GROUP, SUBKIND_PUBLICITY, invited_ids, event_costume_types

try:  # soda naudas (tērpu kārtības ruļļa pārkāpumi, nenodotas detaļas) — kopīgā daļa
    from moduli import kopeja as K
except ImportError:
    import kopeja as K

PHOTO_DIR = os.path.join(APP_DIR, "costume_photos")

AVAILABLE = "Noliktavā"
CHECKED_OUT = "Izsniegts"
ALL = "Visi"

# Notikumu pūrs values used by the issue window (rehearsals are not events here)
KIND_REHEARSAL = "Mēģinājums"
KIND_EXTRA_REHEARSAL = "Papildmēģinājums"
ANS_NOT_COMING = "Nebūs"

# Issue window: which dancers are listed
GENDER_FILTER_ALL = "Visi dejotāji"
GENDER_FILTERS = {GENDER_FILTER_ALL: None, "Meitenes": GENDER_FEMALE, "Puiši": GENDER_MALE}

# Costume categories. "Nekategorizēts" can be given to dancers of either gender.
CAT_BOYS = "Puišu tērpi"
CAT_GIRLS = "Meiteņu tērpi"
CAT_NONE = "Nekategorizēts"
CATEGORIES = [CAT_BOYS, CAT_GIRLS, CAT_NONE]

# Costume condition: only these three values can be stored.
CONDITIONS = ["Lietojams", "Jālabo", "Nelietojams"]
DEFAULT_CONDITION = CONDITIONS[0]

GENDER_CATEGORY = {GENDER_FEMALE: CAT_GIRLS, GENDER_MALE: CAT_BOYS}

# The common look (Pūrlāde v0.8 — moduli/izskats.py)
LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED, \
    izskats.SELECTED
OK_BG, OK_FG, WARN_BG, WARN_FG, BAD_BG, BAD_FG = (izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG,
                                                  izskats.BAD_BG, izskats.BAD_FG)
ZEBRA, DISABLED_FG = izskats.ZEBRA, izskats.DISABLED_FG
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL
MODULE_COLOUR = RED
COND_COLOURS = {"Lietojams": (OK_BG, OK_FG), "Jālabo": (WARN_BG, WARN_FG), "Nelietojams": (BAD_BG, BAD_FG)}
OVERDUE_DAYS = 30   # costumes kept longer than this are shown in red

# --------------------------------------------------------------------------
# Labels (Latvian). Texts and column names can be renamed in Administrēšana.
# --------------------------------------------------------------------------
DEFAULT_LABELS = {
    "app.group_name": "Tautas deju kolektīvs",
    "pieces.inv_no": "Inventāra numurs",
    "pieces.name": "Nosaukums",
    "pieces.category": "Kategorija",
    "pieces.type": "Veids",
    "pieces.set_name": "Komplekts",
    "pieces.photos": "Foto",
    "pieces.condition_notes": "Stāvoklis",
    "pieces.status": "Statuss",
    "checkouts.piece": "Tērpa detaļa",
    "checkouts.dancer": "Dejotājs",
    "checkouts.checkout_date": "Izsniegšanas datums",
    "checkouts.return_date": "Atgriešanas datums",
    "checkouts.notes": "Piezīmes",
    "checkouts.state": "Statuss",
}
TABLE_TITLES = {
    "app": "Lietotne (galvene)",
    "pieces": "Tērpa gabali",
    "checkouts": "Izsniegumi",
}


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
# "Status formula": a piece is checked out when it has a checkout row with
# no return date; otherwise it is available.
STATUS_EXPR = (
    "CASE WHEN EXISTS (SELECT 1 FROM checkouts c WHERE c.piece_id = {p} "
    "AND (c.return_date IS NULL OR TRIM(c.return_date) = '')) "
    "THEN '" + CHECKED_OUT + "' ELSE '" + AVAILABLE + "' END"
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS costume_pieces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inv_no TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT DEFAULT '',
    type TEXT DEFAULT '',
    set_name TEXT DEFAULT '',
    condition_notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'Noliktavā',
    UNIQUE (inv_no, category)
);
CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    piece_id INTEGER NOT NULL REFERENCES costume_pieces(id) ON DELETE CASCADE,
    filename TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS dancers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    gender TEXT DEFAULT '',
    contact TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS checkouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    piece_id INTEGER NOT NULL REFERENCES costume_pieces(id) ON DELETE CASCADE,
    dancer_id INTEGER NOT NULL REFERENCES dancers(id) ON DELETE CASCADE,
    checkout_date TEXT NOT NULL,
    return_date TEXT DEFAULT '',
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS piece_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    category TEXT NOT NULL DEFAULT 'Nekategorizēts'
);
CREATE TABLE IF NOT EXISTS piece_sets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE
);
"""

# Costume types and sets can only be chosen from lists kept in Administrēšana.
LIST_TABLES = {"type": "piece_types", "set_name": "piece_sets"}

CAT_LIST_SQL = ", ".join("'" + c + "'" for c in CATEGORIES)
COND_LIST_SQL = ", ".join("'" + c + "'" for c in CONDITIONS)

# Automation: whenever a checkout is created, changed (e.g. a return date is
# filled in) or deleted, the linked piece's stored status is refreshed.
# The category triggers make it impossible to store any other category.
TRIGGERS = [
    ("trg_checkout_insert",
     "AFTER INSERT ON checkouts",
     "UPDATE costume_pieces SET status = " + STATUS_EXPR.format(p="NEW.piece_id")
     + " WHERE id = NEW.piece_id;"),
    ("trg_checkout_update",
     "AFTER UPDATE ON checkouts",
     "UPDATE costume_pieces SET status = " + STATUS_EXPR.format(p="NEW.piece_id")
     + " WHERE id = NEW.piece_id;"
     "UPDATE costume_pieces SET status = " + STATUS_EXPR.format(p="OLD.piece_id")
     + " WHERE id = OLD.piece_id;"),
    ("trg_checkout_delete",
     "AFTER DELETE ON checkouts",
     "UPDATE costume_pieces SET status = " + STATUS_EXPR.format(p="OLD.piece_id")
     + " WHERE id = OLD.piece_id;"),
    ("trg_piece_category_insert",
     "BEFORE INSERT ON costume_pieces WHEN NEW.category NOT IN (" + CAT_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīga kategorija');"),
    ("trg_piece_category_update",
     "BEFORE UPDATE OF category ON costume_pieces WHEN NEW.category NOT IN (" + CAT_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīga kategorija');"),
    ("trg_type_category_insert",
     "BEFORE INSERT ON piece_types WHEN NEW.category NOT IN (" + CAT_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīga kategorija');"),
    ("trg_type_category_update",
     "BEFORE UPDATE OF category ON piece_types WHEN NEW.category NOT IN (" + CAT_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīga kategorija');"),
    ("trg_piece_condition_insert",
     "BEFORE INSERT ON costume_pieces WHEN NEW.condition_notes NOT IN (" + COND_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīgs stāvoklis');"),
    ("trg_piece_condition_update",
     "BEFORE UPDATE OF condition_notes ON costume_pieces WHEN NEW.condition_notes NOT IN (" + COND_LIST_SQL + ")",
     "SELECT RAISE(ABORT, 'Nederīgs stāvoklis');"),
]


# The same inventory number may be used once in each category (e.g. "PM1" for a boys' and a girls' piece).
PIECE_COLUMNS = "id, inv_no, name, category, type, set_name, condition_notes, status"


def allow_inv_no_per_category(con):
    """Older databases kept the inventory number unique over all pieces. The table is rebuilt so that
    it only has to be unique within a category. Photos and checkouts keep pointing to the same ids."""
    single_inv_no = False
    for _seq, index, unique, *_rest in con.execute("PRAGMA index_list(costume_pieces)").fetchall():
        cols = [r[2] for r in con.execute(f"PRAGMA index_info('{index}')").fetchall()]
        if unique and cols == ["inv_no"]:
            single_inv_no = True
    if not single_inv_no:
        return
    con.commit()
    con.execute("PRAGMA foreign_keys = OFF")  # otherwise dropping the old table would delete photos/checkouts
    try:
        for name, _when, _body in TRIGGERS:  # they are created again right afterwards
            con.execute(f"DROP TRIGGER IF EXISTS {name}")
        con.execute("BEGIN")
        create = SCHEMA.split("CREATE TABLE IF NOT EXISTS costume_pieces", 1)[1].split(";", 1)[0]
        con.execute("CREATE TABLE costume_pieces_new" + create)
        con.execute(f"INSERT INTO costume_pieces_new ({PIECE_COLUMNS}) SELECT {PIECE_COLUMNS} FROM costume_pieces")
        con.execute("DROP TABLE costume_pieces")
        con.execute("ALTER TABLE costume_pieces_new RENAME TO costume_pieces")
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.execute("PRAGMA foreign_keys = ON")


class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.executescript(SCHEMA)
        allow_inv_no_per_category(self.con)
        type_cols = [r[1] for r in self.con.execute("PRAGMA table_info(piece_types)")]
        add_type_category = "category" not in type_cols  # database from an older version
        if add_type_category:
            self.con.execute("ALTER TABLE piece_types ADD COLUMN category TEXT NOT NULL DEFAULT '" + CAT_NONE + "'")
        # values already used by existing pieces (older database) become list entries
        for column, table in LIST_TABLES.items():
            self.con.execute(
                f"INSERT OR IGNORE INTO {table} (name) SELECT DISTINCT TRIM({column}) "
                f"FROM costume_pieces WHERE TRIM(COALESCE({column},'')) <> ''")
        if add_type_category:  # a type whose pieces all share one category takes that category
            self.con.execute(
                "UPDATE piece_types SET category = COALESCE((SELECT CASE WHEN COUNT(DISTINCT p.category) = 1 "
                "THEN MIN(p.category) ELSE '" + CAT_NONE + "' END FROM costume_pieces p "
                "WHERE p.type = piece_types.name COLLATE NOCASE AND p.category IN (" + CAT_LIST_SQL + ")), '"
                + CAT_NONE + "')")
        ensure_dancer_schema(self.con)  # dancers are kept by the Kopas pūrs module
        K.ensure_fines_schema(self.con)  # v0.6: costume_rules, costume_fines (soda naudas)
        for name, when, body in TRIGGERS:
            self.con.execute(f"DROP TRIGGER IF EXISTS {name}")
            self.con.execute(f"CREATE TRIGGER {name} {when} BEGIN {body} END")
        # only pieces whose stored status is wrong are written (in the shared online database every
        # start of Tērpu pūrs would otherwise rewrite all pieces)
        self.con.execute("UPDATE costume_pieces SET status = " + STATUS_EXPR.format(p="costume_pieces.id")
                         + " WHERE status <> " + STATUS_EXPR.format(p="costume_pieces.id"))
        self.con.commit()

    def has_table(self, name):
        return bool(self.con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def distinct(self, column):
        rows = self.q(
            f"SELECT DISTINCT {column} FROM costume_pieces "
            f"WHERE {column} IS NOT NULL AND TRIM({column}) <> '' ORDER BY {column}"
        )
        return [r[0] for r in rows]

    # -- managed lists: costume types and sets ---------------------------
    def list_items(self, column):
        table = LIST_TABLES[column]
        return self.q(
            f"SELECT t.id, t.name, (SELECT COUNT(*) FROM costume_pieces p "
            f"WHERE p.{column} = t.name COLLATE NOCASE) FROM {table} t ORDER BY t.name COLLATE NOCASE")

    def list_names(self, column):
        return [r[1] for r in self.list_items(column)]

    def type_names(self):
        return self.list_names("type")

    def set_names(self):
        return self.list_names("set_name")

    def add_list_item(self, column, name, category=None):
        if column == "type":
            self.x("INSERT INTO piece_types (name, category) VALUES (?, ?)", (name, category or CAT_NONE))
        else:
            self.x(f"INSERT INTO {LIST_TABLES[column]} (name) VALUES (?)", (name,))

    def type_items(self):
        """(id, name, category, number of pieces using it) for every costume type."""
        return self.q(
            "SELECT t.id, t.name, t.category, (SELECT COUNT(*) FROM costume_pieces p "
            "WHERE p.type = t.name COLLATE NOCASE) FROM piece_types t ORDER BY t.name COLLATE NOCASE")

    def type_category_map(self):
        return {name.lower(): cat for name, cat in self.q("SELECT name, category FROM piece_types")}

    def set_type_category(self, item_id, category):
        self.x("UPDATE piece_types SET category = ? WHERE id = ?", (category, item_id))

    def type_names_for(self, wanted):
        """Types shown to a dancer whose category is `wanted`: that category plus 'Nekategorizēts'."""
        return [r[0] for r in self.q(
            "SELECT name FROM piece_types WHERE category IN (?, ?) ORDER BY name COLLATE NOCASE",
            (wanted, CAT_NONE))]

    def rename_list_item(self, column, item_id, new):
        table = LIST_TABLES[column]
        old = self.q(f"SELECT name FROM {table} WHERE id=?", (item_id,))[0][0]
        try:
            self.con.execute(f"UPDATE {table} SET name=? WHERE id=?", (new, item_id))
            self.con.execute(f"UPDATE costume_pieces SET {column}=? WHERE {column}=? COLLATE NOCASE",
                             (new, old))
            if column == "type":  # Deju pūrs links dances to costume types by name
                try:
                    self.con.execute("UPDATE dance_costumes SET type_name=? WHERE type_name=? COLLATE NOCASE",
                                     (new, old))
                except sqlite3.OperationalError:  # Deju pūrs has not been used yet
                    pass
            self.con.commit()
        except sqlite3.IntegrityError:
            self.con.rollback()
            raise

    def delete_list_item(self, column, item_id):
        self.x(f"DELETE FROM {LIST_TABLES[column]} WHERE id=?", (item_id,))


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
# Dates are shown and typed as DD.MM.GGGG (as everywhere in Pūrlāde); the database keeps
# GGGG-MM-DD so that sorting and older data keep working.
def to_iso(text):
    """Typed date (DD.MM.GGGG, also GGGG-MM-DD) -> GGGG-MM-DD, or None if it is not a valid date."""
    for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text.strip(), fmt).date().isoformat()
        except ValueError:
            pass
    return None


def show_date(iso):
    """'2026-10-21' -> '21.10.2026' (the date format used everywhere in Pūrlāde)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", (iso or "").strip())
    return f"{m.group(3)}.{m.group(2)}.{m.group(1)}" if m else (iso or "")


def today_text():
    return date.today().strftime("%d.%m.%Y")


def open_external(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as exc:  # pragma: no cover
        messagebox.showerror("Kļūda", f"Neizdevās atvērt failu:\n{exc}")


def dancer_labels(rows):
    """rows = (id, name, gender) -> {label: id}; duplicate names get a suffix."""
    out = {}
    for did, name, _gender in rows:
        label = name
        if label in out:
            label = f"{name} (#{did})"
        out[label] = did
    return out


def in_clause(ids):
    return "(" + ",".join("?" * len(ids)) + ")"


def make_tree_with_scroll(parent, tree):
    sb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=sb.set)
    tree.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")


# --------------------------------------------------------------------------
# Import from Excel (.xlsx) / CSV  -- standard library only
# --------------------------------------------------------------------------
def _aliases(extra, *label_keys, L=None):
    out = {_norm(x) for x in extra}
    for key in label_keys:
        out.add(_norm(DEFAULT_LABELS[key]))
        if L is not None:
            out.add(_norm(L(key)))
    return out


def _find_columns(rows, aliases):
    for i, row in enumerate(rows):
        if any(c for c in row):
            mapping = {}
            for col, cell in enumerate(row):
                n = _norm(cell)
                for field, names in aliases.items():
                    if field not in mapping and n in names:
                        mapping[field] = col
            return i, mapping, [c for c in row if c]
    return None, {}, []


def normalize_condition(text):
    c = _norm(text)
    if not c:
        return DEFAULT_CONDITION
    if c.startswith(("nelietoj", "boj")):
        return "Nelietojams"
    if c.startswith(("jalab", "labot", "remont", "repair")):
        return "Jālabo"
    if c.startswith(("lietoj", "labs", "good", "ok")):
        return "Lietojams"
    return None


def normalize_category(text):
    c = _norm(text)
    if not c or c.startswith(("nekat", "uncat", "bez ")):
        return CAT_NONE
    if c.startswith(("meit", "girl", "siev", "fem", "sieviesu")):
        return CAT_GIRLS
    if c.startswith(("pui", "boy", "zen", "viri", "mal", "vir")):
        return CAT_BOYS
    return None


def _cell(row, mapping, field):
    col = mapping.get(field)
    return row[col].strip() if col is not None and col < len(row) else ""


def import_pieces(db, rows, L=None):
    aliases = {
        "inv_no": _aliases(["inventara nr", "inventara numurs", "inv nr", "inv no", "inventory number",
                            "numurs", "nr"], "pieces.inv_no", L=L),
        "name": _aliases(["nosaukums", "name", "tērps", "terps"], "pieces.name", L=L),
        "category": _aliases(["kategorija", "category"], "pieces.category", L=L),
        "type": _aliases(["veids", "tips", "type"], "pieces.type", L=L),
        "set_name": _aliases(["komplekts", "set", "kompl"], "pieces.set_name", L=L),
        "condition_notes": _aliases(["stavokla piezimes", "stavoklis", "piezimes", "condition notes",
                                     "notes"], "pieces.condition_notes", L=L),
    }
    hi, mp, found = _find_columns(rows, aliases)
    needed = {"inv_no": "pieces.inv_no", "category": "pieces.category"}  # "Nosaukums" is optional
    missing = [DEFAULT_LABELS[k] for f, k in needed.items() if f not in mp]
    if hi is None or missing:
        return {"error": "Failā trūkst obligātās kolonnas: " + ", ".join(missing or ["—"]) + ".\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}
    existing = {(inv, cat) for inv, cat in db.q("SELECT inv_no, category FROM costume_pieces")}
    added, skipped, new_items = 0, [], []
    lookups = {t: {_norm(n): n for (n,) in db.q(f"SELECT name FROM {t}")} for t in LIST_TABLES.values()}

    def canon(table, value, category=None):
        """Use the spelling already in the managed list; register unknown values."""
        if not value:
            return ""
        known = lookups[table]
        key = _norm(value)
        if key not in known:
            if table == "piece_types":  # a new type takes the category of the piece it came with
                db.con.execute("INSERT OR IGNORE INTO piece_types (name, category) VALUES (?, ?)",
                               (value, category or CAT_NONE))
            else:
                db.con.execute(f"INSERT OR IGNORE INTO {table} (name) VALUES (?)", (value,))
            known[key] = value
            new_items.append(value)
        return known[key]

    for i in range(hi + 1, len(rows)):
        row = rows[i]
        if not any(row):
            continue
        inv = _cell(row, mp, "inv_no")
        if not inv:
            skipped.append((i + 1, "nav inventāra numura"))
            continue
        # the name column is optional: fall back to the type, then to the inventory number
        name = _cell(row, mp, "name") or _cell(row, mp, "type") or inv
        raw_c = _cell(row, mp, "category")
        category = normalize_category(raw_c)
        if category is None:
            skipped.append((i + 1, f"kategorija “{raw_c}” nav atļauta (tikai {' / '.join(CATEGORIES)})"))
            continue
        raw_s = _cell(row, mp, "condition_notes")
        condition = normalize_condition(raw_s)
        if condition is None:
            skipped.append((i + 1, f"stāvoklis “{raw_s}” nav atļauts (tikai {', '.join(CONDITIONS)})"))
            continue
        if (inv, category) in existing:
            skipped.append((i + 1, f"inventāra numurs {inv} kategorijā “{category}” jau eksistē"))
            continue
        try:
            db.con.execute(
                "INSERT INTO costume_pieces (inv_no, name, category, type, set_name, condition_notes) "
                "VALUES (?,?,?,?,?,?)",
                (inv, name, category, canon("piece_types", _cell(row, mp, "type"), category),
                 canon("piece_sets", _cell(row, mp, "set_name")), condition))
        except sqlite3.IntegrityError as exc:
            skipped.append((i + 1, str(exc)))
            continue
        existing.add((inv, category))
        added += 1
    db.con.commit()
    return {"error": None, "added": added, "skipped": skipped, "new_lists": new_items}


def parse_name_list(rows, column, existing, L):
    """Rows read from an Excel/CSV file -> names for the managed list of costume types or sets.
    existing = names already in the list. Types may also carry a category column."""
    is_type = column == "type"
    key = "pieces.type" if is_type else "pieces.set_name"
    names = ["veids", "veidi", "tērpa veids", "tērpu veids", "type"] if is_type \
        else ["komplekts", "komplekti", "tērpu komplekts", "set"]
    aliases = {"name": _aliases(names + ["nosaukums", "name"], key, L=L),
               "category": _aliases(["kategorija", "category"], "pieces.category", L=L)}
    hi, mp, found = _find_columns(rows, aliases)
    if hi is None or "name" not in mp:
        return {"error": "Faila pirmajā rindā jābūt kolonnai “" + L(key) + "”.\n"
                         "Atrastās kolonnas: " + (", ".join(found) or "nav")}
    seen = {n.lower() for n in existing}
    entries, skipped = [], []
    for i in range(hi + 1, len(rows)):
        row = rows[i]
        name = _cell(row, mp, "name")
        if not name:
            continue
        name = " ".join(name.split())
        category = None
        if is_type:
            raw = _cell(row, mp, "category") if "category" in mp else ""
            category = normalize_category(raw)
            if category is None:
                skipped.append((i + 1, f"“{name}”: kategorija “{raw}” nav atļauta (tikai {' / '.join(CATEGORIES)})"))
                continue
        if name.lower() in seen:
            skipped.append((i + 1, f"“{name}” jau eksistē"))
            continue
        seen.add(name.lower())
        entries.append((name, category))
    return {"error": None, "entries": entries, "skipped": skipped}


def catalog_editable():
    """Lietotāju lomas: the costume catalogue (pieces, types, sets) — only for those who may change everything
    (Tērpu pārzinis, leaders …); presidents only issue / take back the costumes of their own group."""
    return piekluve.current().edits_all("terpu_purs")


def may_issue(db, dancer_id):
    """May costumes be issued to / taken back from this dancer?"""
    acc = piekluve.current()
    if acc.edits_all("terpu_purs"):
        return True
    if acc.view_only("terpu_purs") or dancer_id is None:
        return False
    row = db.q("SELECT dancer_group FROM dancers WHERE id=?", (dancer_id,))
    return acc.can_edit("terpu_purs", group=row[0][0] if row else "")


def rights_note(parent, text, bg=CREAM):
    tk.Label(parent, text="🔒 " + text, bg=bg, fg=RED, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 12))


def run_import(app, parent, kind):
    """Ask for a file, import it and show a summary. kind = 'pieces' (dancers are imported in Kopas pūrs)."""
    if not catalog_editable():
        return piekluve.deny(parent, "Tērpus importēt var tērpu pārzinis vai kolektīva vadība.")
    L = app.L
    if True:
        cols = [L("pieces.inv_no"), L("pieces.category") + f" ({' / '.join(CATEGORIES)})",
                L("pieces.type"), L("pieces.set_name"),
                L("pieces.condition_notes") + f" ({' / '.join(CONDITIONS)})"]
        info = ("Excel faila pirmajā rindā jābūt kolonnu nosaukumiem:\n\n  • " + "\n  • ".join(cols) +
                f"\n\nObligātas ir pirmās divas kolonnas (kolonna “{L('pieces.name')}” nav vajadzīga; ja tā ir, tiek izmantota, "
                f"citādi nosaukumā tiek ielikts veids vai inventāra numurs). Atļautas tikai kategorijas “{CAT_BOYS}”, “{CAT_GIRLS}” un “{CAT_NONE}”; "
                "rindas ar citu kategoriju, nederīgu stāvokli vai inventāra numuru, kas tajā pašā kategorijā jau ir, tiks izlaistas "
                "(vienu un to pašu numuru drīkst izmantot dažādās kategorijās). "
                "Ja stāvoklis nav norādīts, tiek ielikts “Lietojams”.")
        fn = import_pieces
    if not messagebox.askokcancel("Importēt no Excel", info, parent=parent):
        return
    path = filedialog.askopenfilename(
        parent=parent, title="Izvēlieties Excel failu",
        filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
    if not path:
        return
    try:
        rows = read_table(path)
        result = fn(app.db, rows, L)
    except Exception as exc:
        messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=parent)
        return
    if result["error"]:
        messagebox.showerror("Importa kļūda", result["error"], parent=parent)
        return
    app.refresh_all()
    text = f"Pievienoti ieraksti: {result['added']}\nIzlaistas rindas: {len(result['skipped'])}"
    if result.get("nogender"):
        text += f"\nDejotāji bez norādīta dzimuma: {result['nogender']}"
    if result.get("new_lists"):
        text += ("\n\nNo faila sarakstam “veidi/komplekti” pievienoti jauni nosaukumi: "
                 + ", ".join(result["new_lists"][:12]))
    if result["skipped"]:
        text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
        if len(result["skipped"]) > 12:
            text += f"\n… un vēl {len(result['skipped']) - 12}"
    (messagebox.showwarning if result["skipped"] else messagebox.showinfo)("Imports pabeigts", text, parent=parent)


# --------------------------------------------------------------------------
# Small parts of the new look (Pūrlāde v0.8.1 — Tērpu pūrs v0.5.5)
# --------------------------------------------------------------------------
WEEKDAYS = ["Pirmdiena", "Otrdiena", "Trešdiena", "Ceturtdiena", "Piektdiena", "Sestdiena", "Svētdiena"]


def pieces_word(n):
    """“1 tērpu”, “2 tērpus”, “21 tērpu” (accusative)."""
    return "tērpu" if n % 10 == 1 and n % 100 != 11 else "tērpus"


def days_since(iso):
    try:
        return (date.today() - date.fromisoformat((iso or "")[:10])).days
    except ValueError:
        return None


def relative_day(iso):
    """'šodien', 'rīt', 'pēc 4 dienām', 'pirms 2 dienām' …"""
    try:
        delta = (date.fromisoformat((iso or "")[:10]) - date.today()).days
    except ValueError:
        return ""
    if delta == 0:
        return "šodien"
    if delta == 1:
        return "rīt"
    if delta == -1:
        return "vakar"
    return f"pēc {delta} dienām" if delta > 0 else f"pirms {-delta} dienām"


def weekday_text(iso):
    try:
        return WEEKDAYS[date.fromisoformat((iso or "")[:10]).weekday()]
    except ValueError:
        return ""


zebra = izskats.zebra   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


row_tags = izskats.row_tags   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


def link(parent, text, command, bg=WHITE):
    """Underlined text that works like a button."""
    lbl = tk.Label(parent, text=text, bg=bg, fg=NAVY, font=("Segoe UI", 9, "underline"), cursor="hand2")
    lbl.bind("<Button-1>", lambda e: command())
    return lbl


def small_label(parent, text, bg=WHITE):
    return tk.Label(parent, text=text, bg=bg, fg=MUTED, font=("Segoe UI", 8, "bold"))


def condition_chip(parent, condition):
    bg, fg = COND_COLOURS.get(condition, (SELECTED, NAVY))
    return izskats.chip(parent, condition or "—", bg, fg)


def bottom_bar(view):
    """White action bar at the bottom of a view (always visible); returns the inner frame."""
    bar = tk.Frame(view, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
    pin_bottom(bar, padx=20, pady=(10, 14))
    inner = tk.Frame(bar, bg=WHITE)
    inner.pack(fill="x", padx=14, pady=8)
    return inner


class UnsavedDialog(tk.Toplevel):
    """"Ir nesaglabātas izmaiņas …" -> result: "discard", "stay" or "save"."""

    def __init__(self, parent):
        super().__init__(parent)
        self.result = "stay"
        self.title("Nesaglabātas izmaiņas")
        self.configure(bg=CREAM)
        self.transient(parent)
        self.resizable(False, False)
        izskats.dialog_header(self, "Nesaglabātas izmaiņas", colour=MODULE_COLOUR)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Saglabāt un iziet", style="Accent.TButton",
                   command=lambda: self.finish("save")).pack(side="right")
        ttk.Button(foot, text="Palikt", command=lambda: self.finish("stay")).pack(side="right", padx=6)
        ttk.Button(foot, text="Atmest izmaiņas", style="Danger.TButton",
                   command=lambda: self.finish("discard")).pack(side="left")
        tk.Label(self, text="Šajā skatā ir nesaglabātas izmaiņas.\nVai saglabāt tās vai atmest?", bg=CREAM,
                 fg=NAVY, font=("Segoe UI", 11), justify="left").pack(padx=24, pady=18, anchor="w")
        self.protocol("WM_DELETE_WINDOW", lambda: self.finish("stay"))
        self.bind("<Escape>", lambda e: self.finish("stay"))
        self.update_idletasks()
        try:  # centre over the main window
            x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
            y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 3
            self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        except Exception:
            pass
        self.grab_set()
        self.focus_set()

    def finish(self, result):
        self.result = result
        self.destroy()


def ask_unsaved(parent):
    dialog = UnsavedDialog(parent)
    parent.wait_window(dialog)
    return dialog.result


def pin_bottom(bar, **pad):
    """Button bar that always stays visible at the bottom, however small the window gets
    (it is packed before the expanding content, which gives way instead)."""
    others = [w for w in bar.master.pack_slaves() if w is not bar]
    if others:
        bar.pack(side="bottom", fill="x", before=others[0], **pad)
    else:
        bar.pack(side="bottom", fill="x", **pad)


def fit_min_size(win):
    """Do not allow the window to be made smaller than its content needs (so no button is cut off)."""
    try:
        win.update_idletasks()
        w = min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60)
        h = min(win.winfo_reqheight(), win.winfo_screenheight() - 100)
        win.minsize(w, h)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Forms (modal dialogs)
# --------------------------------------------------------------------------
class PieceForm(tk.Toplevel):
    """Tērpa anketa (add or edit a costume piece): data, photos and — for a saved piece — its history."""

    def __init__(self, app, piece_id=None):
        super().__init__(app.root)
        self.app, self.piece_id = app, piece_id
        self.configure(bg=CREAM)
        self.title("Tērpa anketa" if piece_id is None else "Rediģēt tērpu")
        self.after(150, lambda: fit_min_size(self))
        self.transient(app.root)
        self.grab_set()
        L = app.L
        db = app.db

        row = None
        if piece_id is not None:
            row = db.q("SELECT inv_no, name, category, type, set_name, condition_notes "
                       "FROM costume_pieces WHERE id=?", (piece_id,))[0]
        holder = self.holder_text(piece_id)
        head = izskats.dialog_header(
            self, "Jauns tērpa gabals" if row is None else f"{row[0]} — {row[1]}",
            "Aizpildiet tērpa datus; ar * atzīmētie lauki ir obligāti." if row is None else holder,
            colour=MODULE_COLOUR)
        if row is not None:
            chips = tk.Frame(head, bg=WHITE)
            chips.pack(anchor="w", padx=20, pady=(0, 12))
            out = holder.startswith("Izsniegts")
            izskats.chip(chips, CHECKED_OUT if out else AVAILABLE, *((BAD_BG, BAD_FG) if out else (OK_BG, OK_FG))
                         ).pack(side="left")
            condition_chip(chips, row[5]).pack(side="left", padx=6)

        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(foot, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        izskats.note(foot, "Veidus un komplektus pievieno: Noliktava → ⚙ Veidi un komplekti.", bg=WHITE
                     ).pack(side="left")

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        # -- data ------------------------------------------------------------------
        data_outer, _h, data = izskats.panel(body, "Tērpa dati")
        data_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        grid = tk.Frame(data, bg=WHITE)
        grid.pack(fill="both", expand=True, padx=14, pady=10)
        grid.columnconfigure(1, weight=1)
        self.vars = {k: tk.StringVar() for k in ("inv_no", "name", "category", "type", "set_name")}
        fields = [
            ("inv_no", L("pieces.inv_no") + " *", None, False),
            ("name", L("pieces.name") + " *", None, False),
            ("category", L("pieces.category") + " *", CATEGORIES, True),
            ("type", L("pieces.type"), db.type_names(), True),
            ("set_name", L("pieces.set_name"), db.set_names(), True),
        ]
        r = 0
        for key, label, choices, readonly in fields:
            small_label(grid, label.upper()).grid(row=r, column=0, sticky="w", pady=(6, 0), padx=(0, 14))
            if choices is None:
                w = ttk.Entry(grid, textvariable=self.vars[key], width=34)
            else:
                w = ttk.Combobox(grid, textvariable=self.vars[key], values=choices, width=32,
                                 state="readonly" if readonly else "normal")
            w.grid(row=r, column=1, sticky="ew", pady=(6, 0))
            if key == "type":
                w.bind("<<ComboboxSelected>>", lambda e: self.on_type())
            r += 1
        small_label(grid, (L("pieces.condition_notes") + " *").upper()).grid(row=r, column=0, sticky="w",
                                                                              pady=(6, 0), padx=(0, 14))
        self.condition_var = tk.StringVar(value=DEFAULT_CONDITION)
        cond_row = tk.Frame(grid, bg=WHITE)
        cond_row.grid(row=r, column=1, sticky="ew", pady=(6, 0))
        ttk.Combobox(cond_row, textvariable=self.condition_var, values=CONDITIONS, state="readonly",
                     width=16).pack(side="left")
        self.cond_chip = tk.Frame(cond_row, bg=WHITE)
        self.cond_chip.pack(side="left", padx=8)
        self.condition_var.trace_add("write", lambda *a: self.paint_condition())

        # -- photos and history ------------------------------------------------------
        side = tk.Frame(body, bg=CREAM)
        side.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        ph_outer, ph_head, ph = izskats.panel(side, L("pieces.photos"))
        ph_outer.pack(fill="x")
        box = tk.Frame(ph, bg=WHITE)
        box.pack(fill="x", padx=14, pady=10)
        self.photo_list = tk.Listbox(box, height=4, width=28, relief="flat", bd=0, highlightthickness=1,
                                     highlightbackground=FIELD_LINE, selectbackground=SELECTED,
                                     selectforeground=NAVY, fg=NAVY, font=FONT_SMALL)
        self.photo_list.pack(fill="x")
        self.photo_list.bind("<Double-1>", lambda e: self.open_photo())
        pb = tk.Frame(ph, bg=WHITE)
        pb.pack(fill="x", padx=14, pady=(0, 10))
        ttk.Button(pb, text="＋ Pievienot…", command=self.add_photo).pack(side="left")
        ttk.Button(pb, text="Atvērt", command=self.open_photo).pack(side="left", padx=6)
        ttk.Button(pb, text="Noņemt", command=self.remove_photo).pack(side="left")

        if piece_id is not None:
            hist = db.q("SELECT d.name, c.checkout_date, c.return_date FROM checkouts c "
                        "JOIN dancers d ON d.id = c.dancer_id WHERE c.piece_id = ? "
                        "ORDER BY c.checkout_date DESC, c.id DESC", (piece_id,))
            h_outer, _hh, hb = izskats.panel(side, "Izsniegumu vēsture", subtitle=f"{len(hist)}")
            h_outer.pack(fill="both", expand=True, pady=(10, 0))
            if not hist:
                izskats.note(hb, "Šis tērps vēl nav izsniegts.", bg=WHITE).pack(anchor="w", padx=14, pady=10)
            for name, out_d, back in hist[:8]:
                line = tk.Frame(hb, bg=WHITE)
                line.pack(fill="x", padx=14, pady=(6, 0))
                tk.Label(line, text=name, bg=WHITE, fg=NAVY, font=FONT_BOLD).pack(side="left")
                back = (back or "").strip()
                tk.Label(line, text=f"{show_date(out_d)} – {show_date(back) if back else 'pašlaik'}", bg=WHITE,
                         fg=RED if not back else MUTED, font=FONT_SMALL).pack(side="right")
            if len(hist) > 8:
                izskats.note(hb, f"… un vēl {len(hist) - 8}", bg=WHITE).pack(anchor="w", padx=14, pady=(4, 0))
            tk.Frame(hb, bg=WHITE, height=8).pack()

        # entries are either stored file names (no directory part) or new source paths
        self.photos = []
        if row is not None:
            for key, val in zip(("inv_no", "name", "category", "type", "set_name"), row):
                self.vars[key].set(val or "")
            if self.vars["category"].get() not in CATEGORIES:
                self.vars["category"].set("")  # old value no longer allowed: choose again
            # an old free-text note is no longer valid: choose one of the three conditions again
            self.condition_var.set(row[5] if row[5] in CONDITIONS else "")
            self.photos = [p[0] for p in db.q("SELECT filename FROM photos WHERE piece_id=?", (piece_id,))]
        self.refresh_photos()
        self.paint_condition()
        self.bind("<Escape>", lambda e: self.destroy())
        if not catalog_editable():
            piekluve.make_readonly(self, note="Tikai skatīšanai — tērpus labo tērpu pārzinis.")

    def holder_text(self, piece_id):
        if piece_id is None:
            return ""
        rows = self.app.db.q("SELECT d.name, c.checkout_date FROM checkouts c JOIN dancers d ON d.id = c.dancer_id "
                             "WHERE c.piece_id = ? AND TRIM(COALESCE(c.return_date,'')) = '' "
                             "ORDER BY c.id DESC LIMIT 1", (piece_id,))
        if rows:
            return f"Izsniegts: {rows[0][0]} kopš {show_date(rows[0][1])}"
        return "Noliktavā — pieejams izsniegšanai"

    def paint_condition(self):
        for w in self.cond_chip.winfo_children():
            w.destroy()
        if self.condition_var.get() in CONDITIONS:
            condition_chip(self.cond_chip, self.condition_var.get()).pack()

    def on_type(self):
        # an empty category is filled in from the chosen type
        cat = self.app.db.type_category_map().get(self.vars["type"].get().strip().lower())
        if cat and not self.vars["category"].get().strip():
            self.vars["category"].set(cat)

    def refresh_photos(self):
        self.photo_list.delete(0, tk.END)
        for p in self.photos:
            self.photo_list.insert(tk.END, os.path.basename(p))
        if not self.photos:
            self.photo_list.insert(tk.END, "  (nav pievienotu foto)")

    def add_photo(self):
        paths = filedialog.askopenfilenames(
            parent=self, title="Izvēlieties foto",
            filetypes=[("Attēli", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"), ("Visi faili", "*.*")])
        self.photos.extend(paths)
        self.refresh_photos()

    def _selected_photo(self):
        sel = self.photo_list.curselection()
        return self.photos[sel[0]] if sel and sel[0] < len(self.photos) else None

    def open_photo(self):
        p = self._selected_photo()
        if p:
            open_external(p if os.path.dirname(p) else os.path.join(PHOTO_DIR, p))

    def remove_photo(self):
        sel = self.photo_list.curselection()
        if sel and sel[0] < len(self.photos):
            del self.photos[sel[0]]
            self.refresh_photos()

    def save(self):
        if not catalog_editable():
            return piekluve.deny(self, "Tērpus labo tērpu pārzinis vai kolektīva vadība.")
        inv = self.vars["inv_no"].get().strip()
        name = self.vars["name"].get().strip()
        category = self.vars["category"].get().strip()
        if not inv or not name:
            messagebox.showwarning("Trūkst datu", "Lūdzu, norādiet inventāra numuru un nosaukumu.", parent=self)
            return
        if category not in CATEGORIES:
            messagebox.showwarning("Kategorija", "Izvēlieties kategoriju: puišu tērpi, meiteņu tērpi vai nekategorizēts.", parent=self)
            return
        condition = self.condition_var.get().strip()
        if condition not in CONDITIONS:
            messagebox.showwarning("Stāvoklis", "Izvēlieties stāvokli: " + ", ".join(CONDITIONS) + ".", parent=self)
            return
        values = (inv, name, category, self.vars["type"].get().strip(),
                  self.vars["set_name"].get().strip(), condition)
        db = self.app.db
        try:
            if self.piece_id is None:
                self.piece_id = db.x(
                    "INSERT INTO costume_pieces (inv_no, name, category, type, set_name, condition_notes) "
                    "VALUES (?,?,?,?,?,?)", values)
            else:
                db.x("UPDATE costume_pieces SET inv_no=?, name=?, category=?, type=?, set_name=?, "
                     "condition_notes=? WHERE id=?", values + (self.piece_id,))
        except sqlite3.IntegrityError as exc:
            if "kategorija" in str(exc):
                msg = "Nederīga kategorija."
            elif "stāvoklis" in str(exc):
                msg = "Nederīgs stāvoklis."
            else:
                msg = (f"Inventāra numurs “{inv}” kategorijā “{category}” jau eksistē. "
                       "Vienu un to pašu numuru drīkst izmantot tikai dažādās kategorijās.")
            messagebox.showerror("Kļūda", msg, parent=self)
            return
        # photos: copy new files, then rewrite the attachment rows
        os.makedirs(PHOTO_DIR, exist_ok=True)
        stored = []
        for p in self.photos:
            if os.path.dirname(p):
                ext = os.path.splitext(p)[1]
                new_name = f"{uuid.uuid4().hex}{ext}"
                shutil.copy2(p, os.path.join(PHOTO_DIR, new_name))
                stored.append(new_name)
            else:
                stored.append(p)
        db.con.execute("DELETE FROM photos WHERE piece_id=?", (self.piece_id,))
        db.con.executemany("INSERT INTO photos (piece_id, filename) VALUES (?,?)",
                           [(self.piece_id, s) for s in stored])
        db.con.commit()
        self.app.refresh_all()
        self.destroy()


# --------------------------------------------------------------------------
# Izsniegt
# --------------------------------------------------------------------------
class StepCard(tk.Frame):
    """“1 · NOTIKUMS” — one step of the issue view; the step to do now has a red frame."""

    def __init__(self, master, number, title):
        super().__init__(master, bg=WHITE, highlightthickness=2, highlightbackground=LINE)
        self.number, self.name = number, title
        self.head = tk.Label(self, text=f"{number} · {title}", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold"),
                             anchor="w")
        self.head.pack(fill="x", padx=12, pady=(8, 3))
        self.body = tk.Frame(self, bg=WHITE)
        self.body.pack(fill="x", padx=12)
        self.caption_var = tk.StringVar()
        # width=1: the text never makes the card wider (it wraps to the card's width instead)
        self.caption = tk.Label(self, textvariable=self.caption_var, bg=WHITE, fg="#4A4535", font=FONT_SMALL,
                                anchor="w", justify="left", width=1, height=2)
        self.caption.pack(fill="x", padx=12, pady=(5, 9))
        self._wrap = 0
        self.bind("<Configure>", self._rewrap)

    def _rewrap(self, event):
        wrap = max(120, event.width - 28)
        if abs(wrap - self._wrap) > 4:
            self._wrap = wrap
            self.caption.configure(wraplength=wrap)

    def set_state(self, state):
        """'active' (do this now), 'done' or 'todo'."""
        self.configure(highlightbackground=RED if state == "active" else LINE)
        self.head.configure(text=("✓ " if state == "done" else "") + f"{self.number} · {self.name}",
                            fg=RED if state == "active" else (OK_FG if state == "done" else MUTED))


class IssueWindow(tk.Frame):
    """Izsniegt: 1 — an event, 2 — a dance of its programme, 3 — a dancer who dances that dance at that event.
    Left: the costume types the dance needs (issued / chosen / missing) and the dancer's pieces; right: the
    available pieces. Women see only girls' costumes, men only boys' costumes."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        L = app.L

        self.event_map = {}           # label -> session id
        self.publicity = {}           # session id -> invited dancer ids (only "Publicitātes pasākums")
        self.dance_map = {}           # label -> dance id
        self.event_dates = {}
        self.event_label = ""
        self.dance_label = ""
        self.dancer_map = {}          # label -> (id, gender)
        self.dancer_id = None
        self.gender = ""
        self.current_label = ""
        self.original = {}            # piece_id -> checkout_id (already issued)
        self.original_dates = {}      # piece_id -> checkout date
        self.selected = []            # piece ids chosen for this dancer
        self._last_move = 0.0
        self.need_counts = (0, 0)

        # -- 1 · 2 · 3 ---------------------------------------------------------------
        steps = tk.Frame(self, bg=CREAM)
        steps.pack(fill="x", padx=20, pady=(14, 0))
        for i in range(3):
            steps.columnconfigure(i, weight=1, uniform="s")
        self.step_event = StepCard(steps, 1, "NOTIKUMS")
        self.step_event.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self.step_dance = StepCard(steps, 2, "DEJA")
        self.step_dance.grid(row=0, column=1, sticky="nsew", padx=6)
        self.step_dancer = StepCard(steps, 3, "DEJOTĀJS")
        self.step_dancer.grid(row=0, column=2, sticky="nsew", padx=(6, 0))

        b = self.step_event.body
        self.event_var = tk.StringVar()
        self.event_cb = ttk.Combobox(b, textvariable=self.event_var, state="readonly", width=30)
        self.event_cb.pack(fill="x")
        self.event_cb.bind("<<ComboboxSelected>>", lambda e: self.on_event())
        links = tk.Frame(b, bg=WHITE)
        links.pack(fill="x", pady=(5, 0))
        link(links, "Tuvākais notikums", self.pick_nearest_event).pack(side="left")
        self.sum_btn = link(links, "Tērpu kopsavilkums", self.open_summary)
        self.sum_btn.pack(side="left", padx=(14, 0))
        self.sum_btn.pack_forget()    # shown while an event is chosen

        b = self.step_dance.body
        self.dance_var = tk.StringVar()
        self.dance_cb = ttk.Combobox(b, textvariable=self.dance_var, state="readonly", width=26)
        self.dance_cb.pack(fill="x")
        self.dance_cb.bind("<<ComboboxSelected>>", lambda e: self.on_dance())

        b = self.step_dancer.body
        self.dancer_var = tk.StringVar()
        # editable: start typing a name to narrow the list; Enter / Tab confirms the first match
        self.dancer_cb = ttk.Combobox(b, textvariable=self.dancer_var, state="normal", width=20)
        self.dancer_cb.pack(side="left", fill="x", expand=True)
        self.dancer_cb.bind("<<ComboboxSelected>>", lambda e: self.on_dancer())
        self.dancer_cb.bind("<KeyRelease>", self.dancer_typed)
        self.dancer_cb.bind("<Return>", self.dancer_confirm)
        self.dancer_cb.bind("<KP_Enter>", self.dancer_confirm)
        self.dancer_cb.bind("<Tab>", self.dancer_confirm)
        self.gender_filter_var = tk.StringVar(value=GENDER_FILTER_ALL)
        self.gender_filter_prev = GENDER_FILTER_ALL
        gender_cb = ttk.Combobox(b, textvariable=self.gender_filter_var, state="readonly", width=11,
                                 values=list(GENDER_FILTERS))
        gender_cb.pack(side="left", padx=(6, 0))
        gender_cb.bind("<<ComboboxSelected>>", lambda e: self.on_gender_filter())

        self.info_var = tk.StringVar(value="Izvēlieties notikumu, deju un dejotāju.")
        tk.Label(self, textvariable=self.info_var, bg=CREAM, fg=MUTED, font=FONT_SMALL, anchor="w",
                 justify="left").pack(fill="x", padx=22, pady=(8, 0))

        # warning banner (shown above the lists only when needed)
        self.warn_var = tk.StringVar()
        self.warn_lbl = tk.Label(self, textvariable=self.warn_var, bg=BAD_BG, fg=RED,
                                 font=("Segoe UI", 10, "bold"), anchor="w", justify="left",
                                 wraplength=1000, padx=12, pady=6, highlightbackground=RED, highlightthickness=1)

        # -- bottom bar -----------------------------------------------------------
        bar = bottom_bar(self)
        self.summary_var = tk.StringVar()
        tk.Label(bar, textvariable=self.summary_var, bg=WHITE, fg=NAVY, font=FONT, anchor="w",
                 justify="left").pack(side="left", fill="x", expand=True)
        self.issue_btn = ttk.Button(bar, text="Izsniegt", style="Accent.TButton", command=self.save)
        self.issue_btn.pack(side="right")
        acc = piekluve.current()
        self.view_only = acc.view_only("terpu_purs")
        if self.view_only:
            self.issue_btn.configure(state="disabled")
            rights_note(bar, "tikai skatīšanai", bg=WHITE)
        elif not acc.edits_all("terpu_purs"):
            rights_note(bar, "tikai " + acc.scope_text("terpu_purs") + "s dejotājiem", bg=WHITE)
        self.notes_var = tk.StringVar()
        ttk.Entry(bar, textvariable=self.notes_var, width=22).pack(side="right", padx=(4, 14))
        small_label(bar, "PIEZĪME").pack(side="right")
        self.date_var = tk.StringVar(value=today_text())
        date_picker_button(bar, self.date_var, bg=WHITE).pack(side="right", padx=(2, 14))
        ttk.Entry(bar, textvariable=self.date_var, width=11).pack(side="right")
        small_label(bar, "DATUMS").pack(side="right", padx=(14, 4))

        # -- left: needed types and the dancer's pieces · right: available pieces -------------
        panes = tk.Frame(self, bg=CREAM)
        self.panes = panes
        panes.pack(fill="both", expand=True, padx=20, pady=(10, 0))
        panes.columnconfigure(0, weight=2, uniform="p")
        panes.columnconfigure(1, weight=3, uniform="p")
        panes.rowconfigure(0, weight=1)

        left = tk.Frame(panes, bg=CREAM)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        needs_outer, self.needs_head, self.needs_box = izskats.panel(left, "Vajadzīgie tērpi", subtitle="")
        needs_outer.pack(fill="x")

        mine_outer, self.mine_head, mine = izskats.panel(left, "Dejotājam izsniegtie un izvēlētie", subtitle="")
        mine_outer.pack(fill="both", expand=True, pady=(10, 0))
        rh = tk.Frame(mine, bg=WHITE)
        rh.pack(fill="both", expand=True)
        rcols = ("inv_no", "name", "type", "set_name", "state", "go")
        self.right = ttk.Treeview(rh, columns=rcols, show="headings", height=5)
        for c, w in (("inv_no", 80), ("name", 120), ("type", 90), ("set_name", 90), ("state", 100)):
            self.right.heading(c, text=L("pieces." + c) if c != "state" else L("checkouts.state"))
            self.right.column(c, width=w, anchor="w")
        self.right.heading("go", text="")
        self.right.column("go", width=70, anchor="center", stretch=False)
        self.right["displaycolumns"] = ("inv_no", "type", "set_name", "state", "go")  # no "Nosaukums"
        make_tree_with_scroll(rh, self.right)
        zebra(self.right)
        self.right.tag_configure("existing", foreground=NAVY)
        self.right.tag_configure("new", foreground=OK_FG, font=FONT_BOLD)
        self.right.bind("<ButtonRelease-1>", lambda e: self.arrow_click(self.right, e, "#5", False))
        self.right.bind("<Double-1>", lambda e: self.double_click(self.right, e, False))

        avail_outer, self.avail_head, avail = izskats.panel(panes, "Pieejamie tērpi", subtitle="")
        avail_outer.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        tools = self.avail_head.right
        self.search_var = tk.StringVar()
        izskats.search_box(tools, self.search_var, width=12).pack(side="right")
        self.search_var.trace_add("write", lambda *a: self.refresh_lists())
        self.type_var = tk.StringVar(value=ALL)
        self.type_cb = ttk.Combobox(tools, textvariable=self.type_var, state="readonly", width=14,
                                    values=[ALL] + app.db.type_names())
        self.type_cb.pack(side="right", padx=(0, 8))
        small_label(tools, "VEIDS").pack(side="right", padx=(0, 4))
        self.type_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_lists())

        last_row = tk.Frame(avail, bg=WHITE)
        last_row.pack(side="bottom", fill="x")
        tk.Frame(last_row, bg=LINE_SOFT, height=1).pack(fill="x")
        last_inner = tk.Frame(last_row, bg=WHITE)
        last_inner.pack(fill="x", padx=14, pady=7)
        self.last_var = tk.StringVar()
        tk.Label(last_inner, textvariable=self.last_var, bg=WHITE, fg="#4A4535", font=FONT_SMALL).pack(side="left")
        self.hist_btn = link(last_inner, "Visa vēsture", self.open_history)
        self.hist_btn.pack_forget()   # shown only while a dancer and a type are chosen and there is a history

        lh = tk.Frame(avail, bg=WHITE)
        lh.pack(fill="both", expand=True)
        cols = ("inv_no", "name", "type", "set_name", "cond", "go")
        self.left = ttk.Treeview(lh, columns=cols, show="headings")
        for c, w in (("inv_no", 90), ("name", 150), ("type", 110), ("set_name", 110)):
            self.left.heading(c, text=L("pieces." + c))
            self.left.column(c, width=w, anchor="w")
        self.left.heading("cond", text=L("pieces.condition_notes"))
        self.left.column("cond", width=90, anchor="w")
        self.left.heading("go", text="")
        self.left.column("go", width=96, anchor="center", stretch=False)
        self.left["displaycolumns"] = ("inv_no", "type", "set_name", "cond", "go")  # "Nosaukums" is not shown
        make_tree_with_scroll(lh, self.left)
        zebra(self.left)
        self.left.tag_configure("last", background=SELECTED, font=FONT_BOLD)  # the piece this dancer had last time
        self.left.tag_configure("fix", foreground=WARN_FG)
        self.left.tag_configure("broken", foreground=DISABLED_FG)
        self.left.bind("<ButtonRelease-1>", lambda e: self.arrow_click(self.left, e, "#5", True))
        self.left.bind("<Double-1>", lambda e: self.double_click(self.left, e, True))

        self.load_events()
        self.load_dancers()
        self.refresh_lists()

    # -- data -------------------------------------------------------------
    def dirty(self):
        return set(self.selected) != set(self.original)

    def confirm_discard(self):
        return not self.dirty() or messagebox.askyesno(
            "Nesaglabātas izmaiņas", "Izmaiņas nav saglabātas. Vai atmest tās?", parent=self)

    def load_events(self):
        """Events (concerts, reviews, collective events - no rehearsals) from Notikumu pūrs, newest first."""
        db = self.app.db
        rows = []
        if db.has_table("attendance_sessions"):
            rows = db.q("SELECT id, session_date, kind, title FROM attendance_sessions "
                        "WHERE kind NOT IN (?, ?) ORDER BY session_date DESC, id DESC",
                        (KIND_REHEARSAL, KIND_EXTRA_REHEARSAL))
        # Notikumu pūrs: sub-kind of "Kolektīva pasākums" and the dancers invited to a publicity event
        details = {}
        if db.has_table("event_details"):
            cols = {r[1] for r in db.q("PRAGMA table_info(event_details)")}
            if {"subkind", "invited"} <= cols:
                details = {sid: (sub or "", inv or "") for sid, sub, inv in
                           db.q("SELECT session_id, subkind, invited FROM event_details")}
        self.event_map = {}
        self.event_dates = {}         # session id -> ISO date
        self.event_kinds = {}         # session id -> kind shown
        self.publicity = {}
        for sid, day, kind, title in rows:
            subkind, invited = details.get(sid, ("", ""))
            shown_kind = subkind if kind == EVENT_KIND_GROUP and subkind else kind
            if kind == EVENT_KIND_GROUP and subkind == SUBKIND_PUBLICITY:
                self.publicity[sid] = invited_ids(invited)
            label = f"{show_date(day)}  {shown_kind or 'Notikums'}" + (f" “{title}”" if title else "")
            if label in self.event_map:
                label += f" (#{sid})"
            self.event_map[label] = sid
            self.event_dates[sid] = day or ""
            self.event_kinds[sid] = shown_kind or "Notikums"
        self.event_cb["values"] = list(self.event_map)
        if self.event_label not in self.event_map:
            self.event_label = ""
            self.event_var.set("")
        self.load_dances()

    def pick_nearest_event(self):
        """Choose the nearest upcoming event (today counts); falls back to a message when there is none."""
        today = date.today().isoformat()
        upcoming = [(self.event_dates.get(sid, ""), sid, label) for label, sid in self.event_map.items()
                    if self.event_dates.get(sid, "") >= today]
        if not upcoming:
            messagebox.showinfo("Tuvākais notikums", "Nav neviena tuvāk gaidāma notikuma.", parent=self)
            return
        label = min(upcoming)[2]
        self.event_var.set(label)
        self.on_event()

    def load_dances(self):
        """Dances in the programme of the chosen event."""
        db = self.app.db
        self.dance_map = {}
        sid = self.event_map.get(self.event_label)
        if sid is not None and db.has_table("session_dances") and db.has_table("dances"):
            rows = db.q("SELECT d.id, d.title FROM session_dances sd JOIN dances d ON d.id = sd.dance_id "
                        "LEFT JOIN event_program p ON p.session_id = sd.session_id AND p.dance_id = sd.dance_id "
                        "WHERE sd.session_id = ? ORDER BY COALESCE(p.position, 1000000), d.title", (sid,))
            for did, title in rows:
                label = title or f"Deja #{did}"
                if label in self.dance_map:
                    label += f" (#{did})"
                self.dance_map[label] = did
        self.dance_cb["values"] = list(self.dance_map)
        if self.dance_label not in self.dance_map:
            self.dance_label = ""
            self.dance_var.set("")
        if self.is_publicity():  # publicity events have no dances: costumes go to the invited dancers
            self.dance_var.set("— (publicitātes pasākumam nav deju)")
            self.dance_cb.configure(state="disabled")
        else:
            self.dance_cb.configure(state="readonly")
        if sid is not None:
            self.sum_btn.pack(side="left", padx=(14, 0))
        else:
            self.sum_btn.pack_forget()

    def is_publicity(self):
        """The chosen event is a "Publicitātes pasākums" (Kolektīva pasākums without dances)."""
        return self.event_map.get(self.event_label) in self.publicity

    def open_summary(self):
        sid = self.event_map.get(self.event_label)
        if sid is None:
            return
        dances = [(did, label) for label, did in self.dance_map.items()]
        if self.is_publicity():
            dances = [(None, "Uzaicinātie dejotāji")]
        wanted = GENDER_FILTERS.get(self.gender_filter_var.get())   # "Meitenes" / "Puiši" chosen above the dancer list
        lineup, label = self.lineup_rows, self.event_label
        if wanted:
            def lineup(session_id, dance_id, _rows=self.lineup_rows):
                return [r for r in _rows(session_id, dance_id) if r[2] == wanted]
            label = f"{self.event_label}  ·  {self.gender_filter_var.get()}"
        EventCostumeSummary(self, self.app.db, label, dances, lineup, sid)

    def publicity_types(self, sid):
        """{gender: {lower-case type names}} chosen for a publicity event in Notikumu pūrs (empty — none chosen)."""
        return {g: {(n or "").strip().lower() for n in names}
                for g, names in event_costume_types(self.app.db.con, [sid]).get(sid, {}).items()}

    def dance_type_names(self):
        """Lower-case costume type names added to the chosen dance in Deju pūrs (or, for a publicity event, chosen
        in Notikumu pūrs) for the dancer's gender (all genders while the gender is unknown); None while no dance
        is chosen or a publicity event has no costume types."""
        db = self.app.db
        if self.is_publicity():
            by_gender = self.publicity_types(self.event_map.get(self.event_label))
            if not by_gender:
                return None
            if self.dancer_id is not None and self.gender:
                return by_gender.get(self.gender, set())
            return set().union(*by_gender.values())
        did = self.dance_map.get(self.dance_label)
        if did is None or not db.has_table("dance_costumes"):
            return None
        sql, params = "SELECT type_name FROM dance_costumes WHERE dance_id = ?", [did]
        if self.dancer_id is not None and self.gender:
            sql += " AND gender = ?"
            params.append(self.gender)
        return {(n or "").strip().lower() for (n,) in db.q(sql, params)}

    def dance_types_text(self):
        """“Puiši: veste, krekls · Meitas: brunči” for the second step card."""
        db = self.app.db
        sid = self.event_map.get(self.event_label)
        by = {}
        if self.is_publicity():
            by = event_costume_types(db.con, [sid]).get(sid, {})
        else:
            did = self.dance_map.get(self.dance_label)
            if did is None:
                return ""
            if db.has_table("dance_costumes"):
                for g, n in db.q("SELECT gender, type_name FROM dance_costumes WHERE dance_id = ?", (did,)):
                    by.setdefault(g, []).append(n)
        parts = []
        for g, title in ((GENDER_MALE, "Puiši"), (GENDER_FEMALE, "Meitas")):
            names = sorted({(n or "").strip() for n in by.get(g, []) if (n or "").strip()}, key=_norm)
            if names:
                parts.append(f"{title}: " + ", ".join(n.lower() for n in names))
        if parts:
            return " · ".join(parts)
        return ("Publicitātes pasākums — tērpu veidi Notikumu pūrā nav izvēlēti" if self.is_publicity()
                else "Dejai Deju pūrā nav pievienoti tērpu veidi")

    def on_event(self):
        label = self.event_var.get()
        if label == self.event_label:
            return
        if not self.confirm_discard():
            self.event_var.set(self.event_label)
            return
        self.event_label = label
        self.dance_label = ""
        self.dance_var.set("")
        self.load_dances()
        self.load_dancers()
        if self.dancer_id is not None:
            self.reload()
        else:
            self.refresh_lists()
        if self.is_publicity():
            if not self.dancer_map:
                self.info_var.set("Šim publicitātes pasākumam nav uzaicināto dejotāju (vai visi atbildējuši "
                                  "“Nebūs”). Uzaicina modulī “Notikumu pūrs”.")
        elif not self.dance_map:
            self.info_var.set("Šim notikumam nav deju programmas. Dejas pievieno modulī “Notikumu pūrs”.")

    def on_dance(self):
        label = self.dance_var.get()
        if label == self.dance_label:
            return
        if not self.confirm_discard():
            self.dance_var.set(self.dance_label)
            return
        self.dance_label = label
        self.load_dancers()
        if self.dancer_id is not None:
            self.reload()
        else:
            self.refresh_lists()

    def lineup_rows(self, sid, did):
        """[(dancer id, label, gender)] of the dancers who dance dance `did` at event `sid` (sorted by name)."""
        db = self.app.db
        rows = []
        if sid is not None and did is None and sid in self.publicity:
            # publicity event: the invited dancers who have not answered "Nebūs"
            declined = {r[0] for r in db.q("SELECT dancer_id FROM event_participants WHERE session_id = ? "
                                           "AND answer = ?", (sid, ANS_NOT_COMING))} \
                if db.has_table("event_participants") else set()
            for dancer, name, gender in db.q(
                    "SELECT d.id, d.name, d.gender FROM dancers d WHERE " + active_dancer_sql("d")
                    + " OR EXISTS (SELECT 1 FROM checkouts c WHERE c.dancer_id = d.id "
                    "AND TRIM(COALESCE(c.return_date,'')) = '')"):
                if dancer in self.publicity[sid] and dancer not in declined:
                    rows.append((dancer, name, gender))
            rows.sort(key=lambda r: _norm(r[1]))
        elif sid is not None and did is not None and db.has_table("dance_cast"):
            # main-cast dancers who come; for one who answered "Nebūs" his reserve dancer is taken automatically
            declined = {r[0] for r in db.q("SELECT dancer_id FROM event_participants WHERE session_id = ? "
                                           "AND answer = ?", (sid, ANS_NOT_COMING))} \
                if db.has_table("event_participants") else set()
            lineup, _uncovered = dance_lineup(db.con, did, declined)
            info = {r[0]: r for r in db.q(
                "SELECT d.id, d.name, d.gender FROM dancers d WHERE " + active_dancer_sql("d")
                + " OR EXISTS (SELECT 1 FROM checkouts c WHERE c.dancer_id = d.id "
                "AND TRIM(COALESCE(c.return_date,'')) = '')")}
            names = dict(db.q("SELECT id, name FROM dancers"))
            for dancer, replaces in lineup:
                if dancer in info:
                    name = info[dancer][1] + (f" (rezerve, aizvieto {names.get(replaces, '')})" if replaces else "")
                    rows.append((dancer, name, info[dancer][2]))
            rows.sort(key=lambda r: _norm(r[1]))
        return rows

    def load_dancers(self):
        # only dancers who dance the chosen dance at the chosen event (cast of the dance, not declined);
        # active ones, plus anyone who still has costumes issued
        sid = self.event_map.get(self.event_label)
        did = self.dance_map.get(self.dance_label)
        rows = self.lineup_rows(sid, did)
        wanted_gender = GENDER_FILTERS.get(self.gender_filter_var.get())
        if wanted_gender:   # "Meitenes" / "Puiši": only dancers of that gender
            rows = [r for r in rows if r[2] == wanted_gender]
        labels = dancer_labels(rows)
        genders = {r[0]: r[2] for r in rows}
        self.dancer_map = {label: (did, genders[did]) for label, did in labels.items()}
        self.dancer_cb["values"] = list(self.dancer_map)
        if self.dancer_var.get() not in self.dancer_map:  # leftover typed text
            self.dancer_var.set(self.current_label if self.current_label in self.dancer_map else "")
        if sid is None:
            self.info_var.set("Izvēlieties notikumu, deju un dejotāju.")
        elif self.is_publicity():
            self.info_var.set("Publicitātes pasākums: izvēlieties uzaicināto dejotāju." if self.dancer_map else
                              "Šim publicitātes pasākumam nav uzaicināto dejotāju (vai visi atbildējuši “Nebūs”). "
                              "Uzaicina modulī “Notikumu pūrs”.")
        elif did is None:
            self.info_var.set("Izvēlieties deju.")
        elif not self.dancer_map and wanted_gender:
            self.info_var.set("Šajā izvēlē nav neviena dejotāja ar izvēlēto dzimumu (filtrs “Meitenes” / “Puiši”).")
        elif not self.dancer_map:
            self.info_var.set("Šajā notikumā šo deju neviens dejotājs nedejo (dejas sastāvu norāda modulī “Deju pūrs”).")
        elif self.dancer_id is None:
            self.info_var.set(f"Izvēlieties dejotāju ({len(self.dancer_map)} šajā dejā).")
        if self.current_label not in self.dancer_map:
            self.current_label = ""
            self.dancer_var.set("")
            self.dancer_id, self.gender = None, ""
            self.original, self.selected = {}, []

    def on_gender_filter(self):
        """"Meitenes" / "Puiši" / all: narrow the dancer list; the chosen dancer stays when he/she still fits."""
        wanted = GENDER_FILTERS.get(self.gender_filter_var.get())
        if self.dancer_id is not None and wanted and self.gender != wanted and not self.confirm_discard():
            # the chosen dancer would disappear and there are unsaved changes: keep everything as it was
            self.gender_filter_var.set(self.gender_filter_prev)
            return
        self.gender_filter_prev = self.gender_filter_var.get()
        self.load_dancers()
        if self.dancer_id is not None:
            self.reload()
        else:
            self.refresh_lists()

    def dancer_matches(self, text):
        """Dancer labels containing the typed text (case and diacritics ignored); prefix matches first."""
        key = _norm(text)
        labels = list(self.dancer_map)
        if not key:
            return labels
        hits = [l for l in labels if key in _norm(l)]
        return sorted(hits, key=lambda l: 0 if _norm(l).startswith(key) else 1)

    def dancer_typed(self, event):
        """Typing in the dancer field: narrow the list, complete the first name that starts with the text."""
        if event.keysym in ("Return", "KP_Enter", "Tab", "Escape", "Up", "Down", "Left", "Right", "Home", "End",
                            "Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "ISO_Left_Tab"):
            return
        text = self.dancer_var.get()
        matches = self.dancer_matches(text)
        self.dancer_cb["values"] = matches
        key = _norm(text)
        if key and event.keysym not in ("BackSpace", "Delete") and matches and _norm(matches[0]).startswith(key):
            if _norm(matches[0]) != key or matches[0] != text:
                self.dancer_var.set(matches[0])
                self.dancer_cb.icursor(len(text))
                self.dancer_cb.selection_range(len(text), "end")

    def dancer_confirm(self, event=None):
        """Enter / Tab: take the typed dancer (the first match when the text is not complete)."""
        text = self.dancer_var.get().strip()
        label = text if text in self.dancer_map else (self.dancer_matches(text) or [None])[0] if text else None
        self.dancer_cb["values"] = list(self.dancer_map)
        if label is None:
            self.dancer_var.set(self.current_label)   # nothing matches: back to the dancer chosen before
            return "break" if event is not None and event.keysym != "Tab" else None
        self.dancer_var.set(label)
        self.on_dancer()
        self.dancer_cb.selection_clear()
        return "break" if event is not None and event.keysym != "Tab" else None

    def on_dancer(self):
        label = self.dancer_var.get()
        if label == self.current_label:
            return
        if label not in self.dancer_map:
            self.dancer_var.set(self.current_label)
            return
        if self.dirty() and not messagebox.askyesno(
                "Nesaglabātas izmaiņas", "Izmaiņas nav saglabātas. Vai atmest tās?", parent=self):
            self.dancer_var.set(self.current_label)
            return
        self.current_label = label
        self.dancer_id, self.gender = self.dancer_map[label]
        self.reload()

    def reload(self):
        rows = self.app.db.q(
            "SELECT piece_id, id, checkout_date FROM checkouts WHERE dancer_id=? AND "
            "TRIM(COALESCE(return_date,''))='' ORDER BY id", (self.dancer_id,))
        self.original = {p: c for p, c, _d in rows}
        self.original_dates = {p: d for p, _c, d in rows}
        self.selected = [p for p, _c, _d in rows]
        wanted = GENDER_CATEGORY.get(self.gender)
        if wanted:
            text = f"Rādītie tērpi: {wanted.lower()} un {CAT_NONE.lower()}."
        else:
            text = "Dejotājam nav norādīts dzimums — rādīti visi pieejamie tērpi."
        dance_types = self.dance_type_names()
        if dance_types is not None and not dance_types:
            text = ("Šim publicitātes pasākumam Notikumu pūrā nav izvēlēts neviens tērpu veids šim dzimumam."
                    if self.is_publicity() else "Šai dejai Deju pūrā nav pievienots neviens tērpu veids šim dzimumam.")
        self.info_var.set(text)
        self.refresh_lists()

    def refresh(self):
        """Called by the app when data elsewhere changed."""
        self.load_events()
        self.load_dancers()
        if self.dancer_id is not None and not self.dirty():
            self.reload()
        else:
            self.refresh_lists()

    def update_warning(self):
        """Warn when the dancer has two or more pieces of the same type (veids)."""
        groups = {}
        if self.dancer_id is not None and self.selected:
            rows = {r[0]: r for r in self.app.db.q(
                "SELECT id, inv_no, name, type FROM costume_pieces WHERE id IN "
                + in_clause(self.selected), self.selected)}
            for pid in self.selected:
                if pid not in rows:
                    continue
                _id, inv, name, typ = rows[pid]
                typ = (typ or "").strip()
                if typ:
                    groups.setdefault(typ.lower(), (typ, []))[1].append(f"{inv} {name}")
        lines = [f"⚠ Dejotājam jau ir veids “{t}”, bet izvēlēts vēl viens: "
                 f"{', '.join(items)}" for t, items in groups.values() if len(items) > 1]
        if lines:
            self.warn_var.set("\n".join(lines))
            self.warn_lbl.pack(fill="x", padx=20, pady=(8, 0), before=self.panes)
        else:
            self.warn_lbl.pack_forget()

    def show_last_issued(self):
        """With a dancer and a costume type chosen: tell which piece of that type the dancer had last
        time. Returns that piece's id (highlighted in the list of available pieces) or None."""
        self.last_var.set("")
        self.hist_btn.pack_forget()
        type_choice = self.type_var.get()
        if self.dancer_id is None:
            return None
        if type_choice == ALL:
            self.last_var.set("Izvēlieties veidu, lai redzētu, kurš tērps šim dejotājam bija pagājušoreiz.")
            return None
        row = self.app.db.q(
            "SELECT p.id, p.inv_no, c.checkout_date, c.return_date FROM checkouts c "
            "JOIN costume_pieces p ON p.id = c.piece_id WHERE c.dancer_id = ? AND p.type = ? COLLATE NOCASE "
            "ORDER BY c.checkout_date DESC, c.id DESC LIMIT 1", (self.dancer_id, type_choice))
        if not row:
            self.last_var.set(f"Šim dejotājam veids “{type_choice}” vēl nav izsniegts.")
            return None
        pid, inv, out, back = row[0]
        back = (back or "").strip()
        when = f"izsniegts {show_date(out)}" + (f", atgriezts {show_date(back)}" if back else ", vēl nav atgriezts")
        self.last_var.set(f"Pagājušoreiz šim dejotājam: {type_choice.lower()} {inv} ({when})")
        self.hist_btn.pack(side="left", padx=(10, 0))
        return pid

    def open_history(self):
        """Whole history of the chosen costume type for the chosen dancer."""
        type_choice = self.type_var.get()
        if self.dancer_id is None or type_choice == ALL:
            return
        TypeHistoryDialog(self, self.app.db, self.dancer_id, self.current_label, type_choice)

    def filter_type(self, name):
        self.type_var.set(name if name in self.type_cb["values"] else ALL)
        self.refresh_lists()

    def update_steps(self):
        sid = self.event_map.get(self.event_label)
        did = self.dance_map.get(self.dance_label)
        dance_ok = sid is not None and (did is not None or self.is_publicity())
        self.step_event.set_state("done" if sid is not None else "active")
        self.step_dance.set_state("done" if dance_ok else ("active" if sid is not None else "todo"))
        self.step_dancer.set_state("active" if dance_ok else "todo")
        if sid is not None:
            day = self.event_dates.get(sid, "")
            rel = relative_day(day)
            self.step_event.caption_var.set(f"{weekday_text(day)} · {rel}" if rel else "")
        else:
            self.step_event.caption_var.set("Koncerti, skates un pasākumi no Notikumu pūra")
        self.step_dance.caption_var.set(self.dance_types_text() if dance_ok else
                                        "Dejas no notikuma programmas")
        if self.dancer_id is not None:
            parts = []
            size = dancer_size_text(self.app.db.con, self.dancer_id)
            if size:
                parts.append(size)
            have, need = self.need_counts
            if need:
                parts.append(f"{have} no {need} tērpiem izsniegti")
            else:
                parts.append(f"izsniegti tērpi: {len(self.original)}")
            self.step_dancer.caption_var.set(" · ".join(parts))
        elif dance_ok:
            self.step_dancer.caption_var.set(f"{len(self.dancer_map)} dejotāji — rakstiet vārdu vai izvēlieties")
        else:
            self.step_dancer.caption_var.set("Dejotāji, kuri šo deju dejo šajā notikumā")

    def update_needs(self, pieces):
        """Left box: the costume types the dance (or publicity event) needs for this dancer."""
        box = self.needs_box
        for w in box.winfo_children():
            w.destroy()
        head = self.needs_head
        wanted = self.dance_type_names()
        head.title.configure(text="Vajadzīgie tērpi šim pasākumam" if self.is_publicity() else
                             "Vajadzīgie tērpi šai dejai")
        head.subtitle.configure(text="")
        self.need_counts = (0, 0)
        if self.dancer_id is None or wanted is None or not wanted:
            if self.dancer_id is None:
                msg = "Kad būs izvēlēts dejotājs, šeit būs redzams, kuri tērpi viņam jau izsniegti un kuri vēl trūkst."
            elif wanted is None:
                msg = ("Izvēlieties deju — tad būs redzami dejai vajadzīgie tērpu veidi."
                       if not self.is_publicity() else
                       "Publicitātes pasākumam Notikumu pūrā nav izvēlēti tērpu veidi — rādīti visi dejotāja tērpi.")
            else:
                msg = "Dejotāja dzimumam šai dejai nav pievienots neviens tērpu veids (Deju pūrs → dejas logs → Tērpi)."
            izskats.note(box, msg, bg=WHITE, wrap=320).pack(fill="x", padx=14, pady=10)
            return
        names = {n.lower(): n for n in self.app.db.type_names()}
        chosen_type = self.type_var.get().lower()
        have = 0
        for i, t in enumerate(sorted(wanted, key=lambda x: _norm(names.get(x, x)))):
            shown = names.get(t, t[:1].upper() + t[1:])
            mine = [pid for pid in self.selected if (pieces.get(pid, ("", "", ""))[1] or "").strip().lower() == t]
            issued = [pid for pid in mine if pid in self.original]
            new = [pid for pid in mine if pid not in self.original]
            if issued:
                have += 1
                state, colours = "Izsniegts", (OK_BG, OK_FG)
                info = "izsniegts " + ", ".join(pieces[p][0] for p in issued) + \
                       f" · {show_date(self.original_dates.get(issued[0], ''))}"
            elif new:
                state, colours = "Izvēlēts", ("#E8EEF7", NAVY)
                info = "izvēlēts " + ", ".join(pieces[p][0] for p in new) + " — vēl jāizsniedz"
            else:
                state, colours = "Trūkst", (BAD_BG, BAD_FG)
                info = "vēl nav izsniegts — klikšķis: rādīt pieejamos"
            bg = SELECTED if chosen_type == t else WHITE
            row = tk.Frame(box, bg=bg, cursor="hand2")
            row.pack(fill="x")
            if i:
                tk.Frame(row, bg=LINE_SOFT, height=1).pack(fill="x")
            inner = tk.Frame(row, bg=bg)
            inner.pack(fill="x", padx=14, pady=6)
            tk.Frame(inner, bg=colours[1], width=9, height=9).pack(side="left", padx=(0, 10))
            text = tk.Frame(inner, bg=bg)
            text.pack(side="left", fill="x", expand=True)
            tk.Label(text, text=shown, bg=bg, fg=NAVY, font=FONT_BOLD, anchor="w").pack(fill="x")
            tk.Label(text, text=info, bg=bg, fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x")
            izskats.chip(inner, state, *colours).pack(side="right")
            for w in [row, inner, text] + list(text.winfo_children()):
                w.bind("<Button-1>", lambda e, n=shown: self.filter_type(n))
        if self.type_var.get() != ALL:
            more = tk.Frame(box, bg=WHITE)
            more.pack(fill="x", padx=14, pady=(4, 8))
            link(more, "Rādīt visus veidus", lambda: self.filter_type(ALL)).pack(side="left")
        head.subtitle.configure(text=f"{have} no {len(wanted)} izsniegti")
        self.need_counts = (have, len(wanted))

    def update_summary(self, pieces):
        new = [p for p in self.selected if p not in self.original]
        removed = [p for p in self.original if p not in self.selected]
        if self.dancer_id is None:
            text = "Izvēlieties notikumu, deju un dejotāju, tad — tērpus no saraksta labajā pusē."
        elif not new and not removed:
            text = "Nekas nav izvēlēts — spiediet “＋ Izvēlēties” pie tērpa labajā pusē."
        else:
            parts = []
            if new:
                parts.append("Izsniegšanai izvēlēts: " + ", ".join(pieces.get(p, (str(p),))[0] for p in new))
            if removed:
                parts.append("atgriezt noliktavā: " + ", ".join(pieces.get(p, (str(p),))[0] for p in removed))
            text = " · ".join(parts)
        self.summary_var.set(text)
        if new and not removed:
            label = f"Izsniegt {len(new)} {pieces_word(len(new))}"
        elif new or removed:
            label = "Saglabāt izmaiņas"
        else:
            label = "Izsniegt"
        self.issue_btn.configure(text=label,
                                 state="disabled" if self.view_only or not (new or removed) else "normal")

    def refresh_lists(self):
        db = self.app.db
        self.left.delete(*self.left.get_children())
        self.right.delete(*self.right.get_children())
        self.update_warning()
        wanted = GENDER_CATEGORY.get(self.gender) if self.dancer_id is not None else None
        types = db.type_names_for(wanted) if wanted else db.type_names()
        dance_types = self.dance_type_names()
        if dance_types is not None:  # only the types added to the dance in Deju pūrs
            types = [t for t in types if t.lower() in dance_types]
        types = [ALL] + types
        self.type_cb["values"] = types
        if self.type_var.get() not in types:
            self.type_var.set(ALL)
        pieces = {}
        ids = list(set(self.selected) | set(self.original))
        if ids:
            pieces = {r[0]: r[1:] for r in db.q("SELECT id, inv_no, type, set_name FROM costume_pieces WHERE id IN "
                                                 + in_clause(ids), ids)}
        type_choice = self.type_var.get()
        title = "Pieejamie tērpi" + (f" · {type_choice.lower()}" if type_choice != ALL else "")
        if wanted:
            title += " · " + wanted.split()[0].lower()
        self.avail_head.title.configure(text=title)
        if self.dancer_id is None:
            self.last_var.set("")
            self.hist_btn.pack_forget()
            self.avail_head.subtitle.configure(text="")
            self.mine_head.subtitle.configure(text="")
            izskats_hint = "Vispirms izvēlieties dejotāju."
            self.left.insert("", "end", values=("", "", izskats_hint, "", "", ""))
            self.update_needs(pieces)
            self.update_summary(pieces)
            self.update_steps()
            return
        last_piece = self.show_last_issued()
        sql = ("SELECT id, inv_no, name, type, set_name, condition_notes FROM "
               "(SELECT p.*, " + STATUS_EXPR.format(p="p.id") + " AS status_f FROM costume_pieces p) pp "
               "WHERE 1=1")
        params = []
        orig = list(self.original)
        if orig:
            sql += " AND (status_f = ? OR id IN " + in_clause(orig) + ")"
            params += [AVAILABLE] + orig
        else:
            sql += " AND status_f = ?"
            params.append(AVAILABLE)
        if self.selected:
            sql += " AND id NOT IN " + in_clause(self.selected)
            params += self.selected
        if wanted:  # the type's category decides (a piece without a known type uses its own category)
            sql += (" AND COALESCE((SELECT t.category FROM piece_types t WHERE t.name = pp.type COLLATE NOCASE),"
                    " pp.category) IN (?, ?)")
            params += [wanted, CAT_NONE]
        if dance_types is not None:
            # compared in Python: SQLite LOWER() does not fold Latvian letters
            allowed = [t for (t,) in db.q("SELECT DISTINCT type FROM costume_pieces")
                       if (t or "").strip().lower() in dance_types]
            sql += (" AND type IN " + in_clause(allowed)) if allowed else " AND 0"
            params += allowed
        if type_choice != ALL:
            sql += " AND type = ? COLLATE NOCASE"
            params.append(type_choice)
        term = self.search_var.get().strip()
        if term:
            sql += " AND (inv_no LIKE ? OR name LIKE ? OR type LIKE ? OR set_name LIKE ?)"
            params += [f"%{term}%"] * 4
        sql += " ORDER BY inv_no"
        rows = db.q(sql, params)
        # the piece the dancer had last time comes first
        rows.sort(key=lambda r: 0 if r[0] == last_piece else 1)
        for i, r in enumerate(rows):
            cond = r[5] or ""
            tag = "last" if r[0] == last_piece else ("fix" if cond == "Jālabo" else
                                                     "broken" if cond == "Nelietojams" else "")
            inv = ("★ " + r[1]) if r[0] == last_piece else r[1]
            self.left.insert("", "end", iid=str(r[0]), values=(inv, r[2], r[3], r[4], cond, "＋ Izvēlēties"),
                             tags=row_tags(i, tag))
        self.avail_head.subtitle.configure(text=f"{len(rows)}")

        for i, pid in enumerate(self.selected):
            r = db.q("SELECT inv_no, name, type, set_name FROM costume_pieces WHERE id=?", (pid,))
            if not r:
                continue
            r = r[0]
            is_new = pid not in self.original
            state = "jauns" if is_new else f"kopš {show_date(self.original_dates.get(pid, ''))}"
            self.right.insert("", "end", iid=str(pid), values=tuple(r) + (state, "✕ Noņemt"),
                              tags=row_tags(i, "new" if is_new else "existing"))
        self.mine_head.subtitle.configure(text=f"{len(self.selected)}")
        self.update_needs(pieces)
        self.update_summary(pieces)
        self.update_steps()

    # -- moving pieces ----------------------------------------------------
    def _debounced(self):
        now = time.monotonic()
        if now - self._last_move < 0.4:
            return False
        self._last_move = now
        return True

    def arrow_click(self, tree, event, arrow_col, adding):
        # a click on the "＋ Izvēlēties" / "✕ Noņemt" cell of a row moves that piece to the other list
        if tree.identify_region(event.x, event.y) != "cell" or tree.identify_column(event.x) != arrow_col:
            return
        iid = tree.identify_row(event.y)
        if iid and iid.isdigit() and self._debounced():
            self.move_piece(int(iid), adding)

    def double_click(self, tree, event, adding):
        iid = tree.identify_row(event.y)
        if iid and iid.isdigit() and self._debounced():
            self.move_piece(int(iid), adding)

    def move_piece(self, pid, adding):
        if self.dancer_id is None:
            return
        if adding and pid not in self.selected:
            self.selected.append(pid)
        elif not adding and pid in self.selected:
            if pid in self.original and not messagebox.askyesno(
                    "Atgriezt noliktavā?", "Šis tērps dejotājam jau ir izsniegts. Noņemot to, pēc saglabāšanas tas "
                    "tiks atgriezts noliktavā. Turpināt?", parent=self):
                return
            self.selected.remove(pid)
        self.refresh_lists()

    # -- save -------------------------------------------------------------
    def save(self):
        if self.dancer_id is None:
            messagebox.showwarning("Dejotājs", "Vispirms izvēlieties dejotāju.", parent=self)
            return
        if not may_issue(self.app.db, self.dancer_id):
            acc = piekluve.current()
            return piekluve.deny(self, "Jūsu loma nevar izsniegt tērpus" + (
                "." if acc.view_only("terpu_purs") else " šim dejotājam — tikai " +
                acc.scope_text("terpu_purs") + "s dejotājiem."))
        if self.dancer_var.get() != self.current_label:  # a name typed but not confirmed
            messagebox.showwarning("Dejotājs", "Dejotāja laukā ierakstītais vārds nav apstiprināts. "
                                   "Nospiediet Enter vai izvēlieties dejotāju no saraksta.", parent=self)
            return
        when = to_iso(self.date_var.get())
        if when is None:
            messagebox.showwarning("Datums", "Datumam jābūt formātā DD.MM.GGGG, piemēram, "
                                   + today_text() + ".", parent=self)
            return
        db = self.app.db
        new_ids = [p for p in self.selected if p not in self.original]
        removed = [c for p, c in self.original.items() if p not in self.selected]
        if not new_ids and not removed:
            messagebox.showinfo("Izmaiņu nav", "Nav nekā, ko saglabāt.", parent=self)
            return
        for pid in new_ids:  # make sure nobody else got the piece meanwhile
            status = db.q("SELECT " + STATUS_EXPR.format(p="?"), (pid,))[0][0]
            if status != AVAILABLE:
                messagebox.showwarning("Nav pieejams", "Kāds no tērpiem jau ir izsniegts citam dejotājam.", parent=self)
                self.refresh()
                return
        for cid in removed:  # taken out of the dancer's selection -> back to storage
            db.x("UPDATE checkouts SET return_date=? WHERE id=?", (when, cid))
        for pid in new_ids:
            db.x("INSERT INTO checkouts (piece_id, dancer_id, checkout_date, return_date, notes) "
                 "VALUES (?,?,?,?,?)", (pid, self.dancer_id, when, "", self.notes_var.get().strip()))
        self.notes_var.set("")
        self.app.refresh_all()
        self.reload()
        n = len(new_ids)
        messagebox.showinfo("Izsniegts", (f"Izsniegti {n} {pieces_word(n)}." if n else "Izmaiņas saglabātas.")
                            .replace("Izsniegti 1 tērpu", "Izsniegts 1 tērps")
                            .replace("tērpus.", "tērpi."), parent=self)
        return True


# --------------------------------------------------------------------------
# Atgriezt
# --------------------------------------------------------------------------
class ReturnWindow(tk.Frame):
    """Atgriezt: on the left the dancers who have costumes, on the right that dancer's pieces —
    tick the ones brought back and return them to storage."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        L = app.L
        self.dancer_map = {}          # label -> dancer id
        self.dancer_info = {}         # dancer id -> (label, group, count, oldest date)
        self.checked = set()
        self.rows = []
        self.dancer_var = tk.StringVar()
        self.date_var = tk.StringVar(value=today_text())
        self.search_var = tk.StringVar()

        bar = bottom_bar(self)
        self.summary_var = tk.StringVar()
        tk.Label(bar, textvariable=self.summary_var, bg=WHITE, fg=NAVY, font=FONT, anchor="w").pack(
            side="left", fill="x", expand=True)
        self.ret_btn = ttk.Button(bar, text="Atgriezt", style="Accent.TButton", command=self.do_return)
        self.ret_btn.pack(side="right")
        acc = piekluve.current()
        self.view_only = acc.view_only("terpu_purs")
        if self.view_only:
            rights_note(bar, "tikai skatīšanai", bg=WHITE)
        elif not acc.edits_all("terpu_purs"):
            rights_note(bar, "tikai no " + acc.scope_text("terpu_purs") + "s dejotājiem", bg=WHITE)
        date_picker_button(bar, self.date_var, bg=WHITE).pack(side="right", padx=(2, 14))
        ttk.Entry(bar, textvariable=self.date_var, width=11).pack(side="right")
        small_label(bar, "ATGRIEŠANAS DATUMS").pack(side="right", padx=(14, 4))

        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=(14, 0))
        body.columnconfigure(0, weight=2, uniform="r")
        body.columnconfigure(1, weight=3, uniform="r")
        body.rowconfigure(0, weight=1)

        lo, self.left_head, lb = izskats.panel(body, "Dejotāji ar tērpiem", subtitle="")
        lo.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        izskats.search_box(self.left_head.right, self.search_var, width=12).pack()
        self.search_var.trace_add("write", lambda *a: self.fill_dancers())
        izskats.note(lo, f"Sarkanā — kāds tērps izsniegts ilgāk par {OVERDUE_DAYS} dienām.", bg=WHITE
                     ).pack(side="bottom", fill="x", padx=14, pady=6)
        holder = tk.Frame(lb, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.dtree = ttk.Treeview(holder, columns=("name", "group", "n", "since"), show="headings",
                                  selectmode="browse")
        for c, t, w, a in (("name", L("checkouts.dancer"), 170, "w"), ("group", "Grupa", 70, "w"),
                           ("n", "Tērpi", 50, "center"), ("since", "Kopš", 90, "w")):
            self.dtree.heading(c, text=t)
            self.dtree.column(c, width=w, anchor=a, stretch=c == "name")
        make_tree_with_scroll(holder, self.dtree)
        zebra(self.dtree)
        self.dtree.tag_configure("old", foreground=RED)
        self.dtree.bind("<<TreeviewSelect>>", self.on_pick)

        ro, self.right_head, rb = izskats.panel(body, "Izvēlieties dejotāju", subtitle="")
        ro.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        ttk.Button(self.right_head.right, text="Noņemt atzīmes", command=lambda: self.mark_all(False)
                   ).pack(side="right")
        ttk.Button(self.right_head.right, text="Atzīmēt visus", command=lambda: self.mark_all(True)
                   ).pack(side="right", padx=(0, 6))
        izskats.note(ro, "Klikšķis uz rindas atzīmē tērpu, ko atnes atpakaļ.", bg=WHITE
                     ).pack(side="bottom", fill="x", padx=14, pady=6)
        holder = tk.Frame(rb, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = ("chk", "piece", "type", "set_name", "checkout_date", "days")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings")
        heads = {"chk": "✓", "piece": L("checkouts.piece"), "type": L("pieces.type"),
                 "set_name": L("pieces.set_name"), "checkout_date": "Izsniegts", "days": "Dienas"}
        for c, w in (("chk", 40), ("piece", 230), ("type", 110), ("set_name", 110), ("checkout_date", 95),
                     ("days", 60)):
            self.tree.heading(c, text=heads[c])
            self.tree.column(c, width=w, anchor="center" if c in ("chk", "days") else "w",
                             stretch=c not in ("chk", "days"))
        make_tree_with_scroll(holder, self.tree)
        zebra(self.tree)
        self.tree.tag_configure("old", foreground=RED)
        self.tree.tag_configure("checked", background=SELECTED, font=FONT_BOLD)
        self.tree.bind("<ButtonRelease-1>", self.on_click)
        self.refresh()

    def current_dancer_id(self):
        return self.dancer_map.get(self.dancer_var.get())

    def refresh(self):
        db = self.app.db
        group_col = "d.dancer_group" if "dancer_group" in {r[1] for r in db.q("PRAGMA table_info(dancers)")} \
            else "''"
        rows = db.q(
            "SELECT d.id, d.name, d.gender, " + group_col + ", COUNT(*), MIN(c.checkout_date) FROM dancers d "
            "JOIN checkouts c ON c.dancer_id = d.id AND TRIM(COALESCE(c.return_date,'')) = '' "
            "GROUP BY d.id, d.name, d.gender, " + group_col + " ORDER BY d.name")
        self.dancer_map = dancer_labels([(r[0], r[1], r[2]) for r in rows])
        labels = {did: label for label, did in self.dancer_map.items()}
        self.dancer_info = {r[0]: (labels[r[0]], r[3] or "", r[4], r[5] or "") for r in rows}
        if self.dancer_var.get() not in self.dancer_map:
            self.dancer_var.set("")
        self.fill_dancers()
        self.load_rows()

    def fill_dancers(self):
        tree = self.dtree
        tree.delete(*tree.get_children())
        key = _norm(self.search_var.get())
        n = 0
        for did, (label, group, count, since) in sorted(self.dancer_info.items(), key=lambda t: _norm(t[1][0])):
            if key and key not in _norm(label + " " + group):
                continue
            days = days_since(since)
            tree.insert("", "end", iid=str(did), values=(label, group, count, show_date(since)),
                        tags=row_tags(n, "old" if days is not None and days > OVERDUE_DAYS else ""))
            n += 1
        self.left_head.subtitle.configure(text=f"{len(self.dancer_info)}")
        did = self.current_dancer_id()
        if did is not None and tree.exists(str(did)):
            tree.selection_set(str(did))
            tree.see(str(did))

    def on_pick(self, event=None):
        sel = self.dtree.selection()
        if not sel:
            return
        did = int(sel[0])
        label = self.dancer_info.get(did, ("",))[0]
        if label == self.dancer_var.get():
            return
        if self.checked and not messagebox.askyesno(
                "Nesaglabātas izmaiņas", "Atzīmētie tērpi nav atgriezti. Vai atmest atzīmes?", parent=self):
            cur = self.current_dancer_id()
            if cur is not None and self.dtree.exists(str(cur)):
                self.dtree.selection_set(str(cur))
            return
        self.dancer_var.set(label)
        self.on_dancer()

    def select_dancer(self, dancer_id):
        """Open this dancer's pieces (e.g. from the list of issued costumes)."""
        info = self.dancer_info.get(dancer_id)
        if info is None:
            return
        self.dancer_var.set(info[0])
        self.search_var.set("")
        self.on_dancer()
        self.fill_dancers()

    def on_dancer(self):
        self.checked = set()
        self.load_rows()

    def load_rows(self):
        self.tree.delete(*self.tree.get_children())
        did = self.current_dancer_id()
        if did is None:
            self.checked = set()
            self.rows = []
            self.right_head.title.configure(text="Izvēlieties dejotāju")
            self.right_head.subtitle.configure(text="")
            self.update_summary()
            return
        rows = self.app.db.q(
            "SELECT c.id, p.inv_no || ' — ' || p.name, p.type, p.set_name, c.checkout_date "
            "FROM checkouts c JOIN costume_pieces p ON p.id = c.piece_id "
            "WHERE c.dancer_id=? AND TRIM(COALESCE(c.return_date,''))='' ORDER BY p.inv_no", (did,))
        self.rows = rows
        self.checked &= {r[0] for r in rows}
        for i, r in enumerate(rows):
            self.insert_row(i, r)
        self.right_head.title.configure(text=self.dancer_var.get())
        self.right_head.subtitle.configure(text=f"{len(rows)} izsniegti")
        self.update_summary()

    def insert_row(self, i, r):
        days = days_since(r[4])
        on = r[0] in self.checked
        values = ("☑" if on else "☐",) + tuple(r[1:4]) + (show_date(r[4]), "" if days is None else days)
        tags = row_tags(i, "checked" if on else "", "old" if days is not None and days > OVERDUE_DAYS else "")
        if self.tree.exists(str(r[0])):
            self.tree.item(str(r[0]), values=values, tags=tags)
        else:
            self.tree.insert("", "end", iid=str(r[0]), values=values, tags=tags)

    def on_click(self, event):
        if self.tree.identify_region(event.x, event.y) != "cell":
            return
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        cid = int(iid)
        if cid in self.checked:
            self.checked.discard(cid)
        else:
            self.checked.add(cid)
        for i, r in enumerate(self.rows):
            if r[0] == cid:
                self.insert_row(i, r)
        self.update_summary()

    def mark_all(self, state):
        self.checked = {r[0] for r in self.rows} if state else set()
        for i, r in enumerate(self.rows):
            self.insert_row(i, r)
        self.update_summary()

    def update_summary(self):
        n = len(self.checked)
        if self.current_dancer_id() is None:
            text = "Izvēlieties dejotāju sarakstā kreisajā pusē."
        elif not n:
            text = "Atzīmējiet tērpus, kurus dejotājs atnesa atpakaļ."
        else:
            text = f"Atzīmēti: {n} no {len(self.rows)}"
        self.summary_var.set(text)
        self.ret_btn.configure(text=f"Atgriezt {n} {pieces_word(n)}" if n else "Atgriezt",
                               state="normal" if n and not self.view_only else "disabled")

    def do_return(self):
        if not self.checked:
            messagebox.showinfo("Izvēle", "Atzīmējiet vismaz vienu tērpu.", parent=self)
            return
        owners = {r[0] for r in self.app.db.q("SELECT DISTINCT dancer_id FROM checkouts WHERE id IN (" +
                                              ",".join("?" * len(self.checked)) + ")", list(self.checked))}
        if not all(may_issue(self.app.db, d) for d in owners):
            acc = piekluve.current()
            return piekluve.deny(self, "Jūsu loma nevar pieņemt atpakaļ šos tērpus" + (
                "." if acc.view_only("terpu_purs") else " — tikai no " + acc.scope_text("terpu_purs") +
                "s dejotājiem."))
        when = to_iso(self.date_var.get())
        if when is None:
            messagebox.showwarning("Datums", "Datumam jābūt formātā DD.MM.GGGG, piemēram, "
                                   + today_text() + ".", parent=self)
            return
        for cid in self.checked:
            self.app.db.x("UPDATE checkouts SET return_date=? WHERE id=?", (when, cid))
        n = len(self.checked)
        self.checked = set()
        self.app.refresh_all()
        messagebox.showinfo("Atgriezts", f"Atgriezti noliktavā: {n}.", parent=self)
        return True

    def dirty(self):
        return bool(self.checked)


# --------------------------------------------------------------------------
# Noliktava (catalogue)
# --------------------------------------------------------------------------
class CatalogWindow(tk.Frame):
    """Noliktava = tērpu katalogs: filters, the table and a panel with the chosen piece."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        L = app.L
        self.editable = catalog_editable()
        self.search = tk.StringVar()
        self.filters = {k: tk.StringVar(value=ALL) for k in ("category", "type", "set_name", "status", "condition")}
        self.group = tk.StringVar(value="Nav")
        self._photo = None

        # -- filters ------------------------------------------------------------------
        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=20, pady=(14, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        sb = izskats.search_box(bar, self.search, width=20)
        sb.grid(row=1, column=0, sticky="w", padx=(0, 14))
        small_label(bar, "MEKLĒT").grid(row=0, column=0, sticky="w")
        self.search.trace_add("write", lambda *a: self.refresh())
        self.combos = {}
        for i, (key, title, width) in enumerate([("category", L("pieces.category"), 14), ("type", L("pieces.type"), 14),
                                                 ("set_name", L("pieces.set_name"), 14),
                                                 ("status", L("pieces.status"), 11),
                                                 ("condition", L("pieces.condition_notes"), 11)]):
            small_label(bar, title.upper()).grid(row=0, column=1 + i, sticky="w")
            cb = ttk.Combobox(bar, textvariable=self.filters[key], state="readonly", width=width)
            cb.grid(row=1, column=1 + i, sticky="w", padx=(0, 10))
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
            self.combos[key] = cb
        self.combos["category"]["values"] = [ALL] + CATEGORIES
        self.combos["status"]["values"] = [ALL, AVAILABLE, CHECKED_OUT]
        self.combos["condition"]["values"] = [ALL] + CONDITIONS
        small_label(bar, "GRUPĒT").grid(row=0, column=6, sticky="w")
        gb = ttk.Combobox(bar, textvariable=self.group, state="readonly", width=11,
                          values=["Nav", "Komplekts", "Veids", "Kategorija"])
        gb.grid(row=1, column=6, sticky="w", padx=(0, 10))
        gb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        link(bar, "Notīrīt filtrus", self.clear_filters).grid(row=1, column=7, sticky="w")

        # -- actions ------------------------------------------------------------------
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x", padx=20, pady=(10, 0))
        if self.editable:
            ttk.Button(btns, text="＋ Jauns tērps", style="Accent.TButton", command=lambda: PieceForm(app)
                       ).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="Rediģēt" if self.editable else "Atvērt", command=self.edit_piece).pack(side="left")
        if self.editable:
            ttk.Button(btns, text="Dzēst", style="Danger.TButton", command=self.delete_piece).pack(side="left", padx=6)
        else:
            rights_note(btns, "tikai skatīšanai", bg=CREAM)
        self.count_var = tk.StringVar()
        tk.Label(btns, textvariable=self.count_var, bg=CREAM, fg=MUTED, font=FONT_SMALL).pack(side="left", padx=10)
        ttk.Button(btns, text="⚙ Veidi un komplekti", command=lambda: app.open_window(CatalogAdminWindow)
                   ).pack(side="right")
        if self.editable:
            ttk.Button(btns, text="⇪ Importēt no Excel", command=lambda: run_import(app, self, "pieces")
                       ).pack(side="right", padx=6)

        # -- table + piece panel -------------------------------------------------------------
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=(10, 14))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=0, minsize=290)
        body.rowconfigure(0, weight=1)
        table_outer = tk.Frame(body, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        table_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        holder = tk.Frame(table_outer, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = ("inv_no", "name", "category", "type", "set_name", "photos", "condition_notes", "status")
        self.tree = ttk.Treeview(holder, columns=cols, show="tree headings")
        widths = {"inv_no": 110, "name": 190, "category": 115, "type": 110, "set_name": 115,
                  "photos": 60, "condition_notes": 95, "status": 100}
        self.tree.heading("#0", text="")
        self.tree.column("#0", width=26, stretch=False)
        for c in cols:
            self.tree.heading(c, text=L("pieces." + c))
            self.tree.column(c, width=widths[c], anchor="w")
        self.tree["displaycolumns"] = [c for c in cols if c != "name"]  # "Nosaukums" is not shown
        zebra(self.tree)
        self.tree.tag_configure("out", foreground=RED)
        self.tree.tag_configure("fix", foreground=WARN_FG)
        self.tree.tag_configure("broken", foreground=DISABLED_FG)
        self.tree.tag_configure("group", background=CREAM_DARK, font=FONT_BOLD)
        self.tree.bind("<Double-1>", lambda e: self.edit_piece())
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_piece())
        make_tree_with_scroll(holder, self.tree)

        self.side_outer, self.side_head, self.side = izskats.panel(body, "Tērps")
        self.side_outer.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        self.refresh()

    def clear_filters(self):
        self.search.set("")
        for v in self.filters.values():
            v.set(ALL)
        self.group.set("Nav")
        self.refresh()

    def refresh(self):
        db = self.app.db
        for key in ("type", "set_name"):
            vals = [ALL] + db.distinct(key)
            self.combos[key]["values"] = vals
            if self.filters[key].get() not in vals:
                self.filters[key].set(ALL)

        sql = ("SELECT id, inv_no, name, category, type, set_name, condition_notes, status_f, "
               "(SELECT COUNT(*) FROM photos WHERE piece_id = pp.id) FROM "
               "(SELECT p.*, " + STATUS_EXPR.format(p="p.id") + " AS status_f FROM costume_pieces p) pp WHERE 1=1")
        params = []
        term = self.search.get().strip()
        if term:
            sql += (" AND (inv_no LIKE ? OR name LIKE ? OR category LIKE ? OR type LIKE ? "
                    "OR set_name LIKE ? OR condition_notes LIKE ?)")
            params += [f"%{term}%"] * 6
        for key in ("category", "type", "set_name"):
            if self.filters[key].get() != ALL:
                sql += f" AND {key} = ?"
                params.append(self.filters[key].get())
        if self.filters["status"].get() != ALL:
            sql += " AND status_f = ?"
            params.append(self.filters["status"].get())
        if self.filters["condition"].get() != ALL:
            sql += " AND condition_notes = ?"
            params.append(self.filters["condition"].get())

        group_col = {"Komplekts": "set_name", "Veids": "type", "Kategorija": "category"}.get(self.group.get())
        sql += f" ORDER BY {group_col + ', ' if group_col else ''}inv_no"
        rows = db.q(sql, params)

        tree = self.tree
        keep = tree.selection()
        tree.delete(*tree.get_children())
        group_nodes = {}
        idx = {"set_name": 5, "type": 4, "category": 3}
        counter = {}
        for r in rows:
            parent = ""
            if group_col:
                g = r[idx[group_col]] or "(nav norādīts)"
                if g not in group_nodes:
                    group_nodes[g] = tree.insert("", "end", iid=f"g:{g}", text="▾", open=True,
                                                 values=(g, "", "", "", "", "", "", ""), tags=("group",))
                parent = group_nodes[g]
            n = counter.get(parent, 0)
            counter[parent] = n + 1
            tag = "out" if r[7] == CHECKED_OUT else ("fix" if r[6] == "Jālabo" else
                                                     "broken" if r[6] == "Nelietojams" else "")
            tree.insert(parent, "end", iid=str(r[0]), values=(
                r[1], r[2], r[3], r[4], r[5], f"{r[8]} foto" if r[8] else "—", r[6], "● " + r[7]),
                tags=row_tags(n, tag))
        for g, node in group_nodes.items():  # the group row shows its name and how many pieces it has
            tree.set(node, "inv_no", f"{g}  ({len(tree.get_children(node))})")
        total = db.q("SELECT COUNT(*) FROM costume_pieces")[0][0]
        out = sum(1 for r in rows if r[7] == CHECKED_OUT)
        self.count_var.set(f"Rādīti {len(rows)} no {total} · noliktavā {len(rows) - out} · izsniegti {out}")
        keep = [k for k in keep if tree.exists(k)]
        if keep:
            tree.selection_set(keep)
        self.show_piece()

    def show_piece(self):
        """Right panel: the chosen piece — status, condition, who has it, photo and recent history."""
        box = self.side
        for w in box.winfo_children():
            w.destroy()
        self._photo = None
        sel = self.tree.selection()
        pid = int(sel[0]) if sel and not sel[0].startswith("g:") else None
        if pid is None:
            self.side_head.title.configure(text="Tērps")
            izskats.note(box, "Izvēlieties tērpu sarakstā — šeit būs redzams tā stāvoklis, kam tas izsniegts, "
                              "foto un izsniegumu vēsture.\n\nDubultklikšķis atver tērpa anketu.",
                         bg=WHITE, wrap=250).pack(fill="x", padx=14, pady=12)
            return
        db = self.app.db
        row = db.q("SELECT inv_no, name, category, type, set_name, condition_notes, " + STATUS_EXPR.format(p="id")
                   + " FROM costume_pieces WHERE id=?", (pid,))
        if not row:
            return
        inv, name, cat, typ, set_name, cond, status = row[0]
        self.side_head.title.configure(text=inv)
        top = tk.Frame(box, bg=WHITE)
        top.pack(fill="x", padx=14, pady=(10, 4))
        tk.Label(top, text=name, bg=WHITE, fg=NAVY, font=FONT_BOLD, anchor="w", justify="left",
                 wraplength=250).pack(fill="x")
        chips = tk.Frame(top, bg=WHITE)
        chips.pack(fill="x", pady=(4, 0))
        out = status == CHECKED_OUT
        izskats.chip(chips, status, *((BAD_BG, BAD_FG) if out else (OK_BG, OK_FG))).pack(side="left")
        condition_chip(chips, cond).pack(side="left", padx=6)
        facts = tk.Frame(box, bg=WHITE)
        facts.pack(fill="x", padx=14, pady=(6, 0))
        facts.columnconfigure(1, weight=1)
        for i, (k, v) in enumerate(((self.app.L("pieces.category"), cat), (self.app.L("pieces.type"), typ),
                                    (self.app.L("pieces.set_name"), set_name))):
            tk.Label(facts, text=k, bg=WHITE, fg=MUTED, font=FONT_SMALL).grid(row=i, column=0, sticky="w", pady=1)
            tk.Label(facts, text=v or "—", bg=WHITE, fg=NAVY, font=FONT_SMALL).grid(row=i, column=1, sticky="w",
                                                                                   padx=(10, 0))
        if out:
            who = db.q("SELECT d.name, c.checkout_date FROM checkouts c JOIN dancers d ON d.id = c.dancer_id "
                       "WHERE c.piece_id=? AND TRIM(COALESCE(c.return_date,''))='' ORDER BY c.id DESC LIMIT 1", (pid,))
            if who:
                days = days_since(who[0][1])
                warn = tk.Frame(box, bg=BAD_BG)
                warn.pack(fill="x", padx=14, pady=(8, 0))
                tk.Label(warn, text=f"Pie: {who[0][0]}", bg=BAD_BG, fg=RED, font=FONT_BOLD, anchor="w").pack(
                    fill="x", padx=8, pady=(4, 0))
                tk.Label(warn, text=f"kopš {show_date(who[0][1])}" + (f" · {days} dienas" if days is not None else ""),
                         bg=BAD_BG, fg=RED, font=FONT_SMALL, anchor="w").pack(fill="x", padx=8, pady=(0, 4))
        photos = [p[0] for p in db.q("SELECT filename FROM photos WHERE piece_id=?", (pid,))]
        if photos:
            path = os.path.join(PHOTO_DIR, photos[0])
            try:
                self._photo = self.app.load_image(path, 250, 170)
                lbl = tk.Label(box, image=self._photo, bg=WHITE, cursor="hand2")
                lbl.pack(padx=14, pady=(10, 0))
                lbl.bind("<Button-1>", lambda e: open_external(path))
            except Exception:
                link(box, f"Atvērt foto ({len(photos)})", lambda: open_external(path)).pack(anchor="w", padx=14,
                                                                                            pady=(10, 0))
        hist = db.q("SELECT d.name, c.checkout_date, c.return_date FROM checkouts c JOIN dancers d ON d.id = c.dancer_id "
                    "WHERE c.piece_id=? ORDER BY c.checkout_date DESC, c.id DESC LIMIT 5", (pid,))
        tk.Frame(box, bg=LINE_SOFT, height=1).pack(fill="x", pady=(12, 0))
        small_label(box, "PĒDĒJIE IZSNIEGUMI").pack(anchor="w", padx=14, pady=(8, 2))
        if not hist:
            izskats.note(box, "Vēl nav izsniegts.", bg=WHITE).pack(anchor="w", padx=14)
        for nm, out_d, back in hist:
            line = tk.Frame(box, bg=WHITE)
            line.pack(fill="x", padx=14, pady=1)
            tk.Label(line, text=nm, bg=WHITE, fg=NAVY, font=FONT_SMALL).pack(side="left")
            back = (back or "").strip()
            tk.Label(line, text=f"{show_date(out_d)[:6]}–{show_date(back)[:6] if back else '…'}", bg=WHITE,
                     fg=MUTED if back else RED, font=FONT_SMALL).pack(side="right")
        acts = tk.Frame(box, bg=WHITE)
        acts.pack(fill="x", padx=14, pady=12, side="bottom")
        ttk.Button(acts, text="Rediģēt" if self.editable else "Atvērt anketu", command=self.edit_piece
                   ).pack(side="left")

    def selected_piece(self):
        sel = self.tree.selection()
        if not sel or sel[0].startswith("g:"):
            messagebox.showinfo("Izvēle", "Izvēlieties tērpu sarakstā.", parent=self)
            return None
        return int(sel[0])

    def edit_piece(self):
        pid = self.selected_piece()
        if pid:
            PieceForm(self.app, pid)

    def delete_piece(self):
        if not catalog_editable():
            return piekluve.deny(self, "Tērpus dzēst var tērpu pārzinis vai kolektīva vadība.")
        pid = self.selected_piece()
        if pid and messagebox.askyesno("Dzēst", "Dzēst izvēlēto tērpu un tā izsniegumu vēsturi?", parent=self):
            self.app.db.x("DELETE FROM costume_pieces WHERE id=?", (pid,))
            self.app.refresh_all()


VIEW_ALL = "Visi tērpi"


# --------------------------------------------------------------------------
# Izsniegtie (list of checkouts — a tab now, formerly a separate window)
# --------------------------------------------------------------------------
class CheckoutsView(tk.Frame):
    """Izsniegtie: all checkouts (active / returned / all), filterable; double-click — open in “Atgriezt”."""

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        L = app.L
        self.mode = tk.StringVar(value="active")
        self.search = tk.StringVar()
        self.f_category = tk.StringVar(value=ALL)
        self.f_type = tk.StringVar(value=ALL)
        self.overdue = tk.BooleanVar(value=False)

        bar_outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        bar_outer.pack(fill="x", padx=20, pady=(14, 0))
        bar = tk.Frame(bar_outer, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        izskats.Segmented(bar, [("active", "Izsniegtie"), ("returned", "Atgrieztie"), ("all", "Visi")],
                          self.mode, command=self.refresh).pack(side="left")
        small_label(bar, L("pieces.category").upper()).pack(side="left", padx=(18, 4))
        ccb = ttk.Combobox(bar, textvariable=self.f_category, values=[ALL] + CATEGORIES, state="readonly", width=14)
        ccb.pack(side="left")
        small_label(bar, L("pieces.type").upper()).pack(side="left", padx=(14, 4))
        self.type_cb = ttk.Combobox(bar, textvariable=self.f_type, state="readonly", width=14)
        self.type_cb.pack(side="left")
        for cb in (ccb, self.type_cb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        tk.Checkbutton(bar, text=f"Ilgāk par {OVERDUE_DAYS} dienām", variable=self.overdue, command=self.refresh,
                       bg=WHITE, fg=NAVY, activebackground=WHITE, selectcolor=WHITE, font=FONT
                       ).pack(side="left", padx=(14, 0))
        izskats.search_box(bar, self.search, width=16).pack(side="right")
        self.search.trace_add("write", lambda *a: self.refresh())

        info = tk.Frame(self, bg=CREAM)
        info.pack(fill="x", padx=20, pady=(8, 0))
        self.count_var = tk.StringVar()
        tk.Label(info, textvariable=self.count_var, bg=CREAM, fg=NAVY, font=FONT_BOLD).pack(side="left")
        izskats.note(info, "Dubultklikšķis uz izsniegta tērpa — atvērt dejotāja tērpus cilnē “Atgriezt”.").pack(
            side="right")

        outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=(6, 14))
        holder = tk.Frame(outer, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = ("piece", "category", "type", "dancer", "checkout_date", "return_date", "days", "state", "notes")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="browse")
        widths = {"piece": 210, "category": 105, "type": 100, "dancer": 150, "checkout_date": 95,
                  "return_date": 95, "days": 55, "state": 90, "notes": 160}
        heads = {"category": L("pieces.category"), "type": L("pieces.type"), "checkout_date": "Izsniegts",
                 "return_date": "Atgriezts", "days": "Dienas"}
        for c in cols:
            self.tree.heading(c, text=heads.get(c) or L("checkouts." + c))
            self.tree.column(c, width=widths[c], anchor="center" if c == "days" else "w")
        zebra(self.tree)
        self.tree.tag_configure("old", foreground=RED)
        self.tree.tag_configure("returned", foreground=MUTED)
        self.tree.bind("<Double-1>", self.open_dancer)
        make_tree_with_scroll(holder, self.tree)
        self.dancers = {}
        self.refresh()

    def refresh(self):
        db = self.app.db
        types = [ALL] + db.type_names()
        self.type_cb["values"] = types
        if self.f_type.get() not in types:
            self.f_type.set(ALL)
        sql = ("SELECT co.id, p.inv_no || ' — ' || p.name, p.category, p.type, d.name, co.checkout_date, "
               "co.return_date, co.notes, d.id FROM checkouts co JOIN costume_pieces p ON p.id = co.piece_id "
               "JOIN dancers d ON d.id = co.dancer_id WHERE 1=1")
        params = []
        mode = self.mode.get()
        if mode == "active" or self.overdue.get():
            sql += " AND (co.return_date IS NULL OR TRIM(co.return_date) = '')"
        elif mode == "returned":
            sql += " AND TRIM(COALESCE(co.return_date,'')) <> ''"
        if self.f_category.get() != ALL:
            sql += " AND p.category = ?"
            params.append(self.f_category.get())
        if self.f_type.get() != ALL:
            sql += " AND p.type = ? COLLATE NOCASE"
            params.append(self.f_type.get())
        term = self.search.get().strip()
        if term:
            sql += " AND (p.name LIKE ? OR p.inv_no LIKE ? OR d.name LIKE ? OR co.notes LIKE ?)"
            params += [f"%{term}%"] * 4
        sql += " ORDER BY co.checkout_date DESC, co.id DESC"
        self.tree.delete(*self.tree.get_children())
        self.dancers = {}
        n = 0
        for r in db.q(sql, params):
            returned = bool((r[6] or "").strip())
            days = days_since(r[5]) if not returned else None
            old = days is not None and days > OVERDUE_DAYS
            if self.overdue.get() and not old:
                continue
            self.tree.insert("", "end", iid=str(r[0]), values=(
                r[1], r[2], r[3], r[4], show_date(r[5]), show_date(r[6]) or "—", "" if days is None else days,
                AVAILABLE if returned else CHECKED_OUT, r[7]),
                tags=row_tags(n, "returned" if returned else ("old" if old else "")))
            if not returned:
                self.dancers[str(r[0])] = r[8]
            n += 1
        what = {"active": "izsniegti", "returned": "atgriezti", "all": "ieraksti"}[mode] if not self.overdue.get() \
            else f"izsniegti ilgāk par {OVERDUE_DAYS} dienām"
        self.count_var.set(f"{n} {what}")

    def open_dancer(self, event):
        iid = self.tree.identify_row(event.y)
        did = self.dancers.get(iid)
        if did is None:
            return
        view = self.app.open_tab(ReturnWindow)
        if isinstance(view, ReturnWindow):
            view.select_dancer(did)


# --------------------------------------------------------------------------
# Soda naudas (Tērpu pūrs v0.6): tērpu kārtības ruļļa pārkāpumi un nenodotas tērpu detaļas
# --------------------------------------------------------------------------
def _fold(text):
    """Lower case without Latvian diacritics, so “berzins” finds “Bērziņš”."""
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", (text or "").lower()) if unicodedata.category(c) != "Mn")


FINE_STATUS_ALL = "Visi"
FINE_STATUS_FILTERS = [FINE_STATUS_ALL, K.FINE_ACTIVE, K.FINE_EXCUSED, K.FINE_CANCELLED]


def fines_actor():
    """Who is doing it (written into the fine): the logged-in person, else the computer."""
    user = piekluve.current().user
    return (user.name or user.email or "Datora Pūrlāde").strip()


class FinesView(tk.Frame):
    """Soda naudas. Trīs skati:
    • Piedāvātie sodi — tērpa detaļas, kas nav nodotas laikā (programma piedāvā, atbildīgais apstiprina vai atzīmē
      attaisnojošu iemeslu);
    • Uzliktās soda naudas — visi sodi (pārkāpumi, nenodotās detaļas), pārkāpumu var pievienot arī šeit;
    • Noteikumi un summas — tērpu kārtības ruļļa punkti (no tiem lietotnē izvēlas pārkāpumu) un soda summas."""

    MODES = [("fines", "Soda naudas"), ("rules", "Noteikumi un summas")]

    def __init__(self, app, parent):
        super().__init__(parent, bg=CREAM)
        self.app = app
        K.ensure_fines_schema(app.db.con)
        self.mode = tk.StringVar(value="fines")
        self.fine_dancer = {}
        self.chosen_id = None          # dancer chosen in the list (Soda naudas)
        self.top = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        self.top.pack(side="top", fill="x", padx=20, pady=(14, 0))
        bar = tk.Frame(self.top, bg=WHITE)
        bar.pack(fill="x", padx=14, pady=10)
        self.seg = izskats.Segmented(bar, self.MODES, self.mode, command=self.build)
        self.seg.pack(side="left")
        self.count_var = tk.StringVar()
        tk.Label(bar, textvariable=self.count_var, bg=WHITE, fg=NAVY, font=FONT_BOLD).pack(side="right")
        self.body = tk.Frame(self, bg=CREAM)
        self.body.pack(fill="both", expand=True)
        self.build()

    # ---- helpers ---------------------------------------------------------
    def acc(self):
        return piekluve.current()

    def view_only(self):
        return self.acc().view_only("terpu_purs")

    def dancer_group(self, dancer_id):
        rows = self.app.db.q("SELECT dancer_group FROM dancers WHERE id=?", (dancer_id,))
        return rows[0][0] if rows else ""

    def may(self, dancer_id):
        return may_issue(self.app.db, dancer_id)

    def refresh(self):
        self.build()

    def build(self):
        for child in self.body.winfo_children():
            child.destroy()
        mode = self.mode.get()
        {"fines": self.build_fines, "rules": self.build_rules}[mode]()
        self.update_count()

    def update_count(self):
        db = self.app.db
        n = db.q("SELECT COUNT(*), COALESCE(SUM(amount_cents),0) FROM costume_fines WHERE status=?", (K.FINE_ACTIVE,))[0]
        self.count_var.set(f"Uzlikti sodi: {n[0]} · kopā {K.money_text(n[1])}")

    def note_bar(self, text):
        if self.view_only():
            rights_note(self.bar_inner, "tikai skatīšanai", bg=WHITE)
        elif not self.acc().edits_all("terpu_purs"):
            rights_note(self.bar_inner, "tikai " + self.acc().scope_text("terpu_purs") + "s dejotājiem", bg=WHITE)

    def table(self, cols, widths, heads, selectmode="extended"):
        outer = tk.Frame(self.body, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=(8, 14))
        holder = tk.Frame(outer, bg=WHITE)
        holder.pack(fill="both", expand=True)
        tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode=selectmode)
        for c in cols:
            tree.heading(c, text=heads[c])
            tree.column(c, width=widths[c], anchor="e" if c == "amount" else "w", stretch=c in ("description", "piece"))
        zebra(tree)
        make_tree_with_scroll(holder, tree)
        return tree

    # ---- Uzliktās soda naudas -----------------------------------------------
    def build_fines(self):
        """Left: dancers with a search box + “par ko sods” + “Piemērot soda naudu”; right: the fines (of the
        chosen dancer, or of everybody when nobody is chosen)."""
        db = self.app.db
        self.bar_inner = bottom_bar_in(self.body)
        self.fstatus = tk.StringVar(value=FINE_STATUS_ALL)
        self.fsearch = tk.StringVar()
        self.dsearch = tk.StringVar()
        self.reason_var = tk.StringVar()
        self.rule_var = tk.StringVar()
        self.rules = dict((t, i) for i, t in K.fine_rules(db.con))
        self.cancel_btn = ttk.Button(self.bar_inner, text="Atcelt sodu", command=self.cancel_fines)
        self.cancel_btn.pack(side="right")
        self.note_bar("")
        if self.view_only():
            self.cancel_btn.configure(state="disabled")
        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True, padx=20, pady=(8, 14))
        wrap.columnconfigure(0, weight=2, uniform="f")
        wrap.columnconfigure(1, weight=3, uniform="f")
        wrap.rowconfigure(0, weight=1)

        lo, _head, lb = izskats.panel(wrap, "Piemērot soda naudu", subtitle="")
        lo.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        top = tk.Frame(lb, bg=WHITE)
        top.pack(fill="x", padx=14, pady=(10, 4))
        small_label(top, "DEJOTĀJS (RAKSTIET VĀRDU)").pack(anchor="w")
        izskats.search_box(top, self.dsearch, width=30, bg=WHITE).pack(fill="x", pady=(2, 0))
        holder = tk.Frame(lb, bg=WHITE)
        holder.pack(fill="both", expand=True, padx=14)
        self.dancer_tree = ttk.Treeview(holder, columns=("name",), show="headings", selectmode="browse", height=8)
        self.dancer_tree.heading("name", text="Dejotājs")
        self.dancer_tree.column("name", width=260, stretch=True)
        zebra(self.dancer_tree)
        make_tree_with_scroll(holder, self.dancer_tree)
        self.dancer_tree.bind("<<TreeviewSelect>>", lambda e: self.on_dancer())
        self.dsearch.trace_add("write", lambda *a: self.fill_dancers())
        form = tk.Frame(lb, bg=WHITE)
        form.pack(fill="x", padx=14, pady=(8, 12))
        small_label(form, "PAR KO IR ŠIS SODS").pack(anchor="w")
        self.reason_entry = ttk.Entry(form, textvariable=self.reason_var)
        self.reason_entry.pack(fill="x", pady=(2, 8))
        self.reason_entry.bind("<Return>", lambda e: self.apply_fine())
        if self.rules:
            small_label(form, "VAI NOTEIKUMS NO SARAKSTA (NAV OBLIGĀTI)").pack(anchor="w")
            rule_cb = ttk.Combobox(form, textvariable=self.rule_var, values=[""] + list(self.rules),
                                   state="readonly")
            rule_cb.pack(fill="x", pady=(2, 8))
            rule_cb.bind("<<ComboboxSelected>>", self.on_rule)
        self.apply_btn = ttk.Button(form, text=f"Piemērot soda naudu ({K.money_text(K.fine_cents(db.con, K.FINE_RULE))})",
                                    style="Accent.TButton", command=self.apply_fine)
        self.apply_btn.pack(anchor="e")
        if self.view_only():
            self.apply_btn.configure(state="disabled")
        self.fill_dancers()

        ro, _rhead, rb = izskats.panel(wrap, "Uzliktās soda naudas", subtitle="")
        ro.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        filt = tk.Frame(rb, bg=WHITE)
        filt.pack(fill="x", padx=14, pady=(10, 4))
        small_label(filt, "STATUSS").pack(side="left", padx=(0, 4))
        cb = ttk.Combobox(filt, textvariable=self.fstatus, values=FINE_STATUS_FILTERS, state="readonly", width=12)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.fill_fines())
        izskats.search_box(filt, self.fsearch, width=18, bg=WHITE).pack(side="right")
        self.fsearch.trace_add("write", lambda *a: self.fill_fines())
        fh = tk.Frame(rb, bg=WHITE)
        fh.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        cols = ("date", "dancer", "description", "amount", "status", "by")
        heads = {"date": "Datums", "dancer": "Dejotājs", "description": "Par ko", "amount": "Summa",
                 "status": "Statuss", "by": "Pievienoja"}
        widths = {"date": 85, "dancer": 150, "description": 240, "amount": 75, "status": 85, "by": 120}
        self.tree = ttk.Treeview(fh, columns=cols, show="headings", selectmode="extended")
        for c in cols:
            self.tree.heading(c, text=heads[c])
            self.tree.column(c, width=widths[c], anchor="e" if c == "amount" else "w", stretch=c == "description")
        zebra(self.tree)
        make_tree_with_scroll(fh, self.tree)
        self.tree.tag_configure("cancelled", foreground=MUTED)
        self.tree.tag_configure("excused", foreground=MUTED)
        self.fill_fines()

    def fill_dancers(self):
        """Active dancers (the ones this person may fine), narrowed by what is typed in the search box."""
        db = self.app.db
        rows = db.q("SELECT id, name, gender FROM dancers WHERE " + active_dancer_sql("dancers") + " ORDER BY name")
        term = _fold(self.dsearch.get().strip())
        self.dancer_ids = {}
        self.dancer_tree.delete(*self.dancer_tree.get_children())
        for label, did in dancer_labels(rows).items():
            if term and term not in _fold(label):
                continue
            if not self.may(did):
                continue
            iid = str(did)
            self.dancer_ids[iid] = did
            self.dancer_tree.insert("", "end", iid=iid, tags=row_tags(len(self.dancer_ids) - 1), values=(label,))
        kept = self.chosen_id
        if kept is not None and str(kept) in self.dancer_ids:
            self.dancer_tree.selection_set(str(kept))
        elif len(self.dancer_ids) == 1 and term:
            only = next(iter(self.dancer_ids))
            self.dancer_tree.selection_set(only)

    def on_dancer(self):
        sel = self.dancer_tree.selection()
        self.chosen_id = int(sel[0]) if sel else None
        self.fill_fines()

    def on_rule(self, event=None):
        """A rule picked from the list fills the reason when it is still empty."""
        if self.rule_var.get() and not self.reason_var.get().strip():
            self.reason_var.set(self.rule_var.get())

    def apply_fine(self):
        if self.view_only():
            piekluve.deny(self, "Jūsu loma nevar piemērot soda naudu.")
            return
        did = self.chosen_id
        if did is None:
            messagebox.showwarning("Dejotājs", "Sarakstā izvēlieties dejotāju (varat ierakstīt vārdu meklētājā).",
                                   parent=self)
            return
        if not self.may(did):
            piekluve.deny(self, "Šīs grupas dejotājiem sodus nevar piemērot.")
            return
        rule = self.rules.get(self.rule_var.get())
        reason = self.reason_var.get().strip()
        if not reason and rule is None:
            messagebox.showwarning("Par ko sods", "Ierakstiet, par ko ir šis sods.", parent=self)
            self.reason_entry.focus_set()
            return
        try:
            K.add_violation(self.app.db.con, did, rule, "", fines_actor(), reason=reason)
        except ValueError as exc:
            messagebox.showwarning("Soda nauda", str(exc), parent=self)
            return
        self.reason_var.set("")
        self.rule_var.set("")
        self.app.refresh_all()

    def fill_fines(self):
        db = self.app.db
        sql = ("SELECT f.id, f.fine_date, d.name, f.kind, f.description, f.amount_cents, f.status, f.added_by, "
               "f.note, f.dancer_id FROM costume_fines f JOIN dancers d ON d.id = f.dancer_id WHERE 1=1")
        params = []
        chosen = self.chosen_id
        if chosen is not None:
            sql += " AND f.dancer_id = ?"
            params.append(chosen)
        if self.fstatus.get() != FINE_STATUS_ALL:
            sql += " AND f.status = ?"
            params.append(self.fstatus.get())
        term = self.fsearch.get().strip()
        if term:
            sql += " AND (d.name LIKE ? OR f.description LIKE ? OR f.note LIKE ?)"
            params += [f"%{term}%"] * 3
        sql += " ORDER BY f.fine_date DESC, f.id DESC"
        self.tree.delete(*self.tree.get_children())
        self.fine_dancer = {}
        for i, r in enumerate(db.q(sql, params)):
            tag = "cancelled" if r[6] == K.FINE_CANCELLED else "excused" if r[6] == K.FINE_EXCUSED else ""
            self.tree.insert("", "end", iid=str(r[0]), tags=row_tags(i, tag), values=(
                show_date(r[1]), r[2], r[4] + (f" ({r[8]})" if r[8] else ""), K.money_text(r[5]), r[6], r[7]))
            self.fine_dancer[str(r[0])] = r[9]

    def cancel_fines(self):
        ids = [i for i in self.tree.selection()]
        if not ids:
            messagebox.showinfo("Atcelt sodu", "Atzīmējiet sarakstā sodu, ko atcelt.", parent=self)
            return
        for i in ids:
            if not self.may(self.fine_dancer.get(i)):
                piekluve.deny(self, "Šīs grupas dejotājiem sodus nevar mainīt.")
                return
        if not messagebox.askyesno("Atcelt sodu", f"Atcelt {len(ids)} sodus? Ieraksti paliek sarakstā kā “atcelts”.",
                                   parent=self):
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        for i in ids:
            self.app.db.x("UPDATE costume_fines SET status=?, decided_by=?, decided_at=? WHERE id=? AND status<>?",
                          (K.FINE_CANCELLED, fines_actor(), stamp, int(i), K.FINE_CANCELLED))
        self.app.refresh_all()

    # ---- Noteikumi un summas --------------------------------------------------
    def build_rules(self):
        db = self.app.db
        self.editable = catalog_editable()
        wrap = tk.Frame(self.body, bg=CREAM)
        wrap.pack(fill="both", expand=True, padx=20, pady=(8, 14))
        wrap.columnconfigure(0, weight=3, uniform="f")
        wrap.columnconfigure(1, weight=2, uniform="f")
        wrap.rowconfigure(0, weight=1)
        lo, head, lb = izskats.panel(wrap, "Tērpu kārtības ruļļa punkti", subtitle="")
        lo.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        izskats.note(lo, "Šos punktus lietotnē izvēlas, pievienojot pārkāpumu. Izdzēstais punkts vairs nav "
                     "izvēlams, bet jau uzliktie sodi saglabājas.", bg=WHITE).pack(side="bottom", fill="x", padx=14,
                                                                                    pady=6)
        holder = tk.Frame(lb, bg=WHITE)
        holder.pack(fill="both", expand=True)
        self.rule_tree = ttk.Treeview(holder, columns=("title", "n"), show="headings", selectmode="browse")
        self.rule_tree.heading("title", text="Noteikums")
        self.rule_tree.heading("n", text="Sodu skaits")
        self.rule_tree.column("title", width=380, stretch=True)
        self.rule_tree.column("n", width=90, anchor="center", stretch=False)
        zebra(self.rule_tree)
        make_tree_with_scroll(holder, self.rule_tree)
        btns = tk.Frame(head.right, bg=WHITE)
        btns.pack()
        for text, cmd in (("Pievienot…", self.rule_add), ("Labot…", self.rule_edit), ("Uz augšu", lambda: self.rule_move(-1)),
                          ("Uz leju", lambda: self.rule_move(1)), ("Dzēst", self.rule_delete)):
            b = ttk.Button(btns, text=text, command=cmd, state="normal" if self.editable else "disabled")
            b.pack(side="left", padx=(0, 4))
        self.fill_rules()

        ro, rhead, rb = izskats.panel(wrap, "Soda summas", subtitle="")
        ro.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        form = tk.Frame(rb, bg=WHITE)
        form.pack(fill="x", padx=14, pady=10)
        self.rule_cents_var = tk.StringVar(value=K.money_text(K.fine_cents(db.con, K.FINE_RULE)))
        self.late_cents_var = tk.StringVar(value=K.money_text(K.fine_cents(db.con, K.FINE_LATE)))
        for r, (label, var) in enumerate((("Par tērpu kārtības ruļļa pārkāpumu", self.rule_cents_var),
                                          ("Par laikā nenodotu tērpa detaļu", self.late_cents_var))):
            small_label(form, label.upper()).grid(row=2 * r, column=0, sticky="w", pady=(8 if r else 0, 2))
            ttk.Entry(form, textvariable=var, width=12,
                      state="normal" if self.editable else "disabled").grid(row=2 * r + 1, column=0, sticky="w")
        ttk.Button(form, text="Saglabāt summas", style="Accent.TButton", command=self.save_amounts,
                   state="normal" if self.editable else "disabled").grid(row=4, column=0, sticky="w", pady=(14, 0))
        izskats.note(rb, "Summa tiek ierakstīta sodā tā uzlikšanas brīdī — vēlāka maiņa jau uzliktos sodus "
                     "neietekmē.", bg=WHITE, wrap=300).pack(fill="x", padx=14, pady=(0, 8))
        if not self.editable:
            rights_note(rb, "noteikumus un summas maina tērpu pārzinis, vadītājs, repetitors", bg=WHITE)

    def fill_rules(self):
        self.rule_tree.delete(*self.rule_tree.get_children())
        counts = dict(self.app.db.q("SELECT rule_id, COUNT(*) FROM costume_fines WHERE rule_id IS NOT NULL "
                                    "GROUP BY rule_id"))
        for i, (rid, title) in enumerate(K.fine_rules(self.app.db.con)):
            self.rule_tree.insert("", "end", iid=str(rid), tags=row_tags(i), values=(title, counts.get(rid, 0)))

    def rule_selected(self):
        sel = self.rule_tree.selection()
        return int(sel[0]) if sel else None

    def rule_add(self):
        title = simpledialog.askstring("Jauns noteikums", "Tērpu kārtības ruļļa punkts:", parent=self)
        title = (title or "").strip()
        if not title:
            return
        if any(t.lower() == title.lower() for _i, t in K.fine_rules(self.app.db.con)):
            messagebox.showinfo("Jau ir", "Šāds punkts jau ir sarakstā.", parent=self)
            return
        last = self.app.db.q("SELECT COALESCE(MAX(position), 0) FROM costume_rules")[0][0]
        self.app.db.x("INSERT INTO costume_rules (title, position, active) VALUES (?,?,1)", (title[:300], last + 1))
        self.fill_rules()

    def rule_edit(self):
        rid = self.rule_selected()
        if rid is None:
            return
        old = self.rule_tree.item(str(rid), "values")[0]
        title = simpledialog.askstring("Labot noteikumu", "Tērpu kārtības ruļļa punkts:", initialvalue=old, parent=self)
        title = (title or "").strip()
        if not title or title == old:
            return
        self.app.db.x("UPDATE costume_rules SET title=? WHERE id=?", (title[:300], rid))
        self.fill_rules()

    def rule_move(self, step):
        rid = self.rule_selected()
        if rid is None:
            return
        ids = [i for i, _t in K.fine_rules(self.app.db.con)]
        pos = ids.index(rid)
        new = pos + step
        if not 0 <= new < len(ids):
            return
        ids[pos], ids[new] = ids[new], ids[pos]
        for n, i in enumerate(ids, 1):
            self.app.db.con.execute("UPDATE costume_rules SET position=? WHERE id=?", (n, i))
        self.app.db.con.commit()
        self.fill_rules()
        self.rule_tree.selection_set(str(rid))

    def rule_delete(self):
        rid = self.rule_selected()
        if rid is None:
            return
        title = self.rule_tree.item(str(rid), "values")[0]
        if not messagebox.askyesno("Dzēst noteikumu", f"Dzēst punktu “{title}”? Jau uzliktie sodi saglabājas.",
                                   parent=self):
            return
        self.app.db.x("UPDATE costume_rules SET active=0 WHERE id=?", (rid,))
        self.fill_rules()

    def save_amounts(self):
        values = {}
        for kind, var, what in ((K.FINE_RULE, self.rule_cents_var, "pārkāpuma"),
                                (K.FINE_LATE, self.late_cents_var, "nenodotas detaļas")):
            cents = K.parse_money(var.get())
            if cents is None:
                messagebox.showwarning("Summa", f"Ierakstiet {what} soda summu eiro, piemēram, 2 vai 2,50.", parent=self)
                return
            values[kind] = cents
        for kind, cents in values.items():
            K.set_fine_cents(self.app.db.con, kind, cents)
        self.rule_cents_var.set(K.money_text(values[K.FINE_RULE]))
        self.late_cents_var.set(K.money_text(values[K.FINE_LATE]))
        messagebox.showinfo("Saglabāts", "Soda summas saglabātas.", parent=self)


def bottom_bar_in(parent):
    """Like bottom_bar(), for a frame inside a view; returns the inner frame."""
    return bottom_bar(parent)


# --------------------------------------------------------------------------
# Pop-up windows
# --------------------------------------------------------------------------
class EventCostumeSummary(tk.Toplevel):
    """Costume summary of one event: every dance of its programme, the dancers who dance it and the
    inventory numbers of the costumes (of the dance's costume types) currently issued to them."""

    def __init__(self, parent, db, event_label, dances, lineup_rows, session_id):
        super().__init__(parent)
        self.title(f"Tērpu kopsavilkums — {event_label}")
        self.configure(bg=CREAM)
        self.transient(parent.winfo_toplevel())
        self.db, self.dances, self.lineup_rows, self.session_id = db, dances, lineup_rows, session_id
        head = izskats.dialog_header(self, "Tērpu kopsavilkums", event_label, colour=MODULE_COLOUR)
        self.stats = tk.Frame(head, bg=WHITE)
        self.stats.pack(anchor="w", padx=20, pady=(0, 12))
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        self.only_missing = tk.BooleanVar(value=False)
        tk.Checkbutton(foot, text="Rādīt tikai dejotājus bez tērpa", variable=self.only_missing, command=self.fill,
                       bg=WHITE, fg=NAVY, activebackground=WHITE, selectcolor=WHITE, font=FONT).pack(side="left")
        self.info_var = tk.StringVar()
        tk.Label(self, textvariable=self.info_var, bg=CREAM, fg=MUTED, font=FONT_SMALL, anchor="w").pack(
            fill="x", padx=20, pady=(10, 4))
        outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=(0, 14))
        box = tk.Frame(outer, bg=WHITE)
        box.pack(fill="both", expand=True)
        cols = [("dancer", "Dejotājs", 260), ("type", "Tērpa veids", 170), ("inv", "Inv. nr.", 130)]
        self.tree = tree = ttk.Treeview(box, columns=[c[0] for c in cols], show="tree headings", height=16)
        tree.heading("#0", text="Deja")
        tree.column("#0", width=230, anchor="w")
        for key, title, width in cols:
            tree.heading(key, text=title)
            tree.column(key, width=width, anchor="w")
        tree.tag_configure("dance", font=FONT_BOLD, background=CREAM_DARK)
        tree.tag_configure("missing", foreground=RED, background=BAD_BG)
        make_tree_with_scroll(box, tree)
        self.fill()
        self.bind("<Escape>", lambda e: self.destroy())
        fit_min_size(self)
        self.grab_set()

    def fill(self):
        db, tree, session_id = self.db, self.tree, self.session_id
        tree.delete(*tree.get_children())
        for w in self.stats.winfo_children():
            w.destroy()
        missing = total = 0
        if not self.dances:
            self.info_var.set("Šim notikumam nav deju programmas.")
        for dance_id, title in self.dances:
            types_by_gender = {}
            if dance_id is not None and db.has_table("dance_costumes"):
                for gender, name in db.q("SELECT gender, type_name FROM dance_costumes WHERE dance_id = ?",
                                         (dance_id,)):
                    types_by_gender.setdefault(gender, set()).add((name or "").strip().lower())
            elif dance_id is None:   # publicity event: costume types chosen in Notikumu pūrs
                for gender, names in event_costume_types(db.con, [session_id]).get(session_id, {}).items():
                    types_by_gender.setdefault(gender, set()).update((n or "").strip().lower() for n in names)
            by_type = dance_id is not None or bool(types_by_gender)
            people = self.lineup_rows(session_id, dance_id)
            node = tree.insert("", "end", text=title, open=True, tags=("dance",),
                               values=(f"dejotāju: {len(people)}", "", ""))
            dance_missing = 0
            for dancer_id, name, gender in people:
                total += 1
                wanted = types_by_gender.get(gender) if gender else set().union(*types_by_gender.values()) \
                    if types_by_gender else set()
                wanted = wanted or set()
                pieces = [(typ or "", inv) for typ, inv in db.q(
                    "SELECT p.type, p.inv_no FROM checkouts c JOIN costume_pieces p ON p.id = c.piece_id "
                    "WHERE c.dancer_id = ? AND TRIM(COALESCE(c.return_date,'')) = '' ORDER BY p.type, p.inv_no",
                    (dancer_id,)) if not by_type or (typ or "").strip().lower() in wanted]
                if not pieces:
                    missing += 1
                    dance_missing += 1
                    tree.insert(node, "end", values=(name, "—", "nav izsniegts"), tags=("missing",))
                elif not self.only_missing.get():
                    for typ, inv in pieces:
                        tree.insert(node, "end", values=(name, typ, inv))
            tree.set(node, "dancer", f"dejotāju: {len(people)}" + (f" · bez tērpa: {dance_missing}"
                                                                     if dance_missing else " · visi ar tērpiem"))
        if self.dances and self.dances[0][0] is None:  # publicity event: the invited dancers
            self.info_var.set(
                "Tiek rādīti tikai Notikumu pūrā izvēlētie tērpu veidi."
                if event_costume_types(db.con, [session_id]).get(session_id) else
                "Tērpu veidi Notikumu pūrā nav izvēlēti — rādīti visi dejotājam izsniegtie tērpi.")
        elif self.dances:
            self.info_var.set("Tiek rādīti tikai dejai Deju pūrā pievienotie tērpu veidi.")
        izskats.chip(self.stats, f"Dejotāji: {total}", SELECTED, NAVY).pack(side="left")
        izskats.chip(self.stats, f"Ar tērpiem: {total - missing}", OK_BG, OK_FG).pack(side="left", padx=6)
        izskats.chip(self.stats, f"Bez tērpa: {missing}", *((BAD_BG, BAD_FG) if missing else (SELECTED, MUTED))
                     ).pack(side="left")


class TypeHistoryDialog(tk.Toplevel):
    """Every issue of one costume type to one dancer, newest first."""

    def __init__(self, parent, db, dancer_id, dancer_name, type_name):
        super().__init__(parent)
        self.title(f"Vēsture — {dancer_name}, {type_name}")
        self.configure(bg=CREAM)
        self.transient(parent.winfo_toplevel())
        rows = db.q(
            "SELECT c.checkout_date, c.return_date, p.inv_no, p.name, c.notes FROM checkouts c "
            "JOIN costume_pieces p ON p.id = c.piece_id WHERE c.dancer_id = ? AND p.type = ? COLLATE NOCASE "
            "ORDER BY c.checkout_date DESC, c.id DESC", (dancer_id, type_name))
        izskats.dialog_header(self, f"{type_name} — {dancer_name}", f"Izsniegumu skaits: {len(rows)}",
                              colour=MODULE_COLOUR)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Aizvērt", style="Accent.TButton", command=self.destroy).pack(side="right")
        outer = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=20, pady=14)
        box = tk.Frame(outer, bg=WHITE)
        box.pack(fill="both", expand=True)
        cols = [("out", "Izsniegts", 100), ("back", "Atgriezts", 110), ("piece", "Tērpa detaļa", 260),
                ("notes", "Piezīmes", 220)]
        tree = ttk.Treeview(box, columns=[c[0] for c in cols], show="headings", height=min(max(len(rows), 4), 14))
        for key, title, width in cols:
            tree.heading(key, text=title)
            tree.column(key, width=width, anchor="w")
        zebra(tree)
        tree.tag_configure("current", foreground=RED, font=FONT_BOLD)
        for i, (out, back, inv, name, notes) in enumerate(rows):
            back = (back or "").strip()
            tree.insert("", "end", values=(show_date(out), show_date(back) if back else "pašlaik pie dejotāja",
                                           f"{inv} — {name}", notes or ""),
                        tags=row_tags(i, "" if back else "current"))
        make_tree_with_scroll(box, tree)
        self.bind("<Escape>", lambda e: self.destroy())
        fit_min_size(self)
        self.grab_set()


class TypeDialog(tk.Toplevel):
    """Name + category of a costume type. result = (name, category) or None."""

    def __init__(self, parent, title, name="", category=CAT_NONE):
        super().__init__(parent)
        self.result = None
        self.title(title)
        self.configure(bg=CREAM)
        self.transient(parent)
        self.resizable(False, False)
        izskats.dialog_header(self, title + " — tērpu veids", colour=MODULE_COLOUR)
        foot = izskats.dialog_footer(self)
        ttk.Button(foot, text="Labi", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(foot, text="Atcelt", command=self.destroy).pack(side="right", padx=6)
        body = tk.Frame(self, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        body.pack(fill="both", expand=True, padx=20, pady=14)
        inner = tk.Frame(body, bg=WHITE)
        inner.pack(padx=14, pady=12)
        small_label(inner, "NOSAUKUMS").grid(row=0, column=0, sticky="w")
        self.name_var = tk.StringVar(value=name)
        entry = ttk.Entry(inner, textvariable=self.name_var, width=32)
        entry.grid(row=1, column=0, sticky="ew", pady=(2, 8))
        small_label(inner, "KATEGORIJA").grid(row=2, column=0, sticky="w")
        self.cat_var = tk.StringVar(value=category if category in CATEGORIES else CAT_NONE)
        ttk.Combobox(inner, textvariable=self.cat_var, values=CATEGORIES, state="readonly",
                     width=30).grid(row=3, column=0, sticky="ew", pady=(2, 0))
        izskats.note(inner, "Dejotājam izsniegšanā rādās tikai viņa dzimuma un nekategorizēto veidu tērpi.",
                     bg=WHITE, wrap=260).grid(row=4, column=0, sticky="w", pady=(8, 0))
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        entry.focus_set()

    def ok(self):
        name = self.name_var.get().strip()
        if not name:
            messagebox.showwarning("Nosaukums", "Nosaukums nedrīkst būt tukšs.", parent=self)
            return
        self.result = (name, self.cat_var.get())
        self.destroy()


class NameListPanel(tk.Frame):
    """One editable list (costume types or sets). Add / edit / delete are collected here and
    written to the database only when "Saglabāt" is pressed. Types also have a category."""

    def __init__(self, master, app, column, title, on_change=None):
        super().__init__(master, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        self.app, self.column = app, column
        self.has_cat = column == "type"
        self.on_change = on_change
        # [id or None, current name, original name or None, pieces using it, category, original category]
        self.items = []
        self.view_filter = None  # types only: None = all, else that category (plus "Nekategorizēts")
        self.deleted = []      # ids of saved items removed in this session
        head = tk.Frame(self, bg=WHITE)
        head.pack(fill="x", padx=14, pady=(9, 8))
        tk.Label(head, text=title, font=("Georgia", 12, "bold"), bg=WHITE, fg=NAVY).pack(side="left")
        self.count_lbl = tk.Label(head, text="", bg=WHITE, fg=MUTED, font=FONT_SMALL)
        self.count_lbl.pack(side="left", padx=(10, 0))
        tk.Frame(self, bg=LINE_SOFT, height=1).pack(fill="x")
        # buttons: always visible at the bottom
        btns = tk.Frame(self, bg=WHITE)
        btns.pack(side="bottom", fill="x", padx=14, pady=10)
        ttk.Button(btns, text="＋ Pievienot", style="Accent.TButton", command=self.add).pack(side="left")
        ttk.Button(btns, text="Rediģēt" if self.has_cat else "Pārdēvēt",
                   command=self.rename).pack(side="left", padx=6)
        ttk.Button(btns, text="Dzēst", style="Danger.TButton", command=self.delete).pack(side="left")
        ttk.Button(btns, text="⇪ Importēt", command=self.import_file).pack(side="right")
        tk.Frame(self, bg=LINE_SOFT, height=1).pack(side="bottom", fill="x")
        holder = tk.Frame(self, bg=WHITE)
        holder.pack(fill="both", expand=True)
        cols = ("name", "cat", "used") if self.has_cat else ("name", "used")
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("name", text="Nosaukums")
        self.tree.column("name", width=150 if self.has_cat else 190, anchor="w")
        if self.has_cat:
            self.tree.heading("cat", text="Kategorija")
            self.tree.column("cat", width=110, anchor="w")
        self.tree.heading("used", text="Tērpu skaits")
        self.tree.column("used", width=80 if self.has_cat else 90, anchor="center")
        make_tree_with_scroll(holder, self.tree)
        zebra(self.tree)
        self.tree.tag_configure("changed", foreground=OK_FG, font=FONT_BOLD)
        self.tree.bind("<Double-1>", lambda e: self.rename())
        self.load()

    # -- state ---------------------------------------------------------------
    def dirty(self):
        return bool(self.deleted) or any(i[0] is None or i[1] != i[2] or i[4] != i[5] for i in self.items)

    def load(self):
        if self.has_cat:
            self.items = [[i, n, n, used, cat, cat] for i, n, cat, used in self.app.db.type_items()]
        else:
            self.items = [[i, n, n, used, None, None] for i, n, used in self.app.db.list_items(self.column)]
        self.deleted = []
        self.show()

    def refresh(self):
        # outside changes are picked up only while nothing here is waiting to be saved
        if not self.dirty():
            self.load()

    def show(self):
        selected = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        shown = 0
        for n, it in sorted(enumerate(self.items), key=lambda t: t[1][1].lower()):
            if self.has_cat and self.view_filter and it[4] not in (self.view_filter, CAT_NONE):
                continue
            values = (it[1], it[4], it[3]) if self.has_cat else (it[1], it[3])
            changed = it[0] is None or it[1] != it[2] or it[4] != it[5]
            self.tree.insert("", "end", iid=str(n), values=values, tags=row_tags(shown, "changed" if changed else ""))
            shown += 1
        self.count_lbl.configure(text=str(shown))
        keep = [x for x in selected if self.tree.exists(x)]
        if keep:
            self.tree.selection_set(keep)
        if self.on_change:
            self.on_change()

    def _top(self):
        return self.winfo_toplevel()

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties ierakstu sarakstā.", parent=self._top())
            return None
        return int(sel[0])

    def _exists(self, name, skip=None):
        return any(n != skip and it[1].lower() == name.lower() for n, it in enumerate(self.items))

    def _ask(self, title, name="", category=CAT_NONE):
        # -> (name, category) or None
        if self.has_cat:
            dialog = TypeDialog(self._top(), title, name, category)
            self._top().wait_window(dialog)
            return dialog.result
        new = simpledialog.askstring(title, "Jaunais nosaukums:", initialvalue=name, parent=self._top())
        if new is None or not new.strip():
            return None
        return new.strip(), None

    # -- editing (not saved yet) ----------------------------------------------
    def add(self):
        got = self._ask("Pievienot", "", self.view_filter or CAT_NONE)
        if got is None:
            return
        name, cat = got
        if self._exists(name):
            messagebox.showwarning("Dublikāts", "Šāds nosaukums jau eksistē.", parent=self._top())
            return
        self.items.append([None, name, None, 0, cat, None])
        self.show()

    def rename(self):
        n = self._selected()
        if n is None:
            return
        it = self.items[n]
        got = self._ask("Rediģēt" if self.has_cat else "Pārdēvēt", it[1], it[4] or CAT_NONE)
        if got is None:
            return
        name, cat = got
        if name == it[1] and cat == it[4]:
            return
        if self._exists(name, skip=n):
            messagebox.showwarning("Dublikāts", "Šāds nosaukums jau eksistē.", parent=self._top())
            return
        it[1], it[4] = name, cat
        self.show()

    def add_entries(self, entries):
        """Imported (name, category) pairs are added to the list as unsaved items."""
        for name, cat in entries:
            self.items.append([None, name, None, 0, cat, None])
        self.show()

    def import_file(self):
        L = self.app.L
        key = "pieces.type" if self.has_cat else "pieces.set_name"
        info = ("Excel (vai CSV) faila pirmajā rindā jābūt kolonnas nosaukumam:\n\n  • " + L(key))
        if self.has_cat:
            info += f"\n  • {L('pieces.category')} (nav obligāta; {' / '.join(CATEGORIES)})"
        info += ("\n\nJau esošie nosaukumi tiks izlaisti. Importētie ieraksti tiek pievienoti sarakstam, "
                 "bet datubāzē tiek saglabāti tikai pēc pogas “Saglabāt” nospiešanas.")
        if not messagebox.askokcancel("Importēt no Excel", info, parent=self._top()):
            return
        path = filedialog.askopenfilename(
            parent=self._top(), title="Izvēlieties Excel failu",
            filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            result = parse_name_list(read_table(path), self.column, [it[1] for it in self.items], L)
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self._top())
            return
        if result["error"]:
            messagebox.showerror("Importa kļūda", result["error"], parent=self._top())
            return
        self.add_entries(result["entries"])
        text = f"Pievienoti ieraksti: {len(result['entries'])}\nIzlaistas rindas: {len(result['skipped'])}"
        if result["entries"]:
            text += "\n\nNospiediet “Saglabāt”, lai izmaiņas ierakstītu datubāzē."
        if result["skipped"]:
            text += "\n\n" + "\n".join(f"Rinda {n}: {why}" for n, why in result["skipped"][:12])
            if len(result["skipped"]) > 12:
                text += f"\n… un vēl {len(result['skipped']) - 12}"
        (messagebox.showwarning if result["skipped"] else messagebox.showinfo)(
            "Imports pabeigts", text, parent=self._top())

    def delete(self):
        n = self._selected()
        if n is None:
            return
        item_id, name, orig, used = self.items[n][:4]
        if used:
            messagebox.showwarning(
                "Nevar dzēst", f"“{name}” tiek izmantots tērpiem ({used}). Vispirms nomainiet šo vērtību tērpiem.",
                parent=self._top())
            return
        if messagebox.askyesno("Dzēst", f"Dzēst “{name}”?", parent=self._top()):
            if item_id is not None:
                self.deleted.append(item_id)
            del self.items[n]
            self.show()

    # -- saving ----------------------------------------------------------------
    def save(self):
        db, col = self.app.db, self.column
        for item_id in self.deleted:
            db.delete_list_item(col, item_id)
        renamed = [it for it in self.items if it[0] is not None and it[1] != it[2]]
        for it in renamed:  # via temporary names so that swapping two names cannot clash
            db.rename_list_item(col, it[0], f"~~tmp{it[0]}~~")
        for it in renamed:
            db.rename_list_item(col, it[0], it[1])
        for it in self.items:
            if it[0] is None:
                db.add_list_item(col, it[1], it[4])
            elif self.has_cat and it[4] != it[5]:
                db.set_type_category(it[0], it[4])


class CatalogAdminWindow(tk.Toplevel):
    """Veidi un komplekti (Noliktava): edit the costume types and sets."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title("Tērpu veidi un komplekti")
        self.geometry("900x600")
        self.minsize(720, 440)
        self.configure(bg=CREAM)
        self.protocol("WM_DELETE_WINDOW", self.close)
        izskats.dialog_header(
            self, "Tērpu veidi un komplekti",
            "Katram veidam var piešķirt kategoriju: dejotājam izsniegšanā rādās tikai viņa dzimuma un nekategorizēto "
            "veidu tērpi. Pievienojot vai rediģējot tērpu, var izvēlēties tikai šeit izveidotos veidus un komplektus. "
            "Pārdēvējot nosaukumu, tas mainās arī visiem attiecīgajiem tērpiem. Izmaiņas stājas spēkā pēc “Saglabāt”.",
            colour=MODULE_COLOUR, wrap=840)
        bottom = izskats.dialog_footer(self)
        ttk.Button(bottom, text="Aizvērt", command=self.close).pack(side="right")
        self.save_btn = ttk.Button(bottom, text="Saglabāt", style="Accent.TButton", command=self.save)
        self.save_btn.pack(side="right", padx=6)
        ttk.Button(bottom, text="⇪ Importēt veidus un komplektus", command=self.import_both).pack(side="left")
        self.state_lbl = tk.Label(bottom, text="", bg=WHITE, fg=RED, font=FONT_SMALL)
        self.state_lbl.pack(side="left", padx=12)

        view_row = tk.Frame(self, bg=CREAM)
        view_row.pack(fill="x", padx=20, pady=(12, 0))
        small_label(view_row, "RĀDĪT VEIDUS", bg=CREAM).pack(side="left", padx=(0, 8))
        self.view_var = tk.StringVar(value=VIEW_ALL)
        izskats.Segmented(view_row, [(VIEW_ALL, VIEW_ALL), (CAT_GIRLS, CAT_GIRLS), (CAT_BOYS, CAT_BOYS)],
                          self.view_var, command=self.apply_view).pack(side="left")
        izskats.note(view_row, "  (meiteņu vai puišu tērpi + nekategorizētie)").pack(side="left")
        body = tk.Frame(self, bg=CREAM)
        body.pack(fill="both", expand=True, padx=20, pady=(10, 14))
        body.rowconfigure(0, weight=1)
        self.panels = []
        for i, (column, title) in enumerate([("type", "Tērpu veidi"), ("set_name", "Komplekti")]):
            body.columnconfigure(i, weight=1, uniform="a")
            panel = NameListPanel(body, app, column, title, on_change=self.update_state)
            panel.grid(row=0, column=i, sticky="nsew", padx=(0, 7) if i == 0 else (7, 0))
            self.panels.append(panel)
        self.update_state()
        if not catalog_editable():
            piekluve.make_readonly(self, note="Tikai skatīšanai — veidus un komplektus maina tērpu pārzinis.")

    def import_both(self):
        """One Excel/CSV file with columns "Veids" (+ "Kategorija") and/or "Komplekts": both lists are filled."""
        if not catalog_editable():
            return piekluve.deny(self)
        L = self.app.L
        info = ("Excel (vai CSV) faila pirmajā rindā jābūt kolonnām:\n\n"
                f"  • {L('pieces.type')} (tērpu veidi)  — neobligāta kolonna {L('pieces.category')} "
                f"({' / '.join(CATEGORIES)})\n"
                f"  • {L('pieces.set_name')} (tērpu komplekti)\n\n"
                "Pietiek ar vienu no tām. Jau esošie nosaukumi tiks izlaisti. Importētie ieraksti tiek pievienoti "
                "sarakstiem, bet datubāzē tiek saglabāti tikai pēc pogas “Saglabāt” nospiešanas.")
        if not messagebox.askokcancel("Importēt veidus un komplektus", info, parent=self):
            return
        path = filedialog.askopenfilename(
            parent=self, title="Izvēlieties Excel failu",
            filetypes=[("Excel / CSV", "*.xlsx *.xlsm *.csv"), ("Visi faili", "*.*")])
        if not path:
            return
        try:
            rows = read_table(path)
            results = {}
            for panel in self.panels:
                results[panel.column] = parse_name_list(rows, panel.column, [it[1] for it in panel.items], L)
        except Exception as exc:
            messagebox.showerror("Importa kļūda", f"Neizdevās nolasīt failu:\n{exc}", parent=self)
            return
        good = {c: r for c, r in results.items() if not r["error"]}
        if not good:
            found = results["type"]["error"].split("Atrastās kolonnas: ")[-1]
            messagebox.showerror("Importa kļūda", f"Faila pirmajā rindā jābūt kolonnai “{L('pieces.type')}” vai "
                                 f"“{L('pieces.set_name')}”.\nAtrastās kolonnas: {found}", parent=self)
            return
        titles = {"type": "Tērpu veidi", "set_name": "Komplekti"}
        lines, skipped_lines = [], []
        for panel in self.panels:
            r = good.get(panel.column)
            if r is None:
                continue
            panel.add_entries(r["entries"])
            lines.append(f"{titles[panel.column]}: pievienoti {len(r['entries'])}, izlaisti {len(r['skipped'])}")
            skipped_lines += [f"{titles[panel.column]}, rinda {n}: {why}" for n, why in r["skipped"]]
        text = "\n".join(lines)
        if any(r["entries"] for r in good.values()):
            text += "\n\nNospiediet “Saglabāt”, lai izmaiņas ierakstītu datubāzē."
        if skipped_lines:
            text += "\n\n" + "\n".join(skipped_lines[:12])
            if len(skipped_lines) > 12:
                text += f"\n… un vēl {len(skipped_lines) - 12}"
        (messagebox.showwarning if skipped_lines else messagebox.showinfo)("Imports pabeigts", text, parent=self)

    def apply_view(self):
        choice = self.view_var.get()
        for panel in self.panels:
            if panel.has_cat:
                panel.view_filter = None if choice == VIEW_ALL else choice
                panel.show()

    def dirty(self):
        return any(p.dirty() for p in self.panels)

    def update_state(self):
        if not hasattr(self, "save_btn"):
            return
        dirty = self.dirty()
        self.state_lbl.configure(text="● Ir nesaglabātas izmaiņas" if dirty else "")
        self.save_btn.configure(state="normal" if dirty else "disabled")

    def save(self):
        if not catalog_editable():
            return piekluve.deny(self, "Veidus un komplektus maina tērpu pārzinis vai kolektīva vadība.")
        try:
            for panel in self.panels:
                panel.save()
        except sqlite3.IntegrityError:
            messagebox.showwarning("Dublikāts", "Neizdevās saglabāt: nosaukumi atkārtojas.", parent=self)
            return
        for panel in self.panels:
            panel.load()
        self.update_state()
        self.app.refresh_all()
        messagebox.showinfo("Saglabāts", "Izmaiņas saglabātas.", parent=self)

    def close(self):
        if self.dirty() and not messagebox.askyesno(
                "Nesaglabātas izmaiņas", "Izmaiņas nav saglabātas. Vai aizvērt, tās atmetot?", parent=self):
            return
        self.destroy()

    def refresh(self):
        for panel in self.panels:
            panel.refresh()


# --------------------------------------------------------------------------
# Main application (Galvenā lapa)
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Main-view panels: four equal panels, each shows a chosen chart of chosen information
# --------------------------------------------------------------------------
CHART_INFOS = [
    "Tērpi pēc kategorijas",
    "Tērpi pēc veida",
    "Tērpi pēc komplekta",
    "Noliktavā / izsniegti",
    "Izsniegtie tērpi pa dejotājiem",
    "Dejotāji pēc dzimuma",
]
CHART_TYPES = ["Joslu diagramma", "Stabiņu diagramma", "Sektoru diagramma", "Gredzena diagramma"]
CHART_DEFAULTS = [
    ("Tērpi pēc kategorijas", "Joslu diagramma"),
    ("Tērpi pēc komplekta", "Stabiņu diagramma"),
    ("Noliktavā / izsniegti", "Sektoru diagramma"),
    ("Izsniegtie tērpi pa dejotājiem", "Joslu diagramma"),
]
PALETTE = [NAVY, RED, GOLD, "#2E7D6B", "#7A5C99", "#C4703A", "#4F7CAC", "#8C8C8C", "#A0522D", "#5B8C5A"]


def chart_data(db, name):
    # returns {"series": [(name, colour)], "cats": [(label, [value per series], colour or None)]}
    base = "(SELECT p.*, " + STATUS_EXPR.format(p="p.id") + " AS s FROM costume_pieces p)"

    def grouped(col):
        rows = db.q(
            "SELECT CASE WHEN TRIM(COALESCE(" + col + ",'')) = '' THEN '(nav norādīts)' ELSE " + col
            + " END AS grp, SUM(CASE WHEN s=? THEN 1 ELSE 0 END), SUM(CASE WHEN s=? THEN 1 ELSE 0 END) "
            "FROM " + base + " GROUP BY grp ORDER BY COUNT(*) DESC, grp LIMIT 12", (AVAILABLE, CHECKED_OUT))
        return {"series": [(AVAILABLE, NAVY), (CHECKED_OUT, RED)],
                "cats": [(g, [a or 0, o or 0], None) for g, a, o in rows]}

    if name == "Tērpi pēc kategorijas":
        return grouped("category")
    if name == "Tērpi pēc veida":
        return grouped("type")
    if name == "Tērpi pēc komplekta":
        return grouped("set_name")
    if name == "Noliktavā / izsniegti":
        a, o = db.q("SELECT SUM(CASE WHEN s=? THEN 1 ELSE 0 END), SUM(CASE WHEN s=? THEN 1 ELSE 0 END) FROM "
                    + base, (AVAILABLE, CHECKED_OUT))[0]
        return {"series": [("Skaits", GOLD)],
                "cats": [(AVAILABLE, [a or 0], NAVY), (CHECKED_OUT, [o or 0], RED)]}
    if name == "Izsniegtie tērpi pa dejotājiem":
        rows = db.q("SELECT d.name, COUNT(*) FROM dancers d JOIN checkouts co ON co.dancer_id = d.id "
                    "AND TRIM(COALESCE(co.return_date,'')) = '' GROUP BY d.id "
                    "ORDER BY COUNT(*) DESC, d.name LIMIT 12")
        return {"series": [("Izsniegti tērpi", RED)], "cats": [(n, [c], None) for n, c in rows]}
    if name == "Dejotāji pēc dzimuma":
        rows = db.q("SELECT CASE WHEN TRIM(COALESCE(gender,'')) = '' THEN '(nav norādīts)' ELSE gender END, "
                    "COUNT(*) FROM dancers WHERE " + dancer_role_sql("dancers") + " GROUP BY 1 ORDER BY 2 DESC")
        colours = {GENDER_FEMALE: RED, GENDER_MALE: NAVY}
        return {"series": [("Dejotāji", NAVY)],
                "cats": [(g, [c], colours.get(g, GOLD)) for g, c in rows]}
    return {"series": [], "cats": []}


def short_text(text, limit):
    text = str(text)
    return text if len(text) <= limit else text[:max(1, limit - 1)] + "…"


def chart_setting(db, slot, part):
    allowed, default = ((CHART_INFOS, CHART_DEFAULTS[slot][0]) if part == "info"
                        else (CHART_TYPES, CHART_DEFAULTS[slot][1]))
    rows = db.q("SELECT value FROM settings WHERE key=?", (f"chart.{slot}.{part}",))
    value = rows[0][0] if rows else None
    if value == "Pieejami / izsniegti":  # name used before the rename
        value = "Noliktavā / izsniegti"
    return value if value in allowed else default


def save_chart_setting(db, slot, part, value):
    db.x("INSERT INTO settings (key, value) VALUES (?, ?) "
         "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (f"chart.{slot}.{part}", value))


class ChartPanel(tk.Frame):
    # One of the four equal panels on the main view (Pārskats); what it shows is chosen in the settings.

    def __init__(self, master, app, slot):
        super().__init__(master, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        self.app, self.slot = app, slot
        self.info_var = tk.StringVar()
        self.type_var = tk.StringVar()
        self.data = {"series": [], "cats": []}
        head = tk.Frame(self, bg=WHITE)
        head.pack(fill="x", padx=14, pady=(9, 8))
        tk.Label(head, textvariable=self.info_var, bg=WHITE, fg=NAVY, anchor="w",
                 font=("Georgia", 12, "bold")).pack(side="left")
        tk.Label(head, textvariable=self.type_var, bg=WHITE, fg=MUTED, font=FONT_SMALL).pack(side="right")
        tk.Frame(self, bg=LINE_SOFT, height=1).pack(fill="x")
        self.canvas = tk.Canvas(self, bg=WHITE, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=10)
        self.canvas.bind("<Configure>", lambda e: self.draw())
        self.refresh()

    def refresh(self):
        # what to show is chosen in "Pārskata iestatījumi"
        self.info_var.set(chart_setting(self.app.db, self.slot, "info"))
        self.kind = chart_setting(self.app.db, self.slot, "type")
        self.type_var.set(self.kind.lower())
        self.data = chart_data(self.app.db, self.info_var.get())
        self.draw()

    # -- drawing -----------------------------------------------------------
    def draw(self):
        c = self.canvas
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        if w < 80 or h < 80:
            return
        series, cats = self.data["series"], self.data["cats"]
        totals = [sum(v) for _, v, _ in cats]
        if not cats or not sum(totals):
            c.create_text(w / 2, h / 2, text="Nav datu", fill=MUTED, font=FONT)
            return
        kind = getattr(self, "kind", "")   # read in refresh() — redrawing must not query the database
        if kind == "Joslu diagramma":
            self.draw_hbar(c, w, h, series, cats, totals)
        elif kind == "Stabiņu diagramma":
            self.draw_vbar(c, w, h, series, cats, totals)
        else:
            self.draw_pie(c, w, h, cats, totals, donut=(kind == "Gredzena diagramma"))

    def draw_legend(self, c, series):
        x = 2
        for name, colour in series:
            c.create_rectangle(x, 6, x + 10, 16, fill=colour, outline="")
            c.create_text(x + 16, 11, text=name, anchor="w", fill=NAVY, font=FONT_SMALL)
            x += 16 + len(name) * 7 + 18
        return 28

    @staticmethod
    def segment_colour(series, j, colour):
        return colour if (colour and len(series) == 1) else series[j][1]

    def draw_hbar(self, c, w, h, series, cats, totals):
        top = self.draw_legend(c, series) if len(series) > 1 else 6
        n, label_w, right_pad = len(cats), 140, 46
        row_h = max(14, min(30, (h - top - 8) / n))
        bar_h = row_h * 0.62
        scale = (w - label_w - right_pad) / max(totals)
        for i, (label, vals, colour) in enumerate(cats):
            y = top + i * row_h
            c.create_text(label_w - 10, y + bar_h / 2, text=short_text(label, 20), anchor="e",
                          fill="#4A4535", font=FONT_SMALL)
            c.create_rectangle(label_w, y, w - right_pad, y + bar_h, fill=LINE_SOFT, outline="")
            x = label_w
            for j, v in enumerate(vals):
                if v:
                    c.create_rectangle(x, y, x + v * scale, y + bar_h,
                                       fill=self.segment_colour(series, j, colour), outline="")
                    x += v * scale
            c.create_text(w - right_pad + 8, y + bar_h / 2, text=str(totals[i]), anchor="w", fill=NAVY,
                          font=FONT_BOLD)

    def draw_vbar(self, c, w, h, series, cats, totals):
        top = self.draw_legend(c, series) if len(series) > 1 else 14
        n, left, right, bottom = len(cats), 10, 10, 30
        slot = (w - left - right) / n
        bar_w = min(54, slot * 0.6)
        base_y = h - bottom
        scale = max(10, base_y - top - 18) / max(totals)
        for i, (label, vals, colour) in enumerate(cats):
            cx = left + slot * (i + 0.5)
            y = base_y
            for j, v in enumerate(vals):
                if v:
                    c.create_rectangle(cx - bar_w / 2, y - v * scale, cx + bar_w / 2, y,
                                       fill=self.segment_colour(series, j, colour), outline="")
                    y -= v * scale
            c.create_text(cx, y - 9, text=str(totals[i]), fill=NAVY, font=FONT_BOLD)
            c.create_text(cx, base_y + 6, text=short_text(label, max(3, int(slot / 6.5))), anchor="n",
                          fill="#4A4535", font=FONT_SMALL)
        c.create_line(left, base_y, w - right, base_y, fill=LINE, width=1)

    def draw_pie(self, c, w, h, cats, totals, donut):
        legend_w = int(min(220, w * 0.48))
        area_w = w - legend_w
        r = max(10, min(h - 20, area_w - 24) / 2)
        cx, cy = area_w / 2, h / 2
        total = sum(totals)
        colours = [cat[2] or PALETTE[i % len(PALETTE)] for i, cat in enumerate(cats)]
        start = 90.0
        for i, t in enumerate(totals):
            if not t:
                continue
            if t == total:
                c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=colours[i], outline=WHITE, width=2)
            else:
                extent = -360.0 * t / total
                c.create_arc(cx - r, cy - r, cx + r, cy + r, start=start, extent=extent, style="pieslice",
                             fill=colours[i], outline=WHITE, width=2)
                start += extent
        if donut:
            hole = r * 0.58
            c.create_oval(cx - hole, cy - hole, cx + hole, cy + hole, fill=WHITE, outline=WHITE)
            c.create_text(cx, cy - 8, text=str(total), fill=NAVY, font=("Georgia", 18, "bold"))
            c.create_text(cx, cy + 14, text="kopā", fill=MUTED, font=FONT_SMALL)
        row = min(22, (h - 20) / len(cats))
        y = max(8, h / 2 - row * len(cats) / 2)
        for i, (label, _vals, _colour) in enumerate(cats):
            c.create_rectangle(area_w, y + 4, area_w + 10, y + 14, fill=colours[i], outline="")
            c.create_text(area_w + 16, y + 9, text=short_text(label, 20), anchor="w", fill="#4A4535", font=FONT_SMALL)
            c.create_text(w - 4, y + 9, text=str(totals[i]), anchor="e", fill=NAVY, font=FONT_BOLD)
            y += row


class MainSettingsWindow(tk.Toplevel):
    """Pārskata iestatījumi: choose what each of the four charts of the main view shows."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title("Pārskata iestatījumi")
        self.configure(bg=CREAM)
        self.transient(app.root)
        izskats.dialog_header(self, "Pārskata diagrammas",
                              "Katrai no četrām diagrammām izvēlieties, kādu informāciju un kāda veida diagrammu "
                              "rādīt. Izmaiņas stājas spēkā uzreiz.", colour=MODULE_COLOUR, wrap=600)
        btns = izskats.dialog_footer(self)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save_close).pack(side="right")
        ttk.Button(btns, text="Atjaunot sākotnējās", command=self.reset).pack(side="left")
        grid = tk.Frame(self, bg=CREAM)
        grid.pack(fill="both", expand=True, padx=20, pady=14)
        self.vars = []
        for slot in range(4):
            grid.columnconfigure(slot % 2, weight=1, uniform="g")
            box = tk.Frame(grid, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
            box.grid(row=slot // 2, column=slot % 2, sticky="nsew", padx=(0, 6) if slot % 2 == 0 else (6, 0),
                     pady=(0, 12))
            inner = tk.Frame(box, bg=WHITE)
            inner.pack(fill="both", expand=True, padx=14, pady=10)
            tk.Label(inner, text=f"{slot + 1}. diagramma", font=("Georgia", 12, "bold"), bg=WHITE,
                     fg=NAVY).pack(anchor="w", pady=(0, 6))
            info_var = tk.StringVar(value=chart_setting(app.db, slot, "info"))
            type_var = tk.StringVar(value=chart_setting(app.db, slot, "type"))
            self.vars.append((info_var, type_var))
            small_label(inner, "RĀDĪT").pack(anchor="w")
            cb1 = ttk.Combobox(inner, textvariable=info_var, values=CHART_INFOS, state="readonly", width=32)
            cb1.pack(anchor="w", fill="x", pady=(2, 8))
            small_label(inner, "DIAGRAMMAS VEIDS").pack(anchor="w")
            cb2 = ttk.Combobox(inner, textvariable=type_var, values=CHART_TYPES, state="readonly", width=32)
            cb2.pack(anchor="w", fill="x", pady=(2, 0))
            for cb in (cb1, cb2):
                cb.bind("<<ComboboxSelected>>", lambda e, sl=slot: self.apply(sl))
        self.bind("<Escape>", lambda e: self.destroy())

    def save_close(self):
        for slot in range(len(self.vars)):
            self.apply(slot)
        self.destroy()

    def apply(self, slot):
        info_var, type_var = self.vars[slot]
        save_chart_setting(self.app.db, slot, "info", info_var.get())
        save_chart_setting(self.app.db, slot, "type", type_var.get())
        self.app.refresh_dashboard()

    def reset(self):
        self.app.db.x("DELETE FROM settings WHERE key LIKE 'chart.%'")
        for slot, (info_var, type_var) in enumerate(self.vars):
            info_var.set(CHART_DEFAULTS[slot][0])
            type_var.set(CHART_DEFAULTS[slot][1])
        self.app.refresh_dashboard()


# Program name and version (shown in the Windows title bar; bump the version with every delivery)

PROGRAM_NAME = "Tērpu pūrs"
APP_VERSION = "0.6.2"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Tērpu un tērpa detaļu uzskaite, izsniegšana dejotājiem un atgriešana noliktavā",
    "letter": "T",
    "color": RED,
}

# Program icon (window title bar / taskbar): PNG as base64 text. Empty = look for a file
# "app_icon.png" / "app_icon.ico" next to this script instead.
APP_ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABnnklEQVR42u2ddZhd1bn/P2ttOTpucTcSIBBcgxSnQIHBSoHSlhqU"
    "21K3NHX3QqmgRUpwdxgkQYKFMCHuMm5H995rrd8fe5+ZM0mgwG17b++P/Tw8TI7vtd716vf9vvD+9f71/vX+9f71/vX+9f71f/8S"
    "gDAGwTxk6d8w7G/x/9uC/J+7p3nz5onW1lbR3t4uAFpaWgygAfMuPkc2NyPa2+cKgMMOO0zPnz/fvMvPeF8A/h330NzcLNvb20W0"
    "0WrnNyp4cfGLzlX3XBWzvWKqvW29VewpGhVTAqCmdrROV8b9CXWNha985VdZrfVbft/cuXOtxsZGc8stC7QQ/9kC8R8pAMYgzjij"
    "WcICFiwYvuHGGPvCz5w2zst6U3I6M0N7Yqoyelygik0oWeubYlJqOxXgWcYXRhMAQljS1cLSgSXtnC2tHmGLDls6W23bXms7cnks"
    "Fl8+aeTkNd+d/+tuM3zP5dy5c2WkIfT7AvAvPukLFiyg/JT/7Lqfpd5Y9Mzs/oHcwV7R3y9QxVlFzx+vfeI+OVQRAh0gLYFjuVi2"
    "xLXiSMdg46KMT6AURkGgfZTSqEChTIAQEtuysW2BJR0c2+1wYs6KuOO+6DrOUyPGjHvu1z/889YyqyDmzp1rtTzZovgP0Qz/6wVg"
    "3rx58sknn5QtLS1B6bEvfvH8Eevbtx2ufX1ippA9qOgXxgeeougVERLSiUrqamqCphGNetyIcTQ01Iim+pGipqaaZCIpUvEU0hE4"
    "wsYIUFqhA03BK5DL5+nvz5ievi6zraPdbNm6jc3tm0R7W4fs7eu3fFXEth1cxyHmuL0xN/6yG3cerEzVPnjdn297XZtQCTQ3Y0Ez"
    "CxYsUO8LwHvc+NbW+aKk4q+8cl7yoacXHhl43rl5r/AB3/dqvYLC1x41VTVq2sTpavqMyWLmlF3ExDETRF1dpahMVYLjggUEgFGg"
    "NWiDRoduYbQKUkgQAqQAaYGUob+nwCtm6enpY/O2rWbluhX6jWUrzLIVb4rN2zY5vh8Qj8eIOQmVTMYWWTH776OrJtz+hz9ctWU7"
    "zaXeF4B3uPHz588n8tq58NLm6b0dvecV/NwZhVxhSi5fQAvN2BFj/b1334e95swSs6bOkqMaR0LCgkCA7+OpIjowaKMxAiQSg4lu"
    "WCCEKbt9E2lxEQpG9DfR+4QEy7KwbRdiNvjQ39fNyrWrzCtLXtPPvfyiWbFqpV0o5mQikSTuJLviSfvedCp91U1XP/CUMeZ/rSCI"
    "/z0bj2xtZfDEn/GJE/fJ9w5c7AX+6fl8IZnLZ2lqaAgO2Osgc9ghB8ndpu8qKqtrBASoYmB830OjEFjhTUkQRoIwIATCgBFmxyDO"
    "UBbZifD15bJBqAmM1hhDJEQC25Y4sThIR/iFLKvXrddPLnpKtyx6yqxZu8GVNqQTKZLx5COxpPvLW6975MFIEOS8efP43+Iw/q8Q"
    "gLlz59olG3/O+SfslS3kv5IrZk/LZnJSKWV23WVX/9gjjpaH7L+fbGoaAybALxYJ/AAjDXJw0w1ChyfdCIMwMvw/EKoBAzra5Cic"
    "QAgwoV8vhCjTBqXnJIhyrWAwGoEArTUYYSxbEHMT4DhkB3pY/Mpr5u6H7tGLFr8gla+sdGWKRDzxRKoi+cNbrn7o0dBHaLYWLFjw"
    "bnMT/7cEIFL3GuDM80+eMDDQ+ZWi730snys4GqX323M/ddqJJ8v99tpbuIkkfj6H7wcgDFLIoQ2LbsNgkEZgorsSRqBFuFsCgRl8"
    "rdlBAxgE4cfpUFgEO2oFiISi3HoYEAatBUZrbMfCjadBBby27DXuuPd+9ejTTwjfL9hVlVXE4vZNVem6+Tdcdffy7dfg/ysBKJ16"
    "Y4x12oeP/K9crvD1bC5bm8vn9AF7HajOOeN064A99gHLppDLorTGsmR49CjbRzGkvg0go402UfJnu93aaVKhfCkMOjIXDH6XKbcM"
    "gwIQvQgiDSFLUodWBgQkEnGwXJa+sZTrb71BPfnMM8J1LDudSmWdhP2Tu2986odCCFWuAf/PC8C8ecj58zGAOeOCE/fJZvp/XfTy"
    "B3Z39zFt8hTvox/+iH30wUeCJcjnshgDUkaumxBD+ygYvqnRyR86mKGWMMPMvSkz8ZGKHxSC8M1DrzGDm23K84nlJqN8FY0IBWFQ"
    "YkDp0HQkE0mw4NlFz/OXG69Wry9baldXV4qYHV+USCY+f9vfHnkeBr3Uf6tJsP6dX9bc3GxdfnmrNsaIF9545MuFbPa63r7+iQi8"
    "C848j298/ivWLrvMFPlsVvh+ESllmaqPzqPYXnS3q9+UhEAIxKBEDO2iiJy4QdWOCAVBlH9syRwMfaAoPbbd9wlRJoQisgiR5hFC"
    "IIXE9z1832PyxCkcd8SRMplImleWLA0y2ewEI9R5u82Z6q9cuuEZ8x1Dc3Oz1draav7PaYCSmjvzgqPHDvQV/uLp3NFdnf16vzn7"
    "qM996iJ7lxmz8QYy+NozlrCGbLqQlFnpYcp9mIY34T9CdT34OhFuRPhPU7bBw+369mYhOs2mZAJM+JnD3Ifh/oQIw45Ig5T5G4MO"
    "JWilsWxJLJUWq1auNL/642/Vcy+/YDXUNkjbcu6qHVn7sev/cGfXv9Mk/DsEIEyPtrQEJ5952JGFYuGafK44RhF4F559of2R088W"
    "lm3I5/JIIYywwrSrlBKtA1SgEYAWJrLvDLfvg37AkHM2JCjhUzrawKE7Ln9FuEGipHvLBciUa/Sy3TdDghZuuhj8CcNfZnBsByEt"
    "lFFoP0AbLQyGVCJFoLX5yw1Xm+tuvlnFXNuNxe03k27sw3fc8vTL/y4hEP+GzxeAPv5Dcy8Jgvyvu/v75LhRE72vXXapvfee+4tC"
    "fz8KhWUk8VTKFP0ixe5e8l4BK5WitqoObUwY4hmJQUebJDFCI7QI4/uS119K9kROmkBEoaAo8wPK3jMsOigJg8SgwveL6P1aYKJw"
    "UBiBkWZQAEAMRhzhV1thTkIKejp7UPkMiVSMVHUTQoJXyAtjQApBvLLCPP3MU/zwlz8Pege63KqKqkwqWXnB7Tc9fNu/QwjEv3rz"
    "hRD62FMP/KkK1Jc6OjrVwQccYL79hW9Y9fW1ZDMZbMtGm4BEoooVi581C2+9mlWrtvDsys3MmjyC2RMmUVA+CIWtXaRT2myJEgEm"
    "sFCoUNtrCUJFp91g21Zog40Pxgo3VgagLJRQQoAR2sJIBVoihUZpjcDBWD4mkFi2hRE+IrAx+EgpMUYiLIONhTZB9HtstPAwWiBx"
    "UKKILSUvvLGetds6OHRGE5MnT+fwCz7N6GnTRTGXRUpJoAJSldWsW7ueb/z428GKlSvt2uoa4nH5mbsXLPzjv1oI/iUCYEL/Rxhj"
    "zPGnHnK10sH5nZ3d3lmnnmZ//lMXC2EEhWI+3HytiVWkWb3oOe748ddNX5Dn8eUZRlZa7De2gkxOIaSKTqGNFgEWFsYYbBuksfBM"
    "gIVEGwGWQSpBEAWDlpEEIgANrrDBDkA7oUYRBpRNIHxsYxGg0RiksdAECBM6cVoohLEwWqGFCUM+Y7AsC4MKTZOBwCgsaSOMwFce"
    "Ulq4doyFG3vIB4aDx6Wpq63nnO/9moaJE0WQL4AUKKVIJdL0ZnuZ9+Mf6acXPUvTiFrLtuzL7l3wzC//lUIg/lWfaYzh+OaDbvCL"
    "6uye3l7vUxd8zPn4eR8jn8lgjEbKcBGl5ZDP9vDIz79lvFwvgQWqIGgcEcd2XdAW0tXYtoPAwggPlMQYjbAlktIJtggCFQqAcTEi"
    "CB25wMbIACnBUjbK9kC5SEugjI9ULgEFhHHC+o9UCO2g8cPakLHxVREhJBIHpA86zBdJa8jbBwlWVG9SGq19jJYoX1PI5+jsLRKP"
    "2RQGMjRN3o2j/uvbQpqo9oDAKIMds8BYfO8XPzb3PXa/aqitc5Ju6pt3Lnj8B/8qIbD/+TV75C23GHPCqQdd7ynv7L6eXPGyz17q"
    "nn3GWWT7+pBCIKUMHQNjcN0Yq15fbd54cyW9PrT39pGwkhTf9BB6SG1b2KGtFgajJEao6CSCFgoHBy0UyhgsHIzwMdHfSI1GI7WN"
    "lgESCykEvvYRyiGQRaxIAIxQCGWHp16AxI6wASI0O0YhpIzCScKkjwy1gpAGYwQSgSLAKIGQAq0VrpAoNKOq03RlX2ffrjbqG8ei"
    "/UJYcZAS3/exLfjel78l4glH3nbfXf7IWvf7J5528MC9t7X89l8hBP9UAZg7d661YEFLcOJpc/8caH1Ob+9A8Yuf/bx71hlnkunt"
    "QUqr3BUDIQiUb+pGjcFOJNm2rY2X1nUREwP0eDmkkbiWDBWzEpHaBkJn0GCEKOX9URYIFVbwjMRIHSUJZSQ4od8QFoyiBI/QobqX"
    "oTMZPqzDIpIcCgmNMQgJRg8PD0UUfproFMvoPUZDGL1KPKWQAipjsRCrMNUwcfJUquqbUL4/TAlLIVGBoqDyfOO/viS1Mdxx931+"
    "Y0PNb04466DMfTe3XPXPFgL7n7j5dktLS3D86Qd+1/e8j3d2d3mXffZS56zms8j0dGNZclj0LKJYXPk+tQ0jqR87nvptnVQkHSxt"
    "EVguWoFrRZ6/iRJlUbIljO4Hk/5gLAxyMB1cvlFDCSKBiXY2jAR0aEKExpgwTtCRAIQbaDCRvUeYKMljRVFeWRQhZBQxwPZBpqUE"
    "cVsStyySSZe0KxgzfTqJZNrk+vqFkGWJJRNmO7XR5PMFvnHpl4SX0/L+xx4IauvSfzqp+bC2uxc8eV9USPqnlJXlP3PzT2g+9EKl"
    "zLc6Orq9j597nn1O8zlke3uwLGuYpJshBBVaKeHE4oyZMpWkbUjGHAKtsYRAA0qbwdebYTX86P1Gl8LywUtrgzahiTFlqWFjhv6v"
    "Kb0m3EpjoFgIhUZKK8ziSQvLCtW4MduHN3Kw/lBeKDLRd4FAaVBKI4Ug0IaqhE3MsRg1bVe01m/pf0kh0Vrje5745mVflvvvsy89"
    "fX3C99TN51xw8m4LFixQzc3N1v8KAWhubrZaWlqCU5rnHux7xT92tHUGpxx3ovXpj32SbH8fQoq3ihSGTi8wYvIMYq5LdTKG0gY7"
    "chJD+yiQQmAJiZQCS8owTSwjf0KE5kSUsrpSRBsYPh+q5+g/IUPQT+l5YdABVNa4zD6oAQEUCwWKhQL5bI5sJocKwCq93xJRijp8"
    "zIo+x5IifEyUfmuUQhbhc9oYapMOqYpKRkycGqp/8dY+uJSSINBICd//2rfklIlTVF//QLqzt23BRV/5QNWCBQuMMf99J/6/K0Wy"
    "tbXVXHTR2fWd/T2P9Pb11uyx2+76B9/4juX7vjDGiFIqd3j9tSxlFi6YCLTijZbHyHoebb0FLCnwImi2JcWgyTBlVblSwkeIqGwj"
    "jBCEGyAGVfTwAKWURTQGLMsylm0Jz1PU1MY46MRRaCSWqeaSL19GRbqSeDpBzagiYyZXsu7NPmzHioTalNUJGDJRpfqDEARKY0lJ"
    "zLKQlmB6Y5oJ06ax/web0YEWpRrHduXNoUeExA8CqtJpMXvXPeSjLS1BMcg35jNmlzVvbrnpiScOtdevX2/+pwRANDc3y2XLlumG"
    "sRW35AuFvaurar1ffPcHVlWqQniBjyWsHTJxOxRuROhkuYmEaH2mhb7eLtr6iyDAVwatDZYlosre4O4PLfygHR5MvA+d/qgYI2U5"
    "vMtErp0UA5l+4Xs+e85tpGl0isBAW3/AT370C44+ci4fOOoopu42hbXtr+Arn3TcRgWC/IBPCCEUkbqPBLKsWGQw+MrgWhIpBOm4"
    "y4Qql1kHHcqsgw7DyxfFzrXjcBMnhaBQLDBy1BjGjhwpHnj8IT9mJ2bNmDUh+8gDTz0zd+5ce/369frfbgJK+LYTmw//sjbmhKJX"
    "9L7xX1+0R48aLfLFPJaU293WDhWXQaCGDhSpqmoaJ00lJg2JmAMGbCs8sTo03oOQLIxBRAtvWRJLSmzLwrJspJRYlhWp/pKtiQTQ"
    "GJSvMUoIpQKOPuFoTjzlVE465TxEhcu2vgyjR0+jccRYXrv3D7xw/XeZOnkG48YcSk82y95zG0iMEjijHGNV2BQLJkwcWbKsIBhu"
    "mo5+nyMlWhuqUiGSePT02QJjxLAq4j/y1C2bbF8vh809THz49LOsjq4u3wv8H5x24Qf2bmlpCf47/sB7euO8efPk5Zdfrk/5yJHT"
    "vLx3U1d3jzjvnDPlaSc1y4H+XmzLHrRvg6VyM6QJRATPGizLao0bj5u+9k5WvbyQPh8yOR8pwAsMtgwdMmmFiwsCPwjwAkU+lycI"
    "FMW8RzafQ2so5IsorXBdBynC9yEE2kBVg4NrW/i+5ke/+hkXfuLjjB4xlvq6mdz/xMNkMz3svcdBTB4/GSWT1I6dzLW3Xc2GbRuZ"
    "PvUAPnDE2cycM00sW/MmUybWsNuhdVi2RceGHNIO701KCExYi0g4NtoYJjQkGdfUxMFnnifiiQRaaYbXt9/u79AcBIHH3rP3Fq+8"
    "vkRv3rrJFcra59yzLry6o6PDtLa2/vvCwNbWVmGMEcecuv/lmf5CcpdpM/yPnn2uVRgYwJLW8IrY9tptGNwqelhKo4KAEZOnE0+k"
    "qEoothmwbYmUBiyBQJLNZ9GRAFVVpWisqKZpyjiyfQPU1zew74F7MGnCJHL9Wa695hqef/5VLGmjjMJybCzhMH6XGqoakpxx8pcZ"
    "P6qBhVd9lYn7fZDa6mrSCYeJI11eWfIMfeN3Z989P8Cf/nYt1WnDjIlNTJ98AGcdeyKZfFFMGjHJ/PH6H4KTpH1jhhKqXBBiBZXW"
    "odMqwLUlVTGoHTWOmsYmPN+LogjzD1OqpgyIEgQB6UScL376c/ZFX/qsF/hqz5dbW751z4Inv/VeQ0P7vXj9CxYsUB86+8hzjdZH"
    "GmP8Sz/+GTsRS5D3CqE63EnBtQTMEINiEWXPRBiCK98zTWPHUl3fSEX/AFJa2BJcB7p7e4nLODOmjWW8k2B64wj2Pupg0k6aGUcd"
    "QLy+imLfALGaylDA7Di7TGti4bPPYckK1m1aS2vral57bSWtr25jwpwGXl+9lP1mzqRYKKKkgxdoqqvr6MkOMP+KK2lM1jJ75q7c"
    "0fIoe8yoYeaEBiZOnMKyhXeS3fqGmX3oJ5kyaW/WLF8E2iYQRXyliJsIRWwMliVRylCRdonbglHTdiEWT5DtD8Eu78gADELPws/L"
    "5rLMmLkL5591jn35X64KbFd+6SOfPuXG669Y8OZ7wRe+KwEIizwLzKWXnl+9Yv2qH3X19uizTz5T7rX3PgwMtONYsWhryzf6LcLA"
    "YTAPUH4gUlU1pnHceDZtWEMqkaB3oIdsJsdRxx/Dh/Y7mMmjKsmv20pMOqxbspSagw/jzccXMeu0owmMYGD9euKV1dh2nLqmscyZ"
    "2ca4ybNJjqyn0N3H8qXLWbzsVe5/7mGmjB9HRjnsccY3cGOCn/7khzz07HIaSVNRdMht3sLDq7cwKp1i42pFW9tGTj6hnV2m7iW2"
    "GGUcy6FvICvqmmKmYUORgorR42g2KkMxkm9bCpQ2VKccYq7LmOmz0EYPmkdTBlB+m+M/bAWltChkBjjn1DPFU88+b1avXxmz2tt/"
    "ApzU2toq/6U+QGtrs9Xa2qqbxjd8PV/IfrCquiL4zmXfsFwp0UIjSz5lGShDDFp6sR3Q0oReOUYYCUYb3GSKjk1rWb/kRTa156ge"
    "Vcf8H3yLL192CTNmz2DVC69QNWo0m1tXUDO+kf6t3djJFLGKBFVNjQTFIoVMD/FEBbFkkrYN69mydjWpqjqKnk8qGaeq0qYzs4I7"
    "nniAVeu2sGHLar7z65+xYvUGrJ4sVlcOXSxipMV0kWBMVpPIFujyLd7ctpXahjFi9v5H88yLT9Py3OMYU+TY48+juztPfMMGZidq"
    "aFcefUaRslyEhAn1KUY31XPo6RfgJuLCaB3WOCKQy3As23aWUojhAGUkgdGkUikaaurkA088pBzL3WXffXdfeMvNd616t5Cydy4A"
    "85Ctl7eac889qjGT86/t6u2KXXT+R8UB+xwiCrlMmHx5CwGAIWDGUNg2mLSNDKfBcRxy+SxrX3mOU869kC986/PMnrMX2Z5ejC3Q"
    "RZ9cWycmUGx5/Q3iySSN06bQu2ULI2dOBSEo5LLoQOEk4qQqq9m06g1sxwmxAVrx8KIbWbpmNZ6xCIrbWLf+NboyObat6MYMFPEt"
    "gS0Ee8k4U3Bpk5oNeDiB4s2161jetYV1a17kiYULGDsyTnVlA5/68MU0TR/PNY8/Rk0BZsUSbDABSInjSCbVxZi4yyz2P+F0lB+G"
    "f8PCY8FwrVD2XAhaGHqdiBJjRa/IlIlTWLVutV6+aqVlSXvGimU/v+qMM94dh8E7FoDmxmbZ2tqqx84Y9a3cgHfU2HGjgi9efIkl"
    "PDCy1H1T6sTZXgC2u6no71ADCGOEQQobrRWJpMucgw9nzsGHYgmfYrYYgjJUQGVjE9tWriIRSyBtSaKmikxPBivhCLciTaqmGo0i"
    "39ePE4+TSKfp6urnpeefpX1rOy2PPsm4seNJjdyDow/7IHc+8CATRteS6pc0Zm2SBmoLgmnSRQnBIuOxLvDwjMEHGqw4HZluBoqb"
    "aayrY0tblrxKIrVFUfg88cpSXt7STiOSRkuyNVA0VsSYWOsw6+AjmLbPQfjFggiridvnR4Zs/tABiZIbUlD+0jCRZbAdm1ENI+X9"
    "jz2oLMsee+f9SxcvW7Jm+bvRAvY7C/uQ8+cv0Bd+9qRRm7e0fyqbzevmky+0qipqyPbkkLYccvjEzmBW5X5BeT699DKJUAqd7yUh"
    "FVZ9PYWBXrTUImr1MkYILNuhcmQt+W6fRK6K9vWbqaxqwFQmTOeyVdSPHY0Ti6OMor+7i4bRo6kfNY6f/OjX0NZJt1fkmhOu4JJ9"
    "92f9to18+twvce+jf2Vbex/bOj0apCGoiLPONtgVNg0yxZi0TUPgsSFnk7cNI5XBsqp5Y32OZRtypMxqupZdx7iqWg5qqCdXPQKh"
    "cmjjE/Tk6bE8PNtl9n4HI50Y2mgjtBSDEPftGlVE2RoOpS+HYGeldZZSUshl2XXWbhw59zDz4KOPYlniK8aYe4UQ/2wNMNdav369"
    "Hj951MWZXOaE0U1j/Us/9SkLE1XTpEaU4e+kliW0dbkSQAhhwlBJiEETIAQmyEMhgzQapMDLF8j395LLdIESWK6NkBKjDOmmWjqW"
    "rUUEAb5XoGv1JuonjxH5XJ6aMWOwEw6BF5Dv78ZOJGmqqeXVZa20LG3loLmHcP6Zp7Hktp8SswypETO545F72FwwdEqb3kqbDa6N"
    "l3RJ9hc5oaqK2ak0QYPFnHGVVHYL2oyH5cGEygTjJ1TRHVgMBJoKrTlg7Fg+OHk6u08Yz6yJY5iaqqa3MsVdbZ2s6+xlfMNIJkwa"
    "jwp8tDIIiQhzIjvJBYrh6OdyTVEyB8aAaznUVFfJBx5/RLm2O+G+R299+o1XVq15p1rgnQiAWL9+vbn66nnx199c/efevr6asz90"
    "Bgfsv7/M53JYwg7BmZQBKIdifTGIyy/97NJTlkQIickNgJ/FkjbaQLavg2xPNwCJygoSqeqhBdKQrK4k392H0obAKPRADjsRI9lY"
    "i1GS2nFNBJ5Pf+c2pG2TTtcQFDPc+uQz1Iyo54A5ezFrxh5YqWo6BgpcdfejjOj3mCwdDt1lBAGC9qyPVx3nyS09jHdcmjKaJZbH"
    "+DFJxnZqVnsevQNFagOYtUsTb/blWJLL8fi69XTmBphVW4dt21QIm4Or6hgzqo4/PvYkf7/vfnoGOpm79/7EXZei74kwbzJcW4YQ"
    "c3YoZZdnUMP8CQRewOjRo2hd0arXrN1gSVsmV76xYcGsWa2ytZX/vgBEkqRjlc7RmWz+kkQiof7ros/IZCwujNGDP1aUMDIlAZBm"
    "55kto4WUFn6hgMn1kUwlAI3yPAY62ygWsqQra6isa8KJuVEzZ4gHsByX3q6tDPQP0Lt+Pdn+XpKVVWR7upAxgZcrUjdxNEiLbF8P"
    "vl/AiaWJW3D/wsW8uX4VU8c0UlU/ngFtuPgb32ROUxyvP2D3ZJw3N/Vz0OwRtA3k6c0FVNSmeGpLN7tVuYwdsGlNCWqabGZ2SRZ7"
    "RYxSeNuK7LtHI1u7C1ipBC9t2cK2/j4OmjSW7t4MyfGj0a8u56D99qBl/QaeePE5nn/5dY4++BDqaiopFryoJiAHS8pCiJ2UTcQw"
    "H6GkGbQWxOIxLMsWjz7Rgm0z/oBDdr/+5r+t6ps3D9nS8vZC8A8FYNasWbK1tdWMmzby2/39md0OPuAAdeoJJ1mFfB5Z8vzLPBQR"
    "pX3Fdg6OGETeCyOlzdYXF7HirgfId/WRbKolUB5+Pk+qqppURc0g9t5oMCgsyyUo5nm55V4SiRQDnZ0or8Dmpavo6e2hfkwTQVHh"
    "VLhYcRftB+RzfUjpkk7YPPzcqxgrj1Qb+P21t3DbU4tY359j/Kgqxk2t4fnWbvatifHCxn4OO3AsL61sx3EcYkmX5zd386GJtWxb"
    "U0BPrUAHPnuqGPdn+xll23T2Fth/t0Ze3dBHbU2a19Ztw5ceM1NVbNvaSTzpME4kiNdXsLStg63tHdz/9BN84IADaWocSaGYE6Vm"
    "mJ1VMBlmR81wbSDC/omRTSPEs8+94PdmuhPSsjctf339cyXT/d8RANHa2qrP/sKJ9QPtA78tFILkxz9yLpPGTRSe50U9e2WtU9Hv"
    "lcNy/aUbkhitcFMp1j/7LG0r3qR24iTynZ0se/ARMu3baJoyg+oxowgKRYSAQPl4mSx2PEbcSfDqoqfoal9N04gJJGtrSNc30jRh"
    "PLG4Rb4vQ5DJQypORUMdGMgOdIGWVFSkWLpqHQvfWI4lbdr6NP3GpzKZ5JUt/ezRmEZWxehuy9BkSTqlxYRRaV5d3UltVZqM8dna"
    "mad5agMPvNnN5Nk16HaPejQLdcDUnMZL2YyvT7FkWx+NNZW8sGItc6ZNYKKTpHrqGJR2mCQkb+T76fc1Hb2d3P94C8ceOJcRI+oo"
    "FDxhye02ezvDIHb4KxSAQAVUVFexdUs7L73+okw4iZoVrRuu+uhHP/oPs4LyH2H8APq39B4W+Kp2VOMIf89ddxdeoYglZFmGV+yY"
    "9y/rzAnbohSxygqz7uln6Xj1FVKpSrKdnXgo6qeNxY6lefGKm1j95HNIN4blOKhiEScWw3YcutvbWfvmq0yZtSejp8xm6j77stsx"
    "H2DEtOnUj5vEyKnTsbRF32vLePPvD1LoypDb2odlWXiFLCOqkuTzRTZu8zBuAkeDVyhQl3S54/U29p/ayBbbosYRtK3sYnRDStSm"
    "HPI5n4qKBK9k86zpzbOnga19AX6jw67JOLGcor/aofe1DiY2VjC6wsUXEK9M89fnXkJVxMi2dZOqrcTvz3PWjBkU8nmqKyrY0LaN"
    "0z73GTZs3UwymUAp/Y6w22Y7tIMQEoLAHHrAgdJ1XO15wZyPf/y86YCZN2+efM8C0NjYGBbPdXBcoVg0c2bPNrW1dSLs0R9OrGm2"
    "23pjovK8BGOMcRIJ071mLW/ccTfdm9vY9vKSsGSsi/T35NDYTDvlGNpXruX5K66nmMkhY2FblRDwxuLnSCUETWOm4iZcdOCT7exm"
    "zTPPk2yoYd1LS/FyBfxckcpRo2lfsY76xvGMnj6LyhFjOWiffalLVZD3A5yYgw4UfjaPFIKshpc39jJ1ej3rswETpGDblqzZfWI9"
    "A31ZHNfGTsW4Z0MXe4yuZv3rnSTGpllrBCfUpHi+L8foCpvWpW0cOrWBvKeoqkiyqqObp7ZsQGZz9G1qw6pJs1u6it1GjqSru4/a"
    "6kpWbV7PmV/4PP3ZnHFj7mAZeSc9rztPqYswMVQoFMXUSZPF+PHjgqLv293dHccAPPnkk+9ZAMSCBQvU1VfPiwd+cLhSRuyz517W"
    "24GQxM6ejO5HWjbrWp7C7+2nckSTiI2oEysef5qty9ZRWdtI9cgRrH3ueaomjKVuygQe/8WV9KzcSLK2mq4tm9m44g0axkylom6E"
    "UL4nrLjDskeeonrCWNYufBFbSpQl0LZNxdgR6KDIpAP3IsjnCZDMmjCesY2N+FELuBEhDiHwA1KuzfPrexhTn2QNmpFpl54NA0wY"
    "VRXCRANNuirJ8nyebj+gXrhszBTJpmF03CGW89mUsPDW9ZGIWYxKOxSNIJFOcu+SVlR1nHzOE03TJ1Ds7OXkSZPx8x5e0aOmqoKX"
    "W1v52Ne/ipCWCUGvhkHo0z/q5IheEwSKRDrNnrvNFsVCEd8UjwVoaWnR70kA5s2bJwAeXfTSTN9X46srqvUu02ZIv1gc7NcffvLN"
    "sBhWDAI0NZbr0vZ6K6m6SiYduj/CBKZv3QajtEFl86x79nm6V6xhzO670bNqDf3dvUw9fH/euOUB3rz/CbauW43v5WkcO55sb4/p"
    "7+00G15dQv+WbSIoFnFsi/rJoxGOZSbO3Z/Ni19jl6MPQQUhtt/L9LNxy1Y293QTS4a1eBNojNZoX2ELQ0emSN7zRW1TJT3ZIk6m"
    "iA4U45oqyA7kcWIuQdzhmS297F2TYOv6AerHVtKtBHun4ryaK9IQd1i7voc5oyvIB4qq6gpWd/bxcmcHNdVpM7Ctk62eTwrBrDEj"
    "GOjPEihFQ00dd7c8xvzf/YZkdbUJdLCT9RXbrbUZvu5CglHsvceeUgqJrwv7XjTv7PoweH7rY/uWAlBSHV7BOzBQgZw4fkIwsqkR"
    "z/cHc/7mLat8ke0POyAxWmPpIr3r1qF9TePMGdTNmECqsoKYG6NhwhhybR2se/IpRkybRNy1aF+zniknHMnGxa+xfOHT1I9txHIs"
    "+jo7MFqxquUFqsePNOsXL2Zt63J6t2ylYVyD6G/vJF5fhUhIurZspqt9C8L3eGX5SjozWRK2gzAaaUwI4DQGlEEazfJtOSZPqGFL"
    "UTE2ZdG1bYAJDWn8oo/QhkRFjMU9/dSkJF5vQIULfuCzW2MlvQMedm2MbVsHaKpJkIzQxE7M5dlVG+i2Ax59+RVk3EV09jN36kSy"
    "2TzCGIJAUV9Xyy+uvZq77n2AiuoqlFLbLaoZBkUfrg7C7qTAKzJ14mRRW1MTBCqo6dq6bU4JvfWuBaCxscUAeL6/X9HzmDljOm4i"
    "hlFmGJpXbF/wH569QEpp8D3qJ41mnwvOZtReu7Fp6esoAXt/5Gxqp46jd2Mb6TGjiFcmeePuB+nctJWK2ho2LnqJ2t3HY1VIKioq"
    "cOMpEpW1tK/cgLQlPZs6GBjI4cTidG7rxm2oo3tbO2P234O+zh48zyMIAnr7evnTXY/gFz26+rJ0dA3Q05+lN1ukqzdLV2+W7ECW"
    "hcu3mUxXH629WUy2wPKVHUjPo9ifo7Orn7yv2dKX49V1HSR6c7y5pp1Yby+6OwM9OZZ09xO0ZXh99TYSQZGtnQNo2+aJVRvo788x"
    "Z1QToyoqGBmPs3fDCKoTcYrZQshDZgyxuMsXfvxj1m/YaBKJhNHaMNSBEq2p2flhFiJESTXWNjJh7ETtBT5+vrg/QIk0+13VAhYs"
    "QBljxHGnHbKb0YIpEyfJUgO9KWfPGO7+iWEoABGqpsJAN74fEKtIUjW2Scw6+Siz9dXXWf/U80w4bB/RtOtMVj70jPH9Ap4WeJva"
    "yPb2MfPgfbnl1ltZsm0j9VXr2H9zJ7tPGU/X+nU4KSj2dVM1QpKsqCNAMtC+gopqSe+6V/D9ApaIoVSO7r4+jppYwQdm7BW2fQUa"
    "I32EEigjkQ6gNZZ0GFNpM7uhjlHSZrLxqEymmDO2ASFtLGHjeTnGyRhzbEmvFVA/NmwX++bu48CySZsiXizJMROLdGQCEo7Nus2b"
    "6c71M2lEHW1dfdTNnEhVNsM+UyfxxOut1Lku2hHEYzG2dnXyxZ/+kAW//gNyx2TKEM5x+z0wYU+i4ybF9ClTxMtLF+MXgtkALdFh"
    "fucCEBWkPvLpUxv8ojc+5saZMG68QAXDoEyiTDGJnTgrxhgsaTHQ1826VxYxZvpMEolqUxjIMOOoI+jf2M0bd99naiaOZ875zSy8"
    "5iZiaUmiMkV/fz8v3fkIj762nE3tHUwdOUBcZ1j50msYq4TTt6IydEjkqJUiCHyC4nMIW4bt4lJjS0m1naS+Js6E0Q3kix7aCusY"
    "KtAIo8jmiqxe20dvIcCRgq1oLMswkM1Ta2l04CMIEK5gwFP0Bz42gk2BQUuPuHCRGnJSY/V6bO7tR2uFLywmpirYsGUzMxtrqB8/"
    "lnR1LR0bNrJPUxOPv76MwPOxbBetFfV11dz60EP84robuOzCj5LpK2usMZrtWSiGykND5BVTJ00V2oDW7GKMsYQQaien9a0FoPmM"
    "ZrmABcrPFKeoQFdXV1WqpoZ66fnBUJryLdD+URtedPwlKvCpGzeNbEc761tfJFnRyOiJM8AYUTdxjDnwU+ex5I4HWfv4IvZqPoE3"
    "HnyMzk3bEMpncy5g3bZ26ioTxGybdZszaDUwxAKmS8XEEIUrjQArzKVroweh5FII8jmfqVOq2dYzwPJNnaRTDsZItFLU1aTYuK2X"
    "5cu7GVWdRmsTdgNFLWSBCUICSgHIUrFLlzLbCMuAlmgDSvjoQLC5P4+njXGEJcbVJ8jmffadNQVryXKSeyfpz+bYbWQDDRVpMoUi"
    "ScfCxBzaewf44OyJzLY2oosFETp3ZjhoRJdb3O34inRgxo4ZI1zHwffU2Isv/lgTsGXePEREzvWPBaBkM4pBcWqgFE2NDaqqolIG"
    "gY94B5HJcHfQgJSM32subkWStUteRNoOtu3g53JC2pbZ67zTWN/yAouvv51dTjqCTc+9Qr69gyXLluKjSToOqXgMRHntISowibAV"
    "TBmNRdjUGfE1D/YRCilwpEU6FSfj+QQaRjXV0tGTZc2mDMm4gzGCVMIlEXfCdrGoCQUjcIREGolthZ1BaIEyIS+A1iDtsCFVa4Ow"
    "XbQW9PnaFFUgYsKiOh2nkPdZ09HJQTOm07WtkxETxqJyRXYbN5aWN97Azzk0xF2uaN6T2eNH8KtHFyEnLjJHHHiwyOQy2MIqO2Fi"
    "px64EJJiEIiGmloqUmmV97LpTKZ3IrCltbVZwIJ3lwhSvp4YBD5NjU04sRiDTslbJSV2+nfU5CcEo2buz8yDjqOyupYgUAhLYrSm"
    "2NfPmAPnsOupR9J6/2M0TJ/EyH13Z3VXN45tU5F0I6x9GLoZbQiUxvcDgiBE4BptUEqFcOsSMtEYlNYESqGURghJzLaoSbksem0j"
    "y9Z00t1fIOFKqtIuBnAsiS2j/4SFLKFwhERjCJQiCBSB0gRKhw0ggaIYBKjo+5RSgz2IKvqdcddmxbqtaO0jhKGvUMC1Y8wZ0YBn"
    "YP/GBNc3z0FUjeTUK57ibzc8R9ea9QLHHew13PlKD0UIYbu6pqqiQtTX1SmlNIWCN/7tHMF/AAhR47TS1NfUhmB381bSV/YDtyPg"
    "KkWpIdeuMTWNI7C8IoHxTdjcZpC2Re+WzVSNbGDfC0/lzdseY0N2gG25DHHLIlPwKRQHUCYIUURCoIyOaICj5hGlw44gC9AhV5Bl"
    "SbSK2se1oLCijTm7jcB1BLUVLm+szbD7pEqElKzf2k/vQBFZYoW1QKiQHcQYgzQhO4k2pfZzAyVof7Q0jmWhhUH5YWgnJShl2NqT"
    "RSDYsmEbA0GeXLfHmF3G0/LSUiY0VdI8spqTp9Twu6eWc/uLa5icM/zmK5/hxFNPpdA/EHZWm7KuqLfRwVobUvE4dbV1rFq3Ch9/"
    "9LtGBLUc1qJpAW10oxBQX1v91pDVt9AEJVmJyNtK+H+R6+k1A9s2Uz9uvLBtyyg/QAcBfjGPDhRIwf4XnMZ9X/4emYEsY5pqqatI"
    "ELddgkgALFlGBlXa/KgTyBg9yAccMr6HZkEFBmEJUrEY2VwOKcMO4ap0DF8bcoWAhsokdZUJVMQjbxkLZXxAYhmJL/yQsUQItNRI"
    "HTaqhlSxEVNI2OfCxu6M8LTGsSS1qRiJuMvaLd1s6u2nIVHNwNYuxlgxaj3N5NEjuOj+ZZhigU8deiif+/JX2eXgOaLQn4sEWw5j"
    "pxtywSNnYFh3sgHbpq62BqUCjFYj3n0mMHIWjKZOSEl1VXVo7Hjn7Uw7FIVEyKEarx2BFU+z5rWFDPR14cQSFLIDaBUg7dDRGsjk"
    "WNHZQzLm4ljhgtuWxLEFtiyxdYYgFK31YJevLHUjCYMsW5dcvojWGq0UWmtSMZeYLdh7ei2OY6G1IZ/3ScRsfD/AK3ohWlGAZQtc"
    "IY1lCVwnNCFSgtFh27dSISlFqTtYYLCi7uPS5dgSWwpitsXqre3UWAId+EyYMgYXi554NfXG5u8//iFXLLiRXfbbk2xXL0brMsJK"
    "3n79y9lwhaSqskoYY9DKNL5bARCAecI8YRt0tRAWqYqKMKYTb9/FMkxCRTnKUZRzsdI0bQ/qJuxq1r/xMu0b1+IX8xg0WmkSiTgr"
    "Vq5hxZsrqaxMYTRYUg62XcuosphKxnAdi6rKdMg1RPicY1nYUW+gLUOg+v77zmD8uCZ8z2fZinYyWY+KpEtlwiJX9FiysgPtgWUM"
    "s2ZOZNfdJmGCsEVdREgkHZFIl7p9aqtTJOIutTUVmECHvYkyRDlJOYToEQJsKTHaUBF3Wbl+izFpl3Q6RS6XpWLsCI4ZPYZnH7uP"
    "D37qk+RyOZEfGBCW/Q7gmkK+5aGrqqgMfSCjqt+uJvCW35J/YImljXElgmQsNsSnu4MzsmM1MFROZdAwM4zFF7+Yo37CDGzbZevS"
    "F4hVpUlX16OKGtu2WfziqwS+TzLmhvN7IkdOC0PgaWpr0lz4sePIDHhU1VRz5ZW30tMzgOM4IQGVkBghKBQ9GutqOPHEAyjkfK7/"
    "20Ns2tLJ1s4sxlLkPJ+Cp0nYDqNr0uy95zQ+dNphdHZ3sX5VG7lCEdst6zw2kMkVmTZ9BOd85GgG+n18z+fKP96O1hF5ZOQDaW0G"
    "O4e1AZQmGY+xtatH9PkF0r5g5JSxvPrUC9TvOYMxu0wRma5ObNuKlmx7kut3RwUQj8VKZzb1dqrjLaOAB1Y+gNbaSGlh207khOyM"
    "dVu8vVYwJqLRjKLZiMVBBx6x+tHi3pbX6WrbSq6/ExBkMnmeXfQiFankYNLLV5rAGAp+gG8MW9p7efHlFUybPomXFrfS3tmHMgYv"
    "CAiMwQtCVT96TD1rNrRz3Q0PU11TxSkfOhQvUDRUpfjsR0/kMx8+gc9++CjqEi6VlWmOP/EAcrkc11z7IAUvYNSYegpeQKANAYa8"
    "51NVU8GbqzaxePEK6uvrueueZykEAUU/wPdDkqpioAbZSTSGoh9QDELiyEKxSF/eY9nWbbS+tBRrxEieaXmeQttmY8Xcf6To36ry"
    "Uga5C1fdddwwOTYUuol3iggSALVTsXVP/GKtRM3xR39Aj2xoFIGvwkTgYA98qbVj+4yljBBBMooCNUILETHtiBKMzLYk87/1I55c"
    "+DJTJoxk3KhRvLykldtuvZeqigr8SO3WpsMsm2NLPnLOUUybOpa77n6SNWu28Nxzr/Ohkw9k//1n8caStSFeXkh2mzWBT150MsWc"
    "x8yZ46irq+Xa6x6gtraCRDxGLpdn7qFzuO/+hYxoqkV5ik2btrDHnFlkMzn2nD2N004/nGVvrCGf8VAqoKGukv/63IepSLk8+OBC"
    "lry6ku6ubi7+7CnUVVWxduUmIy0pkvEY3dkCgTY4UlIfJbJijkVPJkdlupJd62uoqq2mIZ5mbGWc9OgR1EyaiioURSmyEW+LDTKD"
    "qXYhhtK3Go0bi7Ny9QrzzIsLrYSbWLty+Ybr3spzf0sNkO/3BysPppR7LgcoiCFShNJ/5bWKEmrFlJkOUd4ybkK4+8SR9axYsZpv"
    "/eDP/OyXf+XyK64hnYjh2NZgntl2LHbbdTJ5z2Ptui0ccfh+nPqhw3n1teWccPxBHH7kvmxY34HtOuw9ZzJaa15dspLHn3yJ5uYj"
    "mTRpFL/+7c3k8wU+8YmT+PiFJ7Jhcwdf+8aVVFQk+exnTuPsc47h9da1XHfdfRxx+N7sve8u3Hrr46xe20ZdQxX77DONnt4sCxe+"
    "zLHHHcjcuXvR2dnFxz9xCrV1tSx9cz2BZcRee00niIgtZNTA4QWKoq/IFwNirsOqDZsYM3mc6N7YLjo3baWzvZd1C59DZXNRWfet"
    "fCzz9smXshAsTIYJysCG5l35ABMmTGBzbw5jdMmWCQYrvEOmwJQM3/aNjMNMRukhU8Kzi4jQCwlMaKpGWpLHH3sKO24xobGWtv4i"
    "Qgq8ok9jQzUf+chxjHyilgW3P4YULkcdty8jRzQwbuxo7rn7ae68+xmaTzuMI47Yg11mTGL5yg2k0gl6egb43eV3IJFcesmZbNvW"
    "iQkEn7zoFJ54fDEf/OBhPP/iG0ydPJFLLjmDP/zuVm688SHO/vDRVFYmOPHYfdll5kSaRtbS3jbA/Q8txAjFIYfsye67TyGRSPDn"
    "v97D2tXb+PC5R7LH7Gls2NCJv7kDhMQQRjC2tJAI4q6LEIpcvscEviX2Oe848er9j5rXXnqFjt//UZz29a+R6WjDcuyyUO/tLIAZ"
    "OqBl4260VpGSMOY9AULO3O9UIxBaa43nBYMcaOItQD96py6B2a5OONQlVPpdOsrgNVRVsPvUMUwdXU/CtcNcvDbEYg5r127h2Wde"
    "4ZRTjuCQg/bg1tuf4LVX3mT33aezYvk67rr3GXadPoY3lqxk5erNTJ8xiWOPPZA999yF319xO4V8kUsvPo1AKf56zf389vLbGOjP"
    "cs45x/Hi4lb+9Je7ufrauxk5op5LLjmT15as4ZYFj3L00QdwyCF70jSilgW3PoHxPSaMb+L+R16kq6uXiRNHs2jhUl56eTmHz53D"
    "IQfN4amWV1i/oQ0nIoYAUMZEWVRBVSrGXruNZsnqNYyYMoon/nwHScthnePwmwduI7d2PfHqKrRW/yDb8jaaQCD8IAhL95Lg7XyA"
    "txSA4477nCcEeW0M+XwhpOUrtfVvn/Q15h+EqTu5lRLfX5Qy9X0Fkdr0g0jrCIHvBYwZ08Q+++3GI4+9wPMvLuP4Y/dn5i4TePW1"
    "N5k6bRzHH7M/b6zYxJjxIxk3ZiQ9PX1s2txGe1sHBx+wK4VCgRdfbKWmqpI9Z09mn71nUltTzYoV65g4rpGpU8ey5x4z0BqefPJV"
    "0hUJ9tp7Btu2dNHV04fn+8zefSIdPVk2b+3igo8cQ2VFBc+/uJTjjj+Aoz6wNw8/upgnWxZzwMF7MGZ0I77vY8mQRFJpgzKG/lyB"
    "UXVpqqZP5I5Hl1JI5s2IsfWmaFmsX72ZfOcmc/HJZ5mO518xbmUKo/RwPoUdFvetHfB8IReaaEvk3m0mMCLhkubYU/fLGjQDAwNR"
    "zDnEyz84masECzc7wsPKOQ52+NtEWdyIT8cSIiy2IHFl1FcWEUR1dw9w110tvPBSK4ceuDunf+gIHn38eW674ylOOvEgTv7QYQS+"
    "YcOmNtau28RDD75EW3sn++y7C+eefSJYAX//+xPYlsuppx6ORYyHHl7E3fe08MlPnCwu+ezpJuamueHGe3h58XI+9amTmTZjPFf8"
    "/k62betg9uzJTJ4yCqTkIx8+lt12n8KVV9zDq68v46JPnMIF5x+PY2zuuOMpNm/uIjuQw3FsfBWuT9yxsKWFCQxKGJzNWxnnC2af"
    "dD7Wttd54L6HWLWtg6PGV3F7Txe//MTn+dbDN5CoaSTwC29JJyd2OF9DzljfwECpEbcnQnjLneUC5Fu0gouIkaJDCugf6Dc7I/kq"
    "z/jsiF3budsylB4ua3qIvF5fKTw/DKkwYW4fKfGKPs89txStDePHN/H0s69x5z3PMnv3qdxz3yIefug5xo0fwbp1bfzthkfZtKmd"
    "MaMbOPbYA3j1teXsutsUPvzho7hlwWM8/sQrPPzICzz0yHPst88srrvuAbN8+UYWLHiEFxa38rnPnUk6nWTDuk2ccvLBOFKaF194"
    "09x08xODWb2//PVu1q3bzN5zpnHdtffzwgtvkEwlCJTi+eeWUvS8QYdJCDFYQFJBQPXIWnRflk6R5eXnlzDxhE+xshs8xyfeAbPG"
    "VfJA91Ye/+nvcdKpcDSd2G7x3urwD47I0/T29xoR8il2v+tawNwn58oWWrS05SYEtHV2RMxcYicpCTNsWtf20lk+ZW1IUIfCRimH"
    "t0IJISF6rETDpg3YcYcgCLj5lifAGI47dj8+eMJc7rv/We57YCFCOFhO2F8oHZtcwefVl5dz592LGD+xnk9/4lQENjff9giu5fLh"
    "s49kzp4zefChaq659n4q02m+8F9nUldVxU9/+TcqKlwO2X9OGFxZlpAS8oUCV/7lXty4ywXnHceuu03kxhsf4drrHsSxYkjbDlnI"
    "tRmkwMOEbKeBDmiqr6BmTC3tyzZjJtfwm9/8khM/eBKKNCIp6eo1jMsXWDK5hjtuu9cc+LGPUjNjsvDzuZ1zCokdS7BCCNCK7t5e"
    "pLQRQmx5z30BGLEBJNva2o1WalgYt8P3G3bgOyk5flKYsh6h8qSFEYbQ3tuWTcwNiRwcGca2RofvizkWjhQkYg5xx6GuOs3M6eN4"
    "5ZVlzJgxlsb6KhKuTdK1cC1BOmYz0DvAnXc8RW1FkmOO3BdpSQo5j4Tr4joWSkURjIKYG35+PueRrkpz4okH0tub5a67n6Lo+8K2"
    "w2WyrLBWMW5MI+l0ksWLlzFt2jiSiRjphEvMsbClxIm4AUvFO9e2QRumTR7BhoEcTn+BGsth3UAnz9/3AONHNJDzPIqVNhUdipE1"
    "Fs+rPAuvvAYnng4LXBE45W2rAiZsG88X83R0dghLWti2u+E98wPYjrPKtm22tm8T+UIOW7ooE4RyE5Ex7+DebV8OHqximlJCkPKh"
    "fyEXcOgH+CpAm5ARYLD0IMAPNLZQUapV0jeQ509X3YcKDI5rUygUsERY1EFGqVcpsGI2gTYoLXjo4ed46MGXSKZsfC/gzruf4dXX"
    "1rH8zbXE4ja5fJHrr3+AM888BikslBHYroUhmj88uCY269Zu5Yorb8MPFI5lhwTPOsz6GQwq9GcHiSMDrbGkoKouTUdnJ1OEjas0"
    "usLl+YXPMX3XaTCg6JvqUL2iyMQxRdaOruXeO+9hxvHHMPXYQygOZI0MBxQMCoMRZigBEwFYHNumo7uDrq4uSwiBZcs15U0+70gA"
    "DjvsMN3S0kIiFl9pW1nT0dFh9fT2MrJ2FEEQDFK9DOkdymY27WgkBn+sCdlARORkhrP9wgJOpuCR9RQWFhpBYAyWFChj6M0WyFly"
    "iGNIQOCriAE0bDrVKvRTjTBhvR6DFoauviK/+N2tKB3g2jFyfX74Q3OGzW1Licdc+oteBCML+MOf7goFSJgQYSSizzVlRBcm1E7S"
    "EpHJMqA8tAwJLI0KzUDY36hp68tSEXPwjUH7PjGtsZTBrUywfMVK5n7gYKpMnO60TbVVpClriNsFltbG0IVc2IQ9rN5Wlnk15bib"
    "UJO2dXaagUxGJuKp/sZ01UaABbcs0DvzG3YqAPPnzzcADaMb1nW09XVmcn0NW9ra1JimcdL4g8mcIfthdqL3y72+KNQTISe7idix"
    "BAIjIybNdMymuiKBUSH0qdClyQcBQkBDVZKYbQ3OD1Qq3HxLhLV+rTVGRQZNCgjCTRO2iJC/OoSTaQvfBJF2ERE1exheaRVR3RiB"
    "HZFehZ8jGEp/l7CIhEMjxJCrayGjMbVhRXB1Zy8FP8CVFg3pGOOaqvACjVAa7SmCQBCrjLNp41bcVJwGN8Watj6cZJHxyxQfOmkO"
    "Z3z6G8ycvSe5/uwg3mGYoz08uYLRGiybdevXGd/3qEpXrf3Nb27q+O1vb+atBlLab5NWEL/97nW9x59y6IpABw2r16w1+87Zv4zs"
    "wQzDpG7vnRg0OxoIEdl9Bk8uQiAtibSskCpGhNPAkALLtjFGYdk2lhVW+MLSb5hGVEQ0BGHKM1LBoQwoYcKNMgITxpshi7dlY0oU"
    "9CJaABGOfzFGG2NCnmEjLYEsA7qXDZTWwgxFMyYUBhPV4Uv5EktaWJZBCguEoLLCJZMtELMlyjcYKUjGHLoHOijkcxyw//4kdD8H"
    "7j6awycdxB7HHImTtEWuPxNtvhlOTb8TIICISpGr1q5WUlqW7VhvCCH025FI2m/XGdzS0hK4MXexY9sHLVu5XKPC41miMTPmrXoC"
    "zQ6TXXeWQDRCkO3vZ6Cnl6QtMb4NysYIxUBvlnxRI6SmXwbEbAttzLAJ3yVVLaIClEaFi4+FsaIUqSqNczPhCBrboFRUqIom9kDY"
    "0i6kBmOJ0mi6EFoWOakyAoKU0uEyXAStdTSYXA5S5WAEvb0DFANFwo7TE2jcKbXkfI3UfggiMZJGbVinfLZt2sB3//ZXvP4B4VZK"
    "EC6F/iz5fAEp7bdN/piycrG0JH6xYJavWo3ruCTc2AvvuTGk5DTEY/bTsVjs0uUrV4q+/l5isdjQlIVB3fMuaeujngEhBUee+EHG"
    "Tp5KXU2aRFyC52C5mk09WYoFkI5iVEUa25FlpNHhTJYymEk0/VtHXcnReDgNaAst/Cgp4ohwlpBACssoE0SHOpphhBISJwSnoBDa"
    "whBy9kthhfl1UcaFFE0WCZs5LZA+AhthJJt6ewmMIS6SVKRh79GK255eglUl0NrgGUnSA18IXnl6Iad9wRPKeGT6fYS2Q60orB3H"
    "Xu8MISRCRzrmumbj5s2sWb/OtmxLu7HYU+U+3bsSgJkzFxiAytr0c509XZlNW7ak1m7cYPaYNUvksoXBkSrvIC09NFS5DNoOCK00"
    "n7js82GIYBQKjWVckCqE9xjLIJQIh0NpdvQ8jdjR3yh9iYqelgaCiIlJhiqhxFEmBqsoDBp3I8OjP8jWKMwQoGVQ4ko2RAxmfIxA"
    "GRXOKzACZOQFKkvomDRq+ZP8ddEKxscLeJkMQTaHkEkq6xppHDcaL5czQkohhRWajXLjWjap3LA9tVxkirXGchyxbOVyNZAZsGuq"
    "K9fsPfvI1uu5e9CnewfUAzvmCQRCH33qvk92dw3M/eyFFwXnf/hcK9s7MMiMXY420CJszhhK9sjB4UzhQ5F9jxjFpI1xpSN0SIVn"
    "ECF4s+AVRGn4s0FHSZAhnD/bR5M7uStR1lM5SFxFOYfhsLUsW+FS00E4LHg4LscMw/oNolyEMRKJG3OFHORN0ChjTLHgC00Qop+6"
    "+o09sIZtr66lp+CJ2jFNjJy2B41jazFFYbRWwohoaFUp1W6GcQZitu+9K+vCTlWk+f7Pf+Q/8OgjTl1d1d/uueXp85qbsRYsQL2n"
    "PEApf+w6zgMxNz530eLn9Tmnn2ZZ0oomZQ2XzqG4vxQz6eF2ypgh+lgh6M9m2Lxpm0EYYdBCa21qK2sYObIpxPEPTuyWkZPDTjuT"
    "zE4qnuGYtwiyzRDhcplmEkJijDGDPDeiHPJe6sQaxm8ohmX4hiCPUvh+YJYvfzMqcVtCGZ94LC4mjBmHMA5aacY2VAs9Yl9GzTwQ"
    "SwoINMoPKBaK4SA7MVx6tTGIKLdRotodZN0oswelGcXd3V28tORVEY/FhOvE7g3t/1wBLe8tEVSyHRVVFffns+oHy1etsNdt3Ggm"
    "j50s8l4uipPNsAyQZVlR7Bzi5k3UIi6EAGXQQhgVaBGrSPPysqVc8tWv4LoWUmB6+vo46+RT+daXv0a2v4+YG0fpIHRwZOi0BYFC"
    "aRXaxyhd7Dh21PgRQYN1mFQySiNtiWPZIUDFqMEZQn40ss227RD3L6UJVCDKp7Y4toWJOo9KU0iU1gRB6EdYUmLbNo5j09nVw8Vf"
    "/RIFvyhs4ZDNZ8ysXWZy/W+vEBiFirSJ9gsYT6CidjalommlUg7jVJBSkEokAYnnFQi8IBxVMxh7mqEEkAI3GeO1xYvMlq1bnarK"
    "qu7xTQ2PA7Q82aLeEZj37Vw2Y4w46fQjXuzoaZ/zyQsuDC44+0IrM9CNLaIRrKWbEwq/YNAmIOcNkLDT4UBEXSQIFKlYCiONEUKK"
    "zECWWNwNJ2t6WbQ2xnFs4m6KeMLFoMn050Q86QKCYqGIbUvqqmshEccbyBiltQj8wGTzWZKJJNpocoW8SLhxamqqQLoUsgP0ZwaM"
    "JW0sR4jA0yitqK6qxASG7oFek4gnKBSKpNNJ4VpO6KBakv7+ARAG13EIAk0xKJqqVCWp6moIfJHL5ugb6Cced40ULr19vUipRXVl"
    "DUoFpncgQ2VFBX4Q8gEqpYnFHIyGgpcnGU9SVVULLhT6siFrulEkExUo5bNk2Rv4XsDkSeOoqxtJIdc/5AqVNKPQmACSFSnm/fR7"
    "/sOPPeo01Nfdcs+Cp856JzME/iH2eO7cuZYQIjj1zGNuiMXcOY8/3aLPOuksy7asQRSI1oZELGbWbF0vTv3wx43SRabNmsC2Dd30"
    "9Q1QP6KS2up63nhjOSNG1HHTlX81P//jH3jg0YdJxpOMGj2CdLqKzs5ttLau4ouXfJaPn/8Jvv6Db5pFLy8iEU8wacJEBjL9orcv"
    "w4lHHWUu/tgnqKqqMH19GS6bP49XX19CPJZg0qRxprO9B03AR888jws+fK54fNEzzPvBz8h5AybuxPnOV78sjjvyaAyG2x64m1//"
    "4c8ce8QR/HDeN0MAh9bE4jFeX/am+fqPvksmk6WqoopRY0ayYf0Gxo4czcWf+ASHzT2Cq2660Vxx7V+xcKiuquQn879tRo8cB2gW"
    "3H8vP/7lbzjumCPMJy+4iG989zusXLOSimQlEyaNEdu2thvXiYuzTz+Z8884F88rkEymePHlV/jCt79OY2MdFalqFr60kGMPOcb8"
    "4NtfFY7lhBqplIUxhpgbZ8vWTeaFl1+UqWRKJGKxG/hnXfPmhQbn4x//8JgPfHC/zH6Hz9LPPfOgMv42ne1ap/N963Wme502Xqda"
    "uPBe1TipVj344M2qWNimTjrzGIWLuuSLH1XFQo+65trfqYbJ1WrT2lfVlvWvqRFTa5RbL9T999+o/Gyb2rjxNXXi6Uepcz56qjLG"
    "qOeffUhVjomrmvEp9eLzD6v2tjX6+FMP11ioM8/7oMr3b1DG71EtLXepxAhLNU2uUa1Ln1KrV76qZu03RZFA/exX31LGKH3Bx89S"
    "2KhPfObDypiMHuhao4v9m5WX2aj2mTtbvbjoIW38dp3pWqvzPev1QOcqbUxOfelrn1a4qONPO1J5hQ59993X6fSImKoYlVCPPXab"
    "Nqpf7X/kbEUM9Z3vX6aMyai+9lUq37dO+Zktat+5e6qnn7pbGWPU3/52uSKN2nWfqap96zLV+vpCNXOfKYoE+kc/+YY2qle3bV6m"
    "Ju46Wh19yiHKeB3amH595VU/1bVjq9Xm9a8pP7NFZ3vW61zvel3o3aAz3Wu08fvVDTf/zt/nsBnm+JMPWTVv3vnxnWD430M1EJg/"
    "H93c3Gz95S83bIrFnPuFRNz76EPBDvQllkVXTy/zvvhVjjnmQ7hALOYiHEEiFseNIc4/7wLxyfM/yuZtbSIej1OZriLmusRiMWwL"
    "xjSN5LrfXS72nbM36D4RT7ginUoSd8Pm0IbGMXzp4ktM1agkDz35OK8ufR1sh0TcJZ1MkozHwQgmTZktPvvRC7Figmtvvgkv12Zq"
    "a2oQtqCyIg34USOlElpDY10tjmNDxCk06PppT9RUVyMcQdyNYRnFBz/4IfOhE09ioDfP1TfdANKIinQFwhFUpCoADymsCO2kaair"
    "F/F4HMiRTCZxEwLXdUBpdtl1bz51/kex4tJcf+tNxs/lzAsvv8TadZuZNH4COGly3V1c9JHzOf2DJ4vevj5hW3KY7bYsi0ImwwOP"
    "PaRTySSJePJv8+dfW4go/sx/WwDKr1ile0U6nWLh84vkijUricfiYR++FBQzA+Kw/Q/kY+ecQ7Z7K4iwkhbW841Aw0BnO1+7+FJ2"
    "32UWmVwunNSrNa7rCmL1dHZ08OaqlVx60ScFxXxYLVRh52+IHcyYRCKO4zhorcnlcgKkUFoLrXU0MVSjVMZUVFRg2YJisUCxmBUl"
    "b9kPAjGYwo7C+ED5bA94FFEQHCg1WBH0g8Dg56mqqMKyJD19/eAHg1UCpVQZ83+UMDDaGK0pzTA2EUw/0Aqls1Sk0liWwA8UQeCB"
    "EKTSLnc9cB8/+cX3jLBcg+3wnS99iZGNIyj6PjKaWhpoTTyZ4tkXF5k3V660Y7FYrn7EiGtKDvw72dN3JACRIyF3++shLbZlP5/J"
    "Zq07H7g3kLGY0bo00Nng2mEWTZaNkA95gsJmvRJ83LWtCG0c1q9fWbqE5xYv5Mvf+y633XuXwQ43fvA0GqipqsKyanj59aV0buxj"
    "2uRJ7LHbbgYvj2VZphT6JZMJLCvNhs2b8fo0E8dPpqJmBH4QDZYWogy1ZAbDSBHOoaYsFxAtkIx6/yxi6SpwbNZv3IgqaPbcdRY4"
    "icH7FKUajRlKkIStDcPZPCQWjQ11WDLNwsWL8ToVh+x3AInKSvadsweTJ06mt6+fH/32VxzxoZO46ZabGDlmNKlUkkCrMtweeEWP"
    "W++9QyXicWnb9t+v/M2165qbm613OjvoHWuAuXPnyvlivk7G0j+rrKgQ9z/yIOvXriERj4cImNKNU0YbLMR20UZY/jFmMJYWru3w"
    "aMsT5k9X/5lb77mLRCI+LAtWQqTfdOft/Ow33+aHv/w5Hzj6UP7y699SVVkFSg2WprQ2LF+9khtv+hM//s1vmTh9DN/98tcBOThe"
    "2AyDWUdVysFy305yDAKEBQN9WV5d8iqXffPL3PPAQ3zguEO4+BMfR+Uz2+XrRVlysYSiDecEl7Rl/0COP91wLV/62qXced/9XPDp"
    "0/nRt+dRzGZFXU01V//2D+w+azf8wGPZijf56Oc+az77xc8bIWxkBLbQWpFMp3lm0SLz8pKXrVQi7dXW1/0MEDNnznzHYOJ3LADR"
    "yHJ5yUVfu8ux7Fczmax9850LtOXGQtKGt8KplKZI6Z10OQhhip7Ply/5HFf94Vr+/uercBwXpIXt2AZCqjUpJdva2/n1lZfT1tbJ"
    "BWedxew9DqS/f0AgrdIJRiv4y43Xcc/DD/CViz/Hk3ffxT6zZwtUTkgZHUMpdgQzGyk0ervfF71OGywHOrq6+c2Vv2dbVxvX/O4K"
    "br/qemoqa9C+P9gWLsoInweLYIOzIURURhDCcR1eaX2N3111JZaU/NdFn6Jx5Eg8z0MgmLPHHB6+5VZ++I1vM2bkaCrSaf58/bXc"
    "etfdJCor0EphSUmhkOfGO25RsXjMkrZYcP0Vdy5rbm5+V5PD3pUP0NzcLA4//PCgMp34TnV1tbjvsYdZtmwZiWQywr1vVwUQokQV"
    "OxzWLIQpnzCSyeaFKnaKQ/Y7gIs/9km6tm4TfQP9wrZtBAZf+cz/8tf42qWfRxnN93/1czate5NUMmmitnURjmmz+MV3vs9NV9/I"
    "N776NUY2NIlsNhseYVmaAq5BheYnmjw+WODZeQOuICjClEmTufoPf+GGK67i/PM+guNY+L4fkWaG2U0VBGil0UYPNocqVZqVErZR"
    "aaNJxGPiT7/4rWg+6UNs6+jgq9+fTyGTE7FkBY898wxLX19KMpXk0s9cwgN/v53pk6chhcXzLy02AIFSxNOVPPjEQ+b1pUtlMpbI"
    "1zbUfOfdnv53LQALFixQ8+Yhb77hwbsdy37a93z7rzdcE4jtmthNlHMPN1CEDBdl32S0FpZl4dgWUgriMRcr5hJzLVHbNJ55P/2J"
    "Wbp8mUmn0oDAsS22btvK+WeczaxdprN63Tp+9afLcdNpgVHR2FiJZQmKBR9voIv+zs7QYbIskJYZ1dSEwbB2wwawLJLxOKmaKrp7"
    "eukbGGD0qJH4nj849KKUOpZRy7cQoAoZ+jq7Rba3SyijhDFgxRM01DdglGH12g1IK2FiMYdUTTW9vb109/aY0U0jQRexbQdLSoxR"
    "FAZyfOGiz9LUUM/Tzy3i1jvvMG6igcWvvczl11yNHa+jq22rGDtpmvjEuedT7A+oqa4RAK7r0N3ZyTV//5tKp1NWzHF++7fL71n1"
    "bk//uxYAgNbWZiGEMDX1VV+pqqzQTz77rHik5TGTrKgkiNiupZRopWnv6MAUDW2dnRFuODyBtu2Qy+VFb38f+UKRre1tJtMzYDa3"
    "d5ivz7+Mm26/jV2mTaOzs5eBTIb+TIau7l4qakbz2Qs/jlKaP113DQ8+eJ8hWU9Xby+ZXJa+gQwDmQxuLIEtw5nCQkqCfFacfMwJ"
    "YtSYRu5/5DHzy1//mu5Mr1m+4k0++rlLmHvAQdSPGInn+YMVRRFl9Tu6uoXxNW0d7RhliMVi4WziUiFQGz5yxhkiWely8523cfW1"
    "V9KbHTArVq4051/yWQ7ebz9Gjx5jMJru7h6KeW36+gdMR1e32XOf/Tj9pJPJ9gZ856c/pmPbGjNj6jSu+ONfuenmq6irq8XP9XPv"
    "I49QUZ/kjJM/hJfLEk8mueqG6/TmLVusRDyxdXTDzJ8A8pZbbnnXQ6Stdy8Araa5udn6+/V3b5i165TRSLPPkmVLg6MPPVwm40l0"
    "hM362R9+b5a0vs74sWNo720X2oN99piNEZps1uNHv/slvf29jB81gaXL3+CBxx7l1rvuZtHi5zlwzv4cefih/Oi3v0UrTUNDLRs2"
    "tLH3njM4aN8D6OjopD/Tz7KVKxkzYoy49pa/YbSiobqJ5etWMHvmrqK2pkYEOsCSFn7gMWrESPbfa45Yv3m9uPO+B8zf776dW++4"
    "g0P3O5T5X/uK8PO5sAwrQ9MQj6d58PH7ueWOuxk1ugk/KLCtvUscuO8+xkKKULFLgmKR6dOmsNsuu7F63Vr+fu/t3Hb3fdxx770c"
    "tN9+4ntf+RpCIpa2LufXf/qjqa1JE3NTbOvaKg6Ys7fYe/c9xIpNy8j2eyxftZwTjjtSKGVxw203c9+TD3PTzXeJnv5O8eff/ErM"
    "2W0PhG146aXXzK+u/K2urq60K5KJT1571S0vNjc3yzPOOONdC4DgvV0S4CMfOaWmc6Dj1faezlEnH3OC+dYXvymzmV6kkGSyeZKJ"
    "OJax8UQBr6BJJRMgNTqAQrFAPO4itUOgiwQ6MLZwhR2zEFri6SKBp0jEExgRUMwpLBdibpyYEze5YobAVyIIFEKC67hIY5PzB3Bk"
    "DDfmoAmHWRphQEEilUSrgC2b2xko9pux48eTjleJXKYntNJGomVIPiVxyHh9uCRwLIdAFshnfJLpBLa0QpRRBBsIREA6UU1QLLCp"
    "YzOFrG8aG+uobRohCr19IAxFzw+HY7oOwkiyxQzxWJx4LImwFH7eUCgWiKUtEol6+rraWL15NWmrxkyZMkZIaVHI+xTJ8anPXxZs"
    "3rrRSVfE73/w9udPOP3009/T3OD3pAFKZry5uVnedNPt2d33nLzBcZwzX319qZowZozYZZeZwssXSKWSg/NvLEsSd+MQwastKYnH"
    "3JJnjG1ZODEHy7IGB4pbUhJz3cGEZjwWQ1qhaQl8X0gphWM7uK6D4ziDreoxNxbiB80Qbq/k5BWKBXzfo75hBHVVKZY/8gy1E8cL"
    "bfyw9jpIQxgCD9yYg21Z4TQkS5CMJyP/YDuomxR4+SIGRW1lDY21dULaUhSy2eg3CBzbxnWcwVxEPB4P2c6CgECHDKwx10XpgGIu"
    "RzzmMmbkSOpqakW+mCdfzJOqrOFXV/5KL3zuBVFdnc7Wjaj80JIXV/c0NzfT0tJi/p0CMGgKbvv7/W9M22XcOMuy9n7upcX+wfvs"
    "Z9XXNlAo5kOAZwTIKAMQIkzYMTuIsjUGjRHChMDOEsyg1F27Pf5QRMDMUs1cl+EBtDFl7SdDmSTbdkik4mDbeNm8ueYzl3L7t39K"
    "zI6JqYfui227OPG4UNqPcCMhHrCEB9WDndqDpFdhUili5rIiUoyQQzAIaeqiYReD9f1hiF49rLey1CgrBFhCorUOuQd9hTIBlbW1"
    "PPjQI+by6y5XjTVNjmvHPrXg2kcfb25uti6//HLNf0eVv9drwYIFGpD77r7HpXE3/mZ/pt/93q9+ooqej+04YWdP2QS57YllRMmR"
    "KiM7Ejsge8TwqoYYDkMVUWgvhiBMJppYNZjlM2C8rMcfz/k4S+55kETdCKTrRIgxCydRz5O/u0rcftl3Qy0TqDL0sxjWkgdiOx6E"
    "7YY7R1pP7ICN245MYye2uLyhpiRg2hgq0mlWrFzBL674XVCRrnAtIW++a8Hj18ydO9d+r6r/nyIAkSkQ8+dfnqmKp8+prqrMvbZ0"
    "qfjZ73+t44lEGUPITtqH3gpFaHaC99rZqomh/kExHKIlooxkWKNybJLVlSilTV93N9d/6jJevuU2ce7vfs5n/34Vx37lUvPwr39u"
    "7pr/U+MXcwZjTKq2xghbmuEcPDvu+FB+Q2wvoWXZLjMcP2bK8yXibV0zrRWu69I3kDHzfva9oOjl3LibWDpt4piPA7KlpUX9N/fv"
    "vZuAclMwd+5c+777Htsya/dx691Y7PRXlywNpK3l/vsdLLx8PoI0lVGnDfaPlVHGiCHba8JZcSG3kDGDKdUQfavLSCYiPOYgWthE"
    "9CPGGIyw3Rj927bx8l33iqmHHivG7zGVJy6/2vSu3ygOvOBMMWb3PUTf5s1cfdHFOMk0n771Gqy45MUb7qR+wngs1xJGmch3iTqC"
    "0MNs0iDZhQEjFOgo429K5kMP/s5SanwHwk8xNHmtZBaMwUgbbBHn6z+cp1994xWrrqqurypdfcyfrrh167x588R7tfv/VAEAWL9+"
    "vZ47d6798P3PvDZ9l/GxeCx52DMvPOONrG+Su+6+p8jnB7CEPUytl4+VK2XcMCKEcCWTOE4M23WwHBfLcbBdF8d1sVwH240jXQfH"
    "cbGixyw3nC5muy6WG0OrQDiJBG8+8Yy54txPYvIFHv3d5VQ2NvC5e28X619azB9OPY99zjhV7HP6KTxzzU2sfu4FVi58nnvm/4I5"
    "pxwnasaMQCBxknEs18Zxwu+1XQfLdaPvsrHdGLbjIl0Lx05gxWws18WxY8hY+JukEw6q2kFhlEG9SwIQ1ieMSKQS/PiXvzYPPfEw"
    "dXVVImGnmhfc+OCi/67d/2eEgTv9rLlz51pPPfVUcOIph92cNwNn5gaC4o++Md859PADRaZzANuxBmcLmxKUrKxMY9sxujdv4tmr"
    "b0QaF215mCB0lyQhBl8ARkuU9JDGDYkjhY/ULkhtjND4eZ99zzyF0bvOxE1Vcd9Pf84NX5nHpNkz+eZTj9KxYi1Xfewi9jj1ZF78"
    "+x189amH6Nu8hZ8c8UGyPT189sarmXPWCaKYy7H80ed5o+VRE4slkMoVys4htDPUjCIVKGGEkWinKCw/jbbyYXo4iGEcn8D3Tbqy"
    "Rsz95PnYsZA6phxRPSgAQqDQCA3Jikrzqyt/bW68eYGqb6h2hTSffuC25/44d+5cO6rL/FMu+58oACaySfLUkw69YMH9j9TqBEd9"
    "84fzvR+637IPPuBwsj1dQjrWdpZ/qMlCBwGp2moOOu9sDBIjgginXyKFjrSGEWgZhJ0+QmBkgNRO2A4qNChhEtUVCCnZ+sZSXrn9"
    "HkaNn8hAWycv3nIb+55xBuPmzOblux5gr1NPIllZxeO/vkK4jmXc0U08d9NtTDp4DomaSsbO3oW6qSOFxAk5p2XYuFEa2kjYTygE"
    "0mjhI1UMLb2oE8nByABjjLCkg7StUumCHTo+QiwrCE0yXcsf//pHrl9wg2qqH+k60pp/z20t//TN/2cLAICZNw/x0Y/OL1x22VEf"
    "Wr5ePprT3v5f/953vB9+XdgHH3wYmd5OhHQjEzpkFzFhaGe5LrXjxkaYeMqbL9h+WsZQydYM9s5HQiJ8v2gsx2HbsuV4mQG+/PAd"
    "vHjHnVx7yZeQdozmn32XF2+5g7kXXsjd3/0hj/zmCvOxa35Hsr6W6z/xRdG3tY10fS2J6jSpxmqEjtj4SjMLdmzaEEYYRERUbcRQ"
    "V3SJbjbwfco627bze0NAczyd5vIr/6Svuulq1dhQ7zp27Df3LHjsO/+Kzf9nm4AyHOE8OX/+fP35z3+sduW61fdki5kDPd8rfusL"
    "X3eOOfZoct19AisKsQxoaZC6NIY+XCwjhzJtO3T/DO+JGeKmKJtebqKGHst28L28Sdc2seLJJ/nFiWdRN2oUX3vqXipGTGXL68/x"
    "0w+cQjyd5gv3/536KePIdw0IJx1HFf1wNi8hM7iJqC7LnddhXTvCDDW/lLfFR/dpolBw+zYFZcLWddeN85MrfmIW3Hpv0NBQ49qO"
    "/PW9C575fNTcoXn3TN3/HidwJ9gBM2/ePPnjH/8qd+HJZ97Wlmk7UBFMfvTxJ71kPGbN2XMfVOChtRaDDN9Rj4FElHnFodE3MsoG"
    "iJ2yD4R9gqXViRRGSbPoIMCOx8TA5nbxq6NPYeSMyXzurgXYjqTlT39k9xOOZuZRR/Lc9bfQ+sgTHHDO6QhLCqWCCHrFsN8S5gXk"
    "YLPGEEHD0G8ewgdEJXEhhrTGdg6gUop4IkbgC+b/7If69gfu1E11I9yY6/zsngVPfRGwWlv/NZv/LxOAciH41g9+UPjaly64ecXa"
    "Dbs6jrvr408/6ff394oD9z1A2JYlfN8Pe/B3GDlvyrphdhZhb6cRynIF5V2DIaV7QDxVQcO0CeLwz3yM6pHjuelzl/HE7/8ERrDv"
    "2WeIKQfMYeJ+e4mGKROF9oKogST6NMl2g7AjggMjBwmiBx8raQW2e892PIshf3RARWUNW9o287XvfEc98/xCWd9Ybaec1JfuXPD4"
    "/Obmf+3m/8tMwM7MgTFGnnT6Eb/0VOHS9s4udeA++5pvXPoVa+SoUQwM9GJjg2Uip8+ULfBwfpwdOLTF0I6X8gUi8idEicIm/Czj"
    "phJoo+hYvoHLzziXYl+vaJy+C5+69S/Ek2mEZVHM5SIcYGkYgwgjlii+L7WFGaEROio0Ddp7PcSQzs45vk3U+WMJSbwyzfOLFvP9"
    "33/f72rrdasrq4tWKvjEvTcuuj6y+epfufn/FgHY7nvMKWcfdmkuW/hFb/+A1VTf6H/x4s/Zhx58MF6mSFEVcaQTAUpMuMBSDzqJ"
    "EYxwODElZXQjpVQgoqwJdchJ1FqjjSJdVcfK5xfy8E//yDm/+6lJNVQKP1eMiBVluV8X/i3N4GYP9Y2WQrmSsJY/Vjawqix9Hc4w"
    "CkgnU/iB5qpbrjF/+9utgZXQbjqZWp8UNecuWHDvM/8qh+9/UgAARHNzs1ywYIE67cxjDsv52asKxcLEXD7rN590qvzkuReJdHWC"
    "XF8OgxHSFggV5gsMUddx2aaUDaIZnCYWjU0KT6ssCQND2iByOFECO25j2Q7aU8YLCkIO2uiS5jHDBaC861kPaYWddfHu0LkswuFR"
    "jmURq0ix7I03zW//dLl6YelzVmPVSGlb8t70SPeTN//h0S3/zs3/dwtACV1st7S0BJ+67NzGzRs2Xu75/mnd3b1MmTjJ+/gFH7GP"
    "OOADoAMyhYywcECG9cGQgYMytI4ZIqsZXHgzjCRq2GaaUE1rqZFGGm0UxhghIzaRYW3tUaJquAYoQwkPYwMxw07+MB8kQu9iCVKp"
    "agb6ernhzpv0zbfergJPuckq20vF0t+7++8t39dG8056+f7jBSACl0Y3Kjj97CM/mi8Wf5rJD9TnCvngAwcdzUfP+bCcOn2yIK/I"
    "FLMIS2IbGy0jtT7EOj7EKaSjEq7QkQBEjGFR+FbKQIYCULbZRpa9xwzLVIKIOCOGqF/Cv+Vg9lIMlruHL6UyCktYJFIp/KDIky2L"
    "zNU3XxOs2LDMratsJG4lnotXis/dcs1jLwJy3rywC+vfvRf/IwJQ5uQLQH/msnPGb9q48XtFL/hIf1+WeNz1jz/2SHHG8efIcRPH"
    "of28KOZ8tFAIKUMGDqJkC1Zk7xnczDC/MDTZq3xjS88PV/cKYaydCECk7gfNwZAAhJpeR6o/iu1N2Olk2zbxVBxVhGdfWmhuvPNv"
    "6tXFK6xE2pHxlN2Vcit+/LW5P/7N3p/c2/93q/z/PQKwgzaAsy447qhcNv+DfDG/T09fL9WpOv/oIw/jxOOPtnaZuDtILQqFLMrT"
    "If+AEEisaIPMdgJQgneVJ5tkWZdOifNPbCcARAJQIpYackSFLvvMkqOpCWcYEg5/tuJxsv19LHz5OX3n3Q/qxa+/aFmOllWxJj+V"
    "jl2Xbkx8/9rf3LWuPEL6n1z//3EBCBcCOb8VQTixXJ724aPO8orFLxe84uz+/n7iyZg6YM9D9DFHHibn7Lm7rKpoBOVR8PIoT4en"
    "UoSz/cKTW7ZZyHLbH4VyQ+nYiMwFaUIyCIMeEgBTOvVmUBi0UGFFWhuEDTEngRVzQSnWbljP4888pR576nG9av1qN24nSCTdwIk5"
    "t9Sma39+/VV3v1LmB/3LQ7z/GAHYmTZYvHix87Pff6s5n8l9JlcoHJQrZAl8zfiJo/25+xwh9tt7jpw6ZZKoSteDVGjfx/c8Aq2i"
    "QdLR3CIRwdFl5EhGwxZFGVjFiBL3YBRxaIlCDRWeROiXWcbCciWuHQPLQQV5trV1mlfeeMU8tWihevm1V2Vvf4+dSqZIxBO9qUTq"
    "9orq6suvvWLBS+H9Yc2cifmfsPX/EQKwM0EQQnLWBUfPzXv5TxSz6oSCn60uFjyEsBg9ZoS/5/R92H2PqXL6pBlydONo4qk4SAu0"
    "QSsPHYQDI1Wkrkv4QVHGEmUGiaMiTB4WWCGQU0p3qGRWNHT0t7Fx4xbTuny5ev61582KN1dbPdkuK2a7xGNJYnF3mePEbmhsqLn+"
    "T79dEBI1N2PNmznP/E+r+/8YAdgubzCYCv361z85es3mtcdn8/kPFfPqIF8XKr2ij288KhLVZsyIkWr8hLFm8rjJjB01VjQ21sna"
    "yjrSqSSxuINrxaLxniHwO0w9R7GlBrQvfBWgitBf7KW/f8D0dGXMxra1Zt2GTWbD+s2s3vam7OkYsHzl49gOMTuGm7JXJp3Uwwk3"
    "fsfXvnTe07vueoY3dOL/d278f4IAbK8RgCG6s8997iPj2gc6DvUL/pEF3zvQLwSTPJ23PS+c3yckJGJxUom0TlckdTpdYSoS1SZZ"
    "4RB341jCRVoh+iYIAvxAkS9mRTabJdNfEL35TpHL5K1iPsDTeQSSuBvDdiwcGet1YnJJzE0+VeFUPHzGGYe+cPzxlxbLcx1PPtmi"
    "hPift/H/JwRgMHI0Rhx22GFWNPpElz3ufOYz503pzrftHhT0Xp7yZwXKn6g80+jrQrUByyiBJghjfiRGi7CLSWiEsUGGnryM+gAt"
    "aWNZds62rC6Q623HWhFzYq+n4olXRzWOX/bjH/2urRzw2dzcbMEgUtr8p6zpf5QAbB85PPnkXNnY2GJ2RoRojJGXfeeTtT3dPY1+"
    "vjBCB6bB83PVthOr9QpFt+gXpTFGGGG0ZSydqkqiAtUjcPpt1+pI2slOO55snzJm144vfelL2Z2t3dy5c63Gxkbzn7bp/ycEYPv7"
    "mDdvnmhtbRXt7e1iew3xz/JH2tvbRWNjo7nllgX6P0G9//8kADu/NwPzvjMkGO/0jSWi7JkzZ5qIZ9fw/vX+9f71/vX+9f71/vX+"
    "9f71/vX+9f71f+L6fxZxR27vyGMzAAAAAElFTkSuQmCC"
)


class App:
    def set_window_icon(self):
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            icon = None
            if APP_ICON_PNG_B64:
                icon = tk.PhotoImage(data=APP_ICON_PNG_B64)
            elif os.path.exists(os.path.join(here, "app_icon.png")):
                icon = tk.PhotoImage(file=os.path.join(here, "app_icon.png"))
            if icon is not None:
                self._window_icon = icon  # keep a reference
                self.root.iconphoto(True, icon)
            ico = os.path.join(here, "app_icon.ico")
            if os.name == "nt" and os.path.exists(ico):
                self.root.iconbitmap(ico)
        except Exception:
            pass

    def __init__(self, root, on_exit=None, title_prefix=""):
        # on_exit: called when the module is left (when started from Pūrlāde)
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        os.makedirs(PHOTO_DIR, exist_ok=True)
        if on_exit is None:  # stand-alone: own window size and icon
            root.geometry("1240x820")
            self.set_window_icon()
        root.minsize(1000, 680)
        root.configure(bg=CREAM)
        self.windows = {}
        self.current_view = None      # None = main view (Pārskats), otherwise a view class
        self.view_widget = None
        self.panels = []
        self.card_vars = {}
        self.load_labels()
        self.setup_style()
        self.build_ui()

    # ---- labels ---------------------------------------------------------
    def load_labels(self):
        # column names are fixed; only the collective name (Administrēšana) comes from the settings
        self.labels = dict(DEFAULT_LABELS)
        for k, v in self.db.q("SELECT key, value FROM settings WHERE key='app.group_name'"):
            if v.strip():
                self.labels[k] = v

    def L(self, key):
        return self.labels.get(key, key)

    # ---- logos (collective logo + program logo) ---------------------------
    # kind -> (settings key, file name prefix)
    LOGOS = {"group": ("logo.file", "logo"), "app": ("logo.app", "plogo")}

    def logo_path(self, kind="group"):
        key = self.LOGOS[kind][0]
        rows = self.db.q("SELECT value FROM settings WHERE key=?", (key,))
        if rows and rows[0][0]:
            path = os.path.join(APP_DIR, rows[0][0])
            if os.path.exists(path):
                return path
        return None

    @staticmethod
    def load_image(path, max_w, max_h):
        """PNG/GIF work out of the box; JPG needs the optional Pillow package."""
        try:
            from PIL import Image, ImageTk
        except ImportError:
            img = tk.PhotoImage(file=path)
            f = max(-(-img.width() // max_w), -(-img.height() // max_h), 1)
            return img.subsample(f) if f > 1 else img
        img = Image.open(path)
        img.thumbnail((max_w, max_h))
        return ImageTk.PhotoImage(img)

    def logo_image(self, max_w, max_h, kind="group"):
        path = self.logo_path(kind)
        if not path:
            return None
        try:
            return self.load_image(path, max_w, max_h)
        except Exception:
            return None

    def finish(self):
        # save everything and close the program
        if not self.confirm_leave_view():
            return
        try:
            self.db.con.commit()
            self.db.con.close()
        except Exception:
            pass
        self.root.destroy()

    def back_to_purlade(self):
        # leave the module and return to the Pūrlāde start page
        if not self.confirm_leave_view():
            return
        for win in list(self.windows.values()):
            if win.winfo_exists() and hasattr(win, "dirty") and win.dirty():
                win.lift()
                if not messagebox.askyesno("Nesaglabātas izmaiņas",
                                           "Atvērtajā logā ir nesaglabātas izmaiņas. Vai atmest tās?",
                                           parent=win):
                    return
        for win in list(self.windows.values()):
            if win.winfo_exists():
                win.destroy()
        self.windows = {}
        try:
            self.db.con.commit()
        except Exception:
            pass
        self.on_exit()

    # ---- style ----------------------------------------------------------
    def setup_style(self):
        izskats.apply_style()   # kopīgais izskats (Pūrlāde v0.8)

    # ---- windows --------------------------------------------------------
    def open_window(self, cls):
        win = self.windows.get(cls)
        if win is not None and win.winfo_exists():
            win.deiconify()
            win.lift()
            win.focus_set()
            return win
        win = cls(self)
        fit_min_size(win)
        self.windows[cls] = win
        return win

    def refresh_all(self):
        self.refresh_header()
        self.refresh_dashboard()
        view = self.view_widget
        if view is not None and view.winfo_exists() and hasattr(view, "refresh"):
            view.refresh()
        for win in list(self.windows.values()):
            if win.winfo_exists() and hasattr(win, "refresh"):
                win.refresh()

    # ---- header and tabs ------------------------------------------------
    TABS = None   # filled in build_ui: (view class, tab text)

    def build_ui(self):
        for child in self.root.winfo_children():
            if not isinstance(child, tk.Toplevel):
                child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")
        self.view_widget = None

        # Pūrlāde v0.8: baltā moduļa galvene ar cilnēm (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = izskats.module_header(
            self.root, "terpu_purs", PROGRAM_NAME, f"Tērpi, izsniegšana un noliktava · v{APP_VERSION}",
            on_logo=self.show_main, on_exit=None if self.on_exit is not None else self.finish, tabs=True)
        # shown only on the main view: what the four charts show
        self.settings_btn = izskats.header_button(self.header_right, "⚙ Pārskata iestatījumi",
                                                  lambda: self.open_window(MainSettingsWindow))
        self.tabs = self.header_right.tabs
        self.nav_buttons = {}
        for cls, text in ((None, "Pārskats"), (IssueWindow, "Izsniegt"), (ReturnWindow, "Atgriezt"),
                          (CatalogWindow, "Noliktava"), (CheckoutsView, "Izsniegtie"),
                          (FinesView, "Soda naudas")):
            self.nav_buttons[cls] = self.tabs.add(cls, text, lambda c=cls: self.open_tab(c))

        self.content = tk.Frame(self.root, bg=CREAM)
        self.content.pack(fill="both", expand=True)
        self.refresh_header()
        self._render_view(self.current_view)

    def refresh_header(self):
        """Counts in the header (“412 tērpa detaļas · 27 izsniegtas”) and on the “Izsniegtie” tab."""
        try:
            total, out = self.db.q(
                "SELECT COUNT(*), SUM(CASE WHEN s=? THEN 1 ELSE 0 END) FROM "
                "(SELECT " + STATUS_EXPR.format(p="p.id") + " AS s FROM costume_pieces p)", (CHECKED_OUT,))[0]
        except Exception:
            return
        total, out = total or 0, out or 0
        one = total % 10 == 1 and total % 100 != 11
        sub = self.header_right.subtitle
        if sub is not None:
            sub.configure(text=f"{total} {'tērpa detaļa' if one else 'tērpa detaļas'} · {out} izsniegt"
                               f"{'a' if out % 10 == 1 and out % 100 != 11 else 'as'} · v{APP_VERSION}")
        tab = self.nav_buttons.get(CheckoutsView)
        if tab is not None:
            tab.configure(text=f"Izsniegtie ({out})")

    # ---- views (switched inside this same window) -------------------------
    def _render_view(self, cls):
        for child in self.content.winfo_children():
            child.destroy()
        self.current_view = cls
        self.view_widget = None
        self.panels = []
        if cls is None:
            self.build_main_view(self.content)
        else:
            self.view_widget = cls(self, self.content)
            self.view_widget.pack(fill="both", expand=True)
        if cls is None:
            self.settings_btn.pack(side="right")   # only on the main view
        else:
            self.settings_btn.pack_forget()
        self.tabs.set_active(cls)   # the open view's tab
        return self.view_widget

    def open_tab(self, cls):
        """A tab was clicked: open that view (the open tab stays open). Returns the view widget."""
        if cls is self.current_view:
            return self.view_widget
        if not self.confirm_leave_view():
            return None
        return self._render_view(cls)

    def show_view(self, cls):
        if cls is self.current_view:
            if cls is None:
                return
            cls = None  # pressing the button of the open view returns to the main view (after the check below)
        if not self.confirm_leave_view():
            return
        self._render_view(cls)

    def confirm_leave_view(self):
        """True when the open view may be left: nothing unsaved, or the user chose to discard or to save;
        “Palikt” keeps the view open."""
        view = self.view_widget
        if view is None or not hasattr(view, "dirty") or not view.dirty():
            return True
        choice = ask_unsaved(self.root)
        if choice == "discard":
            return True
        if choice == "save":
            saver = getattr(view, "do_return", None) or getattr(view, "save", None)
            return bool(saver and saver())
        return False

    def show_main(self):
        self.show_view(None)

    # ---- shortcuts (Pārskats cards, Pūrlāde start page) --------------------
    def show_issued(self, overdue=False):
        """Open “Izsniegtie” (overdue=True: only costumes kept longer than 30 days)."""
        view = self.open_tab(CheckoutsView)
        if isinstance(view, CheckoutsView):
            view.mode.set("active")
            view.overdue.set(overdue)
            view.refresh()
        return view

    def show_catalog(self, **filters):
        """Open “Noliktava” with the given filters (status=…, condition=…)."""
        view = self.open_tab(CatalogWindow)
        if isinstance(view, CatalogWindow):
            for v in view.filters.values():
                v.set(ALL)
            view.search.set("")
            for key, value in filters.items():
                view.filters[key].set(value)
            view.refresh()
        return view

    def show_checkouts_popup(self):   # name kept for older callers
        return self.show_issued()

    # ---- main view (Pārskats) -------------------------------------------
    def build_main_view(self, parent):
        cards = tk.Frame(parent, bg=CREAM)
        cards.pack(fill="x", padx=20, pady=(16, 0))
        self.card_vars = {}
        specs = [
            ("total", "Kopā tērpu", NAVY, lambda: self.show_catalog()),
            ("avail", AVAILABLE, OK_FG, lambda: self.show_catalog(status=AVAILABLE)),
            ("out", "Izsniegti", RED, lambda: self.show_issued()),
            ("overdue", f"Ilgāk par {OVERDUE_DAYS} dienām", WARN_FG, lambda: self.show_issued(overdue=True)),
            ("fix", "Jālabo", "#8A4A1F", lambda: self.show_catalog(condition="Jālabo")),
        ]
        for i, (key, title, colour, command) in enumerate(specs):
            cards.columnconfigure(i, weight=1, uniform="k")
            card = tk.Frame(cards, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1, cursor="hand2")
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0 if i == len(specs) - 1 else 5))
            tk.Frame(card, bg=colour, width=4).pack(side="left", fill="y")
            inner = tk.Frame(card, bg=WHITE)
            inner.pack(side="left", fill="both", expand=True, padx=14, pady=10)
            value, sub = tk.StringVar(value="0"), tk.StringVar()
            self.card_vars[key] = (value, sub)
            widgets = [card, inner,
                       tk.Label(inner, text=title, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w"),
                       tk.Label(inner, textvariable=value, bg=WHITE, fg=colour, font=("Georgia", 22, "bold"),
                                anchor="w"),
                       tk.Label(inner, textvariable=sub, bg=WHITE, fg=MUTED, font=FONT_SMALL, anchor="w")]
            for w in widgets[2:]:
                w.pack(fill="x")
            for w in widgets:
                w.configure(cursor="hand2")
                w.bind("<Button-1>", lambda e, c=command: c())

        grid = tk.Frame(parent, bg=CREAM)
        grid.pack(fill="both", expand=True, padx=20, pady=(12, 16))
        self.panels = []
        for i in range(4):
            grid.columnconfigure(i % 2, weight=1, uniform="col")
            grid.rowconfigure(i // 2, weight=1, uniform="row")
            panel = ChartPanel(grid, self, i)
            panel.grid(row=i // 2, column=i % 2, sticky="nsew", padx=(0, 6) if i % 2 == 0 else (6, 0),
                       pady=(0, 6) if i < 2 else (6, 0))
            self.panels.append(panel)
        self.refresh_dashboard()

    def refresh_dashboard(self):
        if self.current_view is not None or not self.panels:
            return  # dashboard widgets only exist while the main view is shown
        total, avail, out = self.db.q(
            "SELECT COUNT(*), SUM(CASE WHEN s=? THEN 1 ELSE 0 END), SUM(CASE WHEN s=? THEN 1 ELSE 0 END) FROM "
            "(SELECT " + STATUS_EXPR.format(p="p.id") + " AS s FROM costume_pieces p)",
            (AVAILABLE, CHECKED_OUT))[0]
        total, avail, out = total or 0, avail or 0, out or 0
        dates = [d for (d,) in self.db.q("SELECT checkout_date FROM checkouts WHERE "
                                         "TRIM(COALESCE(return_date,'')) = ''")]
        overdue = sum(1 for d in dates if (days_since(d) or 0) > OVERDUE_DAYS)
        fix, broken = self.db.q("SELECT SUM(CASE WHEN condition_notes=? THEN 1 ELSE 0 END), "
                                "SUM(CASE WHEN condition_notes=? THEN 1 ELSE 0 END) FROM costume_pieces",
                                ("Jālabo", "Nelietojams"))[0]
        dancers = self.db.q("SELECT COUNT(DISTINCT dancer_id) FROM checkouts WHERE "
                            "TRIM(COALESCE(return_date,'')) = ''")[0][0] or 0
        pct = lambda n: f"{round(100 * n / total)} % no visiem" if total else ""
        values = {
            "total": (total, "klikšķis — atvērt noliktavu"),
            "avail": (avail, pct(avail)),
            "out": (out, f"{dancers} dejotājiem"),
            "overdue": (overdue, "jāatgādina dejotājiem" if overdue else "visi nesen"),
            "fix": (fix or 0, f"nelietojami: {broken or 0}"),
        }
        for key, (value, sub) in values.items():
            self.card_vars[key][0].set(str(value))
            self.card_vars[key][1].set(sub)
        for panel in self.panels:
            panel.refresh()


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            # with the console hidden errors would vanish: write them to a log and tell the user
            text = "".join(traceback.format_exception(exc, val, tb))
            log_error(text)
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        text = traceback.format_exc()
        log_error(text)
        set_console_visible(True)
        print(text)
        try:
            messagebox.showerror("Kļūda", f"Programma nevarēja startēt.\n\nDetaļas: {ERROR_LOG}")
        except Exception:
            pass


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


if __name__ == "__main__":
    main()
