#!/usr/bin/env python3
"""
Pūrlāde — Zelta pūrs: imports no kolektīva kases Excel tabulas

Tabulas uzbūve (tāda, kādu līdz šim veda kasieri):
  * “Fonds A”, “Fonds B” …  — dalības maksas: rindās dejotāji, kolonnā B maksa mēnesī šajā sezonā, kolonnā C —
    iepriekšējā sezonā (kura kolonna kurai sezonai — redzams formulās rindā “Plānotā summa”); kolonnu virsraksti
    “15/09/25” … ir mēneši, pārējās kolonnas — iemaksas par autobusiem, ballēm, nometnēm (“Sabiles autobuss (10 €)”).
    Šūnā: datums (kad samaksāts) vai ✓ — samaksāts; skaitlis — samaksātā summa; x — nav jāmaksā / nebrauc;
    tukšs — nav samaksāts. Kolonna bez virsraksta ar summām + nākamā kolonna ar virsrakstu un datumiem — viena iemaksa.
  * “Tērpi A”, “Tērpi B” — tērpu fonds: pusgada maksas (kolonnas “30/12/25” — 1. pusgads, “30/06/26” — 2. pusgads).
  * “Bilance A 2526” … — izdevumi: bloki ar virsrakstu ar kolu (“Dāvanas koncertiem:”, “AUTOBUSI:” …), zem tā
    rindas: nosaukums, summa, datums, kam / kas maksāja. Saraksts “Maksājumi ar rēķiniem” un kopsavilkumi netiek
    ņemti (tie atkārto tos pašus izdevumus).

Grupas burts (A, B …) tiek piesaistīts Pūrlādes grupai (piem., B → Studija). Katram ierakstam ir importa atslēga
(lapa + šūna), tāpēc importu var atkārtot: jau ievestais netiek dublēts, tiek pievienots tikai jaunais.
Lasa .xlsx ar standarta bibliotēku (zipfile + xml), Excel / openpyxl nav vajadzīgs.
"""

import re
import sqlite3
import traceback
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from difflib import SequenceMatcher

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:
    from moduli import piekluve
    from moduli.kopeja import (_norm, log_error, full_name, DANCER_GROUPS, STATUS_ACTIVE, ROLE_DANCER,
                               CREAM, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:
    import piekluve
    from kopeja import (_norm, log_error, full_name, DANCER_GROUPS, STATUS_ACTIVE, ROLE_DANCER,
                        CREAM, RED, NAVY, GOLD, WHITE, GREEN, GREY)

INCOME = "Ienākumi"
EXPENSE = "Izdevumi"
CASH = "Skaidrā naudā"
BANK = "Pārskaitījums"
FEE_CATEGORY = "Dalības maksa"
CAT_EXTRAS = "Iemaksas par autobusiem un pasākumiem"
CAT_COSTUME = "Tērpu fonds"
NOT_IMPORTED = "— neimportēt —"

KIND_FEES = "fees"
KIND_EXTRAS = "extras"
KIND_COSTUME = "costume"
KIND_EXPENSES = "expenses"
KIND_INCOMES = "incomes"
KIND_TITLES = {KIND_FEES: "Dalības maksas (lapas “Fonds”)",
               KIND_EXTRAS: "Iemaksas par autobusiem, ballēm, nometnēm (lapas “Fonds”)",
               KIND_COSTUME: "Tērpu fonds (lapas “Tērpi”)",
               KIND_EXPENSES: "Izdevumi (lapas “Bilance”)",
               KIND_INCOMES: "Papildu ienākumi — koncerti, avansi u.c. (lapas “Bilance”)"}
KINDS_ORDER = (KIND_FEES, KIND_EXTRAS, KIND_COSTUME, KIND_EXPENSES, KIND_INCOMES)

# expense block headings -> category of Zelta pūrs (Izdevumi). Not found -> "Citi izdevumi".
EXPENSE_CATEGORIES = [
    ("viesiem par deju", "Atlīdzība viesu horeogrāfiem"),
    ("davan", "Dāvanas"),
    ("paldies", "Dāvanas"),
    ("terp", "Tērpi un apavi"),
    ("autobus", "Transports"),
    ("transport", "Transports"),
    ("bank", "Bankas komisijas"),
    ("koncertu dalibas", "Dalības maksas festivālos un skatēs"),
    ("dalibas maks", "Dalības maksas festivālos un skatēs"),
    ("pasakum", "Kolektīva pasākumi"),
    ("uzved", "Uzvedums"),
    ("repet", "Repetitora atlīdzība"),
    ("citi", "Citi izdevumi"),
]
NEW_CATEGORIES = {INCOME: [CAT_EXTRAS, CAT_COSTUME],
                  EXPENSE: ["Dāvanas", "Uzvedums", "Repetitora atlīdzība", "Atlīdzība viesu horeogrāfiem"]}


# ==========================================================================
# Reading .xlsx (standard library only)
# ==========================================================================
NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
DATE_FORMAT_IDS = set(range(14, 23)) | {45, 46, 47}


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def col_index(ref):
    letters = re.match(r"[A-Za-z]+", ref).group(0).upper()
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n


def col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def ref_of(row, col):
    return f"{col_letter(col)}{row}"


class Sheet:
    def __init__(self, name, hidden=False):
        self.name, self.hidden = name, hidden
        self.cells = {}      # (row, col) -> value: str / float / int / date
        self.formulas = {}   # (row, col) -> formula text
        self.max_row = self.max_col = 0

    def get(self, row, col):
        return self.cells.get((row, col))

    def text(self, row, col):
        v = self.cells.get((row, col))
        return v.strip() if isinstance(v, str) else ""


def _is_date_format(code):
    code = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', "", code or "").lower()
    return bool(re.search(r"[dy]", code)) or ("m" in code and "s" not in code and "h" not in code and "0" not in code)


def read_workbook(path):
    """{sheet name: Sheet} with every sheet (also hidden ones)."""
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")):
                if _local(si.tag) != "si":
                    continue
                parts = []
                for el in si:   # plain text or rich-text runs; phonetic hints (rPh) are not part of the text
                    if _local(el.tag) == "t":
                        parts.append(el.text or "")
                    elif _local(el.tag) == "r":
                        parts.extend(t.text or "" for t in el if _local(t.tag) == "t")
                shared.append("".join(parts))
        date_styles = set()
        if "xl/styles.xml" in names:
            st = ET.fromstring(z.read("xl/styles.xml"))
            custom = {}
            for el in st.iter():
                if _local(el.tag) == "numFmt":
                    custom[int(el.attrib.get("numFmtId", 0))] = el.attrib.get("formatCode", "")
            xfs = next((el for el in st if _local(el.tag) == "cellXfs"), None)
            if xfs is not None:
                for i, xf in enumerate(x for x in xfs if _local(x.tag) == "xf"):
                    fid = int(xf.attrib.get("numFmtId", 0))
                    if fid in DATE_FORMAT_IDS or (fid in custom and _is_date_format(custom[fid])):
                        date_styles.add(i)
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = {r.attrib["Id"]: r.attrib["Target"] for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))}
        date1904 = any(_local(el.tag) == "workbookPr" and el.attrib.get("date1904") in ("1", "true")
                       for el in wb.iter())
        base = date(1904, 1, 1) if date1904 else date(1899, 12, 30)
        book = {}
        for el in wb.iter():
            if _local(el.tag) != "sheet":
                continue
            target = rels.get(el.attrib.get(NS_REL), "")
            path_in_zip = target.lstrip("/") if target.startswith("/") else "xl/" + target
            if path_in_zip not in names:
                continue
            sh = Sheet(el.attrib.get("name", ""), el.attrib.get("state", "visible") != "visible")
            for row in ET.fromstring(z.read(path_in_zip)).iter():
                if _local(row.tag) != "row":
                    continue
                for c in row:
                    if _local(c.tag) != "c" or "r" not in c.attrib:
                        continue
                    m = re.match(r"([A-Z]+)(\d+)", c.attrib["r"])
                    col, r = col_index(m.group(1)), int(m.group(2))
                    kind = c.attrib.get("t")
                    style = int(c.attrib.get("s", 0))
                    v = next((x.text for x in c if _local(x.tag) == "v"), None)
                    f = next((x.text for x in c if _local(x.tag) == "f"), None)
                    if f:
                        sh.formulas[(r, col)] = f
                    if kind == "inlineStr":
                        value = "".join((x.text or "") for x in c.iter() if _local(x.tag) == "t")
                    elif v is None:
                        continue
                    elif kind == "s":
                        value = shared[int(v)]
                    elif kind in ("str", "e"):
                        value = v
                    elif kind == "b":
                        value = v == "1"
                    else:
                        try:
                            num = float(v)
                        except ValueError:
                            value = v
                        else:
                            if style in date_styles and 1 <= num < 80000:
                                value = base + timedelta(days=int(num))
                            else:
                                value = int(num) if num == int(num) else num
                    if value is None or (isinstance(value, str) and not value.strip()):
                        continue
                    sh.cells[(r, col)] = value
                    sh.max_row, sh.max_col = max(sh.max_row, r), max(sh.max_col, col)
            book[sh.name] = sh
        return book


# ==========================================================================
# Values: dates, money, names
# ==========================================================================
def season_of(d):
    return d.year if d.month >= 9 else d.year - 1


def season_label(start):
    return f"{start}/{start + 1}"


def header_date(text):
    """'15/09/25' / '30.12.2025' -> date; anything else -> None."""
    m = re.fullmatch(r"\s*(\d{1,2})[/.](\d{1,2})[/.](\d{2}|\d{4})\s*", str(text or ""))
    if not m:
        return None
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    y += 2000 if y < 100 else 0
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def is_x(v):
    return isinstance(v, str) and v.strip().lower() in ("x", "-", "–")


def is_mark(v):
    """A sign that something is paid without a date (✓, v, +, 'jā')."""
    return isinstance(v, str) and v.strip().lower() in ("✓", "✔", "v", "+", "ja", "jā", "ok")


def to_cents(v):
    """Number or '12,50' / '60.28' -> cents; None when it is not an amount."""
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return int(round(v * 100))
    t = str(v).replace("€", "").replace("eur", "").replace("EUR", "").replace(" ", "").strip()
    if re.fullmatch(r"-?\d+([.,]\d{1,2})?", t):
        return int(round(float(t.replace(",", ".")) * 100))
    return None


def _candidates(v, ref):
    """Possible dates for a cell: as given, with day and month swapped (Excel sometimes reads 08/10 as August 10),
    and for 'dd/mm' without a year — the year before, of and after the reference date."""
    out = []
    if isinstance(v, datetime):
        v = v.date()
    if isinstance(v, date):
        base = [v]
        if v.day <= 12 and v.day != v.month:
            try:
                base.append(date(v.year, v.day, v.month))
            except ValueError:
                pass
        for b in base:   # the year is sometimes typed wrong (a date in the future): also the year before
            out.append(b)
            try:
                out.append(b.replace(year=b.year - 1))
            except ValueError:
                pass
        return out
    text = re.sub(r"\(\s*\+\s*\d+\s*\)", "", str(v or ""))   # '23/01 (+1)' — paid also for a guest
    text = re.sub(r"([/.])\1+", r"\1", text)                     # '17//01'
    m = re.fullmatch(r"\s*(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2}|\d{4}))?\.?\s*", text)
    if not m:
        return out
    d, mo = int(m.group(1)), int(m.group(2))
    years = [int(m.group(3)) + (2000 if len(m.group(3)) == 2 else 0)] if m.group(3) else \
        [ref.year - 1, ref.year, ref.year + 1]
    for y in years:
        try:
            out.append(date(y, mo, d))
        except ValueError:
            pass
    return out


def pay_date(v, ref, before=200, after=400, prefer=None, trust=False):
    """The payment date in a cell, as close to `ref` as possible; None when there is no usable date.
    Dates after today are not possible. prefer=(first, last): a date inside this period wins (Bilance: the season)."""
    today = date.today()
    cands = _candidates(v, ref)
    if trust and cands and isinstance(v, (date, datetime)) and prefer and prefer[0] <= cands[0] <= prefer[1] \
            and cands[0] <= today:
        return cands[0]   # a real date inside the period: as written
    ok = [c for c in cands if -before <= (c - ref).days <= after and c <= today]
    if prefer:
        inside = [c for c in ok if prefer[0] <= c <= prefer[1]]
        ok = inside or ok
    return min(ok, key=lambda c: abs((c - ref).days)) if ok else None


def guests(v):
    """'23/01 (+1)' -> 1 (the dancer paid also for one guest)."""
    m = re.search(r"\(\s*\+\s*(\d+)\s*\)", v) if isinstance(v, str) else None
    return int(m.group(1)) if m else 0


def parse_price(title):
    """'Sabiles autobuss (10 €)' -> 1000; '(11+7,26 €)' -> 1826; 'Zemītes autobuss (12€) Balle (3€)' -> 1500;
    '(6 / 7 €)' (two prices) or no price -> None."""
    total = 0
    found = False
    for group in re.findall(r"\(([^)]*)\)", title or ""):
        g = group.lower().replace("eur", "").replace("€", "")
        g = re.sub(r"\(.*", "", g)
        if "/" in g:
            return None
        nums = re.findall(r"\d+(?:[.,]\d+)?", g)
        if not nums:
            continue
        parts = re.split(r"\+", g)
        if len(parts) > 1:   # '11+7,26' or '26,5 + ēšana' (only the numbers that are there)
            value = sum(float(n.replace(",", ".")) for n in nums)
        else:
            value = float(nums[0].replace(",", "."))
        total += value
        found = True
    return int(round(total * 100)) if found else None


def clean_title(text):
    return " ".join(str(text or "").split())


class Matcher:
    """Finds a Kopas pūrs person by the name written in the table (case, diacritics, extra spaces and small
    typos do not matter; a person of the same group is preferred)."""

    def __init__(self, dancers):
        self.dancers = list(dancers)
        self.by_norm = defaultdict(list)
        for d in self.dancers:
            self.by_norm[_norm(d["name"])].append(d)

    def find(self, name, group=None):
        key = _norm(name)
        if not key:
            return None
        hits = self.by_norm.get(key)
        if not hits:   # first + last word ('Ēriks Jānis Krakops' -> 'Ēriks Krakops')
            words = key.split()
            if len(words) > 2:
                hits = self.by_norm.get(f"{words[0]} {words[-1]}")
            if not hits:
                hits = [d for k, ds in self.by_norm.items() for d in ds
                        if len(k.split()) > 2 and k.split()[0] == words[0] and k.split()[-1] == words[-1]]
        if not hits:   # small typos: 'Alise Elīze' / 'Alise Elīza'
            scored = []
            for k, ds in self.by_norm.items():
                r = SequenceMatcher(None, k, key).ratio()
                if r >= 0.9:
                    scored.extend((r, d) for d in ds)
            scored.sort(key=lambda x: -x[0])
            hits = [d for _r, d in scored[:3]]
        if not hits:
            return None
        same = [d for d in hits if d["group"] == group]
        return (same or hits)[0]


# ==========================================================================
# Reading the table into a plan
# ==========================================================================
class Plan:
    def __init__(self):
        self.fees = []        # dict(name, group, month, cents, date, key, sheet)
        self.due = []         # dict(name, group, month, cents) — what this dancer has to pay that month
        self.rates = []       # dict(group, start, end, cents)
        self.extras = []      # dict(name, group, title, cents, date, key)
        self.costume = []     # dict(name, group, title, cents, date, key)
        self.expenses = []    # dict(group, date, category, text, cents, notes, method, key, dated)
        self.incomes = []     # the same for incomes (PAPILDUS IENĀKUMI, the show's income)
        self.warnings = []
        self.sheets = defaultdict(list)   # kind -> sheet names used
        self.letters = set()
        self.seasons = set()


def _data_rows(sh, stop_words=("planota summa", "faktiska summa", "kopa", "atjaunots")):
    """Rows (from 2) whose column A is a person's name; stops at the totals rows."""
    rows = []
    for r in range(2, sh.max_row + 1):
        name = sh.get(r, 1)
        if not isinstance(name, str) or not name.strip():
            continue
        key = _norm(name)
        if any(key.startswith(w) for w in stop_words):
            break
        if is_x(name) or key in ("x",):
            continue
        rows.append(r)
    return rows


def _rate_columns(sh, cols, fallback):
    """{column: column with the dancer's fee} from the formulas of the totals row ($B… / $C…)."""
    out = {}
    for r in range(2, sh.max_row + 1):
        if _norm(sh.text(r, 1)).startswith("planota summa"):
            for c in cols:
                f = sh.formulas.get((r, c), "")
                m = re.search(r"\$([A-Z]{1,2})\$?\d", f)
                if m:
                    out[c] = col_index(m.group(1))
            break
    else:   # Tērpi sheets: the first row after the dancers with formulas
        for r in range(2, sh.max_row + 1):
            hits = {c: sh.formulas.get((r, c), "") for c in cols if sh.formulas.get((r, c))}
            if hits:
                for c, f in hits.items():
                    m = re.search(r"\$([A-Z]{1,2})\$?\d", f)
                    if m:
                        out[c] = col_index(m.group(1))
                if out:
                    break
    last = None
    for c in cols:
        if c in out:
            last = out[c]
        else:
            out[c] = last if last is not None else fallback(c)
    return out


def _mode(values):
    vals = [v for v in values if v]
    return Counter(vals).most_common(1)[0][0] if vals else None


def parse_fonds(sh, letter, from_season, plan):
    head = {c: sh.get(1, c) for c in range(2, sh.max_col + 1)}
    month_cols = {c: header_date(v) for c, v in head.items() if header_date(v)}
    rows = _data_rows(sh)
    if not month_cols or not rows:
        return
    cols = sorted(month_cols)
    rate_col = _rate_columns(sh, cols, lambda c: 3 if season_of(month_cols[c]) < 2026 else 2)
    # ---- monthly fees ----
    by_season = defaultdict(list)
    for c in cols:
        by_season[season_of(month_cols[c])].append(c)
    for season, scols in by_season.items():
        if season < from_season:
            continue
        plan.seasons.add(season)
        rc = rate_col[scols[0]]
        group_rate = _mode(to_cents(sh.get(r, rc)) for r in rows)
        if group_rate is None:
            plan.warnings.append(f"{sh.name}: sezonai {season_label(season)} nav atrasts maksas apmērs — "
                                 "dalības maksas netiek importētas.")
            continue
        months = sorted(month_cols[c] for c in scols)
        plan.rates.append({"group": letter, "start": months[0].strftime("%Y-%m"),
                           "end": months[-1].strftime("%Y-%m"), "cents": group_rate})
        for r in rows:
            name = sh.text(r, 1)
            own = to_cents(sh.get(r, rc))
            paid_any = any(sh.get(r, c) is not None and not is_x(sh.get(r, c)) for c in scols)
            for c in scols:
                mdate = month_cols[c]
                month = mdate.strftime("%Y-%m")
                v = sh.get(r, c)
                due = own if own else (group_rate if paid_any else 0)
                if is_x(v):
                    due = 0
                if due != group_rate:
                    plan.due.append({"name": name, "group": letter, "month": month, "cents": due})
                if v is None or is_x(v):
                    continue
                cents = to_cents(v) if isinstance(v, (int, float)) else None
                if cents is None:
                    if not (_candidates(v, mdate) or is_mark(v)):
                        plan.warnings.append(f"{sh.name}!{ref_of(r, c)} ({name}, {month}): nesaprotama vērtība "
                                             f"“{v}” — izlaista.")
                        continue
                    cents = due or group_rate
                if cents <= 0:
                    continue
                when = pay_date(v, mdate) if not isinstance(v, (int, float)) else None
                plan.fees.append({"name": name, "group": letter, "month": month, "cents": cents,
                                  "date": when or mdate, "key": f"fonds:{sh.name}:{ref_of(r, c)}"})
    plan.sheets[KIND_FEES].append(sh.name)
    # ---- extras (bus, balls, camps) ----
    extra_cols = [c for c in range(4, sh.max_col + 1) if c not in month_cols]
    used = set()
    for c in extra_cols:
        if c in used:
            continue
        title = clean_title(head.get(c))
        amount_col, date_col = c, None
        if not title:
            nxt = c + 1
            if nxt in head and clean_title(head.get(nxt)) and nxt not in month_cols:
                title, amount_col, date_col = clean_title(head[nxt]), c, nxt
                used.add(nxt)
            else:
                if any(sh.get(r, c) is not None for r in rows):
                    plan.warnings.append(f"{sh.name}: kolonnai {col_letter(c)} nav virsraksta — izlaista.")
                continue
        before = [month_cols[m] for m in cols if m < c]
        ref = max(before) if before else min(month_cols.values())
        season = season_of(ref)
        if season < from_season:
            continue
        price = parse_price(title)
        missing = 0
        for r in rows:
            name = sh.text(r, 1)
            v = sh.get(r, amount_col)
            dv = sh.get(r, date_col) if date_col else v
            if v is None and date_col and dv is not None and not is_x(dv):
                v = dv   # only the date is written
            if v is None or is_x(v):
                continue
            if isinstance(v, str) and v.strip() == "?":
                plan.warnings.append(f"{sh.name}!{ref_of(r, amount_col)} ({name}, {title}): “?” — izlaista.")
                continue
            cents = to_cents(v) if isinstance(v, (int, float)) else None
            if cents is None:
                if not (_candidates(v, ref) or is_mark(v)):
                    plan.warnings.append(f"{sh.name}!{ref_of(r, amount_col)} ({name}): nesaprotama vērtība “{v}”.")
                    continue
                cents = price * (1 + guests(v)) if price else price
            if not cents:
                missing += 1
                continue
            when = pay_date(dv, ref, before=120, after=300) if not isinstance(dv, (int, float)) else None
            plan.extras.append({"name": name, "group": letter, "title": title, "cents": cents,
                                "date": when or ref, "key": f"iemaksa:{sh.name}:{ref_of(r, amount_col)}"})
        if missing:
            plan.warnings.append(f"{sh.name}: “{title}” — {missing} samaksām nav zināma summa (virsrakstā nav "
                                 "vienas cenas, šūnā nav summas) — izlaistas.")
    plan.sheets[KIND_EXTRAS].append(sh.name)


def parse_terpi(sh, letter, from_season, plan):
    head = {c: sh.get(1, c) for c in range(2, sh.max_col + 1)}
    half_cols = {c: header_date(v) for c, v in head.items() if header_date(v)}
    rows = _data_rows(sh)
    if not half_cols or not rows:
        return
    cols = sorted(half_cols)
    rate_col = _rate_columns(sh, cols, lambda c: 3 if season_of(half_cols[c]) < 2026 and 3 not in half_cols else 2)
    for c in cols:
        hd = half_cols[c]
        season = season_of(hd)
        if season < from_season:
            continue
        plan.seasons.add(season)
        half = "1. pusgads" if hd.month >= 9 else "2. pusgads"
        rc = rate_col[c]
        group_rate = _mode(to_cents(sh.get(r, rc)) for r in rows)
        title = f"Tērpu fonds, {half} {season_label(season)}"
        ref = date(hd.year, hd.month, 1)
        for r in rows:
            name = sh.text(r, 1)
            v = sh.get(r, c)
            if v is None or is_x(v):
                continue
            cents = to_cents(v) if isinstance(v, (int, float)) else None
            if cents is None:
                if not (_candidates(v, ref) or is_mark(v)):
                    plan.warnings.append(f"{sh.name}!{ref_of(r, c)} ({name}): nesaprotama vērtība “{v}”.")
                    continue
                cents = to_cents(sh.get(r, rc)) or group_rate
            if not cents:
                continue
            when = pay_date(v, ref, before=300, after=400) if not isinstance(v, (int, float)) else None
            plan.costume.append({"name": name, "group": letter, "title": title, "cents": cents,
                                 "date": when or ref, "key": f"terpi:{sh.name}:{ref_of(r, c)}"})
    plan.sheets[KIND_COSTUME].append(sh.name)


def _income_category(text):
    key = _norm(text)
    if any(w in key for w in ("koncert", "bp ienakumi", "avans", "izrad", "uzved", "bilet", "atklasan")):
        return "Honorārs"
    if "ziedoj" in key:
        return "Ziedojumi"
    return "Citi ienākumi"


def parse_incomes(sh, letter, season, plan):
    """PAPILDUS IENĀKUMI at the top of a Bilance sheet (column B: what, C: amount). The date is the month in which
    the row “Papildus ienākumi” of the monthly overview has the same amount (or two amounts together)."""
    s_start = date(season, 9, 1)
    top = next((r for r in range(1, 40) if _norm(sh.text(r, 2)) == "papildus ienakumi"), None)
    stop = next((r for r in range(1, sh.max_row + 1) if _norm(sh.text(r, 2)) == "izdevumi"), None)
    if top is None or stop is None:
        return
    items = []
    for r in range(top + 1, stop):
        text, cents = sh.text(r, 2), to_cents(sh.get(r, 3))
        if not text or not cents or cents <= 0:
            continue
        if any(w in _norm(text) for w in ("vaksan", "ievakt")):
            plan.warnings.append(f"{sh.name}!B{r} “{text}” — nauda no dejotājiem (jau lapā “Fonds”), izlaista.")
            continue
        items.append([r, text, cents, None])
    # monthly overview: a row whose label is "Papildus ienākumi", month dates in row 2 above it
    months = {}
    for (r, c), v in sh.cells.items():
        if r < 12 and isinstance(v, str) and _norm(v).startswith("papildus ienakumi") and c > 3:
            for cc in range(c + 1, c + 14):
                hd = sh.get(2, cc)
                amount = to_cents(sh.get(r, cc))
                if isinstance(hd, (date, datetime)) and amount:
                    months[cc] = (date(hd.year, hd.month, 1), amount)
    for cc, (mdate, amount) in sorted(months.items()):
        free = [it for it in items if it[3] is None]
        hit = next(([it] for it in free if it[2] == amount), None)
        if hit is None:
            hit = next(([a, b] for i, a in enumerate(free) for b in free[i + 1:] if a[2] + b[2] == amount), None)
        for it in hit or []:
            it[3] = mdate
    for r, text, cents, when in items:
        plan.incomes.append({"group": letter, "date": when or s_start, "category": _income_category(text),
                             "text": text, "cents": cents,
                             "notes": "" if when else "datums tabulā nav norādīts (likts sezonas sākums)",
                             "method": BANK, "key": f"bilance:{sh.name}:C{r}", "dated": when is not None})
    if items:
        plan.sheets[KIND_INCOMES].append(sh.name)


def _category(heading):
    key = _norm(heading)
    for word, cat in EXPENSE_CATEGORIES:
        if word in key:
            return cat
    return "Citi izdevumi"


def parse_bilance(sh, letter, season, plan):
    """Expense blocks of one season sheet."""
    start = next((r for r in range(1, sh.max_row + 1) for c in range(1, 4)
                  if _norm(sh.text(r, c)) == "izdevumi"), None)
    if start is None:
        return
    s_start, s_end = date(season, 9, 1), date(season + 1, 8, 31)
    headings = []
    for (r, c), v in sh.cells.items():
        if r > start and isinstance(v, str) and v.strip().endswith(":"):
            total_col = next((cc for cc in range(c + 1, c + 6) if to_cents(sh.get(r, cc)) is not None), None)
            if total_col:
                headings.append((r, c, total_col, v.strip().rstrip(":").strip()))
    by_col = defaultdict(list)
    for h in headings:
        by_col[h[1]].append(h)
    count = 0
    for c, hs in by_col.items():
        hs.sort()
        for i, (r0, c0, tc, heading) in enumerate(hs):
            if "kopa" in _norm(heading).split():
                continue   # PAR DĀVANĀM KOPĀ — a total
            end = hs[i + 1][0] if i + 1 < len(hs) else sh.max_row + 1
            cat = _category(heading)
            last_date, gap, sub = None, 0, ""
            block_sum, block_skipped = 0, 0
            for r in range(r0 + 1, end):
                item = sh.text(r, c0 + 1) if c0 + 1 < tc and sh.text(r, c0 + 1) else ""
                if item:
                    if sh.text(r, c0):
                        sub = sh.text(r, c0)
                else:
                    item = sh.text(r, c0)
                cents = to_cents(sh.get(r, tc))
                income = to_cents(sh.get(r, tc + 1)) if to_cents(sh.get(r0, tc + 1)) else None
                if not cents and income and income > 0 and item:   # 'ieņēmumi' column of the show's block
                    v = sh.get(r, tc + 2)
                    when = pay_date(v, s_start, before=90, after=455, prefer=(s_start, s_end), trust=True) \
                        if v is not None and not isinstance(v, (int, float)) else None
                    plan.incomes.append({"group": letter, "date": when or last_date or s_start,
                                         "category": "Honorārs", "text": item, "cents": income,
                                         "notes": "; ".join(p for p in (heading, sub) if p), "method": BANK,
                                         "key": f"bilance:{sh.name}:{ref_of(r, tc + 1)}", "dated": when is not None})
                    if sh.name not in plan.sheets[KIND_INCOMES]:
                        plan.sheets[KIND_INCOMES].append(sh.name)
                    gap = 0
                    continue
                if not item and cents is None:
                    gap += 1
                    if gap >= 4:
                        break
                    continue
                gap = 0
                if not cents or cents <= 0:
                    continue
                when, note, skip = None, "", False
                for cc in range(tc + 1, tc + 4):
                    v = sh.get(r, cc)
                    if v is None or isinstance(v, (int, float)):
                        continue
                    if isinstance(v, str) and "nav samaks" in _norm(v):
                        skip = True
                        break
                    cand = pay_date(v, s_start, before=90, after=455, prefer=(s_start, s_end), trust=True)
                    if cand:
                        when = cand
                        nv = sh.get(r, cc + 1)
                        if isinstance(nv, str) and nv.strip():
                            note = nv.strip()
                        break
                    if isinstance(v, str) and not note:
                        note = v.strip()
                if skip:
                    plan.warnings.append(f"{sh.name}!{ref_of(r, tc)} “{item}” — atzīmēts “vēl nav samaksāts”, "
                                         "izlaists.")
                    block_skipped += cents
                    continue
                block_sum += cents
                dated = when is not None
                when = when or last_date or s_start
                last_date = when if dated else last_date
                text = item if item and _norm(item) not in ("meneša", "menesa") else f"{heading} (mēneša)"
                notes = "; ".join(p for p in (heading if cat == "Citi izdevumi" or cat == "Dāvanas" else "",
                                               sub, note, "" if dated else "datums tabulā nav norādīts") if p)
                plan.expenses.append({"group": letter, "date": when, "category": cat, "text": text,
                                      "cents": cents, "notes": notes,
                                      "method": CASH if "skaidr" in _norm(note) else BANK,
                                      "key": f"bilance:{sh.name}:{ref_of(r, tc)}", "dated": dated})
                count += 1
            total = to_cents(sh.get(r0, tc)) or 0
            if total and abs(total - block_sum - block_skipped) > 1:
                plan.warnings.append(f"{sh.name}: bloka “{heading}” kopsumma tabulā {total / 100:.2f} €, "
                                     f"importētās rindas {block_sum / 100:.2f} € — pārbaudiet.")
    if count:
        plan.sheets[KIND_EXPENSES].append(sh.name)
        plan.seasons.add(season)


def build_plan(book, from_season):
    plan = Plan()
    for name, sh in book.items():
        m = re.fullmatch(r"\s*Fonds\s+(\S+)\s*", name)
        if m:
            plan.letters.add(m.group(1))
            try:
                parse_fonds(sh, m.group(1), from_season, plan)
            except Exception:
                log_error(traceback.format_exc())
                plan.warnings.append(f"Lapu “{name}” neizdevās nolasīt.")
            continue
        m = re.fullmatch(r"\s*T[eē]rpi\s+(\S+)\s*", name)
        if m:
            plan.letters.add(m.group(1))
            try:
                parse_terpi(sh, m.group(1), from_season, plan)
            except Exception:
                log_error(traceback.format_exc())
                plan.warnings.append(f"Lapu “{name}” neizdevās nolasīt.")
            continue
        m = re.fullmatch(r"\s*Bilance\s+(\S+)\s+(\d{2})(\d{2})\s*", name)
        if m:
            season = 2000 + int(m.group(2))
            plan.letters.add(m.group(1))
            if season >= from_season:
                try:
                    parse_bilance(sh, m.group(1), season, plan)
                    parse_incomes(sh, m.group(1), season, plan)
                except Exception:
                    log_error(traceback.format_exc())
                    plan.warnings.append(f"Lapu “{name}” neizdevās nolasīt.")
    return plan


def seasons_in(book):
    """Seasons (start years) that the month columns / Bilance sheets of the table cover."""
    out = set()
    for name, sh in book.items():
        if re.fullmatch(r"\s*(Fonds|T[eē]rpi)\s+\S+\s*", name):
            for c in range(2, sh.max_col + 1):
                d = header_date(sh.get(1, c))
                if d:
                    out.add(season_of(d))
        m = re.fullmatch(r"\s*Bilance\s+\S+\s+(\d{2})\d{2}\s*", name)
        if m:
            out.add(2000 + int(m.group(1)))
    return sorted(out)


# ==========================================================================
# Writing the plan into Zelta pūrs
# ==========================================================================
def _ensure_categories(db):
    for kind, names in NEW_CATEGORIES.items():
        have = set(db.categories(kind))
        pos = len(have) + 1
        for n in names:
            if n not in have:
                db.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                               (kind, n, pos))
                pos += 1


def summarize(plan, groups, kinds, matcher, create_missing):
    """Text of the preview + the names that are not in Kopas pūrs."""
    def chosen(items):
        return [x for x in items if groups.get(x["group"])]

    lines = []
    unmatched = Counter()
    for kind, items in ((KIND_FEES, plan.fees), (KIND_EXTRAS, plan.extras), (KIND_COSTUME, plan.costume)):
        if kind not in kinds:
            continue
        for x in chosen(items):
            if matcher.find(x["name"], groups[x["group"]]) is None:
                unmatched[(x["name"], groups[x["group"]])] += 1

    def money(c):
        whole, part = divmod(abs(int(c)), 100)
        return ("−" if c < 0 else "") + f"{whole:,}".replace(",", " ") + f",{part:02d} €"

    for kind, items in ((KIND_FEES, plan.fees), (KIND_EXTRAS, plan.extras), (KIND_COSTUME, plan.costume),
                        (KIND_EXPENSES, plan.expenses), (KIND_INCOMES, plan.incomes)):
        mark = "☑" if kind in kinds else "☐"
        sel = chosen(items)
        lines.append(f"{mark} {KIND_TITLES[kind]}: {len(sel)} ieraksti, kopā {money(sum(x['cents'] for x in sel))}")
        per = defaultdict(lambda: [0, 0])
        for x in sel:
            per[groups[x["group"]]][0] += 1
            per[groups[x["group"]]][1] += x["cents"]
        for g, (n, s) in sorted(per.items()):
            lines.append(f"      {g}: {n} ieraksti, {money(s)}")
        if kind == KIND_FEES and kind in kinds:
            for rt in plan.rates:
                if groups.get(rt["group"]):
                    lines.append(f"      dalības maksa {groups[rt['group']]}: {money(rt['cents'])}/mēn., "
                                 f"{rt['start'][5:]}.{rt['start'][:4]}–{rt['end'][5:]}.{rt['end'][:4]}")
            n_due = len([d for d in plan.due if groups.get(d["group"])])
            lines.append(f"      individuāli mēneši (cita maksa, “x” — nav jāmaksā): {n_due}")
        if kind in (KIND_EXPENSES, KIND_INCOMES) and kind in kinds:
            undated = sum(1 for x in sel if not x["dated"])
            if undated:
                lines.append(f"      bez datuma tabulā: {undated} (likts iepriekšējā ieraksta datums vai sezonas "
                             "sākums)")
            cats = Counter()
            for x in sel:
                cats[x["category"]] += x["cents"]
            for cat, s in cats.most_common():
                lines.append(f"        · {cat}: {money(s)}")
    lines.append("")
    if unmatched:
        lines.append(f"Kopas pūrā nav atrasti {len(unmatched)} cilvēki" +
                     (" — tiks pievienoti Kopas pūrā:" if create_missing else
                      " — viņu dalības maksas netiek importētas, pārējās iemaksas — bez saites ar dejotāju:"))
        for (name, g), n in sorted(unmatched.items()):
            lines.append(f"      {name} ({g}) — {n} ieraksti")
        lines.append("")
    if plan.warnings:
        lines.append(f"Piezīmes ({len(plan.warnings)}):")
        lines.extend("      " + w for w in plan.warnings[:60])
        if len(plan.warnings) > 60:
            lines.append(f"      … un vēl {len(plan.warnings) - 60}")
    return "\n".join(lines), unmatched


def apply_plan(db, plan, groups, kinds, create_missing, user_name=""):
    """Write the chosen parts of the plan. Returns {what: count}. Already imported entries (same key) are skipped."""
    con = db.con
    counts = Counter()
    _ensure_categories(db)
    have_keys = {k for (k,) in con.execute("SELECT import_key FROM fin_entries WHERE COALESCE(import_key,'') <> ''")}
    dancers = db.dancers()
    matcher = Matcher(dancers.values())
    acc = piekluve.current()

    if create_missing:
        need = {}
        for kind, items in ((KIND_FEES, plan.fees), (KIND_EXTRAS, plan.extras), (KIND_COSTUME, plan.costume)):
            if kind in kinds:
                for x in items:
                    g = groups.get(x["group"])
                    if g and matcher.find(x["name"], g) is None:
                        need[_norm(x["name"])] = (x["name"].strip(), g)
        for name, g in need.values():
            if not acc.can_edit("kopas_purs", group=g):
                counts["dejotāji nav pievienoti (nav tiesību Kopas pūrā)"] += 1
                continue
            parts = name.split()
            first, last = " ".join(parts[:-1]) if len(parts) > 1 else name, parts[-1] if len(parts) > 1 else ""
            con.execute("INSERT INTO dancers (name, first_name, last_name, status, role, dancer_group) "
                        "VALUES (?, ?, ?, ?, ?, ?)", (name, first, last, STATUS_ACTIVE, ROLE_DANCER, g))
            counts["pievienoti dejotāji Kopas pūrā"] += 1
        con.commit()
        dancers = db.dancers()
        matcher = Matcher(dancers.values())

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    insert_sql = ("INSERT INTO fin_entries (entry_date, kind, category, amount_cents, fin_group, method, party, "
                  "dancer_id, session_id, fee_months, document, notes, created_by, created_at, updated_at, import_key) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, '', ?, ?, ?, ?, ?)")

    def add(entry_date, kind, category, cents, group, method, party, dancer_id, fee_months, notes, key):
        if key in have_keys:
            counts["jau bija importēti (izlaisti)"] += 1
            return
        con.execute(insert_sql, (entry_date.isoformat(), kind, category, cents, group, method, party, dancer_id,
                                 fee_months, notes, user_name, stamp, stamp, key))
        have_keys.add(key)
        counts[category] += 1

    def editable(g):
        return g and acc.can_edit("zelta_purs", group=g)

    if KIND_FEES in kinds:
        for rt in plan.rates:
            g = groups.get(rt["group"])
            if not editable(g):
                continue
            if con.execute("SELECT 1 FROM fin_fee_rates WHERE fin_group=? AND valid_from=?",
                           (g, rt["start"])).fetchone():
                con.execute("UPDATE fin_fee_rates SET amount_cents=?, valid_to=? WHERE fin_group=? AND valid_from=?",
                            (rt["cents"], rt["end"], g, rt["start"]))
            else:
                con.execute("INSERT INTO fin_fee_rates (fin_group, valid_from, valid_to, amount_cents) "
                            "VALUES (?, ?, ?, ?)", (g, rt["start"], rt["end"], rt["cents"]))
            counts["dalības maksas apmēri"] += 1
        for d in plan.due:
            g = groups.get(d["group"])
            p = matcher.find(d["name"], g) if editable(g) else None
            if p is None:
                continue
            con.execute("DELETE FROM fin_fee_due WHERE dancer_id=? AND month=?", (p["id"], d["month"]))
            con.execute("INSERT INTO fin_fee_due (dancer_id, month, amount_cents) VALUES (?, ?, ?)",
                        (p["id"], d["month"], d["cents"]))
            counts["individuāli mēneši"] += 1
        for x in plan.fees:
            g = groups.get(x["group"])
            if not editable(g):
                continue
            p = matcher.find(x["name"], g)
            if p is None:
                counts["dalības maksas bez dejotāja (izlaistas)"] += 1
                continue
            add(x["date"], INCOME, FEE_CATEGORY, x["cents"], g, BANK, p["name"], p["id"],
                f"{x['month']}:{x['cents']}", "Imports no Excel", x["key"])
    for kind, items, cat in ((KIND_EXTRAS, plan.extras, CAT_EXTRAS), (KIND_COSTUME, plan.costume, CAT_COSTUME)):
        if kind not in kinds:
            continue
        for x in items:
            g = groups.get(x["group"])
            if not editable(g):
                continue
            p = matcher.find(x["name"], g)
            add(x["date"], INCOME, cat, x["cents"], g, BANK, p["name"] if p else x["name"].strip(),
                p["id"] if p else None, "", x["title"], x["key"])
    if KIND_EXPENSES in kinds:
        for x in plan.expenses:
            g = groups.get(x["group"])
            if not editable(g):
                continue
            add(x["date"], EXPENSE, x["category"], x["cents"], g, x["method"], "", None, "",
                "; ".join(p for p in (x["text"], x["notes"]) if p), x["key"])
    if KIND_INCOMES in kinds:
        for x in plan.incomes:
            g = groups.get(x["group"])
            if not editable(g):
                continue
            add(x["date"], INCOME, x["category"], x["cents"], g, x["method"], "", None, "",
                "; ".join(p for p in (x["text"], x["notes"]) if p), x["key"])
    con.commit()
    return counts


# ==========================================================================
# Window
# ==========================================================================
class ImportWindow(tk.Toplevel):
    def __init__(self, app, path, book):
        super().__init__(app.root)
        self.app, self.path, self.book = app, path, book
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Importēt no Excel")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit("zelta_purs", group=g)]
        letters = sorted({m.group(1) for n in book for m in [re.fullmatch(r"\s*(?:Fonds|T[eē]rpi|Bilance)\s+(\S+).*",
                                                                          n)] if m})
        tk.Label(self, text="Importēt no Excel", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=4, sticky="w")
        tk.Label(self, text=path, bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(0, 8))

        box = tk.LabelFrame(self, text=" Grupas tabulā → grupas Pūrlādē ", bg=CREAM, fg=RED,
                            font=("Georgia", 11, "bold"), padx=10, pady=6)
        box.grid(row=2, column=0, sticky="nw")
        self.group_vars = {}
        for i, letter in enumerate(letters):
            guess = {"a": "A", "b": "Studija", "s": "Studija", "studija": "Studija", "d": "VPDK",
                     "vpdk": "VPDK"}.get(letter.lower(), letter if letter in DANCER_GROUPS else "")
            var = tk.StringVar(value=guess if guess in self.edit_groups else NOT_IMPORTED)
            tk.Label(box, text=f"“{letter}” →", bg=CREAM, fg=NAVY).grid(row=i, column=0, sticky="w", pady=2)
            cb = ttk.Combobox(box, textvariable=var, values=self.edit_groups + [NOT_IMPORTED], state="readonly",
                              width=16)
            cb.grid(row=i, column=1, sticky="w", padx=(6, 0))
            cb.bind("<<ComboboxSelected>>", lambda e: self.preview())
            self.group_vars[letter] = var

        opts = tk.LabelFrame(self, text=" Ko importēt ", bg=CREAM, fg=RED, font=("Georgia", 11, "bold"),
                             padx=10, pady=6)
        opts.grid(row=2, column=1, columnspan=3, sticky="nw", padx=(14, 0))
        seasons = seasons_in(book)
        tk.Label(opts, text="No sezonas:", bg=CREAM, fg=NAVY).grid(row=0, column=0, sticky="w")
        default = 2025 if 2025 in seasons else (seasons[-1] if seasons else date.today().year)
        self.season_var = tk.StringVar(value=season_label(default))
        scb = ttk.Combobox(opts, textvariable=self.season_var, values=[season_label(s) for s in seasons],
                           state="readonly", width=10)
        scb.grid(row=0, column=1, sticky="w", padx=(6, 0))
        scb.bind("<<ComboboxSelected>>", lambda e: self.rebuild())
        self.kind_vars = {}
        for i, kind in enumerate(KINDS_ORDER, start=1):
            var = tk.BooleanVar(value=True)
            tk.Checkbutton(opts, text=KIND_TITLES[kind], variable=var, bg=CREAM, fg=NAVY, activebackground=CREAM,
                           selectcolor=WHITE, command=self.preview).grid(row=i, column=0, columnspan=2, sticky="w")
            self.kind_vars[kind] = var
        self.create_var = tk.BooleanVar(value=False)
        can_kopas = any(acc.can_edit("kopas_purs", group=g) for g in self.edit_groups)
        cbm = tk.Checkbutton(opts, text="Pievienot Kopas pūrā cilvēkus, kuru tur nav", variable=self.create_var,
                             bg=CREAM, fg=NAVY, activebackground=CREAM, selectcolor=WHITE, command=self.preview)
        cbm.grid(row=len(KINDS_ORDER) + 1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        if not can_kopas:
            cbm.configure(state="disabled")

        tk.Label(self, text="Priekšskatījums — nekas vēl nav ierakstīts:", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 10, "bold")).grid(row=3, column=0, columnspan=4, sticky="w", pady=(10, 2))
        holder = tk.Frame(self, bg=CREAM)
        holder.grid(row=4, column=0, columnspan=4, sticky="nsew")
        self.rowconfigure(4, weight=1)
        self.columnconfigure(3, weight=1)
        self.text = tk.Text(holder, width=110, height=24, wrap="word", relief="solid", bd=1, bg=WHITE, fg=NAVY,
                            font=("Consolas", 9))
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)
        self.text.pack(side="left", fill="both", expand=True)
        sb.pack(side="left", fill="y")
        tk.Label(self, text="Importu var atkārtot (piemēram, kad Excel tabula papildināta) — jau ievestie ieraksti "
                            "netiek dublēti. Dalības maksas apmērs un individuālie mēneši tiek pārrakstīti no tabulas.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), wraplength=760, justify="left").grid(
            row=5, column=0, columnspan=4, sticky="w", pady=(6, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=6, column=0, columnspan=4, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        self.go = ttk.Button(btns, text="⇪ Importēt", style="Accent.TButton", command=self.run)
        self.go.pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.changed = False
        self.rebuild()

    def groups(self):
        return {l: v.get() for l, v in self.group_vars.items() if v.get() != NOT_IMPORTED}

    def kinds(self):
        return {k for k, v in self.kind_vars.items() if v.get()}

    def rebuild(self):
        try:
            self.plan = build_plan(self.book, int(self.season_var.get()[:4]))
        except Exception:
            log_error(traceback.format_exc())
            self.plan = Plan()
            self.plan.warnings.append("Tabulu neizdevās nolasīt (detaļas kludas.log).")
        self.preview()

    def preview(self):
        matcher = Matcher(self.app.db.dancers().values())
        text, _unmatched = summarize(self.plan, self.groups(), self.kinds(), matcher, self.create_var.get())
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", text)
        self.text.configure(state="disabled")

    def run(self):
        if not self.groups() or not self.kinds():
            return messagebox.showinfo("Imports", "Izvēlieties vismaz vienu grupu un ko importēt.", parent=self)
        if not messagebox.askyesno("Imports", "Ierakstīt Zelta pūrā priekšskatījumā redzamo?", parent=self):
            return
        try:
            user = piekluve.current().user
            counts = apply_plan(self.app.db, self.plan, self.groups(), self.kinds(), self.create_var.get(),
                                user.name or user.email or "")
        except sqlite3.Error as exc:
            log_error(traceback.format_exc())
            try:
                self.app.db.con.rollback()
            except Exception:
                pass
            return messagebox.showerror("Imports", f"Importēt neizdevās:\n{exc}", parent=self)
        self.destroy()
        self.app.refresh_all()
        text = "\n".join(f"{k}: {v}" for k, v in sorted(counts.items())) or "Nekas jauns netika atrasts."
        messagebox.showinfo("Imports pabeigts", text, parent=self.app.root)


def start_import(app):
    """Zelta pūrs button “⇪ Importēt no Excel…”."""
    if not app.can_edit_any:
        return piekluve.deny(app.root)
    path = filedialog.askopenfilename(parent=app.root, title="Izvēlieties kases Excel tabulu",
                                      filetypes=[("Excel", "*.xlsx *.xlsm"), ("Visi faili", "*.*")])
    if not path:
        return
    try:
        book = read_workbook(path)
    except Exception as exc:
        log_error(traceback.format_exc())
        return messagebox.showerror("Imports", f"Failu neizdevās nolasīt:\n{exc}\n\nDer tikai .xlsx fails.",
                                    parent=app.root)
    if not any(re.fullmatch(r"\s*(Fonds|T[eē]rpi|Bilance)\s+\S+.*", n) for n in book):
        return messagebox.showwarning("Imports", "Failā nav lapu “Fonds …”, “Tērpi …” vai “Bilance …” — tas "
                                                 "neizskatās pēc kolektīva kases tabulas.", parent=app.root)
    ImportWindow(app, path, book)
