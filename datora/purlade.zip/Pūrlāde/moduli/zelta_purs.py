"""
Pūrlāde — modulis "Zelta pūrs" (finanšu pārvaldībai)

Modulis vēl tiek izstrādāts. Kamēr šajā failā nav funkcijas start(),
Pūrlādes sākuma logā tas redzams ar atzīmi "Izstrādē" un nav atverams.

Kad modulis būs gatavs, tam jādefinē:
    def start(root, on_exit, title_prefix=""):
        # uzzīmē moduli logā root; on_exit() atgriež uz Pūrlādes sākuma logu
"""

try:
    from moduli.kopeja import GOLD
except ImportError:
    from kopeja import GOLD

MODULE = {
    "name": "Zelta pūrs",
    "version": None,
    "description": "Finanšu pārvaldība: ienākumi, izdevumi, dalības maksas",
    "letter": "Z",
    "color": GOLD,
}
