#!/usr/bin/env python3
"""
Pūrlāde — modulis "Zelta pūrs" (kolektīva finanšu pārvaldībai)

Ko modulis dara:
  * Darījumi      — visi ienākumi un izdevumi (datums, kategorija, summa, grupa, maksātājs / saņēmējs,
                    skaidrā naudā vai pārskaitījums, dokumenta nr., saistītais notikums no Notikumu pūra);
  * Dalības maksas — katram dejotājam pa mēnešiem: samaksāts / parāds; maksas apmērs katrai grupai (ar datumu,
                    no kura tas spēkā) un individuāla maksa (atlaide vai atbrīvojums) atsevišķiem dejotājiem;
  * Honorāri      — Notikumu pūra notikumi ar ierakstītu honorāru: vai tas jau saņemts (ienākums piesaistīts
                    notikumam);
  * Pārskats      — gada ienākumi un izdevumi pa kategorijām un mēnešiem, atlikums; eksports uz CSV (Excel).
Augšā: atlikums kopā, kasē (skaidrā naudā) un kontā, gada ienākumi / izdevumi un dalības maksu parāds.

Piekļuve (moduli/piekluve.py): vadītājs, repetitors, sistēmas administrators — visas grupas;
A grupas kasieris / Prezidents — tikai A grupas finanses; Studijas kasieris / Studijas vecākais — tikai Studijas.
Citu grupu finanses šīm lomām netiek rādītas vispār.

Summas glabā centos (veseli skaitļi), lai nerastos noapaļošanas kļūdas. Datumi — DD.MM.GGGG.
Divi lietotāji vienlaikus: saglabājot pārbauda, vai ierakstu kāds cits pa to laiku nav mainījis vai dzēsis.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/zelta_purs.py
"""

import csv
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import date, datetime
from tkinter import ttk, messagebox, filedialog

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible,
                               ensure_dancer_schema, full_name, parse_date, date_picker_button, _norm,
                               POWER_ICON_B64, HOME_ICON_B64, DANCER_GROUPS, DEFAULT_DANCER_GROUP,
                               STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT, ROLE_DANCER,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible,
                        ensure_dancer_schema, full_name, parse_date, date_picker_button, _norm,
                        POWER_ICON_B64, HOME_ICON_B64, DANCER_GROUPS, DEFAULT_DANCER_GROUP,
                        STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT, ROLE_DANCER,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

PROGRAM_NAME = "Zelta pūrs"
APP_VERSION = "0.1"
MODULE_KEY = "zelta_purs"
DARK_GOLD = "#8A6D0B"
AMBER = "#B07D00"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Finanšu pārvaldība: ienākumi, izdevumi, dalības maksas, honorāri",
    "letter": "Z",
    "color": GOLD,
}

INCOME = "Ienākumi"
EXPENSE = "Izdevumi"
KINDS = [INCOME, EXPENSE]
CASH = "Skaidrā naudā"
BANK = "Pārskaitījums"
METHODS = [CASH, BANK]
FEE_CATEGORY = "Dalības maksa"     # Ienākumi: used by the "Dalības maksas" tab — cannot be renamed or deleted
FEE_CATEGORY_EVENT = "Honorārs"     # Ienākumi: suggested for the honorarium of an event
ALL = "Visi"
ALL_GROUPS = "Visas"
MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts", "Septembris",
          "Oktobris", "Novembris", "Decembris"]
MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "Mai", "Jūn", "Jūl", "Aug", "Sep", "Okt", "Nov", "Dec"]

DEFAULT_CATEGORIES = {
    INCOME: [FEE_CATEGORY, FEE_CATEGORY_EVENT, "Pašvaldības finansējums", "Projektu finansējums", "Ziedojumi",
             "Tērpu noma", "Citi ienākumi"],
    EXPENSE: ["Tērpi un apavi", "Tērpu remonts un kopšana", "Transports", "Ēdināšana",
              "Dalības maksas festivālos un skatēs", "Kolektīva pasākumi", "Saimniecības izdevumi",
              "Bankas komisijas", "Citi izdevumi"],
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS fin_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    position INTEGER DEFAULT 0,
    UNIQUE (kind, name)
);
CREATE TABLE IF NOT EXISTS fin_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT NOT NULL,
    kind TEXT NOT NULL,
    category TEXT DEFAULT '',
    amount_cents INTEGER NOT NULL,
    fin_group TEXT NOT NULL DEFAULT 'A',
    method TEXT DEFAULT '',
    party TEXT DEFAULT '',
    dancer_id INTEGER,
    session_id INTEGER,
    fee_months TEXT DEFAULT '',
    document TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT DEFAULT '',
    created_at TEXT DEFAULT '',
    updated_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS fin_fee_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fin_group TEXT NOT NULL,
    valid_from TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    UNIQUE (fin_group, valid_from)
);
CREATE TABLE IF NOT EXISTS fin_fee_personal (
    dancer_id INTEGER PRIMARY KEY,
    amount_cents INTEGER NOT NULL,
    note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS fin_opening (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fin_group TEXT NOT NULL,
    method TEXT NOT NULL,
    amount_cents INTEGER NOT NULL DEFAULT 0,
    UNIQUE (fin_group, method)
);
"""

ENTRY_FIELDS = ("entry_date", "kind", "category", "amount_cents", "fin_group", "method", "party", "dancer_id",
                "session_id", "fee_months", "document", "notes")


# --------------------------------------------------------------------------
# Money and months
# --------------------------------------------------------------------------
def parse_money(text):
    """'12,50' / '12.50' / '1 234,5 €' / '12' -> cents (int). Empty or wrong -> None. Negative not allowed."""
    t = str(text or "").replace("€", "").replace("EUR", "").replace("eur", "").replace("\u00a0", "")
    t = t.replace(" ", "").strip()
    if not t:
        return None
    if "," in t and "." in t:   # 1.234,50 or 1,234.50 — the last sign is the decimal sign
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    else:
        t = t.replace(",", ".")
    if not re.fullmatch(r"\d+(\.\d{1,2})?", t):
        return None
    whole, _, part = t.partition(".")
    return int(whole) * 100 + int((part + "00")[:2])


def money(cents, sign=False, euro=True):
    """1234567 -> '12 345,67 €'"""
    cents = int(cents or 0)
    neg = cents < 0
    whole, part = divmod(abs(cents), 100)
    text = f"{whole:,}".replace(",", " ") + f",{part:02d}"
    if neg:
        text = "−" + text
    elif sign and cents > 0:
        text = "+" + text
    return text + (" €" if euro else "")


def money_plain(cents):
    """For CSV / Excel: 1234.5 -> '12,34' (no thousand separator, no euro sign)."""
    cents = int(cents or 0)
    whole, part = divmod(abs(cents), 100)
    return ("-" if cents < 0 else "") + f"{whole},{part:02d}"


def show_date(iso):
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or ""


def month_key(year, month):
    return f"{year:04d}-{month:02d}"


def month_label(key):
    """'2026-09' -> 'Septembris 2026'"""
    try:
        y, m = key.split("-")
        return f"{MONTHS[int(m) - 1]} {y}"
    except (ValueError, IndexError):
        return key


def parse_months(text):
    return [m.strip() for m in (text or "").split(",") if re.fullmatch(r"\d{4}-\d{2}", m.strip())]


def now_text():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")


def this_month():
    t = date.today()
    return month_key(t.year, t.month)


def group_of(group):
    return (group or "").strip() or DEFAULT_DANCER_GROUP


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def save_csv(parent, title, default_name, header, rows):
    path = filedialog.asksaveasfilename(parent=parent, title=title, defaultextension=".csv",
                                        initialfile=default_name,
                                        filetypes=[("CSV (Excel)", "*.csv"), ("Visi faili", "*.*")])
    if not path:
        return
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:   # utf-8-sig: Excel shows ā, ē … right
            w = csv.writer(fh, delimiter=";")
            w.writerow(header)
            w.writerows(rows)
    except OSError as exc:
        messagebox.showerror("Eksports", f"Failu neizdevās saglabāt:\n{exc}", parent=parent)
        return
    messagebox.showinfo("Eksports", f"Saglabāts:\n{path}", parent=parent)


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        ensure_dancer_schema(self.con)
        for statement in SCHEMA.split(";"):
            if statement.strip():
                self.con.execute(statement)
        self.con.commit()
        if not self.q("SELECT 1 FROM fin_categories LIMIT 1"):
            for kind, names in DEFAULT_CATEGORIES.items():
                for i, name in enumerate(names):
                    self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                                     (kind, name, i))
            self.con.commit()
        # Dalības maksa must always exist (the fee tab uses it)
        self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                         (INCOME, FEE_CATEGORY, -1))
        self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def has_table(self, name):
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)))

    # ---- categories -------------------------------------------------------
    def categories(self, kind=None):
        rows = self.q("SELECT kind, name FROM fin_categories ORDER BY position, name")
        if kind:
            return [n for k, n in rows if k == kind]
        return rows

    # ---- dancers ----------------------------------------------------------
    def dancers(self):
        """{id: dict} of every person in Kopas pūrs."""
        rows = self.q("SELECT id, first_name, last_name, name, dancer_group, status, role, join_date FROM dancers")
        out = {}
        for did, first, last, name, group, status, role, join in rows:
            out[did] = {"id": did, "name": full_name(first, last) or name or f"#{did}",
                        "group": group_of(group), "status": status or STATUS_ACTIVE,
                        "dancer": (role or "").strip() in ("", ROLE_DANCER), "join": join or ""}
        return out

    # ---- events (Notikumu pūrs / Cītības pūrs) ------------------------------
    def events(self):
        """[(id, date, kind, title, groups text, fee text)] — empty when the modules were never used."""
        if not self.has_table("attendance_sessions"):
            return []
        if self.has_table("event_details"):
            cols = {r[1] for r in self.q("PRAGMA table_info(event_details)")}
            groups = "COALESCE(e.for_groups, '')" if "for_groups" in cols else "''"
            fee = "COALESCE(e.fee, '')" if "fee" in cols else "''"
            return self.q(f"SELECT s.id, s.session_date, COALESCE(s.kind,''), COALESCE(s.title,''), {groups}, {fee} "
                          "FROM attendance_sessions s LEFT JOIN event_details e ON e.session_id = s.id "
                          "ORDER BY s.session_date DESC")
        return [(i, d, k, t, "", "") for i, d, k, t in
                self.q("SELECT id, session_date, COALESCE(kind,''), COALESCE(title,'') FROM attendance_sessions "
                       "ORDER BY session_date DESC")]

    # ---- entries ----------------------------------------------------------
    def entries(self):
        rows = self.q("SELECT id, " + ", ".join(ENTRY_FIELDS) + ", created_by, created_at, updated_at "
                      "FROM fin_entries")
        keys = ("id",) + ENTRY_FIELDS + ("created_by", "created_at", "updated_at")
        return [dict(zip(keys, r)) for r in rows]

    def entry(self, entry_id):
        rows = self.q("SELECT id, " + ", ".join(ENTRY_FIELDS) + ", updated_at FROM fin_entries WHERE id=?",
                      (entry_id,))
        return dict(zip(("id",) + ENTRY_FIELDS + ("updated_at",), rows[0])) if rows else None

    def save_entry(self, values, entry_id=None, expected_stamp=None):
        """Insert / update one entry. When someone else changed or deleted it meanwhile -> raises ValueError."""
        stamp = now_text()
        if entry_id is None:
            user = piekluve.current().user
            return self.x("INSERT INTO fin_entries (" + ", ".join(ENTRY_FIELDS) + ", created_by, created_at, "
                          "updated_at) VALUES (" + ", ".join("?" * (len(ENTRY_FIELDS) + 3)) + ")",
                          tuple(values[f] for f in ENTRY_FIELDS) + (user.name or user.email or "", stamp, stamp))
        current = self.q("SELECT updated_at FROM fin_entries WHERE id=?", (entry_id,))
        if not current:
            raise ValueError("Šo ierakstu pa to laiku kāds cits ir izdzēsis.")
        if expected_stamp is not None and (current[0][0] or "") != (expected_stamp or ""):
            raise ValueError("Šo ierakstu pa to laiku kāds cits ir mainījis. Aizveriet logu un atveriet to vēlreiz, "
                             "lai redzētu jaunāko versiju.")
        self.x("UPDATE fin_entries SET " + ", ".join(f"{f}=?" for f in ENTRY_FIELDS) + ", updated_at=? WHERE id=?",
               tuple(values[f] for f in ENTRY_FIELDS) + (stamp, entry_id))
        return entry_id

    # ---- fees -------------------------------------------------------------
    def fee_rates(self):
        """{group: [(valid_from 'GGGG-MM', cents), …] sorted}"""
        out = {}
        for group, start, cents in self.q("SELECT fin_group, valid_from, amount_cents FROM fin_fee_rates "
                                          "ORDER BY valid_from"):
            out.setdefault(group, []).append((start, cents))
        return out

    def personal_fees(self):
        return {did: (cents, note or "") for did, cents, note in
                self.q("SELECT dancer_id, amount_cents, note FROM fin_fee_personal")}

    def opening(self):
        """{(group, method): cents}"""
        return {(g, m): c for g, m, c in self.q("SELECT fin_group, method, amount_cents FROM fin_opening")}


def rate_for(rates, group, month):
    """The monthly fee of the group in that month (0 when nothing is set)."""
    value = 0
    for start, cents in rates.get(group, []):
        if start <= month:
            value = cents
    return value


def fee_due(rates, personal, dancer, month):
    """What a dancer should pay for one month (individual fee wins over the group's fee)."""
    if dancer["id"] in personal:
        return personal[dancer["id"]][0]
    return rate_for(rates, dancer["group"], month)


def fee_paid_by_month(entries):
    """{dancer_id: {month: cents}} — a payment for several months is split equally between them."""
    out = {}
    for e in entries:
        if e["kind"] != INCOME or e["category"] != FEE_CATEGORY or not e["dancer_id"]:
            continue
        months = parse_months(e["fee_months"])
        if not months:
            d = e["entry_date"] or ""
            months = [d[:7]] if len(d) >= 7 else []
        if not months:
            continue
        share, rest = divmod(int(e["amount_cents"] or 0), len(months))
        per = out.setdefault(e["dancer_id"], {})
        for i, m in enumerate(months):
            per[m] = per.get(m, 0) + share + (1 if i < rest else 0)
    return out


def due_months(dancer, year, until):
    """Months of the year for which a dancer must pay: from the join month (if known) to `until` ('GGGG-MM')."""
    months = []
    join = (dancer.get("join") or "")[:7]
    for m in range(1, 13):
        key = month_key(year, m)
        if key > until:
            break
        if join and key < join:
            continue
        months.append(key)
    return months


# --------------------------------------------------------------------------
# Entry form (one income or expense)
# --------------------------------------------------------------------------
class EntryForm(tk.Toplevel):
    def __init__(self, app, entry_id=None, kind=INCOME, preset=None):
        super().__init__(app.root)
        self.app, self.entry_id = app, entry_id
        db = app.db
        self.configure(bg=CREAM, padx=18, pady=14)
        self.transient(app.root)
        self.grab_set()
        self.stamp = None
        data = db.entry(entry_id) if entry_id is not None else None
        if entry_id is not None and data is None:
            self.destroy()
            messagebox.showwarning("Ieraksts", "Šis ieraksts vairs nepastāv (kāds to ir izdzēsis).",
                                   parent=app.root)
            app.refresh_all()
            return
        if data:
            kind = data["kind"]
            self.stamp = data["updated_at"]
        self.kind = kind
        self.title(("Jauns ienākums" if kind == INCOME else "Jauns izdevums") if entry_id is None
                   else ("Ienākums" if kind == INCOME else "Izdevums"))
        tk.Label(self, text=("Jauns ienākums" if kind == INCOME else "Jauns izdevums") if entry_id is None
                 else ("Ienākums" if kind == INCOME else "Izdevums"),
                 font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN if kind == INCOME else RED).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))

        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit(MODULE_KEY, group=g)]
        self.v = {k: tk.StringVar() for k in ("date", "category", "amount", "group", "method", "party", "event",
                                              "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(BANK)
        default_group = app.group_var.get() if app.group_var.get() in self.edit_groups else \
            (self.edit_groups[0] if self.edit_groups else "")
        self.v["group"].set(default_group)

        def label(text, r, c=0):
            tk.Label(self, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))

        label("Datums *", 1)
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=1, column=1, sticky="w", padx=(8, 0))
        self.date_entry = ttk.Entry(drow, textvariable=self.v["date"], width=14)
        self.date_entry.pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        label("Summa, € *", 1, 2)
        self.amount_entry = ttk.Entry(self, textvariable=self.v["amount"], width=16)
        self.amount_entry.grid(row=1, column=3, sticky="w", padx=(8, 0))

        label("Kategorija *", 2)
        cats = db.categories(kind)
        if kind == INCOME:
            cats = [c for c in cats if c != FEE_CATEGORY] if not (data and data["category"] == FEE_CATEGORY) else cats
        self.cat_cb = ttk.Combobox(self, textvariable=self.v["category"], values=cats, state="readonly", width=30)
        self.cat_cb.grid(row=2, column=1, sticky="w", padx=(8, 0))
        label("Grupa *", 2, 2)
        self.group_cb = ttk.Combobox(self, textvariable=self.v["group"], values=self.edit_groups, state="readonly",
                                     width=14)
        self.group_cb.grid(row=2, column=3, sticky="w", padx=(8, 0))

        label("Maksātājs" if kind == INCOME else "Saņēmējs", 3)
        ttk.Entry(self, textvariable=self.v["party"], width=32).grid(row=3, column=1, sticky="w", padx=(8, 0))
        label("Maksājuma veids", 3, 2)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=3, column=3, sticky="w", padx=(8, 0))

        label("Notikums", 4)
        self.events = [(None, "— nav —")]
        for sid, d, ek, title, _groups, _fee in db.events():
            self.events.append((sid, f"{show_date(d)} · {title or ek or 'notikums'}"))
        self.event_cb = ttk.Combobox(self, textvariable=self.v["event"], values=[t for _i, t in self.events],
                                     state="readonly", width=40)
        self.event_cb.grid(row=4, column=1, columnspan=3, sticky="w", padx=(8, 0))
        self.v["event"].set(self.events[0][1])

        label("Dokumenta nr.", 5)
        ttk.Entry(self, textvariable=self.v["document"], width=24).grid(row=5, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="čeks, rēķins, maksājuma uzdevums …", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=5, column=2, columnspan=2, sticky="w", padx=(18, 0))

        label("Piezīmes", 6)
        self.notes = tk.Text(self, width=56, height=3, wrap="word", relief="solid", bd=1)
        self.notes.grid(row=6, column=1, columnspan=3, sticky="ew", pady=4, padx=(8, 0))

        self.info = tk.Label(self, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), justify="left")
        self.info.grid(row=7, column=0, columnspan=4, sticky="w", pady=(4, 0))

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=8, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if entry_id is not None:
            ttk.Button(btns, text="Dzēst", command=self.delete).pack(side="left")
        self.bind("<Escape>", lambda e: self.destroy())

        self.data = data
        if data:
            self.v["date"].set(show_date(data["entry_date"]))
            self.v["amount"].set(money(data["amount_cents"], euro=False).replace(" ", ""))
            self.v["category"].set(data["category"] or "")
            self.v["group"].set(data["fin_group"] or DEFAULT_DANCER_GROUP)
            self.v["method"].set(data["method"] or "")
            self.v["party"].set(data["party"] or "")
            self.v["document"].set(data["document"] or "")
            self.notes.insert("1.0", data["notes"] or "")
            for sid, text in self.events:
                if sid is not None and sid == data["session_id"]:
                    self.v["event"].set(text)
            if data["category"] == FEE_CATEGORY:
                months = ", ".join(month_label(m) for m in parse_months(data["fee_months"]))
                self.cat_cb.configure(state="disabled")
                self.info.configure(text=f"Dalības maksa par: {months or '—'}. Mēnešus maina cilnē “Dalības "
                                         "maksas” (izdzēsiet šo maksājumu un reģistrējiet no jauna).")
        elif preset:
            for key, value in preset.items():
                if key == "event":
                    for sid, text in self.events:
                        if sid == value:
                            self.v["event"].set(text)
                elif key in self.v:
                    self.v[key].set(value)
        if data and data["fin_group"] not in self.edit_groups:
            piekluve.make_readonly(self, note="Tikai skatīšanai — šīs grupas finanses jūsu loma nevar mainīt.")
        elif not self.edit_groups:
            piekluve.make_readonly(self)
        self.amount_entry.focus_set()
        self.after(100, lambda: fit_min_size(self))

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = parse_date(self.v["date"].get())
        if not d:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        cents = parse_money(self.v["amount"].get())
        if not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 25 vai 12,50.", parent=self)
        category = self.v["category"].get().strip()
        if not category:
            return messagebox.showwarning("Kategorija", "Izvēlieties kategoriju.", parent=self)
        group = self.v["group"].get()
        if group not in self.edit_groups:
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        session = next((sid for sid, text in self.events if text == self.v["event"].get()), None)
        data = self.data or {}
        values = {"entry_date": d, "kind": self.kind, "category": category, "amount_cents": cents,
                  "fin_group": group, "method": self.v["method"].get(), "party": self.v["party"].get().strip(),
                  "dancer_id": data.get("dancer_id"), "session_id": session,
                  "fee_months": data.get("fee_months") or "", "document": self.v["document"].get().strip(),
                  "notes": self.notes.get("1.0", "end").strip()}
        try:
            self.app.db.save_entry(values, self.entry_id, self.stamp)
        except ValueError as exc:
            messagebox.showwarning("Saglabāt", str(exc), parent=self)
            return
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return
        self.destroy()
        self.app.refresh_all()

    def delete(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        if messagebox.askyesno("Dzēst", "Dzēst šo ierakstu?", parent=self):
            self.app.db.x("DELETE FROM fin_entries WHERE id=?", (self.entry_id,))
            self.destroy()
            self.app.refresh_all()


# --------------------------------------------------------------------------
# Membership fee payment
# --------------------------------------------------------------------------
class FeePaymentForm(tk.Toplevel):
    """Register a membership fee payment of one dancer for one or several months."""

    def __init__(self, app, dancer_id=None, year=None, month=None):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Dalības maksas samaksa")
        self.transient(app.root)
        self.grab_set()
        db = app.db
        acc = piekluve.current()
        self.year = year or date.today().year
        self.all_dancers = db.dancers()
        self.rates, self.personal = db.fee_rates(), db.personal_fees()
        self.paid = fee_paid_by_month(db.entries())
        self.dancers = sorted((d for d in self.all_dancers.values()
                               if d["dancer"] and d["group"] in app.groups and acc.can_edit(MODULE_KEY, group=d["group"])
                               and (d["status"] != STATUS_LEFT or d["id"] == dancer_id)),
                              key=lambda d: _norm(d["name"]))
        tk.Label(self, text="Dalības maksas samaksa", font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))
        self.v = {k: tk.StringVar() for k in ("dancer", "date", "amount", "method", "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(BANK)

        tk.Label(self, text="Dejotājs *", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=4)
        self.names = [f"{d['name']} ({d['group']})" for d in self.dancers]
        cb = ttk.Combobox(self, textvariable=self.v["dancer"], values=self.names, state="readonly", width=34)
        cb.grid(row=1, column=1, columnspan=3, sticky="w", padx=(8, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.show_months())

        tk.Label(self, text="Gads", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
        self.year_var = tk.StringVar(value=str(self.year))
        ycb = ttk.Combobox(self, textvariable=self.year_var, state="readonly", width=8,
                           values=[str(y) for y in range(date.today().year - 3, date.today().year + 2)])
        ycb.grid(row=2, column=1, sticky="w", padx=(8, 0))
        ycb.bind("<<ComboboxSelected>>", lambda e: self.show_months())

        self.month_box = tk.LabelFrame(self, text=" Par mēnešiem ", bg=CREAM, fg=RED, font=("Georgia", 11, "bold"),
                                       padx=10, pady=6)
        self.month_box.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(8, 4))
        self.month_vars = {}
        self.month_cbs = {}
        for i in range(12):
            var = tk.BooleanVar(value=False)
            c = tk.Checkbutton(self.month_box, text=MONTHS[i], variable=var, bg=CREAM, fg=NAVY, anchor="w",
                               activebackground=CREAM, selectcolor=WHITE, width=20, command=self.update_amount)
            c.grid(row=i % 6, column=i // 6, sticky="w")
            self.month_vars[i + 1] = var
            self.month_cbs[i + 1] = c

        tk.Label(self, text="Summa, € *", bg=CREAM, fg=NAVY).grid(row=4, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.v["amount"], width=14).grid(row=4, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Datums *", bg=CREAM, fg=NAVY).grid(row=4, column=2, sticky="w", padx=(18, 0))
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=4, column=3, sticky="w", padx=(8, 0))
        ttk.Entry(drow, textvariable=self.v["date"], width=12).pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        tk.Label(self, text="Maksājuma veids", bg=CREAM, fg=NAVY).grid(row=5, column=0, sticky="w", pady=4)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=5, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Dokumenta nr.", bg=CREAM, fg=NAVY).grid(row=5, column=2, sticky="w", padx=(18, 0))
        ttk.Entry(self, textvariable=self.v["document"], width=16).grid(row=5, column=3, sticky="w", padx=(8, 0))
        self.info = tk.Label(self, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), justify="left",
                             wraplength=520)
        self.info.grid(row=6, column=0, columnspan=4, sticky="w", pady=(6, 0))

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=7, column=0, columnspan=4, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())

        if dancer_id is not None:
            for d, n in zip(self.dancers, self.names):
                if d["id"] == dancer_id:
                    self.v["dancer"].set(n)
        self.show_months(preselect=month)
        if not self.dancers:
            piekluve.make_readonly(self, note="Nav dejotāju, kuru dalības maksas jūsu loma var reģistrēt.")
        self.after(100, lambda: fit_min_size(self))

    def dancer(self):
        name = self.v["dancer"].get()
        for d, n in zip(self.dancers, self.names):
            if n == name:
                return d
        return None

    def show_months(self, preselect=None):
        d = self.dancer()
        year = int(self.year_var.get())
        paid = self.paid.get(d["id"], {}) if d else {}
        first_open = None
        for m, c in self.month_cbs.items():
            key = month_key(year, m)
            due = fee_due(self.rates, self.personal, d, key) if d else 0
            got = paid.get(key, 0)
            mark = ""
            if got and got >= due:
                mark = "  ✓"
            elif got:
                mark = f"  ({money(got, euro=False)})"
            c.configure(text=MONTHS[m - 1] + mark, fg=GREEN if mark.strip() == "✓" else NAVY)
            self.month_vars[m].set(False)
            if d and first_open is None and got < due and key >= (d["join"] or "")[:7]:
                first_open = m
        if preselect:
            self.month_vars[preselect].set(True)
        elif first_open:
            self.month_vars[first_open].set(True)
        if d:
            rate = fee_due(self.rates, self.personal, d, this_month())
            pers = self.personal.get(d["id"])
            self.info.configure(text=f"Mēneša maksa: {money(rate)}" + (f" (individuāla — {pers[1]})" if pers and pers[1]
                                                                    else " (individuāla)" if pers else
                                                                    f" ({d['group']} grupas maksa)") +
                                ". Ar ✓ atzīmētie mēneši jau samaksāti. Ja maksā par vairākiem mēnešiem, summa "
                                "tiek sadalīta vienādi.")
        else:
            self.info.configure(text="Izvēlieties dejotāju.")
        self.update_amount()

    def update_amount(self):
        d = self.dancer()
        if not d:
            return
        year = int(self.year_var.get())
        paid = self.paid.get(d["id"], {})
        total = 0
        for m, var in self.month_vars.items():
            if var.get():
                key = month_key(year, m)
                total += max(fee_due(self.rates, self.personal, d, key) - paid.get(key, 0), 0)
        self.v["amount"].set(money(total, euro=False).replace(" ", "") if total else "")

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = self.dancer()
        if not d:
            return messagebox.showwarning("Dejotājs", "Izvēlieties dejotāju.", parent=self)
        if not piekluve.current().can_edit(MODULE_KEY, group=d["group"]):
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        year = int(self.year_var.get())
        months = [month_key(year, m) for m, var in self.month_vars.items() if var.get()]
        if not months:
            return messagebox.showwarning("Mēneši", "Atzīmējiet, par kuriem mēnešiem samaksāts.", parent=self)
        cents = parse_money(self.v["amount"].get())
        if not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 15 vai 12,50.", parent=self)
        day = parse_date(self.v["date"].get())
        if not day:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        values = {"entry_date": day, "kind": INCOME, "category": FEE_CATEGORY, "amount_cents": cents,
                  "fin_group": d["group"], "method": self.v["method"].get(), "party": d["name"],
                  "dancer_id": d["id"], "session_id": None, "fee_months": ",".join(months),
                  "document": self.v["document"].get().strip(), "notes": ""}
        try:
            self.app.db.save_entry(values)
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return
        self.destroy()
        self.app.refresh_all()


# --------------------------------------------------------------------------
# Settings: fee rates, individual fees, opening balances, categories
# --------------------------------------------------------------------------
class FeeRatesWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Dalības maksas apmērs")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit(MODULE_KEY, group=g)]
        tk.Label(self, text="Dalības maksas apmērs", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text="Mēneša maksa katrai grupai un mēnesis, no kura tā spēkā. Ja maksa mainās, pievienojiet "
                            "jaunu rindu — iepriekšējie mēneši paliek ar veco maksu.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9), wraplength=520, justify="left").pack(anchor="w",
                                                                                                 pady=(2, 8))
        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=("group", "from", "amount"), show="headings", height=8)
        for key, text, w in (("group", "Grupa", 110), ("from", "Spēkā no", 150), ("amount", "Mēnesī", 110)):
            self.tree.heading(key, text=text)
            self.tree.column(key, width=w, anchor="w")
        make_tree_with_scroll(holder, self.tree)

        form = tk.Frame(self, bg=CREAM)
        form.pack(fill="x", pady=(10, 0))
        self.g = tk.StringVar(value=self.edit_groups[0] if self.edit_groups else "")
        self.y = tk.StringVar(value=str(date.today().year))
        self.m = tk.StringVar(value=MONTHS[date.today().month - 1])
        self.a = tk.StringVar()
        ttk.Combobox(form, textvariable=self.g, values=self.edit_groups, state="readonly", width=9).pack(side="left")
        tk.Label(form, text=" no ", bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Combobox(form, textvariable=self.m, values=MONTHS, state="readonly", width=11).pack(side="left")
        ttk.Combobox(form, textvariable=self.y, state="readonly", width=6,
                     values=[str(y) for y in range(date.today().year - 5, date.today().year + 3)]).pack(side="left",
                                                                                                         padx=(4, 0))
        tk.Label(form, text="  €/mēn. ", bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Entry(form, textvariable=self.a, width=8).pack(side="left")
        ttk.Button(form, text="＋ Pievienot", style="Accent.TButton", command=self.add).pack(side="left", padx=(8, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Dzēst izvēlēto", command=self.delete).pack(side="left")
        ttk.Button(btns, text="Aizvērt", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.refresh()
        if not self.edit_groups:
            piekluve.make_readonly(self)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for rid, group, start, cents in self.app.db.q("SELECT id, fin_group, valid_from, amount_cents FROM "
                                                      "fin_fee_rates ORDER BY fin_group, valid_from"):
            if group in self.app.groups:
                self.tree.insert("", "end", iid=str(rid), values=(group, month_label(start), money(cents)))

    def add(self):
        cents = parse_money(self.a.get())
        if cents is None:
            return messagebox.showwarning("Summa", "Ierakstiet mēneša maksu eiro (0, ja maksas nav).", parent=self)
        if self.g.get() not in self.edit_groups:
            return piekluve.deny(self)
        key = month_key(int(self.y.get()), MONTHS.index(self.m.get()) + 1)
        db = self.app.db
        if db.q("SELECT 1 FROM fin_fee_rates WHERE fin_group=? AND valid_from=?", (self.g.get(), key)):
            db.x("UPDATE fin_fee_rates SET amount_cents=? WHERE fin_group=? AND valid_from=?",
                 (cents, self.g.get(), key))
        else:
            db.x("INSERT INTO fin_fee_rates (fin_group, valid_from, amount_cents) VALUES (?, ?, ?)",
                 (self.g.get(), key, cents))
        self.a.set("")
        self.refresh()
        self.app.refresh_all()

    def delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        group = self.tree.item(sel[0], "values")[0]
        if group not in self.edit_groups:
            return piekluve.deny(self)
        self.app.db.x("DELETE FROM fin_fee_rates WHERE id=?", (int(sel[0]),))
        self.refresh()
        self.app.refresh_all()


class PersonalFeeForm(tk.Toplevel):
    """Individual monthly fee of one dancer (discount, or 0 = released from the fee)."""

    def __init__(self, app, dancer):
        super().__init__(app.root)
        self.app, self.dancer = app, dancer
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Individuāla dalības maksa")
        self.transient(app.root)
        self.grab_set()
        current = app.db.personal_fees().get(dancer["id"])
        tk.Label(self, text=dancer["name"], font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.on = tk.BooleanVar(value=current is not None)
        tk.Checkbutton(self, text="Individuāla mēneša maksa (atlaide vai atbrīvojums)", variable=self.on, bg=CREAM,
                       fg=NAVY, activebackground=CREAM, selectcolor=WHITE).grid(row=1, column=0, columnspan=2,
                                                                               sticky="w")
        self.a = tk.StringVar(value=money(current[0], euro=False).replace(" ", "") if current else "0")
        self.n = tk.StringVar(value=current[1] if current else "")
        tk.Label(self, text="Maksa, €/mēn.", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.a, width=10).grid(row=2, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Iemesls", bg=CREAM, fg=NAVY).grid(row=3, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.n, width=34).grid(row=3, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="0 € — dejotājs no dalības maksas atbrīvots. Ja atzīme noņemta, maksā grupas maksu.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).grid(row=4, column=0, columnspan=2, sticky="w")
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=5, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if not piekluve.current().can_edit(MODULE_KEY, group=dancer["group"]):
            piekluve.make_readonly(self)

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        db = self.app.db
        db.x("DELETE FROM fin_fee_personal WHERE dancer_id=?", (self.dancer["id"],))
        if self.on.get():
            cents = parse_money(self.a.get())
            if cents is None:
                return messagebox.showwarning("Summa", "Ierakstiet maksu eiro (0 — atbrīvots).", parent=self)
            db.x("INSERT INTO fin_fee_personal (dancer_id, amount_cents, note) VALUES (?, ?, ?)",
                 (self.dancer["id"], cents, self.n.get().strip()))
        self.destroy()
        self.app.refresh_all()


class OpeningWindow(tk.Toplevel):
    """Opening balances: the money the group had in cash and on the account before the first entry."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Sākuma atlikums")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        opening = app.db.opening()
        tk.Label(self, text="Sākuma atlikums", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=3, sticky="w")
        tk.Label(self, text="Cik naudas grupai bija kasē un kontā pirms pirmā Zelta pūrā ierakstītā darījuma.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9)).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))
        tk.Label(self, text="Kasē (skaidrā naudā), €", bg=CREAM, fg=NAVY).grid(row=2, column=1, padx=6)
        tk.Label(self, text="Kontā, €", bg=CREAM, fg=NAVY).grid(row=2, column=2, padx=6)
        self.vars = {}
        for r, g in enumerate(app.groups, start=3):
            tk.Label(self, text=g, bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).grid(row=r, column=0, sticky="w")
            for c, m in enumerate(METHODS, start=1):
                var = tk.StringVar(value=money(opening.get((g, m), 0), euro=False).replace(" ", ""))
                e = ttk.Entry(self, textvariable=var, width=12)
                e.grid(row=r, column=c, padx=6, pady=3)
                if not acc.can_edit(MODULE_KEY, group=g):
                    e.configure(state="readonly")
                self.vars[(g, m)] = var
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=10, column=0, columnspan=3, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")

    def save(self):
        acc = piekluve.current()
        db = self.app.db
        values = {}
        for (g, m), var in self.vars.items():
            if not acc.can_edit(MODULE_KEY, group=g):
                continue
            text = var.get().strip()
            neg = text.startswith("-") or text.startswith("−")
            cents = parse_money(text.lstrip("-−")) if text.lstrip("-−") else 0
            if cents is None:
                return messagebox.showwarning("Summa", f"{g}, {m}: nepareiza summa.", parent=self)
            values[(g, m)] = -cents if neg else cents
        for (g, m), cents in values.items():
            db.x("DELETE FROM fin_opening WHERE fin_group=? AND method=?", (g, m))
            db.x("INSERT INTO fin_opening (fin_group, method, amount_cents) VALUES (?, ?, ?)", (g, m, cents))
        self.destroy()
        self.app.refresh_all()


class CategoriesWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Kategorijas")
        self.transient(app.root)
        self.grab_set()
        tk.Label(self, text="Ienākumu un izdevumu kategorijas", font=("Georgia", 15, "bold"), bg=CREAM,
                 fg=RED).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.lists = {}
        for c, kind in enumerate(KINDS):
            box = tk.LabelFrame(self, text=f" {kind} ", bg=CREAM, fg=GREEN if kind == INCOME else RED,
                                font=("Georgia", 11, "bold"), padx=8, pady=6)
            box.grid(row=1, column=c, sticky="nsew", padx=(0 if c == 0 else 10, 0))
            lb = tk.Listbox(box, width=34, height=12, bg=WHITE, fg=NAVY, selectbackground=GOLD,
                            selectforeground=NAVY, activestyle="none", exportselection=False)
            lb.pack(fill="both", expand=True)
            row = tk.Frame(box, bg=CREAM)
            row.pack(fill="x", pady=(6, 0))
            ttk.Button(row, text="＋ Jauna", command=lambda k=kind: self.add(k)).pack(side="left")
            ttk.Button(row, text="Pārdēvēt", command=lambda k=kind: self.rename(k)).pack(side="left", padx=4)
            ttk.Button(row, text="Dzēst", command=lambda k=kind: self.delete(k)).pack(side="left")
            self.lists[kind] = lb
        tk.Label(self, text="Pārdēvējot kategoriju, tā tiek nomainīta arī visiem jau ierakstītajiem darījumiem. "
                            "Dzēst var tikai kategoriju, kas nav izmantota. “Dalības maksa” ir obligāta.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), wraplength=560, justify="left").grid(
            row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Button(self, text="Aizvērt", command=self.destroy).grid(row=3, column=1, sticky="e", pady=(10, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        self.refresh()
        if not piekluve.current().edits_all(MODULE_KEY):
            piekluve.make_readonly(self, note="Kategorijas ir kopīgas visām grupām — tās maina vadītājs vai "
                                              "sistēmas administrators.")

    def refresh(self):
        for kind, lb in self.lists.items():
            lb.delete(0, "end")
            for name in self.app.db.categories(kind):
                lb.insert("end", name)

    def chosen(self, kind):
        lb = self.lists[kind]
        sel = lb.curselection()
        return lb.get(sel[0]) if sel else None

    def ask(self, title, initial=""):
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=CREAM, padx=14, pady=12)
        win.transient(self)
        win.grab_set()
        var = tk.StringVar(value=initial)
        result = {}
        tk.Label(win, text="Nosaukums:", bg=CREAM, fg=NAVY).pack(anchor="w")
        e = ttk.Entry(win, textvariable=var, width=36)
        e.pack(fill="x", pady=4)
        e.focus_set()

        def ok(_e=None):
            result["v"] = var.get().strip()
            win.destroy()
        row = tk.Frame(win, bg=CREAM)
        row.pack(fill="x", pady=(6, 0))
        ttk.Button(row, text="Atcelt", command=win.destroy).pack(side="right", padx=4)
        ttk.Button(row, text="Labi", style="Accent.TButton", command=ok).pack(side="right")
        win.bind("<Return>", ok)
        win.bind("<Escape>", lambda e: win.destroy())
        self.wait_window(win)
        try:
            self.grab_set()
        except tk.TclError:
            pass
        return result.get("v")

    def add(self, kind):
        name = self.ask(f"Jauna kategorija — {kind}")
        if not name:
            return
        db = self.app.db
        if db.q("SELECT 1 FROM fin_categories WHERE kind=? AND name=?", (kind, name)):
            return messagebox.showinfo("Kategorija", "Tāda kategorija jau ir.", parent=self)
        pos = (db.q("SELECT COALESCE(MAX(position), 0) FROM fin_categories WHERE kind=?", (kind,))[0][0] or 0) + 1
        db.x("INSERT INTO fin_categories (kind, name, position) VALUES (?, ?, ?)", (kind, name, pos))
        self.refresh()
        self.app.refresh_all()

    def rename(self, kind):
        old = self.chosen(kind)
        if not old:
            return
        if old == FEE_CATEGORY:
            return messagebox.showinfo("Kategorija", "“Dalības maksa” nevar pārdēvēt — to izmanto dalības maksu "
                                                     "uzskaite.", parent=self)
        new = self.ask("Pārdēvēt kategoriju", old)
        if not new or new == old:
            return
        db = self.app.db
        if db.q("SELECT 1 FROM fin_categories WHERE kind=? AND name=?", (kind, new)):
            return messagebox.showinfo("Kategorija", "Tāda kategorija jau ir.", parent=self)
        db.con.execute("UPDATE fin_categories SET name=? WHERE kind=? AND name=?", (new, kind, old))
        db.con.execute("UPDATE fin_entries SET category=? WHERE kind=? AND category=?", (new, kind, old))
        db.con.commit()
        self.refresh()
        self.app.refresh_all()

    def delete(self, kind):
        name = self.chosen(kind)
        if not name:
            return
        if name == FEE_CATEGORY:
            return messagebox.showinfo("Kategorija", "“Dalības maksa” nevar dzēst.", parent=self)
        db = self.app.db
        used = db.q("SELECT COUNT(*) FROM fin_entries WHERE kind=? AND category=?", (kind, name))[0][0]
        if used:
            return messagebox.showinfo("Kategorija", f"Kategorija izmantota {used} darījumos — to nevar dzēst. "
                                                     "Varat to pārdēvēt.", parent=self)
        if messagebox.askyesno("Dzēst", f"Dzēst kategoriju “{name}”?", parent=self):
            db.x("DELETE FROM fin_categories WHERE kind=? AND name=?", (kind, name))
            self.refresh()
            self.app.refresh_all()


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
ENTRY_COLUMNS = [
    ("date", "Datums", 95),
    ("kind", "Veids", 85),
    ("category", "Kategorija", 190),
    ("amount", "Summa", 110),
    ("group", "Grupa", 70),
    ("party", "Maksātājs / saņēmējs", 190),
    ("method", "Maksājuma veids", 120),
    ("event", "Notikums", 200),
    ("document", "Dokuments", 110),
    ("notes", "Piezīmes", 220),
]


class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        acc = piekluve.current()
        groups = acc.groups(MODULE_KEY)
        # a role that may only look (none today) sees every group; the cashiers / presidents only their own
        self.groups = groups if groups else list(DANCER_GROUPS)
        self.can_edit_any = any(acc.can_edit(MODULE_KEY, group=g) for g in self.groups)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=CREAM, foreground=NAVY, font=("Segoe UI", 10))
        s.configure("TFrame", background=CREAM)
        s.configure("TLabel", background=CREAM, foreground=NAVY)
        s.configure("TButton", background=CREAM_DARK, foreground=NAVY, padding=(10, 5), borderwidth=1)
        s.map("TButton", background=[("active", GOLD)])
        s.configure("Accent.TButton", background=RED, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Accent.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Green.TButton", background=GREEN, foreground=CREAM, font=("Segoe UI", 10, "bold"))
        s.map("Green.TButton", background=[("active", NAVY)], foreground=[("active", CREAM)])
        s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=NAVY, rowheight=28,
                    bordercolor=GOLD)
        s.configure("Treeview.Heading", background=NAVY, foreground=CREAM, font=("Segoe UI", 10, "bold"),
                    padding=6)
        s.map("Treeview.Heading", background=[("active", RED)])
        s.map("Treeview", background=[("selected", GOLD)], foreground=[("selected", NAVY)])
        s.configure("TNotebook", background=CREAM, borderwidth=0)
        s.configure("TNotebook.Tab", background=CREAM_DARK, foreground=NAVY, padding=(16, 6),
                    font=("Segoe UI", 10, "bold"))
        s.map("TNotebook.Tab", background=[("selected", GOLD)], foreground=[("selected", NAVY)])

    # ---- layout -----------------------------------------------------------
    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        header = tk.Frame(self.root, bg=NAVY)
        header.pack(fill="x")
        header.columnconfigure(0, weight=1, uniform="h")
        header.columnconfigure(2, weight=1, uniform="h")
        left = tk.Frame(header, bg=NAVY)
        left.grid(row=0, column=0, sticky="w")
        logo = module_logo(left, MODULE_KEY, on_click=self.show_main)
        if logo is not None:
            logo.pack(side="left", padx=(16, 0), pady=6)
        title_box = tk.Frame(left, bg=NAVY)
        title_box.pack(side="left", padx=(12 if logo is not None else 20, 12), pady=12)
        tk.Label(title_box, text=PROGRAM_NAME, font=("Georgia", 20, "bold"), bg=NAVY, fg=CREAM).pack(anchor="w")
        centre = tk.Frame(header, bg=NAVY)
        centre.place(relx=0.5, rely=0.5, anchor="center")
        self.group_logo = group_logo(150, 40)
        tk.Label(centre, text=read_setting("app.group_name", "Tautas deju kolektīvs"),
                 font=("Georgia", 14, "italic"), bg=NAVY, fg=GOLD).pack(
            side="top", pady=(4, 2) if self.group_logo is not None else 12)
        if self.group_logo is not None:
            tk.Label(centre, image=self.group_logo, bg=NAVY).pack(side="top", pady=(0, 4))
        right = tk.Frame(header, bg=NAVY)
        right.grid(row=0, column=2, sticky="e", padx=14, pady=10)
        try:
            self.power_icon = tk.PhotoImage(data=HOME_ICON_B64 if self.on_exit is not None else POWER_ICON_B64)
        except Exception:
            self.power_icon = None
        embedded = self.on_exit is not None
        tk.Button(right, text=" Atgriezties moduļu izvēlē" if embedded else " Beigt darbu",
                  image=self.power_icon or "", compound="left",
                  command=self.on_exit if embedded else self.root.destroy, font=("Segoe UI", 11, "bold"),
                  bg=NAVY, fg=GOLD, activebackground=RED, activeforeground=CREAM, relief="flat", bd=0,
                  highlightthickness=2, highlightbackground=GOLD, highlightcolor=GOLD, cursor="hand2",
                  padx=12, pady=3).pack()
        tk.Frame(self.root, bg=GOLD, height=4).pack(fill="x")
        copyright_footer(self.root)

        # group + year (for every tab)
        top = tk.Frame(self.root, bg=CREAM)
        top.pack(fill="x", padx=18, pady=(10, 0))
        self.group_var = tk.StringVar(value=ALL_GROUPS if len(self.groups) > 1 else self.groups[0])
        self.year_var = tk.StringVar(value=str(date.today().year))
        tk.Label(top, text="Grupa:", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).pack(side="left")
        gcb = ttk.Combobox(top, textvariable=self.group_var, state="readonly", width=10,
                           values=([ALL_GROUPS] if len(self.groups) > 1 else []) + self.groups)
        gcb.pack(side="left", padx=(4, 16))
        tk.Label(top, text="Gads:", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).pack(side="left")
        self.year_cb = ttk.Combobox(top, textvariable=self.year_var, state="readonly", width=7)
        self.year_cb.pack(side="left", padx=4)
        for cb in (gcb, self.year_cb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_all())
        acc = piekluve.current()
        if not acc.edits_all(MODULE_KEY):
            text = ("🔒 tikai skatīšanai" if not self.can_edit_any else
                    "🔒 redzamas un labojamas tikai " + ", ".join(self.groups) + " grupas finanses")
            tk.Label(top, text=text, bg=CREAM, fg=RED, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(12, 0))
        ttk.Button(top, text="⚙ Kategorijas…", command=lambda: CategoriesWindow(self)).pack(side="right")
        ttk.Button(top, text="Sākuma atlikums…", command=lambda: OpeningWindow(self)).pack(side="right", padx=6)

        # summary cards
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=18, pady=(10, 6))
        self.card_vars = {}
        self.card_titles = {}
        for i, (key, title, colour) in enumerate([
                ("balance", "Atlikums kopā", NAVY),
                ("cash", "Kasē (skaidrā naudā)", DARK_GOLD),
                ("bank", "Kontā", NAVY),
                ("income", "Ienākumi", GREEN),
                ("expense", "Izdevumi", RED),
                ("debt", "Dalības maksu parāds", AMBER)]):
            card = tk.Frame(cards, bg=WHITE, highlightbackground=colour, highlightthickness=3)
            card.grid(row=0, column=i, padx=5, sticky="ew")
            cards.columnconfigure(i, weight=1, uniform="card")
            var = tk.StringVar(value="—")
            tvar = tk.StringVar(value=title)
            self.card_vars[key] = var
            self.card_titles[key] = (tvar, title)
            tk.Label(card, textvariable=var, font=("Georgia", 17, "bold"), bg=WHITE, fg=colour).pack(pady=(6, 0))
            tk.Label(card, textvariable=tvar, font=("Segoe UI", 9), bg=WHITE, fg=NAVY).pack(pady=(0, 6))

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=18, pady=(6, 6))
        self.build_entries_tab()
        self.build_fees_tab()
        self.build_events_tab()
        self.build_report_tab()
        self.refresh_all()

    # ---- tab: Darījumi -------------------------------------------------------
    def build_entries_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Darījumi  ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=(8, 4))
        b1 = ttk.Button(bar, text="＋ Ienākums", style="Green.TButton",
                        command=lambda: EntryForm(self, kind=INCOME))
        b1.pack(side="left")
        b2 = ttk.Button(bar, text="－ Izdevums", style="Accent.TButton",
                        command=lambda: EntryForm(self, kind=EXPENSE))
        b2.pack(side="left", padx=6)
        ttk.Button(bar, text="Atvērt" if not self.can_edit_any else "Rediģēt",
                   command=self.edit_entry).pack(side="left", padx=3)
        b3 = ttk.Button(bar, text="Dzēst", command=self.delete_entry)
        b3.pack(side="left", padx=3)
        if not self.can_edit_any:
            for b in (b1, b2, b3):
                b.configure(state="disabled")
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_entries).pack(side="right")

        flt = ttk.Frame(tab)
        flt.pack(fill="x", pady=(2, 4))
        self.search = tk.StringVar()
        self.f_kind = tk.StringVar(value=ALL)
        self.f_cat = tk.StringVar(value=ALL)
        self.f_month = tk.StringVar(value=ALL)
        ttk.Label(flt, text="Meklēt:").pack(side="left")
        ttk.Entry(flt, textvariable=self.search, width=22).pack(side="left", padx=(4, 14))
        self.search.trace_add("write", lambda *a: self.refresh_entries())
        ttk.Label(flt, text="Mēnesis:").pack(side="left")
        mcb = ttk.Combobox(flt, textvariable=self.f_month, values=[ALL] + MONTHS, state="readonly", width=11)
        mcb.pack(side="left", padx=(4, 14))
        ttk.Label(flt, text="Veids:").pack(side="left")
        kcb = ttk.Combobox(flt, textvariable=self.f_kind, values=[ALL] + KINDS, state="readonly", width=10)
        kcb.pack(side="left", padx=(4, 14))
        ttk.Label(flt, text="Kategorija:").pack(side="left")
        self.cat_filter = ttk.Combobox(flt, textvariable=self.f_cat, state="readonly", width=26)
        self.cat_filter.pack(side="left", padx=4)
        for cb in (mcb, kcb, self.cat_filter):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_entries())
        ttk.Button(flt, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")

        holder = ttk.Frame(tab)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in ENTRY_COLUMNS], show="headings")
        for key, title, width in ENTRY_COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=50, anchor="e" if key == "amount" else "w",
                             stretch=key == "notes")
        self.tree.tag_configure(INCOME, foreground=GREEN)
        self.tree.tag_configure(EXPENSE, foreground=RED)
        self.tree.bind("<Double-1>", lambda e: self.edit_entry())
        make_tree_with_scroll(holder, self.tree)
        self.entries_info = tk.StringVar()
        tk.Label(tab, textvariable=self.entries_info, bg=CREAM, fg=NAVY, font=("Segoe UI", 9, "italic")).pack(
            anchor="w", pady=(4, 0))
        self.sort_key, self.sort_desc = "date", True

    # ---- tab: Dalības maksas -------------------------------------------------
    def build_fees_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Dalības maksas  ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=(8, 4))
        b1 = ttk.Button(bar, text="＋ Reģistrēt samaksu", style="Green.TButton", command=self.fee_payment)
        b1.pack(side="left")
        b2 = ttk.Button(bar, text="Individuāla maksa…", command=self.personal_fee)
        b2.pack(side="left", padx=6)
        ttk.Button(bar, text="Dalības maksas apmērs…", command=lambda: FeeRatesWindow(self)).pack(side="left")
        if not self.can_edit_any:
            for b in (b1, b2):
                b.configure(state="disabled")
        self.fee_show_left = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Rādīt arī izstājušos", variable=self.fee_show_left, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_fees).pack(side="left",
                                                                                                  padx=(14, 0))
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_fees).pack(side="right")
        cols = ["name", "group", "rate"] + [f"m{i}" for i in range(1, 13)] + ["paid", "debt"]
        holder = ttk.Frame(tab)
        holder.pack(fill="both", expand=True)
        self.fee_tree = ttk.Treeview(holder, columns=cols, show="headings")
        self.fee_tree.heading("name", text="Dejotājs")
        self.fee_tree.column("name", width=180, anchor="w")
        self.fee_tree.heading("group", text="Grupa")
        self.fee_tree.column("group", width=65, anchor="w")
        self.fee_tree.heading("rate", text="€/mēn.")
        self.fee_tree.column("rate", width=65, anchor="e")
        for i in range(1, 13):
            self.fee_tree.heading(f"m{i}", text=MONTHS_SHORT[i - 1])
            self.fee_tree.column(f"m{i}", width=52, minwidth=40, anchor="center")
        self.fee_tree.heading("paid", text="Samaksāts")
        self.fee_tree.column("paid", width=95, anchor="e")
        self.fee_tree.heading("debt", text="Parāds")
        self.fee_tree.column("debt", width=95, anchor="e")
        self.fee_tree.tag_configure("debt", foreground=RED)
        self.fee_tree.tag_configure("ok", foreground=GREEN)
        self.fee_tree.tag_configure("pause", foreground=AMBER)
        self.fee_tree.tag_configure("left", foreground=GREY)
        self.fee_tree.bind("<Double-1>", self.fee_double_click)
        make_tree_with_scroll(holder, self.fee_tree)
        tk.Label(tab, text="✓ samaksāts · skaitlis — samaksāta daļa · ✗ nav samaksāts · – maksa nepienākas "
                           "(pirms iestāšanās vai 0 €) · tukšs — mēnesis vēl nav pienācis. Parāds skaitās līdz "
                           "šim mēnesim, dejotājiem “Uz pauzes” un izstājušamies — netiek skaitīts. "
                           "Dubultklikšķis uz mēneša — reģistrēt samaksu.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic"), wraplength=1100, justify="left").pack(
            anchor="w", pady=(4, 0))

    # ---- tab: Honorāri --------------------------------------------------------
    def build_events_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Honorāri  ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=(8, 4))
        b = ttk.Button(bar, text="＋ Reģistrēt saņemto honorāru", style="Green.TButton", command=self.register_fee)
        b.pack(side="left")
        if not self.can_edit_any:
            b.configure(state="disabled")
        self.ev_only_open = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Tikai nesaņemtie", variable=self.ev_only_open, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_events).pack(side="left",
                                                                                                    padx=(14, 0))
        cols = [("date", "Datums", 95), ("kind", "Veids", 130), ("title", "Notikums", 260), ("groups", "Grupa", 90),
                ("fee", "Honorārs (Notikumu pūrā)", 200), ("got", "Saņemts", 110), ("status", "Statuss", 120)]
        holder = ttk.Frame(tab)
        holder.pack(fill="both", expand=True)
        self.ev_tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.ev_tree.heading(key, text=title)
            self.ev_tree.column(key, width=width, anchor="e" if key == "got" else "w", stretch=key == "title")
        self.ev_tree.tag_configure("open", foreground=RED)
        self.ev_tree.tag_configure("done", foreground=GREEN)
        self.ev_tree.bind("<Double-1>", lambda e: self.register_fee())
        make_tree_with_scroll(holder, self.ev_tree)
        tk.Label(tab, text="Notikumi, kuriem Notikumu pūrā ierakstīts honorārs (vai kuriem Zelta pūrā piesaistīts "
                           "ienākums). Saņemto honorāru reģistrē kā ienākumu — tas tiek piesaistīts notikumam.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 8, "italic")).pack(anchor="w", pady=(4, 0))

    # ---- tab: Pārskats --------------------------------------------------------
    def build_report_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Pārskats  ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=(8, 4))
        self.report_title = tk.StringVar()
        tk.Label(bar, textvariable=self.report_title, bg=CREAM, fg=RED, font=("Georgia", 13, "bold")).pack(
            side="left")
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_report).pack(side="right")
        body = ttk.Frame(tab)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        left = ttk.Frame(body)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.cat_tree = ttk.Treeview(left, columns=("category", "count", "sum"), show="tree headings")
        self.cat_tree.heading("#0", text="")
        self.cat_tree.column("#0", width=24, stretch=False)
        for key, text, w in (("category", "Kategorija", 230), ("count", "Darījumi", 70), ("sum", "Summa", 120)):
            self.cat_tree.heading(key, text=text)
            self.cat_tree.column(key, width=w, anchor="e" if key != "category" else "w")
        self.cat_tree.tag_configure(INCOME, foreground=GREEN, font=("Segoe UI", 10, "bold"))
        self.cat_tree.tag_configure(EXPENSE, foreground=RED, font=("Segoe UI", 10, "bold"))
        self.cat_tree.tag_configure("total", foreground=NAVY, font=("Segoe UI", 10, "bold"))
        make_tree_with_scroll(left, self.cat_tree)
        right = ttk.Frame(body)
        right.grid(row=0, column=1, sticky="nsew")
        self.month_tree = ttk.Treeview(right, columns=("month", "in", "out", "diff", "balance"), show="headings")
        for key, text, w in (("month", "Mēnesis", 110), ("in", "Ienākumi", 110), ("out", "Izdevumi", 110),
                             ("diff", "Starpība", 110), ("balance", "Atlikums mēneša beigās", 160)):
            self.month_tree.heading(key, text=text)
            self.month_tree.column(key, width=w, anchor="w" if key == "month" else "e")
        self.month_tree.tag_configure("neg", foreground=RED)
        self.month_tree.tag_configure("total", font=("Segoe UI", 10, "bold"))
        make_tree_with_scroll(right, self.month_tree)

    # ---- data helpers ----------------------------------------------------------
    def chosen_groups(self):
        g = self.group_var.get()
        return list(self.groups) if g == ALL_GROUPS else [g]

    def year(self):
        try:
            return int(self.year_var.get())
        except ValueError:
            return date.today().year

    def visible_entries(self):
        groups = set(self.chosen_groups())
        return [e for e in self.all_entries if (e["fin_group"] or DEFAULT_DANCER_GROUP) in groups]

    def show_main(self):
        self.nb.select(0)
        self.clear_filters()
        self.tree.yview_moveto(0)

    def clear_filters(self):
        self.search.set("")
        self.f_kind.set(ALL)
        self.f_cat.set(ALL)
        self.f_month.set(ALL)
        self.refresh_entries()

    def sort_by(self, key):
        self.sort_desc = not self.sort_desc if key == self.sort_key else key in ("date", "amount")
        self.sort_key = key
        self.refresh_entries()

    # ---- refresh -----------------------------------------------------------------
    def refresh_all(self):
        try:
            self.all_entries = self.db.entries()
            self.dancer_map = self.db.dancers()
            self.event_map = {e[0]: e for e in self.db.events()}
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Neizdevās nolasīt datus:\n{exc}", parent=self.root)
            return
        years = {date.today().year}
        years.update(int(e["entry_date"][:4]) for e in self.all_entries if (e["entry_date"] or "")[:4].isdigit())
        self.year_cb.configure(values=[str(y) for y in sorted(years, reverse=True)])
        cats = [n for _k, n in self.db.categories()]
        self.cat_filter.configure(values=[ALL] + list(dict.fromkeys(cats)))
        self.refresh_cards()
        self.refresh_entries()
        self.refresh_fees()
        self.refresh_events()
        self.refresh_report()

    def balance_parts(self, until=None):
        """(cash, bank) of the chosen groups: opening balances + entries up to `until` (ISO date, included)."""
        groups = set(self.chosen_groups())
        opening = self.db.opening()
        totals = {CASH: 0, BANK: 0}
        for (g, m), cents in opening.items():
            if g in groups and m in totals:
                totals[m] += cents
        for e in self.visible_entries():
            if until and (e["entry_date"] or "") > until:
                continue
            m = e["method"] if e["method"] in totals else BANK
            totals[m] += e["amount_cents"] if e["kind"] == INCOME else -e["amount_cents"]
        return totals[CASH], totals[BANK]

    def refresh_cards(self):
        cash, bank = self.balance_parts()
        year = str(self.year())
        rows = [e for e in self.visible_entries() if (e["entry_date"] or "").startswith(year)]
        income = sum(e["amount_cents"] for e in rows if e["kind"] == INCOME)
        expense = sum(e["amount_cents"] for e in rows if e["kind"] == EXPENSE)
        self.card_vars["balance"].set(money(cash + bank))
        self.card_vars["cash"].set(money(cash))
        self.card_vars["bank"].set(money(bank))
        self.card_vars["income"].set(money(income))
        self.card_vars["expense"].set(money(expense))
        self.card_titles["income"][0].set(f"Ienākumi {year}")
        self.card_titles["expense"][0].set(f"Izdevumi {year}")
        self.card_vars["debt"].set(money(self.fee_debt_total()))

    def event_text(self, sid):
        ev = self.event_map.get(sid)
        if not ev:
            return ""
        return f"{show_date(ev[1])} · {ev[3] or ev[2]}"

    def refresh_entries(self):
        year = str(self.year())
        term = _norm(self.search.get())
        month = self.f_month.get()
        rows = []
        for e in self.visible_entries():
            if not (e["entry_date"] or "").startswith(year):
                continue
            if month != ALL and (e["entry_date"] or "")[5:7] != f"{MONTHS.index(month) + 1:02d}":
                continue
            if self.f_kind.get() != ALL and e["kind"] != self.f_kind.get():
                continue
            if self.f_cat.get() != ALL and e["category"] != self.f_cat.get():
                continue
            r = {"id": e["id"], "date": e["entry_date"] or "", "kind": e["kind"], "category": e["category"] or "",
                 "amount": e["amount_cents"] if e["kind"] == INCOME else -e["amount_cents"],
                 "group": e["fin_group"] or "", "party": e["party"] or "", "method": e["method"] or "",
                 "event": self.event_text(e["session_id"]), "document": e["document"] or "",
                 "notes": " ".join((e["notes"] or "").split())}
            if e["category"] == FEE_CATEGORY and e["fee_months"]:
                months = ", ".join(MONTHS_SHORT[int(m[5:7]) - 1] + " " + m[:4] for m in parse_months(e["fee_months"]))
                r["notes"] = f"par {months}" + (f" · {r['notes']}" if r["notes"] else "")
            if term and term not in _norm(" ".join(str(v) for k, v in r.items() if k != "id")):
                continue
            rows.append(r)

        def key(r):
            v = r[self.sort_key]
            return (0, v) if isinstance(v, int) else (v == "", _norm(v))
        rows.sort(key=lambda r: r["id"], reverse=True)
        rows.sort(key=key, reverse=self.sort_desc)
        keep = self.tree.selection()[0] if self.tree.selection() else None
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            values = [show_date(r["date"]) if k == "date" else money(r["amount"], sign=True) if k == "amount"
                      else r[k] for k, _t, _w in ENTRY_COLUMNS]
            self.tree.insert("", "end", iid=str(r["id"]), values=values, tags=(r["kind"],))
        if keep and self.tree.exists(keep):
            self.tree.selection_set(keep)
        inc = sum(r["amount"] for r in rows if r["amount"] > 0)
        out = -sum(r["amount"] for r in rows if r["amount"] < 0)
        self.shown_entries = rows
        self.entries_info.set(f"Rādīti {len(rows)} darījumi ({year}): ienākumi {money(inc)}, izdevumi {money(out)}, "
                              f"starpība {money(inc - out, sign=True)}. Dubultklikšķis — atvērt; klikšķis uz "
                              "virsraksta — kārtot.")

    # ---- fees ------------------------------------------------------------------------
    def fee_rows(self, year):
        """[(dancer, {month: (due, paid)}, paid total, debt)] for the chosen groups and year."""
        rates, personal = self.db.fee_rates(), self.db.personal_fees()
        paid = fee_paid_by_month(self.all_entries)
        groups = set(self.chosen_groups())
        now = this_month()
        until = month_key(year, 12) if month_key(year, 12) < now else now
        out = []
        for d in sorted(self.dancer_map.values(), key=lambda d: _norm(d["name"])):
            if not d["dancer"] or d["group"] not in groups:
                continue
            got = paid.get(d["id"], {})
            year_paid = sum(v for m, v in got.items() if m.startswith(f"{year:04d}-"))
            if d["status"] == STATUS_LEFT and not year_paid and not self.fee_show_left.get():
                continue
            cells = {}
            debt = 0
            counted = d["status"] == STATUS_ACTIVE
            due_list = set(due_months(d, year, month_key(year, 12)))
            for m in range(1, 13):
                key = month_key(year, m)
                due = fee_due(rates, personal, d, key) if key in due_list else 0
                cells[m] = (due, got.get(key, 0), key <= now)
                if counted and key <= until and key in due_list:
                    debt += max(due - got.get(key, 0), 0)
            out.append((d, cells, year_paid, debt))
        return out

    def fee_debt_total(self):
        try:
            return sum(r[3] for r in self.fee_rows(self.year()))
        except Exception:
            log_error(traceback.format_exc())
            return 0

    def refresh_fees(self):
        year = self.year()
        rates, personal = self.db.fee_rates(), self.db.personal_fees()
        keep = self.fee_tree.selection()[0] if self.fee_tree.selection() else None
        self.fee_tree.delete(*self.fee_tree.get_children())
        self.fee_export = []
        for d, cells, year_paid, debt in self.fee_rows(year):
            values = [d["name"] + ("" if d["status"] == STATUS_ACTIVE else f" ({d['status'].lower()})"), d["group"]]
            rate = fee_due(rates, personal, d, this_month())
            values.append(money(rate, euro=False) + ("*" if d["id"] in personal else ""))
            exp = [d["name"], d["group"], d["status"], money_plain(rate)]
            for m in range(1, 13):
                due, got, past = cells[m]
                if got and got >= due:
                    cell = "✓"
                elif got:
                    cell = money(got, euro=False)
                elif not due:
                    cell = "–"
                elif past:
                    cell = "✗"
                else:
                    cell = ""
                values.append(cell)
                exp.append(money_plain(got) if got else ("" if not due else "0"))
            values += [money(year_paid), money(debt) if debt else "—"]
            exp += [money_plain(year_paid), money_plain(debt)]
            tag = ("left" if d["status"] == STATUS_LEFT else "pause" if d["status"] == STATUS_INACTIVE
                   else "debt" if debt else "ok")
            self.fee_tree.insert("", "end", iid=str(d["id"]), values=values, tags=(tag,))
            self.fee_export.append(exp)
        if keep and self.fee_tree.exists(keep):
            self.fee_tree.selection_set(keep)
        missing = [g for g in self.chosen_groups() if not rates.get(g)]
        self.fee_tree.heading("rate", text="€/mēn." + (" ⚠" if missing else ""))

    def selected_fee_dancer(self):
        sel = self.fee_tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sarakstā.", parent=self.root)
            return None
        return self.dancer_map.get(int(sel[0]))

    def fee_payment(self, dancer_id=None, month=None):
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        if not self.db.fee_rates():
            if messagebox.askyesno("Dalības maksa", "Dalības maksas apmērs vēl nav iestatīts. Iestatīt tagad?",
                                   parent=self.root):
                FeeRatesWindow(self)
            return
        if dancer_id is None and self.fee_tree.selection():
            dancer_id = int(self.fee_tree.selection()[0])
        FeePaymentForm(self, dancer_id, self.year(), month)

    def fee_double_click(self, event):
        row = self.fee_tree.identify_row(event.y)
        col = self.fee_tree.identify_column(event.x)
        if not row:
            return
        month = None
        try:   # the column id (also when some columns are hidden with the right mouse button)
            cid = str(self.fee_tree.column(col, "id")) if col else ""
        except tk.TclError:
            cid = ""
        if re.fullmatch(r"m\d{1,2}", cid):
            month = int(cid[1:])
        self.fee_tree.selection_set(row)
        if month is not None:
            paid_entries = [e for e in self.all_entries if e["category"] == FEE_CATEGORY
                            and e["dancer_id"] == int(row) and month_key(self.year(), month) in
                            parse_months(e["fee_months"])]
            due, got, _past = self.fee_rows_cache_cell(int(row), month)
            if got and got >= due and paid_entries:   # paid: show the payment
                return EntryForm(self, paid_entries[-1]["id"])
        self.fee_payment(int(row), month)

    def fee_rows_cache_cell(self, dancer_id, month):
        for d, cells, _p, _debt in self.fee_rows(self.year()):
            if d["id"] == dancer_id:
                return cells[month]
        return (0, 0, False)

    def personal_fee(self):
        d = self.selected_fee_dancer()
        if d:
            PersonalFeeForm(self, d)

    # ---- honoraria ---------------------------------------------------------------------
    def refresh_events(self):
        year = str(self.year())
        groups = set(self.chosen_groups())
        received = {}
        for e in self.visible_entries():
            if e["session_id"] and e["kind"] == INCOME:
                received[e["session_id"]] = received.get(e["session_id"], 0) + e["amount_cents"]
        self.ev_tree.delete(*self.ev_tree.get_children())
        for sid, d, kind, title, for_groups, fee in self.event_map.values():
            if not (d or "").startswith(year):
                continue
            ev_groups = [g.strip() for g in (for_groups or "").split(",") if g.strip()]
            if ev_groups and not (set(ev_groups) & groups):
                continue
            fee = (fee or "").strip()
            got = received.get(sid, 0)
            if not fee and not got:
                continue
            done = bool(got)
            if self.ev_only_open.get() and done:
                continue
            self.ev_tree.insert("", "end", iid=str(sid), tags=("done" if done else "open",), values=(
                show_date(d), kind, title, ", ".join(ev_groups) or "visas", fee, money(got) if got else "—",
                "✓ saņemts" if done else ("nākotnē" if d > date.today().isoformat() else "✗ nav saņemts")))

    def register_fee(self):
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        sel = self.ev_tree.selection()
        if not sel:
            return messagebox.showinfo("Izvēle", "Izvēlieties notikumu sarakstā.", parent=self.root)
        sid = int(sel[0])
        ev = self.event_map.get(sid)
        preset = {"event": sid, "category": FEE_CATEGORY_EVENT, "method": BANK}
        if ev:
            cents = parse_money(re.sub(r"[^\d,.\s€]", "", ev[5] or "").strip())
            if cents:
                preset["amount"] = money(cents, euro=False).replace(" ", "")
            ev_groups = [g.strip() for g in (ev[4] or "").split(",") if g.strip()]
            for g in ev_groups:
                if g in self.groups:
                    preset["group"] = g
                    break
            preset["party"] = ""
        if FEE_CATEGORY_EVENT not in self.db.categories(INCOME):
            preset.pop("category")
        EntryForm(self, kind=INCOME, preset=preset)

    # ---- report ------------------------------------------------------------------------
    def refresh_report(self):
        year = self.year()
        y = f"{year:04d}"
        self.report_title.set(f"{y}. gads — " + ", ".join(self.chosen_groups()) +
                              (" grupa" if len(self.chosen_groups()) == 1 else " grupas"))
        rows = [e for e in self.visible_entries() if (e["entry_date"] or "").startswith(y)]
        self.cat_tree.delete(*self.cat_tree.get_children())
        self.report_export = []
        totals = {}
        for kind in KINDS:
            sums = {}
            for e in rows:
                if e["kind"] == kind:
                    c = e["category"] or "(bez kategorijas)"
                    n, s = sums.get(c, (0, 0))
                    sums[c] = (n + 1, s + e["amount_cents"])
            total = sum(s for _n, s in sums.values())
            totals[kind] = total
            parent = self.cat_tree.insert("", "end", open=True, tags=(kind,), values=(
                kind, sum(n for n, _s in sums.values()), money(total)))
            self.report_export.append([kind, "", money_plain(total)])
            for c, (n, s) in sorted(sums.items(), key=lambda kv: -kv[1][1]):
                self.cat_tree.insert(parent, "end", values=(c, n, money(s)))
                self.report_export.append(["", c, money_plain(s)])
        self.cat_tree.insert("", "end", tags=("total",), values=(
            "Starpība", "", money(totals[INCOME] - totals[EXPENSE], sign=True)))
        self.report_export.append(["Starpība", "", money_plain(totals[INCOME] - totals[EXPENSE])])

        self.month_tree.delete(*self.month_tree.get_children())
        cash, bank = self.balance_parts(until=f"{year - 1:04d}-12-31")
        balance = cash + bank
        self.month_tree.insert("", "end", tags=("total",), values=(
            "Gada sākumā", "", "", "", money(balance)))
        self.month_export = [["Gada sākumā", "", "", "", money_plain(balance)]]
        for m in range(1, 13):
            prefix = f"{y}-{m:02d}"
            inc = sum(e["amount_cents"] for e in rows if e["kind"] == INCOME and e["entry_date"].startswith(prefix))
            out = sum(e["amount_cents"] for e in rows if e["kind"] == EXPENSE and e["entry_date"].startswith(prefix))
            balance += inc - out
            self.month_tree.insert("", "end", tags=("neg",) if balance < 0 else (), values=(
                MONTHS[m - 1], money(inc) if inc else "", money(out) if out else "",
                money(inc - out, sign=True) if inc or out else "", money(balance)))
            self.month_export.append([MONTHS[m - 1], money_plain(inc), money_plain(out), money_plain(inc - out),
                                      money_plain(balance)])
        self.month_tree.insert("", "end", tags=("total",), values=(
            "Kopā", money(totals[INCOME]), money(totals[EXPENSE]), money(totals[INCOME] - totals[EXPENSE], sign=True),
            money(balance)))
        self.month_export.append(["Kopā", money_plain(totals[INCOME]), money_plain(totals[EXPENSE]),
                                  money_plain(totals[INCOME] - totals[EXPENSE]), money_plain(balance)])

    # ---- entries: open / delete / export -----------------------------------------------
    def selected_entry(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties darījumu sarakstā.", parent=self.root)
            return None
        return int(sel[0])

    def edit_entry(self):
        eid = self.selected_entry()
        if eid is not None:
            EntryForm(self, eid)

    def delete_entry(self):
        eid = self.selected_entry()
        if eid is None:
            return
        e = self.db.entry(eid)
        if e is None:
            self.refresh_all()
            return
        if not piekluve.current().can_edit(MODULE_KEY, group=e["fin_group"]):
            return piekluve.deny(self.root, "Šīs grupas finanses jūsu loma nevar mainīt.")
        text = f"{show_date(e['entry_date'])} · {e['category']} · {money(e['amount_cents'])}"
        if messagebox.askyesno("Dzēst", f"Dzēst darījumu?\n\n{text}", parent=self.root):
            self.db.x("DELETE FROM fin_entries WHERE id=?", (eid,))
            self.refresh_all()

    def export_entries(self):
        header = [t for _k, t, _w in ENTRY_COLUMNS]
        rows = []
        for r in getattr(self, "shown_entries", []):
            rows.append([show_date(r["date"]) if k == "date" else money_plain(r["amount"]) if k == "amount"
                         else r[k] for k, _t, _w in ENTRY_COLUMNS])
        save_csv(self.root, "Eksportēt darījumus", f"Zelta pūrs darījumi {self.year()}.csv", header, rows)

    def export_fees(self):
        header = ["Dejotājs", "Grupa", "Statuss", "€/mēn."] + MONTHS + ["Samaksāts", "Parāds"]
        save_csv(self.root, "Eksportēt dalības maksas", f"Zelta pūrs dalības maksas {self.year()}.csv", header,
                 getattr(self, "fee_export", []))

    def export_report(self):
        rows = [["Pa kategorijām"], ["Veids", "Kategorija", "Summa"]] + self.report_export + [[]]
        rows += [["Pa mēnešiem"], ["Mēnesis", "Ienākumi", "Izdevumi", "Starpība", "Atlikums"]] + self.month_export
        save_csv(self.root, "Eksportēt pārskatu", f"Zelta pūrs pārskats {self.year()}.csv",
                 [f"Zelta pūrs — pārskats {self.year()}", ", ".join(self.chosen_groups())], rows)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
