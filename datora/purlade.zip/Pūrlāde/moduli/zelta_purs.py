#!/usr/bin/env python3
"""
Pūrlāde — modulis "Zelta pūrs" (kolektīva finanšu pārvaldībai)

Ko modulis dara:
  * Darījumi      — visi ienākumi un izdevumi (datums, kategorija, summa, grupa, maksātājs / saņēmējs,
                    skaidrā naudā vai pārskaitījums, dokumenta nr., saistītais notikums no Notikumu pūra);
  * Dalības maksas — katram dejotājam pa mēnešiem: samaksāts / parāds; maksas apmērs katrai grupai (ar datumu,
                    no kura tas spēkā) un individuāla maksa (atlaide vai atbrīvojums) atsevišķiem dejotājiem;
  * Autobusi      — Notikumu pūra notikumi, kuriem transports ir autobuss ar cenu: kam jāmaksā (dejotāji, kuri
                    dejo, un tie, kas atzīmēti “brauks ar autobusu”), kas samaksājis, parāds; samaksa — ienākums
                    “Iemaksas par autobusiem un pasākumiem”, piesaistīts notikumam un dejotājam (Kabatas Pūrlādē
                    dejotājs redz, cik jāmaksā, līdz samaksāts);
  * Honorāri      — Notikumu pūra notikumi ar ierakstītu honorāru: vai tas jau saņemts (ienākums piesaistīts
                    notikumam);
  * Pārskats      — gada ienākumi un izdevumi pa kategorijām un mēnešiem, atlikums; eksports uz CSV (Excel).
Augšā: atlikums kopā, kasē (skaidrā naudā) un kontā, gada ienākumi / izdevumi un dalības maksu parāds.

Piekļuve (moduli/piekluve.py): vadītājs, repetitors, sistēmas administrators — visas grupas;
A grupas kasieris / Prezidents — tikai A grupas finanses; Studijas kasieris / Studijas vecākais — tikai Studijas.
Citu grupu finanses šīm lomām netiek rādītas vispār.

Summas glabā centos (veseli skaitļi), lai nerastos noapaļošanas kļūdas. Datumi — DD.MM.GGGG.
Divi lietotāji vienlaikus: saglabājot pārbauda, vai ierakstu kāds cits pa to laiku nav mainījis vai dzēsis.

Requirements: Python 3.8+ (only the standard library: tkinter + sqlite3).
Normally started from Pūrlāde. It can also be run on its own:
              python moduli/zelta_purs.py
"""

import csv
import re
import sqlite3
import traceback
import tkinter as tk
from datetime import date, datetime
from tkinter import ttk, messagebox, filedialog

try:  # kopīgais izskats (Pūrlāde v0.8)
    from moduli import izskats
except ImportError:
    import izskats

try:  # who may change what (lietotāju lomas)
    from moduli import piekluve
except ImportError:
    import piekluve

try:  # started from Pūrlāde
    from moduli.kopeja import BUS_CATEGORY, BUS_REASON_DANCES, bus_dues
except ImportError:  # started directly from the moduli folder
    from kopeja import BUS_CATEGORY, BUS_REASON_DANCES, bus_dues

try:  # started from Pūrlāde
    from moduli.kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                               copyright_footer, module_logo, console_is_own, set_console_visible,
                               ensure_dancer_schema, full_name, parse_date, date_picker_button, _norm,
                               POWER_ICON_B64, HOME_ICON_B64, DANCER_GROUPS, DEFAULT_DANCER_GROUP,
                               STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT, ROLE_DANCER,
                               CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)
except ImportError:  # started directly from the moduli folder
    from kopeja import (DB_PATH, connect_db, ERROR_LOG, prepare_database, log_error, group_logo, read_setting,
                        copyright_footer, module_logo, console_is_own, set_console_visible,
                        ensure_dancer_schema, full_name, parse_date, date_picker_button, _norm,
                        POWER_ICON_B64, HOME_ICON_B64, DANCER_GROUPS, DEFAULT_DANCER_GROUP,
                        STATUS_ACTIVE, STATUS_INACTIVE, STATUS_LEFT, ROLE_DANCER,
                        CREAM, CREAM_DARK, RED, NAVY, GOLD, WHITE, GREEN, GREY)

PROGRAM_NAME = "Zelta pūrs"
APP_VERSION = "0.1.6"
MODULE_KEY = "zelta_purs"
DARK_GOLD = "#8A6D0B"
AMBER = "#B07D00"

# Description for the Pūrlāde start page
MODULE = {
    "name": PROGRAM_NAME,
    "version": APP_VERSION,
    "description": "Finanšu pārvaldība: ienākumi, izdevumi, dalības maksas, honorāri",
    "letter": "Z",
    "color": GOLD,
}

INCOME = "Ienākumi"
EXPENSE = "Izdevumi"
KINDS = [INCOME, EXPENSE]
CASH = "Skaidrā naudā"
BANK = "Pārskaitījums"
METHODS = [CASH, BANK]
FEE_CATEGORY = "Dalības maksa"     # Ienākumi: used by the "Dalības maksas" tab — cannot be renamed or deleted
FEE_CATEGORY_EVENT = "Honorārs"     # Ienākumi: suggested for the honorarium of an event
COSTUME_CATEGORY = "Tērpu fonds"    # Ienākumi: used by the "Tērpu fonds" tab — cannot be renamed or deleted
COSTUME_DEADLINES = {1: (12, 15), 2: (5, 15)}   # pusgads: (mēnesis, diena), līdz kuram jāsamaksā
ALL = "Visi"
ALL_GROUPS = "Visas"
MONTHS = ["Janvāris", "Februāris", "Marts", "Aprīlis", "Maijs", "Jūnijs", "Jūlijs", "Augusts", "Septembris",
          "Oktobris", "Novembris", "Decembris"]
MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "Mai", "Jūn", "Jūl", "Aug", "Sep", "Okt", "Nov", "Dec"]

DEFAULT_CATEGORIES = {
    INCOME: [FEE_CATEGORY, FEE_CATEGORY_EVENT, "Pašvaldības finansējums", "Projektu finansējums", "Ziedojumi",
             "Tērpu noma", "Citi ienākumi"],
    EXPENSE: ["Tērpi un apavi", "Tērpu remonts un kopšana", "Transports", "Ēdināšana",
              "Dalības maksas festivālos un skatēs", "Kolektīva pasākumi", "Saimniecības izdevumi",
              "Bankas komisijas", "Citi izdevumi"],
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS fin_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    position INTEGER DEFAULT 0,
    UNIQUE (kind, name)
);
CREATE TABLE IF NOT EXISTS fin_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT NOT NULL,
    kind TEXT NOT NULL,
    category TEXT DEFAULT '',
    amount_cents INTEGER NOT NULL,
    fin_group TEXT NOT NULL DEFAULT 'A',
    method TEXT DEFAULT '',
    party TEXT DEFAULT '',
    dancer_id INTEGER,
    session_id INTEGER,
    fee_months TEXT DEFAULT '',
    document TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT DEFAULT '',
    created_at TEXT DEFAULT '',
    updated_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS fin_fee_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fin_group TEXT NOT NULL,
    valid_from TEXT NOT NULL,
    valid_to TEXT DEFAULT '',
    amount_cents INTEGER NOT NULL,
    UNIQUE (fin_group, valid_from)
);
CREATE TABLE IF NOT EXISTS fin_fee_due (
    dancer_id INTEGER NOT NULL,
    month TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    PRIMARY KEY (dancer_id, month)
);
CREATE TABLE IF NOT EXISTS fin_costume_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fin_group TEXT NOT NULL,
    from_season TEXT NOT NULL,
    to_season TEXT DEFAULT '',
    amount_cents INTEGER NOT NULL,
    UNIQUE (fin_group, from_season)
);
CREATE TABLE IF NOT EXISTS fin_costume_due (
    dancer_id INTEGER NOT NULL,
    half TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    PRIMARY KEY (dancer_id, half)
);
CREATE TABLE IF NOT EXISTS fin_fee_personal (
    dancer_id INTEGER PRIMARY KEY,
    amount_cents INTEGER NOT NULL,
    note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS fin_opening (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fin_group TEXT NOT NULL,
    method TEXT NOT NULL,
    amount_cents INTEGER NOT NULL DEFAULT 0,
    UNIQUE (fin_group, method)
);
"""

ENTRY_FIELDS = ("entry_date", "kind", "category", "amount_cents", "fin_group", "method", "party", "dancer_id",
                "session_id", "fee_months", "document", "notes")


# --------------------------------------------------------------------------
# Money and months
# --------------------------------------------------------------------------
def parse_money(text):
    """'12,50' / '12.50' / '1 234,5 €' / '12' -> cents (int). Empty or wrong -> None. Negative not allowed."""
    t = str(text or "").replace("€", "").replace("EUR", "").replace("eur", "").replace("\u00a0", "")
    t = t.replace(" ", "").strip()
    if not t:
        return None
    if "," in t and "." in t:   # 1.234,50 or 1,234.50 — the last sign is the decimal sign
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    else:
        t = t.replace(",", ".")
    if not re.fullmatch(r"\d+(\.\d{1,2})?", t):
        return None
    whole, _, part = t.partition(".")
    return int(whole) * 100 + int((part + "00")[:2])


def money(cents, sign=False, euro=True):
    """1234567 -> '12 345,67 €'"""
    cents = int(cents or 0)
    neg = cents < 0
    whole, part = divmod(abs(cents), 100)
    text = f"{whole:,}".replace(",", " ") + f",{part:02d}"
    if neg:
        text = "−" + text
    elif sign and cents > 0:
        text = "+" + text
    return text + (" €" if euro else "")


def money_plain(cents):
    """For CSV / Excel: 1234.5 -> '12,34' (no thousand separator, no euro sign)."""
    cents = int(cents or 0)
    whole, part = divmod(abs(cents), 100)
    return ("-" if cents < 0 else "") + f"{whole},{part:02d}"


def show_date(iso):
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or ""


def month_key(year, month):
    return f"{year:04d}-{month:02d}"


def month_label(key):
    """'2026-09' -> 'Septembris 2026'"""
    try:
        y, m = key.split("-")
        return f"{MONTHS[int(m) - 1]} {y}"
    except (ValueError, IndexError):
        return key


def fee_parts(text):
    """fee_months text -> [('GGGG-MM', cents or None)]. Stored as '2026-09:1500,2026-10:1500' (how much of the payment
    goes to each month); older / hand-made entries only list the months ('2026-09,2026-10')."""
    out = []
    for part in (text or "").split(","):
        m = re.fullmatch(r"\s*(\d{4}-\d{2})(?::(\d+))?\s*", part)
        if m:
            out.append((m.group(1), int(m.group(2)) if m.group(2) is not None else None))
    return out


def parse_months(text):
    return [m for m, _c in fee_parts(text)]


def now_text():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")


def this_month():
    t = date.today()
    return month_key(t.year, t.month)


def group_of(group):
    return (group or "").strip() or DEFAULT_DANCER_GROUP


def make_tree_with_scroll(parent, tree):
    vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)


def fit_min_size(win):
    try:
        win.update_idletasks()
        win.minsize(min(win.winfo_reqwidth(), win.winfo_screenwidth() - 60),
                    min(win.winfo_reqheight(), win.winfo_screenheight() - 100))
    except Exception:
        pass


def save_csv(parent, title, default_name, header, rows):
    path = filedialog.asksaveasfilename(parent=parent, title=title, defaultextension=".csv",
                                        initialfile=default_name,
                                        filetypes=[("CSV (Excel)", "*.csv"), ("Visi faili", "*.*")])
    if not path:
        return
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:   # utf-8-sig: Excel shows ā, ē … right
            w = csv.writer(fh, delimiter=";")
            w.writerow(header)
            w.writerows(rows)
    except OSError as exc:
        messagebox.showerror("Eksports", f"Failu neizdevās saglabāt:\n{exc}", parent=parent)
        return
    messagebox.showinfo("Eksports", f"Saglabāts:\n{path}", parent=parent)


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Database:
    def __init__(self, path):
        self.con = connect_db(path)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        ensure_dancer_schema(self.con)
        for statement in SCHEMA.split(";"):
            if statement.strip():
                self.con.execute(statement)
        if "valid_to" not in {r[1] for r in self.q("PRAGMA table_info(fin_fee_rates)")}:   # Zelta pūrs v0.1
            self.con.execute("ALTER TABLE fin_fee_rates ADD COLUMN valid_to TEXT DEFAULT ''")
        if "import_key" not in {r[1] for r in self.q("PRAGMA table_info(fin_entries)")}:   # Zelta pūrs v0.1.2
            self.con.execute("ALTER TABLE fin_entries ADD COLUMN import_key TEXT DEFAULT ''")
        self.con.commit()
        if not self.q("SELECT 1 FROM fin_categories LIMIT 1"):
            for kind, names in DEFAULT_CATEGORIES.items():
                for i, name in enumerate(names):
                    self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                                     (kind, name, i))
            self.con.commit()
        # Dalības maksa must always exist (the fee tab uses it); bus payments (tab “Autobusi”) too
        self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                         (INCOME, FEE_CATEGORY, -1))
        self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                         (INCOME, BUS_CATEGORY, 50))
        self.con.execute("INSERT OR IGNORE INTO fin_categories (kind, name, position) VALUES (?, ?, ?)",
                         (INCOME, COSTUME_CATEGORY, 0))
        self.con.commit()
        self.move_costume_payments()

    def move_costume_payments(self):
        """Tērpu fonda maksājumi bez pusgada (ievadīti pirms v0.1.5 vai Excel importā) — pusgads tiek ierakstīts
        maksājumā, lai tie parādītos cilnē “Tērpu fonds”: no piezīmes “… 1. pusgads 2025/2026”, citādi pēc datuma."""
        rows = self.q("SELECT id, entry_date, amount_cents, notes FROM fin_entries WHERE kind=? AND category=? "
                      "AND TRIM(COALESCE(fee_months, '')) = ''", (INCOME, COSTUME_CATEGORY))
        for eid, d, cents, notes in rows:
            key = half_from_text(notes) or half_of_date(d)
            if key:
                self.con.execute("UPDATE fin_entries SET fee_months=? WHERE id=?", (f"{key}:{int(cents or 0)}", eid))
        if rows:
            self.con.commit()

    def q(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def x(self, sql, params=()):
        cur = self.con.execute(sql, params)
        self.con.commit()
        return cur.lastrowid

    def has_table(self, name):
        return bool(self.q("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)))

    # ---- categories -------------------------------------------------------
    def categories(self, kind=None):
        rows = self.q("SELECT kind, name FROM fin_categories ORDER BY position, name")
        if kind:
            return [n for k, n in rows if k == kind]
        return rows

    # ---- dancers ----------------------------------------------------------
    def dancers(self):
        """{id: dict} of every person in Kopas pūrs."""
        rows = self.q("SELECT id, first_name, last_name, name, dancer_group, status, role, join_date FROM dancers")
        out = {}
        for did, first, last, name, group, status, role, join in rows:
            out[did] = {"id": did, "name": full_name(first, last) or name or f"#{did}",
                        "group": group_of(group), "status": status or STATUS_ACTIVE,
                        "dancer": (role or "").strip() in ("", ROLE_DANCER), "join": join or ""}
        return out

    # ---- events (Notikumu pūrs / Cītības pūrs) ------------------------------
    def events(self):
        """[(id, date, kind, title, groups text, fee text)] — empty when the modules were never used."""
        if not self.has_table("attendance_sessions"):
            return []
        if self.has_table("event_details"):
            cols = {r[1] for r in self.q("PRAGMA table_info(event_details)")}
            groups = "COALESCE(e.for_groups, '')" if "for_groups" in cols else "''"
            fee = "COALESCE(e.fee, '')" if "fee" in cols else "''"
            return self.q(f"SELECT s.id, s.session_date, COALESCE(s.kind,''), COALESCE(s.title,''), {groups}, {fee} "
                          "FROM attendance_sessions s LEFT JOIN event_details e ON e.session_id = s.id "
                          "ORDER BY s.session_date DESC")
        return [(i, d, k, t, "", "") for i, d, k, t in
                self.q("SELECT id, session_date, COALESCE(kind,''), COALESCE(title,'') FROM attendance_sessions "
                       "ORDER BY session_date DESC")]

    # ---- entries ----------------------------------------------------------
    def entries(self):
        rows = self.q("SELECT id, " + ", ".join(ENTRY_FIELDS) + ", created_by, created_at, updated_at "
                      "FROM fin_entries")
        keys = ("id",) + ENTRY_FIELDS + ("created_by", "created_at", "updated_at")
        return [dict(zip(keys, r)) for r in rows]

    def entry(self, entry_id):
        rows = self.q("SELECT id, " + ", ".join(ENTRY_FIELDS) + ", updated_at FROM fin_entries WHERE id=?",
                      (entry_id,))
        return dict(zip(("id",) + ENTRY_FIELDS + ("updated_at",), rows[0])) if rows else None

    def save_entry(self, values, entry_id=None, expected_stamp=None):
        """Insert / update one entry. When someone else changed or deleted it meanwhile -> raises ValueError."""
        stamp = now_text()
        if entry_id is None:
            user = piekluve.current().user
            return self.x("INSERT INTO fin_entries (" + ", ".join(ENTRY_FIELDS) + ", created_by, created_at, "
                          "updated_at) VALUES (" + ", ".join("?" * (len(ENTRY_FIELDS) + 3)) + ")",
                          tuple(values[f] for f in ENTRY_FIELDS) + (user.name or user.email or "", stamp, stamp))
        current = self.q("SELECT updated_at FROM fin_entries WHERE id=?", (entry_id,))
        if not current:
            raise ValueError("Šo ierakstu pa to laiku kāds cits ir izdzēsis.")
        if expected_stamp is not None and (current[0][0] or "") != (expected_stamp or ""):
            raise ValueError("Šo ierakstu pa to laiku kāds cits ir mainījis. Aizveriet logu un atveriet to vēlreiz, "
                             "lai redzētu jaunāko versiju.")
        self.x("UPDATE fin_entries SET " + ", ".join(f"{f}=?" for f in ENTRY_FIELDS) + ", updated_at=? WHERE id=?",
               tuple(values[f] for f in ENTRY_FIELDS) + (stamp, entry_id))
        return entry_id

    # ---- fees -------------------------------------------------------------
    def fee_rates(self):
        """{group: [(valid_from 'GGGG-MM', valid_to 'GGGG-MM' or '' = no end, cents), …] sorted by valid_from}"""
        out = {}
        for group, start, end, cents in self.q("SELECT fin_group, valid_from, COALESCE(valid_to, ''), amount_cents "
                                               "FROM fin_fee_rates ORDER BY valid_from"):
            out.setdefault(group, []).append((start, end or "", cents))
        # what single dancers have to pay in single months (from the Excel import, or "Atbrīvot"): key "__due__"
        out[DUE_KEY] = {(did, m): c for did, m, c in self.q("SELECT dancer_id, month, amount_cents FROM fin_fee_due")}
        return out

    def costume_rates(self):
        """{group: [(from_season, to_season or '', cents per half), …], DUE_KEY: {(dancer_id, half): cents}}"""
        out = {}
        for group, start, end, cents in self.q("SELECT fin_group, from_season, COALESCE(to_season, ''), amount_cents "
                                               "FROM fin_costume_rates ORDER BY from_season"):
            out.setdefault(group, []).append((int(start), int(end) if str(end).strip() else None, cents))
        out[DUE_KEY] = {(did, h): c for did, h, c in self.q("SELECT dancer_id, half, amount_cents FROM fin_costume_due")}
        return out

    def personal_fees(self):
        return {did: (cents, note or "") for did, cents, note in
                self.q("SELECT dancer_id, amount_cents, note FROM fin_fee_personal")}

    def opening(self):
        """{(group, method): cents}"""
        return {(g, m): c for g, m, c in self.q("SELECT fin_group, method, amount_cents FROM fin_opening")}


DUE_KEY = "__due__"   # in the fee_rates() dict: {(dancer_id, 'GGGG-MM'): cents} for single months


def has_rates(rates):
    return any(k != DUE_KEY and v for k, v in rates.items())


def rate_for(rates, group, month):
    """The monthly fee of the group in that month: the rate whose period (from … to, both included) covers the month;
    when several do, the one that starts last. None when no rate is in force (e.g. summer months)."""
    value = None
    for start, end, cents in rates.get(group, []):
        if start <= month and (not end or month <= end):
            value = cents
    return value


def fee_due(rates, personal, dancer, month):
    """What a dancer should pay for one month: nothing when the group's fee is not in force that month; otherwise
    the individual fee (if set) or the group's fee."""
    single = rates.get(DUE_KEY, {}).get((dancer["id"], month))
    if single is not None:
        return single
    group_rate = rate_for(rates, dancer["group"], month)
    if group_rate is None:
        return 0
    if dancer["id"] in personal:
        return personal[dancer["id"]][0]
    return group_rate


# A season starts in September and ends in August of the next year.
SEASON_START_MONTH = 9


def season_of(key):
    """'2026-11' -> 2026, '2027-03' -> 2026 (the year the season started)."""
    y, m = int(key[:4]), int(key[5:7])
    return y if m >= SEASON_START_MONTH else y - 1


def current_season():
    return season_of(this_month())


def season_label(start):
    return f"{start}/{start + 1}"


def season_months(start):
    """The 12 months of the season, September … August: ['2026-09', …, '2027-08']."""
    return ([month_key(start, m) for m in range(SEASON_START_MONTH, 13)] +
            [month_key(start + 1, m) for m in range(1, SEASON_START_MONTH)])


def month_short(key):
    return MONTHS_SHORT[int(key[5:7]) - 1]


def fee_paid_by_month(entries):
    """{dancer_id: {month: cents}} — a payment for several months is split equally between them."""
    out = {}
    for e in entries:
        if e["kind"] != INCOME or e["category"] != FEE_CATEGORY or not e["dancer_id"]:
            continue
        parts = fee_parts(e["fee_months"])
        if not parts:
            d = e["entry_date"] or ""
            parts = [(d[:7], None)] if len(d) >= 7 else []
        if not parts:
            continue
        amount = int(e["amount_cents"] or 0)
        per = out.setdefault(e["dancer_id"], {})
        if all(c is not None for _m, c in parts) and sum(c for _m, c in parts) == amount:
            for m, c in parts:
                per[m] = per.get(m, 0) + c
            continue
        share, rest = divmod(amount, len(parts))   # no split stored (or the amount was changed later): equal parts
        for i, (m, _c) in enumerate(parts):
            per[m] = per.get(m, 0) + share + (1 if i < rest else 0)
    return out


def due_months(dancer, season):
    """Months of the season for which a dancer may owe a fee: from the join month (if known) on."""
    join = (dancer.get("join") or "")[:7]
    return [key for key in season_months(season) if not (join and key < join)]


# --------------------------------------------------------------------------
# Entry form (one income or expense)
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Tērpu fonds: two payments a season — 1. pusgads (līdz 15.12.), 2. pusgads (līdz 15.05.)
# Half key: 'GGGG-1' / 'GGGG-2', GGGG — the year the season started ('2026-2' = līdz 15.05.2027).
# --------------------------------------------------------------------------
def half_key(season, half):
    return f"{season}-{half}"


def half_parts(key):
    return int(key[:4]), int(key[5])


def half_label(key, short=False):
    season, half = half_parts(key)
    return f"{half}. pusgads" + ("" if short else f" {season_label(season)}")


def half_deadline(key):
    season, half = half_parts(key)
    month, day = COSTUME_DEADLINES[half]
    return date(season if half == 1 else season + 1, month, day)


def half_of_date(iso):
    """A payment without a half: September … January — 1. pusgads, February … August — 2. pusgads."""
    try:
        d = datetime.strptime(iso, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None
    if d.month >= 9:
        return half_key(d.year, 1)
    if d.month == 1:
        return half_key(d.year - 1, 1)
    return half_key(d.year - 1, 2)


def half_from_text(text):
    """'Tērpu fonds, 1. pusgads 2025/2026' -> '2025-1'"""
    m = re.search(r"([12])\.\s*pusgad\w*\s*(\d{4})\s*/", text or "")
    return half_key(int(m.group(2)), int(m.group(1))) if m else None


def half_parts_of(text):
    """fee_months of a Tērpu fonds payment -> [('2026-1', cents or None)]"""
    out = []
    for part in (text or "").split(","):
        m = re.fullmatch(r"\s*(\d{4}-[12])(?::(\d+))?\s*", part)
        if m:
            out.append((m.group(1), int(m.group(2)) if m.group(2) is not None else None))
    return out


def costume_rate_for(rates, group, season):
    value = None
    for start, end, cents in rates.get(group, []):
        if start <= season and (end is None or season <= end):
            value = cents
    return value


def costume_due(rates, dancer, key):
    """What a dancer has to pay into the costume fund for one half (0 — nothing)."""
    single = rates.get(DUE_KEY, {}).get((dancer["id"], key))
    if single is not None:
        return single
    join = dancer.get("join") or ""
    if join and join > half_deadline(key).isoformat():
        return 0
    return costume_rate_for(rates, dancer["group"], half_parts(key)[0]) or 0


def costume_paid(entries):
    """{dancer_id: {half: cents}} from the Tērpu fonds payments."""
    out = {}
    for e in entries:
        if e["kind"] != INCOME or e["category"] != COSTUME_CATEGORY or not e["dancer_id"]:
            continue
        parts = half_parts_of(e["fee_months"])
        if not parts:
            key = half_from_text(e["notes"]) or half_of_date(e["entry_date"])
            parts = [(key, None)] if key else []
        if not parts:
            continue
        amount = int(e["amount_cents"] or 0)
        per = out.setdefault(e["dancer_id"], {})
        if all(c is not None for _k, c in parts) and sum(c for _k, c in parts) == amount:
            for k, c in parts:
                per[k] = per.get(k, 0) + c
            continue
        share, rest = divmod(amount, len(parts))
        for i, (k, _c) in enumerate(parts):
            per[k] = per.get(k, 0) + share + (1 if i < rest else 0)
    return out


class EntryForm(tk.Toplevel):
    def __init__(self, app, entry_id=None, kind=INCOME, preset=None):
        super().__init__(app.root)
        self.app, self.entry_id = app, entry_id
        db = app.db
        self.configure(bg=CREAM, padx=18, pady=14)
        self.transient(app.root)
        self.grab_set()
        self.stamp = None
        data = db.entry(entry_id) if entry_id is not None else None
        if entry_id is not None and data is None:
            self.destroy()
            messagebox.showwarning("Ieraksts", "Šis ieraksts vairs nepastāv (kāds to ir izdzēsis).",
                                   parent=app.root)
            app.refresh_all()
            return
        if data:
            kind = data["kind"]
            self.stamp = data["updated_at"]
        self.kind = kind
        self.title(("Jauns ienākums" if kind == INCOME else "Jauns izdevums") if entry_id is None
                   else ("Ienākums" if kind == INCOME else "Izdevums"))
        tk.Label(self, text=("Jauns ienākums" if kind == INCOME else "Jauns izdevums") if entry_id is None
                 else ("Ienākums" if kind == INCOME else "Izdevums"),
                 font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN if kind == INCOME else RED).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))

        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit(MODULE_KEY, group=g)]
        self.v = {k: tk.StringVar() for k in ("date", "category", "amount", "group", "method", "party", "event",
                                              "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(BANK)
        default_group = app.group_var.get() if app.group_var.get() in self.edit_groups else \
            (self.edit_groups[0] if self.edit_groups else "")
        self.v["group"].set(default_group)

        def label(text, r, c=0):
            tk.Label(self, text=text, bg=CREAM, fg=NAVY).grid(row=r, column=c, sticky="w", pady=4,
                                                               padx=(0 if c == 0 else 18, 0))

        label("Datums *", 1)
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=1, column=1, sticky="w", padx=(8, 0))
        self.date_entry = ttk.Entry(drow, textvariable=self.v["date"], width=14)
        self.date_entry.pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        label("Summa, € *", 1, 2)
        self.amount_entry = ttk.Entry(self, textvariable=self.v["amount"], width=16)
        self.amount_entry.grid(row=1, column=3, sticky="w", padx=(8, 0))

        label("Kategorija *", 2)
        cats = db.categories(kind)
        if kind == INCOME:   # dalības maksu un tērpu fondu reģistrē savās cilnēs
            own = data["category"] if data else None
            cats = [c for c in cats if c not in (FEE_CATEGORY, COSTUME_CATEGORY) or c == own]
        self.cat_cb = ttk.Combobox(self, textvariable=self.v["category"], values=cats, state="readonly", width=30)
        self.cat_cb.grid(row=2, column=1, sticky="w", padx=(8, 0))
        label("Grupa *", 2, 2)
        self.group_cb = ttk.Combobox(self, textvariable=self.v["group"], values=self.edit_groups, state="readonly",
                                     width=14)
        self.group_cb.grid(row=2, column=3, sticky="w", padx=(8, 0))

        label("Maksātājs" if kind == INCOME else "Saņēmējs", 3)
        ttk.Entry(self, textvariable=self.v["party"], width=32).grid(row=3, column=1, sticky="w", padx=(8, 0))
        label("Maksājuma veids", 3, 2)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=3, column=3, sticky="w", padx=(8, 0))

        label("Notikums", 4)
        self.events = [(None, "— nav —")]
        for sid, d, ek, title, _groups, _fee in db.events():
            self.events.append((sid, f"{show_date(d)} · {title or ek or 'notikums'}"))
        self.event_cb = ttk.Combobox(self, textvariable=self.v["event"], values=[t for _i, t in self.events],
                                     state="readonly", width=40)
        self.event_cb.grid(row=4, column=1, columnspan=3, sticky="w", padx=(8, 0))
        self.v["event"].set(self.events[0][1])

        label("Dokumenta nr.", 5)
        ttk.Entry(self, textvariable=self.v["document"], width=24).grid(row=5, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="čeks, rēķins, maksājuma uzdevums …", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 8, "italic")).grid(row=5, column=2, columnspan=2, sticky="w", padx=(18, 0))

        label("Piezīmes", 6)
        self.notes = tk.Text(self, width=56, height=3, wrap="word", relief="solid", bd=1)
        self.notes.grid(row=6, column=1, columnspan=3, sticky="ew", pady=4, padx=(8, 0))

        self.info = tk.Label(self, text="", bg=CREAM, fg=MUTED, font=FONT_SMALL, justify="left")
        self.info.grid(row=7, column=0, columnspan=4, sticky="w", pady=(4, 0))

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=8, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if entry_id is not None:
            ttk.Button(btns, text="Dzēst", command=self.delete).pack(side="left")
        self.bind("<Escape>", lambda e: self.destroy())

        self.data = data
        if data:
            self.v["date"].set(show_date(data["entry_date"]))
            self.v["amount"].set(money(data["amount_cents"], euro=False).replace(" ", ""))
            self.v["category"].set(data["category"] or "")
            self.v["group"].set(data["fin_group"] or DEFAULT_DANCER_GROUP)
            self.v["method"].set(data["method"] or "")
            self.v["party"].set(data["party"] or "")
            self.v["document"].set(data["document"] or "")
            self.notes.insert("1.0", data["notes"] or "")
            for sid, text in self.events:
                if sid is not None and sid == data["session_id"]:
                    self.v["event"].set(text)
            if data["category"] == FEE_CATEGORY:
                months = ", ".join(month_label(m) for m in parse_months(data["fee_months"]))
                self.cat_cb.configure(state="disabled")
                self.info.configure(text=f"Dalības maksa par: {months or '—'}. Mēnešus maina cilnē “Dalības "
                                         "maksas” (izdzēsiet šo maksājumu un reģistrējiet no jauna).")
            elif data["category"] == COSTUME_CATEGORY:
                halves = ", ".join(half_label(k) for k, _c in half_parts_of(data["fee_months"]))
                self.cat_cb.configure(state="disabled")
                self.info.configure(text=f"Tērpu fonds par: {halves or '—'}. Pusgadus maina cilnē “Tērpu fonds” "
                                         "(izdzēsiet šo maksājumu un reģistrējiet no jauna).")
        elif preset:
            for key, value in preset.items():
                if key == "event":
                    for sid, text in self.events:
                        if sid == value:
                            self.v["event"].set(text)
                elif key in self.v:
                    self.v[key].set(value)
        if data and data["fin_group"] not in self.edit_groups:
            piekluve.make_readonly(self, note="Tikai skatīšanai — šīs grupas finanses jūsu loma nevar mainīt.")
        elif not self.edit_groups:
            piekluve.make_readonly(self)
        self.amount_entry.focus_set()
        self.after(100, lambda: fit_min_size(self))

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = parse_date(self.v["date"].get())
        if not d:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        cents = parse_money(self.v["amount"].get())
        if not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 25 vai 12,50.", parent=self)
        category = self.v["category"].get().strip()
        if not category:
            return messagebox.showwarning("Kategorija", "Izvēlieties kategoriju.", parent=self)
        group = self.v["group"].get()
        if group not in self.edit_groups:
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        session = next((sid for sid, text in self.events if text == self.v["event"].get()), None)
        data = self.data or {}
        values = {"entry_date": d, "kind": self.kind, "category": category, "amount_cents": cents,
                  "fin_group": group, "method": self.v["method"].get(), "party": self.v["party"].get().strip(),
                  "dancer_id": data.get("dancer_id"), "session_id": session,
                  "fee_months": data.get("fee_months") or "", "document": self.v["document"].get().strip(),
                  "notes": self.notes.get("1.0", "end").strip()}
        try:
            self.app.db.save_entry(values, self.entry_id, self.stamp)
        except ValueError as exc:
            messagebox.showwarning("Saglabāt", str(exc), parent=self)
            return
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return
        self.destroy()
        self.app.refresh_all()

    def delete(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        if messagebox.askyesno("Dzēst", "Dzēst šo ierakstu?", parent=self):
            self.app.db.x("DELETE FROM fin_entries WHERE id=?", (self.entry_id,))
            self.destroy()
            self.app.refresh_all()


# --------------------------------------------------------------------------
# Membership fee payment
# --------------------------------------------------------------------------
class FeePaymentForm(tk.Toplevel):
    """Register a membership fee payment of one dancer for one or several months."""

    def __init__(self, app, dancer_id=None, season=None, month=None):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Dalības maksas samaksa")
        self.transient(app.root)
        self.grab_set()
        db = app.db
        acc = piekluve.current()
        self.season = season or current_season()
        self.all_dancers = db.dancers()
        self.rates, self.personal = db.fee_rates(), db.personal_fees()
        self.paid = fee_paid_by_month(db.entries())
        self.dancers = sorted((d for d in self.all_dancers.values()
                               if d["dancer"] and d["group"] in app.groups and acc.can_edit(MODULE_KEY, group=d["group"])
                               and (d["status"] != STATUS_LEFT or d["id"] == dancer_id)),
                              key=lambda d: _norm(d["name"]))
        tk.Label(self, text="Dalības maksas samaksa", font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))
        self.v = {k: tk.StringVar() for k in ("dancer", "date", "amount", "method", "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(BANK)

        tk.Label(self, text="Dejotājs *", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=4)
        self.names = [f"{d['name']} ({d['group']})" for d in self.dancers]
        cb = ttk.Combobox(self, textvariable=self.v["dancer"], values=self.names, state="readonly", width=34)
        cb.grid(row=1, column=1, columnspan=3, sticky="w", padx=(8, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.show_months())

        tk.Label(self, text="Sezona", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
        self.season_var = tk.StringVar(value=season_label(self.season))
        ycb = ttk.Combobox(self, textvariable=self.season_var, state="readonly", width=10,
                           values=[season_label(y) for y in range(current_season() + 1, current_season() - 4, -1)])
        ycb.grid(row=2, column=1, sticky="w", padx=(8, 0))
        ycb.bind("<<ComboboxSelected>>", lambda e: self.show_months())

        self.month_box = tk.LabelFrame(self, text=" Par mēnešiem ", bg=CREAM, fg=RED, font=("Georgia", 11, "bold"),
                                       padx=10, pady=6)
        self.month_box.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(8, 4))
        self.month_vars = {}
        self.month_cbs = {}
        for i in range(12):   # positions 1 … 12 of the season: September … August
            var = tk.BooleanVar(value=False)
            c = tk.Checkbutton(self.month_box, text="", variable=var, bg=CREAM, fg=NAVY, anchor="w",
                               activebackground=CREAM, selectcolor=WHITE, width=24, command=self.update_amount)
            c.grid(row=i % 6, column=i // 6, sticky="w")
            self.month_vars[i + 1] = var
            self.month_cbs[i + 1] = c

        tk.Label(self, text="Summa, € *", bg=CREAM, fg=NAVY).grid(row=4, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.v["amount"], width=14).grid(row=4, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Datums *", bg=CREAM, fg=NAVY).grid(row=4, column=2, sticky="w", padx=(18, 0))
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=4, column=3, sticky="w", padx=(8, 0))
        ttk.Entry(drow, textvariable=self.v["date"], width=12).pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        tk.Label(self, text="Maksājuma veids", bg=CREAM, fg=NAVY).grid(row=5, column=0, sticky="w", pady=4)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=5, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Dokumenta nr.", bg=CREAM, fg=NAVY).grid(row=5, column=2, sticky="w", padx=(18, 0))
        ttk.Entry(self, textvariable=self.v["document"], width=16).grid(row=5, column=3, sticky="w", padx=(8, 0))
        self.info = tk.Label(self, text="", bg=CREAM, fg=MUTED, font=FONT_SMALL, justify="left",
                             wraplength=520)
        self.info.grid(row=6, column=0, columnspan=4, sticky="w", pady=(6, 0))

        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Nav jāmaksā / atjaunot maksu", command=self.toggle_exempt).pack(side="left")
        self.bind("<Escape>", lambda e: self.destroy())

        if dancer_id is not None:
            for d, n in zip(self.dancers, self.names):
                if d["id"] == dancer_id:
                    self.v["dancer"].set(n)
        self.show_months(preselect=month)
        if not self.dancers:
            piekluve.make_readonly(self, note="Nav dejotāju, kuru dalības maksas jūsu loma var reģistrēt.")
        self.after(100, lambda: fit_min_size(self))

    def dancer(self):
        name = self.v["dancer"].get()
        for d, n in zip(self.dancers, self.names):
            if n == name:
                return d
        return None

    def months(self):
        """{position 1 … 12: 'GGGG-MM'} of the chosen season."""
        return dict(enumerate(season_months(int(self.season_var.get()[:4])), start=1))

    def show_months(self, preselect=None):
        """preselect: 'GGGG-MM' to tick."""
        d = self.dancer()
        months = self.months()
        paid = self.paid.get(d["id"], {}) if d else {}
        first_open = None
        for m, c in self.month_cbs.items():
            key = months[m]
            due = fee_due(self.rates, self.personal, d, key) if d else 0
            got = paid.get(key, 0)
            mark = ""
            if got and got >= due:
                mark = "  ✓"
            elif got:
                mark = f"  ({money(got, euro=False)})"
            elif d and not due:
                mark = "  –"
            c.configure(text=month_label(key) + mark, fg=GREEN if mark.strip() == "✓" else
                        GREY if mark.strip() == "–" else NAVY)
            self.month_vars[m].set(False)
            if d and first_open is None and got < due and key >= (d["join"] or "")[:7]:
                first_open = m
        if preselect in months.values():
            self.month_vars[next(m for m, k in months.items() if k == preselect)].set(True)
        elif first_open:
            self.month_vars[first_open].set(True)
        if d:
            rate = fee_due(self.rates, self.personal, d, this_month())
            pers = self.personal.get(d["id"])
            self.info.configure(text=f"Mēneša maksa: {money(rate)}" + (f" (individuāla — {pers[1]})" if pers and pers[1]
                                                                    else " (individuāla)" if pers else
                                                                    f" ({d['group']} grupas maksa)") +
                                ". Ar ✓ atzīmētie mēneši jau samaksāti, ar – maksa nepienākas. Ja maksā par "
                                "vairākiem mēnešiem, summa tiek sadalīta vienādi.")
        else:
            self.info.configure(text="Izvēlieties dejotāju.")
        self.update_amount()

    def toggle_exempt(self):
        """The ticked months: 'nav jāmaksā' (0 €) — or, when all of them already are, back to the normal fee."""
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = self.dancer()
        if not d:
            return messagebox.showwarning("Dejotājs", "Izvēlieties dejotāju.", parent=self)
        if not piekluve.current().can_edit(MODULE_KEY, group=d["group"]):
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        chosen = self.months()
        months = [chosen[m] for m, var in self.month_vars.items() if var.get()]
        if not months:
            return messagebox.showinfo("Mēneši", "Atzīmējiet mēnešus.", parent=self)
        single = self.rates.get(DUE_KEY, {})
        db = self.app.db
        if all(single.get((d["id"], m)) == 0 for m in months):
            for m in months:
                db.con.execute("DELETE FROM fin_fee_due WHERE dancer_id=? AND month=?", (d["id"], m))
        else:
            for m in months:
                db.con.execute("DELETE FROM fin_fee_due WHERE dancer_id=? AND month=?", (d["id"], m))
                db.con.execute("INSERT INTO fin_fee_due (dancer_id, month, amount_cents) VALUES (?, ?, 0)",
                               (d["id"], m))
        db.con.commit()
        self.rates = db.fee_rates()
        self.app.refresh_all()
        ticked = [m for m, var in self.month_vars.items() if var.get()]
        self.show_months()
        for m, var in self.month_vars.items():   # the same months stay ticked
            var.set(m in ticked)
        self.update_amount()

    def update_amount(self):
        d = self.dancer()
        if not d:
            return
        months = self.months()
        paid = self.paid.get(d["id"], {})
        total = 0
        for m, var in self.month_vars.items():
            if var.get():
                key = months[m]
                total += max(fee_due(self.rates, self.personal, d, key) - paid.get(key, 0), 0)
        self.v["amount"].set(money(total, euro=False).replace(" ", "") if total else "")

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = self.dancer()
        if not d:
            return messagebox.showwarning("Dejotājs", "Izvēlieties dejotāju.", parent=self)
        if not piekluve.current().can_edit(MODULE_KEY, group=d["group"]):
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        chosen = self.months()
        months = [chosen[m] for m, var in self.month_vars.items() if var.get()]
        if not months:
            return messagebox.showwarning("Mēneši", "Atzīmējiet, par kuriem mēnešiem samaksāts.", parent=self)
        cents = parse_money(self.v["amount"].get())
        if not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 15 vai 12,50.", parent=self)
        # the payment fills the months in order by what is still owed; months without a fee get nothing
        paid = self.paid.get(d["id"], {})
        owed = {m: max(fee_due(self.rates, self.personal, d, m) - paid.get(m, 0), 0) for m in months}
        if any(owed.values()):
            months = [m for m in months if owed[m]]
        split, left = {}, cents
        for m in months:
            take = min(owed[m], left) if any(owed.values()) else 0
            split[m] = take
            left -= take
        if left:
            if any(owed.values()):   # more than owed: the rest goes to the last month
                split[months[-1]] += left
            else:                    # nothing owed: equal parts
                share, rest = divmod(cents, len(months))
                split = {m: share + (1 if i < rest else 0) for i, m in enumerate(months)}
        day = parse_date(self.v["date"].get())
        if not day:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        values = {"entry_date": day, "kind": INCOME, "category": FEE_CATEGORY, "amount_cents": cents,
                  "fin_group": d["group"], "method": self.v["method"].get(), "party": d["name"],
                  "dancer_id": d["id"], "session_id": None,
                  "fee_months": ",".join(f"{m}:{split[m]}" for m in months),
                  "document": self.v["document"].get().strip(), "notes": ""}
        try:
            self.app.db.save_entry(values)
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return
        self.destroy()
        self.app.refresh_all()


# --------------------------------------------------------------------------
# Settings: fee rates, individual fees, opening balances, categories
# --------------------------------------------------------------------------
NO_END = "bez beigām"


class CostumePaymentForm(tk.Toplevel):
    """Register a costume fund payment of one dancer for one or both halves of a season."""

    def __init__(self, app, dancer_id=None, season=None, half=None):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Tērpu fonda samaksa")
        self.transient(app.root)
        self.grab_set()
        db = app.db
        acc = piekluve.current()
        self.rates = db.costume_rates()
        self.paid = costume_paid(db.entries())
        self.dancers = sorted((d for d in db.dancers().values()
                               if d["dancer"] and d["group"] in app.groups and acc.can_edit(MODULE_KEY, group=d["group"])
                               and (d["status"] != STATUS_LEFT or d["id"] == dancer_id)),
                              key=lambda d: _norm(d["name"]))
        self.names = [f"{d['name']} ({d['group']})" for d in self.dancers]
        tk.Label(self, text="Tērpu fonda samaksa", font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))
        self.v = {k: tk.StringVar() for k in ("dancer", "date", "amount", "method", "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(BANK)
        tk.Label(self, text="Dejotājs *", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=4)
        cb = ttk.Combobox(self, textvariable=self.v["dancer"], values=self.names, state="readonly", width=34)
        cb.grid(row=1, column=1, columnspan=3, sticky="w", padx=(8, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.show_halves())
        tk.Label(self, text="Sezona", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
        self.season_var = tk.StringVar(value=season_label(season or current_season()))
        scb = ttk.Combobox(self, textvariable=self.season_var, state="readonly", width=10,
                           values=[season_label(y) for y in range(current_season() + 1, current_season() - 4, -1)])
        scb.grid(row=2, column=1, sticky="w", padx=(8, 0))
        scb.bind("<<ComboboxSelected>>", lambda e: self.show_halves())
        box = tk.LabelFrame(self, text=" Par pusgadu ", bg=CREAM, fg=RED, font=("Georgia", 11, "bold"),
                            padx=10, pady=6)
        box.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(8, 4))
        self.half_vars, self.half_cbs = {}, {}
        for h in (1, 2):
            var = tk.BooleanVar(value=False)
            c = tk.Checkbutton(box, text="", variable=var, bg=CREAM, fg=NAVY, anchor="w", activebackground=CREAM,
                               selectcolor=WHITE, width=52, command=self.update_amount)
            c.grid(row=h - 1, column=0, sticky="w")
            self.half_vars[h], self.half_cbs[h] = var, c
        tk.Label(self, text="Summa, € *", bg=CREAM, fg=NAVY).grid(row=4, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.v["amount"], width=14).grid(row=4, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Datums *", bg=CREAM, fg=NAVY).grid(row=4, column=2, sticky="w", padx=(18, 0))
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=4, column=3, sticky="w", padx=(8, 0))
        ttk.Entry(drow, textvariable=self.v["date"], width=12).pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        tk.Label(self, text="Maksājuma veids", bg=CREAM, fg=NAVY).grid(row=5, column=0, sticky="w", pady=4)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=5, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Dokumenta nr.", bg=CREAM, fg=NAVY).grid(row=5, column=2, sticky="w", padx=(18, 0))
        ttk.Entry(self, textvariable=self.v["document"], width=16).grid(row=5, column=3, sticky="w", padx=(8, 0))
        self.info = tk.Label(self, text="", bg=CREAM, fg=MUTED, font=FONT_SMALL, justify="left",
                             wraplength=520)
        self.info.grid(row=6, column=0, columnspan=4, sticky="w", pady=(6, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        ttk.Button(btns, text="Nav jāmaksā / atjaunot maksu", command=self.toggle_exempt).pack(side="left")
        self.bind("<Escape>", lambda e: self.destroy())
        for d, n in zip(self.dancers, self.names):
            if d["id"] == dancer_id:
                self.v["dancer"].set(n)
        self.show_halves(preselect=half)
        if not self.dancers:
            piekluve.make_readonly(self, note="Nav dejotāju, kuru tērpu fondu jūsu loma var reģistrēt.")
        self.after(100, lambda: fit_min_size(self))

    def dancer(self):
        name = self.v["dancer"].get()
        return next((d for d, n in zip(self.dancers, self.names) if n == name), None)

    def keys(self):
        season = int(self.season_var.get()[:4])
        return {1: half_key(season, 1), 2: half_key(season, 2)}

    def show_halves(self, preselect=None):
        d = self.dancer()
        keys = self.keys()
        paid = self.paid.get(d["id"], {}) if d else {}
        first_open = None
        for h, c in self.half_cbs.items():
            k = keys[h]
            due = costume_due(self.rates, d, k) if d else 0
            got = paid.get(k, 0)
            mark = ""
            if d:
                if got and got >= due:
                    mark = "  ✓ samaksāts"
                elif got:
                    mark = f"  (samaksāts {money(got, euro=False)} no {money(due, euro=False)})"
                elif not due:
                    mark = "  – nav jāmaksā"
                else:
                    mark = f"  — {money(due)}"
            c.configure(text=f"{half_label(k)} (līdz {half_deadline(k):%d.%m.%Y}){mark}",
                        fg=GREEN if "✓" in mark else GREY if "–" in mark else NAVY)
            self.half_vars[h].set(False)
            if d and first_open is None and got < due:
                first_open = h
        if preselect in keys.values():
            self.half_vars[next(h for h, k in keys.items() if k == preselect)].set(True)
        elif first_open:
            self.half_vars[first_open].set(True)
        self.info.configure(text="Izvēlieties dejotāju." if not d else
                            "Ja maksā par abiem pusgadiem, summa tiek sadalīta pēc tā, cik katrā vēl jāmaksā.")
        self.update_amount()

    def update_amount(self):
        d = self.dancer()
        if not d:
            return
        keys = self.keys()
        paid = self.paid.get(d["id"], {})
        total = sum(max(costume_due(self.rates, d, keys[h]) - paid.get(keys[h], 0), 0)
                    for h, var in self.half_vars.items() if var.get())
        self.v["amount"].set(money(total, euro=False).replace(" ", "") if total else "")

    def toggle_exempt(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = self.dancer()
        if not d:
            return messagebox.showwarning("Dejotājs", "Izvēlieties dejotāju.", parent=self)
        if not piekluve.current().can_edit(MODULE_KEY, group=d["group"]):
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        keys = self.keys()
        chosen = [keys[h] for h, var in self.half_vars.items() if var.get()]
        if not chosen:
            return messagebox.showinfo("Pusgads", "Atzīmējiet pusgadu.", parent=self)
        single = self.rates.get(DUE_KEY, {})
        db = self.app.db
        exempt_all = all(single.get((d["id"], k)) == 0 for k in chosen)
        for k in chosen:
            db.con.execute("DELETE FROM fin_costume_due WHERE dancer_id=? AND half=?", (d["id"], k))
            if not exempt_all:
                db.con.execute("INSERT INTO fin_costume_due (dancer_id, half, amount_cents) VALUES (?, ?, 0)",
                               (d["id"], k))
        db.con.commit()
        self.rates = db.costume_rates()
        self.app.refresh_all()
        ticked = [h for h, var in self.half_vars.items() if var.get()]
        self.show_halves()
        for h, var in self.half_vars.items():
            var.set(h in ticked)
        self.update_amount()

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        d = self.dancer()
        if not d:
            return messagebox.showwarning("Dejotājs", "Izvēlieties dejotāju.", parent=self)
        if not piekluve.current().can_edit(MODULE_KEY, group=d["group"]):
            return piekluve.deny(self, "Šīs grupas finanses jūsu loma nevar mainīt.")
        keys = self.keys()
        chosen = [keys[h] for h, var in self.half_vars.items() if var.get()]
        if not chosen:
            return messagebox.showwarning("Pusgads", "Atzīmējiet, par kuru pusgadu samaksāts.", parent=self)
        cents = parse_money(self.v["amount"].get())
        if not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 20 vai 12,50.", parent=self)
        day = parse_date(self.v["date"].get())
        if not day:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        paid = self.paid.get(d["id"], {})
        owed = {k: max(costume_due(self.rates, d, k) - paid.get(k, 0), 0) for k in chosen}
        if any(owed.values()):
            chosen = [k for k in chosen if owed[k]]
        split, left = {}, cents
        for k in chosen:
            take = min(owed[k], left) if any(owed.values()) else 0
            split[k] = take
            left -= take
        if left:
            if any(owed.values()):
                split[chosen[-1]] += left
            else:
                share, rest = divmod(cents, len(chosen))
                split = {k: share + (1 if i < rest else 0) for i, k in enumerate(chosen)}
        values = {"entry_date": day, "kind": INCOME, "category": COSTUME_CATEGORY, "amount_cents": cents,
                  "fin_group": d["group"], "method": self.v["method"].get(), "party": d["name"],
                  "dancer_id": d["id"], "session_id": None,
                  "fee_months": ",".join(f"{k}:{split[k]}" for k in chosen),
                  "document": self.v["document"].get().strip(),
                  "notes": "Tērpu fonds, " + ", ".join(half_label(k) for k in chosen)}
        try:
            self.app.db.save_entry(values)
        except sqlite3.Error as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            return
        self.destroy()
        self.app.refresh_all()


class CostumeRatesWindow(tk.Toplevel):
    """Costume fund per half for each group and the seasons it is in force."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Tērpu fonda apmērs")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit(MODULE_KEY, group=g)]
        tk.Label(self, text="Tērpu fonda apmērs", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text="Cik katram dejotājam jāiemaksā tērpu fondā par vienu pusgadu (1. pusgads — līdz 15. "
                            "decembrim, 2. pusgads — līdz 15. maijam) un no kuras līdz kurai sezonai tas spēkā. Ja "
                            "apmērs mainās, pievienojiet jaunu rindu ar jauno sezonu.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9), wraplength=560, justify="left").pack(anchor="w",
                                                                                                 pady=(2, 8))
        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=("group", "from", "to", "amount"), show="headings", height=7)
        for key, text, w in (("group", "Grupa", 100), ("from", "No sezonas", 130), ("to", "Līdz sezonai", 130),
                             ("amount", "Par pusgadu", 110)):
            self.tree.heading(key, text=text)
            self.tree.column(key, width=w, anchor="e" if key == "amount" else "w")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.load_selected())
        make_tree_with_scroll(holder, self.tree)
        seasons = [season_label(y) for y in range(current_season() - 4, current_season() + 4)]
        form = tk.Frame(self, bg=CREAM)
        form.pack(fill="x", pady=(10, 0))
        self.g = tk.StringVar(value=self.edit_groups[0] if self.edit_groups else "")
        self.s_from = tk.StringVar(value=season_label(current_season()))
        self.s_to = tk.StringVar(value=NO_END)
        self.a = tk.StringVar()
        ttk.Combobox(form, textvariable=self.g, values=self.edit_groups, state="readonly", width=9).pack(side="left")
        tk.Label(form, text="  no ", bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Combobox(form, textvariable=self.s_from, values=seasons, state="readonly", width=10).pack(side="left")
        tk.Label(form, text="  līdz ", bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Combobox(form, textvariable=self.s_to, values=[NO_END] + seasons, state="readonly", width=11).pack(
            side="left")
        tk.Label(form, text="  € par pusgadu ", bg=CREAM, fg=NAVY).pack(side="left")
        ttk.Entry(form, textvariable=self.a, width=8).pack(side="left")
        ttk.Button(form, text="＋ Pievienot / saglabāt", style="Accent.TButton", command=self.add).pack(
            side="left", padx=(8, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Dzēst izvēlēto", command=self.delete).pack(side="left")
        ttk.Button(btns, text="Aizvērt", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.refresh()
        if not self.edit_groups:
            piekluve.make_readonly(self)
        self.after(100, lambda: fit_min_size(self))

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for rid, group, start, end, cents in self.app.db.q(
                "SELECT id, fin_group, from_season, COALESCE(to_season, ''), amount_cents FROM fin_costume_rates "
                "ORDER BY fin_group, from_season"):
            if group in self.app.groups:
                self.tree.insert("", "end", iid=str(rid), values=(
                    group, season_label(int(start)), season_label(int(end)) if str(end).strip() else NO_END,
                    money(cents)))

    def load_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], "values")
        if values[0] in self.edit_groups:
            self.g.set(values[0])
        self.s_from.set(values[1])
        self.s_to.set(values[2])
        self.a.set(str(values[3]).replace(" €", "").replace(" ", ""))

    def add(self):
        cents = parse_money(self.a.get())
        if cents is None:
            return messagebox.showwarning("Summa", "Ierakstiet summu par pusgadu eiro (0, ja nav jāmaksā).",
                                          parent=self)
        if self.g.get() not in self.edit_groups:
            return piekluve.deny(self)
        start = self.s_from.get()[:4]
        end = "" if self.s_to.get() == NO_END else self.s_to.get()[:4]
        if end and end < start:
            return messagebox.showwarning("Periods", "Sezona “līdz” ir agrāk nekā “no”.", parent=self)
        db = self.app.db
        if db.q("SELECT 1 FROM fin_costume_rates WHERE fin_group=? AND from_season=?", (self.g.get(), start)):
            db.x("UPDATE fin_costume_rates SET amount_cents=?, to_season=? WHERE fin_group=? AND from_season=?",
                 (cents, end, self.g.get(), start))
        else:
            db.x("INSERT INTO fin_costume_rates (fin_group, from_season, to_season, amount_cents) VALUES (?, ?, ?, ?)",
                 (self.g.get(), start, end, cents))
        self.a.set("")
        self.refresh()
        self.app.refresh_all()

    def delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        if self.tree.item(sel[0], "values")[0] not in self.edit_groups:
            return piekluve.deny(self)
        self.app.db.x("DELETE FROM fin_costume_rates WHERE id=?", (int(sel[0]),))
        self.refresh()
        self.app.refresh_all()


class BusPaymentForm(tk.Toplevel):
    """Register bus payments (one or several dancers, the same event) — one income entry per dancer."""

    def __init__(self, app, sid, dues):
        super().__init__(app.root)
        self.app, self.sid = app, sid
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Autobusa samaksa")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        self.dues = [d for d in dues if acc.can_edit(MODULE_KEY, group=app.dancer_map[d["dancer_id"]]["group"])]
        ev = dues[0]["event"]
        self.ev_text = f"{show_date(ev['date'])} · {ev['title'] or ev['subkind'] or ev['kind']}"
        tk.Label(self, text="Autobusa samaksa", font=("Georgia", 15, "bold"), bg=CREAM, fg=GREEN).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))
        tk.Label(self, text=f"{self.ev_text}  ·  cena {money(ev['price'])}", bg=CREAM, fg=NAVY,
                 font=("Segoe UI", 10, "bold")).grid(row=1, column=0, columnspan=4, sticky="w", pady=(0, 8))
        names = [f"{app.dancer_map[d['dancer_id']]['name']} — {money(d['due'])}" for d in self.dues]
        box = tk.Text(self, width=56, height=min(10, max(2, len(names))), wrap="word", relief="solid", bd=1,
                      bg=WHITE, fg=NAVY)
        box.insert("1.0", "\n".join(names) or "—")
        box.configure(state="disabled")
        box.grid(row=2, column=0, columnspan=4, sticky="ew")
        self.v = {k: tk.StringVar() for k in ("date", "amount", "method", "document")}
        self.v["date"].set(date.today().strftime("%d.%m.%Y"))
        self.v["method"].set(CASH)
        dues_set = {d["due"] for d in self.dues}
        self.v["amount"].set(money(dues_set.pop(), euro=False).replace(" ", "") if len(dues_set) == 1 else "")
        tk.Label(self, text="Summa katram, €", bg=CREAM, fg=NAVY).grid(row=3, column=0, sticky="w", pady=(10, 4))
        ttk.Entry(self, textvariable=self.v["amount"], width=12).grid(row=3, column=1, sticky="w", padx=(8, 0),
                                                                     pady=(10, 4))
        tk.Label(self, text="Datums *", bg=CREAM, fg=NAVY).grid(row=3, column=2, sticky="w", padx=(18, 0),
                                                               pady=(10, 4))
        drow = tk.Frame(self, bg=CREAM)
        drow.grid(row=3, column=3, sticky="w", padx=(8, 0), pady=(10, 4))
        ttk.Entry(drow, textvariable=self.v["date"], width=12).pack(side="left")
        date_picker_button(drow, self.v["date"]).pack(side="left", padx=(2, 0))
        tk.Label(self, text="Maksājuma veids", bg=CREAM, fg=NAVY).grid(row=4, column=0, sticky="w", pady=4)
        ttk.Combobox(self, textvariable=self.v["method"], values=METHODS, state="readonly", width=14).grid(
            row=4, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Dokumenta nr.", bg=CREAM, fg=NAVY).grid(row=4, column=2, sticky="w", padx=(18, 0))
        ttk.Entry(self, textvariable=self.v["document"], width=14).grid(row=4, column=3, sticky="w", padx=(8, 0))
        tk.Label(self, text="Tukša summa — katram tiek ierakstīts viņa atlikušais maksājums. Katram dejotājam tiek "
                            f"izveidots atsevišķs ienākums “{BUS_CATEGORY}” (grupa — dejotāja grupa).",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL, wraplength=480, justify="left").grid(
            row=5, column=0, columnspan=4, sticky="w", pady=(6, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        if not self.dues:
            piekluve.make_readonly(self, note="Šo dejotāju grupas finanses jūsu loma nevar mainīt.")
        self.after(100, lambda: fit_min_size(self))

    def save(self):
        if getattr(self, "readonly", False) or not self.dues:
            return piekluve.deny(self)
        d = parse_date(self.v["date"].get())
        if not d:
            return messagebox.showwarning("Datums", "Ierakstiet datumu formā DD.MM.GGGG.", parent=self)
        text = self.v["amount"].get().strip()
        cents = parse_money(text) if text else None
        if text and not cents:
            return messagebox.showwarning("Summa", "Ierakstiet summu eiro, piemēram, 12 vai 12,50.", parent=self)
        app = self.app
        try:
            for due in self.dues:
                person = app.dancer_map[due["dancer_id"]]
                app.db.save_entry({
                    "entry_date": d, "kind": INCOME, "category": BUS_CATEGORY, "amount_cents": cents or due["due"],
                    "fin_group": person["group"], "method": self.v["method"].get(), "party": person["name"],
                    "dancer_id": due["dancer_id"], "session_id": self.sid, "fee_months": "",
                    "document": self.v["document"].get().strip(), "notes": f"Autobuss: {self.ev_text}"})
        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Saglabāt", f"Neizdevās saglabāt:\n{exc}", parent=self)
            app.refresh_all()
            return
        self.destroy()
        app.refresh_all()


class FeeRatesWindow(tk.Toplevel):
    """Monthly membership fee of each group and the period it is in force (from … to, both months included)."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Dalības maksas apmērs")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        self.edit_groups = [g for g in app.groups if acc.can_edit(MODULE_KEY, group=g)]
        tk.Label(self, text="Dalības maksas apmērs", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).pack(anchor="w")
        tk.Label(self, text="Mēneša maksa katrai grupai un laiks, kad tā spēkā — no kura līdz kuram mēnesim (abi "
                            "ieskaitot). Sezona ir no septembra līdz augustam. Mēnešos, kuros neviena maksa nav spēkā "
                            "(piemēram, vasarā), dalības maksa nepienākas. Ja maksa mainās, pievienojiet jaunu rindu — "
                            "iepriekšējie mēneši paliek ar veco maksu (ja periodi pārklājas, der vēlāk sākusies).",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9), wraplength=600, justify="left").pack(anchor="w",
                                                                                                 pady=(2, 8))
        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=("group", "from", "to", "amount"), show="headings", height=8)
        for key, text, w in (("group", "Grupa", 100), ("from", "Spēkā no", 150), ("to", "Spēkā līdz", 150),
                             ("amount", "Mēnesī", 100)):
            self.tree.heading(key, text=text)
            self.tree.column(key, width=w, anchor="e" if key == "amount" else "w")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.load_selected())
        make_tree_with_scroll(holder, self.tree)

        season = current_season()
        years = [str(y) for y in range(season - 4, season + 4)]
        form = tk.Frame(self, bg=CREAM)
        form.pack(fill="x", pady=(10, 0))
        self.g = tk.StringVar(value=self.edit_groups[0] if self.edit_groups else "")
        self.m_from = tk.StringVar(value=MONTHS[SEASON_START_MONTH - 1])
        self.y_from = tk.StringVar(value=str(season))
        self.m_to = tk.StringVar(value=MONTHS[SEASON_START_MONTH - 2])
        self.y_to = tk.StringVar(value=str(season + 1))
        self.a = tk.StringVar()
        tk.Label(form, text="Grupa ", bg=CREAM, fg=NAVY).grid(row=0, column=0, sticky="w")
        ttk.Combobox(form, textvariable=self.g, values=self.edit_groups, state="readonly", width=9).grid(
            row=0, column=1, sticky="w")
        tk.Label(form, text="  €/mēn. ", bg=CREAM, fg=NAVY).grid(row=0, column=2, sticky="e")
        ttk.Entry(form, textvariable=self.a, width=9).grid(row=0, column=3, sticky="w")
        tk.Label(form, text="Spēkā no ", bg=CREAM, fg=NAVY).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Combobox(form, textvariable=self.m_from, values=MONTHS, state="readonly", width=11).grid(
            row=1, column=1, sticky="w", pady=(6, 0))
        ttk.Combobox(form, textvariable=self.y_from, values=years, state="readonly", width=6).grid(
            row=1, column=2, sticky="w", padx=(4, 0), pady=(6, 0))
        tk.Label(form, text="Spēkā līdz ", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=(4, 0))
        self.to_month_cb = ttk.Combobox(form, textvariable=self.m_to, values=MONTHS + [NO_END], state="readonly",
                                        width=11)
        self.to_month_cb.grid(row=2, column=1, sticky="w", pady=(4, 0))
        self.to_month_cb.bind("<<ComboboxSelected>>", lambda e: self.no_end_changed())
        self.to_year_cb = ttk.Combobox(form, textvariable=self.y_to, values=years, state="readonly", width=6)
        self.to_year_cb.grid(row=2, column=2, sticky="w", padx=(4, 0), pady=(4, 0))
        tb = tk.Frame(form, bg=CREAM)
        tb.grid(row=1, column=3, rowspan=2, sticky="w", padx=(10, 0))
        ttk.Button(tb, text="Visa sezona", command=self.whole_season).pack(side="left")
        ttk.Button(tb, text="Sept.–maijs", command=lambda: self.whole_season(end_month=5)).pack(side="left", padx=4)
        ttk.Button(form, text="＋ Pievienot / saglabāt", style="Accent.TButton", command=self.add).grid(
            row=3, column=0, columnspan=4, sticky="w", pady=(10, 0))
        btns = tk.Frame(self, bg=CREAM)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Dzēst izvēlēto", command=self.delete).pack(side="left")
        ttk.Button(btns, text="Aizvērt", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.refresh()
        if not self.edit_groups:
            piekluve.make_readonly(self)
        self.after(100, lambda: fit_min_size(self))

    def whole_season(self, end_month=SEASON_START_MONTH - 1):
        """September of the chosen 'from' year … end_month of the next year."""
        try:
            start = int(self.y_from.get())
        except ValueError:
            start = current_season()
        self.m_from.set(MONTHS[SEASON_START_MONTH - 1])
        self.m_to.set(MONTHS[end_month - 1])
        self.y_to.set(str(start + 1))
        self.no_end_changed()

    def no_end_changed(self):
        self.to_year_cb.configure(state="disabled" if self.m_to.get() == NO_END else "readonly")

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for rid, group, start, end, cents in self.app.db.q(
                "SELECT id, fin_group, valid_from, COALESCE(valid_to, ''), amount_cents FROM fin_fee_rates "
                "ORDER BY fin_group, valid_from"):
            if group in self.app.groups:
                self.tree.insert("", "end", iid=str(rid), values=(group, month_label(start),
                                                                  month_label(end) if end else NO_END, money(cents)))

    def load_selected(self):
        """Clicking a row puts it into the fields below (to change it: edit and press Saglabāt)."""
        sel = self.tree.selection()
        if not sel:
            return
        rows = self.app.db.q("SELECT fin_group, valid_from, COALESCE(valid_to, ''), amount_cents FROM fin_fee_rates "
                             "WHERE id=?", (int(sel[0]),))
        if not rows:
            return
        group, start, end, cents = rows[0]
        if group in self.edit_groups:
            self.g.set(group)
        self.m_from.set(MONTHS[int(start[5:7]) - 1])
        self.y_from.set(start[:4])
        if end:
            self.m_to.set(MONTHS[int(end[5:7]) - 1])
            self.y_to.set(end[:4])
        else:
            self.m_to.set(NO_END)
        self.a.set(money(cents, euro=False).replace(" ", ""))
        self.no_end_changed()

    def add(self):
        cents = parse_money(self.a.get())
        if cents is None:
            return messagebox.showwarning("Summa", "Ierakstiet mēneša maksu eiro (0, ja maksas nav).", parent=self)
        if self.g.get() not in self.edit_groups:
            return piekluve.deny(self)
        start = month_key(int(self.y_from.get()), MONTHS.index(self.m_from.get()) + 1)
        end = "" if self.m_to.get() == NO_END else month_key(int(self.y_to.get()), MONTHS.index(self.m_to.get()) + 1)
        if end and end < start:
            return messagebox.showwarning("Periods", "Mēnesis “līdz” ir agrāk nekā “no”.", parent=self)
        db = self.app.db
        if db.q("SELECT 1 FROM fin_fee_rates WHERE fin_group=? AND valid_from=?", (self.g.get(), start)):
            db.x("UPDATE fin_fee_rates SET amount_cents=?, valid_to=? WHERE fin_group=? AND valid_from=?",
                 (cents, end, self.g.get(), start))
        else:
            db.x("INSERT INTO fin_fee_rates (fin_group, valid_from, valid_to, amount_cents) VALUES (?, ?, ?, ?)",
                 (self.g.get(), start, end, cents))
        self.a.set("")
        self.refresh()
        self.app.refresh_all()

    def delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        group = self.tree.item(sel[0], "values")[0]
        if group not in self.edit_groups:
            return piekluve.deny(self)
        self.app.db.x("DELETE FROM fin_fee_rates WHERE id=?", (int(sel[0]),))
        self.refresh()
        self.app.refresh_all()


class PersonalFeeForm(tk.Toplevel):
    """Individual monthly fee of one dancer (discount, or 0 = released from the fee)."""

    def __init__(self, app, dancer):
        super().__init__(app.root)
        self.app, self.dancer = app, dancer
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Individuāla dalības maksa")
        self.transient(app.root)
        self.grab_set()
        current = app.db.personal_fees().get(dancer["id"])
        tk.Label(self, text=dancer["name"], font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.on = tk.BooleanVar(value=current is not None)
        tk.Checkbutton(self, text="Individuāla mēneša maksa (atlaide vai atbrīvojums)", variable=self.on, bg=CREAM,
                       fg=NAVY, activebackground=CREAM, selectcolor=WHITE).grid(row=1, column=0, columnspan=2,
                                                                               sticky="w")
        self.a = tk.StringVar(value=money(current[0], euro=False).replace(" ", "") if current else "0")
        self.n = tk.StringVar(value=current[1] if current else "")
        tk.Label(self, text="Maksa, €/mēn.", bg=CREAM, fg=NAVY).grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.a, width=10).grid(row=2, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="Iemesls", bg=CREAM, fg=NAVY).grid(row=3, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.n, width=34).grid(row=3, column=1, sticky="w", padx=(8, 0))
        tk.Label(self, text="0 € — dejotājs no dalības maksas atbrīvots. Ja atzīme noņemta, maksā grupas maksu.",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL).grid(row=4, column=0, columnspan=2, sticky="w")
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=5, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")
        if not piekluve.current().can_edit(MODULE_KEY, group=dancer["group"]):
            piekluve.make_readonly(self)

    def save(self):
        if getattr(self, "readonly", False):
            return piekluve.deny(self)
        db = self.app.db
        db.x("DELETE FROM fin_fee_personal WHERE dancer_id=?", (self.dancer["id"],))
        if self.on.get():
            cents = parse_money(self.a.get())
            if cents is None:
                return messagebox.showwarning("Summa", "Ierakstiet maksu eiro (0 — atbrīvots).", parent=self)
            db.x("INSERT INTO fin_fee_personal (dancer_id, amount_cents, note) VALUES (?, ?, ?)",
                 (self.dancer["id"], cents, self.n.get().strip()))
        self.destroy()
        self.app.refresh_all()


class OpeningWindow(tk.Toplevel):
    """Opening balances: the money the group had in cash and on the account before the first entry."""

    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Sākuma atlikums")
        self.transient(app.root)
        self.grab_set()
        acc = piekluve.current()
        opening = app.db.opening()
        tk.Label(self, text="Sākuma atlikums", font=("Georgia", 15, "bold"), bg=CREAM, fg=RED).grid(
            row=0, column=0, columnspan=3, sticky="w")
        tk.Label(self, text="Cik naudas grupai bija kasē un kontā pirms pirmā Zelta pūrā ierakstītā darījuma.",
                 bg=CREAM, fg=NAVY, font=("Segoe UI", 9)).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))
        tk.Label(self, text="Kasē (skaidrā naudā), €", bg=CREAM, fg=NAVY).grid(row=2, column=1, padx=6)
        tk.Label(self, text="Kontā, €", bg=CREAM, fg=NAVY).grid(row=2, column=2, padx=6)
        self.vars = {}
        for r, g in enumerate(app.groups, start=3):
            tk.Label(self, text=g, bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).grid(row=r, column=0, sticky="w")
            for c, m in enumerate(METHODS, start=1):
                var = tk.StringVar(value=money(opening.get((g, m), 0), euro=False).replace(" ", ""))
                e = ttk.Entry(self, textvariable=var, width=12)
                e.grid(row=r, column=c, padx=6, pady=3)
                if not acc.can_edit(MODULE_KEY, group=g):
                    e.configure(state="readonly")
                self.vars[(g, m)] = var
        btns = tk.Frame(self, bg=CREAM)
        btns.grid(row=10, column=0, columnspan=3, sticky="e", pady=(12, 0))
        ttk.Button(btns, text="Atcelt", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="Saglabāt", style="Accent.TButton", command=self.save).pack(side="right")

    def save(self):
        acc = piekluve.current()
        db = self.app.db
        values = {}
        for (g, m), var in self.vars.items():
            if not acc.can_edit(MODULE_KEY, group=g):
                continue
            text = var.get().strip()
            neg = text.startswith("-") or text.startswith("−")
            cents = parse_money(text.lstrip("-−")) if text.lstrip("-−") else 0
            if cents is None:
                return messagebox.showwarning("Summa", f"{g}, {m}: nepareiza summa.", parent=self)
            values[(g, m)] = -cents if neg else cents
        for (g, m), cents in values.items():
            db.x("DELETE FROM fin_opening WHERE fin_group=? AND method=?", (g, m))
            db.x("INSERT INTO fin_opening (fin_group, method, amount_cents) VALUES (?, ?, ?)", (g, m, cents))
        self.destroy()
        self.app.refresh_all()


class CategoriesWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.configure(bg=CREAM, padx=18, pady=14)
        self.title("Kategorijas")
        self.transient(app.root)
        self.grab_set()
        tk.Label(self, text="Ienākumu un izdevumu kategorijas", font=("Georgia", 15, "bold"), bg=CREAM,
                 fg=RED).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.lists = {}
        for c, kind in enumerate(KINDS):
            box = tk.LabelFrame(self, text=f" {kind} ", bg=CREAM, fg=GREEN if kind == INCOME else RED,
                                font=("Georgia", 11, "bold"), padx=8, pady=6)
            box.grid(row=1, column=c, sticky="nsew", padx=(0 if c == 0 else 10, 0))
            lb = tk.Listbox(box, width=34, height=12, bg=WHITE, fg=NAVY, selectbackground=GOLD,
                            selectforeground=NAVY, activestyle="none", exportselection=False)
            lb.pack(fill="both", expand=True)
            row = tk.Frame(box, bg=CREAM)
            row.pack(fill="x", pady=(6, 0))
            ttk.Button(row, text="＋ Jauna", command=lambda k=kind: self.add(k)).pack(side="left")
            ttk.Button(row, text="Pārdēvēt", command=lambda k=kind: self.rename(k)).pack(side="left", padx=4)
            ttk.Button(row, text="Dzēst", command=lambda k=kind: self.delete(k)).pack(side="left")
            self.lists[kind] = lb
        tk.Label(self, text="Pārdēvējot kategoriju, tā tiek nomainīta arī visiem jau ierakstītajiem darījumiem. "
                            "Dzēst var tikai kategoriju, kas nav izmantota. “Dalības maksa” ir obligāta.",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL, wraplength=560, justify="left").grid(
            row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Button(self, text="Aizvērt", command=self.destroy).grid(row=3, column=1, sticky="e", pady=(10, 0))
        self.bind("<Escape>", lambda e: self.destroy())
        self.refresh()
        if not piekluve.current().edits_all(MODULE_KEY):
            piekluve.make_readonly(self, note="Kategorijas ir kopīgas visām grupām — tās maina vadītājs vai "
                                              "sistēmas administrators.")

    def refresh(self):
        for kind, lb in self.lists.items():
            lb.delete(0, "end")
            for name in self.app.db.categories(kind):
                lb.insert("end", name)

    def chosen(self, kind):
        lb = self.lists[kind]
        sel = lb.curselection()
        return lb.get(sel[0]) if sel else None

    def ask(self, title, initial=""):
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=CREAM, padx=14, pady=12)
        win.transient(self)
        win.grab_set()
        var = tk.StringVar(value=initial)
        result = {}
        tk.Label(win, text="Nosaukums:", bg=CREAM, fg=NAVY).pack(anchor="w")
        e = ttk.Entry(win, textvariable=var, width=36)
        e.pack(fill="x", pady=4)
        e.focus_set()

        def ok(_e=None):
            result["v"] = var.get().strip()
            win.destroy()
        row = tk.Frame(win, bg=CREAM)
        row.pack(fill="x", pady=(6, 0))
        ttk.Button(row, text="Atcelt", command=win.destroy).pack(side="right", padx=4)
        ttk.Button(row, text="Labi", style="Accent.TButton", command=ok).pack(side="right")
        win.bind("<Return>", ok)
        win.bind("<Escape>", lambda e: win.destroy())
        modern_dialog(win, title=title)
        self.wait_window(win)
        try:
            self.grab_set()
        except tk.TclError:
            pass
        return result.get("v")

    def add(self, kind):
        name = self.ask(f"Jauna kategorija — {kind}")
        if not name:
            return
        db = self.app.db
        if db.q("SELECT 1 FROM fin_categories WHERE kind=? AND name=?", (kind, name)):
            return messagebox.showinfo("Kategorija", "Tāda kategorija jau ir.", parent=self)
        pos = (db.q("SELECT COALESCE(MAX(position), 0) FROM fin_categories WHERE kind=?", (kind,))[0][0] or 0) + 1
        db.x("INSERT INTO fin_categories (kind, name, position) VALUES (?, ?, ?)", (kind, name, pos))
        self.refresh()
        self.app.refresh_all()

    def rename(self, kind):
        old = self.chosen(kind)
        if not old:
            return
        if old in (FEE_CATEGORY, COSTUME_CATEGORY):
            return messagebox.showinfo("Kategorija", f"“{old}” nevar pārdēvēt — to izmanto cilne “{old}”.",
                                       parent=self)
        new = self.ask("Pārdēvēt kategoriju", old)
        if not new or new == old:
            return
        db = self.app.db
        if db.q("SELECT 1 FROM fin_categories WHERE kind=? AND name=?", (kind, new)):
            return messagebox.showinfo("Kategorija", "Tāda kategorija jau ir.", parent=self)
        db.con.execute("UPDATE fin_categories SET name=? WHERE kind=? AND name=?", (new, kind, old))
        db.con.execute("UPDATE fin_entries SET category=? WHERE kind=? AND category=?", (new, kind, old))
        db.con.commit()
        self.refresh()
        self.app.refresh_all()

    def delete(self, kind):
        name = self.chosen(kind)
        if not name:
            return
        if name in (FEE_CATEGORY, COSTUME_CATEGORY):
            return messagebox.showinfo("Kategorija", f"“{name}” nevar dzēst.", parent=self)
        db = self.app.db
        used = db.q("SELECT COUNT(*) FROM fin_entries WHERE kind=? AND category=?", (kind, name))[0][0]
        if used:
            return messagebox.showinfo("Kategorija", f"Kategorija izmantota {used} darījumos — to nevar dzēst. "
                                                     "Varat to pārdēvēt.", parent=self)
        if messagebox.askyesno("Dzēst", f"Dzēst kategoriju “{name}”?", parent=self):
            db.x("DELETE FROM fin_categories WHERE kind=? AND name=?", (kind, name))
            self.refresh()
            self.app.refresh_all()


# --------------------------------------------------------------------------
# The common look (Pūrlāde v0.8 — moduli/izskats.py)
# --------------------------------------------------------------------------
LINE, LINE_SOFT, FIELD_LINE, MUTED, SELECTED = izskats.LINE, izskats.LINE_SOFT, izskats.FIELD_LINE, izskats.MUTED, \
    izskats.SELECTED
OK_BG, OK_FG, WARN_BG, WARN_FG, BAD_BG, BAD_FG = (izskats.OK_BG, izskats.OK_FG, izskats.WARN_BG, izskats.WARN_FG,
                                                  izskats.BAD_BG, izskats.BAD_FG)
ZEBRA = izskats.ZEBRA
FONT, FONT_BOLD, FONT_SMALL = izskats.FONT, izskats.FONT_BOLD, izskats.FONT_SMALL
MODULE_COLOUR = izskats.MODULE_COLORS.get(MODULE_KEY, GOLD)
# cell look of the payment tables: state -> (background, border/text colour)
CELL_LOOK = {"y": (OK_BG, OK_FG), "p": (WARN_BG, WARN_FG), "n": (BAD_BG, BAD_FG), "x": ("#F3F1EC", "#B8AE96"),
             "f": (WHITE, LINE), "o": ("#E8EEF7", NAVY)}
ROW_FG = {"debt": RED, "pause": WARN_FG, "left": GREY, "ok": NAVY, "open": NAVY}


zebra = izskats.zebra   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


boxed = izskats.boxed   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


recolour = izskats.recolour   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


def modern_dialog(win, title=None, subtitle=None):
    """Turn an older pop-up window (title label on top, fields, a row of buttons at the bottom) into the new look:
    white title strip, the fields on a white panel, the buttons in a white bar at the bottom. Works for windows laid
    out with grid or with pack; the widgets themselves are not changed, only moved into the new frames."""
    try:
        slaves = win.grid_slaves()
        manager = "grid"
        if not slaves:
            slaves, manager = win.pack_slaves(), "pack"
        if not slaves:
            return
        if manager == "grid":
            slaves = sorted(slaves, key=lambda w: (int(w.grid_info()["row"]), int(w.grid_info()["column"])))
        infos = [(w, dict(w.grid_info() if manager == "grid" else w.pack_info())) for w in slaves]
        cols = {}
        if manager == "grid":
            size = win.grid_size()
            cols = {"c": [(i, win.grid_columnconfigure(i)) for i in range(size[0])],
                    "r": [(i, win.grid_rowconfigure(i)) for i in range(size[1])]}
        # the big coloured title and (if next to it) its explanation
        colour = MODULE_COLOUR
        head_w, sub_w = None, None
        for i, (w, _info) in enumerate(infos):
            if isinstance(w, tk.Label) and "Georgia" in str(w.cget("font")):
                head_w = w
                if title is None:
                    title = w.cget("text")
                fg = str(w.cget("fg")).upper()
                colour = OK_FG if fg == GREEN.upper() else (RED if fg == RED.upper() else MODULE_COLOUR)
                nxt, nxt_info = infos[i + 1] if i + 1 < len(infos) else (None, {})
                spans = manager == "pack" or int(nxt_info.get("columnspan", 1)) > 1
                if (subtitle is None and spans and isinstance(nxt, tk.Label) and "Georgia" not in str(nxt.cget("font"))
                        and not str(nxt.cget("textvariable"))):
                    sub_w, subtitle = nxt, nxt.cget("text")
                break
        # the button row: the last frame that holds only buttons, or a single button at the end
        foot_w = None
        for w, _info in reversed(infos):
            kids = w.winfo_children() if isinstance(w, (tk.Frame, ttk.Frame)) else []
            if kids and all(isinstance(k, (ttk.Button, tk.Button)) for k in kids):
                foot_w = w
                break
            if isinstance(w, ttk.Button):
                foot_w = w
                break
        for w, _info in infos:
            w.grid_forget() if manager == "grid" else w.pack_forget()
        for w in (head_w, sub_w):
            if w is not None:
                w.destroy()
        win.configure(padx=0, pady=0, bg=CREAM)
        izskats.dialog_header(win, title or win.title(), subtitle or "", colour=colour, wrap=620)
        foot = izskats.dialog_footer(win)
        body = tk.Frame(win, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
        body.pack(fill="both", expand=True, padx=18, pady=14)
        inner = tk.Frame(body, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=16, pady=12)
        for w, info in infos:
            if w in (head_w, sub_w):
                continue
            info.pop("in", None)
            if w is foot_w:
                if isinstance(w, ttk.Button):
                    w.pack(in_=foot, side="right")
                else:
                    w.pack(in_=foot, fill="x")
                w.lift()
                continue
            if manager == "grid":
                w.grid(in_=inner, **info)
            else:
                w.pack(in_=inner, **info)
            w.lift()   # the widgets were made before the new panel: bring them in front of it
        for kind, items in cols.items():
            for i, conf in items:
                if conf.get("weight"):
                    (inner.columnconfigure if kind == "c" else inner.rowconfigure)(i, weight=conf["weight"])
        recolour(win)
    except tk.TclError:
        log_error(traceback.format_exc())


def modernize(cls):
    """Class decorator: the window gets the new look when it has been built."""
    original = cls.__init__

    def __init__(self, *args, **kwargs):
        original(self, *args, **kwargs)
        try:
            if self.winfo_exists():
                modern_dialog(self)
        except tk.TclError:
            pass
    cls.__init__ = __init__
    return cls


TabHost = izskats.TabHost   # kopīgais (moduli/izskats.py, Pūrlāde v0.9.6)


class CellGrid(tk.Frame):
    """A table drawn on a canvas, with coloured cells (paid ✓ / part / ✗ / not due – / later).
    columns: [(key, title, width, kind)] — kind 'text' (left), 'num' (right) or 'cell' (coloured box)."""
    ROW, HEAD = 30, 34

    def __init__(self, master, columns, on_double=None, on_select=None):
        super().__init__(master, bg=WHITE)
        self.columns = list(columns)
        self.titles = {c[0]: c[1] for c in self.columns}
        self.on_double, self.on_select = on_double, on_select
        self.rows, self.selected = [], None
        self.head = tk.Canvas(self, height=self.HEAD, bg=SELECTED, highlightthickness=0)
        self.body = tk.Canvas(self, bg=WHITE, highlightthickness=0, takefocus=1)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.body.yview)
        hsb = ttk.Scrollbar(self, orient="horizontal", command=self._xview)
        self.body.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.head.configure(xscrollcommand=hsb.set)
        self.head.grid(row=0, column=0, sticky="ew")
        self.body.grid(row=1, column=0, sticky="nsew")
        vsb.grid(row=1, column=1, sticky="ns")
        hsb.grid(row=2, column=0, sticky="ew")
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)
        self.body.bind("<Configure>", lambda e: self.draw())
        self.body.bind("<Button-1>", self.click)
        self.body.bind("<Double-1>", self.double)
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.body.bind(seq, self.wheel)
        self.body.bind("<Up>", lambda e: self.move(-1))
        self.body.bind("<Down>", lambda e: self.move(1))

    def _xview(self, *args):
        self.head.xview(*args)
        self.body.xview(*args)

    def wheel(self, event):
        step = -1 if (getattr(event, "num", 0) == 4 or getattr(event, "delta", 0) > 0) else 1
        self.body.yview_scroll(step * 2, "units")

    # -- the Treeview-like part used by the module ------------------------------
    def heading(self, key, text=None):
        if text is not None:
            self.titles[key] = text
            self.draw_head()
        return self.titles.get(key, "")

    def selection(self):
        return (self.selected,) if self.selected is not None else ()

    def selection_set(self, iid):
        self.selected = str(iid)
        self.draw()

    def exists(self, iid):
        return any(r["iid"] == str(iid) for r in self.rows)

    def set_rows(self, rows):
        """rows: [{iid, values: {key: text}, states: {key: state}, tag}]"""
        self.rows = rows
        if self.selected is not None and not self.exists(self.selected):
            self.selected = None
        self.draw()

    # -- drawing ------------------------------------------------------------------
    def layout(self):
        width = max(self.body.winfo_width(), 100)
        total = sum(c[2] for c in self.columns)
        extra = max(0, width - total)
        xs, x = {}, 0
        for i, (key, _t, w, _k) in enumerate(self.columns):
            w = w + (extra if i == 0 else 0)
            xs[key] = (x, x + w)
            x += w
        return xs, x

    def draw_head(self):
        c = self.head
        c.delete("all")
        xs, total = self.layout()
        c.create_rectangle(0, 0, total, self.HEAD, fill=SELECTED, outline="")
        for key, _t, _w, kind in self.columns:
            x0, x1 = xs[key]
            text = self.titles[key]
            if kind == "text":
                c.create_text(x0 + 10, self.HEAD / 2, text=text, anchor="w", fill=NAVY, font=FONT_BOLD)
            elif kind == "num":
                c.create_text(x1 - 10, self.HEAD / 2, text=text, anchor="e", fill=NAVY, font=FONT_BOLD)
            else:
                c.create_text((x0 + x1) / 2, self.HEAD / 2, text=text, fill=NAVY, font=FONT_BOLD)
        c.configure(scrollregion=(0, 0, total, self.HEAD))

    def draw(self):
        self.draw_head()
        c = self.body
        c.delete("all")
        xs, total = self.layout()
        if not self.rows:
            c.create_text(max(c.winfo_width(), 200) / 2, 40, text="Nav ierakstu", fill=MUTED, font=FONT)
            c.configure(scrollregion=(0, 0, total, 80))
            return
        for i, r in enumerate(self.rows):
            y = i * self.ROW
            on = r["iid"] == self.selected
            c.create_rectangle(0, y, total, y + self.ROW, fill=SELECTED if on else (ZEBRA if i % 2 else WHITE),
                               outline="")
            if on:
                c.create_rectangle(0, y, 3, y + self.ROW, fill=MODULE_COLOUR, outline="")
            c.create_line(0, y + self.ROW - 1, total, y + self.ROW - 1, fill=LINE_SOFT)
            fg = ROW_FG.get(r.get("tag"), NAVY)
            for key, _t, _w, kind in self.columns:
                x0, x1 = xs[key]
                text = r["values"].get(key, "")
                if kind == "cell":
                    state = r["states"].get(key, "f")
                    bg, line = CELL_LOOK.get(state, CELL_LOOK["f"])
                    c.create_rectangle(x0 + 3, y + 3, x1 - 3, y + self.ROW - 4, fill=bg, outline=line)
                    tfg = line if state != "f" else MUTED
                    c.create_text((x0 + x1) / 2, y + self.ROW / 2 - 0.5, text=text, fill=tfg,
                                  font=("Segoe UI", 9, "bold"))
                elif kind == "num":
                    c.create_text(x1 - 10, y + self.ROW / 2, text=text, anchor="e",
                                  fill=RED if key == "debt" and text not in ("", "—") else fg,
                                  font=FONT_BOLD if key == "debt" else FONT)
                else:
                    c.create_text(x0 + 10, y + self.ROW / 2, text=text, anchor="w", fill=fg,
                                  font=FONT_BOLD if key == "name" else FONT)
        c.configure(scrollregion=(0, 0, total, len(self.rows) * self.ROW))

    # -- mouse and keys --------------------------------------------------------------
    def hit(self, event):
        i = int(self.body.canvasy(event.y) // self.ROW)
        if not 0 <= i < len(self.rows):
            return None, None
        x = self.body.canvasx(event.x)
        xs, _total = self.layout()
        key = next((k for k, (x0, x1) in xs.items() if x0 <= x < x1), None)
        return self.rows[i]["iid"], key

    def click(self, event):
        self.body.focus_set()
        iid, _key = self.hit(event)
        if iid is not None and iid != self.selected:
            self.selected = iid
            self.draw()
            if self.on_select:
                self.on_select(iid)

    def double(self, event):
        iid, key = self.hit(event)
        if iid is not None and self.on_double:
            self.selected = iid
            self.draw()
            self.on_double(iid, key)

    def move(self, step):
        if not self.rows:
            return
        ids = [r["iid"] for r in self.rows]
        i = ids.index(self.selected) if self.selected in ids else -1
        i = max(0, min(len(ids) - 1, i + step))
        self.selected = ids[i]
        self.draw()


def legend(parent, items, bg=WHITE):
    """Small coloured squares with their meaning: [(state, text)]."""
    box = tk.Frame(parent, bg=bg)
    for state, text in items:
        fill, line = CELL_LOOK[state]
        sq = tk.Frame(box, bg=fill, highlightbackground=line, highlightthickness=1, width=12, height=12)
        sq.pack(side="left", padx=(10, 4))
        tk.Label(box, text=text, bg=bg, fg="#4A4535", font=FONT_SMALL).pack(side="left")
    return box


def toolbar(parent, store=None):
    """White bar for the buttons and filters of a tab; returns the inner frame (kopīgais izskats.white_bar)."""
    return izskats.white_bar(parent, store=store)


for _cls in (EntryForm, FeePaymentForm, CostumePaymentForm, CostumeRatesWindow, BusPaymentForm, FeeRatesWindow,
             PersonalFeeForm, OpeningWindow, CategoriesWindow):
    modernize(_cls)   # Pūrlāde v0.8.7: the pop-up windows in the new look


# --------------------------------------------------------------------------
# Main window of the module
# --------------------------------------------------------------------------
ENTRY_COLUMNS = [
    ("date", "Datums", 95),
    ("kind", "Veids", 85),
    ("category", "Kategorija", 190),
    ("amount", "Summa", 110),
    ("group", "Grupa", 70),
    ("party", "Maksātājs / saņēmējs", 190),
    ("method", "Maksājuma veids", 120),
    ("event", "Notikums", 200),
    ("document", "Dokuments", 110),
    ("notes", "Piezīmes", 220),
]


class App:
    def __init__(self, root, on_exit=None, title_prefix=""):
        self.root = root
        self.on_exit = on_exit
        self.title_prefix = title_prefix
        prepare_database()
        self.db = Database(DB_PATH)
        acc = piekluve.current()
        groups = acc.groups(MODULE_KEY)
        # a role that may only look (none today) sees every group; the cashiers / presidents only their own
        self.groups = groups if groups else list(DANCER_GROUPS)
        self.can_edit_any = any(acc.can_edit(MODULE_KEY, group=g) for g in self.groups)
        if on_exit is None:
            root.geometry("1180x800")
        root.minsize(980, 680)
        root.configure(bg=CREAM)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        izskats.apply_style()   # kopīgais izskats (Pūrlāde v0.8)
        ttk.Style().configure("White.TLabel", background=WHITE, foreground=NAVY)

    # ---- layout -----------------------------------------------------------

    def build_ui(self):
        for child in self.root.winfo_children():
            child.destroy()
        self.root.title(f"{self.title_prefix}{PROGRAM_NAME} v{APP_VERSION}")

        # Pūrlāde v0.8: baltā moduļa galvene ar cilnēm (moduli/izskats.py); navigācija — Pūrlādes sānu joslā
        self.header_right = hr = izskats.module_header(
            self.root, MODULE_KEY, PROGRAM_NAME, f"Kolektīva finanses · v{APP_VERSION}", on_logo=self.show_main,
            on_exit=None if self.on_exit is not None else self.root.destroy, tabs=True)
        # group + year (for every tab) and the module's own buttons — in the header
        self.group_var = tk.StringVar(value=ALL_GROUPS if len(self.groups) > 1 else self.groups[0])
        self.year_var = tk.StringVar(value=str(date.today().year))
        if self.can_edit_any:
            izskats.header_button(hr, "⇪ Importēt no Excel", self.import_excel).pack(side="right", padx=(6, 0))
        izskats.header_button(hr, "⚙ Kategorijas", lambda: CategoriesWindow(self)).pack(side="right", padx=(6, 0))
        izskats.header_button(hr, "Sākuma atlikums", lambda: OpeningWindow(self)).pack(side="right", padx=(6, 0))
        self.year_cb = ttk.Combobox(hr, textvariable=self.year_var, state="readonly", width=7)
        self.year_cb.pack(side="right", padx=(4, 14))
        tk.Label(hr, text="GADS", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="right")
        gcb = ttk.Combobox(hr, textvariable=self.group_var, state="readonly", width=9,
                           values=([ALL_GROUPS] if len(self.groups) > 1 else []) + self.groups)
        gcb.pack(side="right", padx=(4, 12))
        tk.Label(hr, text="GRUPA", bg=WHITE, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="right")
        for cb in (gcb, self.year_cb):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_all())
        acc = piekluve.current()
        if not acc.edits_all(MODULE_KEY):
            text = ("🔒 tikai skatīšanai" if not self.can_edit_any else
                    "🔒 tikai " + ", ".join(self.groups) + " grupas finanses")
            tk.Label(hr, text=text, bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold")).pack(side="right", padx=(0, 12))

        # summary cards
        cards = tk.Frame(self.root, bg=CREAM)
        cards.pack(fill="x", padx=20, pady=(14, 0))
        self.card_vars = {}
        self.card_titles = {}
        specs = [("balance", "Atlikums kopā", NAVY), ("cash", "Kasē (skaidrā naudā)", DARK_GOLD),
                 ("bank", "Kontā", NAVY), ("income", "Ienākumi", OK_FG), ("expense", "Izdevumi", RED),
                 ("debt", "Dalības maksu parāds", RED), ("costume_debt", "Tērpu fonda parāds", RED)]
        for i, (key, title, colour) in enumerate(specs):
            cards.columnconfigure(i, weight=1, uniform="card")
            card = tk.Frame(cards, bg=WHITE, highlightbackground=LINE, highlightcolor=LINE, highlightthickness=1)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 4, 0 if i == len(specs) - 1 else 4))
            tk.Frame(card, bg=colour, width=4).pack(side="left", fill="y")
            inner = tk.Frame(card, bg=WHITE)
            inner.pack(side="left", fill="both", expand=True, padx=10, pady=8)
            var = tk.StringVar(value="—")
            tvar = tk.StringVar(value=title)
            self.card_vars[key] = var
            self.card_titles[key] = (tvar, title)
            tk.Label(inner, textvariable=tvar, font=("Segoe UI", 8), bg=WHITE, fg=MUTED, anchor="w", justify="left",
                     wraplength=140).pack(fill="x")
            tk.Label(inner, textvariable=var, font=("Georgia", 15, "bold"), bg=WHITE, fg=colour, anchor="w").pack(
                fill="x")

        self._bars = []
        self.nb = TabHost(self.root, hr.tabs)
        self.nb.pack(fill="both", expand=True, padx=20, pady=(12, 14))
        self.build_entries_tab()
        self.build_fees_tab()
        self.build_costume_tab()
        self.build_bus_tab()
        self.build_events_tab()
        self.build_report_tab()
        for bar in self._bars:
            recolour(bar)
        self.nb.select(0)
        self.refresh_all()

    def import_excel(self):
        try:
            from moduli import zelta_imports
        except ImportError:
            import zelta_imports
        zelta_imports.start_import(self)

    # ---- tab: Darījumi -------------------------------------------------------
    def build_entries_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Darījumi  ")
        bar = toolbar(tab, self._bars)
        b1 = ttk.Button(bar, text="＋ Ienākums", style="Green.TButton",
                        command=lambda: EntryForm(self, kind=INCOME))
        b1.pack(side="left")
        b2 = ttk.Button(bar, text="－ Izdevums", style="Danger.TButton",
                        command=lambda: EntryForm(self, kind=EXPENSE))
        b2.pack(side="left", padx=6)
        ttk.Button(bar, text="Atvērt" if not self.can_edit_any else "Rediģēt",
                   command=self.edit_entry).pack(side="left", padx=3)
        b3 = ttk.Button(bar, text="Dzēst", style="Danger.TButton", command=self.delete_entry)
        b3.pack(side="left", padx=3)
        if not self.can_edit_any:
            for b in (b1, b2, b3):
                b.configure(state="disabled")
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_entries).pack(side="right")

        flt = toolbar(tab, self._bars)
        self.search = tk.StringVar()
        self.f_kind = tk.StringVar(value=ALL)
        self.f_cat = tk.StringVar(value=ALL)
        self.f_month = tk.StringVar(value=ALL)
        ttk.Label(flt, text="Meklēt:").pack(side="left")
        ttk.Entry(flt, textvariable=self.search, width=22).pack(side="left", padx=(4, 14))
        self.search.trace_add("write", lambda *a: self.refresh_entries())
        ttk.Label(flt, text="Mēnesis:").pack(side="left")
        mcb = ttk.Combobox(flt, textvariable=self.f_month, values=[ALL] + MONTHS, state="readonly", width=11)
        mcb.pack(side="left", padx=(4, 14))
        ttk.Label(flt, text="Veids:").pack(side="left")
        kcb = ttk.Combobox(flt, textvariable=self.f_kind, values=[ALL] + KINDS, state="readonly", width=10)
        kcb.pack(side="left", padx=(4, 14))
        ttk.Label(flt, text="Kategorija:").pack(side="left")
        self.cat_filter = ttk.Combobox(flt, textvariable=self.f_cat, state="readonly", width=26)
        self.cat_filter.pack(side="left", padx=4)
        for cb in (mcb, kcb, self.cat_filter):
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_entries())
        ttk.Button(flt, text="Notīrīt filtrus", command=self.clear_filters).pack(side="right")

        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=[c[0] for c in ENTRY_COLUMNS], show="headings")
        for key, title, width in ENTRY_COLUMNS:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=50, anchor="e" if key == "amount" else "w",
                             stretch=key == "notes")
        self.tree.tag_configure(INCOME, foreground=OK_FG)
        self.tree.tag_configure(EXPENSE, foreground=RED)
        zebra(self.tree)
        self.tree.bind("<Double-1>", lambda e: self.edit_entry())
        make_tree_with_scroll(holder, self.tree)
        self.entries_info = tk.StringVar()
        tk.Label(tab, textvariable=self.entries_info, bg=CREAM, fg=MUTED, font=FONT_SMALL).pack(
            anchor="w", pady=(4, 0))
        self.sort_key, self.sort_desc = "date", True

    # ---- tab: Dalības maksas -------------------------------------------------
    def build_fees_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Dalības maksas  ")
        bar = toolbar(tab, self._bars)
        b1 = ttk.Button(bar, text="＋ Reģistrēt samaksu", style="Accent.TButton", command=self.fee_payment)
        b1.pack(side="left")
        b2 = ttk.Button(bar, text="Individuāla maksa…", command=self.personal_fee)
        b2.pack(side="left", padx=6)
        ttk.Button(bar, text="Dalības maksas apmērs…", command=lambda: FeeRatesWindow(self)).pack(side="left")
        if not self.can_edit_any:
            for b in (b1, b2):
                b.configure(state="disabled")
        tk.Label(bar, text="Sezona:", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).pack(side="left",
                                                                                       padx=(16, 4))
        self.season_var = tk.StringVar(value=season_label(current_season()))
        self.season_cb = ttk.Combobox(bar, textvariable=self.season_var, state="readonly", width=10)
        self.season_cb.pack(side="left")
        self.season_cb.bind("<<ComboboxSelected>>", lambda e: (self.refresh_cards(), self.refresh_fees()))
        self.fee_show_left = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Rādīt arī izstājušos", variable=self.fee_show_left, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_fees).pack(side="left",
                                                                                                  padx=(14, 0))
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_fees).pack(side="right")
        cols = ([("name", "Dejotājs", 170, "text"), ("group", "Grupa", 56, "text"), ("rate", "€/mēn.", 62, "num")]
                + [(f"m{i}", MONTHS_SHORT[i - 1], 46, "cell") for i in range(1, 13)]
                + [("paid", "Samaksāts", 88, "num"), ("debt", "Parāds", 84, "num")])
        legend(tab, [("y", "✓ samaksāts"), ("p", "daļēji"), ("n", "✗ parāds"), ("x", "– nav jāmaksā"),
                     ("f", "vēl nav pienācis")], bg=CREAM).pack(anchor="w", pady=(0, 6))
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.fee_tree = CellGrid(holder, cols, on_double=self.fee_double_click)
        self.fee_tree.pack(fill="both", expand=True)
        tk.Label(tab, text="✓ samaksāts · skaitlis — samaksāta daļa · ✗ nav samaksāts · – maksa nepienākas "
                           "(pirms iestāšanās vai mēnesī, kad maksa nav spēkā) · tukšs — mēnesis vēl nav pienācis. "
                           "Sezona — no septembra līdz augustam. Parāds skaitās līdz "
                           "šim mēnesim, dejotājiem “Uz pauzes” un izstājušamies — netiek skaitīts. "
                           "Dubultklikšķis uz mēneša — reģistrēt samaksu; samaksas logā “Nav jāmaksā” atbrīvo atzīmētos "
                           "mēnešus (tabulā “x”).",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL, wraplength=1000, justify="left").pack(
            anchor="w", pady=(4, 0))

    # ---- tab: Honorāri --------------------------------------------------------
    # ---- tab: Tērpu fonds ---------------------------------------------------------
    def build_costume_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Tērpu fonds  ")
        bar = toolbar(tab, self._bars)
        b1 = ttk.Button(bar, text="＋ Reģistrēt samaksu", style="Accent.TButton", command=self.costume_payment)
        b1.pack(side="left")
        ttk.Button(bar, text="Tērpu fonda apmērs…", command=lambda: CostumeRatesWindow(self)).pack(side="left",
                                                                                                    padx=6)
        if not self.can_edit_any:
            b1.configure(state="disabled")
        tk.Label(bar, text="Sezona:", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold")).pack(side="left",
                                                                                       padx=(16, 4))
        self.costume_season_var = tk.StringVar(value=season_label(current_season()))
        self.costume_season_cb = ttk.Combobox(bar, textvariable=self.costume_season_var, state="readonly", width=10)
        self.costume_season_cb.pack(side="left")
        self.costume_season_cb.bind("<<ComboboxSelected>>", lambda e: (self.refresh_cards(), self.refresh_costume()))
        self.costume_show_left = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Rādīt arī izstājušos", variable=self.costume_show_left, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_costume).pack(side="left",
                                                                                                     padx=(14, 0))
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_costume).pack(side="right")
        cols = [("name", "Dejotājs", 230, "text"), ("group", "Grupa", 70, "text"), ("h1", "1. pusgads", 190, "cell"),
                ("h2", "2. pusgads", 190, "cell"), ("paid", "Samaksāts sezonā", 130, "num"), ("debt", "Parāds", 110, "num")]
        legend(tab, [("y", "✓ samaksāts"), ("p", "daļēji"), ("n", "✗ termiņš pagājis"), ("o", "jāmaksā"),
                     ("x", "– nav jāmaksā")], bg=CREAM).pack(anchor="w", pady=(0, 6))
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.costume_tree = CellGrid(holder, cols, on_double=self.costume_double_click)
        self.costume_tree.pack(fill="both", expand=True)
        tk.Label(tab, text="Katram dejotājam par katru pusgadu jāiemaksā tērpu fondā: par 1. pusgadu — līdz 15. "
                           "decembrim, par 2. pusgadu — līdz 15. maijam. ✓ samaksāts · skaitlis — samaksāta daļa · "
                           "✗ termiņš pagājis, nav samaksāts · “jāmaksā” — termiņš vēl nav pienācis · – nav jāmaksā "
                           "(iestājies pēc termiņa, atbrīvots vai apmērs nav iestatīts). Parāds — tikai pusgadi, kuru "
                           "termiņš pagājis; dejotājiem “Uz pauzes” un izstājušamies netiek skaitīts. Dubultklikšķis "
                           "uz pusgada — reģistrēt samaksu (vai atvērt jau reģistrēto).",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL, wraplength=1000, justify="left").pack(
            anchor="w", pady=(4, 0))

    def costume_season(self):
        try:
            return int(self.costume_season_var.get()[:4])
        except (ValueError, AttributeError):
            return current_season()

    def costume_rows(self, season):
        """[(dancer, {half: (due, paid, deadline passed)}, paid in the season, debt)]"""
        rates = self.db.costume_rates()
        paid = costume_paid(self.all_entries)
        groups = set(self.chosen_groups())
        today = date.today()
        keys = [half_key(season, 1), half_key(season, 2)]
        out = []
        for d in sorted(self.dancer_map.values(), key=lambda d: _norm(d["name"])):
            if not d["dancer"] or d["group"] not in groups:
                continue
            got = paid.get(d["id"], {})
            season_paid = sum(got.get(k, 0) for k in keys)
            if d["status"] == STATUS_LEFT and not season_paid and not self.costume_show_left.get():
                continue
            cells, debt = {}, 0
            for k in keys:
                due = costume_due(rates, d, k)
                passed = half_deadline(k) < today
                cells[k] = (due, got.get(k, 0), passed)
                if d["status"] == STATUS_ACTIVE and passed:
                    debt += max(due - got.get(k, 0), 0)
            out.append((d, cells, season_paid, debt))
        return out

    def costume_debt_total(self):
        try:
            return sum(r[3] for r in self.costume_rows(self.costume_season()))
        except Exception:
            log_error(traceback.format_exc())
            return 0

    def refresh_costume(self):
        season = self.costume_season()
        keys = [half_key(season, 1), half_key(season, 2)]
        for col, k in zip(("h1", "h2"), keys):
            self.costume_tree.heading(col, text=f"{half_label(k, short=True)} (līdz {half_deadline(k):%d.%m.%Y})")
        rows = []
        self.costume_export = []
        for d, cells, season_paid, debt in self.costume_rows(season):
            values = {"name": d["name"] + ("" if d["status"] == STATUS_ACTIVE else f" ({d['status'].lower()})"),
                      "group": d["group"]}
            states = {}
            exp = [d["name"], d["group"], d["status"]]
            for col, k in zip(("h1", "h2"), keys):
                due, got, passed = cells[k]
                if got and got >= due:
                    cell, state = ("✓" if got == due or not due else f"✓ {money(got, euro=False)}"), "y"
                elif got:
                    cell, state = f"{money(got, euro=False)} no {money(due, euro=False)}", "p"
                elif not due:
                    cell, state = "–", "x"
                elif passed:
                    cell, state = f"✗ {money(due, euro=False)}", "n"
                else:
                    cell, state = f"jāmaksā {money(due, euro=False)}", "o"
                values[col], states[col] = cell, state
                exp += [money_plain(due), money_plain(got)]
            values["paid"], values["debt"] = money(season_paid), (money(debt) if debt else "—")
            exp += [money_plain(season_paid), money_plain(debt)]
            open_ = any(c[0] > c[1] for c in cells.values())
            tag = ("left" if d["status"] == STATUS_LEFT else "pause" if d["status"] == STATUS_INACTIVE
                   else "debt" if debt else "open" if open_ else "ok")
            rows.append({"iid": str(d["id"]), "values": values, "states": states, "tag": tag})
            self.costume_export.append(exp)
        self.costume_tree.set_rows(rows)
        rates = self.db.costume_rates()
        missing = [g for g in self.chosen_groups() if costume_rate_for(rates, g, season) is None]
        self.costume_tree.heading("name", text="Dejotājs" + (f"  ⚠ nav apmēra: {', '.join(missing)}" if missing
                                                             else ""))

    def costume_payment(self, dancer_id=None, half=None):
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        rates = self.db.costume_rates()
        if not any(k != DUE_KEY and v for k, v in rates.items()):
            if messagebox.askyesno("Tērpu fonds", "Tērpu fonda apmērs vēl nav iestatīts. Iestatīt tagad?",
                                   parent=self.root):
                CostumeRatesWindow(self)
            return
        if dancer_id is None and self.costume_tree.selection():
            dancer_id = int(self.costume_tree.selection()[0])
        CostumePaymentForm(self, dancer_id, self.costume_season(), half)

    def costume_double_click(self, row, cid):
        """Double click in the costume fund table (row = dancer id, cid = column key)."""
        if not row:
            return
        half = None
        if cid in ("h1", "h2"):
            half = half_key(self.costume_season(), int(cid[1]))
            for d, cells, _p, _debt in self.costume_rows(self.costume_season()):
                if d["id"] == int(row):
                    due, got, _passed = cells[half]
                    if got and got >= due:   # paid: show the payment
                        entries = [e for e in self.all_entries if e["category"] == COSTUME_CATEGORY
                                   and e["dancer_id"] == int(row)
                                   and half in [k for k, _c in half_parts_of(e["fee_months"])]]
                        if entries:
                            return EntryForm(self, entries[-1]["id"])
        self.costume_payment(int(row), half)

    def export_costume(self):
        season = self.costume_season()
        h = [half_label(half_key(season, i), short=True) for i in (1, 2)]
        header = ["Dejotājs", "Grupa", "Statuss", f"{h[0]} jāmaksā", f"{h[0]} samaksāts", f"{h[1]} jāmaksā",
                  f"{h[1]} samaksāts", "Samaksāts sezonā", "Parāds"]
        save_csv(self.root, "Eksportēt tērpu fondu", f"Zelta pūrs tērpu fonds {season}-{season + 1}.csv", header,
                 getattr(self, "costume_export", []))

    # ---- tab: Autobusi ----------------------------------------------------------
    def build_bus_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Autobusi  ")
        self.bus_tab = tab
        bar = toolbar(tab, self._bars)
        b = ttk.Button(bar, text="＋ Reģistrēt samaksu", style="Accent.TButton", command=self.bus_payment)
        b.pack(side="left")
        if not self.can_edit_any:
            b.configure(state="disabled")
        self.bus_only_debt = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Tikai ar parādu", variable=self.bus_only_debt, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_bus).pack(side="left",
                                                                                                 padx=(14, 0))
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_bus).pack(side="right")
        self.bus_total = tk.Label(bar, text="", bg=CREAM, fg=NAVY, font=("Segoe UI", 10, "bold"))
        self.bus_total.pack(side="right", padx=(0, 12))
        pane = ttk.PanedWindow(tab, orient="vertical")
        pane.pack(fill="both", expand=True)
        top = boxed(pane)
        bottom = boxed(pane)
        pane.add(top, weight=1)
        pane.add(bottom, weight=2)
        cols = [("date", "Datums", 90), ("title", "Notikums", 240), ("groups", "Grupa", 80), ("price", "Cena", 80),
                ("payers", "Jāmaksā", 70), ("paid", "Samaksājuši", 90), ("got", "Saņemts", 100),
                ("debt", "Parāds", 100)]
        self.bus_ev_tree = ttk.Treeview(top, columns=[c[0] for c in cols], show="headings", selectmode="browse",
                                        height=6)
        for key, title, width in cols:
            self.bus_ev_tree.heading(key, text=title)
            self.bus_ev_tree.column(key, width=width, stretch=key == "title",
                                    anchor="w" if key in ("date", "title", "groups") else "e")
        self.bus_ev_tree.tag_configure("open", foreground=RED)
        self.bus_ev_tree.tag_configure("done", foreground=OK_FG)
        self.bus_ev_tree.bind("<<TreeviewSelect>>", lambda e: self.refresh_bus_people())
        make_tree_with_scroll(top, self.bus_ev_tree)
        cols = [("name", "Dejotājs", 220), ("group", "Grupa", 80), ("why", "Kāpēc maksā", 160),
                ("paid", "Samaksāts", 100), ("due", "Jāmaksā", 100), ("status", "Statuss", 130)]
        self.bus_tree = ttk.Treeview(bottom, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.bus_tree.heading(key, text=title)
            self.bus_tree.column(key, width=width, stretch=key == "name",
                                 anchor="e" if key in ("paid", "due") else "w")
        self.bus_tree.tag_configure("open", foreground=RED)
        self.bus_tree.tag_configure("done", foreground=OK_FG)
        self.bus_tree.bind("<Double-1>", self.bus_double_click)
        make_tree_with_scroll(bottom, self.bus_tree)
        tk.Label(tab, text="Notikumi, kuriem Notikumu pūrā transports ir “Autobuss” un ierakstīta cena. Jāmaksā "
                           "dejotājiem, kuri dejo šajā notikumā, un tiem, kas atzīmēti “brauks ar autobusu” "
                           "(“Nebūs” un “nebrauks” — nemaksā). Izvēlieties dejotājus (Ctrl / Shift — vairākus) un "
                           "spiediet “Reģistrēt samaksu” vai dubultklikšķi; samaksa tiek ierakstīta ienākumos "
                           f"(“{BUS_CATEGORY}”), un Kabatas Pūrlādē dejotājam vairs netiek rādīts, ka jāmaksā.",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL, wraplength=1000, justify="left").pack(
            anchor="w", pady=(4, 0))

    def load_bus(self):
        """[due dict] of the chosen year and groups (kopeja.bus_dues)."""
        try:
            dues = bus_dues(self.db.con)
        except sqlite3.Error:
            dues = []
        year = str(self.year())
        groups = set(self.chosen_groups())
        result = []
        for d in dues:
            person = self.dancer_map.get(d["dancer_id"])
            if not person or person["group"] not in groups or not d["event"]["date"].startswith(year):
                continue
            result.append(d)
        return result

    def refresh_bus(self):
        self.bus_rows = self.load_bus()
        keep = self.bus_ev_tree.selection()
        self.bus_ev_tree.delete(*self.bus_ev_tree.get_children())
        by_event = {}
        for d in self.bus_rows:
            by_event.setdefault(d["session_id"], []).append(d)
        debt_total = 0
        for sid, rows in sorted(by_event.items(), key=lambda kv: (kv[1][0]["event"]["date"], kv[0]), reverse=True):
            ev = rows[0]["event"]
            debt = sum(r["due"] for r in rows)
            debt_total += debt
            if self.bus_only_debt.get() and not debt:
                continue
            groups = ", ".join(g.strip() for g in (ev["groups"] or "").split(",") if g.strip()) or "visas"
            self.bus_ev_tree.insert("", "end", iid=str(sid), tags=("open" if debt else "done",), values=(
                show_date(ev["date"]), ev["title"] or ev["subkind"] or ev["kind"], groups, money(ev["price"]),
                len(rows), sum(1 for r in rows if not r["due"]), money(sum(r["paid"] for r in rows)),
                money(debt) if debt else "✓"))
        self.bus_total.configure(text=f"Parāds par autobusiem {self.year()}: {money(debt_total)}")
        for iid in keep:
            if self.bus_ev_tree.exists(iid):
                self.bus_ev_tree.selection_set(iid)
        if not self.bus_ev_tree.selection() and self.bus_ev_tree.get_children():
            self.bus_ev_tree.selection_set(self.bus_ev_tree.get_children()[0])
        self.refresh_bus_people()

    def bus_event_rows(self):
        sel = self.bus_ev_tree.selection()
        if not sel:
            return None, []
        sid = int(sel[0])
        return sid, [d for d in self.bus_rows if d["session_id"] == sid]

    def refresh_bus_people(self):
        self.bus_tree.delete(*self.bus_tree.get_children())
        _sid, rows = self.bus_event_rows()
        rows = sorted(rows, key=lambda d: (not d["due"], _norm(self.dancer_map[d["dancer_id"]]["name"])))
        for d in rows:
            person = self.dancer_map[d["dancer_id"]]
            if self.bus_only_debt.get() and not d["due"]:
                continue
            self.bus_tree.insert("", "end", iid=str(d["dancer_id"]), tags=("open" if d["due"] else "done",), values=(
                person["name"], person["group"],
                "dejo šajā notikumā" if d["reason"] == BUS_REASON_DANCES else "atzīmēts “brauks”",
                money(d["paid"]) if d["paid"] else "—", money(d["due"]) if d["due"] else "—",
                "✓ samaksāts" if not d["due"] else ("daļēji samaksāts" if d["paid"] else "✗ nav samaksāts")))

    def bus_payment(self, dancer_ids=None):
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        sid, rows = self.bus_event_rows()
        if sid is None:
            return messagebox.showinfo("Izvēle", "Izvēlieties notikumu sarakstā.", parent=self.root)
        ids = dancer_ids if dancer_ids is not None else [int(i) for i in self.bus_tree.selection()]
        chosen = [d for d in rows if d["dancer_id"] in ids and d["due"]]
        if not chosen:
            if ids:
                return messagebox.showinfo("Autobuss", "Izvēlētie dejotāji par šo autobusu jau ir samaksājuši.",
                                           parent=self.root)
            return messagebox.showinfo("Izvēle", "Izvēlieties vienu vai vairākus dejotājus, kuri samaksāja "
                                                 "(Ctrl / Shift — vairākus).", parent=self.root)
        BusPaymentForm(self, sid, chosen)

    def bus_double_click(self, event):
        row = self.bus_tree.identify_row(event.y)
        if not row:
            return
        did = int(row)
        sid, rows = self.bus_event_rows()
        d = next((r for r in rows if r["dancer_id"] == did), None)
        if d and d["due"]:
            return self.bus_payment([did])
        entries = [e for e in self.all_entries if e["session_id"] == sid and e["dancer_id"] == did
                   and e["kind"] == INCOME and e["category"] == BUS_CATEGORY]
        if entries:   # already paid: open the payment (to correct or delete it)
            EntryForm(self, entry_id=max(entries, key=lambda e: (e["entry_date"], e["id"]))["id"])

    def export_bus(self):
        rows = []
        for d in sorted(self.bus_rows, key=lambda r: (r["event"]["date"], _norm(self.dancer_map[r["dancer_id"]]["name"]))):
            person = self.dancer_map[d["dancer_id"]]
            rows.append([show_date(d["event"]["date"]), d["event"]["title"] or d["event"]["kind"], person["name"],
                         person["group"], "dejo" if d["reason"] == BUS_REASON_DANCES else "brauks",
                         money_plain(d["price"]), money_plain(d["paid"]), money_plain(d["due"])])
        save_csv(self.root, "Autobusi", f"autobusi_{self.year()}.csv",
                 ["Datums", "Notikums", "Dejotājs", "Grupa", "Kāpēc maksā", "Cena", "Samaksāts", "Parāds"], rows)

    def build_events_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Honorāri  ")
        bar = toolbar(tab, self._bars)
        b = ttk.Button(bar, text="＋ Reģistrēt saņemto honorāru", style="Accent.TButton", command=self.register_fee)
        b.pack(side="left")
        if not self.can_edit_any:
            b.configure(state="disabled")
        self.ev_only_open = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="Tikai nesaņemtie", variable=self.ev_only_open, bg=CREAM, fg=NAVY,
                       activebackground=CREAM, selectcolor=WHITE, command=self.refresh_events).pack(side="left",
                                                                                                    padx=(14, 0))
        cols = [("date", "Datums", 95), ("kind", "Veids", 130), ("title", "Notikums", 260), ("groups", "Grupa", 90),
                ("fee", "Honorārs (Notikumu pūrā)", 200), ("got", "Saņemts", 110), ("status", "Statuss", 120)]
        holder = boxed(tab)
        holder.pack(fill="both", expand=True)
        self.ev_tree = ttk.Treeview(holder, columns=[c[0] for c in cols], show="headings")
        for key, title, width in cols:
            self.ev_tree.heading(key, text=title)
            self.ev_tree.column(key, width=width, anchor="e" if key == "got" else "w", stretch=key == "title")
        self.ev_tree.tag_configure("open", foreground=RED)
        self.ev_tree.tag_configure("done", foreground=OK_FG)
        self.ev_tree.bind("<Double-1>", lambda e: self.register_fee())
        make_tree_with_scroll(holder, self.ev_tree)
        tk.Label(tab, text="Notikumi, kuriem Notikumu pūrā ierakstīts honorārs (vai kuriem Zelta pūrā piesaistīts "
                           "ienākums). Saņemto honorāru reģistrē kā ienākumu — tas tiek piesaistīts notikumam.",
                 bg=CREAM, fg=MUTED, font=FONT_SMALL).pack(anchor="w", pady=(4, 0))

    # ---- tab: Pārskats --------------------------------------------------------
    def build_report_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Pārskats  ")
        bar = toolbar(tab, self._bars)
        self.report_title = tk.StringVar()
        tk.Label(bar, textvariable=self.report_title, bg=CREAM, fg=NAVY, font=("Georgia", 13, "bold")).pack(
            side="left")
        ttk.Button(bar, text="⇩ Eksportēt (Excel)", command=self.export_report).pack(side="right")
        body = ttk.Frame(tab)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        body.rowconfigure(1, weight=0)
        left = boxed(body)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.cat_tree = ttk.Treeview(left, columns=("category", "count", "sum"), show="tree headings")
        self.cat_tree.heading("#0", text="")
        self.cat_tree.column("#0", width=24, stretch=False)
        for key, text, w in (("category", "Kategorija", 230), ("count", "Darījumi", 70), ("sum", "Summa", 120)):
            self.cat_tree.heading(key, text=text)
            self.cat_tree.column(key, width=w, anchor="e" if key != "category" else "w")
        self.cat_tree.tag_configure(INCOME, foreground=OK_FG, font=("Segoe UI", 10, "bold"))
        self.cat_tree.tag_configure(EXPENSE, foreground=RED, font=("Segoe UI", 10, "bold"))
        self.cat_tree.tag_configure("total", foreground=NAVY, font=("Segoe UI", 10, "bold"))
        make_tree_with_scroll(left, self.cat_tree)
        right = boxed(body)
        right.grid(row=0, column=1, sticky="nsew")
        chart = boxed(body)
        chart.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(10, 0))
        tk.Label(chart, text="Ienākumi un izdevumi pa mēnešiem", bg=WHITE, fg=NAVY, font=("Georgia", 12, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(8, 0))
        self.report_canvas = tk.Canvas(chart, bg=WHITE, highlightthickness=0, height=170)
        self.report_canvas.pack(fill="both", expand=True, padx=10, pady=(4, 8))
        self.report_canvas.bind("<Configure>", lambda e: self.draw_report_chart())
        self.month_tree = ttk.Treeview(right, columns=("month", "in", "out", "diff", "balance"), show="headings")
        for key, text, w in (("month", "Mēnesis", 110), ("in", "Ienākumi", 110), ("out", "Izdevumi", 110),
                             ("diff", "Starpība", 110), ("balance", "Atlikums mēneša beigās", 160)):
            self.month_tree.heading(key, text=text)
            self.month_tree.column(key, width=w, anchor="w" if key == "month" else "e")
        self.month_tree.tag_configure("neg", foreground=RED)
        self.month_tree.tag_configure("total", font=("Segoe UI", 10, "bold"))
        make_tree_with_scroll(right, self.month_tree)

    # ---- data helpers ----------------------------------------------------------
    def chosen_groups(self):
        g = self.group_var.get()
        return list(self.groups) if g == ALL_GROUPS else [g]

    def year(self):
        try:
            return int(self.year_var.get())
        except ValueError:
            return date.today().year

    def visible_entries(self):
        groups = set(self.chosen_groups())
        return [e for e in self.all_entries if (e["fin_group"] or DEFAULT_DANCER_GROUP) in groups]

    def show_main(self):
        self.nb.select(0)
        self.clear_filters()
        self.tree.yview_moveto(0)

    def clear_filters(self):
        self.search.set("")
        self.f_kind.set(ALL)
        self.f_cat.set(ALL)
        self.f_month.set(ALL)
        self.refresh_entries()

    def sort_by(self, key):
        self.sort_desc = not self.sort_desc if key == self.sort_key else key in ("date", "amount")
        self.sort_key = key
        self.refresh_entries()

    # ---- refresh -----------------------------------------------------------------
    def refresh_all(self):
        try:
            self.all_entries = self.db.entries()
            self.dancer_map = self.db.dancers()
            self.event_map = {e[0]: e for e in self.db.events()}
        except sqlite3.Error as exc:
            messagebox.showerror("Datubāze", f"Neizdevās nolasīt datus:\n{exc}", parent=self.root)
            return
        years = {date.today().year}
        years.update(int(e["entry_date"][:4]) for e in self.all_entries if (e["entry_date"] or "")[:4].isdigit())
        self.year_cb.configure(values=[str(y) for y in sorted(years, reverse=True)])
        seasons = {current_season(), current_season() + 1}
        seasons.update(season_of(m) for e in self.all_entries for m in parse_months(e["fee_months"]))
        self.season_cb.configure(values=[season_label(y) for y in sorted(seasons, reverse=True)])
        c_seasons = {current_season(), current_season() + 1}
        c_seasons.update(half_parts(k)[0] for e in self.all_entries if e["category"] == COSTUME_CATEGORY
                         for k, _c in half_parts_of(e["fee_months"]))
        self.costume_season_cb.configure(values=[season_label(y) for y in sorted(c_seasons, reverse=True)])
        cats = [n for _k, n in self.db.categories()]
        self.cat_filter.configure(values=[ALL] + list(dict.fromkeys(cats)))
        self.refresh_cards()
        self.refresh_entries()
        self.refresh_fees()
        self.refresh_costume()
        self.refresh_bus()
        self.refresh_events()
        self.refresh_report()

    def balance_parts(self, until=None):
        """(cash, bank) of the chosen groups: opening balances + entries up to `until` (ISO date, included)."""
        groups = set(self.chosen_groups())
        opening = self.db.opening()
        totals = {CASH: 0, BANK: 0}
        for (g, m), cents in opening.items():
            if g in groups and m in totals:
                totals[m] += cents
        for e in self.visible_entries():
            if until and (e["entry_date"] or "") > until:
                continue
            m = e["method"] if e["method"] in totals else BANK
            totals[m] += e["amount_cents"] if e["kind"] == INCOME else -e["amount_cents"]
        return totals[CASH], totals[BANK]

    def refresh_cards(self):
        cash, bank = self.balance_parts()
        year = str(self.year())
        rows = [e for e in self.visible_entries() if (e["entry_date"] or "").startswith(year)]
        income = sum(e["amount_cents"] for e in rows if e["kind"] == INCOME)
        expense = sum(e["amount_cents"] for e in rows if e["kind"] == EXPENSE)
        self.card_vars["balance"].set(money(cash + bank))
        self.card_vars["cash"].set(money(cash))
        self.card_vars["bank"].set(money(bank))
        self.card_vars["income"].set(money(income))
        self.card_vars["expense"].set(money(expense))
        self.card_titles["income"][0].set(f"Ienākumi {year}")
        self.card_titles["expense"][0].set(f"Izdevumi {year}")
        self.card_vars["debt"].set(money(self.fee_debt_total()))
        self.card_titles["debt"][0].set(f"Dalības maksu parāds {season_label(self.season())}")
        self.card_vars["costume_debt"].set(money(self.costume_debt_total()))
        self.card_titles["costume_debt"][0].set(f"Tērpu fonda parāds {season_label(self.costume_season())}")

    def event_text(self, sid):
        ev = self.event_map.get(sid)
        if not ev:
            return ""
        return f"{show_date(ev[1])} · {ev[3] or ev[2]}"

    def refresh_entries(self):
        year = str(self.year())
        term = _norm(self.search.get())
        month = self.f_month.get()
        rows = []
        for e in self.visible_entries():
            if not (e["entry_date"] or "").startswith(year):
                continue
            if month != ALL and (e["entry_date"] or "")[5:7] != f"{MONTHS.index(month) + 1:02d}":
                continue
            if self.f_kind.get() != ALL and e["kind"] != self.f_kind.get():
                continue
            if self.f_cat.get() != ALL and e["category"] != self.f_cat.get():
                continue
            r = {"id": e["id"], "date": e["entry_date"] or "", "kind": e["kind"], "category": e["category"] or "",
                 "amount": e["amount_cents"] if e["kind"] == INCOME else -e["amount_cents"],
                 "group": e["fin_group"] or "", "party": e["party"] or "", "method": e["method"] or "",
                 "event": self.event_text(e["session_id"]), "document": e["document"] or "",
                 "notes": " ".join((e["notes"] or "").split())}
            if e["category"] == FEE_CATEGORY and e["fee_months"]:
                months = ", ".join(MONTHS_SHORT[int(m[5:7]) - 1] + " " + m[:4] for m in parse_months(e["fee_months"]))
                r["notes"] = f"par {months}" + (f" · {r['notes']}" if r["notes"] else "")
            elif e["category"] == COSTUME_CATEGORY and e["fee_months"]:
                halves = ", ".join(half_label(k) for k, _c in half_parts_of(e["fee_months"]))
                if halves and halves not in r["notes"]:
                    r["notes"] = f"par {halves}" + (f" · {r['notes']}" if r["notes"] else "")
            if term and term not in _norm(" ".join(str(v) for k, v in r.items() if k != "id")):
                continue
            rows.append(r)

        def key(r):
            v = r[self.sort_key]
            return (0, v) if isinstance(v, int) else (v == "", _norm(v))
        rows.sort(key=lambda r: r["id"], reverse=True)
        rows.sort(key=key, reverse=self.sort_desc)
        keep = self.tree.selection()[0] if self.tree.selection() else None
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            values = [show_date(r["date"]) if k == "date" else money(r["amount"], sign=True) if k == "amount"
                      else r[k] for k, _t, _w in ENTRY_COLUMNS]
            self.tree.insert("", "end", iid=str(r["id"]), values=values,
                             tags=(r["kind"],) + (("odd",) if len(self.tree.get_children()) % 2 else ()))
        if keep and self.tree.exists(keep):
            self.tree.selection_set(keep)
        inc = sum(r["amount"] for r in rows if r["amount"] > 0)
        out = -sum(r["amount"] for r in rows if r["amount"] < 0)
        self.shown_entries = rows
        self.entries_info.set(f"Rādīti {len(rows)} darījumi ({year}): ienākumi {money(inc)}, izdevumi {money(out)}, "
                              f"starpība {money(inc - out, sign=True)}. Dubultklikšķis — atvērt; klikšķis uz "
                              "virsraksta — kārtot.")

    # ---- fees ------------------------------------------------------------------------
    def season(self):
        try:
            return int(self.season_var.get()[:4])
        except (ValueError, AttributeError):
            return current_season()

    def fee_rows(self, season):
        """[(dancer, {'GGGG-MM': (due, paid, past)}, paid in the season, debt)] for the chosen groups and season."""
        rates, personal = self.db.fee_rates(), self.db.personal_fees()
        paid = fee_paid_by_month(self.all_entries)
        groups = set(self.chosen_groups())
        now = this_month()
        months = season_months(season)
        out = []
        for d in sorted(self.dancer_map.values(), key=lambda d: _norm(d["name"])):
            if not d["dancer"] or d["group"] not in groups:
                continue
            got = paid.get(d["id"], {})
            season_paid = sum(got.get(k, 0) for k in months)
            if d["status"] == STATUS_LEFT and not season_paid and not self.fee_show_left.get():
                continue
            cells = {}
            debt = 0
            counted = d["status"] == STATUS_ACTIVE
            due_list = set(due_months(d, season))
            for key in months:
                due = fee_due(rates, personal, d, key) if key in due_list else 0
                cells[key] = (due, got.get(key, 0), key <= now)
                if counted and key <= now:
                    debt += max(due - got.get(key, 0), 0)
            out.append((d, cells, season_paid, debt))
        return out

    def fee_debt_total(self):
        try:
            return sum(r[3] for r in self.fee_rows(self.season()))
        except Exception:
            log_error(traceback.format_exc())
            return 0

    def refresh_fees(self):
        season = self.season()
        months = season_months(season)
        for i, key in enumerate(months, start=1):
            self.fee_tree.heading(f"m{i}", text=month_short(key))
        rates, personal = self.db.fee_rates(), self.db.personal_fees()
        rows = []
        self.fee_export = []
        for d, cells, season_paid, debt in self.fee_rows(season):
            values = {"name": d["name"] + ("" if d["status"] == STATUS_ACTIVE else f" ({d['status'].lower()})"),
                      "group": d["group"]}
            rate = fee_due(rates, personal, d, this_month())
            values["rate"] = money(rate, euro=False) + ("*" if d["id"] in personal else "")
            exp = [d["name"], d["group"], d["status"], money_plain(rate)]
            states = {}
            for i, key in enumerate(months, start=1):
                due, got, past = cells[key]
                if got and got >= due:
                    cell, state = "✓", "y"
                elif got:
                    cell, state = money(got, euro=False), "p"
                elif not due:
                    cell, state = "–", "x"
                elif past:
                    cell, state = "✗", "n"
                else:
                    cell, state = "", "f"
                values[f"m{i}"], states[f"m{i}"] = cell, state
                exp.append(money_plain(got) if got else ("" if not due else "0"))
            values["paid"], values["debt"] = money(season_paid), (money(debt) if debt else "—")
            exp += [money_plain(season_paid), money_plain(debt)]
            tag = ("left" if d["status"] == STATUS_LEFT else "pause" if d["status"] == STATUS_INACTIVE
                   else "debt" if debt else "ok")
            rows.append({"iid": str(d["id"]), "values": values, "states": states, "tag": tag})
            self.fee_export.append(exp)
        self.fee_tree.set_rows(rows)
        missing = [g for g in self.chosen_groups() if not rates.get(g)]  # noqa: the "__due__" key is never a group
        self.fee_tree.heading("rate", text="€/mēn." + (" ⚠" if missing else ""))

    def selected_fee_dancer(self):
        sel = self.fee_tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties dejotāju sarakstā.", parent=self.root)
            return None
        return self.dancer_map.get(int(sel[0]))

    def fee_payment(self, dancer_id=None, month=None):
        """month: 'GGGG-MM' to tick in the form."""
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        if not has_rates(self.db.fee_rates()):
            if messagebox.askyesno("Dalības maksa", "Dalības maksas apmērs vēl nav iestatīts. Iestatīt tagad?",
                                   parent=self.root):
                FeeRatesWindow(self)
            return
        if dancer_id is None and self.fee_tree.selection():
            dancer_id = int(self.fee_tree.selection()[0])
        FeePaymentForm(self, dancer_id, self.season(), month)

    def fee_double_click(self, row, cid):
        """Double click in the fee table (row = dancer id, cid = column key)."""
        if not row:
            return
        month = None
        if cid and re.fullmatch(r"m\d{1,2}", cid):
            month = season_months(self.season())[int(cid[1:]) - 1]
        if month is not None:
            paid_entries = [e for e in self.all_entries if e["category"] == FEE_CATEGORY
                            and e["dancer_id"] == int(row) and month in parse_months(e["fee_months"])]
            due, got, _past = self.fee_cell(int(row), month)
            if got and got >= due and paid_entries:   # paid: show the payment
                return EntryForm(self, paid_entries[-1]["id"])
        self.fee_payment(int(row), month)

    def fee_cell(self, dancer_id, month):
        for d, cells, _p, _debt in self.fee_rows(self.season()):
            if d["id"] == dancer_id:
                return cells.get(month, (0, 0, False))
        return (0, 0, False)

    def personal_fee(self):
        d = self.selected_fee_dancer()
        if d:
            PersonalFeeForm(self, d)

    # ---- honoraria ---------------------------------------------------------------------
    def refresh_events(self):
        year = str(self.year())
        groups = set(self.chosen_groups())
        received = {}
        for e in self.visible_entries():
            if e["session_id"] and e["kind"] == INCOME and e["category"] != BUS_CATEGORY:   # not bus payments
                received[e["session_id"]] = received.get(e["session_id"], 0) + e["amount_cents"]
        self.ev_tree.delete(*self.ev_tree.get_children())
        for sid, d, kind, title, for_groups, fee in self.event_map.values():
            if not (d or "").startswith(year):
                continue
            ev_groups = [g.strip() for g in (for_groups or "").split(",") if g.strip()]
            if ev_groups and not (set(ev_groups) & groups):
                continue
            fee = (fee or "").strip()
            got = received.get(sid, 0)
            if not fee and not got:
                continue
            done = bool(got)
            if self.ev_only_open.get() and done:
                continue
            self.ev_tree.insert("", "end", iid=str(sid), tags=("done" if done else "open",), values=(
                show_date(d), kind, title, ", ".join(ev_groups) or "visas", fee, money(got) if got else "—",
                "✓ saņemts" if done else ("nākotnē" if d > date.today().isoformat() else "✗ nav saņemts")))

    def register_fee(self):
        if not self.can_edit_any:
            return piekluve.deny(self.root)
        sel = self.ev_tree.selection()
        if not sel:
            return messagebox.showinfo("Izvēle", "Izvēlieties notikumu sarakstā.", parent=self.root)
        sid = int(sel[0])
        ev = self.event_map.get(sid)
        preset = {"event": sid, "category": FEE_CATEGORY_EVENT, "method": BANK}
        if ev:
            cents = parse_money(re.sub(r"[^\d,.\s€]", "", ev[5] or "").strip())
            if cents:
                preset["amount"] = money(cents, euro=False).replace(" ", "")
            ev_groups = [g.strip() for g in (ev[4] or "").split(",") if g.strip()]
            for g in ev_groups:
                if g in self.groups:
                    preset["group"] = g
                    break
            preset["party"] = ""
        if FEE_CATEGORY_EVENT not in self.db.categories(INCOME):
            preset.pop("category")
        EntryForm(self, kind=INCOME, preset=preset)

    # ---- report ------------------------------------------------------------------------
    def refresh_report(self):
        year = self.year()
        y = f"{year:04d}"
        self.report_title.set(f"{y}. gads — " + ", ".join(self.chosen_groups()) +
                              (" grupa" if len(self.chosen_groups()) == 1 else " grupas"))
        rows = [e for e in self.visible_entries() if (e["entry_date"] or "").startswith(y)]
        self.cat_tree.delete(*self.cat_tree.get_children())
        self.report_export = []
        totals = {}
        for kind in KINDS:
            sums = {}
            for e in rows:
                if e["kind"] == kind:
                    c = e["category"] or "(bez kategorijas)"
                    n, s = sums.get(c, (0, 0))
                    sums[c] = (n + 1, s + e["amount_cents"])
            total = sum(s for _n, s in sums.values())
            totals[kind] = total
            parent = self.cat_tree.insert("", "end", open=True, tags=(kind,), values=(
                kind, sum(n for n, _s in sums.values()), money(total)))
            self.report_export.append([kind, "", money_plain(total)])
            for c, (n, s) in sorted(sums.items(), key=lambda kv: -kv[1][1]):
                self.cat_tree.insert(parent, "end", values=(c, n, money(s)))
                self.report_export.append(["", c, money_plain(s)])
        self.cat_tree.insert("", "end", tags=("total",), values=(
            "Starpība", "", money(totals[INCOME] - totals[EXPENSE], sign=True)))
        self.report_export.append(["Starpība", "", money_plain(totals[INCOME] - totals[EXPENSE])])

        self.month_tree.delete(*self.month_tree.get_children())
        cash, bank = self.balance_parts(until=f"{year - 1:04d}-12-31")
        balance = cash + bank
        self.month_tree.insert("", "end", tags=("total",), values=(
            "Gada sākumā", "", "", "", money(balance)))
        self.month_export = [["Gada sākumā", "", "", "", money_plain(balance)]]
        for m in range(1, 13):
            prefix = f"{y}-{m:02d}"
            inc = sum(e["amount_cents"] for e in rows if e["kind"] == INCOME and e["entry_date"].startswith(prefix))
            out = sum(e["amount_cents"] for e in rows if e["kind"] == EXPENSE and e["entry_date"].startswith(prefix))
            balance += inc - out
            self.month_tree.insert("", "end", tags=("neg",) if balance < 0 else (), values=(
                MONTHS[m - 1], money(inc) if inc else "", money(out) if out else "",
                money(inc - out, sign=True) if inc or out else "", money(balance)))
            self.month_export.append([MONTHS[m - 1], money_plain(inc), money_plain(out), money_plain(inc - out),
                                      money_plain(balance)])
        self.month_tree.insert("", "end", tags=("total",), values=(
            "Kopā", money(totals[INCOME]), money(totals[EXPENSE]), money(totals[INCOME] - totals[EXPENSE], sign=True),
            money(balance)))
        self.month_export.append(["Kopā", money_plain(totals[INCOME]), money_plain(totals[EXPENSE]),
                                  money_plain(totals[INCOME] - totals[EXPENSE]), money_plain(balance)])
        self.draw_report_chart()

    def draw_report_chart(self):
        """Income (green) and expenses (red) of every month of the chosen year."""
        c = getattr(self, "report_canvas", None)
        if c is None:
            return
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        if w < 100 or h < 60:
            return
        y = f"{self.year():04d}"
        rows = [e for e in self.visible_entries() if (e["entry_date"] or "").startswith(y)]
        data = []
        for m in range(1, 13):
            prefix = f"{y}-{m:02d}"
            inc = sum(e["amount_cents"] for e in rows if e["kind"] == INCOME and e["entry_date"].startswith(prefix))
            out = sum(e["amount_cents"] for e in rows if e["kind"] == EXPENSE and e["entry_date"].startswith(prefix))
            data.append((MONTHS_SHORT[m - 1], inc, out))
        peak = max([max(i, o) for _m, i, o in data] + [1])
        top, bottom, left = 10, 22, 8
        slot = (w - 2 * left - 150) / 12
        bar = min(18, slot * 0.32)
        base = h - bottom
        for i, (label, inc, out) in enumerate(data):
            cx = left + slot * (i + 0.5)
            for dx, v, colour in ((-bar / 2 - 1, inc, OK_FG), (bar / 2 + 1, out, RED)):
                if v:
                    c.create_rectangle(cx + dx - bar / 2, base - (base - top) * v / peak, cx + dx + bar / 2, base,
                                       fill=colour, outline="")
            c.create_text(cx, base + 5, text=label, anchor="n", fill="#4A4535", font=FONT_SMALL)
        c.create_line(left, base, left + slot * 12, base, fill=LINE)
        lx = w - 140
        for j, (text, colour) in enumerate((("Ienākumi", OK_FG), ("Izdevumi", RED))):
            c.create_rectangle(lx, 14 + j * 20, lx + 12, 26 + j * 20, fill=colour, outline="")
            c.create_text(lx + 18, 20 + j * 20, text=text, anchor="w", fill=NAVY, font=FONT_SMALL)
        c.create_text(lx, 64, text=f"lielākais: {money(peak)}", anchor="w", fill=MUTED, font=FONT_SMALL)

    # ---- entries: open / delete / export -----------------------------------------------
    def selected_entry(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Izvēle", "Izvēlieties darījumu sarakstā.", parent=self.root)
            return None
        return int(sel[0])

    def edit_entry(self):
        eid = self.selected_entry()
        if eid is not None:
            EntryForm(self, eid)

    def delete_entry(self):
        eid = self.selected_entry()
        if eid is None:
            return
        e = self.db.entry(eid)
        if e is None:
            self.refresh_all()
            return
        if not piekluve.current().can_edit(MODULE_KEY, group=e["fin_group"]):
            return piekluve.deny(self.root, "Šīs grupas finanses jūsu loma nevar mainīt.")
        text = f"{show_date(e['entry_date'])} · {e['category']} · {money(e['amount_cents'])}"
        if messagebox.askyesno("Dzēst", f"Dzēst darījumu?\n\n{text}", parent=self.root):
            self.db.x("DELETE FROM fin_entries WHERE id=?", (eid,))
            self.refresh_all()

    def export_entries(self):
        header = [t for _k, t, _w in ENTRY_COLUMNS]
        rows = []
        for r in getattr(self, "shown_entries", []):
            rows.append([show_date(r["date"]) if k == "date" else money_plain(r["amount"]) if k == "amount"
                         else r[k] for k, _t, _w in ENTRY_COLUMNS])
        save_csv(self.root, "Eksportēt darījumus", f"Zelta pūrs darījumi {self.year()}.csv", header, rows)

    def export_fees(self):
        header = (["Dejotājs", "Grupa", "Statuss", "€/mēn."] + [month_label(k) for k in season_months(self.season())]
                  + ["Samaksāts sezonā", "Parāds"])
        name = season_label(self.season()).replace("/", "-")
        save_csv(self.root, "Eksportēt dalības maksas", f"Zelta pūrs dalības maksas {name}.csv", header,
                 getattr(self, "fee_export", []))

    def export_report(self):
        rows = [["Pa kategorijām"], ["Veids", "Kategorija", "Summa"]] + self.report_export + [[]]
        rows += [["Pa mēnešiem"], ["Mēnesis", "Ienākumi", "Izdevumi", "Starpība", "Atlikums"]] + self.month_export
        save_csv(self.root, "Eksportēt pārskatu", f"Zelta pūrs pārskats {self.year()}.csv",
                 [f"Zelta pūrs — pārskats {self.year()}", ", ".join(self.chosen_groups())], rows)


def start(root, on_exit, title_prefix=""):
    """Entry point used by Pūrlāde: builds the module inside the given window."""
    return App(root, on_exit=on_exit, title_prefix=title_prefix)


def main():
    if console_is_own():
        set_console_visible(False)
    try:
        root = tk.Tk()

        def report(exc, val, tb):
            log_error("".join(traceback.format_exception(exc, val, tb)))
            try:
                messagebox.showerror("Kļūda", f"Radās kļūda: {val}\n\nDetaļas saglabātas failā:\n{ERROR_LOG}",
                                     parent=root)
            except Exception:
                pass

        root.report_callback_exception = report
        App(root)
        root.mainloop()
    except Exception:
        log_error(traceback.format_exc())
        set_console_visible(True)
        print(traceback.format_exc())


if __name__ == "__main__":
    main()
